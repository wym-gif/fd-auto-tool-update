import { normalizeRawEvents } from "../contracts/raw-event.js";
import { createPreviewTask } from "../contracts/preview-task.js";
import { classifyChangeDayMarkerEvent, normalizeSendDate } from "../date/date-rules.js";
import { normalizeMessageText } from "./message-text.js";
import { detectRoleHeader, isNonSendableRemark } from "./role-header.js";

export function parseFixedFormatTasks(rawEvents, options = {}) {
  const events = normalizeRawEvents(rawEvents);
  const tasks = [];
  const diagnostics = [];
  const interactionGroups = new Map();
  const useSendDateContext = Boolean(options.baseSendDate || options.date);
  const baseSendDate = normalizeSendDate(options.baseSendDate || options.date || "");
  let currentSendDate = baseSendDate;
  let nextInteractionGroup = 1;
  let currentDaySegment = 1;
  let current = null;
  let order = 1;

  for (let eventIndex = 0; eventIndex < events.length; eventIndex += 1) {
    const event = events[eventIndex];
    const dayMarker = useSendDateContext ? classifyChangeDayMarkerEvent(event, baseSendDate) : null;
    if (dayMarker?.isHeading) {
      flushText(current, tasks, () => order++);
      current = null;
      if (dayMarker.date) {
        currentSendDate = dayMarker.date;
        currentDaySegment += 1;
        interactionGroups.clear();
        diagnostics.push({
          code: "change_day_marker",
          sourceId: event.sourceId,
          date: dayMarker.date,
          message: `换天标题切换后续发单日期：${dayMarker.date}`
        });
      } else {
        diagnostics.push({
          code: dayMarker.ignoredReason || "ignored_day_marker",
          sourceId: event.sourceId,
          date: dayMarker.ignoredDate || "",
          message: `换天标题日期已过期，继续使用当前发单日期：${currentSendDate}`
        });
      }
      continue;
    }

    const header = detectRoleHeader(event, roleDetectionOptions(options, current));
    if (header) {
      flushText(current, tasks, () => order++);
      current = startSegment(header, event, {
        interactionGroups,
        sendDate: useSendDateContext ? currentSendDate : "",
        daySegment: currentDaySegment,
        nextInteractionGroupRef: {
          get value() {
            return nextInteractionGroup;
          },
          set value(next) {
            nextInteractionGroup = next;
          }
        }
      });
      if (header.useLineAsContent) appendText(current, event.text, event);
      if (!header.time && (options.scheduleMode || "doc") === "doc") {
        diagnostics.push({
          code: "missing_document_time",
          sourceId: event.sourceId,
          message: `角色行没有时间：${event.text}`
        });
      }
      continue;
    }

    if (!current) continue;
    if (event.kind === "divider") {
      flushText(current, tasks, () => order++);
      continue;
    }
    if (event.kind === "line") {
      const cleanedText = cleanBodyText(event.text);
      if (cleanedText.trim() && isNonSendableRemark(cleanedText, { insideRoleSegment: true })) continue;
      if (!cleanedText.trim() && String(event.text || "").trim()) continue;
      appendText(current, cleanedText, event);
      continue;
    }
    if (event.kind === "image" || event.kind === "sticker" || event.kind === "video") {
      if (isFeishuStickerImageEcho(event, events[eventIndex - 1], events[eventIndex + 1])) {
        diagnostics.push({
          code: "dropped_sticker_image_echo",
          sourceId: event.sourceId,
          message: "已忽略飞书同一素材同时暴露出的表情包副本，保留图片"
        });
        continue;
      }
      flushText(current, tasks, () => order++);
      tasks.push(makeMediaTask(current, event, order++));
    }
  }

  flushText(current, tasks, () => order++);
  return { tasks, diagnostics };
}

function roleDetectionOptions(options, current) {
  if (!current) return options;
  return {
    ...options,
    allowBareNameHeaders: options.allowBareNameHeadersInsideSegment === true,
    allowHighlightedDouma: false
  };
}

function startSegment(header, event, refs) {
  const interactionKey = header.role === "tuo" ? normalizeInteractionKey(header.speaker) : "";
  let interactionGroup = "";
  if (interactionKey) {
    if (header.continueSpeaker && !refs.interactionGroups.has(interactionKey)) {
      refs.interactionGroups.set(interactionKey, `interaction-${refs.nextInteractionGroupRef.value}`);
      refs.nextInteractionGroupRef.value += 1;
    }
    interactionGroup = refs.interactionGroups.get(interactionKey) || "";
  }

  return {
    sourceId: event.sourceId,
    sourceText: header.sourceText,
    role: header.role,
    speaker: header.speaker,
    date: refs.sendDate || header.date,
    documentDate: header.date,
    documentTime: header.time,
    daySegment: refs.daySegment || 1,
    time: header.time,
    interactionGroup,
    continueMarker: Boolean(header.continueSpeaker),
    cleanSpeaker: header.cleanSpeaker || header.speaker,
    speakerConfidence: header.speakerConfidence || "",
    textBuffer: [],
    textSourceIds: [],
    textSourceText: []
  };
}

function appendText(segment, text, event) {
  if (!segment) return;
  const line = cleanBodyText(text);
  segment.textBuffer.push(line);
  segment.textSourceIds.push(event.sourceId);
  segment.textSourceText.push(event.sourceText || event.text || "");
}

function flushText(segment, tasks, nextOrder) {
  if (!segment || !segment.textBuffer.length) return;
  const text = normalizeMessageText(segment.textBuffer.join("\n"));
  segment.textBuffer = [];
  const sourceIds = segment.textSourceIds.splice(0);
  const sourceText = segment.textSourceText.splice(0).join("\n");
  if (!text) return;
  tasks.push(createPreviewTask({
    sourceId: sourceIds.join(",") || segment.sourceId,
    sourceText: sourceText || segment.sourceText,
    role: segment.role,
    speaker: segment.speaker,
    date: segment.date,
    documentDate: segment.documentDate,
    documentTime: segment.documentTime,
    daySegment: segment.daySegment,
    time: segment.time,
    type: "text",
    text,
    mediaPath: "",
    skip: false,
    order: nextOrder(),
    interactionGroup: segment.interactionGroup,
    continueMarker: segment.continueMarker,
    cleanSpeaker: segment.cleanSpeaker,
    speakerConfidence: segment.speakerConfidence
  }));
}

function cleanBodyText(text) {
  return String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/（[^）]*下面还说话[^）]*）/g, "")
    .replace(/\([^)]*下面还说话[^)]*\)/g, "")
    .replace(/【[^】]*下面还说话[^】]*】/g, "")
    .replace(/\[[^\]]*下面还说话[^\]]*\]/g, "")
    .replace(/下面还说话/g, "")
    .split("\n")
    .map((line) => line.trim())
    .join("\n");
}

function trimOuterBlankLines(text) {
  const lines = String(text || "").split("\n");
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines.at(-1).trim()) lines.pop();
  return lines.join("\n");
}

function makeMediaTask(segment, event, order) {
  const sourceUrl = firstStableSourceUrl(
    event.sourceUrl,
    event.raw?.sourceUrl,
    event.raw?.originalMediaPath,
    event.raw?.originalBlobMediaPath,
    event.assetUrl
  );
  return createPreviewTask({
    sourceId: event.sourceId,
    sourceText: event.sourceText || segment.sourceText,
    role: segment.role,
    speaker: segment.speaker,
    date: segment.date,
    documentDate: segment.documentDate,
    documentTime: segment.documentTime,
    daySegment: segment.daySegment,
    time: segment.time,
    type: event.kind,
    text: "",
    mediaPath: event.mediaPath || event.assetUrl,
    sourceUrl,
    skip: false,
    order,
    interactionGroup: segment.interactionGroup,
    continueMarker: segment.continueMarker,
    cleanSpeaker: segment.cleanSpeaker,
    speakerConfidence: segment.speakerConfidence
  });
}

function isFeishuStickerImageEcho(event, previous, next) {
  if (event?.kind !== "sticker") return false;
  return isDuplicateStickerImagePair(event, previous) || isDuplicateStickerImagePair(event, next);
}

function isDuplicateStickerImagePair(left, right) {
  if (!left || !right) return false;
  const kinds = new Set([left.kind, right.kind]);
  if (!kinds.has("sticker") || !kinds.has("image")) return false;
  if (String(left.collectSpeaker || "") !== String(right.collectSpeaker || "")) return false;
  if (String(left.collectTime || "") !== String(right.collectTime || "")) return false;
  if (!eventsOverlapAtSameVisualPosition(left, right)) return false;
  return hasFeishuCoverSource(left) !== hasFeishuCoverSource(right) && hasTemporaryInlineImageSource(left, right);
}

function eventsOverlapAtSameVisualPosition(left, right) {
  const leftBox = left.boundingInfo || {};
  const rightBox = right.boundingInfo || {};
  const leftY = Number(left.y ?? leftBox.y);
  const rightY = Number(right.y ?? rightBox.y);
  if (Number.isFinite(leftY) && Number.isFinite(rightY) && Math.abs(leftY - rightY) <= 2) return true;
  const leftTop = Number(leftBox.y);
  const rightTop = Number(rightBox.y);
  const leftBottom = leftTop + Number(leftBox.height || 0);
  const rightBottom = rightTop + Number(rightBox.height || 0);
  if (![leftTop, rightTop, leftBottom, rightBottom].every(Number.isFinite)) return false;
  return Math.max(leftTop, rightTop) <= Math.min(leftBottom, rightBottom);
}

function hasFeishuCoverSource(event) {
  return /internal-api-drive-stream\.feishu\.cn\/space\/api\/box\/stream\/download\/v2\/cover\//i.test([
    event.sourceUrl,
    event.assetUrl,
    event.mediaPath,
    event.raw?.sourceUrl,
    event.raw?.assetUrl,
    event.raw?.mediaPath
  ].map((value) => String(value || "")).join("\n"));
}

function hasTemporaryInlineImageSource(...events) {
  return events.some((event) => {
    const text = [event.sourceUrl, event.assetUrl, event.mediaPath, event.raw?.sourceUrl, event.raw?.assetUrl, event.raw?.mediaPath]
      .map((value) => String(value || ""))
      .join("\n");
    return Boolean(event.inlineMediaDataUrl || event.raw?.inlineMediaDataUrl || /(^|\n)(blob:|image-blob:)/i.test(text));
  });
}

function firstStableSourceUrl(...values) {
  for (const value of values) {
    const text = String(value || "").trim();
    if (!text || /^(blob:|image-blob:)/i.test(text)) continue;
    return text;
  }
  return "";
}

function normalizeInteractionKey(speaker) {
  return String(speaker || "").replace(/\s+/g, "").toLowerCase();
}

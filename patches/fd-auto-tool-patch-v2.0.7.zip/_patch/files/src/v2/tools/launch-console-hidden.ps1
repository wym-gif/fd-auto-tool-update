param(
  [string]$ProjectRoot = ""
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
  $ProjectRoot = Join-Path $PSScriptRoot "..\..\.."
}

$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$ScriptPath = Join-Path $ProjectRoot "src\v2\tools\run-console-cli.js"
$BundledNode = Join-Path $ProjectRoot "tools\node\node.exe"
$NodeExe = if (Test-Path -LiteralPath $BundledNode) { $BundledNode } else { "node.exe" }
$LocalBrowsers = Join-Path $ProjectRoot "ms-playwright"
if (Test-Path -LiteralPath $LocalBrowsers) {
  $env:PLAYWRIGHT_BROWSERS_PATH = $LocalBrowsers
}
Set-Location -LiteralPath $ProjectRoot
$LogDir = Join-Path $ProjectRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$StdOut = Join-Path $LogDir "v2-console-hidden-$Stamp.out.log"
$StdErr = Join-Path $LogDir "v2-console-hidden-$Stamp.err.log"

Start-Process `
  -FilePath $NodeExe `
  -ArgumentList @($ScriptPath, "--port", "62230", "--no-open") `
  -WorkingDirectory $ProjectRoot `
  -WindowStyle Hidden `
  -RedirectStandardOutput $StdOut `
  -RedirectStandardError $StdErr

$ConsoleUrl = "http://127.0.0.1:62230/?controlled=1"
$Ready = $false
$Deadline = (Get-Date).AddSeconds(20)
while ((Get-Date) -lt $Deadline) {
  try {
    Invoke-RestMethod -Uri "http://127.0.0.1:62230/api/status" -TimeoutSec 1 | Out-Null
    $Ready = $true
    break
  } catch {
    Start-Sleep -Milliseconds 400
  }
}

if (-not $Ready) {
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show("控制台后台服务没有启动成功。请查看 logs 目录里的最新 .err.log。", "2.0 可视化控制台启动失败") | Out-Null
  exit 1
}

$BrowserResult = & $NodeExe (Join-Path $ProjectRoot "src\v2\tools\open-controlled-cms-browser-cli.js") --url $ConsoleUrl --console 2>&1
$BrowserExitCode = $LASTEXITCODE
if ($BrowserExitCode -ne 0) {
  Add-Content -LiteralPath $StdErr -Value ($BrowserResult -join "`n")
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(($BrowserResult -join "`n"), "2.0 可控浏览器启动失败") | Out-Null
  exit 1
}

import fs from "node:fs";
import fsp from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const DEFAULT_PORT = 62230;

async function main(argv = process.argv.slice(2)) {
  const projectRoot = path.resolve(parseArg(argv, "--project-root") || process.cwd());
  const port = Number(parseArg(argv, "--port") || DEFAULT_PORT);
  const openBrowser = !argv.includes("--no-open");
  const nodeExe = process.execPath;
  const logsDir = path.join(projectRoot, "logs");
  await fsp.mkdir(logsDir, { recursive: true });
  const stamp = timestamp();
  const outPath = path.join(logsDir, `v2-console-daemon-${stamp}.out.log`);
  const errPath = path.join(logsDir, `v2-console-daemon-${stamp}.err.log`);
  const consoleUrl = `http://127.0.0.1:${port}/?controlled=1`;
  const serviceUrl = `http://127.0.0.1:${port}/`;

  if (!await isConsoleReady(serviceUrl)) {
    const out = fs.openSync(outPath, "a");
    const err = fs.openSync(errPath, "a");
    const child = spawn(nodeExe, [
      path.join(projectRoot, "src", "v2", "tools", "run-console-cli.js"),
      "--port",
      String(port),
      "--no-open"
    ], {
      cwd: projectRoot,
      detached: true,
      stdio: ["ignore", out, err],
      windowsHide: true,
      env: {
        ...process.env,
        PLAYWRIGHT_BROWSERS_PATH: path.join(projectRoot, "ms-playwright")
      }
    });
    child.unref();
    fs.closeSync(out);
    fs.closeSync(err);
    await waitForConsoleReady(serviceUrl, 20000, errPath);
  }

  if (openBrowser) await runBrowserOpener(projectRoot, nodeExe, consoleUrl, errPath);
  console.log("2.0 可视化控制台已打开。");
}

function parseArg(argv, name) {
  const index = argv.indexOf(name);
  return index >= 0 ? argv[index + 1] : "";
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

async function waitForConsoleReady(url, timeoutMs, errPath) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (await isConsoleReady(url)) return;
    await new Promise((resolve) => setTimeout(resolve, 350));
  }
  throw new Error(`控制台后台服务没有启动成功。请查看日志：${errPath}`);
}

function isConsoleReady(url) {
  return new Promise((resolve) => {
    const req = http.get(new URL("api/status", url), { timeout: 800 }, (res) => {
      let body = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { body += chunk; });
      res.on("end", () => {
        try {
          const parsed = JSON.parse(body || "{}");
          resolve(parsed?.ok === true);
        } catch {
          resolve(false);
        }
      });
    });
    req.on("timeout", () => {
      req.destroy();
      resolve(false);
    });
    req.on("error", () => resolve(false));
  });
}

function runBrowserOpener(projectRoot, nodeExe, consoleUrl, errPath) {
  return new Promise((resolve, reject) => {
    let stderr = "";
    const child = spawn(nodeExe, [
      path.join(projectRoot, "src", "v2", "tools", "open-controlled-cms-browser-cli.js"),
      "--url",
      consoleUrl,
      "--console"
    ], {
      cwd: projectRoot,
      windowsHide: false,
      env: {
        ...process.env,
        PLAYWRIGHT_BROWSERS_PATH: path.join(projectRoot, "ms-playwright")
      }
    });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.stdout.on("data", () => {});
    child.on("error", reject);
    child.on("close", async (code) => {
      if (code === 0) {
        resolve();
        return;
      }
      const message = stderr.trim() || `浏览器启动失败，错误码：${code}`;
      await fsp.appendFile(errPath, `\n${message}\n`, "utf8").catch(() => {});
      reject(new Error(message));
    });
  });
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main().catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

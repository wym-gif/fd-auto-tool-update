import http from "node:http";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import path from "node:path";
import { applyPreviewDefaultDate, finalPreviewCheck, finalPreviewPath, loadPreviewForOpen, saveFinalPreview } from "./preview-store.js";

export async function createPreviewTestServer(runDir, options = {}) {
  const server = http.createServer((req, res) => {
    handleRequest(req, res, runDir, options).catch((error) => sendJson(res, 500, {
      ok: false,
      error: error?.message || String(error)
    }));
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port || 0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });
  const address = server.address();
  const url = `http://127.0.0.1:${address.port}/`;
  return {
    server,
    url,
    close: () => new Promise((resolve) => server.close(resolve))
  };
}

async function handleRequest(req, res, runDir, options = {}) {
  const url = new URL(req.url || "/", "http://127.0.0.1");
  if (req.method === "GET" && url.pathname === "/") {
    const meta = await loadPreviewPageMeta(runDir);
    const defaultDate = options.defaultDate || meta.defaultDate || "";
    const state = await loadPreviewForOpen(runDir, {
      regenerate: url.searchParams.get("regenerate") === "1",
      defaultDate
    });
    sendHtml(res, renderPreviewPage(state, runDir, {
      ...meta,
      consoleUrl: options.consoleUrl || "",
      defaultDate
    }));
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/preview") {
    sendJson(res, 200, { ok: true, ...(await loadPreviewForOpen(runDir)) });
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/media-preview") {
    await sendMediaPreview(req, res, url.searchParams.get("path") || "");
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/media-status") {
    sendJson(res, 200, await mediaStatus(url.searchParams.get("path") || ""));
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/upload-media") {
    const uploaded = await saveUploadedMedia(req, runDir);
    sendJson(res, 200, { ok: true, ...uploaded });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/preview") {
    const body = await readJsonBody(req);
    const saved = await saveFinalPreview(runDir, body.tasks, { requireComplete: true });
    await options.onPreviewSaved?.({ runDir, path: saved.path, tasks: saved.tasks });
    sendJson(res, 200, { ok: true, source: "preview.json", path: saved.path, tasks: saved.tasks, savedAt: new Date().toISOString() });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/regenerate") {
    if (options.onRegeneratePreview) {
      const result = await options.onRegeneratePreview({ runDir });
      sendJson(res, 202, { ok: true, ...result });
      return;
    }
    const meta = await loadPreviewPageMeta(runDir);
    const state = await loadPreviewForOpen(runDir, {
      regenerate: true,
      defaultDate: options.defaultDate || meta.defaultDate || ""
    });
    sendJson(res, 200, { ok: true, ...state });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/final-check") {
    const body = await readJsonBody(req);
    sendJson(res, 200, await finalPreviewCheck(runDir, body.tasks));
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/prepare-cms") {
    const body = await readJsonBody(req);
    const check = await finalPreviewCheck(runDir, body.tasks);
    if (!check.ok) {
      sendJson(res, 400, check);
      return;
    }
    if (options.onPrepareCms) {
      const result = await options.onPrepareCms({ runDir, tasks: body.tasks, check });
      sendJson(res, 202, { ok: true, preparedCms: true, ...result });
      return;
    }
    sendJson(res, 200, check);
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/return-settings") {
    const result = await options.onReturnSettings?.({ runDir });
    sendJson(res, 200, { ok: true, consoleUrl: options.consoleUrl || "", ...(result || {}) });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/abandon") {
    const body = await readJsonBody(req);
    await savePreviewDraft(runDir, body.tasks || []);
    const result = await options.onAbandon?.({ runDir, tasks: body.tasks || [] });
    sendJson(res, 200, { ok: true, consoleUrl: options.consoleUrl || "", draftPath: path.join(runDir, "preview-draft.json"), ...(result || {}) });
    return;
  }
  sendJson(res, 404, { ok: false, error: "Not found" });
}

function renderPreviewPage(state, runDir, meta = {}) {
  const tasksJson = JSON.stringify(applyPreviewDefaultDate(state.tasks, meta.defaultDate)).replace(/</g, "\\u003c");
  const source = escapeHtml(state.source);
  const previewPathText = escapeHtml(finalPreviewPath(runDir));
  const runDirText = escapeHtml(runDir);
  const runId = path.basename(path.resolve(runDir));
  const rangeLabel = escapeHtml(meta.rangeLabel || "未记录");
  const rawEventCount = escapeHtml(meta.rawEventCount ?? "-");
  const previewTaskCount = escapeHtml(meta.previewTaskCount ?? state.tasks.length);
  const consoleUrl = JSON.stringify(meta.consoleUrl || "").replace(/</g, "\\u003c");
  const defaultDate = JSON.stringify(meta.defaultDate || "").replace(/</g, "\\u003c");
  const runDirJson = JSON.stringify(runDir).replace(/</g, "\\u003c");
  const runIdJson = JSON.stringify(runId).replace(/</g, "\\u003c");
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>妙券自动发单 - 预览确认</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, "Microsoft YaHei", sans-serif; background: #f3f6fa; color: #111827; }
    header { position: sticky; top: 0; z-index: 5; background: rgba(255,255,255,0.98); border-bottom: 1px solid #d8dde6; box-shadow: 0 1px 4px rgba(15, 23, 42, 0.04); }
    main { padding: 16px 18px 40px; }
    .topbar { min-height: 70px; padding: 14px 18px 12px; display: flex; align-items: flex-start; justify-content: space-between; gap: 18px; }
    .title { font-size: 20px; line-height: 1.2; font-weight: 700; }
    .subtitle { margin-top: 4px; color: #475569; font-size: 13px; }
    .pathline { margin-top: 4px; color: #64748b; font-size: 12px; max-width: 760px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .run-summary { margin-top: 8px; display: flex; gap: 10px; flex-wrap: wrap; color: #475569; font-size: 12px; }
    .summary-pill { border: 1px solid #d7e0ee; background: #f8fafc; border-radius: 999px; padding: 3px 9px; }
    .actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
    .batchbar { margin: 0 18px 12px; padding: 12px; border: 1px solid #d7e0ee; border-radius: 8px; background: #fff; display: grid; gap: 10px; }
    .tool-row { min-height: 36px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .status-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .view-note { font-size: 12px; color: #64748b; line-height: 1.45; }
    button { height: 36px; border: 1px solid #94a3b8; background: #fff; border-radius: 6px; padding: 0 14px; cursor: pointer; font: inherit; }
    button.primary { background: #2563eb; border-color: #2563eb; color: white; }
    button.danger { border-color: #dc2626; color: #b91c1c; }
    button.ghost { border-color: #2563eb; color: #1d4ed8; }
    button.active { background: #111827; border-color: #111827; color: white; }
    button.small-btn { height: 32px; padding: 0 10px; font-size: 13px; }
    table { width: 100%; border-collapse: collapse; table-layout: fixed; background: #fff; border: 1px solid #d8dde6; }
    th, td { border-bottom: 1px solid #e2e8f0; padding: 10px; vertical-align: top; font-size: 14px; }
    th { background: #eef3f9; text-align: left; font-weight: 700; position: sticky; top: 204px; z-index: 1; }
    input, select, textarea { width: 100%; border: 1px solid #cbd5e1; border-radius: 5px; padding: 7px 8px; font: inherit; background: #fff; }
    textarea { min-height: 72px; resize: vertical; line-height: 1.45; }
    .select-col { width: 58px; text-align: center; }
    .exec { width: 76px; }
    .role { width: 92px; }
    .speaker { width: 146px; }
    .date { width: 136px; }
    .time { width: 136px; }
    .type { width: 94px; }
    .skip { width: 72px; text-align: center; }
    .content { min-width: 520px; }
    .muted { color: #64748b; font-size: 12px; }
    .status { min-height: 18px; font-size: 13px; color: #166534; }
    .error { color: #b91c1c; }
    .index-cell strong { display: block; font-size: 16px; margin-bottom: 2px; }
    .subnote { margin-top: 5px; color: #64748b; font-size: 12px; line-height: 1.35; }
    .content-grid { display: grid; grid-template-columns: 1fr; gap: 8px; }
    .media-box { display: grid; grid-template-columns: 96px 1fr; gap: 10px; align-items: start; }
    .thumb { width: 96px; height: 76px; border: 1px solid #d1d5db; background: #f8fafc; display: flex; align-items: center; justify-content: center; overflow: hidden; color: #64748b; font-size: 12px; }
    .thumb img, .thumb video { max-width: 100%; max-height: 100%; display: block; }
    .hidden-file { display: none; }
    tr.skipped { background: #f3f4f6; color: #6b7280; }
    tr.invalid { outline: 2px solid #fecaca; outline-offset: -2px; }
    .row-note { margin-top: 4px; color: #b91c1c; font-size: 12px; line-height: 1.35; }
    .toolbar-label { color: #374151; font-size: 13px; }
    .toolbar-input { width: 132px; }
    .toolbar-date-custom { width: 132px; }
    .toolbar-number { width: 80px; }
    .preview-path { margin-top: 5px; color: #64748b; font-size: 12px; overflow-wrap: anywhere; line-height: 1.35; }
    .tag { display: inline-block; border-radius: 999px; background: #dbeafe; color: #1d4ed8; padding: 2px 8px; font-size: 12px; margin-right: 8px; }
    .media-status { margin-top: 5px; color: #64748b; font-size: 12px; }
    .media-status.bad { color: #b91c1c; font-weight: 600; }
    .manual-badge { display: inline-block; margin-top: 4px; color: #92400e; background: #fef3c7; border: 1px solid #fde68a; border-radius: 999px; padding: 1px 7px; font-size: 12px; }
    .modal-backdrop { position: fixed; inset: 0; z-index: 20; display: none; align-items: center; justify-content: center; padding: 22px; background: rgba(15, 23, 42, 0.42); }
    .modal-backdrop.open { display: flex; }
    .modal { width: min(720px, 100%); max-height: calc(100vh - 44px); overflow: auto; background: #fff; border-radius: 8px; box-shadow: 0 24px 60px rgba(15, 23, 42, 0.24); border: 1px solid #d8dde6; }
    .modal-header { padding: 16px 18px 12px; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .modal-title { font-size: 18px; font-weight: 700; }
    .modal-body { padding: 16px 18px; display: grid; gap: 14px; }
    .modal-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
    .modal-field { display: grid; gap: 6px; }
    .modal-field label { font-size: 13px; color: #374151; }
    .modal-field.full { grid-column: 1 / -1; }
    .modal-actions { padding: 12px 18px 16px; display: flex; justify-content: flex-end; gap: 8px; border-top: 1px solid #e2e8f0; }
    .modal-error { color: #b91c1c; font-size: 13px; min-height: 18px; line-height: 1.4; }
    .manual-media-preview { display: grid; grid-template-columns: 112px 1fr; align-items: start; gap: 10px; }
    @media (max-width: 720px) {
      .modal-grid, .manual-media-preview { grid-template-columns: 1fr; }
    }
    details.debug { margin-top: 8px; color: #64748b; font-size: 12px; }
    details.debug summary { cursor: pointer; user-select: none; }
    .debug-grid { margin-top: 8px; display: grid; grid-template-columns: repeat(5, minmax(130px, 1fr)); gap: 8px; }
    .debug-grid label { display: block; color: #475569; }
    .debug-grid input, .debug-grid textarea { margin-top: 4px; font-size: 12px; }
  </style>
</head>
<body>
  <header>
    <div class="topbar">
      <div>
        <div class="title">妙券自动发单 - 预览确认</div>
        <div class="subtitle">本次共 <strong id="totalCount">0</strong> 条，已选中 <strong id="selectedCount">0</strong> 条，已标记不发 <strong id="skipCount">0</strong> 条</div>
        <div class="run-summary">
          <span class="summary-pill">本次读取范围：${rangeLabel}</span>
          <span class="summary-pill">原始采集：${rawEventCount} 条</span>
          <span class="summary-pill">预览条目：${previewTaskCount} 条</span>
        </div>
        <div class="pathline">preview.json：${previewPathText}</div>
        <div class="pathline">当前目录：${runDirText}</div>
      </div>
      <div class="actions">
        <button class="ghost" id="addRowBtn">手动补一条</button>
        <button class="ghost" id="regenerateBtn" title="正式控制台打开时会按当前配置重新采集/解析/生成；单模块测试入口才只重载当前目录 preview-tasks.json。">重新生成预览</button>
        <button class="primary" id="confirmBtn">确认无误，进入云中客设置</button>
      </div>
    </div>
    <div class="batchbar">
      <div class="tool-row">
        <span class="toolbar-label">批量修改：已选 <strong id="batchSelectedCount">0</strong> 条</span>
        <button id="selectAllBtn" class="small-btn">全选</button>
        <button id="selectNoneBtn" class="small-btn">全不选</button>
        <span class="toolbar-label">批量日期：</span>
        <select id="batchDateQuick" class="toolbar-input"></select>
        <input id="batchDateCustom" class="toolbar-date-custom" placeholder="自定义日期" hidden>
        <button id="applyDateBtn" class="small-btn">应用日期</button>
        <span class="toolbar-label">时间：</span>
        <button id="delayBtn" class="small-btn">整体延后</button>
        <button id="advanceBtn" class="small-btn">整体提前</button>
        <input id="batchMinutes" class="toolbar-number" type="number" value="5">
        <span class="toolbar-label">分钟</span>
        <button id="applyTimeBtn" class="small-btn">应用时间</button>
        <button id="restoreTimeBtn" class="small-btn">恢复选中行时间</button>
      </div>
      <div class="tool-row">
        <span class="toolbar-label">角色：</span>
        <select id="batchRole" class="toolbar-input"><option value="">角色</option><option value="tuo">托</option><option value="douma">豆妈</option></select>
        <button id="applyRoleBtn" class="small-btn">批量改角色</button>
        <button id="skipSelectedBtn" class="small-btn">设为不发</button>
        <button id="unskipSelectedBtn" class="small-btn">取消不发</button>
        <span class="toolbar-label">查看方式：</span>
        <button class="active" id="executionViewBtn">按执行顺序</button>
        <button id="timeViewBtn">按时间顺序</button>
      </div>
      <div class="status-row">
        <div id="viewNote" class="view-note">
          <div>按执行顺序：同编号托会放在一起，时间不变。</div>
          <div>按时间顺序：仅用于检查，不改变正式执行顺序。</div>
        </div>
        <div id="status" class="status"></div>
      </div>
    </div>
    <span id="source" hidden>${source}</span>
  </header>
  <main>
    <table>
      <thead>
        <tr>
          <th class="select-col">批量</th>
          <th class="exec">序号</th>
          <th class="role">角色</th>
          <th class="speaker">说话人</th>
          <th class="date">日期</th>
          <th class="time">时间</th>
          <th class="type">类型</th>
          <th class="content">内容/素材</th>
          <th class="skip">不发</th>
        </tr>
      </thead>
      <tbody id="rows"></tbody>
    </table>
  </main>
  <div class="modal-backdrop" id="manualModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="manualModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="manualModalTitle">手动补一条</div>
        <button class="small-btn" id="manualCancelTopBtn" type="button">取消</button>
      </div>
      <div class="modal-body">
        <div class="modal-grid">
          <div class="modal-field">
            <label for="manualRole">角色</label>
            <select id="manualRole"><option value="tuo">托</option><option value="douma">豆妈</option></select>
          </div>
          <div class="modal-field">
            <label for="manualSpeaker">说话人</label>
            <input id="manualSpeaker">
          </div>
          <div class="modal-field">
            <label for="manualDate">日期</label>
            <input id="manualDate">
          </div>
          <div class="modal-field">
            <label for="manualTime">时间</label>
            <input id="manualTime" placeholder="例如 19:16:10">
          </div>
          <div class="modal-field">
            <label for="manualType">类型</label>
            <select id="manualType"><option value="text">文字</option><option value="image">图片</option><option value="sticker">表情包</option><option value="video">视频</option></select>
          </div>
          <div class="modal-field">
            <label for="manualInsertPosition">插入位置</label>
            <select id="manualInsertPosition"><option value="after-selection">当前选中行后</option><option value="before-selection">当前选中行前</option><option value="end">末尾</option></select>
          </div>
          <div class="modal-field">
            <label><input id="manualSkip" type="checkbox"> 是否不发</label>
          </div>
          <div class="modal-field full" id="manualTextWrap">
            <label for="manualText">正文</label>
            <textarea id="manualText"></textarea>
          </div>
          <div class="modal-field full" id="manualMediaWrap" hidden>
            <label for="manualMediaPath">素材选择/上传</label>
            <div class="manual-media-preview">
              <div class="thumb" id="manualMediaThumb">无素材</div>
              <div>
                <input id="manualMediaPath" placeholder="可填写本地素材路径">
                <div class="preview-path" id="manualMediaShortPath">未选择素材</div>
                <div class="media-status" id="manualMediaStatus">未选择素材</div>
                <input class="hidden-file" id="manualMediaFile" type="file">
                <button class="small-btn ghost" id="manualChooseMediaBtn" type="button">选择素材</button>
              </div>
            </div>
          </div>
        </div>
        <div id="manualModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="manualCancelBtn" type="button">取消</button>
        <button class="primary" id="manualAddBtn" type="button">添加</button>
      </div>
    </div>
  </div>
  <script>
    const defaultDate = ${defaultDate};
    const runDirForPage = ${runDirJson};
    const runIdForPage = ${runIdJson};
    clearLegacyPreviewStorage();
    let tasks = normalizeTasksForCurrentRun(${tasksJson});
    let viewMode = "execution";
    let pendingTimeDirection = 1;
    let selectedRows = new Set();
    let dirty = false;
    let autoSaveTimer = null;
    let saveFailed = false;
    let savedAt = "";
    const consoleUrl = ${consoleUrl};
    window.__v2PreviewPage = true;
    window.__v2PreviewRunDir = runDirForPage;
    window.__v2PreviewRunId = runIdForPage;
    window.__v2PreviewDefaultDate = defaultDate;
    window.__v2PreviewDirty = false;
    const originalTimes = tasks.map((task) => ({ date: task.documentDate || task.date || "", time: task.documentTime || task.time || "" }));
    const fields = ["role", "speaker", "date", "time", "type", "text", "mediaPath", "skip", "order", "interactionGroup", "continueMarker", "cleanSpeaker", "sourceId", "sourceText", "documentDate", "documentTime", "daySegment"];
    initBatchDateControls();
    render();

    document.getElementById("executionViewBtn").addEventListener("click", () => {
      collect();
      viewMode = "execution";
      render();
      setStatus("当前按执行顺序显示；同编号托会放在一起，时间不变。");
    });
    document.getElementById("timeViewBtn").addEventListener("click", () => {
      collect();
      viewMode = "time";
      render();
      setStatus("当前仅按时间顺序查看，不改变实际执行顺序。");
    });
    document.getElementById("addRowBtn").addEventListener("click", () => {
      collect();
      openManualModal();
    });
    document.getElementById("manualCancelTopBtn").addEventListener("click", () => closeManualModal());
    document.getElementById("manualCancelBtn").addEventListener("click", () => closeManualModal());
    document.getElementById("manualType").addEventListener("change", () => updateManualTypeFields());
    document.getElementById("manualMediaPath").addEventListener("input", () => updateManualMediaPreview());
    document.getElementById("manualMediaFile").addEventListener("change", () => updateManualMediaPreview());
    document.getElementById("manualChooseMediaBtn").addEventListener("click", () => document.getElementById("manualMediaFile").click());
    document.getElementById("manualAddBtn").addEventListener("click", () => addManualTaskFromModal());
    document.getElementById("selectAllBtn").addEventListener("click", () => {
      collect();
      selectedRows = new Set(sortedRowsForView().map((row) => row.originalIndex));
      render();
    });
    document.getElementById("selectNoneBtn").addEventListener("click", () => {
      collect();
      selectedRows = new Set();
      render();
    });
    document.getElementById("applyDateBtn").addEventListener("click", () => applyBatchDate());
    document.getElementById("batchDateQuick").addEventListener("change", () => updateBatchDateCustomVisibility());
    document.getElementById("delayBtn").addEventListener("click", () => {
      pendingTimeDirection = 1;
      updateTimeDirectionButtons();
      setStatus("已选择整体延后：先勾选要修改的行，填写分钟数后应用");
    });
    document.getElementById("advanceBtn").addEventListener("click", () => {
      pendingTimeDirection = -1;
      updateTimeDirectionButtons();
      setStatus("已选择整体提前：先勾选要修改的行，填写分钟数后应用");
    });
    document.getElementById("applyTimeBtn").addEventListener("click", () => shiftSelectedTimes(pendingTimeDirection));
    document.getElementById("applyRoleBtn").addEventListener("click", () => applyBatchRole());
    document.getElementById("skipSelectedBtn").addEventListener("click", () => setSelectedSkip(true));
    document.getElementById("unskipSelectedBtn").addEventListener("click", () => setSelectedSkip(false));
    document.getElementById("restoreTimeBtn").addEventListener("click", () => restoreSelectedTimes());
    document.getElementById("confirmBtn").addEventListener("click", async () => {
      const saved = await savePreview();
      if (!saved.ok) return;
      const result = await postJson("/api/prepare-cms", { tasks });
      if (result.ok) {
        setStatus(result.preparedCms
          ? "已进入 CMS 准备阶段：请在云中客页面手动确认分组、机器人和发送策略，然后回到控制台继续。"
          : "已保存并核对通过：请准备云中客页面后再开始创建。");
        if (!result.preparedCms && (result.consoleUrl || consoleUrl)) setTimeout(() => openConsole(result), 400);
      } else {
        setStatus(result.error || "进入 CMS 准备阶段失败", true);
      }
    });
    document.getElementById("regenerateBtn").addEventListener("click", async () => {
      const message = dirty
        ? "当前预览有未保存修改。确认重新生成预览？这会按控制台当前配置重新采集/解析，并覆盖当前未保存修改。"
        : "确认重新生成预览？这会返回控制台当前配置，重新采集/解析/生成最新预览。";
      if (!confirm(message)) return;
      const result = await postJson("/api/regenerate", {});
      if (result.ok) {
        if (Array.isArray(result.tasks)) {
          clearLegacyPreviewStorage();
          tasks = normalizeTasksForCurrentRun(result.tasks);
          selectedRows = new Set();
          document.getElementById("source").textContent = result.source || "";
          dirty = false;
          window.__v2PreviewDirty = false;
          viewMode = "execution";
          render();
          setStatus("已重新生成 preview.json");
          return;
        }
        setStatus("已提交重新生成预览请求，正在回到控制台");
        openConsole(result);
        return;
      }
      setStatus(result.error || "重新生成预览失败", true);
    });

    function render() {
      const rows = document.getElementById("rows");
      rows.innerHTML = "";
      const displayRows = sortedRowsForView();
      for (const { task, originalIndex } of displayRows) {
        const tr = document.createElement("tr");
        tr.dataset.index = String(originalIndex);
        tr.className = task.skip ? "skipped" : "";
        tr.innerHTML = [
          cell(rowCheckbox(originalIndex)),
          execCell(originalIndex, task),
          cell(select("role", task.role, [["tuo", "托"], ["douma", "豆妈"]])),
          cell(input("speaker", task.speaker)),
          dateCell(originalIndex, task),
          timeCell(originalIndex, task),
          cell(select("type", task.type, [["text", "文字"], ["image", "图片"], ["sticker", "表情包"], ["video", "视频"]])),
          contentCell(task),
          skipCell(task)
        ].join("");
        rows.appendChild(tr);
      }
      updateViewControls();
      refreshMediaStatuses();
    }

    function normalizeTasksForCurrentRun(items) {
      const fallback = normalizePreviewDate(defaultDate || "");
      return (Array.isArray(items) ? items : []).map((task) => {
        const next = { ...task };
        next.date = normalizePreviewDate(String(next.date || "").trim() || fallback);
        return next;
      });
    }

    function clearLegacyPreviewStorage() {
      try {
        const keys = [];
        for (let index = 0; index < localStorage.length; index += 1) {
          const key = localStorage.key(index) || "";
          if (/^(v2-preview|preview-page|preview-state)/i.test(key)) keys.push(key);
        }
        for (const key of keys) localStorage.removeItem(key);
      } catch {}
    }

    document.addEventListener("input", (event) => {
      const row = event.target.closest && event.target.closest("tr[data-index]");
      if (!row || !event.target.dataset.field) return;
      updateTaskFromRow(row);
      clearRowError(row);
      markDirty();
    });
    document.addEventListener("change", async (event) => {
      const row = event.target.closest && event.target.closest("tr[data-index]");
      if (!row) return;
      if (event.target.dataset.selectRow === "1") {
        const index = Number(row.dataset.index);
        if (event.target.checked) selectedRows.add(index);
        else selectedRows.delete(index);
        updateViewControls();
        return;
      }
      if (event.target.dataset.uploadFor === "mediaPath") {
        await uploadReplacement(row, event.target.files && event.target.files[0]);
        return;
      }
      if (event.target.dataset.field) {
        updateTaskFromRow(row);
        markDirty();
        if (event.target.dataset.field === "type" || event.target.dataset.field === "skip") render();
      }
    });
    document.addEventListener("click", (event) => {
      const button = event.target.closest && event.target.closest("button[data-action]");
      if (!button) return;
      const row = button.closest("tr[data-index]");
      if (!row) return;
      if (button.dataset.action === "choose-media") {
        const fileInput = row.querySelector("input[type='file'][data-upload-for='mediaPath']");
        if (fileInput) fileInput.click();
      }
      if (button.dataset.action === "mark-skip") {
        updateTaskFromRow(row);
        tasks[Number(row.dataset.index)].skip = true;
        render();
        markDirty("已设为不发，正在自动保存 preview.json");
      }
    });

    function collect() {
      const nextTasks = tasks.map((task) => ({ ...task }));
      for (const row of Array.from(document.querySelectorAll("tbody tr"))) {
        const originalIndex = Number(row.dataset.index);
        if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= nextTasks.length) continue;
        nextTasks[originalIndex] = readTaskFromRow(row, nextTasks[originalIndex]);
      }
      tasks = nextTasks;
    }

    function readTaskFromRow(row, baseTask) {
      const task = { ...baseTask };
      for (const field of fields) {
        const el = row.querySelector("[data-field='" + field + "']");
        if (!el) continue;
        if (field === "skip") task[field] = el.checked;
        else if (field === "continueMarker") task[field] = el.checked;
        else if (field === "order") task[field] = Number(el.value);
        else task[field] = el.value;
      }
      return task;
    }

    function updateTaskFromRow(row) {
      const originalIndex = Number(row.dataset.index);
      if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= tasks.length) return;
      tasks[originalIndex] = readTaskFromRow(row, tasks[originalIndex]);
    }

    function sortedRowsForView() {
      const rows = tasks.map((task, originalIndex) => ({ task, originalIndex }));
      if (viewMode !== "time") return rows;
      return [...rows].sort((a, b) => {
        const left = timeSortKey(a.task);
        const right = timeSortKey(b.task);
        if (left !== right) return left - right;
        return a.originalIndex - b.originalIndex;
      });
    }

    function selectedIndexes() {
      return Array.from(selectedRows).filter((index) => index >= 0 && index < tasks.length);
    }

    function applyBatchDate() {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改日期的行，或点全选", true);
      const value = selectedBatchDate();
      if (!value) return setStatus("请先选择或填写批量日期", true);
      if (!validDate(value)) return setStatus("批量日期格式不合法", true);
      for (const index of indexes) tasks[index].date = value;
      render();
      markDirty("已批量修改日期，正在自动保存 preview.json");
    }

    function shiftSelectedTimes(direction) {
      collect();
      const minutes = Math.abs(Number(document.getElementById("batchMinutes").value || 0));
      if (!minutes) return setStatus("请填写时间偏移分钟", true);
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改时间的行，或点全选，再应用", true);
      for (const index of indexes) {
        tasks[index].time = shiftClock(tasks[index].time, direction * minutes);
      }
      render();
      markDirty(direction > 0 ? "已批量延后时间，正在自动保存 preview.json" : "已批量提前时间，正在自动保存 preview.json");
    }

    function applyBatchRole() {
      collect();
      const role = document.getElementById("batchRole").value;
      if (!role) return setStatus("请先选择批量角色", true);
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改角色的行，或点全选", true);
      for (const index of indexes) tasks[index].role = role;
      render();
      markDirty("已批量修改角色，正在自动保存 preview.json");
    }

    function setSelectedSkip(skip) {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要设为不发的行，或点全选", true);
      for (const index of indexes) tasks[index].skip = skip;
      render();
      markDirty(skip ? "已将选中行设为不发，正在自动保存 preview.json" : "已取消选中行不发，正在自动保存 preview.json");
    }

    function restoreSelectedTimes() {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要恢复时间的行，或点全选", true);
      for (const index of indexes) {
        if (!originalTimes[index]) continue;
        tasks[index].date = originalTimes[index].date;
        tasks[index].time = originalTimes[index].time;
      }
      render();
      markDirty("已恢复选中行原时间，正在自动保存 preview.json");
    }

    async function savePreview(options = {}) {
      if (!options.auto && autoSaveTimer) {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = null;
      }
      setStatus("正在保存...");
      collect();
      const errors = validateClient(tasks);
      if (errors.length) {
        if (!options.auto) markInvalidRows(errors);
        const prefix = options.auto ? "未自动保存：" : "";
        setStatus(prefix + errors.slice(0, 4).map((item) => item.message).join("；"), true);
        saveFailed = true;
        return { ok: false };
      }
      let result;
      try {
        result = await postJson("/api/preview", { tasks });
      } catch (error) {
        result = { ok: false, error: error?.message || String(error) };
      }
      if (result.ok) tasks = result.tasks;
      if (result.ok) {
        dirty = false;
        window.__v2PreviewDirty = false;
        saveFailed = false;
        savedAt = result.savedAt || new Date().toISOString();
      }
      setStatus(result.ok
        ? (options.auto ? "已自动保存 preview.json：" : "已保存 preview.json：") + formatTime(savedAt)
        : "保存失败，请重试：" + (result.error || "未知原因"),
        !result.ok);
      if (!result.ok) saveFailed = true;
      if (!options.auto || options.render) render();
      return result;
    }

    function openManualModal() {
      const selected = selectedIndexes();
      const anchorIndex = selected.length ? Math.max(...selected) : tasks.length - 1;
      const anchor = tasks[anchorIndex] || {};
      document.getElementById("manualRole").value = anchor.role || "tuo";
      document.getElementById("manualSpeaker").value = anchor.speaker || "";
      document.getElementById("manualDate").value = defaultDate || todayMonthDay();
      document.getElementById("manualTime").value = validTime(anchor.time) ? shiftClock(anchor.time, 1) : currentClock();
      document.getElementById("manualType").value = "text";
      document.getElementById("manualText").value = "";
      document.getElementById("manualMediaPath").value = "";
      document.getElementById("manualMediaFile").value = "";
      document.getElementById("manualSkip").checked = false;
      document.getElementById("manualInsertPosition").value = selected.length ? "after-selection" : "end";
      document.getElementById("manualModalError").textContent = "";
      updateManualTypeFields();
      updateManualMediaPreview();
      const modal = document.getElementById("manualModal");
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setTimeout(() => document.getElementById("manualSpeaker").focus(), 0);
    }

    function closeManualModal() {
      const modal = document.getElementById("manualModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      const file = document.getElementById("manualMediaFile");
      if (file) file.value = "";
    }

    function updateManualTypeFields() {
      const type = document.getElementById("manualType").value;
      document.getElementById("manualTextWrap").hidden = type !== "text";
      document.getElementById("manualMediaWrap").hidden = type === "text";
      document.getElementById("manualMediaFile").setAttribute("accept", acceptForType(type));
      document.getElementById("manualModalError").textContent = "";
      updateManualMediaPreview();
    }

    async function updateManualMediaPreview() {
      const type = document.getElementById("manualType").value;
      const thumb = document.getElementById("manualMediaThumb");
      const status = document.getElementById("manualMediaStatus");
      const short = document.getElementById("manualMediaShortPath");
      if (type === "text") return;
      const file = document.getElementById("manualMediaFile").files?.[0];
      const pathValue = document.getElementById("manualMediaPath").value.trim();
      if (file) {
        const objectUrl = URL.createObjectURL(file);
        thumb.innerHTML = type === "video"
          ? "<video src='" + escapeAttr(objectUrl) + "' muted></video>"
          : "<img src='" + escapeAttr(objectUrl) + "' alt='素材预览'>";
        short.textContent = file.name;
        status.textContent = "已选择本地文件，点击添加后保存到本轮素材缓存";
        status.className = "media-status";
        return;
      }
      short.textContent = shortPath(pathValue) || "未选择素材";
      const preview = mediaPreviewSrc(pathValue);
      if (preview) {
        thumb.innerHTML = type === "video"
          ? "<video src='" + escapeAttr(preview) + "' muted></video>"
          : "<img src='" + escapeAttr(preview) + "' alt='素材预览'>";
      } else {
        thumb.textContent = "无素材";
      }
      if (!pathValue) {
        status.textContent = "未选择素材";
        status.className = "media-status bad";
        return;
      }
      const result = await fetch("/api/media-status?path=" + encodeURIComponent(pathValue)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
      status.textContent = result.message || (result.ok ? "素材可用" : "素材不可用");
      status.className = result.ok ? "media-status" : "media-status bad";
    }

    async function addManualTaskFromModal() {
      const errorEl = document.getElementById("manualModalError");
      errorEl.textContent = "";
      const role = document.getElementById("manualRole").value;
      const speaker = document.getElementById("manualSpeaker").value.trim();
      const date = normalizePreviewDate(document.getElementById("manualDate").value);
      const time = document.getElementById("manualTime").value.trim();
      const type = document.getElementById("manualType").value;
      const skip = document.getElementById("manualSkip").checked;
      const text = document.getElementById("manualText").value;
      let mediaPath = document.getElementById("manualMediaPath").value.trim();
      const file = document.getElementById("manualMediaFile").files?.[0] || null;
      const errors = [];
      if (!role) errors.push("请选择角色");
      if (!speaker) errors.push("请填写说话人");
      if (!date) errors.push("请填写日期");
      else if (!validDate(date)) errors.push("日期格式不合法");
      if (!time) errors.push("请填写时间");
      else if (!validTime(time)) errors.push("时间格式不合法");
      if (!type) errors.push("请选择类型");
      if (type === "text") {
        if (!String(text || "").trim()) errors.push("请填写正文");
      } else if (!file && !mediaPath) {
        errors.push("请选择或填写本地素材路径");
      } else if (mediaPath && !mediaPathMatchesType(mediaPath, type)) {
        errors.push("素材类型不匹配");
      }
      if (errors.length) {
        errorEl.textContent = errors.join("；");
        return;
      }
      if (type !== "text" && file) {
        const form = new FormData();
        form.append("file", file);
        form.append("type", type);
        form.append("sourceId", "manual-" + Date.now());
        const uploaded = await postForm("/api/upload-media", form);
        if (!uploaded.ok) {
          errorEl.textContent = uploaded.error || "素材上传失败";
          return;
        }
        mediaPath = uploaded.path;
      }
      if (type !== "text" && mediaPath) {
        const status = await fetch("/api/media-status?path=" + encodeURIComponent(mediaPath)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
        if (!status.ok) {
          errorEl.textContent = status.message || "素材不可用";
          return;
        }
      }
      collect();
      const insertAt = manualInsertIndex();
      const task = {
        sourceId: "manual-" + Date.now(),
        sourceText: "手动新增",
        role,
        speaker,
        date,
        time,
        type,
        text: type === "text" ? text : "",
        mediaPath: type === "text" ? "" : mediaPath,
        skip,
        order: 0,
        interactionGroup: "",
        continueMarker: false,
        cleanSpeaker: speaker.replace(/\\s+/g, "")
      };
      tasks.splice(insertAt, 0, task);
      originalTimes.splice(insertAt, 0, { date: "", time: "" });
      reindexTaskOrders();
      selectedRows = new Set([insertAt]);
      viewMode = "execution";
      closeManualModal();
      render();
      markDirty("已手动新增一条，正在自动保存 preview.json");
    }

    function manualInsertIndex() {
      const mode = document.getElementById("manualInsertPosition").value;
      const selected = selectedIndexes();
      if (mode === "before-selection" && selected.length) return Math.min(...selected);
      if (mode === "after-selection" && selected.length) return Math.max(...selected) + 1;
      return tasks.length;
    }

    function reindexTaskOrders() {
      tasks = tasks.map((task, index) => ({ ...task, order: index + 1 }));
    }

    function shiftClock(value, minutes) {
      const match = String(value || "").trim().match(/^(\\d{1,2})[:：](\\d{1,2})(?:[:：](\\d{1,2}))?$/);
      if (!match) return value;
      let total = Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0) + minutes * 60;
      total = ((total % 86400) + 86400) % 86400;
      const hour = Math.floor(total / 3600);
      const minute = Math.floor((total % 3600) / 60);
      const second = total % 60;
      return pad2(hour) + ":" + pad2(minute) + ":" + pad2(second);
    }

    async function uploadReplacement(row, file) {
      if (!file) return;
      updateTaskFromRow(row);
      const index = Number(row.dataset.index);
      const task = tasks[index];
      const form = new FormData();
      form.append("file", file);
      form.append("type", task.type || "");
      form.append("sourceId", task.sourceId || "");
      const result = await postForm("/api/upload-media", form);
      if (!result.ok) {
        setStatus(result.error || "素材上传失败", true);
        return;
      }
      task.mediaPath = result.path;
      row.querySelector("[data-field='mediaPath']").value = result.path;
      render();
      markDirty("素材已替换，正在自动保存 preview.json");
    }

    function validateClient(items) {
      const errors = [];
      for (const [index, task] of items.entries()) {
        if (task.skip) continue;
        const label = "第 " + (index + 1) + " 条";
        if (!task.role) errors.push({ index, message: label + " 缺少角色" });
        if (!String(task.date || "").trim()) errors.push({ index, message: label + " 缺少日期" });
        else if (!validDate(task.date)) errors.push({ index, message: label + " 日期格式不合法" });
        if (!String(task.time || "").trim()) errors.push({ index, message: label + " 缺少时间" });
        else if (!validTime(task.time)) errors.push({ index, message: label + " 时间格式不合法" });
        if (task.type === "text") {
          if (!String(task.text || "").trim()) errors.push({ index, message: label + " 文字正文为空" });
        } else if (!String(task.mediaPath || "").trim()) {
          errors.push({ index, message: label + " 素材路径为空" });
        } else if (/^(blob:|image-blob:)/i.test(String(task.mediaPath || "").trim())) {
          errors.push({ index, message: label + " 是临时素材地址，请重新生成预览或点更换素材换成本地文件" });
        } else if (!mediaPathMatchesType(task.mediaPath, task.type)) {
          errors.push({ index, message: label + " 素材类型不匹配" });
        }
      }
      return errors;
    }

    function markInvalidRows(errors) {
      document.querySelectorAll("tbody tr").forEach((row) => clearRowError(row));
      const byIndex = new Map();
      for (const error of errors) {
        if (!byIndex.has(error.index)) byIndex.set(error.index, []);
        byIndex.get(error.index).push(error.message);
      }
      for (const [index, messages] of byIndex.entries()) {
        const row = document.querySelector("tr[data-index='" + index + "']");
        if (!row) continue;
        row.classList.add("invalid");
        const note = document.createElement("div");
        note.className = "row-note";
        note.textContent = messages.join("；");
        row.querySelector("td:last-child").appendChild(note);
      }
    }

    function clearRowError(row) {
      row.classList.remove("invalid");
      row.querySelectorAll(".row-note").forEach((node) => node.remove());
    }

    function timeSortKey(task) {
      return dateSortKey(task.date) * 1000000 + clockSortKey(task.time);
    }

    function dateSortKey(date) {
      const match = String(date || "").match(/(\\d{1,2})\\s*[\\\/月]\\s*(\\d{1,2})/);
      if (!match) return 0;
      return Number(match[1]) * 100 + Number(match[2]);
    }

    function clockSortKey(time) {
      const match = String(time || "").match(/^(\\d{1,2}):(\\d{1,2})(?::(\\d{1,2}))?/);
      if (!match) return 999999;
      return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0);
    }

    function updateViewControls() {
      document.getElementById("executionViewBtn").classList.toggle("active", viewMode === "execution");
      document.getElementById("timeViewBtn").classList.toggle("active", viewMode === "time");
      const selectedCount = selectedIndexes().length;
      const skipCount = tasks.filter((task) => task.skip).length;
      document.getElementById("totalCount").textContent = String(tasks.length);
      document.getElementById("selectedCount").textContent = String(selectedCount);
      document.getElementById("batchSelectedCount").textContent = String(selectedCount);
      document.getElementById("skipCount").textContent = String(skipCount);
      updateTimeDirectionButtons();
    }

    function updateTimeDirectionButtons() {
      document.getElementById("delayBtn").classList.toggle("active", pendingTimeDirection === 1);
      document.getElementById("advanceBtn").classList.toggle("active", pendingTimeDirection === -1);
    }

    function initBatchDateControls() {
      const select = document.getElementById("batchDateQuick");
      if (!select) return;
      select.innerHTML = batchDateOptions().map((option) =>
        "<option value='" + escapeAttr(option.value) + "'>" + escapeHtmlJs(option.label) + "</option>"
      ).join("");
      select.value = todayMonthDay();
      updateBatchDateCustomVisibility();
    }

    function batchDateOptions() {
      return [
        { label: "今天 " + dateOffsetMonthDay(0), value: dateOffsetMonthDay(0) },
        { label: "明天 " + dateOffsetMonthDay(1), value: dateOffsetMonthDay(1) },
        { label: "后天 " + dateOffsetMonthDay(2), value: dateOffsetMonthDay(2) },
        { label: "大后天 " + dateOffsetMonthDay(3), value: dateOffsetMonthDay(3) },
        { label: "自定义日期", value: "custom" }
      ];
    }

    function updateBatchDateCustomVisibility() {
      const custom = document.getElementById("batchDateCustom");
      const select = document.getElementById("batchDateQuick");
      if (!custom || !select) return;
      custom.hidden = select.value !== "custom";
      if (!custom.hidden) custom.focus();
    }

    function selectedBatchDate() {
      const select = document.getElementById("batchDateQuick");
      if (!select) return "";
      if (select.value !== "custom") return normalizePreviewDate(select.value);
      return normalizePreviewDate(document.getElementById("batchDateCustom")?.value || "");
    }

    function input(field, value, type = "text", readonly = false) {
      return "<input data-field='" + field + "' type='" + type + "' value='" + escapeAttr(value ?? "") + "'" + (readonly ? " readonly" : "") + ">";
    }
    function textarea(field, value, readonly = false) {
      return "<textarea data-field='" + field + "'" + (readonly ? " readonly" : "") + ">" + escapeHtmlJs(value ?? "") + "</textarea>";
    }
    function checkbox(field, value) {
      return "<input data-field='" + field + "' type='checkbox'" + (value ? " checked" : "") + ">";
    }
    function select(field, value, options) {
      return "<select data-field='" + field + "'>" + options.map(([key, label]) => "<option value='" + key + "'" + (key === value ? " selected" : "") + ">" + label + "</option>").join("") + "</select>";
    }
    function fileInput(task) {
      return "<input class='hidden-file' data-upload-for='mediaPath' type='file' accept='" + acceptForType(task.type) + "'>";
    }
    function dateCell(originalIndex, task) {
      return cell(input("date", task.date) + "<div class='subnote'>原日期：" + escapeHtmlJs(originalTimes[originalIndex]?.date || "-") + "</div>");
    }
    function timeCell(originalIndex, task) {
      return cell(input("time", task.time) + "<div class='subnote'>原时间：" + escapeHtmlJs(originalTimes[originalIndex]?.time || "-") + "</div>");
    }
    function contentCell(task) {
      const details = debugDetails(task);
      if (task.type === "text") {
        return cell("<div class='content-grid'>" + textarea("text", task.text) + hiddenMediaField(task) + details + "</div>");
      }
      return cell("<div class='content-grid'>" + hiddenTextField(task) + mediaCell(task) + details + "</div>");
    }
    function mediaCell(task) {
      const path = task.mediaPath || "";
      const disabled = task.type === "text" ? " disabled" : "";
      return "<div class='media-box'>" +
        mediaThumb(task) +
        "<div>" +
          "<span class='tag'>" + typeLabel(task.type) + "</span>" +
          input("mediaPath", path) +
          "<div class='preview-path'>" + escapeHtmlJs(shortPath(path) || "未选择素材") + "</div>" +
          "<div class='media-status' data-media-status data-path='" + escapeAttr(path) + "'>正在检查素材状态...</div>" +
          fileInput(task) +
          "<button class='small-btn ghost' data-action='choose-media'" + disabled + ">更换素材</button>" +
        "</div>" +
      "</div>";
    }
    function mediaThumb(task) {
      const src = mediaPreviewSrc(task.mediaPath);
      if (!src || task.type === "text") return "<div class='thumb'>无素材</div>";
      if (task.type === "video") return "<div class='thumb'><video src='" + escapeAttr(src) + "' muted></video></div>";
      return "<div class='thumb'><img src='" + escapeAttr(src) + "' alt='素材预览'></div>";
    }
    function mediaPreviewSrc(value) {
      const text = String(value || "").trim();
      if (!text) return "";
      if (/^https?:\\/\\//i.test(text)) return "";
      if (/^data:/i.test(text)) return text;
      return "/api/media-preview?path=" + encodeURIComponent(text);
    }
    async function refreshMediaStatuses() {
      const nodes = Array.from(document.querySelectorAll("[data-media-status]"));
      await Promise.all(nodes.map(async (node) => {
        const value = node.dataset.path || "";
        if (!value) {
          node.textContent = "未选择素材";
          node.className = "media-status bad";
          return;
        }
        const result = await fetch("/api/media-status?path=" + encodeURIComponent(value)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
        node.textContent = result.message || (result.ok ? "素材可用" : "素材不可用");
        node.className = result.ok ? "media-status" : "media-status bad";
      }));
    }
    function cell(html) { return "<td>" + html + "</td>"; }
    function execCell(originalIndex, task) {
      const manual = isManualTask(task) ? "<span class='manual-badge'>手动新增</span>" : "";
      return "<td class='index-cell'><strong>" + (originalIndex + 1) + "</strong><div class='subnote'>执行顺序</div>" + manual + hiddenInput("order", task.order, "number") + "</td>";
    }
    function rowCheckbox(originalIndex) {
      return "<input type='checkbox' data-select-row='1'" + (selectedRows.has(originalIndex) ? " checked" : "") + ">";
    }
    function skipCell(task) {
      return cell(checkbox("skip", task.skip) + "<div class='subnote'>" + (task.skip ? "不发，创建时跳过" : "要发") + "</div>");
    }
    function debugDetails(task) {
      return "<details class='debug'><summary>高级/调试信息</summary><div class='debug-grid'>" +
        debugField("interactionGroup", input("interactionGroup", task.interactionGroup)) +
        debugField("continueMarker", checkbox("continueMarker", task.continueMarker)) +
        debugField("cleanSpeaker", input("cleanSpeaker", task.cleanSpeaker)) +
        debugField("sourceId", input("sourceId", task.sourceId, "text", true)) +
        debugField("sourceText", textarea("sourceText", task.sourceText, true)) +
      "</div></details>";
    }
    function debugField(label, control) {
      return "<label>" + label + control + "</label>";
    }
    function hiddenInput(field, value, type = "text") {
      return "<input data-field='" + field + "' type='" + type + "' value='" + escapeAttr(value ?? "") + "' hidden>";
    }
    function hiddenMediaField(task) {
      return "<input data-field='mediaPath' value='" + escapeAttr(task.mediaPath || "") + "' hidden>";
    }
    function hiddenTextField(task) {
      return "<textarea data-field='text' hidden>" + escapeHtmlJs(task.text || "") + "</textarea>";
    }
    function typeLabel(type) {
      if (type === "image") return "图片";
      if (type === "sticker") return "表情包";
      if (type === "video") return "视频";
      return "文字";
    }
    function isManualTask(task) {
      return /^manual-/i.test(String(task.sourceId || "")) || String(task.sourceText || "") === "手动新增";
    }
    function shortPath(value) {
      const text = String(value || "").trim();
      if (!text) return "";
      if (/^https?:\\/\\//i.test(text) || /^blob:/i.test(text)) return text;
      return text.split(/[\\\\\\/]/).slice(-3).join("\\\\");
    }
    function acceptForType(type) {
      if (type === "video") return ".mp4,.mov,.webm,video/*";
      if (type === "sticker") return ".gif,.webp,.png,.jpg,.jpeg,image/gif,image/webp,image/png,image/jpeg";
      return ".jpg,.jpeg,.png,.webp,.gif,image/*";
    }
    function validDate(value) {
      const text = String(value || "").trim();
      return /^\\d{1,2}\\s*[\\/月-]\\s*\\d{1,2}\\s*日?$/.test(text) || /^\\d{4}-\\d{1,2}-\\d{1,2}$/.test(text);
    }
    function normalizePreviewDate(value) {
      const text = String(value || "").trim();
      const ymd = text.match(/^\\d{4}-(\\d{1,2})-(\\d{1,2})$/);
      if (ymd) return Number(ymd[1]) + "/" + Number(ymd[2]);
      const md = text.match(/^(\\d{1,2})\\s*[\\/月-]\\s*(\\d{1,2})\\s*日?$/);
      if (md) return Number(md[1]) + "/" + Number(md[2]);
      return text;
    }
    function validTime(value) {
      const match = String(value || "").trim().match(/^(\\d{1,2})[:：](\\d{1,2})(?:[:：](\\d{1,2}))?$/);
      if (!match) return false;
      const h = Number(match[1]), m = Number(match[2]), s = Number(match[3] || 0);
      return h >= 0 && h <= 23 && m >= 0 && m <= 59 && s >= 0 && s <= 59;
    }
    function mediaPathMatchesType(value, type) {
      const text = String(value || "").toLowerCase();
      if (/^https?:\\/\\//.test(text) || /^sample:\\/\\//.test(text)) return true;
      if (type === "video") return /\\.(mp4|mov|webm)$/.test(text);
      if (type === "sticker") return /\\.(gif|webp|png|jpg|jpeg)$/.test(text);
      if (type === "image") return /\\.(jpg|jpeg|png|webp|gif)$/.test(text);
      return true;
    }
    function pad2(value) {
      return String(value).padStart(2, "0");
    }
    function escapeAttr(value) { return String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;"); }
    function escapeHtmlJs(value) { return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;"); }
    async function postJson(url, data) {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      return response.json();
    }
    async function postForm(url, data) {
      const response = await fetch(url, { method: "POST", body: data });
      return response.json();
    }
    function setStatus(message, error = false) {
      const el = document.getElementById("status");
      el.textContent = message || "";
      el.className = error ? "status error" : "status";
    }
    function markDirty(message = "有修改，正在自动保存 preview.json") {
      dirty = true;
      window.__v2PreviewDirty = true;
      saveFailed = false;
      setStatus(message);
      scheduleAutoSave();
    }
    function scheduleAutoSave() {
      if (autoSaveTimer) clearTimeout(autoSaveTimer);
      autoSaveTimer = setTimeout(async () => {
        autoSaveTimer = null;
        if (!dirty) return;
        await savePreview({ auto: true });
      }, 900);
    }
    function openConsole(resultOrUrl) {
      if (resultOrUrl && typeof resultOrUrl === "object" && resultOrUrl.focusedConsole) {
        return;
      }
      const target = typeof resultOrUrl === "string" ? resultOrUrl : (resultOrUrl?.consoleUrl || consoleUrl);
      if (!target) return setStatus("没有控制台地址，无法自动返回。请从 2.0 控制台重新打开预览页。", true);
      window.location.href = target;
    }
    function todayMonthDay() {
      return dateOffsetMonthDay(0);
    }
    function currentClock() {
      const now = new Date();
      return pad2(now.getHours()) + ":" + pad2(now.getMinutes()) + ":" + pad2(now.getSeconds());
    }
    function dateOffsetMonthDay(offsetDays) {
      const now = new Date();
      now.setDate(now.getDate() + Number(offsetDays || 0));
      return (now.getMonth() + 1) + "/" + now.getDate();
    }
    function formatTime(value) {
      if (!value) return "";
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return value;
      return pad2(date.getHours()) + ":" + pad2(date.getMinutes()) + ":" + pad2(date.getSeconds());
    }
  </script>
</body>
</html>`;
}

async function readJsonBody(req) {
  const raw = await readRawBody(req);
  const text = raw.toString("utf8");
  return text ? JSON.parse(text) : {};
}

async function loadPreviewPageMeta(runDir, state) {
  const report = await readJsonIfExists(path.join(runDir, "console-generate-report.json"));
  const diagnostics = await readJsonIfExists(path.join(runDir, "collect-diagnostics.json"));
  return {
    runId: path.basename(path.resolve(runDir)),
    defaultDate: report.readRange?.baseSendDate || "",
    rangeLabel: report.readRange?.label || (report.readRange?.mode === "full" ? "全文读取" : ""),
    rawEventCount: report.rawEventCount ?? diagnostics.collectedEventCount,
    previewTaskCount: report.previewTaskCount ?? state?.tasks?.length
  };
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function readRawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function savePreviewDraft(runDir, tasks) {
  const draftPath = path.join(runDir, "preview-draft.json");
  await fs.writeFile(draftPath, JSON.stringify(Array.isArray(tasks) ? tasks : [], null, 2), "utf8");
  return draftPath;
}

async function saveUploadedMedia(req, runDir) {
  const parsed = parseMultipartFormData(await readRawBody(req), req.headers["content-type"] || "");
  const file = parsed.files[0];
  if (!file?.body?.length) {
    throw new Error("没有收到素材文件。");
  }
  const type = String(parsed.fields.type || "").trim();
  const extension = normalizedMediaExtension(file.filename, type);
  if (!extension) {
    throw new Error(`素材类型不匹配：${type || "未知"} / ${file.filename || ""}`);
  }
  const cacheDir = path.join(runDir, "manual-media-cache");
  await fs.mkdir(cacheDir, { recursive: true });
  const base = sanitizeFilename(path.basename(file.filename || `media${extension}`, path.extname(file.filename || ""))) || "media";
  const hash = crypto.createHash("sha1").update(file.body).digest("hex").slice(0, 10);
  const localPath = path.join(cacheDir, `${Date.now()}-${hash}-${base}${extension}`);
  await fs.writeFile(localPath, file.body);
  return {
    path: localPath,
    previewUrl: `/api/media-preview?path=${encodeURIComponent(localPath)}`,
    size: file.body.length
  };
}

function parseMultipartFormData(buffer, contentType) {
  const boundaryMatch = String(contentType || "").match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!boundaryMatch) throw new Error("上传请求缺少 boundary。");
  const boundary = Buffer.from(`--${boundaryMatch[1] || boundaryMatch[2]}`);
  const fields = {};
  const files = [];
  let offset = buffer.indexOf(boundary);
  while (offset >= 0) {
    const next = buffer.indexOf(boundary, offset + boundary.length);
    if (next < 0) break;
    let part = buffer.subarray(offset + boundary.length, next);
    if (part.subarray(0, 2).toString() === "--") break;
    if (part.subarray(0, 2).toString() === "\r\n") part = part.subarray(2);
    if (part.subarray(-2).toString() === "\r\n") part = part.subarray(0, -2);
    const headerEnd = part.indexOf(Buffer.from("\r\n\r\n"));
    if (headerEnd > 0) {
      const headerText = part.subarray(0, headerEnd).toString("utf8");
      const body = part.subarray(headerEnd + 4);
      const disposition = headerText.match(/content-disposition:[^\n]+/i)?.[0] || "";
      const name = disposition.match(/name="([^"]+)"/i)?.[1] || "";
      const filename = disposition.match(/filename="([^"]*)"/i)?.[1] || "";
      if (filename) files.push({ name, filename, body });
      else if (name) fields[name] = body.toString("utf8");
    }
    offset = next;
  }
  return { fields, files };
}

async function sendMediaPreview(req, res, mediaPath) {
  const filePath = String(mediaPath || "").trim();
  if (!filePath || /^[a-z]+:\/\//i.test(filePath)) {
    sendJson(res, 400, { ok: false, error: "只能预览本地素材路径。" });
    return;
  }
  let stat;
  try {
    stat = await fs.stat(filePath);
  } catch {
    sendJson(res, 404, { ok: false, error: "素材不存在。" });
    return;
  }
  if (!stat.isFile()) {
    sendJson(res, 400, { ok: false, error: "素材路径不是文件。" });
    return;
  }
  res.writeHead(200, {
    "Content-Type": mediaContentType(filePath),
    "Content-Length": stat.size,
    "Cache-Control": "no-store"
  });
  createReadStream(filePath).pipe(res);
}

async function mediaStatus(mediaPath) {
  const filePath = String(mediaPath || "").trim();
  if (!filePath) return { ok: false, message: "未选择素材" };
  if (/^(blob:|image-blob:)/i.test(filePath)) return { ok: false, message: "浏览器临时素材地址，需重新生成预览或更换成本地文件" };
  if (/^data:/i.test(filePath)) return { ok: true, message: "内嵌素材可用" };
  if (/^https?:\/\//i.test(filePath)) {
    return { ok: false, message: "远程地址未落地，保存时会尝试下载到本地 media-cache" };
  }
  if (/^sample:\/\//i.test(filePath)) {
    return { ok: true, message: "测试素材可用" };
  }
  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile() || stat.size <= 0) return { ok: false, message: "素材文件无效" };
    return { ok: true, message: `本地素材可用（${Math.ceil(stat.size / 1024)}KB）` };
  } catch {
    return { ok: false, message: "素材不存在" };
  }
}

function normalizedMediaExtension(filename, type) {
  const ext = path.extname(String(filename || "")).toLowerCase();
  if (type === "video") return [".mp4", ".mov", ".webm"].includes(ext) ? ext : "";
  if (type === "sticker") return [".gif", ".webp", ".png", ".jpg", ".jpeg"].includes(ext) ? ext : "";
  if (type === "image") return [".jpg", ".jpeg", ".png", ".webp", ".gif"].includes(ext) ? ext : "";
  return [".jpg", ".jpeg", ".png", ".webp", ".gif", ".mp4", ".mov", ".webm"].includes(ext) ? ext : "";
}

function mediaContentType(filename) {
  const ext = path.extname(String(filename || "")).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  if (ext === ".gif") return "image/gif";
  if (ext === ".mp4") return "video/mp4";
  if (ext === ".mov") return "video/quicktime";
  if (ext === ".webm") return "video/webm";
  return "application/octet-stream";
}

function sanitizeFilename(value) {
  return String(value || "").replace(/[^\w.-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}

function sendHtml(res, html) {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(html);
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload, null, 2));
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

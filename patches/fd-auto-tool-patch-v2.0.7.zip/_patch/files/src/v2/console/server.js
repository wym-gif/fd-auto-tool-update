import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";
import {
  deleteIntervalPreset,
  loadConsoleSettings,
  loadIntervalPresets,
  saveConsoleSettings,
  saveIntervalPreset
} from "./settings.js";
import { createConsoleState } from "./state.js";
import { createConsoleWorkflow } from "./workflow.js";
import {
  assertCompanyAccessAllowed,
  getLicenseDiagnostics,
  getLicenseStatus,
  submitLicenseRequest
} from "../license/license-manager.js";
import {
  createStableBackup,
  getVersionStatus,
  openBackupDir,
  rollbackToPreviousStableVersion,
  updateToLatestVersion
} from "../version/version-manager.js";
import {
  ensureV2ControlledBrowser,
  loadV2ControlledBrowserState
} from "../browser/controlled-browser.js";

export async function createConsoleServer(projectRoot, options = {}) {
  const licenseOptions = pickLicenseOptions(options);
  const state = createConsoleState();
  const workflow = createConsoleWorkflow({ projectRoot, state, licenseOptions });
  const serviceInfo = await buildConsoleServiceInfo(projectRoot);
  let lastResult = null;
  let closing = false;

  const server = http.createServer((req, res) => {
    handleRequest(req, res).catch((error) => {
      sendJson(res, error?.statusCode || 500, {
        ok: false,
        error: error?.message || String(error),
        license: error?.license
      });
    });
  });

  async function handleRequest(req, res) {
    const url = new URL(req.url || "/", "http://127.0.0.1");
    if (req.method === "GET" && url.pathname === "/") {
      if (resetTerminalConsoleStateOnOpen(state)) lastResult = null;
      sendHtml(res, renderConsolePage());
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/settings") {
      sendJson(res, 200, { ok: true, settings: await loadConsoleSettings(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/settings") {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, settings: await saveConsoleSettings(projectRoot, body.settings || body) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/interval-presets") {
      sendJson(res, 200, { ok: true, presets: await loadIntervalPresets(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/interval-presets/save") {
      const body = await readJsonBody(req);
      const result = await saveIntervalPreset(projectRoot, body.preset || body);
      sendJson(res, 200, { ok: true, ...result });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/interval-presets/delete") {
      const body = await readJsonBody(req);
      const result = await deleteIntervalPreset(projectRoot, body.id);
      sendJson(res, 200, { ok: true, ...result });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/status") {
      sendJson(res, 200, { ok: true, state: state.snapshot(), lastResult });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/next-run") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      lastResult = null;
      sendJson(res, 200, { ok: true, state: state.resetForNextRun?.() || state.snapshot() });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/preview/restore-candidate") {
      sendJson(res, 200, { ok: true, candidate: await workflow.getRestorablePreview() });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview/restore") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const body = await readJsonBody(req);
      const settings = await saveConsoleSettings(projectRoot, body.settings || body);
      const result = await workflow.restoreLatestPreview(settings);
      sendJson(res, result.ok ? 200 : 404, result);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/service-info") {
      sendJson(res, 200, { ok: true, service: serviceInfo });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/license/status") {
      sendJson(res, 200, { ok: true, license: await getLicenseStatus(projectRoot, licenseOptions) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/license/diagnostics") {
      sendJson(res, 200, { ok: true, diagnostics: await getLicenseDiagnostics(projectRoot, licenseOptions) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/license/request") {
      sendJson(res, 200, { ok: true, request: await submitLicenseRequest(projectRoot, licenseOptions) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/version/status") {
      sendJson(res, 200, { ok: true, version: await getVersionStatus(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/backup") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能创建版本备份。" });
        return;
      }
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, result: await createStableBackup(projectRoot, backupOptions(body)) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/update") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能更新版本。" });
        return;
      }
      const body = await readJsonBody(req);
      const result = await updateToLatestVersion(projectRoot, versionActionOptions(body));
      state.log("版本管理：已更新到最新版本，正在重启控制台服务。");
      sendJson(res, 200, { ok: true, result, message: "已更新，控制台服务将重启。" });
      scheduleConsoleRestart(projectRoot, closeServer);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/rollback") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能回退版本。" });
        return;
      }
      const body = await readJsonBody(req);
      const result = await rollbackToPreviousStableVersion(projectRoot, versionActionOptions(body));
      state.log(`版本管理：已回退到 ${result.rolledBackTo}，正在重启控制台服务。`);
      sendJson(res, 200, { ok: true, result, message: `已回退到 ${result.rolledBackTo}，控制台服务将重启。` });
      scheduleConsoleRestart(projectRoot, closeServer);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/open-backup-dir") {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, result: await openBackupDir(projectRoot, backupOptions(body)) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/browser-state") {
      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const browserState = await loadV2ControlledBrowserState(projectRoot, config);
      sendJson(res, 200, {
        ok: true,
        controlled: Boolean(browserState.cdpUrl),
        cdpUrl: browserState.cdpUrl || "",
        profileDir: browserState.profileDir || ""
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/feishu-title") {
      const body = await readJsonBody(req);
      const result = await workflow.readFeishuTitle(body.feishuUrl);
      sendJson(res, result.statusCode || (result.ok ? 200 : 500), result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/heading-structure") {
      const body = await readJsonBody(req);
      const result = await workflow.readHeadingStructure(body.feishuUrl);
      sendJson(res, result.statusCode || (result.ok ? 200 : 500), result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/control") {
      const body = await readJsonBody(req);
      const action = String(body.action || "").trim();
      if (action === "pause") sendJson(res, 200, { ok: true, state: state.pause() });
      else if (action === "resume") sendJson(res, 200, { ok: true, state: state.resume() });
      else if (action === "stop") sendJson(res, 200, { ok: true, state: state.stop() });
      else sendJson(res, 400, { ok: false, error: "unknown control action" });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/generate-preview") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      if (!body.forceRegeneratePreview && await workflow.previewHasUnsavedChanges?.()) {
        sendJson(res, 409, {
          ok: false,
          code: "preview_dirty",
          error: "已有预览页有未保存修改。确认放弃这些修改并重新生成预览？"
        });
        return;
      }
      const previousSettings = await loadConsoleSettings(projectRoot);
      const settings = await saveConsoleSettings(projectRoot, body.settings || body);
      lastResult = null;
      state.log("页面请求：保存设置，生成预览");
      workflow.generatePreview({
        ...settings,
        previousFeishuUrl: previousSettings.feishuUrl || ""
      }).then((result) => {
        lastResult = result;
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("生成预览", lastResult.error);
      });
      sendJson(res, 202, { ok: true, state: state.snapshot() });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/prepare-cms") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "prepare-cms", licenseOptions);
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const settings = await saveConsoleSettings(projectRoot, body.settings || body);
      lastResult = null;
      state.log("页面请求：进入云中客设置");
      workflow.prepareCms({ ...settings, runDir: state.snapshot().runDir }).then((result) => {
        lastResult = result;
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("CMS 准备", lastResult.error);
      });
      sendJson(res, 202, { ok: true, state: state.snapshot() });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/start-cms") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "start-cms", licenseOptions);
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const savedSettings = await saveConsoleSettings(projectRoot, body.settings || body);
      const settings = body.temporarySettings && typeof body.temporarySettings === "object"
        ? { ...savedSettings, ...body.temporarySettings }
        : savedSettings;
      lastResult = null;
      state.log("页面请求：我已设置好，开始创建");
      workflow.startCms({ ...settings, runDir: state.snapshot().runDir }).then((result) => {
        lastResult = result;
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("正式创建 CMS", lastResult.error);
      });
      sendJson(res, 202, { ok: true, state: state.snapshot() });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/shutdown") {
      state.log("页面请求：退出/关闭服务");
      sendJson(res, 200, { ok: true, message: "控制台服务正在关闭" });
      setTimeout(() => {
        closeServer().catch(() => {});
      }, 50);
      return;
    }
    sendJson(res, 404, { ok: false, error: "Not found" });
  }

  async function closeServer() {
    if (closing) return;
    closing = true;
    await workflow.close();
    await new Promise((resolve) => server.close(resolve));
  }

  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port || 0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });

  const address = server.address();
  const consoleUrl = `http://127.0.0.1:${address.port}/`;
  const controlledUrl = withControlledFlag(consoleUrl);
  workflow.setConsoleUrl?.(controlledUrl);
  return {
    server,
    state,
    workflow,
    url: consoleUrl,
    controlledUrl,
    open: () => openControlledConsole(projectRoot, controlledUrl),
    close: closeServer
  };
}

function renderConsolePage() {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>2.0 可视化控制台</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, "Microsoft YaHei", sans-serif; background: #f3f6fb; color: #102033; }
    .topbar { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 24px 32px 18px; background: #fff; border-bottom: 1px solid #d9e2f1; }
    .title h1 { margin: 0; font-size: 21px; }
    .title p { margin: 6px 0 0; color: #53657d; font-size: 14px; }
    .top-actions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; justify-content: flex-end; }
    main { max-width: 980px; margin: 20px auto 112px; padding: 0 16px; }
    section { background: #fff; border: 1px solid #cfe0f8; border-radius: 8px; padding: 16px; margin-bottom: 12px; }
    h2 { margin: 0 0 14px; font-size: 17px; }
    .panel-note { color: #53657d; font-size: 13px; margin-top: -6px; margin-bottom: 12px; }
    .grid { display: grid; grid-template-columns: 128px 1fr; gap: 10px 12px; align-items: center; }
    .grid.compact { grid-template-columns: 120px 1fr 120px 1fr; }
    label { color: #40536b; font-size: 13px; }
    input, select, textarea { width: 100%; min-height: 38px; border: 1px solid #c9d6e8; border-radius: 6px; padding: 7px 10px; font: inherit; background: #fff; }
    textarea { min-height: 70px; resize: vertical; }
    button { min-height: 38px; border: 1px solid #9fb4d1; background: #fff; border-radius: 6px; padding: 0 14px; cursor: pointer; font-weight: 600; color: #17345c; }
    button.primary { background: #4f8ff7; border-color: #4f8ff7; color: white; }
    button.danger { background: #e11d48; border-color: #e11d48; color: white; }
    button.warn { background: #f59e0b; border-color: #f59e0b; color: white; }
    button.good { background: #59c485; border-color: #59c485; color: white; }
    button.outline-danger { border-color: #ef4444; color: #dc2626; }
    button:disabled { opacity: .55; cursor: not-allowed; }
    .check-btn { min-width: 90px; border-color: #2f73ff; color: #2f73ff; }
    .run-box { border: 1px solid #d6e2f4; border-radius: 8px; padding: 12px; background: #fbfdff; }
    .browser-warning { display: none; border-color: #fecaca; background: #fff1f2; color: #b91c1c; font-weight: 700; line-height: 1.55; }
    .version-notice { display: none; align-items: center; gap: 10px; border-color: #bfdbfe; background: #eff6ff; color: #1d4ed8; font-weight: 700; }
    .version-notice.is-open { display: flex; flex-wrap: wrap; }
    .license-panel { display: none; border-color: #fecaca; background: #fff7f7; }
    .license-panel.is-open { display: block; }
    .license-panel.authorized { border-color: #bbf7d0; background: #f0fdf4; }
    .license-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .license-head strong { font-size: 18px; color: #b91c1c; }
    .license-panel.authorized .license-head strong { color: #166534; }
    .license-diagnostics { display: grid; grid-template-columns: 150px minmax(0, 1fr); gap: 8px 12px; margin-top: 12px; font-size: 13px; }
    .license-diagnostics span:nth-child(odd) { color: #63758c; }
    .license-diagnostics strong { word-break: break-word; }
    .license-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 12px; }
    .version-panel { display: none; }
    .version-panel.is-open { display: block; }
    .version-summary { display: grid; gap: 8px; max-width: 620px; }
    .version-line { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .version-line span { color: #63758c; font-size: 14px; }
    .version-line strong { font-size: 18px; }
    .version-main-state { font-size: 18px; font-weight: 800; color: #166534; }
    .version-main-state.has-update { color: #1d4ed8; }
    .version-main-state.failed { color: #b91c1c; }
    .version-update-hint { color: #53657d; font-size: 14px; line-height: 1.5; }
    .version-grid { display: grid; grid-template-columns: 150px minmax(0, 1fr) 150px minmax(0, 1fr); gap: 10px 12px; align-items: start; }
    .version-grid span:nth-child(odd) { color: #63758c; font-size: 13px; }
    .version-grid strong { word-break: break-word; font-size: 13px; }
    .version-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }
    .version-state { margin-top: 10px; color: #53657d; font-size: 13px; line-height: 1.5; }
    details.version-advanced { margin-top: 14px; border-top: 1px solid #e3ebf6; padding-top: 12px; }
    details.version-advanced summary { cursor: pointer; color: #40536b; font-weight: 700; }
    .run-row { display: grid; grid-template-columns: 110px 1fr; gap: 10px; min-height: 30px; align-items: center; }
    .run-row span:first-child { color: #63758c; }
    .run-row strong { font-size: 16px; word-break: break-word; }
    .actions { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
    .hint { margin-top: 10px; font-size: 13px; color: #5b6f87; line-height: 1.5; }
    .choice-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .choice-grid.three { grid-template-columns: repeat(3, 1fr); }
    .choice { display: block; border: 1px solid #c9d6e8; border-radius: 8px; padding: 14px; cursor: pointer; min-height: 72px; background: #fff; }
    .choice:has(input:checked) { border-color: #2f73ff; background: #eef5ff; box-shadow: inset 0 0 0 1px #2f73ff; }
    .choice input { width: auto; min-height: auto; margin-right: 8px; }
    .choice b { font-size: 14px; }
    .choice p { margin: 6px 0 0 26px; color: #53657d; font-size: 13px; line-height: 1.45; }
    .time-field-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 14px; }
    .field { display: grid; gap: 6px; color: #40536b; font-size: 13px; }
    .inline-field { display: flex; gap: 8px; align-items: center; }
    .inline-field input { flex: 1; }
    .field-badge { display: inline-flex; min-height: 26px; align-items: center; border-radius: 999px; padding: 0 10px; background: #eef2ff; color: #3156a3; font-size: 12px; font-weight: 700; }
    .field-badge.warn { background: #fff7ed; color: #b45309; }
    .field-badge.bad { background: #fff1f2; color: #be123c; }
    .field-badge.good { background: #ecfdf5; color: #166534; }
    .link-feedback { grid-column: 2; color: #53657d; font-size: 13px; line-height: 1.5; }
    .link-feedback.good { color: #166534; }
    .link-feedback.warn { color: #b45309; }
    .link-feedback.bad { color: #be123c; font-weight: 700; }
    .interval-panel { margin-top: 12px; border: 1px solid #d8e5f8; border-radius: 8px; padding: 12px; background: #f8fbff; }
    .interval-panel h3 { margin: 0 0 6px; font-size: 16px; }
    .interval-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }
    .interval-tools { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; min-width: 360px; }
    .interval-tools select { width: 180px; }
    .interval-tools button { padding: 0 12px; }
    .interval-preset-panel { display: none; margin-top: 10px; border: 1px solid #cfe0f8; border-radius: 8px; padding: 10px; background: #fff; }
    .interval-preset-panel.is-open { display: block; }
    .interval-preset-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 8px; }
    .interval-preset-head strong { color: #17345c; }
    .interval-preset-list { display: grid; gap: 8px; }
    .interval-preset-empty { color: #63758c; font-size: 13px; padding: 8px 0; }
    .interval-preset-row { display: grid; grid-template-columns: minmax(160px, 1fr) minmax(180px, 1fr) auto; gap: 8px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 8px; }
    .interval-preset-summary { color: #53657d; font-size: 13px; line-height: 1.4; }
    .interval-preset-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
    .interval-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; }
    .interval-item { display: grid; grid-template-columns: 1fr 82px 14px 82px 24px; gap: 8px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 10px; background: #fff; }
    .interval-item span:first-child { color: #24425f; font-size: 14px; }
    .status-grid { display: grid; grid-template-columns: repeat(2, minmax(160px, 1fr)); gap: 10px; margin-top: 12px; }
    .stat { border: 1px solid #e1e8f2; border-radius: 6px; padding: 10px; background: #fbfcfe; min-height: 62px; }
    .stat .k { color: #6b7f98; font-size: 12px; }
    .stat .v { margin-top: 6px; font-weight: 700; word-break: break-word; }
    .recovery-panel { display: none; margin-top: 12px; border: 1px solid #fed7aa; border-radius: 8px; padding: 12px; background: #fff7ed; }
    .recovery-panel.is-open { display: block; }
    .recovery-panel h3 { margin: 0 0 6px; font-size: 15px; color: #9a3412; }
    .recovery-panel p { margin: 0; color: #7c2d12; font-size: 13px; line-height: 1.5; }
    .recovery-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
    .preview-restore-panel { display: none; margin-top: 12px; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px; background: #eff6ff; }
    .preview-restore-panel.is-open { display: block; }
    .preview-restore-panel h3 { margin: 0 0 6px; font-size: 15px; color: #1d4ed8; }
    .preview-restore-panel p { margin: 0; color: #1e3a8a; font-size: 13px; line-height: 1.5; }
    .preview-restore-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
    .failed { color: #b91c1c; }
    .waiting { color: #92400e; }
    .done { color: #166534; }
    .links { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
    .links a { color: #2563eb; text-decoration: none; font-weight: 700; }
    pre { height: 260px; overflow: auto; white-space: pre-wrap; word-break: break-word; background: #0b1020; color: #e5e7eb; padding: 12px; border-radius: 6px; font-size: 12px; line-height: 1.45; }
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .bottom-actions { position: fixed; left: 0; right: 0; bottom: 0; background: rgba(255,255,255,.94); border-top: 1px solid #d8e2f0; padding: 14px 24px; backdrop-filter: blur(8px); }
    .bottom-inner { max-width: 980px; margin: 0 auto; display: flex; justify-content: flex-end; gap: 10px; align-items: center; }
    .save-state { margin-right: auto; color: #b45309; font-size: 13px; }
    .hidden-native { display: none; }
    @media (max-width: 780px) {
      .grid, .grid.compact { grid-template-columns: 1fr; }
      .choice-grid, .choice-grid.three { grid-template-columns: 1fr; }
      .time-field-grid, .interval-grid { grid-template-columns: 1fr; }
      .interval-item { grid-template-columns: 1fr 76px 14px 76px 22px; }
      .interval-head { display: grid; }
      .interval-tools { min-width: 0; justify-content: flex-start; }
      .interval-tools select { width: 100%; }
      .interval-preset-row { grid-template-columns: 1fr; }
      .interval-preset-actions { justify-content: flex-start; }
      .status-grid { grid-template-columns: 1fr; }
      .version-grid { grid-template-columns: 1fr; }
      .topbar { padding: 18px; align-items: flex-start; }
      .bottom-inner { flex-wrap: wrap; justify-content: flex-start; }
      .save-state { width: 100%; }
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="title">
      <h1>妙券自动发单 2.0</h1>
      <p>这一页负责完整流程：配置参数、生成预览、人工校对、保存后正式创建 CMS 任务。</p>
    </div>
    <div class="top-actions">
      <button id="versionBtn">隐藏版本更新</button>
      <button class="check-btn" id="refreshBtn">刷新运行状态</button>
    </div>
  </header>
  <main>
    <section class="browser-warning" id="browserWarning">
      当前不是 2.0 专用可控浏览器。请从“2.0可视化控制台”正式入口启动；不要手动用普通浏览器打开控制台，否则飞书、预览页、云中客页面无法复用同一个 CDP 浏览器。
    </section>
    <section class="version-notice" id="versionNotice">
      <span id="versionNoticeText">发现新版本，可前往版本更新。</span>
      <button class="check-btn" id="versionNoticeOpenBtn">前往版本更新</button>
      <button id="versionNoticeDismissBtn">暂不更新</button>
    </section>
    <section class="license-panel" id="licensePanel">
      <div class="license-head">
        <div>
          <h2 style="margin-bottom:6px">授权检查</h2>
          <strong id="licenseMainText">正在检查授权...</strong>
        </div>
        <button class="check-btn" id="licenseRefreshBtn" type="button">重新检查</button>
      </div>
      <div class="license-diagnostics">
        <span>DNS</span><strong id="licenseDns">-</strong>
        <span>授权服务</span><strong id="licenseService">-</strong>
        <span>本机设备号</span><strong id="licenseDevice">-</strong>
        <span>处理建议</span><strong id="licenseAdvice">-</strong>
      </div>
      <div class="license-actions">
        <button class="primary" id="licenseRequestBtn" type="button">申请授权</button>
        <button id="licenseCopyDeviceBtn" type="button">复制设备号</button>
        <span class="hint" id="licenseRequestState" style="margin-top:0">未授权时可以提交申请，由管理员在总控页面审批。</span>
      </div>
    </section>
    <section class="version-panel is-open" id="versionPanel">
      <h2>版本更新</h2>
      <div class="version-summary">
        <div class="version-line"><span>当前版本：</span><strong id="versionNumber">-</strong></div>
        <div class="version-main-state" id="versionMainState">正在检查更新...</div>
        <div class="version-update-hint" id="versionUpdateHint">启动控制台时会自动检查一次，有新版本只提示，不会强制更新。</div>
      </div>
      <div class="version-actions">
        <button class="check-btn" id="versionRefreshBtn">检查更新</button>
        <button class="primary" id="versionUpdateBtn" disabled>立即更新</button>
        <button id="versionRollbackBtn">回退到上一版本</button>
      </div>
      <div class="version-state" id="versionState">版本状态未刷新。</div>
      <details class="version-advanced">
        <summary>高级信息 / 开发信息</summary>
        <div class="version-grid" style="margin-top:12px">
          <span>当前 commit</span><strong id="versionCommit">-</strong>
          <span>GitHub 远程地址</span><strong id="versionRemote">-</strong>
          <span>当前项目目录</span><strong id="versionProjectDir">-</strong>
          <span>本地修改状态</span><strong id="versionLocalChanges">-</strong>
          <span>最近本地备份</span><strong id="versionLatestBackup">-</strong>
          <span>最近 stable tag</span><strong id="versionStableTag">-</strong>
          <span>授权状态</span><strong id="licenseStatus">-</strong>
        </div>
        <div class="version-actions">
          <button id="versionBackupBtn">创建当前稳定备份</button>
          <button id="versionOpenBackupBtn">打开备份目录</button>
        </div>
      </details>
    </section>
    <section>
      <h2>运行控制</h2>
      <div class="run-box">
        <div class="run-row"><span>状态</span><strong id="status">-</strong></div>
        <div class="run-row"><span>当前</span><strong id="step">-</strong></div>
        <div class="run-row"><span>处理进度</span><strong id="current">-</strong></div>
        <div class="run-row"><span>等待原因</span><strong id="waiting">-</strong></div>
      </div>
      <div class="actions">
        <button class="warn" id="pauseBtn">暂停</button>
        <button class="good" id="resumeBtn">继续</button>
        <button class="danger" id="stopBtn">停止</button>
      </div>
      <div class="hint">暂停/继续/停止会在后台流程检查点生效。正式创建时仍然按保存后的 preview.json 执行。</div>
    </section>

    <section>
      <h2>1. 飞书文档</h2>
      <div class="grid">
        <label>当前文档标题</label>
        <div class="inline-field"><input id="feishuTitle"><span class="field-badge" id="feishuTitleBadge">已保存</span></div>
        <label>主飞书文档链接</label>
        <div>
          <textarea id="feishuUrl"></textarea>
          <div class="actions" style="margin-top:8px"><button id="readFeishuTitleBtn" type="button">读取标题</button></div>
        </div>
        <div></div><div class="link-feedback" id="feishuLinkFeedback">链接状态：已保存</div>
      </div>
      <div class="hint">标题来自上次成功读取记录，也可以在这里手动改，用来确认你选的是哪份文档。</div>
    </section>

    <section>
      <h2>2. 发单版本</h2>
      <select class="hidden-native" id="robotStrategy"><option value="random">按页面/随机托</option><option value="fixed">固定角色前缀</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="robotStrategyChoice" value="random"><b>粗略版：随机托</b><p>使用当前随机托流程，同一个互动托仍会绑定同一个机器人。</p></label>
        <label class="choice"><input type="radio" name="robotStrategyChoice" value="fixed"><b>精细版：固定托</b><p>选择角色范围后再更换机器人。</p></label>
      </div>
    </section>

    <section>
      <h2>3. 机器人不在群</h2>
      <select class="hidden-native" id="robotNotInGroupPolicy"><option value="ignore">不用管，直接创建</option><option value="switch_robot">自动更换机器人后再创建</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="robotNotInGroupPolicyChoice" value="ignore"><b>不用管，直接创建</b><p>确认弹窗提示机器人不在群时，仍然点击确认创建。</p></label>
        <label class="choice"><input type="radio" name="robotNotInGroupPolicyChoice" value="switch_robot"><b>自动更换机器人后再创建</b><p>取消弹窗，点击当前页面更换机器人，再重新执行发送检查。</p></label>
      </div>
      <div class="grid" id="robotNotInGroupRetryConfig" style="margin-top:12px">
        <label>最多重试次数</label><input id="robotNotInGroupMaxRetries" type="number" min="1" value="3">
      </div>
      <div class="hint" id="robotNotInGroupHint">连续 3 次仍不在群，就停止当前批次并提示人工处理。</div>
    </section>

    <section>
      <h2>4. 读取范围</h2>
      <select class="hidden-native" id="rangeMode"><option value="range">指定开始结束位置</option><option value="full">全文读取</option><option value="heading">按节奏/天数选择</option></select>
      <div class="choice-grid three">
        <label class="choice"><input type="radio" name="rangeModeChoice" value="full"><b>全文读取</b><p>适合文档不变或只发本次内容。</p></label>
        <label class="choice"><input type="radio" name="rangeModeChoice" value="range"><b>指定开始/结束位置</b><p>从开始位置读到结束那条为止。</p></label>
        <label class="choice"><input type="radio" name="rangeModeChoice" value="heading"><b>按节奏/天数选择</b><p>从飞书左侧目录读取标题结构后选择范围。</p></label>
      </div>
      <div class="grid" id="rangeInputs" style="margin-top:12px">
        <label>开始位置</label><input id="startKeyword">
        <label>结束位置</label><input id="endKeyword" placeholder="空=到文档末尾">
      </div>
      <div class="grid" id="headingRangeInputs" style="margin-top:12px; display:none">
        <label>标题结构</label><div class="inline-field"><button id="readHeadingStructureBtn" type="button">读取/刷新标题结构</button><span class="field-badge warn" id="headingStructureBadge">待读取</span></div>
        <label>第几天</label><select id="headingDay"><option value="">请先读取标题结构</option></select>
        <label>节奏/阶段</label><select id="headingRhythm"><option value="">整天</option></select>
        <label>自动范围</label><div class="hint" id="headingRangeHint">从选中标题下方开始，到下一个同级标题前；朋友圈默认跳过。</div>
      </div>
      <div class="hint" id="rangeHint"></div>
    </section>

    <section>
      <h2>5. 时间模式</h2>
      <select class="hidden-native" id="scheduleMode"><option value="doc">文档时间</option><option value="realtime">实时跟发</option><option value="catchup">补发到文档时间</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="doc"><b>文档时间</b><p>按飞书上写的时间定。适用：文案时间已经排好。</p></label>
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="realtime"><b>实时跟发</b><p>按输入的开始时间重新生成发送时间。结束时间可留空。</p></label>
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="catchup"><b>补发到文档时间</b><p>过期内容先补发，后面衔接回文档时间。</p></label>
      </div>
      <div class="hint" id="timeModeHint"></div>
      <div class="time-field-grid" id="timeFields">
        <div class="field" id="dateField"><label>本轮基础发单日期</label><input id="date" placeholder="不填默认今天"></div>
        <div class="field" id="realtimeStartField"><label>开始时间</label><input id="realtimeStartTime" placeholder="不填默认 1 分钟后开始"></div>
        <div class="field" id="catchupStartField"><label>开始时间</label><input id="currentTime" placeholder="不填默认 1 分钟后开始"></div>
        <div class="field" id="realtimeEndField"><label>结束时间</label><input id="realtimeEndTime" placeholder="可留空"></div>
      </div>
      <div class="interval-panel" id="customIntervals">
        <div class="interval-head">
          <div>
            <h3>自定义间隔范围（可选）</h3>
            <div class="panel-note">不填就使用默认规则；只影响实时跟发和补发到文档时间。</div>
          </div>
          <div class="interval-tools">
            <select id="intervalPresetSelect"><option value="">选择已保存方案</option></select>
            <button id="saveIntervalPresetBtn" type="button">保存当前为方案</button>
            <button id="manageIntervalPresetBtn" type="button">方案设置</button>
            <button id="clearIntervalsBtn" type="button">清空自定义间隔</button>
          </div>
        </div>
        <div class="interval-preset-panel" id="intervalPresetPanel">
          <div class="interval-preset-head">
            <strong>方案设置</strong>
            <button id="closeIntervalPresetPanelBtn" type="button">关闭</button>
          </div>
          <div class="interval-preset-list" id="intervalPresetList"></div>
        </div>
        <div class="interval-grid">
          <div class="interval-item"><span>不同托之间（非互动）</span><input id="differentTuoMin" type="number" min="1" placeholder="最短"><span>-</span><input id="differentTuoMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>同一个托连续说话</span><input id="sameTuoMin" type="number" min="1" placeholder="最短"><span>-</span><input id="sameTuoMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>豆妈连续内容</span><input id="doumaSameMin" type="number" min="1" placeholder="最短"><span>-</span><input id="doumaSameMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>豆妈/托切换</span><input id="roleSwitchMin" type="number" min="1" placeholder="最短"><span>-</span><input id="roleSwitchMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
        </div>
      </div>
      <div class="hint" id="intervalDefaultHint">不填时使用默认规则：同一个托连续文字约 20-45 秒；豆妈连续内容约 45 秒；图片/表情包/视频附近约 30-50 秒；不同托非互动约 15 秒；豆妈/托切换至少 120 秒。填写自定义后，图片/表情包/视频附近会跟随对应的豆妈连续、同托、不同托或豆妈/托切换规则。</div>
      <input class="hidden-native" id="mediaMin">
      <input class="hidden-native" id="mediaMax">
    </section>

    <section>
      <h2>6. 结果和日志</h2>
      <div class="status-grid">
        <div class="stat"><div class="k">成功/失败</div><div class="v" id="counts">-</div></div>
        <div class="stat"><div class="k">缺失文件</div><div class="v" id="missing">-</div></div>
        <div class="stat"><div class="k">run 目录</div><div class="v" id="runDir">-</div></div>
        <div class="stat"><div class="k">preview.json</div><div class="v" id="previewPath">-</div></div>
        <div class="stat"><div class="k">失败原因</div><div class="v failed" id="failure">-</div></div>
      </div>
      <div class="recovery-panel" id="robotRecoveryPanel">
        <h3>机器人不在群，已达到自动重试上限</h3>
        <p>可以直接按当前弹窗继续创建，也可以继续尝试更换机器人。本操作会复用当前 run 和已保存的 preview.json。</p>
        <div class="recovery-actions">
          <button class="primary" id="robotDirectCreateBtn" type="button">直接创建</button>
          <select id="robotDirectCreateMode" style="width:auto; min-width:138px">
            <option value="once">只允许这次</option>
            <option value="always">以后一直</option>
          </select>
          <button id="robotRetryMoreBtn" type="button">继续更换机器人重试</button>
        </div>
      </div>
      <div class="links">
        <a id="previewLink" href="#" target="_blank" style="display:none">打开预览页</a>
      </div>
      <div class="preview-restore-panel" id="previewRestorePanel">
        <h3>检测到上次预览</h3>
        <p id="previewRestoreText">是否恢复上次预览页？</p>
        <div class="preview-restore-actions">
          <button class="primary" id="previewRestoreBtn" type="button">恢复</button>
          <button id="previewRestoreCancelBtn" type="button">取消</button>
        </div>
      </div>
      <pre id="logs"></pre>
    </section>
  </main>
  <input class="hidden-native" id="cmsUrl">
  <input class="hidden-native" id="cdpUrl">
  <input class="hidden-native" id="feishuTitleUrl">
  <select class="hidden-native" id="restoreSelection"><option value="true">是</option><option value="false">否</option></select>
  <div class="bottom-actions">
    <div class="bottom-inner">
      <span class="save-state" id="saveState">页面已就绪。</span>
      <button id="discardBtn">放弃本轮，重新生成预览</button>
      <button class="outline-danger" id="exitBtn">退出</button>
      <button class="primary" id="generateBtn">保存设置，生成预览</button>
      <button class="primary" id="startCmsBtn" style="display:none">我已设置好，开始创建任务</button>
      <button class="primary" id="nextRunBtn" style="display:none">开始下一轮发单</button>
    </div>
  </div>
  <script>
    const ids = ["feishuUrl","feishuTitle","feishuTitleUrl","rangeMode","startKeyword","endKeyword","headingDay","headingRhythm","scheduleMode","realtimeStartTime","realtimeEndTime","currentTime","date","sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax","cmsUrl","cdpUrl","robotStrategy","robotNotInGroupPolicy","robotNotInGroupMaxRetries","restoreSelection"];
    const $ = (id) => document.getElementById(id);
    let controlledBrowserReady = false;
    let manualStatusFeedbackUntil = 0;
    let versionNoticeDismissed = false;
    let savedFeishuUrl = "";
    let titleReadForFeishuUrl = "";
    let latestStatus = null;
    let headingStructure = null;
    let backendDisconnected = false;
    let latestLicenseDiagnostics = null;
    let licenseAllowed = false;
    let licenseCheckInFlight = false;
    let licenseAutoRefreshTimer = null;
    let previewRestoreDismissed = false;
    let intervalPresets = [];

    checkControlledBrowser().then(loadSettings);
    loadIntervalPresets().catch(() => {});
    refreshLicenseDiagnostics({ auto: true });
    refreshVersionStatus({ startup: true });
    checkPreviewRestoreCandidate();
    bindCardGroup("robotStrategyChoice", "robotStrategy");
    bindCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
    bindCardGroup("rangeModeChoice", "rangeMode");
    bindCardGroup("scheduleModeChoice", "scheduleMode");
    updateRangeVisibility();
    updateRobotNotInGroupVisibility();
    updateScheduleModeVisibility();
    setInterval(() => refreshStatus().catch(() => {}), 1200);
    refreshStatus().catch(() => {});

    $("refreshBtn").addEventListener("click", refreshStatusManually);
    $("versionBtn").addEventListener("click", async () => {
      $("versionPanel").classList.toggle("is-open");
      const isOpen = $("versionPanel").classList.contains("is-open");
      $("versionBtn").textContent = isOpen ? "隐藏版本更新" : "版本更新";
      if (isOpen) await refreshVersionStatus();
    });
    $("versionNoticeOpenBtn").addEventListener("click", async () => {
      $("versionPanel").classList.add("is-open");
      $("versionBtn").textContent = "隐藏版本更新";
      $("versionPanel").scrollIntoView({ behavior: "smooth", block: "start" });
      await refreshVersionStatus();
    });
    $("versionNoticeDismissBtn").addEventListener("click", () => {
      versionNoticeDismissed = true;
      $("versionNotice").classList.remove("is-open");
    });
    $("versionRefreshBtn").addEventListener("click", refreshVersionStatus);
    $("licenseRefreshBtn").addEventListener("click", () => refreshLicenseDiagnostics({ manual: true }));
    $("licenseRequestBtn").addEventListener("click", requestLicenseAccess);
    $("licenseCopyDeviceBtn").addEventListener("click", copyLicenseDeviceId);
    $("versionBackupBtn").addEventListener("click", () => runVersionAction("backup"));
    $("versionUpdateBtn").addEventListener("click", () => runVersionAction("update"));
    $("versionRollbackBtn").addEventListener("click", () => runVersionAction("rollback"));
    $("versionOpenBackupBtn").addEventListener("click", () => runVersionAction("open-backup-dir"));
    $("previewRestoreBtn").addEventListener("click", restorePreviousPreview);
    $("previewRestoreCancelBtn").addEventListener("click", cancelPreviewRestore);
    $("feishuUrl").addEventListener("input", handleFeishuUrlChanged);
    $("feishuUrl").addEventListener("paste", () => setTimeout(handleFeishuUrlChanged, 0));
    $("feishuTitle").addEventListener("input", handleFeishuTitleEdited);
    $("readFeishuTitleBtn").addEventListener("click", readFeishuTitle);
    $("readHeadingStructureBtn").addEventListener("click", readHeadingStructure);
    $("headingDay").addEventListener("change", updateHeadingRhythmOptions);
    $("headingRhythm").addEventListener("change", updateHeadingRangeHint);
    $("pauseBtn").addEventListener("click", () => sendControl("pause"));
    $("resumeBtn").addEventListener("click", () => sendControl("resume"));
    $("stopBtn").addEventListener("click", () => sendControl("stop"));
    $("robotNotInGroupMaxRetries").addEventListener("input", updateRobotNotInGroupVisibility);
    $("clearIntervalsBtn").addEventListener("click", clearCustomIntervals);
    $("intervalPresetSelect").addEventListener("change", applySelectedIntervalPreset);
    $("saveIntervalPresetBtn").addEventListener("click", saveCurrentIntervalPreset);
    $("manageIntervalPresetBtn").addEventListener("click", toggleIntervalPresetPanel);
    $("closeIntervalPresetPanelBtn").addEventListener("click", () => $("intervalPresetPanel").classList.remove("is-open"));
    $("discardBtn").addEventListener("click", async () => {
      if (!confirm("确认放弃当前 run，并按当前设置重新生成预览？")) return;
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再生成预览。";
        return;
      }
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      setButtons("running");
      $("saveState").textContent = "已提交重新生成请求。";
      let result;
      try {
        result = await submitGeneratePreview();
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，重新生成预览不会继续。请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (result.code === "preview_dirty") return;
      if (!result.ok && result.code !== "preview_dirty") $("saveState").textContent = result.error || "重新生成预览失败。";
      await refreshStatus({ manual: true });
    });
    $("exitBtn").addEventListener("click", async () => {
      if (!confirm("确认退出并关闭本次 2.0 控制台后台服务？")) return;
      $("saveState").textContent = "正在关闭控制台服务。";
      try {
        await postJson("/api/shutdown", {});
        document.body.innerHTML = "<main><section><h2>控制台服务已关闭</h2><p class='hint'>可以关闭这个浏览器标签页。下次使用请重新双击 2.0 可视化控制台入口。</p></section></main>";
      } catch (error) {
        $("saveState").textContent = "关闭服务请求失败：" + (error?.message || error);
      }
    });
    $("generateBtn").addEventListener("click", async () => {
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再生成预览。";
        return;
      }
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      setButtons("running");
      $("saveState").textContent = "已保存设置，正在生成预览。";
      if (isFeishuUrlDirty()) {
        $("saveState").textContent = "文档链接已更新，将重新读取标题和内容。";
        $("feishuLinkFeedback").textContent = "链接状态：已修改，正在生成预览";
        $("feishuLinkFeedback").className = "link-feedback warn";
      }
      let result;
      try {
        result = await submitGeneratePreview();
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，生成预览不会继续。请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (result.code === "preview_dirty") return;
      if (!result.ok) $("saveState").textContent = result.error || "保存设置失败。";
      else {
        savedFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
        titleReadForFeishuUrl = savedFeishuUrl;
        $("feishuTitleUrl").value = savedFeishuUrl;
        $("feishuTitleBadge").textContent = "已更新";
        $("feishuTitleBadge").className = "field-badge good";
        $("feishuLinkFeedback").textContent = "链接状态：已保存，已生成预览";
        $("feishuLinkFeedback").className = "link-feedback good";
      }
      await refreshStatus();
    });

    async function submitGeneratePreview(options = {}) {
      const result = await postJson("/api/generate-preview", {
        settings: readSettings(),
        forceRegeneratePreview: options.forceRegeneratePreview === true
      });
      if (result.code !== "preview_dirty") return result;
      setButtons("ready");
      const confirmed = confirm(result.error || "已有预览页有未保存修改。确认放弃这些修改并重新生成预览？");
      if (!confirmed) {
        $("saveState").textContent = "已取消重新生成，当前预览页未保存修改仍保留。";
        await refreshStatus({ manual: true });
        return result;
      }
      setButtons("running");
      $("saveState").textContent = "已确认放弃旧预览未保存修改，正在重新生成预览。";
      return postJson("/api/generate-preview", {
        settings: readSettings(),
        forceRegeneratePreview: true
      });
    }
    $("startCmsBtn").addEventListener("click", async () => {
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再开始创建。";
        return;
      }
      await startCmsWithSettings(readSettings(), "已确认云中客设置，正在开始正式创建。");
    });
    $("nextRunBtn").addEventListener("click", async () => {
      if (latestStatus && (latestStatus.status === "running" || latestStatus.status === "paused")) {
        $("saveState").textContent = "当前流程还在运行，不能开始下一轮。";
        return;
      }
      setButtons("running");
      $("saveState").textContent = "正在准备下一轮，保留当前配置。";
      let result;
      try {
        result = await postJson("/api/next-run", {});
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (!result.ok) {
        $("saveState").textContent = result.error || "开始下一轮失败。";
        await refreshStatus({ manual: true });
        return;
      }
      manualStatusFeedbackUntil = Date.now() + 5000;
      $("saveState").textContent = "已进入下一轮，可以修改飞书链接、时间模式，或直接生成新预览。";
      await refreshStatus({ manual: true });
    });
    $("robotDirectCreateBtn").addEventListener("click", async () => {
      const mode = $("robotDirectCreateMode").value === "always" ? "always" : "once";
      if (mode === "always") {
        if (!confirm("确认以后一直直接创建？这会把“机器人不在群”设置保存为“不用管，直接创建”。")) return;
        $("robotNotInGroupPolicy").value = "ignore";
        syncCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
        updateRobotNotInGroupVisibility();
        await startCmsWithSettings(readSettings(), "已保存为以后一直直接创建，正在用当前 run 重新开始正式创建。");
        return;
      }
      if (!confirm("确认只允许这次直接创建？本次会忽略机器人不在群提示，但不会修改以后默认设置。")) return;
      await startCmsWithSettings(readSettings(), "已选择本次直接创建，正在用当前 run 重新开始正式创建。", {
        robotNotInGroupPolicy: "ignore"
      });
    });
    $("robotRetryMoreBtn").addEventListener("click", async () => {
      const settings = {
        ...readSettings(),
        robotNotInGroupPolicy: "switch_robot",
        robotNotInGroupMaxRetries: Math.max(1, Number($("robotNotInGroupMaxRetries").value || 3))
      };
      await startCmsWithSettings(settings, "已选择继续更换机器人重试，正在用当前 run 重新开始正式创建。");
    });

    async function startCmsWithSettings(settings, message, temporarySettings = null) {
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再开始创建。";
        return;
      }
      setButtons("running");
      updateRobotRecoveryActions(null);
      $("saveState").textContent = message || "正在开始正式创建。";
      let result;
      try {
        result = await postJson("/api/start-cms", { settings, temporarySettings });
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，正式创建不会继续。请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (!result.ok) {
        $("saveState").textContent = result.error || "开始创建失败。";
        await refreshStatus({ manual: true });
        return;
      }
      await refreshStatus({ manual: true });
    }

    async function checkControlledBrowser(attempt = 0) {
      const hasControlledFlag = new URLSearchParams(location.search).get("controlled") === "1";
      try {
        const result = await fetchJson("/api/browser-state");
        controlledBrowserReady = Boolean(result.ok && result.controlled && hasControlledFlag);
        if (!controlledBrowserReady && hasControlledFlag && attempt < 6) {
          setTimeout(() => checkControlledBrowser(attempt + 1), 500);
        }
        if ($("cdpUrl") && result.cdpUrl) $("cdpUrl").value = result.cdpUrl;
        $("browserWarning").style.display = controlledBrowserReady ? "none" : "block";
        if (controlledBrowserReady) {
          $("saveState").textContent = "已连接 2.0 专用可控浏览器。";
        } else {
          $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从“2.0可视化控制台”正式入口启动。";
        }
      } catch (error) {
        controlledBrowserReady = false;
        $("browserWarning").style.display = "block";
        $("saveState").textContent = "无法确认可控浏览器状态：" + (error?.message || error);
      }
      setButtons("idle");
    }

    async function loadSettings() {
      const result = await fetchJson("/api/settings");
      if (!result.ok) return;
      if (result.settings.headingDay) setSelectOptions($("headingDay"), [{ value: result.settings.headingDay, label: result.settings.headingDay }]);
      if (result.settings.headingRhythm) setSelectOptions($("headingRhythm"), [{ value: "", label: "整天" }, { value: result.settings.headingRhythm, label: result.settings.headingRhythm }]);
      for (const id of ids) if ($(id) && result.settings[id] !== undefined) $(id).value = String(result.settings[id]);
      savedFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      titleReadForFeishuUrl = normalizeFeishuUrlInput($("feishuTitleUrl").value);
      clearStaleFeishuTitleIfNeeded();
      updateFeishuLinkFeedback();
      syncFeishuTitleFromStatus(latestStatus);
      syncCardGroups();
    }

    function readSettings() {
      const data = {};
      for (const id of ids) data[id] = $(id)?.value || "";
      data.restoreSelection = data.restoreSelection !== "false";
      data.robotNotInGroupMaxRetries = Number(data.robotNotInGroupMaxRetries || 3);
      for (const key of ["sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"]) {
        if (String(data[key] || "").trim() !== "") data[key] = Number(data[key]);
      }
      return data;
    }

    function handleFeishuUrlChanged() {
      headingStructure = null;
      resetHeadingStructureOptions("请先读取标题结构");
      clearStaleFeishuTitleIfNeeded();
      updateFeishuLinkFeedback();
    }

    function handleFeishuTitleEdited() {
      const title = $("feishuTitle").value.trim();
      if (!title || isPlaceholderFeishuTitle(title)) {
        titleReadForFeishuUrl = "";
        $("feishuTitleUrl").value = "";
        return;
      }
      titleReadForFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      $("feishuTitleUrl").value = titleReadForFeishuUrl;
    }

    function clearStaleFeishuTitleIfNeeded() {
      const currentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      const titleUrl = normalizeFeishuUrlInput($("feishuTitleUrl").value || titleReadForFeishuUrl);
      const currentTitle = $("feishuTitle").value.trim();
      if (!currentTitle || isPlaceholderFeishuTitle(currentTitle)) return false;
      if (currentUrl && titleUrl && sameFeishuDocument(currentUrl, titleUrl)) return false;
      $("feishuTitle").value = "待读取";
      titleReadForFeishuUrl = "";
      $("feishuTitleUrl").value = "";
      return true;
    }

    function updateFeishuLinkFeedback() {
      const input = $("feishuUrl").value;
      const normalized = normalizeFeishuUrlInput(input);
      const dirty = isFeishuUrlDirty();
      $("readFeishuTitleBtn").disabled = !normalized || !controlledBrowserReady;
      $("readHeadingStructureBtn").disabled = !normalized || !controlledBrowserReady;
      if (!String(input || "").trim()) {
        $("feishuTitleBadge").textContent = "待读取";
        $("feishuTitleBadge").className = "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接状态：请粘贴飞书文档链接";
        $("feishuLinkFeedback").className = "link-feedback warn";
        return;
      }
      if (!normalized) {
        $("feishuTitleBadge").textContent = "待更新";
        $("feishuTitleBadge").className = "field-badge bad";
        $("feishuLinkFeedback").textContent = "链接格式可能不正确，请检查";
        $("feishuLinkFeedback").className = "link-feedback bad";
        return;
      }
      if (dirty) {
        clearStaleFeishuTitleIfNeeded();
        $("feishuTitleBadge").textContent = "待更新";
        $("feishuTitleBadge").className = "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接已识别。检测到新的文档链接，尚未保存；链接状态：已修改，未生成预览。";
        $("feishuLinkFeedback").className = "link-feedback warn";
        $("generateBtn").classList.add("primary");
        if (controlledBrowserReady) $("generateBtn").disabled = false;
      } else {
        $("feishuTitleBadge").textContent = $("feishuTitle").value.trim() ? "已保存" : "待读取";
        $("feishuTitleBadge").className = $("feishuTitle").value.trim() ? "field-badge good" : "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接已识别。链接状态：已保存";
        $("feishuLinkFeedback").className = "link-feedback good";
      }
    }

    function isFeishuUrlDirty() {
      return normalizeFeishuUrlInput($("feishuUrl").value) !== savedFeishuUrl;
    }

    function normalizeFeishuUrlInput(value) {
      const text = String(value || "")
        .replace(/[<>]/g, " ")
        .replace(/[“”]/g, '"')
        .replace(/[‘’]/g, "'")
        .trim();
      if (!text) return "";
      const markdown = text.match(/\\((https?:\\/\\/[^)]+)\\)/);
      const source = markdown?.[1] || text;
      const compactSource = source.replace(/\\s+/g, "");
      const match = compactSource.match(/https:\\/\\/\\S*feishu\\.cn\\/(?:docx|docs|wiki|sheets)\\/\\S+/i);
      const url = (match?.[0] || "").replace(/[)\\]};,，。；]+$/g, "");
      return /^https:\\/\\/[^/]*feishu\\.cn\\/(?:docx|docs|wiki|sheets)\\//i.test(url) ? url : "";
    }

    async function readFeishuTitle() {
      const feishuUrl = $("feishuUrl").value;
      if (!normalizeFeishuUrlInput(feishuUrl)) {
        $("feishuLinkFeedback").textContent = "链接格式可能不正确，请检查";
        $("feishuLinkFeedback").className = "link-feedback bad";
        return;
      }
      $("readFeishuTitleBtn").disabled = true;
      $("feishuTitleBadge").textContent = "读取中";
      $("feishuTitleBadge").className = "field-badge warn";
      $("feishuLinkFeedback").textContent = "正在读取飞书文档标题...";
      $("feishuLinkFeedback").className = "link-feedback warn";
      try {
        const result = await postJson("/api/feishu-title", { feishuUrl });
        if (!result.ok) throw new Error(result.error || "读取标题失败。");
        $("feishuTitle").value = result.title || "未读取到标题";
        titleReadForFeishuUrl = normalizeFeishuUrlInput(result.feishuUrl || feishuUrl);
        $("feishuTitleUrl").value = titleReadForFeishuUrl;
        $("feishuTitleBadge").textContent = "待更新";
        $("feishuTitleBadge").className = "field-badge warn";
        $("feishuLinkFeedback").textContent = "标题已读取，检测到新的文档链接，尚未保存；点击保存设置，生成预览后生效。";
        $("feishuLinkFeedback").className = "link-feedback good";
      } catch (error) {
        $("feishuTitle").value = $("feishuTitle").value.trim() || "待读取";
        $("feishuTitleBadge").textContent = "待读取";
        $("feishuTitleBadge").className = "field-badge bad";
        $("feishuLinkFeedback").textContent = "读取标题失败：" + (error?.message || error);
        $("feishuLinkFeedback").className = "link-feedback bad";
      } finally {
        updateFeishuLinkFeedback();
      }
    }

    async function readHeadingStructure() {
      const feishuUrl = $("feishuUrl").value;
      if (!normalizeFeishuUrlInput(feishuUrl)) {
        $("headingStructureBadge").textContent = "链接无效";
        $("headingStructureBadge").className = "field-badge bad";
        $("headingRangeHint").textContent = "链接格式可能不正确，请检查。";
        return;
      }
      $("readHeadingStructureBtn").disabled = true;
      $("headingStructureBadge").textContent = "读取中";
      $("headingStructureBadge").className = "field-badge warn";
      $("headingRangeHint").textContent = "正在读取飞书左侧目录，不会采集正文和素材。";
      try {
        const result = await postJson("/api/heading-structure", { feishuUrl });
        if (!result.ok) throw new Error(result.error || "识别标题结构失败。");
        headingStructure = result.structure || null;
        if (result.title) {
          $("feishuTitle").value = result.title;
          syncFeishuTitleFromStatus({ feishuTitle: result.title, feishuUrl: result.feishuUrl || feishuUrl });
        }
        fillHeadingOptions(headingStructure);
        $("headingStructureBadge").textContent = "已读取";
        $("headingStructureBadge").className = "field-badge good";
        updateHeadingRangeHint();
      } catch (error) {
        $("headingStructureBadge").textContent = "读取失败";
        $("headingStructureBadge").className = "field-badge bad";
        $("headingRangeHint").textContent = "识别标题结构失败：" + (error?.message || error);
      } finally {
        $("readHeadingStructureBtn").disabled = false;
      }
    }

    function fillHeadingOptions(structure) {
      const days = Array.isArray(structure?.days) ? structure.days : [];
      const previousDay = $("headingDay").value;
      setSelectOptions($("headingDay"), days.length ? days : [{ value: "", label: "未识别到天数" }]);
      if (days.some((item) => item.value === previousDay)) $("headingDay").value = previousDay;
      else if (days[0]) $("headingDay").value = days[0].value;
      updateHeadingRhythmOptions();
    }

    function updateHeadingRhythmOptions() {
      const day = $("headingDay").value;
      const choices = Array.isArray(headingStructure?.choices) ? headingStructure.choices : [];
      const rhythms = [];
      for (const choice of choices) {
        if (choice.day !== day || !choice.rhythm) continue;
        if (!rhythms.some((item) => item.value === choice.rhythm)) rhythms.push({ value: choice.rhythm, label: choice.rhythm });
      }
      setSelectOptions($("headingRhythm"), [{ value: "", label: "整天" }, ...rhythms]);
      updateHeadingRangeHint();
    }

    function updateHeadingRangeHint() {
      const day = $("headingDay").value || "未选择";
      const rhythm = $("headingRhythm").value || "整天";
      if (!headingStructure) {
        $("headingRangeHint").textContent = "从选中标题下方开始，到下一个同级标题前；朋友圈默认跳过。";
        return;
      }
      $("headingRangeHint").textContent = "自动范围：" + day + " / " + rhythm + "；从对应标题下方开始，到下一个同级标题前；朋友圈默认跳过。";
    }

    function resetHeadingStructureOptions(message) {
      if (!$("headingDay") || !$("headingRhythm")) return;
      setSelectOptions($("headingDay"), [{ value: "", label: message || "请先读取标题结构" }]);
      setSelectOptions($("headingRhythm"), [{ value: "", label: "整天" }]);
      if ($("headingStructureBadge")) {
        $("headingStructureBadge").textContent = "待读取";
        $("headingStructureBadge").className = "field-badge warn";
      }
      if ($("headingRangeHint")) $("headingRangeHint").textContent = "从选中标题下方开始，到下一个同级标题前；朋友圈默认跳过。";
    }

    function setSelectOptions(select, options) {
      const previous = select.value;
      select.innerHTML = "";
      for (const option of options) {
        const item = document.createElement("option");
        item.value = option.value || "";
        item.textContent = option.label || option.value || "";
        select.appendChild(item);
      }
      if (options.some((option) => option.value === previous)) select.value = previous;
    }

    async function checkPreviewRestoreCandidate() {
      if (previewRestoreDismissed) return;
      try {
        const result = await fetchJson("/api/preview/restore-candidate");
        const candidate = result.candidate || {};
        if (!result.ok || !candidate.available) {
          $("previewRestorePanel").classList.remove("is-open");
          return;
        }
        $("previewRestoreText").textContent = "上次预览：" + (candidate.runName || "未命名") + "，共 " + (candidate.taskCount || 0) + " 条。是否恢复这个预览页？";
        $("previewRestorePanel").classList.add("is-open");
      } catch {
        $("previewRestorePanel").classList.remove("is-open");
      }
    }

    async function restorePreviousPreview() {
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再恢复预览。";
        return;
      }
      $("previewRestoreBtn").disabled = true;
      $("previewRestoreCancelBtn").disabled = true;
      $("saveState").textContent = "正在恢复上次预览。";
      try {
        const result = await postJson("/api/preview/restore", { settings: readSettings() });
        if (!result.ok) throw new Error(result.error || "恢复上次预览失败。");
        previewRestoreDismissed = true;
        $("previewRestorePanel").classList.remove("is-open");
        $("saveState").textContent = "已恢复上次预览，请检查预览页。";
        await refreshStatus({ manual: true });
      } catch (error) {
        $("saveState").textContent = "恢复上次预览失败：" + (error?.message || error);
        $("previewRestoreBtn").disabled = false;
        $("previewRestoreCancelBtn").disabled = false;
      }
    }

    function cancelPreviewRestore() {
      previewRestoreDismissed = true;
      $("previewRestorePanel").classList.remove("is-open");
      $("saveState").textContent = "已取消恢复上次预览。";
    }

    async function refreshStatusManually() {
      $("refreshBtn").disabled = true;
      $("saveState").textContent = "正在刷新运行状态...";
      try {
        const status = await refreshStatus({ manual: true });
        manualStatusFeedbackUntil = Date.now() + 5000;
        $("saveState").textContent = "运行状态已刷新：" + currentClockText() + "，当前状态：" + labelStatus(status?.status);
      } catch (error) {
        manualStatusFeedbackUntil = Date.now() + 5000;
        $("saveState").textContent = "刷新运行状态失败：" + (error?.message || error);
      } finally {
        $("refreshBtn").disabled = false;
      }
    }

    async function refreshStatus(options = {}) {
      let result;
      try {
        result = await fetchJson("/api/status");
      } catch (error) {
        markBackendDisconnected(error);
        if (options.manual) throw error;
        return null;
      }
      if (!result.ok) {
        if (options.manual) throw new Error(result.error || "状态接口返回失败。");
        return null;
      }
      if (backendDisconnected) {
        backendDisconnected = false;
        await checkControlledBrowser();
      }
      const s = result.state;
      latestStatus = s;
      syncFeishuTitleFromStatus(s);
      $("step").textContent = s.step || "-";
      $("status").textContent = labelStatus(s.status);
      $("status").className = "v " + (s.status === "failed" ? "failed" : s.status === "waiting" ? "waiting" : s.status === "completed" ? "done" : "");
      $("current").textContent = s.currentIndex ? "第 " + s.currentIndex + " 条 / 共 " + (s.totalCount || "?") + " 条" : "-";
      $("counts").textContent = (s.successCount || 0) + " / " + (s.failureCount || 0);
      $("waiting").textContent = s.waitingReason || "-";
      $("missing").textContent = (s.missingFiles || []).join("、") || "-";
      $("runDir").textContent = s.runDir || "-";
      $("previewPath").textContent = s.previewPath || "-";
      $("failure").textContent = s.failureReason || "-";
      updateRobotRecoveryActions(s);
      const link = $("previewLink");
      if (s.previewUrl) {
        link.href = s.previewUrl;
        link.style.display = "";
      } else {
        link.style.display = "none";
      }
      $("logs").textContent = (s.logs || []).map((item) => "[" + item.time.replace("T", " ").slice(0, 19) + "] " + item.message).join("\\n");
      updateMainActionButtons(s);
      if (!options.manual && Date.now() >= manualStatusFeedbackUntil) {
        if (s.status === "failed") $("saveState").textContent = "流程失败，请看失败原因和 run 目录。";
        else if (s.status === "waiting") $("saveState").textContent = s.waitingReason || "预览已生成，请打开预览页检查并保存 preview.json。";
        else if (s.status === "completed") $("saveState").textContent = "本轮已创建完成，可以核对任务列表，或开始下一轮发单。";
      }
      setButtons(s.status);
      return s;
    }

    function updateMainActionButtons(s) {
      const completed = s.status === "completed";
      const cmsReady = s.step === "CMS 准备";
      $("startCmsBtn").style.display = cmsReady || completed ? "" : "none";
      $("startCmsBtn").textContent = completed ? "本轮已创建完成" : "我已设置好，开始创建任务";
      $("nextRunBtn").style.display = completed ? "" : "none";
    }

    function updateRobotRecoveryActions(state) {
      const panel = $("robotRecoveryPanel");
      if (!panel) return;
      const show = Boolean(state && state.status === "failed" && isRobotNotInGroupRetryFailure(state.failureReason));
      panel.classList.toggle("is-open", show);
      $("robotDirectCreateBtn").disabled = !show || !controlledBrowserReady || !licenseAllowed;
      $("robotDirectCreateMode").disabled = !show || !controlledBrowserReady || !licenseAllowed;
      $("robotRetryMoreBtn").disabled = !show || !controlledBrowserReady || !licenseAllowed;
    }

    function isRobotNotInGroupRetryFailure(reason) {
      const text = String(reason || "");
      return text.includes("机器人不在群") && (
        text.includes("已尝试更换机器人") ||
        text.includes("更换机器人后仍检测到机器人不在群")
      );
    }

    function markBackendDisconnected(error, options = {}) {
      backendDisconnected = true;
      controlledBrowserReady = false;
      const reason = error?.message || String(error || "无法连接后台服务");
      const saveMessage = options.saveMessage || "控制台后台服务已断开，请重新双击 2.0 可视化控制台正式入口。当前操作不会继续生成预览。";
      latestStatus = {
        ...(latestStatus || {}),
        step: "后台断开",
        status: "disconnected",
        waitingReason: "后台服务已断开，请重新打开正式入口。",
        failureReason: reason
      };
      $("step").textContent = "后台断开";
      $("status").textContent = "后台断开";
      $("status").className = "v failed";
      $("waiting").textContent = "后台服务已断开，请重新打开正式入口。";
      $("failure").textContent = reason;
      $("saveState").textContent = saveMessage;
      $("previewLink").style.display = "none";
      updateRobotRecoveryActions(null);
      setButtons("ready");
    }

    function syncFeishuTitleFromStatus(state) {
      const title = String(state?.feishuTitle || "").trim();
      if (!title || isPlaceholderFeishuTitle(title)) return;
      const statusUrl = normalizeFeishuUrlInput(state?.feishuUrl || "");
      const currentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      if (statusUrl && currentUrl && !sameFeishuDocument(statusUrl, currentUrl)) return;
      const currentTitle = $("feishuTitle").value.trim();
      if (currentTitle === title) return;
      if (currentTitle && !isPlaceholderFeishuTitle(currentTitle)) return;
      $("feishuTitle").value = title;
      titleReadForFeishuUrl = statusUrl || currentUrl || titleReadForFeishuUrl;
      $("feishuTitleUrl").value = titleReadForFeishuUrl;
      $("feishuTitleBadge").textContent = "已读取";
      $("feishuTitleBadge").className = "field-badge good";
    }

    function isPlaceholderFeishuTitle(value) {
      return ["待读取", "未读取到标题"].includes(String(value || "").trim());
    }

    function sameFeishuDocument(left, right) {
      const leftKey = feishuDocumentKey(left);
      const rightKey = feishuDocumentKey(right);
      return Boolean(leftKey && rightKey && leftKey === rightKey);
    }

    function feishuDocumentKey(value) {
      const url = normalizeFeishuUrlInput(value);
      if (!url) return "";
      const match = url.match(/^https:\\/\\/([^/]*feishu\\.cn)\\/(docx|docs|wiki|sheets)\\/([^?#]+)/i);
      return match ? (match[1].toLowerCase() + "/" + match[2].toLowerCase() + "/" + match[3]) : "";
    }

    async function refreshLicenseDiagnostics(options = {}) {
      if (licenseCheckInFlight) return;
      licenseCheckInFlight = true;
      if (licenseAutoRefreshTimer) {
        clearTimeout(licenseAutoRefreshTimer);
        licenseAutoRefreshTimer = null;
      }
      $("licenseRefreshBtn").disabled = true;
      if (!options.auto) $("licenseRequestState").textContent = "正在检查授权和公司网络...";
      try {
        const result = await fetchJson("/api/license/diagnostics");
        if (!result.ok) throw new Error(result.error || "授权检查失败。");
        latestLicenseDiagnostics = result.diagnostics || null;
        renderLicenseDiagnostics(latestLicenseDiagnostics);
      } catch (error) {
        licenseAllowed = false;
        $("licensePanel").className = "license-panel is-open";
        $("licenseMainText").textContent = "授权检查失败";
        $("licenseDns").textContent = "-";
        $("licenseService").textContent = error?.message || String(error);
        $("licenseDevice").textContent = "-";
        $("licenseAdvice").textContent = "请确认已连接公司网络后重新检查。";
        $("licenseRequestBtn").disabled = true;
        $("licenseCopyDeviceBtn").disabled = true;
      } finally {
        licenseCheckInFlight = false;
        $("licenseRefreshBtn").disabled = false;
        setButtons(latestStatus?.status || "ready");
        scheduleLicenseAutoRefresh();
      }
    }

    function scheduleLicenseAutoRefresh() {
      if (licenseAllowed || licenseAutoRefreshTimer) return;
      licenseAutoRefreshTimer = setTimeout(() => {
        licenseAutoRefreshTimer = null;
        refreshLicenseDiagnostics({ auto: true }).catch(() => {});
      }, 5000);
    }

    function renderLicenseDiagnostics(diagnostics) {
      const license = diagnostics?.license || {};
      licenseAllowed = license.allowed === true;
      $("licensePanel").className = licenseAllowed ? "license-panel is-open authorized" : "license-panel is-open";
      $("licenseMainText").textContent = licenseAllowed ? "授权通过" : (license.message || "当前设备未授权");
      $("licenseDns").textContent = diagnostics?.dns?.message || "-";
      $("licenseService").textContent = diagnostics?.service?.message || "-";
      $("licenseDevice").textContent = diagnostics?.deviceId || "-";
      const canRequest = Boolean(diagnostics?.deviceId && diagnostics?.dns?.ok && diagnostics?.service?.ok && !licenseAllowed);
      $("licenseRequestBtn").disabled = !canRequest;
      $("licenseCopyDeviceBtn").disabled = !diagnostics?.deviceId;
      $("licenseAdvice").textContent = licenseAllowed
        ? "可以正常使用。"
        : canRequest
          ? "点击申请授权，管理员在总控页面通过后，再点重新检查。"
          : "请先处理 DNS、公司网络或设备号读取问题。";
      $("licenseRequestState").textContent = licenseAllowed ? "这台电脑已在授权名单中。" : "未授权时可以提交申请，由管理员在总控页面审批。";
    }

    async function requestLicenseAccess() {
      $("licenseRequestBtn").disabled = true;
      $("licenseRequestState").textContent = "正在提交授权申请...";
      try {
        const result = await postJson("/api/license/request", {});
        if (!result.ok || !result.request?.ok) throw new Error(result.request?.message || result.error || "申请提交失败。");
        $("licenseRequestState").textContent = result.request.message || "申请已提交，请等待管理员审批。";
        if (result.request.deviceId) {
          latestLicenseDiagnostics = { ...(latestLicenseDiagnostics || {}), deviceId: result.request.deviceId };
          $("licenseDevice").textContent = result.request.deviceId;
        }
      } catch (error) {
        $("licenseRequestState").textContent = "申请失败：" + (error?.message || error);
      } finally {
        await refreshLicenseDiagnostics();
      }
    }

    async function copyLicenseDeviceId() {
      const deviceId = latestLicenseDiagnostics?.deviceId || $("licenseDevice").textContent;
      if (!deviceId || deviceId === "-") return;
      try {
        await navigator.clipboard.writeText(deviceId);
        $("licenseRequestState").textContent = "设备号已复制。";
      } catch {
        $("licenseRequestState").textContent = "复制失败，可以手动选中设备号复制。";
      }
    }

    async function refreshVersionStatus(options = {}) {
      $("versionState").textContent = options.startup ? "正在自动检查更新..." : "正在检查更新...";
      $("versionRefreshBtn").disabled = true;
      try {
        const [versionResult, licenseResult] = await Promise.all([
          fetchJson("/api/version/status"),
          fetchJson("/api/license/status")
        ]);
        if (!versionResult.ok) {
          throw new Error(versionResult.error || "检查失败，可稍后重试。");
        }
        const v = versionResult.version || {};
        const license = licenseResult.license || {};
        renderVersionStatus(v, license, options);
      } catch (error) {
        $("versionMainState").textContent = "检查失败，可稍后重试";
        $("versionMainState").className = "version-main-state failed";
        $("versionUpdateHint").textContent = "没有完成更新检查，不会影响当前使用。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
        $("versionState").textContent = "检查失败，可稍后重试：" + (error?.message || error);
      } finally {
        $("versionRefreshBtn").disabled = false;
      }
    }

    function renderVersionStatus(v, license, options = {}) {
      licenseAllowed = license.allowed === true;
      const current = v.currentDisplayVersion || v.currentVersion || "-";
      const latest = v.latestRemoteDisplayVersion || v.latestRemoteVersion || "";
      $("versionNumber").textContent = current;
      if (v.updateAvailable) {
        $("versionMainState").textContent = "发现新版本：" + latest;
        $("versionMainState").className = "version-main-state has-update";
        $("versionUpdateHint").textContent = "发现新版本 " + latest + "，建议更新。更新前会自动备份当前版本。";
        $("versionUpdateBtn").dataset.updateAvailable = "1";
        $("versionUpdateBtn").disabled = false;
        if (!versionNoticeDismissed) {
          $("versionNoticeText").textContent = "发现新版本 " + latest + "，可前往版本更新。";
          $("versionNotice").classList.add("is-open");
        }
      } else {
        $("versionMainState").textContent = "已是最新版本";
        $("versionMainState").className = "version-main-state";
        $("versionUpdateHint").textContent = "当前已是最新版本。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
      }
      $("versionCommit").textContent = v.currentCommit || "-";
      $("versionProjectDir").textContent = v.projectDir || "-";
      $("versionRemote").textContent = v.hasUpdateSource ? ("补丁源：" + (v.updateSourceUrl || "已配置")) : (v.hasGitRemote ? (v.remoteUrl || "已连接") : "未连接");
      $("versionLocalChanges").textContent = v.hasLocalChanges ? "有本地修改" : "干净";
      $("versionLatestBackup").textContent = v.latestBackup ? v.latestBackup.path : "-";
      $("versionStableTag").textContent = v.latestStableTag || "-";
      $("licenseStatus").textContent = license.message || "-";
      $("versionState").textContent = options.startup ? "已自动检查更新。" : "检查更新完成。";
      setButtons(latestStatus?.status || "ready");
    }

    async function runVersionAction(action) {
      const prompts = {
        backup: "确认创建当前稳定备份？",
        update: "更新前会自动备份当前版本，是否继续？",
        rollback: "回退前会自动备份当前版本，是否继续？",
        "open-backup-dir": ""
      };
      const endpoints = {
        backup: "/api/version/backup",
        update: "/api/version/update",
        rollback: "/api/version/rollback",
        "open-backup-dir": "/api/version/open-backup-dir"
      };
      if (prompts[action] && !confirm(prompts[action])) return;
      setVersionButtons(true);
      $("versionState").textContent = action === "open-backup-dir" ? "正在打开备份目录。" : "正在执行版本操作，请等待。";
      try {
        const result = await postJson(endpoints[action], {});
        if (!result.ok) throw new Error(result.error || "版本操作失败。");
        $("versionState").textContent = result.message || result.result?.backupPath || "版本操作完成。";
        await refreshVersionStatus();
      } catch (error) {
        $("versionState").textContent = "版本操作失败：" + (error?.message || error);
      } finally {
        setVersionButtons(false);
      }
    }

    function setVersionButtons(disabled) {
      for (const id of ["versionRefreshBtn","versionBackupBtn","versionUpdateBtn","versionRollbackBtn","versionOpenBackupBtn"]) {
        if (id === "versionUpdateBtn" && !disabled) {
          $(id).disabled = $(id).dataset.updateAvailable !== "1";
        } else {
          $(id).disabled = disabled;
        }
      }
    }

    function currentClockText() {
      return new Date().toLocaleTimeString("zh-CN", { hour12: false });
    }

    function labelStatus(status) {
      if (status === "running") return "运行中";
      if (status === "paused") return "已暂停";
      if (status === "stopped") return "已停止";
      if (status === "waiting") return "等待人工确认";
      if (status === "completed") return "完成";
      if (status === "failed") return "失败";
      if (status === "disconnected") return "后台断开";
      return "就绪";
    }

    function setButtons(status) {
      const busy = status === "running" || status === "paused";
      $("generateBtn").disabled = busy || !controlledBrowserReady || !licenseAllowed;
      const completed = latestStatus && latestStatus.status === "completed";
      $("startCmsBtn").disabled = completed || busy || !controlledBrowserReady || !licenseAllowed;
      $("nextRunBtn").disabled = busy || !controlledBrowserReady;
      $("discardBtn").disabled = busy || !controlledBrowserReady;
      if ($("robotRecoveryPanel")?.classList.contains("is-open")) {
        $("robotDirectCreateBtn").disabled = busy || !controlledBrowserReady || !licenseAllowed;
        $("robotDirectCreateMode").disabled = busy || !controlledBrowserReady || !licenseAllowed;
        $("robotRetryMoreBtn").disabled = busy || !controlledBrowserReady || !licenseAllowed;
      }
      $("pauseBtn").disabled = status !== "running";
      $("resumeBtn").disabled = status !== "paused";
      $("stopBtn").disabled = !busy;
    }

    function bindCardGroup(name, selectId) {
      for (const radio of document.querySelectorAll("input[name='" + name + "']")) {
        radio.addEventListener("change", () => {
          if (radio.checked) $(selectId).value = radio.value;
          if (selectId === "rangeMode") isolateRangeModeFields(radio.value);
          if (selectId === "rangeMode") updateRangeVisibility();
          if (selectId === "robotNotInGroupPolicy") updateRobotNotInGroupVisibility();
          if (selectId === "scheduleMode") updateScheduleModeVisibility();
        });
      }
    }

    function syncCardGroups() {
      syncCardGroup("robotStrategyChoice", "robotStrategy");
      syncCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
      syncCardGroup("rangeModeChoice", "rangeMode");
      syncCardGroup("scheduleModeChoice", "scheduleMode");
      updateRangeVisibility();
      updateRobotNotInGroupVisibility();
      updateScheduleModeVisibility();
    }

    function syncCardGroup(name, selectId) {
      const value = $(selectId)?.value || "";
      const radio = document.querySelector("input[name='" + name + "'][value='" + value + "']");
      if (radio) radio.checked = true;
    }

    function updateRangeVisibility() {
      const mode = $("rangeMode").value;
      const full = mode === "full";
      const heading = mode === "heading";
      $("rangeInputs").style.display = mode === "range" ? "grid" : "none";
      $("headingRangeInputs").style.display = heading ? "grid" : "none";
      $("rangeHint").textContent = full
        ? "本次读取：全文。不会显示开始位置/结束位置，也不会使用节奏标题。"
        : heading
          ? "本次读取：按节奏/天数选择。识别标题结构时只读取左侧目录；生成预览时才读取正文和素材。"
          : "本次选择指定范围：按当前填写的开始位置和结束位置读取；结束位置为空表示读到文档末尾。";
    }

    function isolateRangeModeFields(mode) {
      if (mode === "full") {
        $("startKeyword").value = "";
        $("endKeyword").value = "";
        headingStructure = null;
        resetHeadingStructureOptions("请先读取标题结构");
      } else if (mode === "range") {
        headingStructure = null;
        resetHeadingStructureOptions("请先读取标题结构");
      } else if (mode === "heading") {
        $("startKeyword").value = "";
        $("endKeyword").value = "";
      }
    }

    function updateRobotNotInGroupVisibility() {
      const switchRobot = $("robotNotInGroupPolicy").value === "switch_robot";
      $("robotNotInGroupRetryConfig").style.display = switchRobot ? "grid" : "none";
      $("robotNotInGroupHint").style.display = switchRobot ? "block" : "none";
      $("robotNotInGroupHint").textContent = "连续 " + ($("robotNotInGroupMaxRetries").value || "3") + " 次仍不在群，就停止当前批次并提示人工处理。";
    }

    function updateScheduleModeVisibility() {
      const mode = $("scheduleMode").value;
      const isDoc = mode === "doc";
      const isRealtime = mode === "realtime";
      const isCatchup = mode === "catchup";
      $("timeFields").style.display = "grid";
      $("customIntervals").style.display = isDoc ? "none" : "block";
      $("intervalDefaultHint").style.display = isDoc ? "none" : "block";
      $("realtimeStartField").style.display = isRealtime ? "grid" : "none";
      $("realtimeEndField").style.display = isRealtime ? "grid" : "none";
      $("catchupStartField").style.display = isCatchup ? "grid" : "none";
      $("dateField").style.display = "grid";
      if (isDoc) {
        $("timeModeHint").textContent = "文档时间：只取文档里的时分秒；日期使用本轮基础发单日期，除非遇到换天标题。预览顺序可以按互动逻辑调整，但每条时间不能改。";
      } else if (isRealtime) {
        $("timeModeHint").textContent = "实时跟发：按开始时间重新生成发送时间；结束时间可留空。设置结束时间后，生成时间不能超过结束时间，超过会停止生成预览。";
      } else {
        $("timeModeHint").textContent = "补发到文档时间：过期内容从开始时间补发，后面能接回文档原时间时就回到文档时间，不会把后面所有时间重新顺一遍。";
      }
    }

    const visibleIntervalFields = ["differentTuoMin","differentTuoMax","sameTuoMin","sameTuoMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"];
    const intervalPresetGroups = [
      ["不同托", "differentTuoMin", "differentTuoMax"],
      ["同托", "sameTuoMin", "sameTuoMax"],
      ["豆妈连续", "doumaSameMin", "doumaSameMax"],
      ["豆妈托切换", "roleSwitchMin", "roleSwitchMax"]
    ];

    async function loadIntervalPresets(selectedId = "") {
      const result = await fetchJson("/api/interval-presets");
      intervalPresets = Array.isArray(result.presets) ? result.presets : [];
      renderIntervalPresetOptions(selectedId);
    }

    function renderIntervalPresetOptions(selectedId = "") {
      const select = $("intervalPresetSelect");
      if (!select) return;
      select.innerHTML = "";
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = intervalPresets.length ? "选择已保存方案" : "暂无已保存方案";
      select.appendChild(placeholder);
      for (const preset of intervalPresets) {
        const option = document.createElement("option");
        option.value = preset.id;
        option.textContent = preset.name || "未命名方案";
        select.appendChild(option);
      }
      select.value = selectedId && intervalPresets.some((item) => item.id === selectedId) ? selectedId : "";
      renderIntervalPresetList();
    }

    function renderIntervalPresetList() {
      const list = $("intervalPresetList");
      if (!list) return;
      list.innerHTML = "";
      if (!intervalPresets.length) {
        const empty = document.createElement("div");
        empty.className = "interval-preset-empty";
        empty.textContent = "暂无已保存方案。先填写上面的间隔，再点“保存当前为方案”。";
        list.appendChild(empty);
        return;
      }
      for (const preset of intervalPresets) {
        const row = document.createElement("div");
        row.className = "interval-preset-row";

        const nameInput = document.createElement("input");
        nameInput.value = preset.name || "";
        nameInput.placeholder = "方案名称";
        nameInput.dataset.presetId = preset.id;

        const summary = document.createElement("div");
        summary.className = "interval-preset-summary";
        summary.textContent = intervalPresetSummary(preset.intervals || {});

        const actions = document.createElement("div");
        actions.className = "interval-preset-actions";

        const renameBtn = document.createElement("button");
        renameBtn.type = "button";
        renameBtn.textContent = "保存名称";
        renameBtn.addEventListener("click", () => renameIntervalPreset(preset.id, nameInput.value));

        const updateBtn = document.createElement("button");
        updateBtn.type = "button";
        updateBtn.textContent = "更新为当前填写";
        updateBtn.addEventListener("click", () => updateIntervalPresetFromCurrent(preset.id, nameInput.value));

        const deleteBtn = document.createElement("button");
        deleteBtn.type = "button";
        deleteBtn.className = "outline-danger";
        deleteBtn.textContent = "删除";
        deleteBtn.addEventListener("click", () => deleteIntervalPresetById(preset.id));

        actions.append(renameBtn, updateBtn, deleteBtn);
        row.append(nameInput, summary, actions);
        list.appendChild(row);
      }
    }

    function intervalPresetSummary(intervals) {
      return intervalPresetGroups
        .map(([label, minKey, maxKey]) => {
          const min = intervals[minKey];
          const max = intervals[maxKey];
          return String(min ?? "").trim() && String(max ?? "").trim() ? label + " " + min + "-" + max + "秒" : "";
        })
        .filter(Boolean)
        .join("；") || "未填写间隔";
    }

    function toggleIntervalPresetPanel() {
      const panel = $("intervalPresetPanel");
      panel.classList.toggle("is-open");
      if (panel.classList.contains("is-open")) renderIntervalPresetList();
    }

    function readVisibleIntervalValues() {
      const values = {};
      for (const key of visibleIntervalFields) values[key] = $(key)?.value || "";
      values.mediaMin = "";
      values.mediaMax = "";
      return values;
    }

    function hasVisibleIntervalValues(values) {
      return visibleIntervalFields.some((key) => String(values[key] || "").trim() !== "");
    }

    function defaultIntervalPresetName(values) {
      const filled = intervalPresetGroups
        .map(([label, minKey, maxKey]) => ({ label, min: values[minKey], max: values[maxKey] }))
        .filter((item) => String(item.min || "").trim() && String(item.max || "").trim());
      if (filled.length === 1) return filled[0].label + " " + filled[0].min + "-" + filled[0].max + "秒";
      if (filled.length > 1 && filled.every((item) => item.min === filled[0].min && item.max === filled[0].max)) {
        return "统一间隔 " + filled[0].min + "-" + filled[0].max + "秒";
      }
      const now = new Date();
      const pad = (value) => String(value).padStart(2, "0");
      return "间隔方案 " + pad(now.getMonth() + 1) + "-" + pad(now.getDate()) + " " + pad(now.getHours()) + ":" + pad(now.getMinutes());
    }

    function applySelectedIntervalPreset() {
      const id = $("intervalPresetSelect").value;
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "请先选择一个已保存的间隔方案。";
        return;
      }
      const intervals = preset.intervals || {};
      for (const key of visibleIntervalFields) {
        if ($(key)) $(key).value = intervals[key] === undefined ? "" : String(intervals[key] || "");
      }
      if ($("mediaMin")) $("mediaMin").value = "";
      if ($("mediaMax")) $("mediaMax").value = "";
      $("saveState").textContent = "已应用间隔方案：" + (preset.name || "未命名方案") + "。";
    }

    async function saveCurrentIntervalPreset() {
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      const intervals = readVisibleIntervalValues();
      if (!hasVisibleIntervalValues(intervals)) {
        $("saveState").textContent = "请先填写至少一组自定义间隔，再保存为方案。";
        return;
      }
      const defaultName = defaultIntervalPresetName(intervals);
      const name = prompt("方案名称", defaultName);
      if (name === null) return;
      try {
        const result = await postJson("/api/interval-presets/save", { preset: { name, intervals } });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(result.preset?.id || "");
        $("saveState").textContent = "已保存间隔方案：" + (result.preset?.name || name || defaultName) + "。";
      } catch (error) {
        $("saveState").textContent = "保存间隔方案失败：" + (error?.message || error);
      }
    }

    async function renameIntervalPreset(id, name) {
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "没有找到这个间隔方案。";
        return;
      }
      try {
        const result = await postJson("/api/interval-presets/save", {
          preset: { id, name, intervals: preset.intervals || {} }
        });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(id);
        $("saveState").textContent = "已保存方案名称。";
      } catch (error) {
        $("saveState").textContent = "保存方案名称失败：" + (error?.message || error);
      }
    }

    async function updateIntervalPresetFromCurrent(id, name) {
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      const intervals = readVisibleIntervalValues();
      if (!hasVisibleIntervalValues(intervals)) {
        $("saveState").textContent = "请先填写至少一组自定义间隔，再更新方案。";
        return;
      }
      try {
        const result = await postJson("/api/interval-presets/save", {
          preset: { id, name, intervals }
        });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(id);
        $("saveState").textContent = "已用当前填写更新方案：" + (result.preset?.name || name || "未命名方案") + "。";
      } catch (error) {
        $("saveState").textContent = "更新间隔方案失败：" + (error?.message || error);
      }
    }

    async function deleteIntervalPresetById(id) {
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "没有找到这个间隔方案。";
        return;
      }
      if (!confirm("确认删除间隔方案“" + (preset.name || "未命名方案") + "”？当前输入框内容不会被清空。")) return;
      try {
        const result = await postJson("/api/interval-presets/delete", { id });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions();
        $("saveState").textContent = "已删除间隔方案。";
      } catch (error) {
        $("saveState").textContent = "删除间隔方案失败：" + (error?.message || error);
      }
    }

    function clearCustomIntervals() {
      for (const key of ["sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"]) {
        if ($(key)) $(key).value = "";
      }
      $("saveState").textContent = "已清空，将使用默认间隔规则";
    }

    function validateIntervalInputs() {
      if ($("scheduleMode").value === "doc") return "";
      const groups = [
        ["differentTuoMin", "differentTuoMax"],
        ["sameTuoMin", "sameTuoMax"],
        ["doumaSameMin", "doumaSameMax"],
        ["roleSwitchMin", "roleSwitchMax"]
      ];
      for (const [minId, maxId] of groups) {
        const min = String($(minId)?.value || "").trim();
        const max = String($(maxId)?.value || "").trim();
        if (!min && !max) continue;
        if (!min || !max) return "自定义间隔的最短和最长要么都填，要么都不填。";
        if (!/^\\d+$/.test(min) || !/^\\d+$/.test(max) || Number(min) <= 0 || Number(max) <= 0) return "自定义间隔只能填写正整数秒数。";
        if (Number(min) > Number(max)) return "自定义间隔的最短不能大于最长。";
      }
      return "";
    }

    async function sendControl(action) {
      await postJson("/api/control", { action });
      await refreshStatus();
    }

    async function fetchJson(url) {
      const response = await fetch(url);
      if (!response.ok) throw new Error("后台接口返回失败：" + response.status);
      return response.json();
    }

    async function postJson(url, body) {
      const response = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!response.ok) throw new Error("后台接口返回失败：" + response.status);
      return response.json();
    }
  </script>
</body>
</html>`;
}

async function readJsonBody(req) {
  let body = "";
  for await (const chunk of req) body += chunk;
  if (!body.trim()) return {};
  return JSON.parse(body);
}

function isWorkflowBusy(state) {
  const status = state.snapshot().status;
  return status === "running" || status === "paused";
}

function resetTerminalConsoleStateOnOpen(state) {
  const status = state.snapshot().status;
  if (!["failed", "stopped", "disconnected"].includes(status)) return false;
  state.resetTerminalState?.("重新打开控制台：已清理上次失败/停止状态");
  return true;
}

function sendWorkflowBusy(res, state) {
  sendJson(res, 409, {
    ok: false,
    error: "已有流程正在运行，请等当前流程结束。",
    state: state.snapshot()
  });
}

function backupOptions(body = {}) {
  return {
    name: body.name,
    backupRoot: body.backupRoot
  };
}

function versionActionOptions(body = {}) {
  return {
    ...backupOptions(body),
    backupName: body.backupName,
    installCommand: body.installCommand,
    installArgs: body.installArgs,
    checkCommand: body.checkCommand,
    checkArgs: body.checkArgs
  };
}

function pickLicenseOptions(options = {}) {
  return {
    fetch: options.licenseFetch,
    licenseConfig: options.licenseConfig,
    appVersion: options.appVersion
  };
}

function scheduleConsoleRestart(projectRoot, closeServer) {
  setTimeout(() => {
    const scriptPath = path.join(projectRoot, "src", "v2", "tools", "launch-console-hidden.ps1");
    const child = spawn("powershell.exe", [
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      scriptPath,
      "-ProjectRoot",
      projectRoot
    ], {
      cwd: projectRoot,
      detached: true,
      stdio: "ignore",
      windowsHide: true
    });
    child.unref();
    closeServer().catch(() => {});
  }, 500);
}

function sendJson(res, status, data) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function sendHtml(res, html) {
  res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  res.end(html);
}

async function openControlledConsole(projectRoot, url) {
  const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
  await ensureV2ControlledBrowser({ projectRoot, config, url });
}

function withControlledFlag(url) {
  const parsed = new URL(url);
  parsed.searchParams.set("controlled", "1");
  return parsed.toString();
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function buildConsoleServiceInfo(projectRoot) {
  return {
    protocol: "v2-console-service-v2-license",
    projectRoot: path.resolve(projectRoot),
    codeRevision: await readGitRevision(projectRoot),
    startedAt: new Date().toISOString()
  };
}

async function readGitRevision(projectRoot) {
  try {
    const gitDir = path.join(projectRoot, ".git");
    const head = String(await fs.readFile(path.join(gitDir, "HEAD"), "utf8")).trim();
    if (head.startsWith("ref:")) {
      const refPath = head.slice(5).trim().replace(/\//g, path.sep);
      return String(await fs.readFile(path.join(gitDir, refPath), "utf8")).trim();
    }
    return head;
  } catch {
    return "";
  }
}

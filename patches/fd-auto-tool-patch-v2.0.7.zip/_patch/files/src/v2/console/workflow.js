import fs from "node:fs/promises";
import path from "node:path";
import { assertCompanyAccessAllowed } from "../license/license-manager.js";
import { collectRawEventsFromPageWithDiagnostics, materializeRawEventMediaFromPage, summarizeRawEvents, validateCollectedRawEvents } from "../feishu/collector.js";
import { collectError, isFeishuCollectError } from "../feishu/collect-errors.js";
import { closeFeishuCollectPage, normalizeFeishuUrl, openRealFeishuCollectPage } from "../feishu/page-controller.js";
import { normalizeSendDate, todayMonthDay } from "../date/date-rules.js";
import { locateRange } from "../range/locate-range.js";
import { isRangeLocateError } from "../range/range-errors.js";
import {
  buildHeadingStructure,
  collectHeadingStructureFromPage,
  locateHeadingRange,
  resolveHeadingSelection
} from "../range/heading-range.js";
import { parseFixedFormatTasks } from "../parser/parse-fixed-format.js";
import { validatePreviewTaskShape } from "../contracts/preview-task.js";
import { buildPreviewScheduleOptions, preparePreviewTasksForGeneration } from "../time/schedule-preview-tasks.js";
import { createPreviewTestServer } from "../preview/preview-page.js";
import { finalPreviewPath, findLatestV2RealFlowRun, loadPreviewForOpen, previewTasksPath } from "../preview/preview-store.js";
import { openRealCmsCreatePages } from "../cms/real-cms-adapter.js";
import {
  clearCmsPageBindings,
  createCmsPageBindingsForRun,
  runIdFromRunDir,
  runRealCmsCli
} from "../tools/run-real-cms-cli.js";
import { collectGenerateOptions, cmsRunOptions, normalizeConsoleSettings } from "./settings.js";
import { createWorkflowControl } from "./state.js";
import {
  ensureV2ControlledBrowser,
  inspectControlledPages,
  loadV2ControlledBrowserState,
  openOrFocusConsolePage,
  openOrFocusControlledPage,
  openOrReplaceControlledPage
} from "../browser/controlled-browser.js";

const DEFAULT_CMS_URL = "https://cms.iyunzk.com/wx/FenWei_rw";

export function createConsoleWorkflow({ projectRoot, state, licenseFetch, licenseOptions: injectedLicenseOptions }) {
  const licenseOptions = injectedLicenseOptions || (licenseFetch ? { fetch: licenseFetch } : {});
  let previewServer = null;
  let running = null;
  let consoleUrl = "";
  let currentSettings = {};
  let preparedCmsPages = null;

  async function generatePreview(settings = {}) {
    await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    running = runGeneratePreview(settings).finally(() => {
      running = null;
    });
    return running;
  }

  async function startCms(settings = {}) {
    await assertCompanyAccessAllowed(projectRoot, "start-cms", licenseOptions);
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    running = runCms(settings).finally(() => {
      running = null;
    });
    return running;
  }

  async function prepareCms(settings = {}) {
    await assertCompanyAccessAllowed(projectRoot, "prepare-cms", licenseOptions);
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    running = runPrepareCms(settings).finally(() => {
      running = null;
    });
    return running;
  }

  async function readFeishuTitle(feishuUrl) {
    if (running) {
      return { ok: false, statusCode: 409, error: "已有流程正在运行，请等当前流程结束后再读取标题。" };
    }
    const url = normalizeFeishuUrl(feishuUrl);
    if (!url) {
      return { ok: false, statusCode: 400, error: "链接格式可能不正确，请检查。" };
    }
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const controlledBrowser = await loadControlledBrowserState(projectRoot, config);
    if (!controlledBrowser.cdpUrl) {
      return { ok: false, statusCode: 409, error: "当前不是 2.0 专用可控浏览器，请从正式入口启动后再读取标题。" };
    }
    let opened;
    try {
      opened = await openRealFeishuCollectPage({
        url,
        cdpUrl: controlledBrowser.cdpUrl,
        headless: false,
        timeoutMs: 30000
      });
      const title = opened.title || "";
      state.log(`飞书链接标题读取：${url}；标题=${title || "未读取到标题"}`);
      return { ok: true, feishuUrl: url, title };
    } finally {
      await closeOpenedFeishuPage(opened, state);
    }
  }

  async function readHeadingStructure(feishuUrl) {
    if (running) {
      return { ok: false, statusCode: 409, error: "已有流程正在运行，请等当前流程结束后再识别标题结构。" };
    }
    const url = normalizeFeishuUrl(feishuUrl);
    if (!url) {
      return { ok: false, statusCode: 400, error: "链接格式可能不正确，请检查。" };
    }
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const controlledBrowser = await loadControlledBrowserState(projectRoot, config);
    if (!controlledBrowser.cdpUrl) {
      return { ok: false, statusCode: 409, error: "当前不是 2.0 专用可控浏览器，请从正式入口启动后再识别标题结构。" };
    }
    let opened;
    try {
      opened = await openRealFeishuCollectPage({
        url,
        cdpUrl: controlledBrowser.cdpUrl,
        headless: false,
        focusBody: false,
        timeoutMs: 30000
      });
      const structure = await collectHeadingStructureFromPage(opened.page);
      state.update({ feishuUrl: url, feishuTitle: opened.title || "", feishuTitleUrl: url });
      state.log(`识别标题结构：只读取飞书左侧目录；当前飞书链接=${url}；标题数=${structure.headings.length}`);
      return { ok: true, feishuUrl: url, title: opened.title || "", structure };
    } finally {
      await closeOpenedFeishuPage(opened, state);
    }
  }

  async function previewHasUnsavedChanges() {
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const controlledBrowser = await loadControlledBrowserState(projectRoot, config);
    if (!controlledBrowser.cdpUrl) return false;
    const pages = await inspectControlledPages(controlledBrowser.cdpUrl, {
      titleIncludes: "妙券自动发单 - 预览确认",
      onlyLocalhost: true,
      includeDirty: true
    }).catch(() => []);
    return pages.some((page) => page.previewDirty);
  }

  async function getRestorablePreview() {
    const runDir = await findRestorablePreviewRun();
    if (!runDir) return { available: false };
    const previewPath = finalPreviewPath(runDir);
    const tasks = await readJsonIfExists(previewPath);
    const stat = await fs.stat(previewPath).catch(() => null);
    return {
      available: true,
      runDir,
      runName: path.basename(runDir),
      previewPath,
      taskCount: Array.isArray(tasks) ? tasks.length : 0,
      modifiedAt: stat ? stat.mtime.toISOString() : ""
    };
  }

  async function restoreLatestPreview(settings = {}) {
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    const candidate = await getRestorablePreview();
    if (!candidate.available) return { ok: false, error: "没有找到可以恢复的上次预览。" };
    const normalized = normalizeConsoleSettings(settings);
    currentSettings = normalized;
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const defaultDate = normalizeSendDate(normalized.date || "") || todayMonthDay();
    await previewServer?.close?.().catch(() => {});
    previewServer = await createPreviewServerForRun(candidate.runDir, {
      config,
      defaultDate,
      reason: "已恢复上次预览，等待确认发单"
    });
    state.update({
      step: "等待预览确认",
      status: "waiting",
      runDir: candidate.runDir,
      previewPath: candidate.previewPath,
      previewUrl: previewServer.url,
      totalCount: candidate.taskCount,
      waitingReason: "已恢复上次预览，请在预览页检查、修改并保存 preview.json"
    });
    state.log(`已恢复上次预览：${candidate.previewPath}`);
    state.log(`预览页：${previewServer.url}`);
    await openControlledPreviewPage(projectRoot, config, withPreviewRunParams(previewServer.url, candidate.runDir));
    return {
      ok: true,
      runDir: candidate.runDir,
      previewPath: candidate.previewPath,
      previewUrl: previewServer.url,
      taskCount: candidate.taskCount
    };
  }

  async function runGeneratePreview(settings) {
    const normalized = normalizeConsoleSettings(settings);
    const previousFeishuUrl = normalizeFeishuUrl(settings.previousFeishuUrl || "");
    currentSettings = normalized;
    const runsRoot = path.join(projectRoot, "runs");
    const runName = `v2_real_flow_${timestamp()}`;
    const runDir = path.join(runsRoot, runName);
    let opened;
    preparedCmsPages = null;
    state.resetForRun("采集飞书");
    state.update({ runDir, previewPath: "", previewUrl: "" });

    try {
      await fs.mkdir(runDir, { recursive: true });
      await clearCmsPageBindings(runDir);
      state.log(`run 目录：${runDir}`);

      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const controlledBrowser = await loadControlledBrowserState(projectRoot, config);
      if (!controlledBrowser.cdpUrl) {
        throw new Error("当前没有检测到 2.0 专用可控浏览器/CDP。请从“2.0可视化控制台”正式入口重新启动。");
      }
      const options = collectGenerateOptions(normalized);
      const url = normalizeFeishuUrl(options.url || config.feishuUrl);
      if (!url) throw new Error("缺少飞书文档链接。");
      const linkChanged = Boolean(previousFeishuUrl && previousFeishuUrl !== url);
      state.log(`本次使用的飞书链接：${url}`);
      state.log(`飞书链接是否和上次不同：${linkChanged ? "是" : "否"}`);
      if (normalized.rangeMode === "range" && !options.startKeyword) {
        throw new Error("指定范围模式必须填写开始位置。");
      }
      if (normalized.rangeMode === "heading" && !options.headingDay) {
        throw new Error("按节奏/天数选择模式必须先选择第几天。");
      }
      const baseSendDate = resolveBaseSendDate(normalized.date);
      state.log(formatRangeLog(normalized));
      state.log(`本轮基础发单日期：${baseSendDate}${normalized.date ? "" : "（控制台未填写日期，默认今天）"}`);

      state.update({ step: "采集飞书", waitingReason: normalized.rangeMode === "heading" ? "正在打开飞书并按目录标题确定读取范围" : "正在打开飞书文档并滚动采集" });
      opened = await openRealFeishuCollectPage({
        url,
        cdpUrl: controlledBrowser.cdpUrl,
        headless: false,
        timeoutMs: 30000
      });
      await opened.page.waitForTimeout(2500).catch(() => {});
      state.update({ feishuUrl: url, feishuTitle: opened.title || normalized.feishuTitle || "", feishuTitleUrl: url });
      state.log(`读取到的文档标题：${opened.title || normalized.feishuTitle || "未读取到标题"}`);

      const headingRange = normalized.rangeMode === "heading"
        ? await resolveHeadingRangeFromPage(opened.page, normalized, state)
        : null;
      const collectStartKeyword = headingRange ? headingRange.startTitle : options.startKeyword;
      const collectEndKeyword = headingRange ? headingRange.endTitle : options.endKeyword;
      const collectEndAtDocumentEnd = headingRange ? !headingRange.endTitle : options.endAtDocumentEnd;

      const collectOptions = {
        scanFullPage: true,
        startKeyword: normalized.rangeMode === "full" ? "" : collectStartKeyword,
        endKeyword: normalized.rangeMode === "full" || collectEndAtDocumentEnd ? "" : collectEndKeyword,
        requireStartKeywordSearch: normalized.rangeMode === "range",
        requireDocumentEnd: normalized.rangeMode === "full",
        deferMediaMaterialization: true,
        maxSteps: normalized.rangeMode === "full" ? 240 : undefined,
        mediaCacheDir: path.join(runDir, "media-cache"),
        diagnosticsDir: path.join(runDir, "diagnostics")
      };
      let collected;
      try {
        collected = await collectRawEventsFromPageWithDiagnostics(opened.page, collectOptions);
      } catch (error) {
        if (!isClosedPageError(error)) throw error;
        state.log("飞书页面在采集时已关闭，重新打开当前飞书链接后重试一次；不会改成全文读取，也不会复用旧结果。");
        await closeOpenedFeishuPage(opened, state);
        opened = await openRealFeishuCollectPage({
          url,
          cdpUrl: controlledBrowser.cdpUrl,
          headless: false,
          timeoutMs: 30000
        });
        await opened.page.waitForTimeout(2500).catch(() => {});
        state.update({ feishuUrl: url, feishuTitle: opened.title || normalized.feishuTitle || "", feishuTitleUrl: url });
        state.log(`重新打开飞书文档：${url}；标题=${opened.title || normalized.feishuTitle || "未读取到标题"}`);
        collected = await collectRawEventsFromPageWithDiagnostics(opened.page, collectOptions);
      }
      await saveJson(path.join(runDir, "collect-diagnostics.json"), collected.diagnostics);
      appendSearchTraceLogs(state, collected.diagnostics);
      if (collected.diagnostics?.failure) {
        throw collectError("collect_failed", collected.diagnostics.failure);
      }
      const rawEvents = validateCollectedRawEvents(collected.events, {
        ...buildChecks(normalized),
        allowTemporaryMedia: true
      });
      if (normalized.rangeMode === "full") validateFullReadCompleteness(rawEvents, collected.diagnostics);
      await saveJson(path.join(runDir, "raw-events.json"), rawEvents);
      const rawSummary = summarizeRawEvents(rawEvents);
      state.log(`采集完成：${rawSummary.total} 条 raw-events；首条=${formatEventIdentity(rawSummary.firstEvent)}；末条=${formatEventIdentity(rawSummary.lastEvent)}`);

      state.update({ step: "范围解析", waitingReason: rangeWaitingReason(normalized.rangeMode) });
      state.log("进入范围解析");
      let rangeResult;
      try {
        rangeResult = rangeResultForMode(rawEvents, normalized, options, headingRange, baseSendDate);
      } catch (error) {
        if (normalized.rangeMode === "range" && isRangeLocateError(error)) {
          state.log(formatManualRangeFailureLog(normalized, error));
        }
        throw error;
      }
      if (normalized.rangeMode === "range") {
        state.log(formatManualRangeDiagnosticsLog(normalized, rangeResult.diagnostics));
      }
      state.update({ step: "素材落地", waitingReason: "按当前读取范围统一落地图片、表情包和视频素材" });
      const rangeEvents = validateCollectedRawEvents(await materializeRawEventMediaFromPage(opened.page, rangeResult.events, {
        mediaCacheDir: path.join(runDir, "media-cache"),
        onProgress: (progress) => {
          const message = formatMediaMaterializeProgress(progress);
          if (!message) return;
          state.update({ step: "素材落地", waitingReason: message });
          state.log(message);
        }
      }), {
        requireLocalMedia: true
      });
      await saveJson(path.join(runDir, "range-events.json"), rangeEvents);
      await saveJson(path.join(runDir, "range-diagnostics.json"), rangeResult.diagnostics);
      state.log(`范围解析完成：${rangeEvents.length} 条 events；范围内素材已统一落地到 media-cache`);

      state.update({ step: "生成 preview-tasks.json", waitingReason: "解析角色、互动托、时间模式" });
      const scheduleOptions = buildPreviewScheduleOptions(config, {
        ...options,
        phase: "generate-preview"
      });
      const parsed = parseFixedFormatTasks(rangeEvents, {
        scheduleMode: scheduleOptions.mode,
        baseSendDate
      });
      const prepared = preparePreviewTasksForGeneration(parsed.tasks, scheduleOptions);
      const previewTasks = applyDefaultDate(prepared.tasks, baseSendDate);
      for (const task of previewTasks) validatePreviewTaskShape(task);
      if (normalized.rangeMode === "full" && previewTasks.length <= 0) {
        throw new Error("全文读取没有解析出任何 preview-tasks，已停止。");
      }
      await saveJson(previewTasksPath(runDir), previewTasks);
      await saveJson(path.join(runDir, "console-generate-report.json"), {
        ok: true,
        runDir,
        documentTitle: opened.title || normalized.feishuTitle || "",
        documentUrl: url,
        previousDocumentUrl: previousFeishuUrl,
        documentUrlChanged: linkChanged,
        readRange: {
          mode: normalized.rangeMode,
          sourceMode: rangeSourceModeLabel(normalized.rangeMode),
          label: rangeReportLabel(normalized, headingRange),
          startKeyword: normalized.rangeMode === "full" ? "" : collectStartKeyword,
          endKeyword: normalized.rangeMode === "full" ? "" : collectEndKeyword,
          headingDay: normalized.rangeMode === "heading" ? normalized.headingDay : "",
          headingRhythm: normalized.rangeMode === "heading" ? normalized.headingRhythm : "",
          baseSendDate,
          documentEndConfirmed: Boolean(collected.diagnostics?.documentEndConfirmed)
        },
        rawEventCount: rawEvents.length,
        rangeEventCount: rangeEvents.length,
        previewTaskCount: previewTasks.length,
        firstTask: summarizePreviewIdentity(previewTasks[0]),
        lastTask: summarizePreviewIdentity(previewTasks.at(-1)),
        schedule: {
          mode: prepared.mode,
          interactionReordered: prepared.interactionReordered,
          diagnostics: [...parsed.diagnostics, ...prepared.diagnostics]
        },
        taskCount: previewTasks.length
      });
      state.update({ totalCount: previewTasks.length });
      state.log(`preview-tasks.json 已生成：${previewTasks.length} 条；首条=${formatTaskIdentity(previewTasks[0])}；末条=${formatTaskIdentity(previewTasks.at(-1))}`);

      state.update({ step: "生成 preview.json", waitingReason: "初始化人工确认文件" });
      const previewState = await loadPreviewForOpen(runDir, { regenerate: true, defaultDate: baseSendDate });
      const previewPath = finalPreviewPath(runDir);
      if (!await exists(previewTasksPath(runDir)) || !await exists(previewPath)) {
        throw new Error("新 run 目录缺少 preview-tasks.json 或 preview.json，已停止。");
      }
      await previewServer?.close?.().catch(() => {});
      previewServer = await createPreviewServerForRun(runDir, {
        config,
        defaultDate: baseSendDate,
        reason: "请在预览页检查、修改并保存 preview.json"
      });
      state.update({
        step: "等待预览确认",
        status: "waiting",
        previewPath,
        previewUrl: previewServer.url,
        waitingReason: "请在预览页检查、修改并保存 preview.json"
      });
      state.log(`preview.json 已生成：${previewPath}`);
      state.log(`preview.json 条目：${previewState.tasks.length} 条`);
      state.log(`预览页：${previewServer.url}`);
      await openControlledPreviewPage(projectRoot, config, withPreviewRunParams(previewServer.url, runDir));
      return {
        ok: true,
        runDir,
        previewPath,
        previewUrl: previewServer.url,
        source: previewState.source,
        taskCount: previewTasks.length
      };
    } catch (error) {
      await saveFlowError(runDir, state.snapshot().step || "生成预览", error);
      const files = await keyFiles(runDir);
      state.fail(state.snapshot().step || "生成预览", error?.message || String(error), {
        runDir,
        previewPath: "",
        previewUrl: "",
        missingFiles: missingKeyFiles(files)
      });
      return {
        ok: false,
        runDir,
        error: error?.message || String(error),
        files
      };
    } finally {
      await closeOpenedFeishuPage(opened, state);
    }
  }

  async function runPrepareCms(settings) {
    const normalized = normalizeConsoleSettings(settings);
    currentSettings = normalized;
    const runDir = String(settings.runDir || state.snapshot().runDir || "").trim();
    state.update({
      step: "CMS 准备",
      status: "running",
      runDir,
      previewPath: runDir ? finalPreviewPath(runDir) : "",
      waitingReason: "正在打开/切换云中客创建任务页面",
      failureStep: "",
      failureReason: ""
    });

    try {
      if (!runDir) throw new Error("没有当前 run 目录，请先生成并保存 preview.json。");
      await clearCmsPageBindings(runDir);
      preparedCmsPages = null;
      const files = await keyFiles(runDir);
      const missing = missingKeyFiles(files);
      if (missing.length) {
        throw new Error(`新 run 目录缺少关键文件：${missing.join("、")}。禁止打开旧 preview 或继续创建。`);
      }
      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const controlledBrowser = await loadControlledBrowserState(projectRoot, config);
      const cmsUrl = normalized.cmsUrl || config.cmsUrl || DEFAULT_CMS_URL;
      const cdpUrl = normalized.cdpUrl || controlledBrowser.cdpUrl;
      if (cdpUrl) {
        preparedCmsPages = await openRealCmsCreatePages({
          projectRoot,
          cmsUrl,
          cdpUrl,
          requireExistingCreatePage: false,
          forceFreshCreatePages: true,
          requiredRoles: ["tuo", "douma"],
          minCreatePages: 2,
          headless: false,
          timeoutMs: 30000
        });
        preparedCmsPages.runId = runIdFromRunDir(runDir);
        preparedCmsPages.bindingState = await createCmsPageBindingsForRun(runDir, pageInfosFromPreparedPages(preparedCmsPages.pages), ["tuo", "douma"], {
          source: "prepare-cms"
        });
        preparedCmsPages.shouldClose = false;
      } else {
        preparedCmsPages = null;
        if (settings.openBrowserFallback !== false) await openControlledBrowserPage(projectRoot, config, cmsUrl);
        state.update({
          step: "CMS 准备",
          status: "waiting",
          runDir,
          previewPath: finalPreviewPath(runDir),
          waitingReason: "已在当前浏览器打开/切到云中客页面。请手动确认分组、机器人和发送策略。"
        });
        state.log("CMS 准备：未检测到可控 CDP 浏览器，已禁止启动新的 browser profile。请在当前浏览器云中客标签页手动确认设置。");
        return {
          ok: true,
          runDir,
          previewPath: finalPreviewPath(runDir),
          cmsUrl,
          openInCurrentBrowser: settings.openBrowserFallback === false,
          cmsPageCount: 0,
          needsControlledBrowser: true
        };
      }
      const pages = preparedCmsPages.pages || [];
      for (const page of pages) {
        await page.bringToFront?.().catch(() => {});
        await page.waitForTimeout?.(250).catch(() => {});
      }
      await pages[0]?.bringToFront?.().catch(() => {});
      state.update({
        step: "CMS 准备",
        status: "waiting",
        runDir,
        previewPath: finalPreviewPath(runDir),
        waitingReason: "请在云中客页面手动确认分组、机器人和发送策略。确认完成后，回到控制台点击“我已设置好，开始创建”。"
      });
      state.log(`CMS 准备完成：已重建 ${pages.length} 个云中客创建任务页。当前 runId=${runIdFromRunDir(runDir)}；托页面、豆妈页面已固定标记，请手动确认分组、机器人、发送策略和任务备注。`);
      return {
        ok: true,
        runDir,
        previewPath: finalPreviewPath(runDir),
        cmsUrl,
        cmsPageCount: pages.length
      };
    } catch (error) {
      state.fail("CMS 准备", error?.message || String(error), {
        runDir,
        previewPath: runDir ? finalPreviewPath(runDir) : ""
      });
      return { ok: false, error: error?.message || String(error) };
    }
  }

  async function runCms(settings) {
    const normalized = normalizeConsoleSettings(settings);
    currentSettings = normalized;
    const runDir = String(settings.runDir || state.snapshot().runDir || "").trim();
    state.resetForRun("正式创建 CMS");
    state.update({
      runDir,
      previewPath: runDir ? finalPreviewPath(runDir) : "",
      failureStep: "",
      failureReason: ""
    });

    try {
      if (!runDir) throw new Error("没有当前 run 目录，请先生成并保存 preview.json。");
      const files = await keyFiles(runDir);
      const missing = missingKeyFiles(files);
      if (missing.length) {
        throw new Error(`新 run 目录缺少关键文件：${missing.join("、")}。禁止打开旧 preview 或继续创建。`);
      }
      const preview = await readJsonIfExists(finalPreviewPath(runDir));
      state.update({ waitingReason: "正在校验 CMS 页面配置、本地素材和创建计划，随后开始逐条创建。" });
      state.log("正式创建准备：正在校验 CMS 页面配置、本地素材和创建计划。");
      if (Array.isArray(preview)) state.update({ totalCount: preview.filter((task) => !task.skip).length });
      const options = cmsRunOptions(normalized);
      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const controlledBrowser = await loadControlledBrowserState(projectRoot, config);
      const cdpUrl = options.cdpUrl || controlledBrowser.cdpUrl;
      if (!cmsPagesAlive(preparedCmsPages) && !cdpUrl) {
        throw new Error("正式创建需要复用可控制的云中客页面，但当前没有检测到 2.0 受控浏览器/CDP 连接。已停止，且不会启动新的浏览器 profile。");
      }
      if (cmsPagesAlive(preparedCmsPages) && preparedCmsPages.runId && preparedCmsPages.runId !== runIdFromRunDir(runDir)) {
        throw new Error(`正式创建已停止：云中客页面绑定属于旧预览 runId=${preparedCmsPages.runId}，当前预览 runId=${runIdFromRunDir(runDir)}。请重新点击“确认无误进入云中客设置”。`);
      }
      const reusableCmsPages = cmsPagesAlive(preparedCmsPages) ? {
        ...preparedCmsPages,
        pages: preparedCmsPages.pages.filter((page) => !page.isClosed?.()),
        shouldClose: false
      } : null;
      const report = await runRealCmsCli({
        ...options,
        assumeYes: true,
        cdpUrl,
        noLaunchBrowser: true,
        runDir,
        projectRoot,
        preparedCmsPages: reusableCmsPages,
        control: createWorkflowControl(state)
      });
      const successCount = countSubmitted(report);
      state.update({
        step: "正式创建 CMS",
        status: "completed",
        successCount,
        failureCount: 0,
        waitingReason: "正式创建完成"
      });
      state.log("正式创建完成");
      state.log(report);
      return { ok: true, report };
    } catch (error) {
      state.fail("正式创建 CMS", error?.message || String(error), {
        runDir,
        previewPath: runDir ? finalPreviewPath(runDir) : ""
      });
      return { ok: false, error: error?.message || String(error) };
    }
  }

  return {
    generatePreview,
    readFeishuTitle,
    readHeadingStructure,
    prepareCms,
    startCms,
    previewHasUnsavedChanges,
    getRestorablePreview,
    restoreLatestPreview,
    isRunning() {
      return Boolean(running);
    },
    setConsoleUrl(url) {
      consoleUrl = String(url || "");
    },
    get previewServer() {
      return previewServer;
    },
    async close() {
      await previewServer?.close?.().catch(() => {});
      previewServer = null;
      await preparedCmsPages?.context?.close?.().catch(() => {});
      preparedCmsPages = null;
    }
  };

  async function createPreviewServerForRun(runDir, options = {}) {
    return createPreviewTestServer(runDir, {
      consoleUrl,
      defaultDate: options.defaultDate || "",
      onPreviewSaved: async ({ path: previewPath, tasks }) => {
        state.update({
          step: "等待预览确认",
          status: "waiting",
          runDir,
          previewPath,
          totalCount: Array.isArray(tasks) ? tasks.length : state.snapshot().totalCount,
          waitingReason: "预览已保存，等待确认发单"
        });
        state.log(`preview.json 已由预览页保存：${previewPath}`);
      },
      onRegeneratePreview: async () => {
        state.log("预览页请求：按控制台当前配置重新采集/解析/生成预览");
        const focusedConsole = await focusConsolePage(projectRoot, consoleUrl);
        setTimeout(() => {
          generatePreview(currentSettings).catch((error) => {
            state.fail("重新生成预览", error?.message || String(error));
          });
        }, 25);
        return { consoleUrl, focusedConsole };
      },
      onReturnSettings: async () => {
        state.update({
          step: "等待预览确认",
          status: "waiting",
          waitingReason: "用户返回控制台修改设置，本轮配置已保留"
        });
        state.log("预览页请求：返回修改设置");
        const focusedConsole = await focusConsolePage(projectRoot, consoleUrl);
        return { consoleUrl, focusedConsole };
      },
      onAbandon: async ({ runDir: abandonedRunDir }) => {
        state.update({
          step: "等待预览确认",
          status: "stopped",
          runDir: abandonedRunDir,
          waitingReason: "用户选择暂不发，已保存预览草稿，不执行正式发单"
        });
        state.log("预览页请求：暂不发，回到监控/控制台");
        const focusedConsole = await focusConsolePage(projectRoot, consoleUrl);
        return { consoleUrl, focusedConsole };
      },
      onPrepareCms: async ({ runDir: prepareRunDir }) => {
        const prepareConfig = await readJsonIfExists(path.join(projectRoot, "config.json"));
        const cmsUrl = currentSettings.cmsUrl || prepareConfig.cmsUrl || DEFAULT_CMS_URL;
        state.log("预览页请求：确认无误，进入云中客设置");
        setTimeout(() => {
          prepareCms({ ...currentSettings, runDir: prepareRunDir, openBrowserFallback: false }).catch((error) => {
            state.fail("CMS 准备", error?.message || String(error), {
              runDir: prepareRunDir,
              previewPath: finalPreviewPath(prepareRunDir)
            });
          });
        }, 25);
        return { consoleUrl, cmsUrl, openInCurrentBrowser: true };
      }
    });
  }

  async function findRestorablePreviewRun() {
    const runsRoot = path.join(projectRoot, "runs");
    const runDir = await findLatestV2RealFlowRun(runsRoot);
    if (!runDir || !await exists(finalPreviewPath(runDir))) return null;
    return runDir;
  }
}

function buildChecks(settings) {
  const checks = {};
  if (settings.rangeMode === "range" && settings.startKeyword) checks.startKeyword = settings.startKeyword;
  if (settings.rangeMode === "range" && settings.endKeyword) checks.endKeyword = settings.endKeyword;
  return checks;
}

function formatRangeLog(settings) {
  if (settings.rangeMode === "full") {
    return "本次读取范围：全文读取。当前 rangeMode=full；不会使用开始位置/结束位置，也不会使用 heading/rhythm/day/phase。";
  }
  if (settings.rangeMode === "heading") {
    return `本次读取范围：按节奏/天数选择。当前 rangeMode=heading/rhythm；选择的第几天=${settings.headingDay || "未选择"}；选择的节奏标题=${settings.headingRhythm || "整天"}；不会使用手动 start/end；识别标题结构只读目录，生成预览才读取正文和素材。`;
  }
  return `本次读取范围：指定开始/结束位置。当前 rangeMode=manual/start-end；start=${settings.startKeyword || "空"}；end=${settings.endKeyword || "空，读到文档末尾"}；本次禁止使用 heading/rhythm/day/phase 作为范围来源。`;
}

function rangeWaitingReason(mode) {
  if (mode === "full") return "全文读取，不截取范围";
  if (mode === "heading") return "按目录标题结构截取范围";
  return "按开始/结束位置截取范围";
}

function rangeResultForMode(rawEvents, normalized, options, headingRange, baseSendDate) {
  if (normalized.rangeMode === "full") return fullRangeResult(rawEvents);
  if (normalized.rangeMode === "heading") return locateHeadingRange(rawEvents, headingRange);
  return locateRange(rawEvents, {
    start: options.startKeyword,
    end: options.endKeyword,
    endAtDocumentEnd: options.endAtDocumentEnd
  }, {
    baseSendDate
  });
}

async function resolveHeadingRangeFromPage(page, settings, state) {
  state.update({ step: "识别标题结构", waitingReason: "只读取飞书左侧目录，不采集正文和素材" });
  const structure = await collectHeadingStructureFromPage(page);
  const fallbackStructure = structure.headings.length ? structure : buildHeadingStructure([
    settings.headingRhythm ? `${settings.headingDay}${settings.headingRhythm}` : settings.headingDay
  ]);
  const resolved = resolveHeadingSelection(fallbackStructure, settings);
  state.log(`识别标题结构：只读目录；识别标题数=${fallbackStructure.headings.length}；可选天数=${fallbackStructure.days.map((item) => item.label).join("、") || "无"}`);
  state.log(`按节奏/天数选择：第几天=${resolved.day}；节奏标题=${resolved.rhythm || "整天"}；自动识别的开始位置=${resolved.startTitle}；自动识别的结束位置=${resolved.endTitle || "文档末尾"}；跳过朋友圈=${resolved.skippedHeadings.length ? "是" : "否"}`);
  return resolved;
}

function rangeReportLabel(normalized, headingRange) {
  if (normalized.rangeMode === "full") return "全文读取";
  if (normalized.rangeMode === "heading") return `按节奏/天数选择：${headingRange?.label || normalized.headingDay || ""}`;
  return "指定开始/结束位置";
}

function rangeSourceModeLabel(mode) {
  if (mode === "full") return "full";
  if (mode === "heading") return "heading/rhythm";
  return "manual/start-end";
}

function pageInfosFromPreparedPages(pages = []) {
  return pages.map((page, index) => ({
    index: index + 1,
    page,
    url: page?.url?.() || "",
    cmsRole: page?.__v2CmsRole || "",
    selection: {}
  }));
}

function formatMediaMaterializeProgress(progress = {}) {
  const phase = String(progress.phase || "");
  if (!["start", "done", "failed"].includes(phase)) return "";
  const typeLabel = mediaTypeLabel(progress.type);
  const prefix = phase === "failed"
    ? "素材保存失败"
    : phase === "done"
      ? "素材已保存"
      : "正在保存素材";
  const count = `${progress.current || 0}/${progress.total || 0}`;
  const item = progress.item || {};
  const identity = mediaProgressIdentity(item, progress);
  const slowHint = progress.type === "video" && phase === "start" ? "；正在保存视频，可能较慢" : "";
  const localHint = phase === "done" && progress.localPath ? `；本地路径=${progress.localPath}` : "";
  const errorHint = phase === "failed" && progress.error ? `；原因=${progress.error}` : "";
  return `${prefix} ${count}：${typeLabel}${slowHint}；${identity}；原始地址=${progress.source || mediaProgressSource(item)}${localHint}${errorHint}`;
}

function mediaTypeLabel(type) {
  if (type === "video") return "视频";
  if (type === "sticker") return "表情";
  return "图片";
}

function mediaProgressIdentity(item = {}, progress = {}) {
  const speaker = item.collectSpeaker || item.raw?.collectSpeaker || parseEventSpeakerTime(item).speaker || "未识别";
  const time = item.collectTime || item.raw?.collectTime || parseEventSpeakerTime(item).time || "未知时间";
  const order = Number.isFinite(Number(item.order)) ? Number(item.order) + 1 : Number(progress.index) + 1;
  return `第 ${order || "?"} 条；说话人=${speaker}；时间=${time}`;
}

function mediaProgressSource(item = {}) {
  return item.mediaPath || item.assetUrl || item.src || item.sourceUrl || item.raw?.sourceUrl || "";
}

function fullRangeResult(rawEvents) {
  return {
    events: rawEvents,
    diagnostics: {
      mode: "full",
      includedEventCount: rawEvents.length,
      startMatchedEvent: rawEvents[0] || null,
      startExpandedToEvent: rawEvents[0] || null,
      endMatchedEvent: rawEvents.at(-1) || null
    }
  };
}

function formatManualRangeDiagnosticsLog(settings, diagnostics = {}) {
  return [
    "manual/start-end 定位结果：",
    `rangeMode=manual/start-end`,
    `start=${settings.startKeyword || ""}`,
    `end=${settings.endKeyword || "文档末尾"}`,
    `start匹配方式=${manualMatchMethod(diagnostics.startMatchReason)}`,
    `start上下文=${manualCandidateContext(diagnostics.startSelectedCandidate || diagnostics.startMatchedEvent)}`,
    `end匹配方式=${settings.endKeyword ? manualMatchMethod(diagnostics.endMatchReason) : "document_end"}`,
    `end上下文=${settings.endKeyword ? manualCandidateContext(diagnostics.endSelectedCandidate || diagnostics.endMatchedEvent) : "文档末尾"}`,
    `裁剪后events=${diagnostics.includedEventCount ?? 0}`
  ].join("；");
}

function formatManualRangeFailureLog(settings, error) {
  const diagnostics = error?.diagnostics || {};
  return [
    "manual/start-end 定位失败：",
    `rangeMode=manual/start-end`,
    `start=${settings.startKeyword || ""}`,
    `end=${settings.endKeyword || "文档末尾"}`,
    `start匹配方式=${manualMatchMethod(diagnostics.startMatchReason)}`,
    `start候选=${manualCandidateList(diagnostics.startCandidates)}`,
    `end匹配方式=${settings.endKeyword ? manualMatchMethod(diagnostics.endMatchReason) : "document_end"}`,
    `end候选=${settings.endKeyword ? manualCandidateList(diagnostics.endCandidates) : "文档末尾"}`,
    `错误=${error?.message || error}`
  ].join("；");
}

function manualMatchMethod(reason = "") {
  const value = String(reason || "");
  if (value.includes("structured")) return "speaker/date/time";
  if (value.includes("text")) return "text";
  if (value.includes("empty")) return "empty";
  if (value.includes("no_")) return "not_found";
  return value || "unknown";
}

function manualCandidateContext(candidate) {
  if (!candidate) return "无";
  const event = candidate.event || candidate;
  const text = candidate.contextText || event.text || event.sourceText || "";
  const speaker = candidate.speaker || candidate.cleanSpeaker || "";
  const date = candidate.date || "";
  const time = candidate.time || "";
  return [`#${candidate.index ?? event.order ?? ""}`, speaker, date, time, text]
    .filter(Boolean)
    .join(" ")
    .slice(0, 260);
}

function manualCandidateList(candidates = []) {
  if (!Array.isArray(candidates) || !candidates.length) return "无";
  return candidates.slice(0, 5).map(manualCandidateContext).join(" | ");
}

function validateFullReadCompleteness(rawEvents, diagnostics = {}) {
  if (!diagnostics.documentEndConfirmed) {
    throw new Error(`全文读取未确认到达文档末尾，停止原因：${diagnostics.stoppedBecause || "未知"}，滚动次数：${diagnostics.scrollCount ?? 0}`);
  }
  if (!Array.isArray(rawEvents) || rawEvents.length < 3) {
    throw new Error(`全文读取采集结果过少：${rawEvents?.length || 0} 条 raw-events，已停止。`);
  }
}

function isClosedPageError(error) {
  const message = String(error?.message || error || "");
  return /Target page, context or browser has been closed|Target closed|browser has been closed|page has been closed/i.test(message);
}

function summarizePreviewIdentity(task) {
  if (!task) return null;
  return {
    role: task.role || "",
    speaker: task.cleanSpeaker || task.speaker || "",
    date: task.date || "",
    time: task.time || "",
    type: task.type || ""
  };
}

function formatTaskIdentity(task) {
  const item = summarizePreviewIdentity(task);
  if (!item) return "无";
  return `${item.speaker || "未识别"} ${item.date || ""} ${item.time || ""} ${item.type || ""}`.trim();
}

function formatEventIdentity(event) {
  if (!event) return "无";
  const parsed = parseEventSpeakerTime(event);
  return `${parsed.speaker || event.text || event.sourceText || event.type || "未识别"} ${parsed.date || ""} ${parsed.time || ""}`.trim();
}

function parseEventSpeakerTime(event) {
  const text = String(event?.text || event?.sourceText || "").trim();
  const match = text.match(/^(.{1,40}?)\s+(?:(\d{1,2}[\/月]\d{1,2}(?:日)?)\s+)?(\d{1,2}[:：]\d{1,2}(?::\d{1,2})?)/);
  if (!match) return { speaker: "", date: "", time: "" };
  return {
    speaker: match[1].trim(),
    date: match[2] || "",
    time: match[3].replace(/：/g, ":")
  };
}

function applyDefaultDate(tasks, date) {
  const fallback = String(date || "").trim();
  if (!fallback) return tasks;
  return tasks.map((task) => task.date ? task : { ...task, date: fallback });
}

function resolveBaseSendDate(value) {
  const text = String(value || "").trim();
  return normalizeSendDate(text) || todayMonthDay();
}

function appendSearchTraceLogs(state, diagnostics = {}) {
  const keywordJumps = Array.isArray(diagnostics.keywordJumps) ? diagnostics.keywordJumps : [];
  for (const jump of keywordJumps) {
    const traces = Array.isArray(jump.searchTrace) ? jump.searchTrace : [];
    const label = jump.label === "start" ? "开始" : (jump.label === "end" ? "结束" : "关键词");
    for (const item of traces) {
      const parts = [
        `飞书搜索定位/${label}/${item.index || "-"}：${item.message || item.stage || ""}`,
        item.url ? `url=${item.url}` : "",
        item.title ? `标题=${item.title}` : "",
        item.point ? `点击=(${Math.round(Number(item.point.x) || 0)},${Math.round(Number(item.point.y) || 0)})` : "",
        item.text ? `文字=${String(item.text).slice(0, 80)}` : "",
        item.candidateCount !== undefined ? `候选=${item.candidateCount}` : "",
        item.inputValue !== undefined ? `输入=${String(item.inputValue).slice(0, 80)}` : "",
        item.visibleTextContainsKeyword !== undefined && item.visibleTextContainsKeyword !== null ? `可见包含关键词=${item.visibleTextContainsKeyword ? "是" : "否"}` : ""
      ].filter(Boolean);
      state.log(parts.join("；"));
    }
    if (jump.failureScreenshot) state.log(`飞书搜索定位/${label}：失败截图=${jump.failureScreenshot}`);
  }
}

async function saveFlowError(runDir, step, error) {
  await fs.mkdir(runDir, { recursive: true }).catch(() => {});
  await saveJson(path.join(runDir, "flow-error.json"), {
    ok: false,
    step,
    code: error?.code || error?.name || "error",
    message: error?.message || String(error),
    failedAt: new Date().toISOString()
  }).catch(() => {});
}

async function keyFiles(runDir) {
  return {
    rawEvents: await exists(path.join(runDir, "raw-events.json")),
    previewTasks: await exists(previewTasksPath(runDir)),
    previewJson: await exists(finalPreviewPath(runDir)),
    flowError: await exists(path.join(runDir, "flow-error.json")),
    collectDiagnostics: await exists(path.join(runDir, "collect-diagnostics.json"))
  };
}

function missingKeyFiles(files) {
  const missing = [];
  if (!files.rawEvents) missing.push("raw-events.json");
  if (!files.previewTasks) missing.push("preview-tasks.json");
  if (!files.previewJson) missing.push("preview.json");
  return missing;
}

function countSubmitted(report) {
  return (String(report || "").match(/提交成功/g) || []).length;
}

function cmsPagesAlive(opened) {
  const pages = opened?.pages || [];
  return pages.filter((page) => !page.isClosed?.()).length >= 2;
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function loadControlledBrowserState(projectRoot, config = {}) {
  return loadV2ControlledBrowserState(projectRoot, config);
}

async function saveJson(filePath, value) {
  await fs.writeFile(filePath, JSON.stringify(value, null, 2), "utf8");
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

async function openControlledBrowserPage(projectRoot, config, url) {
  const controlled = await ensureV2ControlledBrowser({
    projectRoot,
    config,
    url,
    openUrl: true
  });
  await openOrFocusControlledPage(controlled.cdpUrl, url).catch(() => {});
}

async function openControlledPreviewPage(projectRoot, config, url) {
  const controlled = await ensureV2ControlledBrowser({
    projectRoot,
    config,
    openUrl: false
  });
  await openOrReplaceControlledPage(controlled.cdpUrl, url, {
    titleIncludes: "妙券自动发单 - 预览确认",
    onlyLocalhost: true,
    closeExtra: true
  }).catch(() => {});
}

async function focusConsolePage(projectRoot, consoleUrl) {
  if (!consoleUrl) return false;
  try {
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const controlled = await loadControlledBrowserState(projectRoot, config);
    if (!controlled.cdpUrl) return false;
    await openOrFocusConsolePage(controlled.cdpUrl, withControlledFlag(consoleUrl));
    return true;
  } catch {
    return false;
  }
}

async function closeOpenedFeishuPage(opened, state) {
  const result = await closeFeishuCollectPage(opened);
  if (!result.ok) {
    state?.log?.(`飞书页面关闭失败：${result.error || "未知原因"}，后续流程继续。`);
  } else if (result.closed && !result.closedBrowserContext) {
    state?.log?.("飞书页面已关闭。");
  }
  return result;
}

function withControlledFlag(url) {
  const parsed = new URL(url);
  parsed.searchParams.set("controlled", "1");
  return parsed.toString();
}

function withPreviewRunParams(url, runDir) {
  const parsed = new URL(withControlledFlag(url));
  parsed.searchParams.set("runId", path.basename(path.resolve(runDir || "")));
  parsed.searchParams.set("ts", String(Date.now()));
  return parsed.toString();
}

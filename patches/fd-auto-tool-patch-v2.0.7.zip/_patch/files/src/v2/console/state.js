export function createConsoleState() {
  const state = {
    step: "idle",
    status: "ready",
    runDir: "",
    previewPath: "",
    previewUrl: "",
    successCount: 0,
    failureCount: 0,
    currentIndex: 0,
    totalCount: 0,
    waitingReason: "",
    failureStep: "",
    failureReason: "",
    missingFiles: [],
    control: "ready",
    logs: [],
    updatedAt: new Date().toISOString()
  };

  return {
    snapshot() {
      return { ...state, logs: [...state.logs] };
    },
    update(patch = {}) {
      Object.assign(state, patch, { updatedAt: new Date().toISOString() });
      return this.snapshot();
    },
    pause(reason = "用户点击暂停") {
      if (state.status === "running") {
        state.status = "paused";
        state.control = "paused";
        state.waitingReason = reason;
        state.updatedAt = new Date().toISOString();
        this.log(reason);
      }
      return this.snapshot();
    },
    resume(reason = "用户点击继续") {
      if (state.status === "paused") {
        state.status = "running";
        state.control = "running";
        state.waitingReason = reason;
        state.updatedAt = new Date().toISOString();
        this.log(reason);
      }
      return this.snapshot();
    },
    stop(reason = "用户点击停止") {
      if (state.status === "running" || state.status === "paused") {
        state.status = "stopped";
        state.control = "stopped";
        state.waitingReason = reason;
        state.updatedAt = new Date().toISOString();
        this.log(reason);
      }
      return this.snapshot();
    },
    log(message, fields = {}) {
      const entry = {
        time: new Date().toISOString(),
        message: String(message || ""),
        ...fields
      };
      state.logs.push(entry);
      if (state.logs.length > 1000) state.logs.splice(0, state.logs.length - 1000);
      state.updatedAt = entry.time;
      return entry;
    },
    fail(step, reason, fields = {}) {
      state.status = "failed";
      state.step = "失败";
      state.failureStep = step;
      state.failureReason = String(reason || "");
      state.failureCount += 1;
      state.waitingReason = "";
      Object.assign(state, fields, { updatedAt: new Date().toISOString() });
      this.log(`失败：${step}：${reason}`);
      return this.snapshot();
    },
    resetTerminalState(reason = "重新打开控制台，清理上次终态") {
      if (!["failed", "stopped", "disconnected"].includes(state.status)) return this.snapshot();
      Object.assign(state, {
        step: "idle",
        status: "ready",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        successCount: 0,
        failureCount: 0,
        currentIndex: 0,
        totalCount: 0,
        waitingReason: "",
        failureStep: "",
        failureReason: "",
        missingFiles: [],
        control: "ready",
        updatedAt: new Date().toISOString()
      });
      this.log(reason);
      return this.snapshot();
    },
    resetForNextRun(reason = "开始下一轮发单：已清理本轮运行状态") {
      Object.assign(state, {
        step: "idle",
        status: "ready",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        successCount: 0,
        failureCount: 0,
        currentIndex: 0,
        totalCount: 0,
        waitingReason: "可以修改飞书链接、时间模式或直接生成下一轮预览",
        failureStep: "",
        failureReason: "",
        missingFiles: [],
        control: "ready",
        logs: [],
        updatedAt: new Date().toISOString()
      });
      this.log(reason);
      return this.snapshot();
    },
    resetForRun(step) {
      Object.assign(state, {
        step,
        status: "running",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        successCount: 0,
        failureCount: 0,
        currentIndex: 0,
        totalCount: 0,
        waitingReason: "",
        failureStep: "",
        failureReason: "",
        missingFiles: [],
        control: "running",
        logs: [],
        updatedAt: new Date().toISOString()
      });
      this.log(`开始：${step}`);
      return this.snapshot();
    }
  };
}

export function createWorkflowControl(consoleState) {
  return {
    async checkpoint(label) {
      const text = String(label || "");
      const match = text.match(/第\s*(\d+)\s*条/);
      const before = consoleState.snapshot();
      if (before.control === "stopped") {
        throw new Error(`用户已停止，后台停在检查点：${text}`);
      }
      consoleState.update({
        step: "正式创建 CMS",
        status: before.control === "paused" ? "paused" : "running",
        control: before.control === "paused" ? "paused" : "running",
        currentIndex: match ? Number(match[1]) : consoleState.snapshot().currentIndex,
        waitingReason: text
      });
      consoleState.log(text);
      while (consoleState.snapshot().control === "paused") {
        await sleep(500);
      }
      if (consoleState.snapshot().control === "stopped") {
        throw new Error(`用户已停止，后台停在检查点：${text}`);
      }
    }
  };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

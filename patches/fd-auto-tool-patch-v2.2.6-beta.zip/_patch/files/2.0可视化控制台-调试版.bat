@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo Starting 2.0 visual console debug mode...
echo This debug window stays open and shows raw Node logs.
echo Use the normal "2.0可视化控制台.bat" for daily use without this window.
echo.
node "src\v2\tools\run-console-cli.js" --port 62230 %*
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
  echo 2.0 visual console closed.
) else (
  echo 2.0 visual console failed. Exit code: %EXIT_CODE%
)
pause
exit /b %EXIT_CODE%

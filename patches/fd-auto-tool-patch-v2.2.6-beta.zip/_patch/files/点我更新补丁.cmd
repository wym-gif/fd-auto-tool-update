@echo off
setlocal
cd /d "%~dp0"

set "NODE_EXE="
if exist "%~dp0tools\node\node.exe" set "NODE_EXE=%~dp0tools\node\node.exe"
if not defined NODE_EXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE for /f "delims=" %%N in ('where node 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"

if not defined NODE_EXE (
  echo Node runtime not found.
  echo Please use the full runtime package first.
  pause
  exit /b 1
)

if not exist "%~dp0_patch\patch-manifest.json" (
  echo Patch files not found.
  echo Please unzip the patch package into this tool folder first.
  pause
  exit /b 1
)

if not exist "%~dp0tools\apply-patch.cjs" (
  echo Patch updater not found.
  echo Please use a newer full package.
  pause
  exit /b 1
)

echo Stopping old console service for this folder if it is still running...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$root=(Resolve-Path '%~dp0').Path.TrimEnd('\'); Get-CimInstance Win32_Process -Filter \"Name='node.exe'\" | Where-Object { $_.CommandLine -and $_.CommandLine -like ('*' + $root + '*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>nul

"%NODE_EXE%" "%~dp0tools\apply-patch.cjs"
echo.
pause

const TRAILING_TIME_RE = /(?:(\d{1,2})[\/月](\d{1,2})(?:日)?\s+)?(\d{1,2})[：:](\d{1,2})(?:[：:](\d{1,2}))?\s*$/;
const FORWARDED_HEADER_RE = /^转发\s*[·・•]\s*(.+?)\s*[·・•]\s*(\d{4})-(\d{1,2})-(\d{1,2})\s+(\d{1,2})[：:](\d{1,2})(?:[：:](\d{1,2}))?$/;
const CONTINUE_HINT = "下面还说话";

export function parseExplicitTimedRoleHeaderLine(value) {
  const text = normalizeText(value);
  if (!text || text.includes("\n") || text.length > 90) return null;
  const annotated = extractTrailingRoleAnnotation(text);
  const forwarded = parseForwardedHeader(annotated.headerText);
  if (forwarded) return { ...forwarded, sourceText: text, forwarded: true, ...(annotated.note ? { personaHint: annotated.note } : {}) };

  const withoutHint = stripTrailingRoleHint(stripContinueHint(annotated.headerText));
  const time = parseHeaderTime(withoutHint);
  if (!time) return null;
  const speakerPart = withoutHint.slice(0, time.index).trim();
  if (!time.date && /\d{1,2}\s*[\/月]\s*\d{1,2}(?:日)?\s*$/.test(speakerPart)) return null;
  const speaker = cleanSpeaker(speakerPart);
  if (!isPlausibleTimedSpeaker(speaker, speakerPart)) return null;
  return {
    speaker,
    date: time.date,
    time: time.time,
    sourceText: text,
    forwarded: false,
    ...(annotated.note ? { personaHint: annotated.note } : {})
  };
}

export function isLikelyTimedBodySpeaker(value) {
  const compact = normalizeText(value).replace(/\s+/g, "");
  if (!compact) return false;
  if (/^(?:⏰|⏱️|🔔|📢)*(?:我们|咱们|咱|大家|明天|明日|明早|明晚|今天|今晚|上午|下午|晚上|早上|中午|凌晨|午间|晚间)/.test(compact)) return true;
  return /(?:活动|开抢|直播|提醒|截止|恢复|开奖|上架|发售|优惠|秒杀|正文)?时间$/.test(compact);
}

export function detectRoleHeader(event, options = {}) {
  if (!event || event.kind !== "line") return null;
  const block = splitTimedHeaderBlock(event.text);
  const explicitTimed = parseExplicitTimedRoleHeaderLine(block.useHeaderLine ? block.headerText : event.text);
  if (explicitTimed) {
    if (isOrdinaryForwardText(explicitTimed.speaker)) return null;
    if (options.currentRole && (isBodyTimeLabel(explicitTimed.speaker) || isLikelyTimedBodySpeaker(explicitTimed.speaker))) return null;
    return buildHeader({
      role: explicitTimed.speaker.includes("豆妈") || (event.highlighted && options.allowHighlightedSellerHeader !== false) ? "douma" : "tuo",
      speaker: explicitTimed.speaker,
      date: explicitTimed.date,
      time: explicitTimed.time,
      sourceText: block.headerText,
      explicit: true,
      personaHint: explicitTimed.personaHint || "",
      ...(block.hasInlineBody ? { inlineBodyText: block.bodyText } : {})
    });
  }

  const rawText = normalizeText(block.useHeaderLine ? block.headerText : event.text);
  if (!rawText || isNonHeaderText(rawText)) return null;

  const withoutHint = stripContinueHint(rawText);
  const time = parseHeaderTime(withoutHint);
  const speakerPart = time
    ? withoutHint.slice(0, time.index).trim()
    : withoutHint.trim();
  const speaker = cleanSpeaker(speakerPart);
  if (time && isOrdinaryForwardText(speakerPart)) return null;
  if (options.currentRole && time && isBodyTimeLabel(speakerPart)) return null;
  if (options.currentRole === "douma" && time && isDoumaBodyTimeReminder(withoutHint, speakerPart, time)) {
    return null;
  }

  const numbered = parseNumberedTuoMarker(speaker || withoutHint);
  if (numbered) {
    return buildHeader({
      role: "tuo",
      speaker: numbered.speaker,
      date: time?.date || "",
      time: time?.time || "",
      sourceText: rawText,
      explicit: true,
      ...(block.useHeaderLine ? { inlineBodyText: block.bodyText } : {})
    });
  }

  if (isExplicitDoumaHeader(speaker, withoutHint, time)) {
    return buildHeader({
      role: "douma",
      speaker: speaker || "豆妈",
      date: time?.date || "",
      time: time?.time || "",
      sourceText: rawText,
      explicit: true,
      ...(block.useHeaderLine ? { inlineBodyText: block.bodyText } : {})
    });
  }

  if (event.highlighted && time && speaker && options.allowHighlightedSellerHeader !== false) {
    return buildHeader({
      role: "douma",
      speaker,
      date: time.date,
      time: time.time,
      sourceText: rawText,
      explicit: true,
      ...(block.useHeaderLine ? { inlineBodyText: block.bodyText } : {})
    });
  }

  if (time && !speaker && hasAbnormalTimedSpeaker(speakerPart)) {
    return buildHeader({
      role: "tuo",
      speaker: speakerPart.trim(),
      cleanSpeaker: "匿名托",
      speakerConfidence: "low",
      date: time.date,
      time: time.time,
      sourceText: rawText,
      explicit: true,
      ...(block.useHeaderLine ? { inlineBodyText: block.bodyText } : {})
    });
  }

  if (time && speaker) {
    return buildHeader({
      role: "tuo",
      speaker,
      date: time.date,
      time: time.time,
      sourceText: rawText,
      explicit: true,
      ...(block.useHeaderLine ? { inlineBodyText: block.bodyText } : {})
    });
  }

  if (isBarePersonHeader(speaker || withoutHint, options)) {
    return buildHeader({
      role: "tuo",
      speaker: speaker || withoutHint,
      date: "",
      time: "",
      sourceText: rawText,
      explicit: true
    });
  }

  if (event.highlighted && options.allowHighlightedDouma !== false) {
    return buildHeader({
      role: "douma",
      speaker: "豆妈",
      date: "",
      time: "",
      sourceText: rawText,
      explicit: false,
      useLineAsContent: true
    });
  }

  return null;
}

function splitTimedHeaderBlock(text) {
  const normalized = String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ");
  const lines = normalized.split("\n");
  const headerLineIndex = lines.findIndex((line) => line.trim());
  if (headerLineIndex < 0 || headerLineIndex === lines.length - 1) {
    return { headerText: normalized.trim(), bodyText: "", hasInlineBody: false, useHeaderLine: false };
  }
  const headerText = lines[headerLineIndex].trim();
  const bodyText = lines.slice(headerLineIndex + 1).join("\n");
  return {
    headerText,
    bodyText,
    hasInlineBody: Boolean(bodyText.trim()),
    useHeaderLine: isStandaloneTimedHeaderLine(headerText)
  };
}

function isStandaloneTimedHeaderLine(text) {
  return Boolean(parseExplicitTimedRoleHeaderLine(text));
}

function parseForwardedHeader(text) {
  const match = normalizeText(text).match(FORWARDED_HEADER_RE);
  if (!match) return null;
  const [, rawSpeaker, , month, day, hour, minute, second] = match;
  const speaker = cleanSpeaker(rawSpeaker);
  if (!speaker) return null;
  return {
    speaker,
    date: `${Number(month)}/${Number(day)}`,
    time: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:${String(second || "00").padStart(2, "0")}`
  };
}

export function hasContinueHint(text) {
  return normalizeText(text).replace(/\s+/g, "").includes(CONTINUE_HINT);
}

export function isNonSendableRemark(text, options = {}) {
  const compact = normalizeText(text).replace(/\s+/g, "");
  if (!compact) return true;
  if (compact.includes(CONTINUE_HINT)) return true;
  if (/^备注/.test(compact)) return true;
  if (isRhythmHeadingText(compact, options)) return true;
  if (isStandaloneCollectionHeadingText(compact)) return true;
  if (isMediaAnnotationText(compact)) return true;
  if (/^(图|图片|视频|素材|物料)(?:要)?(?:换|替换|换一下|需换|需要换)$/.test(compact)) return true;
  if (/^(不发|不用发|不定时|标注)$/.test(compact)) return true;
  return false;
}

function isMediaAnnotationText(compact) {
  if (compact.length > 24) return false;
  if (/^(?:换|改|替换|换成|改成|替换成)(?:自己|自己的|我们自己的|我的)?(?:到货|实拍|晒单|买家秀)?(?:图|图片|照片)$/.test(compact)) return true;
  if (/^(?:自己|自己的|我们自己的|我的)(?:到货|实拍|晒单|买家秀)(?:图|图片|照片)$/.test(compact)) return true;
  return false;
}

function isStandaloneCollectionHeadingText(compact) {
  if (compact.length > 16 || !compact.includes("合集")) return false;
  return /^(?:未失效|已失效|失效|有效|不过期)?(?:好物|商品|福利|链接)?合集(?:好物|商品|清单|链接|福利)?$/.test(compact)
    || /^(?:未失效|已失效|失效|有效|不过期)?(?:好物|商品|福利|链接)(?:合集)$/.test(compact);
}

function isRhythmHeadingText(compact, options = {}) {
  if (options.insideRoleSegment && isBareLinkCommandText(compact)) return false;
  return /^(?:(?:早上|上午|中午|下午|傍晚|晚上|晚间|早间|午间|凌晨)?(?:\d{1,2}(?:点(?:半|[0-5]?\d(?:分|点)?)?|[:：]\d{1,2})?)?(?:之后|以后|前|左右)?(?:日常|小)?(?:晒图|预热|预告|定时|反馈|返场|开团|开抢|催单|福利单|福利|科普|早餐|晚安|早安|互动|收割|养群|穿插养群|开始正文|正文|上链接|发链接|开链接)(?:互动|预告|提醒|定时|之后)?|(?:八点|九点|十点|\d{1,2}点(?:半|[0-5]?\d(?:分|点)?)?)(?:之后|以后|前|左右)?|(?:早上|上午|中午|下午|傍晚|晚上|晚间|早间|午间|凌晨))$/.test(compact);
}

function isBareLinkCommandText(compact) {
  return /^(?:上链接|发链接|开链接)$/.test(compact);
}

function isDoumaBodyTimeReminder(text, speakerPart, time) {
  const compact = normalizeText(text).replace(/\s+/g, "");
  const prefix = normalizeText(speakerPart).replace(/\s+/g, "");
  const afterTime = compact.slice(Math.max(0, time.index + time.raw.length));
  if (!afterTime) return false;
  if (prefix && !/(?:^|[⏰⏱️🔔📢])(?:明天|明日|明早|明晚|今天|今晚|上午|下午|晚上|早上|中午|凌晨|午间|晚间)/.test(prefix)) return false;
  return /(?:准时|限量|限时|售罄|售完|卖完|没了|恢复原价|复原价|手速|买|抢|开抢|置顶|定好?闹钟|闹钟|提醒|蹲|拍|下单|上链接|开链接|发链接|开团|开售|开卖|秒杀|预告)/.test(afterTime);
}

function isOrdinaryForwardText(speakerPart) {
  return /^转发(?!\s*[·・•])/.test(normalizeText(speakerPart));
}

function isBodyTimeLabel(speakerPart) {
  const compact = normalizeText(speakerPart).replace(/\s+/g, "");
  return /^(?:活动|开抢|直播|提醒|截止|恢复|开奖|上架|发售|优惠|秒杀|正文)?时间$/.test(compact);
}

function buildHeader(fields) {
  return {
    ...fields,
    continueSpeaker: hasContinueHint(fields.sourceText)
  };
}

function parseHeaderTime(text) {
  const match = String(text || "").match(TRAILING_TIME_RE);
  if (!match) return null;
  const [, month, day, hour, minute, second] = match;
  if (!isValidHeaderDate(month, day) || !isValidHeaderClock(hour, minute, second)) return null;
  return {
    date: month && day ? `${Number(month)}/${Number(day)}` : "",
    time: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:${String(second || "00").padStart(2, "0")}`,
    raw: match[0],
    index: match.index
  };
}

function isPlausibleTimedSpeaker(speaker, rawSpeaker) {
  const compact = String(speaker || "").replace(/\s+/g, "");
  if (!compact || compact.length > 28) return false;
  if (/^[/:：月日.\-—_~～]+$/.test(compact)) return false;
  if (/[<>]/.test(String(rawSpeaker || ""))) return false;
  return true;
}

function stripTrailingRoleHint(text) {
  return String(text || "")
    .replace(/\s*[（(【\[]\s*下面(?:有|还有|继续|还说话)\s*[）)】\]]\s*$/, "")
    .trim();
}

function extractTrailingRoleAnnotation(text) {
  const match = String(text || "").match(/^(.*?\d{1,2}[：:]\d{1,2}(?:[：:]\d{1,2})?)\s*[（(【\[]\s*([^）)】\]]{1,40})\s*[）)】\]]\s*$/);
  if (!match) return { headerText: text, note: "" };
  const note = normalizeText(match[2]);
  if (!/(?:人设|看图|按图|头像|昵称|备注|已婚|宝妈|年轻|成熟|学生|大学生|工作|上班|职场|办公室|男士|男性|女性|女生|下面还说话|继续说话|托)/.test(note)) {
    return { headerText: text, note: "" };
  }
  return { headerText: match[1].trim(), note };
}

function isValidHeaderDate(month, day) {
  if (!month && !day) return true;
  const m = Number(month);
  const d = Number(day);
  if (!Number.isInteger(m) || !Number.isInteger(d) || m < 1 || m > 12 || d < 1) return false;
  return d <= new Date(2024, m, 0).getDate();
}

function isValidHeaderClock(hour, minute, second) {
  const h = Number(hour);
  const m = Number(minute);
  const s = Number(second || 0);
  return Number.isInteger(h) && Number.isInteger(m) && Number.isInteger(s)
    && h >= 0 && h <= 23 && m >= 0 && m <= 59 && s >= 0 && s <= 59;
}

function parseNumberedTuoMarker(text) {
  const compact = normalizeText(text).replace(/\s+/g, "");
  const match = compact.match(/^(?:T|托)(\d*)$/i);
  if (!match) return null;
  const prefix = compact[0].toUpperCase() === "T" ? "T" : "托";
  return { speaker: `${prefix}${match[1] || ""}` };
}

function stripContinueHint(text) {
  return normalizeText(text)
    .replace(new RegExp(`（[^）]*${CONTINUE_HINT}[^）]*）`, "g"), "")
    .replace(new RegExp(`\\([^)]*${CONTINUE_HINT}[^)]*\\)`, "g"), "")
    .replace(new RegExp(`【[^】]*${CONTINUE_HINT}[^】]*】`, "g"), "")
    .replace(new RegExp(`\\[[^\\]]*${CONTINUE_HINT}[^\\]]*\\]`, "g"), "")
    .replace(new RegExp(CONTINUE_HINT, "g"), "")
    .trim();
}

function isExplicitDoumaHeader(speaker, text, time) {
  const clean = cleanSpeaker(speaker || text);
  const compact = clean.replace(/\s+/g, "");
  if (!compact.includes("豆妈")) return false;
  if (time) return true;
  return /^豆妈(?:[🍒🌸❤️❤💕💖]*)?$/.test(compact);
}

function cleanSpeaker(text) {
  const normalized = normalizeText(text);
  if (isStandalonePunctuationSpeaker(normalized)) return normalized;
  return normalized
    .replace(/(?:[:：]|[!！?？])+\s*[(（]\s*$/, "")
    .replace(/[，,。；;：:]+$/, "")
    .trim();
}

function isStandalonePunctuationSpeaker(text) {
  return /^[。．.·・丶]$/.test(String(text || "").trim());
}

function hasAbnormalTimedSpeaker(text) {
  const raw = normalizeText(text);
  if (!raw) return false;
  if (/^\d+$/.test(raw)) return false;
  return true;
}

function isBarePersonHeader(text, options = {}) {
  const line = cleanSpeaker(text);
  if (!line || line.includes("豆妈")) return false;
  if (isStandaloneBodySeparator(line)) return false;
  if (Array.isArray(options.knownSpeakers) && options.knownSpeakers.includes(line)) return true;
  if (options.allowBareNameHeaders === false) return false;
  if (line.length > 6) return false;
  if (/https?:\/\//i.test(line)) return false;
  if (/[，,。！？!?；;：:、]/.test(line)) return false;
  if (/\s/.test(line)) return false;
  if (/^(图片|视频|表情包|动态表情|备注|不发|不用发|不定时)$/.test(line)) return false;
  return true;
}

function isStandaloneBodySeparator(text) {
  return /^[-－—_~～]+$/.test(String(text || "").trim());
}

function isNonHeaderText(text) {
  const line = normalizeText(text);
  if (/^https?:\/\//i.test(line)) return true;
  return false;
}

function normalizeText(text) {
  return String(text || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .trim();
}

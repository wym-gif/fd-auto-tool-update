import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createHash, createHmac, randomBytes, randomUUID } from "node:crypto";
import { spawn } from "node:child_process";

const STORE_VERSION = 1;
const LOCK_STALE_MS = 15_000;
const LOCK_WAIT_MS = 5_000;

export function deviceProofStoreRoot(options = {}) {
  if (options.storeRoot) return path.resolve(options.storeRoot);
  return path.join(process.env.LOCALAPPDATA || os.tmpdir(), "MiaoQuan", "device-credentials-v1");
}

export async function ensureDeviceProofKey(options = {}) {
  const deviceId = normalizeDeviceId(options.deviceId);
  const provided = normalizeProofKey(options.proofKey || "");
  if (provided && options.persistProvided !== true) return provided;
  const file = proofPath(deviceId, options);
  const existing = await readStoredProof(file, options);
  if (existing) return existing;

  return withStoreLock(deviceId, options, async () => {
    const current = await readStoredProof(file, options);
    if (current) return current;
    const proofKey = provided || randomBytes(32).toString("base64url");
    const ciphertext = await protect(proofKey, options);
    const value = {
      version: STORE_VERSION,
      protection: options.protectValue ? "test" : "dpapi-current-user",
      deviceId,
      keyHash: proofKeyHash(proofKey),
      ciphertext,
      createdAt: new Date().toISOString()
    };
    await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 });
    const temp = `${file}.${process.pid}.${randomUUID()}.tmp`;
    await fs.writeFile(temp, `${JSON.stringify(value)}\n`, { encoding: "utf8", mode: 0o600 });
    await fs.rename(temp, file);
    return proofKey;
  });
}

export function buildFeishuEnrollment({ companyId, deviceId, appVersion, computerName = "", proofKey,
  now = Date.now(), nonce = randomBytes(24).toString("hex"), enrollmentId = randomUUID() } = {}) {
  const normalizedKey = normalizeProofKey(proofKey);
  if (!normalizedKey) throw enrollmentError("设备飞书连接证明无效。", "DEVICE_PROOF_INVALID");
  const payload = {
    companyId: String(companyId || ""),
    deviceId: normalizeDeviceId(deviceId),
    appVersion: String(appVersion || "").slice(0, 32),
    computerName: String(computerName || "").slice(0, 80),
    proofKeyHash: proofKeyHash(normalizedKey),
    enrollmentId: String(enrollmentId || "").slice(0, 64),
    timestamp: Math.floor(Number(now) / 1000),
    nonce: String(nonce || "").slice(0, 128)
  };
  const canonical = canonicalEnrollment(payload);
  payload.proofSignature = createHmac("sha256", Buffer.from(payload.proofKeyHash, "hex"))
    .update(canonical).digest("hex");
  return payload;
}

export function canonicalEnrollment(payload) {
  return [payload.companyId, payload.deviceId, payload.appVersion, payload.computerName,
    payload.proofKeyHash, payload.enrollmentId, payload.timestamp, payload.nonce,
    "feishu-enroll-v1"].join("\n");
}

export function proofKeyHash(proofKey) {
  return createHash("sha256").update(normalizeProofKey(proofKey)).digest("hex");
}

async function readStoredProof(file, options) {
  try {
    const raw = await fs.readFile(file, "utf8");
    if (raw.length > 16 * 1024) return "";
    const value = JSON.parse(raw);
    if (!value || value.version !== STORE_VERSION || value.deviceId !== normalizeDeviceId(options.deviceId)
      || typeof value.ciphertext !== "string" || !/^[a-f0-9]{64}$/.test(String(value.keyHash || ""))) return "";
    const proofKey = normalizeProofKey(await unprotect(value.ciphertext, options));
    if (!proofKey || proofKeyHash(proofKey) !== value.keyHash) return "";
    return proofKey;
  } catch {
    return "";
  }
}

async function withStoreLock(deviceId, options, task) {
  const root = deviceProofStoreRoot(options);
  await fs.mkdir(root, { recursive: true, mode: 0o700 });
  const lockPath = path.join(root, `${deviceId}.lock`);
  const deadline = Date.now() + Number(options.lockWaitMs || LOCK_WAIT_MS);
  while (true) {
    try {
      const handle = await fs.open(lockPath, "wx", 0o600);
      await handle.writeFile(JSON.stringify({ pid: process.pid, createdAt: Date.now() }), "utf8");
      await handle.close();
      try {
        return await task();
      } finally {
        await fs.unlink(lockPath).catch(() => {});
      }
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      await recoverStaleLock(lockPath, options);
      if (Date.now() >= deadline) throw enrollmentError("本机其他实例正在初始化飞书连接，请稍后重试。", "DEVICE_PROOF_BUSY");
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }
}

async function recoverStaleLock(lockPath, options) {
  try {
    const stat = await fs.stat(lockPath);
    if (Date.now() - stat.mtimeMs < Number(options.lockStaleMs || LOCK_STALE_MS)) return;
    await fs.unlink(lockPath);
  } catch {}
}

async function protect(value, options) {
  if (options.protectValue) return options.protectValue(value);
  assertWindows();
  return powershellDpapi("Protect", value);
}

async function unprotect(value, options) {
  if (options.unprotectValue) return options.unprotectValue(value);
  assertWindows();
  return powershellDpapi("Unprotect", value);
}

function powershellDpapi(operation, value) {
  const script = operation === "Protect"
    ? "Add-Type -AssemblyName System.Security;$v=[Console]::In.ReadToEnd();$b=[Text.Encoding]::UTF8.GetBytes($v);$p=[Security.Cryptography.ProtectedData]::Protect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);[Convert]::ToBase64String($p)"
    : "Add-Type -AssemblyName System.Security;$v=[Console]::In.ReadToEnd();$b=[Convert]::FromBase64String($v);$p=[Security.Cryptography.ProtectedData]::Unprotect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);[Text.Encoding]::UTF8.GetString($p)";
  return new Promise((resolve, reject) => {
    const child = spawn("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], {
      windowsHide: true, stdio: ["pipe", "pipe", "pipe"]
    });
    let stdout = "", stderr = "";
    const timer = setTimeout(() => child.kill(), 10_000);
    child.stdout.on("data", (chunk) => { if (stdout.length < 16 * 1024) stdout += chunk; });
    child.stderr.on("data", (chunk) => { if (stderr.length < 2048) stderr += chunk; });
    child.on("error", reject);
    child.on("close", (code) => {
      clearTimeout(timer);
      if (code !== 0 || !stdout.trim()) {
        reject(enrollmentError(`无法安全保存飞书连接证明${stderr.trim() ? `：${stderr.trim().slice(0, 120)}` : "。"}`, "DEVICE_PROOF_STORE_FAILED"));
        return;
      }
      resolve(stdout.trim());
    });
    child.stdin.end(value);
  });
}

function proofPath(deviceId, options) {
  return path.join(deviceProofStoreRoot(options), `${deviceId}.json`);
}

function normalizeDeviceId(value) {
  const deviceId = String(value || "").trim();
  if (!/^[a-f0-9]{64}$/.test(deviceId)) throw enrollmentError("本机设备标识无效。", "DEVICE_ID_INVALID");
  return deviceId;
}

function normalizeProofKey(value) {
  const key = String(value || "").trim();
  return key.length >= 32 && key.length <= 256 && /^[A-Za-z0-9_-]+$/.test(key) ? key : "";
}

function assertWindows() {
  if (process.platform !== "win32") throw enrollmentError("当前系统不支持 Windows 安全凭据存储。", "DEVICE_PROOF_STORE_UNSUPPORTED");
}

function enrollmentError(message, code) {
  return Object.assign(new Error(message), { code });
}

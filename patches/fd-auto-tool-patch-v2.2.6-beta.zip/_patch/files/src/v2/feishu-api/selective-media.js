import path from "node:path";
import { createHash } from "node:crypto";
import { createPreviewTask } from "../contracts/preview-task.js";
import { sourceOccurrenceIdsFrom } from "./source-identity.js";
import { buildPreviewSourceAudit, sourceRefsForEvent, sourceRefsForTask } from "../preview/source-audit.js";
import { detectMediaType } from "./client.js";
import { selectedFeishuMediaManifest } from "./document-reader.js";

const SUPPORTED_MIME = new Map([
  ["image/png", { kind: "image", extension: ".png" }],
  ["image/jpeg", { kind: "image", extension: ".jpg" }],
  ["image/gif", { kind: "sticker", extension: ".gif" }],
  ["image/webp", { kind: "image", extension: ".webp" }],
  ["image/avif", { kind: "image", extension: ".avif" }],
  ["video/mp4", { kind: "video", extension: ".mp4" }],
  ["video/quicktime", { kind: "video", extension: ".mov" }],
  ["video/webm", { kind: "video", extension: ".webm" }]
]);

export async function downloadSelectedFeishuMedia(result, options = {}) {
  const downloader = typeof options.downloader === "function" ? options.downloader : null;
  const entries = selectedFeishuMediaManifest(result, options.sourceIds || []);
  const selectedIds = new Set((options.sourceIds || []).map(String));
  const expectedMediaIds = new Set(entries.map((item) => item.sourceId));
  const missingFromManifest = [...selectedIds].filter((sourceId) =>
    String(sourceId).startsWith("feishu-api-") && !expectedMediaIds.has(sourceId) &&
    options.mediaSourceIds?.includes(sourceId));
  if (missingFromManifest.length) {
    throw new Error(`素材完整性检查失败：范围内原始素材未进入下载前清单：${missingFromManifest.join("、")}`);
  }

  const assets = new Map(result.assets || []);
  const rows = (result.report?.rows || []).map((row) => ({ ...row }));
  const outcomes = new Map();
  const byToken = new Map();
  for (const entry of entries) {
    if (!entry.token) {
      outcomes.set(entry.sourceId, failure(entry, entry.declaredError || "原始块缺少素材标识"));
      continue;
    }
    if (!byToken.has(entry.token)) byToken.set(entry.token, []);
    byToken.get(entry.token).push(entry);
  }

  let downloadedBytes = 0;
  let sequence = 0;
  let retryRecoveredCount = 0;
  let endpointUnavailableError = "";
  for (const [token, occurrences] of byToken) {
    const first = occurrences[0];
    const assetId = String(first.blockOrder);
    try {
      if (endpointUnavailableError) throw permanentMediaError(endpointUnavailableError);
      if (!downloader) throw permanentMediaError("飞书后台当前不支持按范围下载素材，请在预览中手动补充");
      const downloadedResult = await downloadWithRetry(() => downloader({
        documentUrl: options.documentUrl,
        revision: result.report?.revision,
        token,
        assetId,
        mediaCacheDir: options.mediaCacheDir,
        declaredName: first.declaredName,
        signal: options.signal,
        onProgress: options.onProgress
      }), options);
      const checked = validateDownloadedAsset(downloadedResult.asset, first);
      assets.set(assetId, checked);
      downloadedBytes += checked.bytes;
      if (downloadedResult.attempts > 1) retryRecoveredCount += occurrences.length;
      for (const entry of occurrences) outcomes.set(entry.sourceId, success(entry, assetId, checked, downloadedResult.attempts));
    } catch (error) {
      const message = String(error?.message || "素材下载失败").trim();
      if (error?.code === "FEISHU_MEDIA_ENDPOINT_UNAVAILABLE") endpointUnavailableError = message;
      for (const entry of occurrences) outcomes.set(entry.sourceId, failure(entry, message));
    } finally {
      sequence += 1;
      options.progress?.({ completed: sequence, total: byToken.size, bytes: downloadedBytes });
    }
  }

  for (const row of rows) {
    const outcome = outcomes.get(`feishu-api-${row.order}`);
    if (!outcome) continue;
    delete row.mediaError;
    delete row.assetId;
    delete row.mime;
    delete row.detectedMime;
    delete row.bytes;
    if (outcome.status === "downloaded") {
      row.assetId = outcome.assetId;
      row.mime = outcome.mime;
      row.detectedMime = outcome.detectedMime;
      row.bytes = outcome.bytes;
    } else {
      row.mediaError = outcome.error;
    }
  }

  const manifest = entries.map((entry) => sanitizeOutcome(outcomes.get(entry.sourceId) || failure(entry, "素材未执行下载")));
  const failed = manifest.filter((item) => item.status !== "downloaded");
  return {
    ...result,
    assets,
    report: {
      ...result.report,
      rows,
      downloadedCount: manifest.filter((item) => item.status === "downloaded").length,
      selectedMediaCount: manifest.length,
      downloadedBytes,
      retryRecoveredCount,
      manualRequiredCount: failed.length,
      mediaCompleteness: {
        ok: failed.length === 0,
        expected: manifest.length,
        downloaded: manifest.length - failed.length,
        retryRecovered: retryRecoveredCount,
        failed: failed.length
      }
    },
    selectedMediaManifest: manifest
  };
}

export function assertFeishuMediaComplete(result) {
  const manifest = Array.isArray(result?.selectedMediaManifest) ? result.selectedMediaManifest : [];
  const failed = manifest.filter((item) => item.status !== "downloaded");
  if (failed.length) {
    const details = failed.slice(0, 5).map((item) => `${item.sourceId}：${item.error || item.status}`).join("；");
    throw new Error(`素材读取未完成：范围内 ${manifest.length} 项，成功 ${manifest.length - failed.length} 项，失败 ${failed.length} 项。${details}`);
  }
  return { ok: true, count: manifest.length };
}

export function assertFeishuManifestMappedToRawEvents(result, events = []) {
  const expected = (result?.mediaManifest || []).map((item) => ({
    identity: String(item.sourceOccurrenceId || item.sourceId),
    sourceId: String(item.sourceId || "")
  }));
  const counts = new Map();
  for (const event of events) {
    const identity = String(event?.sourceOccurrenceId || event?.sourceId || "");
    counts.set(identity, Number(counts.get(identity) || 0) + 1);
  }
  const missing = expected.filter((item) => counts.get(item.identity) !== 1);
  if (missing.length) {
    throw new Error(`素材完整性检查失败：下载前原始块无法逐项对应 RawEvent：${missing.slice(0, 10)
      .map((item) => `${item.sourceId}[${item.identity}]`).join("、")}`);
  }
  return { ok: true, count: expected.length };
}

export function recoverFeishuRangeMediaPreviewTasks(rangeEvents = [], previewTasks = [], options = {}) {
  const events = Array.isArray(rangeEvents) ? rangeEvents : [];
  let tasks = Array.isArray(previewTasks) ? previewTasks.map((task) => createPreviewTask({ ...task })) : [];
  const initialAudit = buildPreviewSourceAudit(events, tasks, options.diagnostics);
  const taskIds = previewTaskSourceIds(tasks);
  const ignoredIds = intentionallyDroppedMediaSourceIds(options.diagnostics, events);
  const unresolvedIndexes = new Set(initialAudit.unresolved.map((item) => Number(item.eventIndex)));
  const missing = events.filter((event, index) => unresolvedIndexes.has(index) &&
    (isPreviewMediaEvent(event) || event?.kind === "line") && !ignoredIds.has(String(event?.sourceId || "")));
  if (!missing.length) {
    return {
      tasks,
      recovered: [],
      ignoredSourceIds: [...ignoredIds],
      degraded: !initialAudit.complete,
      audit: initialAudit,
      postRecoveryAudit: initialAudit
    };
  }

  const sourceOrder = new Map(events.map((event, index) => [String(event?.sourceId || ""), finiteOrder(event?.order, index)]));
  const recovered = [];
  for (const event of missing) {
    const sourceOccurrenceIds = sourceOccurrenceIdsFrom(event);
    const sourceAuditRefs = sourceRefsForEvent(event);
    const auditOutcome = initialAudit.unresolved.find((item) => Number(item.eventIndex) === events.indexOf(event));
    const alreadyMapped = tasks.findIndex((task) => sourceRefsForTask(task)
      .some((ref) => sourceAuditRefs.includes(ref)));
    if (alreadyMapped >= 0) {
      const current = tasks[alreadyMapped];
      const duplicateSourceOccurrence = /重复读取/.test(String(auditOutcome?.reason || ""));
      tasks[alreadyMapped] = createPreviewTask({
        ...current,
        previewError: String(event?.previewError || auditOutcome?.reason || "原文位置需要人工核对。"),
        previewWarning: duplicateSourceOccurrence
          ? "系统没有按文字、图片哈希或文件 token 自动删除；请根据原文具体位置确认。"
          : "系统已保留能够确认的内容；请对照原文位置补充缺失部分。",
        recoveryRequired: true
      });
      recovered.push({ sourceId: event.sourceId, type: current.type, duplicateSourceOccurrence });
      continue;
    }
    const eventOrder = finiteOrder(event?.order, Number.MAX_SAFE_INTEGER);
    const anchor = nearestPreviewTask(tasks, eventOrder, sourceOrder);
    const collectedSpeaker = String(event?.collectSpeaker || "").trim();
    const speakerStatus = collectedSpeaker ? "confirmed" : "unconfirmed";
    const speaker = collectedSpeaker || "说话人待确认";
    const suggestedSpeaker = speakerStatus === "unconfirmed" ? String(anchor?.speaker || "").trim() : "";
    const role = /豆妈/.test(collectedSpeaker) ? "douma" : (["douma", "tuo"].includes(anchor?.role) ? anchor.role : "tuo");
    const type = isPreviewMediaEvent(event) ? previewMediaType(event) : "text";
    const mediaPath = String(event?.mediaPath || event?.assetUrl || "").trim();
    const sourceId = String(event?.sourceId || "").trim();
    const reason = String(event?.previewError || "").trim() || (type === "text"
      ? "这段原文未能可靠归属到预览。系统已保留原文，请确认说话人、正文和顺序。"
      : mediaPath
        ? "系统已保留素材，但无法完全确认它在预览中的归属位置。请核对说话人、时间和顺序。"
        : "系统未能取得这条素材文件。请在本行更换、拖拽或粘贴素材；不需要发送时可设为不发。");
    const placeholder = createPreviewTask({
      sourceId,
      sourceOccurrenceIds,
      sourceText: event?.sourceText || "待人工确认的原始素材",
      role,
      speaker,
      sourceSpeaker: collectedSpeaker,
      speakerStatus,
      suggestedSpeaker,
      date: String(options.baseSendDate || event?.collectDate || anchor?.date || "").trim(),
      documentDate: String(event?.collectDate || anchor?.documentDate || "").trim(),
      documentTime: String(event?.collectTime || anchor?.documentTime || "").trim(),
      daySegment: Number(anchor?.daySegment || 1),
      time: String(event?.collectTime || anchor?.time || "").trim(),
      type,
      text: type === "text" ? String(event?.text || event?.sourceText || "") : "",
      mediaPath: type === "text" ? "" : mediaPath,
      sourceUrl: String(event?.sourceUrl || event?.assetUrl || "").trim(),
      skip: false,
      order: tasks.length + 1,
      interactionGroup: String(anchor?.interactionGroup || ""),
      continueMarker: false,
      cleanSpeaker: speaker.replace(/\s+/g, ""),
      previewError: reason,
      previewWarning: suggestedSpeaker
        ? `此行为系统兜底恢复项；相邻条目说话人为“${suggestedSpeaker}”，仅供参考，必须人工确认。`
        : "此行为系统兜底恢复项，必须人工确认后才能进入正式创建。",
      recoveryRequired: true,
      repairsSourceIds: sourceId,
      importResolutionConfirmed: false
    });
    insertTaskBySourceOrder(tasks, placeholder, eventOrder, sourceOrder);
    taskIds.add(sourceId);
    recovered.push({ sourceId, sourceOccurrenceIds, type, mediaPath, speaker, speakerStatus, suggestedSpeaker, time: placeholder.time });
  }
  tasks = tasks.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
  const postRecoveryAudit = buildPreviewSourceAudit(events, tasks, options.diagnostics);
  return {
    tasks,
    recovered,
    ignoredSourceIds: [...ignoredIds],
    degraded: recovered.length > 0 || !initialAudit.complete,
    audit: initialAudit,
    postRecoveryAudit
  };
}

export function assertFeishuRangeMediaMappedToPreview(rangeEvents = [], previewTasks = [], options = {}) {
  const expected = rangeEvents.filter((event) => ["image", "sticker", "video"].includes(event?.kind));
  const taskIds = previewTaskSourceIds(previewTasks);
  const taskOccurrences = new Set((Array.isArray(previewTasks) ? previewTasks : []).flatMap((task) => sourceOccurrenceIdsFrom(task)));
  const ignoredIds = intentionallyDroppedMediaSourceIds(options.diagnostics, rangeEvents);
  const missing = expected.filter((event) => {
    const occurrenceIds = sourceOccurrenceIdsFrom(event);
    const mapped = occurrenceIds.length
      ? occurrenceIds.every((sourceOccurrenceId) => taskOccurrences.has(sourceOccurrenceId))
      : taskIds.has(String(event.sourceId));
    return !mapped && !ignoredIds.has(String(event.sourceId));
  });
  if (missing.length) {
    throw new Error(`素材完整性检查失败：范围内素材未进入最终 PreviewTask：${missing.slice(0, 10).map((event) => event.sourceId).join("、")}`);
  }
  return { ok: true, count: expected.length, ignored: expected.filter((event) => ignoredIds.has(String(event.sourceId))).length };
}

function previewTaskSourceIds(tasks = []) {
  return new Set((Array.isArray(tasks) ? tasks : []).flatMap((task) =>
    String(task?.sourceId || "").split(",").map((value) => value.trim()).filter(Boolean)));
}

function intentionallyDroppedMediaSourceIds(diagnostics = [], events = []) {
  const allowedCodes = new Set([
    "dropped_sticker_image_echo",
    "dropped_video_cover_echo",
    "dropped_duplicate_media_echo",
    "dropped_detached_floating_video_player",
    "dropped_detached_tiny_top_ui_media",
    "dropped_repeated_floating_video_player"
  ]);
  const apiSourceIds = new Set((Array.isArray(events) ? events : [])
    .filter((event) => sourceOccurrenceIdsFrom(event).length > 0)
    .map((event) => String(event?.sourceId || "")));
  return new Set((Array.isArray(diagnostics) ? diagnostics : [])
    .filter((item) => allowedCodes.has(String(item?.code || "")) &&
      (!apiSourceIds.has(String(item?.sourceId || "")) || item?.sameSourceOccurrence === true))
    .flatMap((item) => String(item?.sourceId || "").split(","))
    .map((value) => value.trim())
    .filter(Boolean));
}

function isPreviewMediaEvent(event) {
  return ["image", "sticker", "video", "unknown-media"].includes(String(event?.kind || ""));
}

function previewMediaType(event) {
  const kind = String(event?.kind || "");
  return ["image", "sticker", "video"].includes(kind) ? kind : "unknown-media";
}

function finiteOrder(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function taskSourceOrder(task, sourceOrder) {
  const orders = String(task?.sourceId || "").split(",")
    .map((sourceId) => sourceOrder.get(sourceId.trim()))
    .filter(Number.isFinite);
  return orders.length ? Math.min(...orders) : null;
}

function nearestPreviewTask(tasks, eventOrder, sourceOrder) {
  let nearest = null;
  let nearestDistance = Number.POSITIVE_INFINITY;
  for (const task of tasks) {
    const order = taskSourceOrder(task, sourceOrder);
    if (!Number.isFinite(order)) continue;
    const distance = Math.abs(order - eventOrder);
    if (distance < nearestDistance) {
      nearest = task;
      nearestDistance = distance;
    }
  }
  return nearest;
}

function insertTaskBySourceOrder(tasks, task, eventOrder, sourceOrder) {
  const index = tasks.findIndex((candidate) => {
    const order = taskSourceOrder(candidate, sourceOrder);
    return Number.isFinite(order) && order > eventOrder;
  });
  if (index < 0) tasks.push(task);
  else tasks.splice(index, 0, task);
}

function validateDownloadedAsset(asset, entry) {
  const filePath = String(asset?.filePath || "");
  const head = Buffer.isBuffer(asset?.head) ? asset.head : Buffer.from(asset?.head || []);
  const detectedMime = detectMediaType(head, "application/octet-stream");
  const declaredMime = String(asset?.mime || "").split(";", 1)[0].trim().toLowerCase();
  const mime = detectedMime !== "application/octet-stream" ? detectedMime : declaredMime;
  const supported = SUPPORTED_MIME.get(mime);
  if (!filePath || !Number.isFinite(Number(asset?.bytes)) || Number(asset.bytes) <= 0 || !supported) {
    throw new Error(`素材文件未完整落盘或实际类型不受支持（${mime || "未知"}）`);
  }
  const compatibleKind = entry.declaredKind === "unknown" || entry.declaredKind === supported.kind ||
    (entry.declaredKind === "image" && supported.kind === "sticker");
  if (!compatibleKind) {
    throw new Error(`素材类型冲突：原始块声明为${entry.declaredKind}，文件内容为${supported.kind}`);
  }
  return {
    filePath,
    mime,
    detectedMime,
    bytes: Number(asset.bytes),
    sha256: String(asset.sha256 || ""),
    kind: supported.kind
  };
}

function success(entry, assetId, asset, attempts = 1) {
  return { ...entry, status: "downloaded", assetId, mime: asset.mime, detectedMime: asset.detectedMime,
    bytes: asset.bytes, sha256: asset.sha256, kind: asset.kind, fileName: path.basename(asset.filePath),
    attempts, recoveredAfterRetry: attempts > 1 };
}

function failure(entry, error) {
  return { ...entry, status: "failed", error: String(error || "素材下载失败") };
}

function sanitizeOutcome(outcome) {
  const { token, ...safe } = outcome;
  return { ...safe, tokenRef: token ? createHash("sha256").update(token).digest("hex").slice(0, 16) : "" };
}

async function downloadWithRetry(download, options = {}) {
  const sleep = options.sleep || ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)));
  let lastError;
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      return { asset: await download(), attempts: attempt };
    } catch (error) {
      lastError = error;
      if (attempt >= 2 || !isRetryableMediaError(error) || options.signal?.aborted) throw error;
      await sleep(Math.max(0, Number(options.retryDelayMs ?? 250)));
    }
  }
  throw lastError;
}

function isRetryableMediaError(error) {
  const code = String(error?.code || "").toUpperCase();
  if ([
    "FEISHU_UPSTREAM_TIMEOUT", "FEISHU_MEDIA_FAILED", "FEISHU_MEDIA_INCOMPLETE",
    "FEISHU_MEDIA_HASH_MISMATCH", "HEAVY_OPERATION_BUSY", "ECONNRESET", "ETIMEDOUT"
  ].includes(code)) return true;
  const message = String(error?.message || error || "");
  return /超时|timeout|连接中断|terminated|interrupted|传输不完整|哈希|hash|限流|繁忙|busy|429|\b5\d\d\b/i.test(message);
}

function permanentMediaError(message) {
  const error = new Error(message);
  error.code = "FEISHU_MEDIA_PERMANENT";
  return error;
}


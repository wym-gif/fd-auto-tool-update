import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import {
  deleteIntervalPreset,
  loadConsoleSettings,
  loadIntervalPresets,
  saveConsoleSettings,
  saveIntervalPreset
} from "./settings.js";
import { createConsoleState } from "./state.js";
import { createConsoleWorkflow } from "./workflow.js";
import {
  assertCompanyAccessAllowed,
  confirmLicenseOperator,
  getLicenseEmployeeDirectory,
  getLicenseDiagnostics,
  getLicenseStatus,
  submitLicenseHeartbeat,
  submitLicenseOpsEvent,
  submitLicenseRequest,
  submitLicenseSupportReport
} from "../license/license-manager.js";
import {
  createStableBackup,
  getVersionStatus,
  openBackupDir,
  prepareLatestVersionUpdate,
  rollbackToPreviousStableVersion,
  updateToLatestVersion
} from "../version/version-manager.js";
import {
  ensureV2ControlledBrowser,
  loadV2ControlledBrowserState
} from "../browser/controlled-browser.js";
import { appendInstanceParams, createInstanceConfig, saveInstanceName } from "../runtime/instance-config.js";
import {
  deleteTuoRosterLibraryItem,
  listTuoRosterLibrary,
  renameTuoRosterLibraryItem,
  resolveTuoRosterLibraryItem,
  saveTuoRosterToLibrary
} from "../tuo/tuo-roster-library.js";
import {
  deleteCmsConfigLibraryItem,
  listCmsConfigLibrary,
  renameCmsConfigLibraryItem,
  resolveCmsConfigLibraryItem,
  saveCmsConfigToLibrary
} from "../cms/cms-config-library.js";
import { createCmsConfigFormSnapshot } from "../cms/cms-config-form.js";
import { buildCmsConfigSnapshot } from "../cms/cms-config-snapshot.js";
import {
  buildCmsRecoverySummary,
  resolveCmsRecoveryDecision
} from "../cms/recovery-plan.js";
import { robotStrategyForCreateRun } from "../cms/create-preflight.js";
import {
  cleanupExpiredPreviewMedia,
  PREVIEW_MEDIA_CLEANUP_INTERVAL_MS
} from "../preview/preview-recovery.js";

export async function createConsoleServer(projectRoot, options = {}) {
  const licenseOptions = pickLicenseOptions(options);
  const instanceConfig = options.instanceConfig || createInstanceConfig(projectRoot, {
    instance: options.instance,
    port: options.port
  });
  const settingsOptions = { instanceId: instanceConfig.id };
  const launchSessionId = randomUUID();
  const loadSettings = () => loadConsoleSettings(projectRoot, settingsOptions);
  const saveSettings = (settings) => saveConsoleSettings(projectRoot, settings, settingsOptions);
  const state = createConsoleState();
  let operatorSession = null;
  const previewRecoveryOptions = {
    now: options.previewRecoveryNow,
    retentionMs: options.previewRecoveryRetentionMs
  };
  const workflow = createConsoleWorkflow({
    projectRoot,
    state,
    licenseOptions,
    instanceConfig,
    operatorProvider: () => operatorSession,
    feishuApiReader: options.feishuApiReader,
    feishuApiMediaDownloader: options.feishuApiMediaDownloader,
    feishuGateway: options.feishuGateway,
    previewPageOpener: options.previewPageOpener,
    workflowHooks: options.workflowHooks,
    previewRecoveryOptions
  });
  const serviceInfo = await buildConsoleServiceInfo(projectRoot, instanceConfig);
  let lastResult = null;
  let latestDiagnosticReport = null;
  let ignoredRestoreRunId = "";
  let previousCompletedRunSnapshot = null;
  let closing = false;
  let backgroundUpdatePreparePromise = null;
  const cmsStartRequests = new Map();
  const cmsStartAcceptances = new Map();
  const cmsStartAdmissionQueues = new Map();
  let stopLicenseHeartbeat = () => {};
  let stopPreviewMediaCleanup = () => {};
  const removeProcessGuards = installConsoleProcessGuards({
    state,
    setLastResult(result) {
      lastResult = result;
    }
  });

  const server = http.createServer((req, res) => {
    handleRequest(req, res).catch((error) => {
      sendJson(res, error?.statusCode || 500, {
        ok: false,
        code: error?.code || "",
        error: error?.message || String(error),
        license: error?.license,
        request: error?.cmsStartRequest,
        recovery: error?.cmsRecoverySummary
      });
    });
  });

  async function handleRequest(req, res) {
    const url = new URL(req.url || "/", "http://127.0.0.1");
    if (req.method === "GET" && url.pathname === "/") {
      const reset = url.searchParams.get("startup") === "1"
        ? resetStartupConsoleStateOnOpen(state, workflow)
        : resetTerminalConsoleStateOnOpen(state);
      if (reset) lastResult = null;
      sendHtml(res, renderConsolePage({ instanceConfig }));
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/settings") {
      sendJson(res, 200, { ok: true, settings: await loadSettings() });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/settings") {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, settings: await saveSettings(body.settings || body) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster/upload") {
      const body = await readJsonBody(req);
      const result = await saveUploadedTuoRoster(projectRoot, body);
      sendJson(res, 200, { ok: true, ...result });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/tuo-roster-library") {
      sendJson(res, 200, { ok: true, items: await listTuoRosterLibrary(projectRoot) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/cms-config-library") {
      sendJson(res, 200, { ok: true, items: await listCmsConfigLibrary(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/cms-config-library/save") {
      const body = await readJsonBody(req);
      const settings = await saveSettings(body.settings || {});
      const targetRunDir = body.runDir || state.snapshot().runDir;
      const snapshot = body.form
        ? createCmsConfigFormSnapshot({
            name: body.name,
            settings,
            form: body.form,
            sourceRunId: runIdFromRunDir(targetRunDir)
          })
        : await buildCmsConfigSnapshotAfterRefresh({
            workflow,
            state,
            runDir: targetRunDir,
            settings,
            name: body.name
          });
      const item = await saveCmsConfigToLibrary(projectRoot, snapshot, { id: body.id, name: body.name });
      const currentSettings = await loadSettings();
      const isEditingExisting = Boolean(String(body.id || "").trim());
      const shouldActivateSavedItem = !isEditingExisting || currentSettings.cmsConfigId === item.id;
      const nextSettings = shouldActivateSavedItem
        ? await saveSettings({ ...currentSettings, cmsConfigId: item.id })
        : currentSettings;
      sendJson(res, 200, { ok: true, item, items: await listCmsConfigLibrary(projectRoot), settings: nextSettings });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/cms-config-library/use") {
      const body = await readJsonBody(req);
      const item = await resolveCmsConfigLibraryItem(projectRoot, body.id);
      const nextSettings = await saveSettings({ ...(await loadSettings()), cmsConfigId: item.id });
      sendJson(res, 200, { ok: true, item, settings: nextSettings });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/cms-config-library/rename") {
      const body = await readJsonBody(req);
      const item = await renameCmsConfigLibraryItem(projectRoot, body.id, body.name);
      sendJson(res, 200, { ok: true, item, items: await listCmsConfigLibrary(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/cms-config-library/delete") {
      const body = await readJsonBody(req);
      const deleted = await deleteCmsConfigLibraryItem(projectRoot, body.id);
      const current = await loadSettings();
      const settings = current.cmsConfigId === deleted.id
        ? await saveSettings({ ...current, cmsConfigId: "" })
        : current;
      sendJson(res, 200, { ok: true, deleted, items: await listCmsConfigLibrary(projectRoot), settings });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster-library/save") {
      const body = await readJsonBody(req);
      const item = await saveTuoRosterToLibrary(projectRoot, body);
      sendJson(res, 200, { ok: true, item, items: await listTuoRosterLibrary(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster-library/use") {
      const body = await readJsonBody(req);
      const item = await resolveTuoRosterLibraryItem(projectRoot, body.id);
      const settings = await saveSettings({
        ...(await loadSettings()),
        tuoRosterPath: item.filePath,
        tuoRosterScopeId: item.scopeId || "",
        robotStrategy: "precise"
      });
      sendJson(res, 200, { ok: true, item, settings });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster-library/rename") {
      const body = await readJsonBody(req);
      const item = await renameTuoRosterLibraryItem(projectRoot, body.id, body.name);
      sendJson(res, 200, { ok: true, item, items: await listTuoRosterLibrary(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster-library/delete") {
      const body = await readJsonBody(req);
      const deleted = await deleteTuoRosterLibraryItem(projectRoot, body.id);
      sendJson(res, 200, { ok: true, deleted, items: await listTuoRosterLibrary(projectRoot) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/interval-presets") {
      sendJson(res, 200, { ok: true, presets: await loadIntervalPresets(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/interval-presets/save") {
      const body = await readJsonBody(req);
      const result = await saveIntervalPreset(projectRoot, body.preset || body);
      sendJson(res, 200, { ok: true, ...result });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/interval-presets/delete") {
      const body = await readJsonBody(req);
      const result = await deleteIntervalPreset(projectRoot, body.id);
      sendJson(res, 200, { ok: true, ...result });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/status") {
      const runId = url.searchParams.get("runId") || "";
      const snapshot = state.snapshot();
      if (runId && lastResult?.cancelled === true && snapshot.status === "ready" && !snapshot.runDir) {
        ignoredRestoreRunId = runId;
        lastResult = null;
      } else if (runId && runId === ignoredRestoreRunId && snapshot.status === "ready" && !snapshot.runDir) {
        lastResult = null;
      } else if (runId && !workflow.isRunning?.() && snapshot.status === "ready" && !snapshot.runDir) {
        const settings = await loadSettings();
        const restored = await workflow.restorePreviewRunState?.(runId, settings).catch((error) => ({
          ok: false,
          error: error?.message || String(error)
        }));
        if (restored?.ok) lastResult = restored;
      }
      const current = state.snapshot();
      const currentRunId = current.runDir ? path.basename(current.runDir) : "";
      const requestKey = `${instanceConfig.id || "default"}:${currentRunId}`;
      let cmsStartRequest = currentRunId
        ? (cmsStartRequests.get(requestKey) || await readCmsStartRequest(current.runDir))
        : null;
      if (cmsStartRequest) {
        cmsStartRequest = await reconcileCmsStartRequestRecord({
          runDir: current.runDir,
          record: cmsStartRequest,
          workflow,
          snapshot: current,
          launchSessionId,
          activeAcceptance: cmsStartAcceptances.get(requestKey)
        });
        cmsStartRequests.set(requestKey, cmsStartRequest);
      }
      sendJson(res, 200, {
        ok: true,
        state: { ...current, runId: currentRunId },
        runIdentity: current.runDir ? { runId: currentRunId, runDir: current.runDir, runGeneration: current.runGeneration } : null,
        cmsStartRequest,
        lastResult
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/status/clear-stale") {
      if (workflow.isRunning?.()) {
        sendJson(res, 200, { ok: true, cleared: false, state: state.snapshot(), reason: "当前后台流程仍在运行，不能清理状态。" });
        return;
      }
      const before = state.snapshot();
      if (!isClearableStaleConsoleState(before)) {
        sendJson(res, 200, { ok: true, cleared: false, state: before, reason: "当前没有需要清理的旧状态。" });
        return;
      }
      lastResult = null;
      sendJson(res, 200, {
        ok: true,
        cleared: true,
        state: state.resetForStartup?.("刷新运行状态：已清理旧状态，预览文件仍可恢复") || state.snapshot()
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/next-run") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      if (workflow.isCmsExecutionLocked?.()) {
        sendJson(res, 409, { ok: false, error: "当前创建轮次仍在等待明确结果，不能开始下一轮或替换最终预览。", state: state.snapshot() });
        return;
      }
      const beforeNextRun = state.snapshot();
      if (beforeNextRun.runDir && (beforeNextRun.lastCompletedIndex || beforeNextRun.successCount || beforeNextRun.status === "completed")) {
        previousCompletedRunSnapshot = {
          runDir: beforeNextRun.runDir,
          previewPath: beforeNextRun.previewPath,
          lastCompletedIndex: beforeNextRun.lastCompletedIndex,
          logs: beforeNextRun.logs,
          status: beforeNextRun.status
        };
      }
      ignoredRestoreRunId = runIdFromRunDir(beforeNextRun.runDir);
      lastResult = null;
      sendJson(res, 200, { ok: true, state: state.resetForNextRun?.() || state.snapshot(), clearedRunId: ignoredRestoreRunId });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/preview/restore-candidate") {
      sendJson(res, 200, {
        ok: true,
        candidate: await workflow.getRestorablePreview(),
        locked: Boolean(workflow.isCmsExecutionLocked?.() || workflow.isRunning?.())
      });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/preview-library") {
      sendJson(res, 200, { ok: true, items: await workflow.getPreviewLibrary() });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/preview-library/shared") {
      const result = await workflow.getSharedPreviewLibrary();
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/open") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const body = await readJsonBody(req);
      const configMode = body.configMode === "current" ? "current" : "saved";
      const settings = configMode === "current"
        ? await saveSettings(body.settings || {})
        : (body.settings || {});
      const result = await workflow.openLibraryPreview(body.id, {
        ...settings,
        libraryConfigMode: configMode,
        reassignPreciseTuo: body.reassignPreciseTuo === true
      });
      sendJson(res, result.ok ? 200 : 404, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/rename") {
      const body = await readJsonBody(req);
      const result = await workflow.renameLibraryPreview(body.id, body.name);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/move") {
      const body = await readJsonBody(req);
      const result = await workflow.moveLibraryPreview(body.id, {
        direction: body.direction,
        targetId: body.targetId,
        position: body.position
      });
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/prepare-shared-upload") {
      const body = await readJsonBody(req);
      const result = await workflow.prepareSharedLibraryUpload(body.id);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/upload-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.uploadSharedLibraryPreview(body.id, { groupName: body.groupName });
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/export-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.exportSharedLibraryPreview(body.id);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/import-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.importSharedLibraryPreviewPackage(body);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/import-shared-file") {
      const fileName = String(url.searchParams.get("fileName") || "");
      const transfer = await receiveSharedPackageFile(projectRoot, instanceConfig.id, req, fileName);
      try {
        const result = await workflow.importSharedLibraryPreviewFile({ fileName, filePath: transfer.filePath });
        sendJson(res, result.ok ? 200 : 400, result);
      } finally {
        await fs.rm(transfer.dir, { recursive: true, force: true }).catch(() => {});
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/download-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.downloadSharedLibraryPreview(body.cloudId);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/download-shared-stream") {
      const body = await readJsonBody(req);
      const controller = new AbortController();
      res.on("close", () => {
        if (!res.writableEnded) controller.abort();
      });
      res.writeHead(200, {
        "Content-Type": "application/x-ndjson; charset=utf-8",
        "Cache-Control": "no-store",
        "Connection": "close"
      });
      const result = await workflow.downloadSharedLibraryPreview(body.cloudId, {
        signal: controller.signal,
        onProgress: (progress) => writeNdjson(res, { type: "progress", ...progress })
      });
      writeNdjson(res, { type: "result", ...result });
      res.end();
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/delete-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.deleteSharedLibraryPreview(body.cloudId);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/delete") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const body = await readJsonBody(req);
      const result = await workflow.deleteLibraryPreview(body.id);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/continue-candidate") {
      const candidate = await buildContinueCandidate(state.snapshot());
      sendJson(res, candidate.ok ? 200 : 404, candidate);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/previous-success-tuo-cooldown") {
      const snapshot = state.snapshot();
      const candidateSource = snapshot.runDir || snapshot.lastCompletedIndex ? snapshot : (previousCompletedRunSnapshot || snapshot);
      sendJson(res, 200, { ok: true, candidate: await buildPreviousSuccessTuoCooldownCandidate(candidateSource) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview/restore") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const body = await readJsonBody(req);
      const settings = await saveSettings(body.settings || body);
      const result = await workflow.restoreLatestPreview(settings, body.runId || "");
      sendJson(res, result.ok ? 200 : 404, result);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/service-info") {
      sendJson(res, 200, { ok: true, service: serviceInfo });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/instance-name") {
      if (!instanceConfig.enabled || !instanceConfig.id) {
        sendJson(res, 400, { ok: false, error: "默认入口没有可编辑的实例名称。" });
        return;
      }
      const body = await readJsonBody(req);
      const saved = await saveInstanceName(projectRoot, instanceConfig.id, body.name);
      instanceConfig.label = saved.label;
      serviceInfo.instanceLabel = saved.label;
      sendJson(res, 200, { ok: true, instance: saved });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/license/status") {
      sendJson(res, 200, { ok: true, license: await getLicenseStatus(projectRoot, licenseOptions) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/license/diagnostics") {
      sendJson(res, 200, { ok: true, diagnostics: await getLicenseDiagnostics(projectRoot, {
        ...licenseOptions,
        forceRefresh: url.searchParams.get("refresh") === "1"
      }) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/license/request") {
      sendJson(res, 200, { ok: true, request: await submitLicenseRequest(projectRoot, licenseOptions) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/operator/directory") {
      const directory = await getLicenseEmployeeDirectory(projectRoot, licenseOptions);
      sendJson(res, directory.ok ? 200 : 403, directory);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/operator/status") {
      sendJson(res, 200, { ok: true, employee: operatorSession?.employee || null });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/operator/login") {
      const body = await readJsonBody(req);
      const confirmed = await confirmLicenseOperator(projectRoot, body.employeeId, body.pin, {
        ...licenseOptions, instanceId: instanceConfig.id || ""
      });
      if (confirmed.ok) {
        operatorSession = { operatorToken: confirmed.operatorToken, employee: confirmed.employee };
        await submitLicenseOpsEvent(projectRoot, {
          ...licenseOptions, ...operatorSession, instanceId: instanceConfig.id || "", launchSessionId,
          event: { eventId: `open:${launchSessionId}`, type: "program_opened", status: "running", source: "console" }
        }).catch(() => {});
      }
      sendJson(res, confirmed.ok ? 200 : 403, { ok: confirmed.ok, employee: confirmed.employee, message: confirmed.message });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/operator/logout") {
      operatorSession = null;
      sendJson(res, 200, { ok: true, message: "已清除当前员工确认。" });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/support/report") {
      const body = await readJsonBody(req);
      const support = buildSupportReportPayload(body.support || {}, state.snapshot(), lastResult);
      latestDiagnosticReport = { ...support, recordedAt: new Date().toISOString() };
      const report = await submitLicenseSupportReport(projectRoot, { ...licenseOptions, instanceId: instanceConfig.id || "", support });
      sendJson(res, report.ok ? 200 : 400, { ok: report.ok, report, message: report.message });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/support/diagnostic") {
      const body = await readJsonBody(req);
      latestDiagnosticReport = {
        ...buildSupportReportPayload(body.support || {}, state.snapshot(), lastResult),
        recordedAt: new Date().toISOString()
      };
      sendJson(res, 200, { ok: true, message: "诊断已记录。" });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/version/status") {
      sendJson(res, 200, { ok: true, version: await getVersionStatus(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/backup") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能创建版本备份。" });
        return;
      }
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, result: await createStableBackup(projectRoot, backupOptions(body)) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/update") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能更新版本。" });
        return;
      }
      const body = await readJsonBody(req);
      const result = await updateToLatestVersion(projectRoot, versionActionOptions(body));
      state.log("版本管理：已更新到最新版本，正在重启控制台服务。");
      sendJson(res, 200, { ok: true, result, message: "已更新，控制台服务将重启。" });
      scheduleConsoleRestart(projectRoot, closeServer, instanceConfig);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/prepare-update") {
      await readJsonBody(req);
      if (backgroundUpdatePreparePromise) {
        sendJson(res, 202, { ok: true, preparing: true, message: "后台正在下载新版本。" });
        return;
      }
      backgroundUpdatePreparePromise = prepareLatestVersionUpdate(projectRoot, versionActionOptions({}))
        .then((result) => {
          if (result.ok && result.prepared) state.log(`版本管理：新版本 ${result.latestVersion || ""} 已下载好，下次启动会自动更新。`);
          else if (result.ok && result.alreadyLatest) state.log("版本管理：后台检查完成，当前已是最新版本。");
          else state.log("版本管理：后台下载更新失败：" + (result.error || "未知错误"));
          return result;
        })
        .catch((error) => {
          const result = { ok: false, error: error?.message || String(error) };
          state.log("版本管理：后台下载更新失败：" + result.error);
          return result;
        })
        .finally(() => {
          backgroundUpdatePreparePromise = null;
        });
      sendJson(res, 202, { ok: true, preparing: true, message: "已开始后台下载新版本，不影响当前操作。" });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/rollback") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能回退版本。" });
        return;
      }
      const body = await readJsonBody(req);
      const result = await rollbackToPreviousStableVersion(projectRoot, versionActionOptions(body));
      state.log(`版本管理：已回退到 ${result.rolledBackTo}，正在重启控制台服务。`);
      sendJson(res, 200, { ok: true, result, message: `已回退到 ${result.rolledBackTo}，控制台服务将重启。` });
      scheduleConsoleRestart(projectRoot, closeServer, instanceConfig);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/open-backup-dir") {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, result: await openBackupDir(projectRoot, backupOptions(body)) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/browser-state") {
      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const browserState = await loadV2ControlledBrowserState(projectRoot, config, {
        runsDir: instanceConfig.runsDir,
        port: instanceConfig.cmsDebugPort
      });
      sendJson(res, 200, {
        ok: true,
        controlled: Boolean(browserState.cdpUrl),
        cdpUrl: browserState.cdpUrl || "",
        profileDir: browserState.profileDir || "",
        requestedProfileDir: browserState.requestedProfileDir || "",
        browserKind: browserState.browserKind || "",
        browserVersion: browserState.browserVersion || "",
        browserComponentStatus: browserState.browserComponentStatus || "",
        browserComponentError: browserState.browserComponentError || "",
        browserFallbackUsed: browserState.browserFallbackUsed === true,
        tabDisplayStatus: browserState.tabDisplayExtensionStatus || "unknown",
        tabDisplayReady: browserState.tabDisplayExtensionConfigured === true,
        tabDisplayError: browserState.tabDisplayExtensionError || "",
        tabDisplayBridgeVersion: browserState.tabDisplayBridgeVersion || ""
      });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/feishu-connection") {
      const result = await workflow.getFeishuConnectionStatus();
      sendJson(res, 200, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/feishu-oauth/start") {
      const result = await workflow.startFeishuOAuth();
      sendJson(res, 200, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/feishu-metadata") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
      const result = await workflow.readFeishuApiMetadata({ documentUrl: body.documentUrl });
      sendJson(res, 200, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/feishu-title") {
      await readJsonBody(req);
      sendJson(res, 410, { ok: false, code: "source_mode_retired", error: "飞书链接读取入口已停用，API 链接会自动读取标题。" });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/heading-structure") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
      const document = body.document || {};
      if (document.mode !== "feishu-api") {
        if (document && typeof document === "object") document.appSecret = "";
        sendJson(res, 410, { ok: false, code: "source_mode_retired", error: "浏览器目录读取入口已停用。请使用飞书 API 读取标题结构。" });
        return;
      }
      const result = await workflow.readFeishuApiHeadingStructure(document);
      sendJson(res, result.statusCode || (result.ok ? 200 : 400), result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/control") {
      const body = await readJsonBody(req);
      const action = String(body.action || "").trim();
      if (action === "stop" && workflow.cancelCurrentRun) {
        const cancelled = await workflow.cancelCurrentRun("stop");
        sendJson(res, cancelled.completed ? 200 : 202, {
          ...cancelled,
          message: cancelled.completed ? "本轮已停止。" : "正在取消本轮，后台退出后会自动显示已停止。"
        });
        return;
      }
      const result = applyControlAction(state, action, body);
      sendJson(res, result.statusCode || (result.ok ? 200 : 409), result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview/edit-after-error") {
      await readJsonBody(req);
      const result = await workflow.returnToPreviewAfterTaskError();
      sendJson(res, 200, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview/edit-expired-schedule") {
      await readJsonBody(req);
      const result = await workflow.openExpiredScheduleEditor();
      sendJson(res, 200, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/generate-preview") {
      await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
      sendJson(res, 410, {
        ok: false,
        code: "source_mode_retired",
        error: "飞书链接滚动采集入口已停用。请使用“飞书 API 读取”或“直接粘贴内容”。"
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/import-document-preview") {
      const body = await readJsonBody(req, { limitBytes: 40 * 1024 * 1024 });
      await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
      const documentMode = String(body.document?.mode || "");
      if (!["feishu-api", "document-paste"].includes(documentMode)) {
        if (body.document && typeof body.document === "object") body.document.appSecret = "";
        sendJson(res, 410, {
          ok: false,
          code: "source_mode_retired",
          error: documentMode === "feishu-download"
            ? "飞书自动下载 Word 入口已停用。请使用“飞书 API 读取”或“直接粘贴内容”。"
            : "这个内容读取入口已停用。请回到控制台选择“飞书 API 读取”或“直接粘贴内容”。"
        });
        return;
      }
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      if (!body.forceRegeneratePreview && await workflow.previewHasUnsavedChanges?.()) {
        sendJson(res, 409, {
          ok: false,
          code: "preview_dirty",
          error: "已有预览页有未保存修改。确认放弃这些修改并重新生成预览？"
        });
        return;
      }
      const previousSettings = await loadSettings();
      const generationSettings = {
        ...(body.settings || {}),
        robotStrategy: body.settings?.robotStrategy === "fixed" ? "precise" : body.settings?.robotStrategy
      };
      await workflow.validatePreviewGenerationSettings(generationSettings);
      const settings = await saveSettings(generationSettings);
      lastResult = null;
      state.log("页面请求：导入文档生成预览");
      workflow.importDocumentPreview(body.document || {}, {
        ...settings,
        previousFeishuUrl: previousSettings.feishuUrl || "",
        previousSuccessTuoCooldown: body.previousSuccessTuoCooldown === true,
        previousSuccessTuoNicknames: Array.isArray(body.previousSuccessTuoNicknames)
          ? body.previousSuccessTuoNicknames
          : []
      }).then((result) => {
        lastResult = result;
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("导入文档", lastResult.error);
      });
      sendJson(res, 202, { ok: true, state: state.snapshot() });
      return;
    }
    if (req.method === "POST" && (url.pathname === "/api/abandon-current-run" || url.pathname === "/api/abandon-and-regenerate")) {
      await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
      if (workflow.isRunning?.()) {
        const cancellation = await workflow.cancelCurrentRun?.("abandon");
        sendJson(res, 202, {
          ok: true,
          accepted: true,
          message: "正在取消并结束本轮；后台退出后会自动回到设置，无需重复点击。",
          state: cancellation?.state || state.snapshot()
        });
        return;
      }
      lastResult = null;
      const completed = await workflow.cancelCurrentRun?.("abandon");
      state.log("页面请求：结束本轮，已回到设置阶段");
      sendJson(res, 200, { ok: true, ...(completed || {}), state: state.snapshot() });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/prepare-cms") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "prepare-cms", licenseOptions);
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const settings = await saveSettings(body.settings || body);
      const repairCmsRole = body.repairCmsRole === "tuo" || body.repairCmsRole === "douma" ? body.repairCmsRole : "";
      lastResult = null;
      state.log("页面请求：进入云中客设置");
      workflow.prepareCms({ ...settings, runDir: state.snapshot().runDir, repairCmsRole }).then((result) => {
        lastResult = result;
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("CMS 准备", lastResult.error);
      });
      sendJson(res, 202, { ok: true, state: state.snapshot() });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/start-cms-recovery") {
      const requestedRunId = String(url.searchParams.get("runId") || "").slice(0, 96);
      const requestId = normalizeCmsStartRequestId(url.searchParams.get("requestId"));
      const snapshot = state.snapshot();
      const runDir = snapshot.runDir || "";
      const runId = runDir ? path.basename(runDir) : "";
      if (!runDir || !runId || requestedRunId !== runId) {
        sendJson(res, 409, { ok: false, code: "CMS_RECOVERY_RUN_MISMATCH", error: "当前页面对应的运行记录已变化，不能读取另一轮续发内容。" });
        return;
      }
      const record = await readCmsStartRequest(runDir);
      if (!record || record.requestId !== requestId) {
        sendJson(res, 409, { ok: false, code: "CMS_RECOVERY_NOT_ALLOWED", error: "当前创建请求已经变化，不能沿用旧的续发选择。", request: record || null });
        return;
      }
      const recovery = await buildCmsRecoverySummary(runDir, record);
      if (record.status !== "unknown" && !recovery.hasHistory) {
        sendJson(res, 409, { ok: false, code: "CMS_RECOVERY_NOT_REQUIRED", error: "当前预览没有历史逐条创建记录，可以正常开始创建。", request: record });
        return;
      }
      sendJson(res, 200, { ok: true, recovery });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/start-cms") {
      const body = await readJsonBody(req);
      const requestId = normalizeCmsStartRequestId(body.requestId) || randomUUID();
      const runDir = state.snapshot().runDir || "";
      const runId = String(body.runId || (runDir ? path.basename(runDir) : "")).slice(0, 96);
      const requestKey = `${instanceConfig.id || "default"}:${runId}`;
      const activeBeforeAdmission = cmsStartAcceptances.get(requestKey);
      if (activeBeforeAdmission) {
        const activeRecord = cmsStartRequests.get(requestKey) || await readCmsStartRequest(runDir);
        if (activeBeforeAdmission.requestId === requestId && activeRecord?.requestId === requestId) {
          sendJson(res, cmsStartRequestHttpStatus(activeRecord), { ok: true, request: activeRecord, state: state.snapshot() });
          return;
        }
        const error = new Error(`本轮已有创建请求 ${activeBeforeAdmission.requestId} 正在受理，不会重复启动。`);
        error.code = "CMS_START_REQUEST_ACTIVE";
        error.statusCode = 409;
        error.cmsStartRequest = activeRecord || null;
        throw error;
      }
      const releaseAdmission = await acquireKeyedAdmission(cmsStartAdmissionQueues, requestKey);
      try {
      let previous = cmsStartRequests.get(requestKey) || await readCmsStartRequest(runDir);
      previous = await reconcileCmsStartRequestRecord({
        runDir, record: previous, workflow, snapshot: state.snapshot(), launchSessionId,
        activeAcceptance: cmsStartAcceptances.get(requestKey)
      });
      if (previous) cmsStartRequests.set(requestKey, previous);
      let recoveryDecision = null;
      let recoverySummary = null;
      const requestedRecoveryDecision = body.recoveryDecision && typeof body.recoveryDecision === "object"
        ? body.recoveryDecision
        : null;
      if (previous && previous.requestId === requestId) {
        sendJson(res, cmsStartRequestHttpStatus(previous), { ok: !["rejected", "failed", "unknown"].includes(previous.status), request: previous, state: state.snapshot() });
        return;
      }
      const previousBlocksNewStart = previous && ["received", "checking", "accepted", "running"].includes(previous.status);
      if (previousBlocksNewStart) {
        const error = new Error(`本轮已有创建请求 ${previous.requestId} 处于“${cmsStartStatusLabel(previous.status)}”，不会重复启动。`);
        error.code = "CMS_START_REQUEST_ACTIVE";
        error.statusCode = 409;
        error.cmsStartRequest = previous;
        throw error;
      }
      const submitStateExists = await fs.access(path.join(runDir, "cms-submit-state.json"))
        .then(() => true)
        .catch(() => false);
      if (submitStateExists || previous?.status === "unknown" || requestedRecoveryDecision) {
        try {
          recoverySummary = await buildCmsRecoverySummary(runDir, previous || {});
        } catch (error) {
          if (previous?.status !== "unknown" || requestedRecoveryDecision) throw error;
          state.log(`旧创建请求需要人工处理，但无法读取历史预览：${error?.message || String(error)}`);
        }
      }
      const recoveryRequired = Boolean(recoverySummary?.hasHistory) || previous?.status === "unknown";
      if (recoveryRequired && !requestedRecoveryDecision) {
        const error = new Error("检测到本轮已有创建记录，请先选择从哪一条开始。未选择前不会启动创建。");
        error.code = "CMS_RECOVERY_DECISION_REQUIRED";
        error.statusCode = 409;
        error.cmsStartRequest = previous || null;
        error.cmsRecoverySummary = recoverySummary;
        throw error;
      }
      if (requestedRecoveryDecision) {
        const expectedOldRequestId = String(previous?.requestId || "");
        if (String(requestedRecoveryDecision.oldRequestId || "") !== expectedOldRequestId) {
          const error = new Error("续发选择对应的旧请求已经变化，请刷新后重新选择。");
          error.code = "CMS_RECOVERY_REQUEST_CHANGED";
          error.statusCode = 409;
          error.cmsStartRequest = previous;
          throw error;
        }
        recoveryDecision = resolveCmsRecoveryDecision(recoverySummary, {
          ...requestedRecoveryDecision,
          decisionId: requestId
        });
      }
      if (previous && ["received", "checking", "accepted", "running", "unknown"].includes(previous.status) && !recoveryDecision) {
        const error = new Error(`本轮已有创建请求 ${previous.requestId} 处于“${cmsStartStatusLabel(previous.status)}”，不会重复启动。`);
        error.code = "CMS_START_REQUEST_ACTIVE";
        error.statusCode = 409;
        error.cmsStartRequest = previous;
        throw error;
      }
      let requestRecord = {
        version: 1,
        requestId,
        instanceId: instanceConfig.id || "default",
        runId,
        status: "received",
        stage: "请求已到后台",
        message: "后台已收到开始创建请求，正在检查创建条件。",
        receivedAt: new Date().toISOString(),
        launchSessionId,
        processId: process.pid,
        ...(recoveryDecision ? {
          recoveryDecision,
          previousRequest: {
            requestId: previous.requestId,
            status: previous.status,
            stage: previous.stage || "",
            message: previous.message || "",
            receivedAt: previous.receivedAt || "",
            acceptedAt: previous.acceptedAt || "",
            updatedAt: previous.updatedAt || ""
          }
        } : {}),
        updatedAt: new Date().toISOString()
      };
      cmsStartRequests.set(requestKey, requestRecord);
      cmsStartAcceptances.set(requestKey, { requestId, runId, launchSessionId });
      const clearAcceptance = () => {
        const current = cmsStartAcceptances.get(requestKey);
        if (current?.requestId === requestId && current?.launchSessionId === launchSessionId) cmsStartAcceptances.delete(requestKey);
      };
      try {
        await writeCmsStartRequest(runDir, requestRecord);
      } catch (error) {
        clearAcceptance();
        throw error;
      }
      state.log(`开始创建请求已收到：requestId=${requestId}；runId=${runId || "-"}；instance=${instanceConfig.id || "default"}${recoveryDecision ? `；续发起点=第${recoveryDecision.startTaskIndex}条` : ""}`);
      try {
        requestRecord = await updateCmsStartRequest(runDir, requestRecord, { status: "checking", stage: "授权检查", message: "正在检查本机共享授权和创建条件。" });
        cmsStartRequests.set(requestKey, requestRecord);
        await assertCompanyAccessAllowed(projectRoot, "start-cms", licenseOptions);
      } catch (error) {
        requestRecord = await updateCmsStartRequest(runDir, requestRecord, {
          status: "rejected", stage: "授权检查未通过", code: error?.code || "LICENSE_DENIED",
          message: error?.message || "授权检查未通过，本次创建未启动。", finishedAt: new Date().toISOString()
        });
        cmsStartRequests.set(requestKey, requestRecord);
        clearAcceptance();
        state.log(`开始创建请求未受理：requestId=${requestId}；${requestRecord.message}`);
        sendJson(res, error?.statusCode || 403, { ok: false, code: requestRecord.code, error: requestRecord.message, request: requestRecord, license: error?.license });
        return;
      }
      const snapshot = state.snapshot();
      if (snapshot.status === "paused" || snapshot.control === "paused") {
        state.log("页面请求：开始创建时检测到当前已暂停，已转为继续");
        requestRecord = await updateCmsStartRequest(runDir, requestRecord, {
          status: "completed", stage: "已继续", message: "当前创建已从暂停状态继续，没有启动重复任务。", finishedAt: new Date().toISOString()
        });
        cmsStartRequests.set(requestKey, requestRecord);
        clearAcceptance();
        sendJson(res, 200, { ok: true, resumed: true, request: requestRecord, state: state.resume() });
        return;
      }
      if (workflow.isRunning?.()) {
        requestRecord = await updateCmsStartRequest(runDir, requestRecord, {
          status: "rejected", stage: "运行占用", code: "WORKFLOW_BUSY",
          message: "已有流程正在运行，本次创建未启动。", finishedAt: new Date().toISOString()
        });
        cmsStartRequests.set(requestKey, requestRecord);
        clearAcceptance();
        sendJson(res, 409, { ok: false, code: requestRecord.code, error: requestRecord.message, request: requestRecord, state: state.snapshot() });
        return;
      }
      let settings;
      try {
        const savedSettings = await saveSettings(body.settings || body);
        settings = body.temporarySettings && typeof body.temporarySettings === "object"
          ? { ...savedSettings, ...body.temporarySettings }
          : savedSettings;
        const runRobotStrategy = await robotStrategyForCreateRun(runDir);
        if (runRobotStrategy && settings.robotStrategy !== runRobotStrategy) {
          const selectedLabel = settings.robotStrategy === "precise" ? "精细托" : "粗略版随机托";
          const runLabel = runRobotStrategy === "precise" ? "精细托" : "粗略版随机托";
          const mismatch = new Error(`当前控制台选择的是“${selectedLabel}”，但这份预览保存的是“${runLabel}”。不会自动重新分配或覆盖人工内容；请恢复与本轮一致的模式，或重新生成预览。`);
          mismatch.code = "CMS_RUN_MODE_MISMATCH";
          throw mismatch;
        }
      } catch (error) {
        requestRecord = await updateCmsStartRequest(runDir, requestRecord, {
          status: "rejected", stage: "参数检查", code: error?.code || "CMS_START_SETTINGS_INVALID",
          message: error?.message || "创建参数无效，本次创建未启动。", finishedAt: new Date().toISOString()
        });
        cmsStartRequests.set(requestKey, requestRecord);
        clearAcceptance();
        sendJson(res, 400, { ok: false, code: requestRecord.code, error: requestRecord.message, request: requestRecord });
        return;
      }
      lastResult = null;
      state.log("页面请求：我已设置好，开始创建");
      requestRecord = await updateCmsStartRequest(runDir, requestRecord, {
        status: "accepted", stage: "已受理", message: "创建请求已受理，正在启动本轮创建。", acceptedAt: new Date().toISOString()
      });
      cmsStartRequests.set(requestKey, requestRecord);
      requestRecord = await updateCmsStartRequest(runDir, requestRecord, { status: "running", stage: "已启动", message: "后台已启动本轮创建，请查看真实运行进度。" });
      cmsStartRequests.set(requestKey, requestRecord);
      Promise.resolve().then(() => workflow.startCms({
        ...settings,
        ...(recoveryDecision ? { recoveryDecision } : {}),
        cmsStartRequestId: requestId,
        runDir: state.snapshot().runDir,
        runId: body.runId
      })).then((result) => {
        lastResult = result;
        const status = result?.ok ? "completed" : result?.waitingForLogin ? "waiting_login" : (isUnknownCmsStartResult(result) ? "unknown" : "failed");
        return updateCmsStartRequest(runDir, requestRecord, {
          status,
          stage: result?.ok ? "创建完成" : status === "waiting_login" ? "等待云中客登录" : status === "unknown" ? "创建结果待确认" : "创建未完成",
          code: result?.code || "",
          message: result?.ok ? "本轮创建已完成。" : (result?.error || "本轮创建未完成。"),
          finishedAt: new Date().toISOString()
        }).then((next) => { requestRecord = next; cmsStartRequests.set(requestKey, next); });
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("正式创建 CMS", lastResult.error);
        return updateCmsStartRequest(runDir, requestRecord, {
          status: isUnknownCmsStartResult(error) ? "unknown" : "failed",
          stage: isUnknownCmsStartResult(error) ? "创建结果待确认" : "启动或创建失败",
          code: error?.code || "",
          message: lastResult.error,
          finishedAt: new Date().toISOString()
        }).then((next) => { requestRecord = next; cmsStartRequests.set(requestKey, next); });
      }).finally(clearAcceptance).catch((error) => {
        state.log(`创建请求状态落盘失败：requestId=${requestId}；${error?.message || String(error)}`);
      });
      sendJson(res, 202, { ok: true, request: requestRecord, state: state.snapshot() });
      return;
      } finally {
        releaseAdmission();
      }
    }
    if (req.method === "GET" && url.pathname === "/api/start-cms-request") {
      const runId = String(url.searchParams.get("runId") || "").slice(0, 96);
      const requestId = normalizeCmsStartRequestId(url.searchParams.get("requestId"));
      const snapshot = state.snapshot();
      const runDir = snapshot.runDir && (!runId || path.basename(snapshot.runDir) === runId) ? snapshot.runDir : "";
      const requestKey = `${instanceConfig.id || "default"}:${runId || (runDir ? path.basename(runDir) : "")}`;
      let record = cmsStartRequests.get(requestKey) || await readCmsStartRequest(runDir);
      if (!record || (requestId && record.requestId !== requestId)) {
        sendJson(res, 404, { ok: false, code: "CMS_START_REQUEST_NOT_FOUND", error: "没有找到该创建请求；不能据此判断任务未执行。" });
        return;
      }
      record = await reconcileCmsStartRequestRecord({
        runDir, record, workflow, snapshot, launchSessionId,
        activeAcceptance: cmsStartAcceptances.get(requestKey)
      });
      cmsStartRequests.set(requestKey, record);
      sendJson(res, 200, { ok: true, request: record, state: snapshot });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/start-cms-request/resolve") {
      const body = await readJsonBody(req);
      const snapshot = state.snapshot();
      const runDir = snapshot.runDir || "";
      const runId = runDir ? path.basename(runDir) : "";
      const requestedRunId = String(body.runId || "");
      const requestId = normalizeCmsStartRequestId(body.requestId);
      if (!runDir || !runId || requestedRunId !== runId) {
        sendJson(res, 409, { ok: false, code: "CMS_START_RESOLUTION_RUN_MISMATCH", error: "当前页面对应的运行记录已变化，不能结算另一轮创建请求。" });
        return;
      }
      const requestKey = `${instanceConfig.id || "default"}:${runId}`;
      let record = cmsStartRequests.get(requestKey) || await readCmsStartRequest(runDir);
      record = await reconcileCmsStartRequestRecord({
        runDir, record, workflow, snapshot, launchSessionId,
        activeAcceptance: cmsStartAcceptances.get(requestKey)
      });
      if (!record || record.requestId !== requestId || record.status !== "unknown") {
        sendJson(res, 409, { ok: false, code: "CMS_START_RESOLUTION_NOT_ALLOWED", error: "该请求当前不是可人工结算的结果待确认状态。", request: record || null });
        return;
      }
      if (workflow.isRunning?.()) {
        sendJson(res, 409, { ok: false, code: "CMS_START_RESOLUTION_RUNNING", error: "后台流程仍在运行，不能人工结算。", request: record });
        return;
      }
      const submitState = await readJsonIfExists(path.join(runDir, "cms-submit-state.json"));
      const protectedRecords = Object.values(submitState?.tasks && typeof submitState.tasks === "object" ? submitState.tasks : {})
        .filter((item) => ["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown", "succeeded"].includes(item?.status));
      if (protectedRecords.length) {
        sendJson(res, 409, { ok: false, code: "CMS_START_RESOLUTION_SUBMIT_PROTECTED", error: "任务级记录中存在已成功或结果未知的提交，不能把整轮结算为未创建。请继续逐条核对 CMS 队列。", request: record });
        return;
      }
      if (body.resolution !== "confirmed_not_submitted" || body.confirmed !== true) {
        sendJson(res, 400, { ok: false, code: "CMS_START_RESOLUTION_CONFIRMATION_REQUIRED", error: "只有在人工核对 CMS 队列并确认本请求没有创建任何任务后，才能解除本次启动保护。" });
        return;
      }
      record = await updateCmsStartRequest(runDir, record, {
        status: "resolved_not_submitted",
        stage: "人工核对：未创建",
        code: "CMS_START_CONFIRMED_NOT_SUBMITTED",
        message: "已人工核对 CMS 队列并确认本请求未创建任务；允许重新点击开始创建。",
        resolvedAt: new Date().toISOString(),
        resolution: { type: "confirmed_not_submitted", operator: String(operatorSession?.employeeName || operatorSession?.employeeId || "本机操作人").slice(0, 80) }
      });
      cmsStartRequests.set(requestKey, record);
      state.log(`创建请求已人工结算为未创建：runId=${runId}；requestId=${requestId}`);
      sendJson(res, 200, { ok: true, request: record, state: snapshot });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/shutdown") {
      state.log("页面请求：退出程序");
      lastResult = null;
      if (workflow.isRunning?.()) {
        state.stop("退出程序：用户主动结束当前流程，不记录失败");
        await waitForWorkflowIdle(workflow, 8000);
      }
      await workflow.exitProgramSession?.();
      const nextState = state.resetForStartup?.("退出程序：已清理上次运行状态，预览文件仍可恢复") || state.snapshot();
      sendJson(res, 200, { ok: true, message: "控制台服务正在关闭", state: nextState });
      setTimeout(() => {
        closeServer().catch(() => {});
      }, 50);
      return;
    }
    sendJson(res, 404, { ok: false, error: "Not found" });
  }

  async function closeServer() {
    if (closing) return;
    closing = true;
    removeProcessGuards();
    stopLicenseHeartbeat();
    stopPreviewMediaCleanup();
    await workflow.close();
    await new Promise((resolve) => server.close(resolve));
  }

  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port || 0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });

  const address = server.address();
  const consoleUrl = `http://127.0.0.1:${address.port}/`;
  const controlledUrl = appendInstanceParams(withControlledFlag(consoleUrl), instanceConfig);
  workflow.setConsoleUrl?.(controlledUrl);
  const runPreviewMediaCleanup = async () => {
    try {
      const currentRunDir = String(state.snapshot()?.runDir || "").trim();
      const report = await cleanupExpiredPreviewMedia(
        instanceConfig.runsDir || path.join(projectRoot, "runs"),
        {
          ...previewRecoveryOptions,
          protectedRunDirs: currentRunDir ? [currentRunDir] : []
        }
      );
      if (report.cleaned > 0) {
        state.log(`预览素材清理：已清理 ${report.cleaned} 个超过 24 小时的临时素材目录。`);
      }
      if (report.failures.length > 0) {
        state.log(`预览素材清理：${report.failures.length} 项清理失败，已保留原文件。`);
      }
    } catch (error) {
      state.log(`预览素材清理暂未完成：${error?.message || String(error)}`);
    }
  };
  await runPreviewMediaCleanup();
  const previewCleanupIntervalMs = Number(options.previewMediaCleanupIntervalMs ?? PREVIEW_MEDIA_CLEANUP_INTERVAL_MS);
  if (Number.isFinite(previewCleanupIntervalMs) && previewCleanupIntervalMs > 0) {
    const previewCleanupTimer = setInterval(() => {
      runPreviewMediaCleanup().catch(() => {});
    }, previewCleanupIntervalMs);
    previewCleanupTimer.unref?.();
    stopPreviewMediaCleanup = () => clearInterval(previewCleanupTimer);
  }
  stopLicenseHeartbeat = startLicenseHeartbeat(projectRoot, {
    licenseOptions: { ...licenseOptions, instanceId: instanceConfig.id || "", launchSessionId },
    operatorProvider: () => operatorSession,
    intervalMs: options.licenseHeartbeatIntervalMs,
    initialDelayMs: options.licenseHeartbeatInitialDelayMs,
    versionStatusProvider: options.versionStatusProvider,
    stateProvider: () => state.snapshot(),
    diagnosticProvider: () => latestDiagnosticReport
  });
  submitLicenseOpsEvent(projectRoot, {
    ...licenseOptions,
    instanceId: instanceConfig.id || "",
    launchSessionId,
    event: { eventId: `open:${launchSessionId}`, type: "program_opened", status: "running", source: "console" }
  }).catch(() => {});
  return {
    server,
    state,
    workflow,
    url: consoleUrl,
    controlledUrl,
    open: () => openControlledConsole(projectRoot, controlledUrl, instanceConfig),
    close: closeServer
  };
}

function renderConsolePage({ instanceConfig = {} } = {}) {
  const instanceIdText = escapeHtmlText(instanceConfig.id || "");
  const stableInstanceLabel = instanceConfig.enabled ? `实例${instanceConfig.id || ""}` : "";
  const configuredInstanceLabel = String(instanceConfig.label || "").trim();
  const hasCustomInstanceLabel = Boolean(configuredInstanceLabel)
    && configuredInstanceLabel !== stableInstanceLabel
    && configuredInstanceLabel !== String(instanceConfig.id || "");
  const instanceDisplayLabel = hasCustomInstanceLabel ? configuredInstanceLabel : stableInstanceLabel;
  const instanceLabelText = escapeHtmlText(instanceDisplayLabel);
  const instanceStableLabelText = escapeHtmlText(stableInstanceLabel);
  const documentTitle = instanceConfig.enabled
    ? `${hasCustomInstanceLabel ? `${configuredInstanceLabel}｜` : ""}${stableInstanceLabel}｜妙券2.0`
    : "妙券2.0｜可视化控制台";
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>${escapeHtmlText(documentTitle)}</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, "Microsoft YaHei", sans-serif; background: #f3f6fb; color: #102033; }
    .topbar { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 24px 32px 18px; background: #fff; border-bottom: 1px solid #d9e2f1; }
    .title h1 { margin: 0; font-size: 21px; }
    .title p { margin: 6px 0 0; color: #53657d; font-size: 14px; }
    .instance-identity { display: flex; flex-direction: column; align-items: flex-start; gap: 5px; max-width: min(720px, 100%); margin-top: 14px; }
    .instance-kicker { color: #64748b; font-size: 12px; font-weight: 700; }
    .instance-primary-row { display: flex; align-items: center; gap: 10px; max-width: 100%; min-width: 0; flex-wrap: wrap; }
    .instance-name-wrap { display: inline-flex; align-items: center; gap: 6px; max-width: 100%; min-width: 0; }
    #instanceDisplayName { color: #123a73; font-size: 25px; font-weight: 800; line-height: 1.2; overflow-wrap: anywhere; }
    .instance-stable-label { display: inline-flex; align-items: center; min-height: 26px; padding: 2px 9px; border: 1px solid #93b4df; border-radius: 999px; background: #eaf3ff; color: #174f91; font-size: 13px; font-weight: 800; white-space: nowrap; }
    .instance-meta { display: flex; align-items: center; gap: 6px 12px; max-width: 100%; flex-wrap: wrap; color: #64748b; font-size: 12px; line-height: 1.4; }
    .instance-meta span + span { position: relative; }
    .instance-meta span + span::before { content: ""; position: absolute; left: -7px; top: 3px; width: 1px; height: 11px; background: #cbd5e1; }
    .instance-name-edit { display: inline-flex; flex: 0 0 auto; align-items: center; justify-content: center; width: 30px; min-height: 30px; padding: 0; border: 0; border-radius: 50%; background: transparent; color: #1d4ed8; font-size: 18px; line-height: 1; }
    .instance-name-edit:hover, .instance-name-edit:focus-visible { background: #dbeafe; outline: none; }
    .top-actions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; justify-content: flex-end; }
    main { max-width: 980px; margin: 20px auto 112px; padding: 0 16px; }
    section { background: #fff; border: 1px solid #cfe0f8; border-radius: 8px; padding: 16px; margin-bottom: 12px; }
    .is-library-disabled { background: #f3f6fa; border-color: #d8e2ef; color: #64748b; }
    .is-library-disabled > :not(.library-disabled-note) { opacity: .62; }
    .is-library-disabled .choice { cursor: not-allowed; background: #f8fafc; }
    .library-disabled-note { display: none; margin: 0 0 12px; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 8px; background: #fff; color: #334155; font-size: 13px; font-weight: 700; }
    .is-library-disabled .library-disabled-note { display: block; }
    .is-import-range-disabled { background: #f8fbff; border-color: #cbdcf5; color: #64748b; }
    .is-import-range-disabled > :not(.import-range-disabled-note):not(.library-disabled-note) { opacity: .66; }
    .is-import-range-disabled .choice { cursor: not-allowed; background: #f8fafc; }
    .import-range-disabled-note { display: none; margin: 0 0 12px; padding: 10px 12px; border: 1px solid #b9d1f5; border-radius: 8px; background: #fff; color: #17345c; font-size: 13px; font-weight: 700; }
    .is-import-range-disabled .import-range-disabled-note { display: block; }
    h2 { margin: 0 0 14px; font-size: 17px; }
    .panel-note { color: #53657d; font-size: 13px; margin-top: -6px; margin-bottom: 12px; }
    .grid { display: grid; grid-template-columns: 128px 1fr; gap: 10px 12px; align-items: center; }
    .grid.compact { grid-template-columns: 120px 1fr 120px 1fr; }
    label { color: #40536b; font-size: 13px; }
    input, select, textarea { width: 100%; min-height: 38px; border: 1px solid #c9d6e8; border-radius: 6px; padding: 7px 10px; font: inherit; background: #fff; }
    textarea { min-height: 70px; resize: vertical; }
    button { min-height: 38px; border: 1px solid #9fb4d1; background: #fff; border-radius: 6px; padding: 0 14px; cursor: pointer; font-weight: 600; color: #17345c; }
    button.primary { background: #4f8ff7; border-color: #4f8ff7; color: white; }
    button.danger { background: #e11d48; border-color: #e11d48; color: white; }
    button.warn { background: #f59e0b; border-color: #f59e0b; color: white; }
    button.good { background: #59c485; border-color: #59c485; color: white; }
    button.outline-danger { border-color: #ef4444; color: #dc2626; }
    button:disabled { opacity: .55; cursor: not-allowed; }
    .check-btn { min-width: 90px; border-color: #2f73ff; color: #2f73ff; }
    .run-box { border: 1px solid #d6e2f4; border-radius: 8px; padding: 12px; background: #fbfdff; }
    .browser-warning { display: none; border-color: #fecaca; background: #fff1f2; color: #b91c1c; font-weight: 700; line-height: 1.55; }
    .version-notice { display: none; align-items: center; gap: 10px; border-color: #bfdbfe; background: #eff6ff; color: #1d4ed8; font-weight: 700; }
    .version-notice.is-open { display: flex; flex-wrap: wrap; }
    .license-panel { display: none; border-color: #fecaca; background: #fff7f7; }
    .license-panel.is-open { display: block; }
    .license-panel.authorized { border-color: #bbf7d0; background: #f0fdf4; }
    .license-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .license-head strong { font-size: 18px; color: #b91c1c; }
    .license-panel.authorized .license-head strong { color: #166534; }
    .license-diagnostics { display: grid; grid-template-columns: 150px minmax(0, 1fr); gap: 8px 12px; margin-top: 12px; font-size: 13px; }
    .license-diagnostics span:nth-child(odd) { color: #63758c; }
    .license-diagnostics strong { word-break: break-word; }
    .license-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 12px; }
    .operator-panel { border-color: #cbd5e1; background: #f8fafc; }
    .operator-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .operator-row select { min-width: 220px; }
    .operator-row input { width: 170px; }
    .operator-current { color: #166534; font-weight: 700; }
    .version-panel { display: none; }
    .version-panel.is-open { display: block; }
    .version-summary { display: grid; gap: 8px; max-width: 620px; }
    .version-line { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .version-line span { color: #63758c; font-size: 14px; }
    .version-line strong { font-size: 18px; }
    .version-main-state { font-size: 18px; font-weight: 800; color: #166534; }
    .version-main-state.has-update { color: #1d4ed8; }
    .version-main-state.failed { color: #b91c1c; }
    .version-update-hint { color: #53657d; font-size: 14px; line-height: 1.5; }
    .version-grid { display: grid; grid-template-columns: 150px minmax(0, 1fr) 150px minmax(0, 1fr); gap: 10px 12px; align-items: start; }
    .version-grid span:nth-child(odd) { color: #63758c; font-size: 13px; }
    .version-grid strong { word-break: break-word; font-size: 13px; }
    .version-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }
    .version-state { margin-top: 10px; color: #53657d; font-size: 13px; line-height: 1.5; }
    details.version-advanced { margin-top: 14px; border-top: 1px solid #e3ebf6; padding-top: 12px; }
    details.version-advanced summary { cursor: pointer; color: #40536b; font-weight: 700; }
    .run-row { display: grid; grid-template-columns: 110px 1fr; gap: 10px; min-height: 30px; align-items: center; }
    .run-row span:first-child { color: #63758c; }
    .run-row strong { font-size: 16px; word-break: break-word; }
    .actions { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
    .hint { margin-top: 10px; font-size: 13px; color: #5b6f87; line-height: 1.5; }
    .choice-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .choice-grid.three { grid-template-columns: repeat(3, 1fr); }
    .choice { display: block; border: 1px solid #c9d6e8; border-radius: 8px; padding: 14px; cursor: pointer; min-height: 72px; background: #fff; }
    .choice:has(input:checked) { border-color: #2f73ff; background: #eef5ff; box-shadow: inset 0 0 0 1px #2f73ff; }
    .choice input { width: auto; min-height: auto; margin-right: 8px; }
    .choice b { font-size: 14px; }
    .choice p { margin: 6px 0 0 26px; color: #53657d; font-size: 13px; line-height: 1.45; }
    .choice-alert { margin: 6px 0 0 18px; color: #c2410c; font-size: 12px; font-weight: 700; line-height: 1.45; }
    .choice-grid > .choice { height: 100%; }
    .choice-grid .choice-grid-alert { min-width: 0; }
    .source-mode-grid .choice { border-width: 2px; background: #fff; box-shadow: none; }
    .source-mode-grid .choice:hover { border-color: #7aa7ff; background: #fbfdff; }
    .source-mode-grid .choice:has(input:checked) { border-color: #2f73ff; background: linear-gradient(135deg, #eaf3ff 0%, #f4f9ff 52%, #fff4df 100%); box-shadow: inset 0 0 0 1px #2f73ff; }
    .source-mode-grid .choice { display: grid; grid-template-columns: auto minmax(0, 1fr); gap: 0 12px; align-items: flex-start; }
    .source-mode-grid .choice input { margin-top: 3px; }
    .source-mode-grid .source-choice-body { min-width: 0; }
    .source-mode-grid .choice b { display: block; color: #0f2f57; font-size: 16px; line-height: 1.35; }
    .source-mode-grid .choice p { margin-left: 0; color: #24425f; font-size: 13px; }
    .source-mode-choice-secondary { background: #fff; }
    .time-field-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 14px; }
    #dateField input { width: 190px; max-width: 100%; }
    .field { display: grid; gap: 6px; color: #40536b; font-size: 13px; }
    .field-help { color: #6b7f96; font-size: 12px; line-height: 1.4; }
    .inline-field { display: flex; gap: 8px; align-items: center; }
    .inline-field input { flex: 1; }
    .field-badge { display: inline-flex; min-height: 26px; align-items: center; border-radius: 999px; padding: 0 10px; background: #eef2ff; color: #3156a3; font-size: 12px; font-weight: 700; }
    .field-badge.warn { background: #fff7ed; color: #b45309; }
    .field-badge.bad { background: #fff1f2; color: #be123c; }
    .field-badge.good { background: #ecfdf5; color: #166534; }
    .link-feedback { grid-column: 2; color: #53657d; font-size: 13px; line-height: 1.5; }
    .link-feedback.good { color: #166534; }
    .link-feedback.warn { color: #b45309; }
    .link-feedback.bad { color: #be123c; font-weight: 700; }
    .interval-panel { position: relative; margin-top: 12px; border: 1px solid #d7e6fb; border-radius: 8px; padding: 12px 12px 12px 16px; background: linear-gradient(135deg, #f1f7ff 0%, #f5f9ff 44%, #fff8ed 56%, #fff3df 100%); overflow: hidden; }
    .interval-panel::before { content: ""; position: absolute; inset: 0 auto 0 0; width: 5px; background: linear-gradient(180deg, #2f73ff 0%, #7aa7ff 58%, #f6b253 100%); }
    .interval-panel::after { content: ""; position: absolute; inset: 0; pointer-events: none; background-image: repeating-linear-gradient(135deg, rgba(47, 115, 255, .055) 0 1px, transparent 1px 14px); opacity: .35; }
    .interval-panel > * { position: relative; z-index: 1; }
    .interval-panel h3 { margin: 0 0 6px; font-size: 16px; }
    .interval-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }
    .interval-tools { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; min-width: 360px; }
    .interval-tools select { width: 180px; }
    .interval-tools button { padding: 0 12px; }
    .interval-preset-panel { display: none; margin-top: 10px; border: 1px solid #cfe0f8; border-radius: 8px; padding: 10px; background: #fff; }
    .interval-preset-panel.is-open { display: block; }
    .interval-preset-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 8px; }
    .interval-preset-head strong { color: #17345c; }
    .interval-preset-list { display: grid; gap: 8px; }
    .interval-preset-empty { color: #63758c; font-size: 13px; padding: 8px 0; }
    .interval-preset-row { display: grid; grid-template-columns: minmax(160px, 1fr) minmax(180px, 1fr) auto; gap: 8px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 8px; }
    .interval-preset-summary { color: #53657d; font-size: 13px; line-height: 1.4; }
    .interval-preset-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
    .interval-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; }
    .interval-item { display: grid; grid-template-columns: 1fr 82px 14px 82px 24px; gap: 8px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 10px; background: #fff; }
    .interval-item span:first-child { color: #24425f; font-size: 14px; }
    .status-grid { display: grid; grid-template-columns: repeat(2, minmax(160px, 1fr)); gap: 10px; margin-top: 12px; }
    .stat { border: 1px solid #e1e8f2; border-radius: 6px; padding: 10px; background: #fbfcfe; min-height: 62px; }
    .stat .k { color: #6b7f98; font-size: 12px; }
    .stat .v { margin-top: 6px; font-weight: 700; word-break: break-word; }
    .recovery-panel { display: none; margin-top: 12px; border: 1px solid #fed7aa; border-radius: 8px; padding: 12px; background: #fff7ed; }
    .recovery-panel.is-open { display: block; }
    .recovery-panel h3 { margin: 0 0 6px; font-size: 15px; color: #9a3412; }
    .recovery-panel p { margin: 0; color: #7c2d12; font-size: 13px; line-height: 1.5; }
    .recovery-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
    .cms-recovery-summary { margin-top: 10px; padding: 10px; border: 1px solid #fdba74; border-radius: 6px; background: #fff; color: #334155; font-size: 13px; line-height: 1.55; }
    .cms-recovery-list { max-height: 180px; overflow: auto; margin-top: 8px; display: grid; gap: 6px; }
    .cms-recovery-task { padding: 8px 10px; border: 1px solid #e2e8f0; border-radius: 6px; background: #f8fafc; }
    .cms-recovery-task strong { display: block; color: #17345c; }
    .cms-recovery-content { margin-top: 4px; white-space: pre-wrap; word-break: break-word; color: #334155; }
    .cms-recovery-boundary { display: none; margin-top: 10px; }
    .cms-recovery-boundary.is-open { display: block; }
    .cms-recovery-boundary select { margin-top: 6px; }
    .cms-recovery-options { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; margin-top: 12px; }
    .cms-recovery-option { display: flex; flex-direction: column; align-items: stretch; gap: 8px; min-width: 0; padding: 10px; border: 1px solid #fdba74; border-radius: 6px; background: #fff; }
    .cms-recovery-option button { width: 100%; }
    .cms-recovery-option .cms-recovery-task { flex: 1; }
    .preview-restore-panel { display: none; margin-top: 12px; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px; background: #eff6ff; }
    .preview-restore-panel.is-open { display: block; }
    .preview-restore-panel h3 { margin: 0 0 6px; font-size: 15px; color: #1d4ed8; }
    .preview-restore-panel p { margin: 0; color: #1e3a8a; font-size: 13px; line-height: 1.5; }
    .preview-restore-select { width: 100%; margin-top: 10px; }
    .preview-restore-meta { margin-top: 8px !important; color: #475569 !important; }
    .preview-restore-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
    .source-layout { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 12px; }
    .source-card { border: 1px solid #d8e5f8; border-radius: 8px; padding: 14px; background: #fbfdff; min-height: 100%; }
    .source-card h3 { margin: 0 0 6px; font-size: 16px; color: #17345c; }
    .source-card .panel-note { margin: 0 0 12px; }
    .source-card.library-source > .library-head > div > .panel-note { margin-top: 8px; }
    .source-card.primary-source { display: flex; flex-direction: column; border-color: #bfdbfe; background: #eff6ff; }
    .source-card.primary-source .source-form { grid-template-columns: 128px minmax(0, 1fr); flex: 1; align-content: start; row-gap: 14px; min-width: 0; min-height: 0; }
    .source-card.primary-source .source-form > * { min-width: 0; }
    .source-card.primary-source > .hint { margin-top: 12px; }
    .source-card.library-source { border-color: #fed7aa; background: #fff7ed; }
    .source-warning { margin: -4px 0 12px; color: #c2410c; font-size: 12px; font-weight: 700; line-height: 1.5; }
    .source-warning-title { display: inline-block; margin-right: 6px; font-size: 13px; }
    .source-warning-line { margin-right: 14px; }
    .source-mode-grid { margin-bottom: 12px; }
    .source-mode-panel { display: none; }
    .source-mode-panel.is-open { display: block; }
    .library-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; flex-wrap: nowrap; }
    .library-title-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .library-search { position: relative; width: min(190px, 100%); }
    .library-search::before { content: "🔍"; position: absolute; left: 10px; top: 50%; transform: translateY(-50%); font-size: 13px; opacity: .7; pointer-events: none; }
    .library-search input { min-height: 34px; padding: 6px 10px 6px 32px; border-radius: 999px; background: #fff; }
    .library-tools { display: flex; gap: 8px; flex: 0 0 auto; align-items: center; }
    .library-tools button { padding: 0 10px; }
    .library-list { display: grid; gap: 8px; margin-top: 10px; max-height: 236px; overflow-y: auto; padding-right: 2px; }
    .library-list.compact { max-height: 160px; }
    .cms-config-panel { margin-top: 14px; border: 1px solid #c7d9f5; border-radius: 8px; background: #fff; overflow: hidden; box-shadow: 0 6px 18px rgba(37, 99, 235, .06); }
    .cms-config-statusbar { position: relative; display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; padding: 14px 16px 14px 20px; background: linear-gradient(135deg, #f1f7ff 0%, #f5f9ff 44%, #fff8ed 56%, #fff3df 100%); border-bottom: 1px solid #d7e6fb; overflow: hidden; }
    .cms-config-statusbar::before { content: ""; position: absolute; inset: 0 auto 0 0; width: 5px; background: linear-gradient(180deg, #2f73ff 0%, #7aa7ff 58%, #f6b253 100%); }
    .cms-config-statusbar::after { content: ""; position: absolute; inset: 0; pointer-events: none; background-image: repeating-linear-gradient(135deg, rgba(47, 115, 255, .055) 0 1px, transparent 1px 14px); opacity: .35; }
    .cms-config-statusbar > * { position: relative; z-index: 1; }
    .cms-config-title { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .cms-config-title h3 { position: relative; margin: 0; padding-left: 14px; color: #0f2f57; font-size: 18px; }
    .cms-config-title h3::before { content: ""; position: absolute; left: 0; top: 50%; width: 8px; height: 8px; border-radius: 999px; transform: translateY(-50%); background: #2f73ff; box-shadow: 0 0 0 4px rgba(47, 115, 255, .14); }
    .cms-config-badge { display: inline-flex; align-items: center; min-height: 24px; border-radius: 999px; padding: 0 10px; background: #e2e8f0; color: #475569; font-size: 12px; font-weight: 800; }
    .cms-config-badge.is-active { background: #dff7e9; color: #166534; box-shadow: inset 0 0 0 1px rgba(34, 197, 94, .18); }
    .cms-config-panel .panel-note { margin: 6px 0 0; color: #24425f; }
    .cms-config-body { display: grid; gap: 8px; max-height: none; overflow: visible; margin-top: 0; padding: 12px 14px 14px; background: #fff; }
    .cms-config-body.library-list.compact { max-height: 260px; overflow-y: auto; overflow-x: hidden; padding-right: 8px; scrollbar-gutter: stable; }
    .cms-config-inline-form { padding: 14px; border-bottom: 1px solid #dbe8fb; background: #fff; }
    .cms-config-inline-form.is-hidden { display: none; }
    .cms-config-empty { border: 1px dashed #9fc3ff; border-radius: 8px; padding: 14px; background: #fff; color: #40536b; line-height: 1.55; }
    .cms-config-empty strong { display: block; margin-bottom: 4px; color: #17345c; font-size: 15px; }
    .cms-config-card { border: 1px solid #bfd5ff; border-radius: 8px; padding: 12px; background: #fff; }
    .cms-config-card-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 8px; }
    .cms-config-card-title { min-width: 0; color: #17345c; font-weight: 800; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .cms-config-card-time { color: #63758c; font-size: 12px; }
    .cms-config-roles { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .cms-config-role { border: 1px solid #e0e8f4; border-radius: 6px; padding: 8px 10px; background: #f8fbff; color: #40536b; font-size: 13px; line-height: 1.45; }
    .cms-config-role b { display: block; color: #17345c; margin-bottom: 2px; }
    .cms-config-role ul { margin: 4px 0 0; padding: 0; list-style: none; display: grid; gap: 3px; }
    .cms-config-role li { color: #40536b; word-break: break-word; }
    .cms-config-role li strong { display: inline; margin: 0 4px 0 0; color: #17345c; }
    .cms-config-warning { margin-top: 6px; color: #64748b; font-size: 12px; font-weight: 600; line-height: 1.45; }
    .cms-config-wizard { width: min(920px, 100%); }
    .cms-wizard-heading { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 4px 18px 12px; border-bottom: 1px solid #edf3fb; }
    .cms-wizard-heading strong { color: #17345c; font-size: 16px; }
    .cms-wizard-heading span { color: #63758c; font-size: 12px; }
    .cms-wizard-pages { overflow: hidden; }
    .cms-wizard-page-track { display: flex; width: 200%; transform: translateX(0); transition: transform .22s ease; }
    .cms-config-wizard.is-douma .cms-wizard-page-track { transform: translateX(-50%); }
    .cms-wizard-page { flex: 0 0 50%; padding: 14px 18px; box-sizing: border-box; }
    .cms-wizard-grid { display: grid; grid-template-columns: 160px minmax(0, 1fr); gap: 10px 12px; align-items: center; }
    .cms-wizard-grid label { color: #17345c; font-weight: 700; }
    .cms-wizard-readonly { min-height: 38px; display: flex; align-items: center; padding: 0 12px; border: 1px solid #e0e8f4; border-radius: 6px; background: #f8fbff; color: #40536b; font-weight: 700; }
    .cms-wizard-radio { display: flex; gap: 22px; flex-wrap: nowrap; align-items: center; }
    .cms-wizard-radio label { display: inline-flex; align-items: center; gap: 6px; min-width: max-content; white-space: nowrap; font-weight: 500; color: #40536b; }
    .cms-wizard-radio input { width: auto; min-width: 16px; }
    .cms-wizard-error { min-height: 22px; padding: 0 18px; color: #b91c1c; font-size: 13px; }
    .library-empty { color: #63758c; font-size: 13px; padding: 8px 0; }
    .library-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 12px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 10px; background: #fbfdff; cursor: grab; }
    .library-row:active { cursor: grabbing; }
    .library-row.is-dragging, .library-manager-row.is-dragging { opacity: .55; }
    .library-row.is-drop-target, .library-manager-row.is-drop-target { border-color: #2563eb; background: #eff6ff; box-shadow: 0 0 0 2px rgba(37, 99, 235, .16); }
    .library-row.is-active, .library-manager-row.is-active { border-color: #f59e0b; background: #fffaf0; }
    .library-item-title { display: flex; align-items: center; gap: 6px; min-width: 0; }
    .library-row strong { display: block; min-width: 0; color: #17345c; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .library-row span { display: block; margin-top: 4px; color: #63758c; font-size: 12px; }
    .library-row .library-active-label, .library-manager-row .library-active-label { display: inline-flex; align-items: center; min-height: 22px; margin: 0 0 0 6px; padding: 0 8px; border-radius: 999px; background: #ffedd5; color: #c2410c; font-size: 12px; font-weight: 700; vertical-align: middle; }
    .cms-config-body .library-row { background: #fff; border-color: #d8e2f0; }
    .cms-config-body .library-row.is-active { border-color: #9fc3ff; background: #f3f8ff; box-shadow: 0 3px 10px rgba(47, 115, 255, .08); }
    .cms-config-body .library-active-label { background: #dcfce7; color: #166534; }
    .cms-config-body .library-actions button:disabled { background: #e8eef7; border-color: #d8e2f0; color: #64748b; opacity: 1; }
    .library-batch-tools { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 0 14px 10px; background: #fff; }
    .library-batch-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .library-batch-actions button { min-height: 32px; padding: 0 12px; }
    .library-selection-summary { color: #63758c; font-size: 12px; white-space: nowrap; }
    .library-select { display: inline-flex; align-items: center; gap: 6px; color: #40536b; font-size: 13px; font-weight: 700; cursor: pointer; user-select: none; }
    .library-select input { width: auto; min-width: 16px; }
    .library-actions { display: flex; gap: 8px; justify-content: flex-end; align-items: center; }
    .library-actions button { padding: 0 14px; min-height: 34px; }
    .library-more { position: relative; }
    .library-more summary { list-style: none; display: inline-flex; align-items: center; min-height: 34px; padding: 0 12px; border: 1px solid #b8c7da; border-radius: 6px; background: #fff; color: #40536b; font-size: 14px; cursor: pointer; user-select: none; }
    .library-more summary::-webkit-details-marker { display: none; }
    .library-more-menu { position: absolute; right: 0; top: calc(100% + 6px); z-index: 4; display: grid; gap: 6px; min-width: 86px; padding: 8px; border: 1px solid #d8e2f0; border-radius: 8px; background: #fff; box-shadow: 0 8px 22px rgba(15, 23, 42, .16); }
    .library-more-menu button { width: 100%; min-height: 30px; padding: 0 10px; }
    .library-manager-backdrop { position: fixed; inset: 0; z-index: 30; display: none; align-items: center; justify-content: center; padding: 24px; background: rgba(15, 23, 42, .42); }
    #consoleActionModal { z-index: 80; }
    .library-manager-backdrop.is-open { display: flex; }
    .library-manager-modal { width: min(760px, 100%); max-height: calc(100vh - 48px); overflow: auto; border: 1px solid #d8e2f0; border-radius: 10px; background: #fff; box-shadow: 0 24px 70px rgba(15, 23, 42, .24); }
    .library-manager-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; padding: 16px 18px 12px; border-bottom: 1px solid #e2e8f0; }
    .library-manager-head h3 { margin: 0; font-size: 18px; line-height: 34px; }
    .library-manager-head .panel-note { margin: 8px 0 0; line-height: 1.45; }
    .library-manager-body { padding: 14px 18px; display: grid; gap: 8px; max-height: min(58vh, 520px); overflow-y: auto; }
    .library-manager-batch-tools { padding: 12px 18px 0; border-top: 1px solid #eef3fb; }
    .library-manager-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 12px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 10px; background: #fbfdff; cursor: grab; }
    .library-manager-row:active { cursor: grabbing; }
    .library-manager-row strong { display: block; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #17345c; }
    .library-manager-row span { display: block; margin-top: 4px; color: #63758c; font-size: 12px; }
    .library-manager-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
    .library-share-status { grid-column: 1 / -1; margin-top: -4px; color: #2563eb; font-size: 12px; line-height: 1.45; }
    .library-share-status.error { color: #b91c1c; font-weight: 700; }
    .library-share-status.success { color: #047857; font-weight: 700; }
    .library-share-status-actions { display: inline-flex; gap: 6px; margin-left: 8px; flex-wrap: wrap; vertical-align: middle; }
    .library-share-status-actions button { min-height: 24px; padding: 0 8px; font-size: 12px; border-radius: 5px; }
    .library-confirm-body { padding: 18px; color: #17345c; line-height: 1.6; }
    .library-confirm-body p { margin: 0 0 12px; }
    .library-confirm-body ul { margin: 8px 0 0 20px; padding: 0; }
    .library-confirm-body li { margin: 3px 0; }
    .library-confirm-name { font-weight: 800; color: #0f2f57; word-break: break-word; }
    .library-confirm-actions { display: flex; justify-content: flex-end; gap: 10px; padding: 14px 18px 18px; border-top: 1px solid #e2e8f0; }
    #consoleActionMessage { white-space: pre-line; }
    .console-action-input { display: block; width: 100%; margin-top: 10px; }
    .console-action-error { min-height: 20px; margin-top: 8px; color: #b91c1c; font-size: 13px; }
    .precise-tuo-option { display: flex; align-items: flex-start; gap: 10px; padding: 10px 0 6px; }
    .precise-tuo-option input { width: auto; margin-top: 3px; }
    .precise-tuo-option strong { display: block; color: #17345c; }
    .precise-tuo-option p { margin: 4px 0 0; color: #4b607a; font-size: 13px; line-height: 1.35; }
    .roster-upload { margin-top: 10px; border: 1px dashed #93b4e8; border-radius: 8px; background: #f8fbff; padding: 14px; cursor: pointer; transition: border-color .15s, background .15s; }
    .roster-upload.is-dragging { border-color: #2563eb; background: #eff6ff; }
    .roster-upload.is-required { border: 2px solid #dc2626; background: #fef2f2; }
    .roster-upload.is-required .roster-upload-title, .roster-upload.is-required .roster-upload-status { color: #b91c1c; }
    .roster-upload-title { color: #17345c; font-weight: 700; }
    .roster-upload-note { margin-top: 4px; color: #63758c; font-size: 13px; }
    .roster-upload-status { margin-top: 8px; color: #166534; font-size: 13px; word-break: break-all; white-space: pre-line; }
    .roster-upload-error { color: #b91c1c; }
    .document-import-field { min-width: 0; max-width: 100%; }
    .document-import-stack { display: grid; gap: 12px; min-width: 0; max-width: 100%; overflow: hidden; }
    .document-import-stack .roster-upload { margin-top: 0; }
    .document-import-paste-panel { min-width: 0; max-width: 100%; border: 1px solid #d8e5f8; border-radius: 8px; padding: 12px; background: #fff; overflow: hidden; }
    .document-import-paste-head { display: flex; align-items: baseline; justify-content: space-between; gap: 10px; flex-wrap: wrap; margin-bottom: 8px; }
    .document-import-paste-title { color: #17345c; font-size: 14px; font-weight: 800; }
    .document-import-paste-note { color: #63758c; font-size: 12px; line-height: 1.45; }
    .rich-paste-box { display: block; width: 100%; max-width: 100%; min-width: 0; min-height: 180px; max-height: 360px; overflow: auto; border: 1px solid #c9d6e8; border-radius: 6px; padding: 10px 12px; background: #fff; white-space: pre-wrap; word-break: break-word; line-height: 1.6; }
    .rich-paste-box:empty::before { content: attr(data-placeholder); color: #94a3b8; }
    .rich-paste-box img { max-width: 160px; max-height: 160px; object-fit: contain; vertical-align: middle; border: 1px solid #e2e8f0; border-radius: 4px; margin: 4px 6px 4px 0; background: #fff; }
    .rich-paste-box:focus { outline: 2px solid rgba(37,99,235,.18); border-color: #2563eb; }
    .roster-tools { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
    .roster-tools button { min-height: 34px; padding: 0 12px; }
    .failed { color: #b91c1c; }
    .waiting { color: #92400e; }
    .done { color: #166534; }
    .links { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
    .links a { color: #2563eb; text-decoration: none; font-weight: 700; }
    pre { height: 260px; overflow: auto; white-space: pre-wrap; word-break: break-word; background: #0b1020; color: #e5e7eb; padding: 12px; border-radius: 6px; font-size: 12px; line-height: 1.45; }
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .bottom-actions { position: fixed; left: 0; right: 0; bottom: 0; background: rgba(255,255,255,.94); border-top: 1px solid #d8e2f0; padding: 14px 24px; backdrop-filter: blur(8px); }
    .bottom-inner { max-width: 980px; margin: 0 auto; display: flex; justify-content: flex-end; gap: 10px; align-items: center; }
    .save-state { margin-right: auto; color: #b45309; font-size: 13px; }
    .save-state.is-error { color: #dc2626; font-weight: 800; }
    .support-panel { display: none; border: 1px solid #fed7aa; background: #fff7ed; border-radius: 8px; padding: 12px; margin: 12px 0; }
    .support-panel.is-open { display: block; }
    .support-panel h3 { margin: 0 0 8px; font-size: 16px; color: #9a3412; }
    .support-panel p { margin: 0 0 8px; color: #334155; }
    .support-panel ol { margin: 0 0 10px 22px; padding: 0; color: #334155; line-height: 1.65; }
    .support-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    .support-actions span { color: #64748b; font-size: 12px; }
    .support-btn { display: none; }
    .support-btn.is-open { display: inline-flex; align-items: center; }
    .hidden-native { display: none; }
    @media (max-width: 780px) {
      .grid, .grid.compact { grid-template-columns: 1fr; }
      .choice-grid, .choice-grid.three { grid-template-columns: 1fr; }
      .cms-recovery-options { grid-template-columns: 1fr; }
      .time-field-grid, .interval-grid { grid-template-columns: 1fr; }
      .interval-item { grid-template-columns: 1fr 76px 14px 76px 22px; }
      .interval-head { display: grid; }
      .interval-tools { min-width: 0; justify-content: flex-start; }
      .interval-tools select { width: 100%; }
      .interval-preset-row { grid-template-columns: 1fr; }
      .interval-preset-actions { justify-content: flex-start; }
      .status-grid { grid-template-columns: 1fr; }
      .version-grid { grid-template-columns: 1fr; }
      .source-layout { grid-template-columns: 1fr; }
      .library-head { flex-wrap: wrap; }
      .library-row { grid-template-columns: 1fr; }
      .library-actions { grid-template-columns: repeat(3, minmax(0, 1fr)); }
      .library-actions .open-library-btn { grid-column: auto; }
      .topbar { padding: 18px; align-items: flex-start; }
      .topbar { flex-wrap: wrap; }
      .title { width: 100%; min-width: 0; }
      .instance-identity { width: 100%; margin-top: 12px; }
      .instance-primary-row { align-items: flex-start; gap: 7px; }
      .instance-name-wrap { flex: 1 1 240px; align-items: flex-start; }
      #instanceDisplayName { font-size: 21px; }
      .instance-meta { gap: 4px 10px; }
      .top-actions { margin-left: auto; }
      .bottom-inner { flex-wrap: wrap; justify-content: flex-start; }
      .save-state { width: 100%; }
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="title">
      <h1>妙券自动发单 2.0</h1>
      <p>这一页负责完整流程：配置参数、生成预览、人工校对、保存后正式创建 CMS 任务。</p>
      ${instanceConfig.enabled ? `<div class="instance-identity" id="instanceIdentity"><span class="instance-kicker">当前工作实例</span><div class="instance-primary-row"><span class="instance-name-wrap"><span id="instanceDisplayName">${instanceLabelText}</span><button class="instance-name-edit" id="editInstanceNameBtn" type="button" title="修改实例显示名称" aria-label="修改实例显示名称">&#9998;</button></span><span class="instance-stable-label" id="instanceStableLabel">${instanceStableLabelText}</span><span id="instanceStableId" hidden>${instanceIdText}</span></div><div class="instance-meta"><span>工作设置独立保存</span><span>控制台 ${instanceConfig.port}</span><span>浏览器 ${instanceConfig.cmsDebugPort}</span></div></div>` : ""}
    </div>
    <div class="top-actions">
      <button id="versionBtn">隐藏版本更新</button>
      <button class="check-btn" id="refreshBtn">刷新运行状态</button>
    </div>
  </header>
  <main>
    <section class="browser-warning" id="browserWarning">
      当前不是 2.0 专用可控浏览器。请从“2.0可视化控制台”正式入口启动；不要手动用普通浏览器打开控制台，否则飞书、预览页、云中客页面无法复用同一个 CDP 浏览器。
    </section>
    <section class="browser-warning" id="browserFollowWarning" style="display:none"></section>
    <section class="version-notice" id="versionNotice">
      <span id="versionNoticeText">发现新版本，可前往版本更新。</span>
      <button class="check-btn" id="versionNoticeOpenBtn">前往版本更新</button>
      <button id="versionNoticeDismissBtn">暂不更新</button>
    </section>
    <section class="license-panel" id="licensePanel">
      <div class="license-head">
        <div>
          <h2 style="margin-bottom:6px">授权检查</h2>
          <strong id="licenseMainText">正在检查授权...</strong>
        </div>
        <button class="check-btn" id="licenseRefreshBtn" type="button">重新检查</button>
      </div>
      <div class="license-diagnostics">
        <span>DNS</span><strong id="licenseDns">-</strong>
        <span>授权服务</span><strong id="licenseService">-</strong>
        <span>本机设备号</span><strong id="licenseDevice">-</strong>
        <span>处理建议</span><strong id="licenseAdvice">-</strong>
      </div>
      <div class="license-actions">
        <button class="primary" id="licenseRequestBtn" type="button">申请授权</button>
        <button id="licenseCopyDeviceBtn" type="button">复制设备号</button>
        <span class="hint" id="licenseRequestState" style="margin-top:0">未授权时可以提交申请，由管理员在总控页面审批。</span>
      </div>
    </section>
    <section class="operator-panel" id="operatorPanel">
      <div class="operator-row"><strong>当前使用人</strong><span class="hint" style="margin:0">后台直接使用本机电脑名展示，无需选择员工或输入确认码；稳定设备号只用于区分同名电脑。</span></div>
    </section>
    <section class="version-panel is-open" id="versionPanel">
      <h2>版本更新</h2>
      <div class="version-summary">
        <div class="version-line"><span>当前版本：</span><strong id="versionNumber">-</strong></div>
        <div class="version-main-state" id="versionMainState">正在检查更新...</div>
        <div class="version-update-hint" id="versionUpdateHint">启动控制台时会自动检查一次，有新版本只提示，不会强制更新。</div>
      </div>
      <div class="version-actions">
        <button class="check-btn" id="versionRefreshBtn">检查更新</button>
        <button class="primary" id="versionUpdateBtn" disabled>立即更新</button>
        <button id="versionRollbackBtn">回退到上一版本</button>
      </div>
      <div class="version-state" id="versionState">版本状态未刷新。</div>
      <details class="version-advanced">
        <summary>高级信息 / 开发信息</summary>
        <div class="version-grid" style="margin-top:12px">
          <span>当前 commit</span><strong id="versionCommit">-</strong>
          <span>GitHub 远程地址</span><strong id="versionRemote">-</strong>
          <span>当前项目目录</span><strong id="versionProjectDir">-</strong>
          <span>本地修改状态</span><strong id="versionLocalChanges">-</strong>
          <span>最近本地备份</span><strong id="versionLatestBackup">-</strong>
          <span>最近 stable tag</span><strong id="versionStableTag">-</strong>
          <span>授权状态</span><strong id="licenseStatus">-</strong>
        </div>
        <div class="version-actions">
          <button id="versionBackupBtn">创建当前稳定备份</button>
          <button id="versionOpenBackupBtn">打开备份目录</button>
        </div>
      </details>
    </section>
    <section>
      <h2>运行控制</h2>
      <div class="run-box">
        <div class="run-row"><span>状态</span><strong id="status">-</strong></div>
        <div class="run-row"><span>当前</span><strong id="step">-</strong></div>
        <div class="run-row"><span>处理进度</span><strong id="current">-</strong></div>
        <div class="run-row"><span>等待原因</span><strong id="waiting">-</strong></div>
      </div>
      <div class="actions">
        <button class="warn" id="pauseBtn">暂停</button>
        <button class="good" id="resumeBtn">继续</button>
        <button class="danger" id="stopBtn">停止</button>
      </div>
      <div class="recovery-panel" id="taskErrorDecisionPanel">
        <h3>当前条创建失败，等待人工处理</h3>
        <p id="taskErrorDecisionText">请处理页面现场后选择下一步。</p>
        <div class="recovery-actions">
          <button class="primary" id="retryCurrentTaskBtn" type="button">重试这一条</button>
          <button id="editFailedTaskPreviewBtn" type="button">返回预览修改</button>
          <button id="skipCurrentTaskBtn" type="button">跳过这一条</button>
          <button class="danger" id="stopCurrentRunBtn" type="button">停止本轮</button>
        </div>
      </div>
      <div class="recovery-panel" id="expiredScheduleDecisionPanel">
        <h3>连续四次遇到过期时间</h3>
        <p id="expiredScheduleDecisionText">当前条已经创建成功，请选择剩余任务的排程方式。</p>
        <div class="recovery-actions">
          <button class="primary" id="expiredScheduleDirectBtn" type="button">直接顺延并继续</button>
          <button id="expiredScheduleEditBtn" type="button">修改剩余间隔</button>
          <button class="danger" id="expiredScheduleStopBtn" type="button">停止本轮</button>
        </div>
      </div>
      <div class="recovery-panel" id="continueDecisionPanel">
        <h3 id="continueDecisionTitle">是否继续创建？</h3>
        <p id="continueDecisionText">请确认从哪一条开始。</p>
        <div class="recovery-actions">
          <button class="primary" id="continueFromCurrentBtn" type="button">是</button>
          <button id="continueFromNextBtn" type="button">从下一条开始</button>
          <button id="continueOpenPreviewBtn" type="button">打开预览页面</button>
        </div>
      </div>
      <div class="hint">暂停/继续/停止会在后台流程检查点生效。正式创建时仍然按已保存的预览内容执行。</div>
    </section>

    <section>
      <h2>1. 选择文档/文案来源</h2>
      <div class="panel-note">先选这次要用哪份内容：填写新的飞书文档重新生成预览，或直接打开文案库里保存好的成品。</div>
      <div class="source-warning">
        <span class="source-warning-title">注意：</span>
        <span class="source-warning-line">①如果视频太大，需要提前准备视频号代码块</span>
        <span class="source-warning-line">②文案需要标明清楚每句话的说话人，不然没办法识别。有互动托需要在说话人旁边标注：（下面还说话）</span>
      </div>
      <select class="hidden-native" id="contentSourceMode"><option value="">请选择</option><option value="feishu">读取新内容</option><option value="library">使用文案库</option></select>
      <div class="choice-grid source-mode-grid">
        <label class="choice source-mode-choice-primary"><input type="radio" name="contentSourceModeChoice" value="feishu"><span class="source-choice-body"><b>读取新内容</b><p>通过飞书 API 读取，或直接粘贴内容后重新生成预览。</p></span></label>
        <label class="choice source-mode-choice-secondary"><input type="radio" name="contentSourceModeChoice" value="library"><span class="source-choice-body"><b>使用文案库</b><p>直接打开已保存的预览成品，文案内容固定。</p></span></label>
      </div>
      <div class="source-mode-panel" id="feishuSourcePanel">
        <div class="source-card primary-source" id="feishuSourceCard">
          <h3>读取新内容</h3>
          <div class="library-disabled-note">当前使用文案库，文案内容已固定；飞书读取相关设置不需要修改。</div>
          <div class="panel-note">选择通过飞书开放平台读取完整文档，或把本次内容直接粘贴到控制台。</div>
          <select class="hidden-native" id="documentInputMode"><option value="feishu-api">飞书 API 读取</option><option value="document-paste">直接粘贴内容</option></select>
          <div class="choice-grid" style="margin-bottom:12px">
            <label class="choice"><input type="radio" name="documentInputModeChoice" value="feishu-api"><b>飞书 API 读取</b><p>通过公司后台连接读取正文和素材，不需要填写应用密钥。</p></label>
            <label class="choice"><input type="radio" name="documentInputModeChoice" value="document-paste"><b>直接粘贴内容</b><p>从飞书复制富文本并粘贴，保留正文、图片和表情包顺序。</p></label>
          </div>
          <div class="grid source-form">
            <label>当前文档标题</label>
            <div class="inline-field"><input id="feishuTitle"><span class="field-badge" id="feishuTitleBadge">已保存</span></div>
            <label class="feishu-api-field">飞书文档链接</label>
            <div class="feishu-api-field">
              <textarea id="feishuUrl"></textarea>
            </div>
            <div class="feishu-api-field"></div><div class="link-feedback feishu-api-field" id="feishuLinkFeedback">链接状态：已保存</div>
            <label class="feishu-api-field">飞书后台连接</label>
            <div class="feishu-api-field inline-field"><span id="feishuConnectionState">正在检查...</span><button id="refreshFeishuConnectionBtn" type="button">刷新</button><button id="authorizeFeishuBtn" type="button" hidden>本人飞书授权</button></div>
            <label class="document-import-field">粘贴内容</label>
            <div class="document-import-field">
              <div class="document-import-stack">
                <div class="document-import-paste-panel">
                  <div class="document-import-paste-head">
                    <div class="document-import-paste-title">粘贴文档内容</div>
                    <div class="document-import-paste-note">支持从飞书复制富文本；图片会显示在下方预览里。</div>
                  </div>
                  <div class="rich-paste-box" id="documentImportRichPaste" contenteditable="true" role="textbox" aria-multiline="true" data-placeholder="把飞书富文本直接粘贴到这里。图片会尽量保留为素材；需要保留说话人和时间，例如：豆妈 9/22 09:56:33"></div>
                  <textarea class="hidden-native" id="documentImportText"></textarea>
                  <div class="roster-upload-status" id="documentImportStatus">尚未粘贴内容。</div>
                </div>
              </div>
            </div>
          </div>
          <div class="hint">API 模式会在链接输入后自动读取真实文档标题；粘贴模式可手动填写标题。不能确定的素材会在预览里标黄或标红。</div>
          <div class="source-warning feishu-api-field"><span class="source-warning-title">读取提醒：</span><span class="source-warning-line">读取期间请暂停修改该飞书文档，并提醒其他协作者暂时不要编辑。系统仍会检查版本并自动重读，提醒不能代替完整性校验。</span></div>
        </div>
      </div>
      <div class="source-mode-panel" id="librarySourcePanel">
        <div class="source-card library-source">
          <div class="library-head">
            <div>
              <div class="library-title-row">
                <h3>使用文案库</h3>
                <div class="library-search"><input id="librarySearchInput" placeholder="搜索文案名称"></div>
              </div>
              <div class="panel-note">适合直接使用已经改好的预览成品，打开后可检查、改时间，再进入云中客设置或开始创建。</div>
            </div>
            <div class="library-tools">
              <button id="openLibraryManagerBtn" type="button">管理文案库</button>
              <button id="openSharedLibraryBtn" type="button">云端文案</button>
              <button id="refreshLibraryBtn" type="button">刷新</button>
            </div>
          </div>
          <div class="library-list" id="previewLibraryList">
            <div class="library-empty">正在读取文案库...</div>
          </div>
          <div class="library-batch-tools" id="libraryBatchTools">
            <span class="library-selection-summary" id="librarySelectionSummary">未选择文案</span>
            <div class="library-batch-actions">
              <button id="selectVisibleLibraryBtn" type="button">全选可见</button>
              <button id="clearLibrarySelectionBtn" type="button">取消选择</button>
              <button class="primary" id="batchShareLibraryBtn" type="button" disabled>批量上传共享</button>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="robotStrategySection">
      <h2>2. 发单版本</h2>
      <select class="hidden-native" id="robotStrategy"><option value="random">按页面/随机托</option><option value="fixed">固定角色前缀</option><option value="precise">精准托名单</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="robotStrategyChoice" value="random"><b>粗略版：随机托</b><p>使用当前随机托流程，同一个互动托仍会绑定同一个机器人。</p></label>
        <label class="choice"><input type="radio" name="robotStrategyChoice" value="fixed"><b>精细版：按人设名单分配</b><p>生成预览前按已上传或已保存的托人设名单分配具体说话人。</p></label>
        <div class="choice-grid-alert"><div class="choice-alert">粗略版：随机托需先在云中客页面打开【多快捷模式】</div></div>
        <div class="choice-grid-alert"><div class="choice-alert">精准版：目前只支持单组托形式</div></div>
      </div>
      <div id="preciseTuoConfig" style="margin-top:12px; display:none">
        <input type="checkbox" id="preciseTuoRosterEnabled" hidden>
        <div id="preciseTuoRosterConfig">
          <input class="hidden-native" id="tuoRosterPath">
          <input class="hidden-native" id="tuoRosterScopeId">
          <input class="hidden-native" id="tuoRosterFileInput" type="file" accept=".xlsx,.csv,.json">
          <div class="roster-upload" id="tuoRosterDropZone" role="button" tabindex="0">
            <div class="roster-upload-title">拖动托名单到这里，或点击上传</div>
            <div class="roster-upload-note">支持 XLSX/CSV/JSON，只读取“昵称”和“备注”。备注里带“备用”的托只做兜底。</div>
            <div class="roster-upload-status" id="tuoRosterUploadStatus">尚未上传名单。</div>
          </div>
          <div class="roster-tools">
            <button id="saveTuoRosterLibraryBtn" type="button">保存托人设</button>
            <button id="openTuoRosterManagerBtn" type="button">管理托人设</button>
            <button class="outline-danger" id="clearTuoRosterBtn" type="button">清空</button>
          </div>
        </div>
      </div>
    </section>

    <section id="cmsConfigSection">
      <h2>3. 云中客配置</h2>
      <div class="panel-note">选择本轮要套用的云中客页面设置；进入云中客后会应用到已绑定的托页和豆妈页，完成后仍需人工核对。</div>
      <div class="cms-config-panel">
        <input class="hidden-native" id="cmsConfigId">
        <div class="cms-config-statusbar">
          <div>
            <div class="cms-config-title">
              <h3>配置库</h3>
              <span class="cms-config-badge" id="cmsConfigStatusBadge">未选择配置</span>
            </div>
            <div class="panel-note" id="cmsConfigActiveText">进入云中客设置后，需要手动检查确认。</div>
          </div>
          <div class="library-tools">
            <button id="saveCmsConfigLibraryBtn" type="button">新增配置</button>
            <button id="openCmsConfigManagerBtn" type="button">管理配置</button>
            <button id="refreshCmsConfigLibraryBtn" type="button">刷新</button>
          </div>
        </div>
        <div class="cms-config-inline-form cms-config-wizard is-hidden" id="cmsConfigWizardForm">
          <div class="cms-wizard-heading">
            <strong id="cmsWizardPageTitle">托页面设置</strong>
            <span id="cmsWizardPageHint">第 1 步，共 2 步</span>
          </div>
          <div class="cms-wizard-pages">
            <div class="cms-wizard-page-track" id="cmsWizardPageTrack">
              <div class="cms-wizard-page is-active" id="cmsWizardTuoPage">
                <div class="cms-wizard-grid">
                  <label>托版本</label><input id="cmsWizardTuoModeDisplay" value="跟随上方发单版本：粗略托" disabled>
                </div>
                <div class="cms-wizard-grid" id="cmsWizardRoughFields" style="margin-top:12px">
                  <label>多快捷模式</label><div class="cms-wizard-readonly">默认开</div>
                  <label>群聊选择个数</label><div class="cms-wizard-readonly">默认全选</div>
                  <label>管理分组</label><input id="cmsRoughManagementGroup" name="cmsRoughManagementGroup" autocomplete="on" list="cmsHistoryRoughManagementGroup" data-cms-history-key="rough-management-group" placeholder="例如：137、AI测试-自动发单">
                  <label>机器人更换方式</label>
                  <select id="cmsRoughRobotSwitchMode">
                    <option value="random">随机更换机器人</option>
                    <option value="sequence">顺序更换机器人</option>
                    <option value="group_sequence">分组内顺序发送</option>
                    <option value="preset_sequence">预设顺序发送</option>
                  </select>
                  <label>任务备注</label><input id="cmsRoughTaskRemark" name="cmsRoughTaskRemark" autocomplete="on" list="cmsHistoryTaskRemark" data-cms-history-key="task-remark" placeholder="例如：测试88">
                </div>
                <div class="cms-wizard-grid" id="cmsWizardPreciseFields" style="display:none; margin-top:12px">
                  <label>群包含分组</label><input id="cmsPreciseGroupFilter" name="cmsPreciseGroupFilter" autocomplete="on" list="cmsHistoryPreciseGroupFilter" data-cms-history-key="precise-group-filter" placeholder="例如：1069、AI测试--自动发单">
                  <label>群聊选择个数</label><input id="cmsPreciseGroupSelectCount" placeholder="默认全选">
                  <label>机器人分组</label><input id="cmsPreciseRobotGroup" name="cmsPreciseRobotGroup" autocomplete="on" list="cmsHistoryPreciseRobotGroup" data-cms-history-key="precise-robot-group" placeholder="例如：23、AI测试-自动发单托号">
                  <label>任务备注</label><input id="cmsPreciseTaskRemark" name="cmsPreciseTaskRemark" autocomplete="on" list="cmsHistoryTaskRemark" data-cms-history-key="task-remark" placeholder="例如：测试88">
                </div>
              </div>
              <div class="cms-wizard-page" id="cmsWizardDoumaPage">
                <div class="cms-wizard-grid">
                  <label>是否使用群分组</label>
                  <div class="cms-wizard-radio">
                    <label><input type="radio" name="cmsDoumaGroupSearchMode" value="group" checked> 是</label>
                    <label><input type="radio" name="cmsDoumaGroupSearchMode" value="keyword"> 否</label>
                  </div>
                  <label>群聊选择个数</label><div class="cms-wizard-readonly" id="cmsDoumaGroupSelectDefault">默认全选</div>
                  <label id="cmsDoumaGroupValueLabel">群分组名称</label><input id="cmsDoumaGroupValue" name="cmsDoumaGroupValue" autocomplete="on" list="cmsHistoryDoumaGroupValue" data-cms-history-key="douma-group-value" placeholder="填写分组名字">
                  <label>是否使用机器人分组</label>
                  <div class="cms-wizard-radio">
                    <label><input type="radio" name="cmsDoumaRobotSearchMode" value="group" checked> 是</label>
                    <label><input type="radio" name="cmsDoumaRobotSearchMode" value="keyword"> 否</label>
                  </div>
                  <label>机器人选择个数</label><div class="cms-wizard-readonly" id="cmsDoumaRobotSelectDefault">默认 1</div>
                  <label id="cmsDoumaRobotValueLabel">机器人分组名称</label><input id="cmsDoumaRobotValue" name="cmsDoumaRobotValue" autocomplete="on" list="cmsHistoryDoumaRobotValue" data-cms-history-key="douma-robot-value" placeholder="填写分组名字">
                  <label>任务备注</label><input id="cmsDoumaTaskRemark" name="cmsDoumaTaskRemark" autocomplete="on" list="cmsHistoryTaskRemark" data-cms-history-key="task-remark" placeholder="例如：测试88">
                </div>
              </div>
            </div>
          </div>
          <datalist id="cmsHistoryRoughManagementGroup"></datalist>
          <datalist id="cmsHistoryPreciseGroupFilter"></datalist>
          <datalist id="cmsHistoryPreciseRobotGroup"></datalist>
          <datalist id="cmsHistoryDoumaGroupValue"></datalist>
          <datalist id="cmsHistoryDoumaRobotValue"></datalist>
          <datalist id="cmsHistoryTaskRemark"></datalist>
          <div class="cms-wizard-error" id="cmsConfigWizardError"></div>
          <div class="library-confirm-actions">
            <button id="cmsWizardBackBtn" type="button">上一步</button>
            <button class="primary" id="cmsWizardNextBtn" type="button">下一页：设置豆妈页面</button>
            <button id="cmsWizardCancelBtn" type="button">取消</button>
            <button class="primary" id="cmsWizardSaveBtn" type="button" style="display:none">保存配置</button>
          </div>
        </div>
        <div class="cms-config-body library-list compact" id="cmsConfigLibraryList">
          <div class="library-empty">正在读取云中客配置...</div>
        </div>
      </div>
    </section>

    <section id="robotNotInGroupSection">
      <h2>4. 机器人不在群</h2>
      <select class="hidden-native" id="robotNotInGroupPolicy"><option value="ignore">不用管，直接创建</option><option value="switch_robot">自动更换机器人后再创建</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="robotNotInGroupPolicyChoice" value="ignore"><b>不用管，直接创建</b><p>确认弹窗提示机器人不在群时，仍然点击确认创建。</p></label>
        <label class="choice"><input type="radio" name="robotNotInGroupPolicyChoice" value="switch_robot"><b>自动更换机器人后再创建</b><p>取消弹窗，点击当前页面更换机器人，再重新执行发送检查。</p></label>
      </div>
      <div class="grid" id="robotNotInGroupRetryConfig" style="margin-top:12px">
        <label>最多重试次数</label><input id="robotNotInGroupMaxRetries" type="number" min="1" value="5">
      </div>
      <div class="hint" id="robotNotInGroupHint">连续 5 次仍不在群，就停止当前批次并提示人工处理。</div>
    </section>

    <section id="rangeSettingsSection">
      <h2>5. 读取范围</h2>
      <div class="library-disabled-note">当前使用文案库，已保存预览会直接打开，下面设置不需要修改。</div>
      <div class="import-range-disabled-note">当前使用直接粘贴模式，会按粘贴的全部内容生成预览；读取范围已禁用。需要截取范围时，只粘贴需要生成的那一段。</div>
      <select class="hidden-native" id="rangeMode"><option value="range">指定开始结束位置</option><option value="full">全文读取</option><option value="heading">按节奏/天数选择</option></select>
      <div class="choice-grid three">
        <label class="choice"><input type="radio" name="rangeModeChoice" value="full"><b>全文读取</b><p>适合文档不变或只发本次内容。</p></label>
        <label class="choice"><input type="radio" name="rangeModeChoice" value="range"><b>指定开始/结束位置</b><p>从开始位置读到结束那条为止。</p></label>
        <label class="choice"><input type="radio" name="rangeModeChoice" value="heading"><b>按节奏/天数选择</b><p>通过飞书 API 读取标题结构后选择范围。</p></label>
      </div>
      <div class="grid" id="rangeInputs" style="margin-top:12px">
        <label>开始位置</label><input id="startKeyword">
        <label>结束位置</label><input id="endKeyword" placeholder="空=到文档末尾">
      </div>
      <div class="grid" id="headingRangeInputs" style="margin-top:12px; display:none">
        <label>标题结构</label><div class="inline-field"><button id="readHeadingStructureBtn" type="button">通过 API 读取标题结构</button><span class="field-badge warn" id="headingStructureBadge">待读取</span></div>
        <label>选择方式</label><div><select class="hidden-native" id="headingSelectionMode"><option value="single">单天</option><option value="range">范围</option></select><div class="choice-grid"><label class="choice"><input type="radio" name="headingSelectionModeChoice" value="single"><b>单天</b><p>选择某一天的整天或单独节奏/阶段。</p></label><label class="choice"><input type="radio" name="headingSelectionModeChoice" value="range"><b>范围</b><p>选择开始天和结束天，读取中间整天内容。</p></label></div></div>
        <label class="heading-single-field" id="headingDayLabel">第几天</label><select class="heading-single-field" id="headingDay"><option value="">请先读取标题结构</option></select>
        <label class="heading-single-field">节奏/阶段</label><select class="heading-single-field" id="headingRhythm"><option value="">整天</option></select>
        <label class="heading-range-field">开始第几天</label><select class="heading-range-field" id="headingStartDay"><option value="">请先读取标题结构</option></select>
        <label class="heading-range-field">结束第几天</label><select class="heading-range-field" id="headingEndDay"><option value="">请先读取标题结构</option></select>
        <label>自动范围</label><div class="hint" id="headingRangeHint">从选中标题下方开始，到下一个同级标题前；朋友圈默认跳过。</div>
      </div>
      <div class="hint" id="rangeHint"></div>
    </section>

    <section id="timeSettingsSection">
      <h2>6. 时间模式</h2>
      <select class="hidden-native" id="scheduleMode"><option value="doc">文档时间</option><option value="realtime">实时跟发</option><option value="catchup">补发到文档时间</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="doc"><b>文档时间</b><p>按飞书上写的时间定。适用：文案时间已经排好。</p></label>
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="realtime"><b>实时跟发</b><p>按输入的开始时间重新生成发送时间。结束时间可留空。</p></label>
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="catchup"><b>补发到文档时间</b><p>过期内容先补发，后面衔接回文档时间。</p></label>
      </div>
      <div class="hint" id="timeModeHint"></div>
      <div class="time-field-grid" id="timeFields">
        <div class="field" id="dateField"><label>第一天发单日期</label><input id="date" type="date" title="不填默认今天；第二天自动顺延"><div class="field-help">不选择时默认使用今天。</div></div>
        <div class="field" id="realtimeStartField"><label>开始时间</label><input id="realtimeStartTime" placeholder="不填默认 1 分钟后开始"></div>
        <div class="field" id="catchupStartField"><label>开始时间</label><input id="currentTime" placeholder="不填默认 1 分钟后开始"></div>
        <div class="field" id="realtimeEndField"><label>结束时间</label><input id="realtimeEndTime" placeholder="可留空"></div>
      </div>
      <div class="interval-panel" id="customIntervals">
        <div class="interval-head">
          <div>
            <h3>自定义间隔范围（可选）</h3>
            <div class="panel-note">不填就使用默认规则；只影响实时跟发和补发到文档时间。</div>
          </div>
          <div class="interval-tools">
            <select id="intervalPresetSelect"><option value="">选择已保存方案</option></select>
            <button id="saveIntervalPresetBtn" type="button">保存当前为方案</button>
            <button id="manageIntervalPresetBtn" type="button">方案设置</button>
            <button id="clearIntervalsBtn" type="button">清空自定义间隔</button>
          </div>
        </div>
        <div class="interval-preset-panel" id="intervalPresetPanel">
          <div class="interval-preset-head">
            <strong>方案设置</strong>
            <button id="closeIntervalPresetPanelBtn" type="button">关闭</button>
          </div>
          <div class="interval-preset-list" id="intervalPresetList"></div>
        </div>
        <div class="interval-grid">
          <div class="interval-item"><span>不同托之间（非互动）</span><input id="differentTuoMin" type="number" min="1" placeholder="最短"><span>-</span><input id="differentTuoMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>同一个托连续说话</span><input id="sameTuoMin" type="number" min="1" placeholder="最短"><span>-</span><input id="sameTuoMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>豆妈连续内容</span><input id="doumaSameMin" type="number" min="1" placeholder="最短"><span>-</span><input id="doumaSameMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>豆妈/托切换</span><input id="roleSwitchMin" type="number" min="1" placeholder="最短"><span>-</span><input id="roleSwitchMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
        </div>
      </div>
      <div class="hint" id="intervalDefaultHint">不填时使用默认规则：同一个托连续文字约 20-45 秒；豆妈连续内容约 45 秒；图片/表情包/视频附近约 30-50 秒；不同托非互动约 15 秒；豆妈/托切换至少 120 秒。填写自定义后，图片/表情包/视频附近会跟随对应的豆妈连续、同托、不同托或豆妈/托切换规则。</div>
      <input class="hidden-native" id="mediaMin">
      <input class="hidden-native" id="mediaMax">
    </section>

    <section>
      <h2>7. 结果和日志</h2>
      <div class="status-grid">
        <div class="stat"><div class="k">成功/失败</div><div class="v" id="counts">-</div></div>
        <div class="stat"><div class="k">缺失文件</div><div class="v" id="missing">-</div></div>
        <div class="stat"><div class="k">run 目录</div><div class="v" id="runDir">-</div></div>
        <div class="stat"><div class="k">预览内容文件</div><div class="v" id="previewPath">-</div></div>
        <div class="stat"><div class="k">失败原因</div><div class="v failed" id="failure">-</div></div>
      </div>
      <div class="recovery-panel" id="robotRecoveryPanel">
        <h3>机器人不在群，已达到自动重试上限</h3>
        <p>可以直接按当前弹窗继续创建，也可以继续尝试更换机器人。本操作会复用本轮记录和已保存的预览内容。</p>
        <div class="recovery-actions">
          <button class="primary" id="robotDirectCreateBtn" type="button">直接创建</button>
          <select id="robotDirectCreateMode" style="width:auto; min-width:138px">
            <option value="once">只允许这次</option>
            <option value="always">以后一直</option>
          </select>
          <button id="robotRetryMoreBtn" type="button">继续更换机器人重试</button>
        </div>
      </div>
      <div class="recovery-panel" id="cmsStartRecoveryPanel">
        <h3>选择本次从哪里开始创建</h3>
        <p id="cmsStartRecoveryWarning">正在读取上次创建记录和预览内容。</p>
        <div class="cms-recovery-summary">
          <strong id="cmsStartRecoveryCounts">-</strong>
          <div class="cms-recovery-list" id="cmsStartRecoveryConfirmed"></div>
        </div>
        <label class="cms-recovery-boundary" id="cmsStartRecoveryBoundary">
          <strong>上次最后一条已确认 CMS 创建的内容</strong>
          <select id="cmsStartRecoveryBoundarySelect"></select>
        </label>
        <div class="cms-recovery-options">
          <div class="cms-recovery-option">
            <div class="cms-recovery-task" id="cmsRecoveryCurrentTask"></div>
            <button class="primary" id="cmsRecoveryCurrentBtn" type="button">从这条开始创建</button>
          </div>
          <div class="cms-recovery-option">
            <div class="cms-recovery-task" id="cmsRecoveryNextTask"></div>
            <button id="cmsRecoveryNextBtn" type="button">跳过当前条，从下一条创建</button>
          </div>
          <div class="cms-recovery-option">
            <div class="cms-recovery-task" id="cmsRecoveryRestartTask"></div>
            <button class="outline-danger" id="cmsRecoveryRestartBtn" type="button">从第1条重新创建</button>
          </div>
        </div>
      </div>
      <div class="links">
        <a id="previewLink" href="#" target="_blank" style="display:none">打开预览页</a>
      </div>
      <div class="support-panel" id="supportPanel">
        <h3 id="supportTitle">处理办法</h3>
        <p id="supportMessage">先按下面步骤处理；如果仍不行，再上报给管理员。</p>
        <ol id="supportSuggestions"></ol>
        <div class="support-actions">
          <button id="supportReportBtn" type="button">上报给管理员</button>
          <span id="supportReportState"></span>
        </div>
      </div>
      <div class="preview-restore-panel" id="previewRestorePanel">
        <h3>检测到上次预览</h3>
        <p id="previewRestoreText">是否恢复上次预览页？</p>
        <select class="preview-restore-select" id="previewRestoreSelect" aria-label="选择历史预览"></select>
        <p class="preview-restore-meta" id="previewRestoreMeta"></p>
        <div class="preview-restore-actions">
          <button class="primary" id="previewRestoreBtn" type="button">恢复此预览</button>
          <button id="previewRestoreCancelBtn" type="button">取消</button>
        </div>
      </div>
      <pre id="logs"></pre>
    </section>
  </main>
  <input class="hidden-native" id="cmsUrl">
  <input class="hidden-native" id="cdpUrl">
  <input class="hidden-native" id="feishuTitleUrl">
  <select class="hidden-native" id="restoreSelection"><option value="true">是</option><option value="false">否</option></select>
  <div class="bottom-actions">
    <div class="bottom-inner">
      <span class="save-state" id="saveState">页面已就绪。</span>
      <button class="support-btn" id="supportAdviceBtn" type="button">查看处理办法</button>
      <button class="support-btn" id="supportReportBottomBtn" type="button">上报给管理员</button>
      <button id="discardBtn">放弃本轮，重新设置</button>
      <button class="outline-danger" id="exitBtn">退出</button>
      <button class="primary" id="generateBtn">保存设置，生成预览</button>
      <button id="resetCmsPageBtn" style="display:none">重新设置云中客</button>
      <button class="primary" id="startCmsBtn" style="display:none">我已设置好，开始创建任务</button>
      <button class="primary" id="nextRunBtn" style="display:none">开始下一轮发单</button>
    </div>
  </div>
  <div class="library-manager-backdrop" id="libraryManagerModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="libraryManagerTitle">
      <div class="library-manager-head">
        <div>
          <div class="library-title-row">
            <h3 id="libraryManagerTitle">管理文案库</h3>
            <div class="library-search"><input id="libraryManagerSearchInput" placeholder="搜索文案名称"></div>
          </div>
          <div class="panel-note">这里可以使用、改名或删除已保存的文案。删除只影响文案库，不删除原始 run。</div>
        </div>
        <div class="library-tools">
          <button id="refreshLibraryManagerBtn" type="button">刷新</button>
          <button id="closeLibraryManagerBtn" type="button">关闭</button>
        </div>
      </div>
      <div class="library-batch-tools library-manager-batch-tools">
        <span class="library-selection-summary" data-library-selection-summary>未选择文案</span>
        <div class="library-batch-actions">
          <button data-library-select-visible type="button">全选可见</button>
          <button data-library-clear-selection type="button">取消选择</button>
          <button class="primary" data-library-batch-share type="button" disabled>批量上传共享</button>
        </div>
      </div>
      <div class="library-manager-body" id="libraryManagerList">
        <div class="library-empty">正在读取文案库...</div>
      </div>
    </div>
  </div>
  <div class="library-manager-backdrop" id="sharedLibraryModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="sharedLibraryTitle">
      <div class="library-manager-head">
        <div>
          <div class="library-title-row">
            <h3 id="sharedLibraryTitle">云端文案</h3>
            <div class="library-search"><input id="sharedLibrarySearchInput" placeholder="搜索云端文案"></div>
            <select id="sharedLibraryGroupFilter"><option value="">全部分组</option></select>
          </div>
          <div class="panel-note">这里只显示已上传共享的文案。下载后会保存到本机文案库，素材路径会自动改成本机可用路径。</div>
        </div>
        <div class="library-tools">
          <button id="importSharedPackageBtn" type="button">导入共享包</button>
          <button id="refreshSharedLibraryBtn" type="button">刷新</button>
          <button id="closeSharedLibraryBtn" type="button">关闭</button>
        </div>
      </div>
      <input id="sharedPackageFileInput" type="file" accept=".json,application/json" hidden>
      <datalist id="sharedLibraryGroupOptions"></datalist>
      <div class="library-manager-body" id="sharedLibraryList">
        <div class="library-empty">正在读取云端文案...</div>
      </div>
    </div>
  </div>
  <div class="library-manager-backdrop" id="cmsConfigManagerModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="cmsConfigManagerTitle">
      <div class="library-manager-head">
        <div>
          <div class="library-title-row">
            <h3 id="cmsConfigManagerTitle">管理云中客配置</h3>
            <div class="library-search"><input id="cmsConfigManagerSearchInput" placeholder="搜索配置名称"></div>
          </div>
          <div class="panel-note">这里可以使用、改名或删除已保存的云中客配置。恢复后仍需要人工确认一次。</div>
        </div>
        <div class="library-tools">
          <button id="refreshCmsConfigManagerBtn" type="button">刷新</button>
          <button id="closeCmsConfigManagerBtn" type="button">关闭</button>
        </div>
      </div>
      <div class="library-manager-body" id="cmsConfigManagerList">
        <div class="library-empty">正在读取云中客配置...</div>
      </div>
    </div>
  </div>
  <div class="library-manager-backdrop" id="consoleActionModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="consoleActionTitle">
      <div class="library-manager-head">
        <div>
          <h3 id="consoleActionTitle">确认操作</h3>
          <div class="panel-note" id="consoleActionNote">请确认后继续。</div>
        </div>
      </div>
      <div class="library-confirm-body">
        <p id="consoleActionMessage"></p>
        <input class="console-action-input" id="consoleActionInput" placeholder="">
        <div class="console-action-error" id="consoleActionError"></div>
      </div>
      <div class="library-confirm-actions">
        <button id="consoleActionCancelBtn" type="button">取消</button>
        <button id="consoleActionExtraBtn" type="button" style="display:none">其他</button>
        <button class="primary" id="consoleActionConfirmBtn" type="button">确定</button>
      </div>
    </div>
  </div>
  <div class="library-manager-backdrop" id="tuoRosterManagerModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="tuoRosterManagerTitle">
      <div class="library-manager-head">
        <div>
          <div class="library-title-row">
            <h3 id="tuoRosterManagerTitle">管理托人设</h3>
            <div class="library-search"><input id="tuoRosterManagerSearchInput" placeholder="搜索托人设名称"></div>
          </div>
          <div class="panel-note">这里可以使用、改名或删除已保存的托名单。清空当前选择不会删除这里的条目。</div>
        </div>
        <div class="library-tools">
          <button id="refreshTuoRosterManagerBtn" type="button">刷新</button>
          <button id="closeTuoRosterManagerBtn" type="button">关闭</button>
        </div>
      </div>
      <div class="library-manager-body" id="tuoRosterManagerList">
        <div class="library-empty">正在读取托人设...</div>
      </div>
    </div>
  </div>
  <script>
    const ids = ["contentSourceMode","feishuUrl","feishuTitle","feishuTitleUrl","rangeMode","startKeyword","endKeyword","headingSelectionMode","headingDay","headingRhythm","headingStartDay","headingEndDay","scheduleMode","realtimeStartTime","realtimeEndTime","currentTime","date","sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax","cmsUrl","cdpUrl","cmsConfigId","robotStrategy","tuoRosterPath","tuoRosterScopeId","robotNotInGroupPolicy","robotNotInGroupMaxRetries","restoreSelection"];
    const $ = (id) => document.getElementById(id);
    let controlledBrowserReady = false;
    let controlledBrowserCdpUrl = "";
    let controlledTabDisplayReady = false;
    let manualStatusFeedbackUntil = 0;
    let versionNoticeDismissed = false;
    let savedFeishuUrl = "";
    let titleReadForFeishuUrl = "";
    let latestStatus = null;
    let statusRefreshInFlight = null;
    let statusUiRound = 0;
    let statusRequestSequence = 0;
    let latestAppliedStatusSequence = 0;
    let acceptedRunGeneration = 0;
    let latestVersionInfo = null;
    let versionAutoPrepareStarted = false;
    let versionPreparePollTimer = null;
    let headingStructure = null;
    let backendDisconnected = false;
    let statusFetchFailureCount = 0;
    let latestLicenseDiagnostics = null;
    let licenseAllowed = false;
    let licenseCheckInFlight = false;
    let licenseAutoRefreshTimer = null;
    let previewRestoreDismissed = false;
    let previewLibraryItems = [];
    let sharedLibraryItems = [];
    let sharedLibraryGroups = ["开群组", "老群组", "合集组"];
    let contentSourceMode = "";
    let activeLibraryItemId = "";
    let draggedLibraryId = "";
    let selectedLibraryShareIds = new Set();
    let sharedBatchUploading = false;
    let sharedUploadStates = new Map();
    let activeSharedDownload = null;
    let activeSharedImportXhr = null;
    let consoleActionResolver = null;
    let consoleActionOptions = null;
    let tuoRosterLibraryItems = [];
    let activeTuoRosterPath = "";
    let cmsConfigLibraryItems = [];
    let activeCmsConfigId = "";
    let cmsConfigWizardPage = "tuo";
    let cmsConfigWizardOpen = false;
    let cmsConfigWizardEditItemId = "";
    let cmsConfigWizardModeOverride = "";
    let lastCmsAutoSetupFailureReason = "";
    let latestSupportContext = null;
    let supportReportInFlight = false;
    let intervalPresets = [];
    let initialRunId = new URLSearchParams(location.search).get("runId") || "";
    let pastedDocumentImport = null;
    let pastedDocumentPlainText = "";
    let pastedDocumentPlainHtml = "";
    let feishuMetadataTimer = null;
    let feishuMetadataRequestId = 0;
    let feishuMetadataController = null;
    let feishuAuthorizationPending = false;
    let cmsStartRequestInFlight = false;
    let cmsStartFeedback = loadCmsStartFeedback();
    let cmsRecoverySummary = null;
    let cmsRecoveryLoadingRequestId = "";

    syncInstanceIdentityTitle();
    checkControlledBrowser().then(loadSettings);
    loadIntervalPresets().catch(() => {});
    refreshLicenseDiagnostics({ auto: true });
    setTimeout(() => recoverCmsStartRequest().catch(() => {}), 1200);
    refreshFeishuConnection({ retryMetadata: false }).catch(() => {});
    refreshVersionStatus({ startup: true });
    checkPreviewRestoreCandidate();
    loadPreviewLibrary().catch(() => {});
    loadTuoRosterLibrary().catch(() => {});
    loadCmsConfigLibrary().catch(() => {});
    bindContentSourceMode();
    bindCardGroup("robotStrategyChoice", "robotStrategy");
    bindCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
    bindCardGroup("documentInputModeChoice", "documentInputMode");
    bindCardGroup("rangeModeChoice", "rangeMode");
    bindCardGroup("headingSelectionModeChoice", "headingSelectionMode");
    bindCardGroup("scheduleModeChoice", "scheduleMode");
    updateRangeVisibility();
    updateRobotStrategyVisibility();
    updateRobotNotInGroupVisibility();
    updateScheduleModeVisibility();
    setInterval(() => refreshStatus().catch(() => {}), 1200);
    refreshStatus().catch(() => {});

    $("refreshBtn").addEventListener("click", refreshStatusManually);
    $("versionBtn").addEventListener("click", async () => {
      $("versionPanel").classList.toggle("is-open");
      const isOpen = $("versionPanel").classList.contains("is-open");
      $("versionBtn").textContent = isOpen ? "隐藏版本更新" : "版本更新";
      if (isOpen) await refreshVersionStatus();
    });
    $("versionNoticeOpenBtn").addEventListener("click", async () => {
      $("versionPanel").classList.add("is-open");
      $("versionBtn").textContent = "隐藏版本更新";
      $("versionPanel").scrollIntoView({ behavior: "smooth", block: "start" });
      await refreshVersionStatus();
    });
    $("versionNoticeDismissBtn").addEventListener("click", () => {
      versionNoticeDismissed = true;
      $("versionNotice").classList.remove("is-open");
    });
    $("versionRefreshBtn").addEventListener("click", refreshVersionStatus);
    $("licenseRefreshBtn").addEventListener("click", () => refreshLicenseDiagnostics({ manual: true }));
    $("licenseRequestBtn").addEventListener("click", requestLicenseAccess);
    $("licenseCopyDeviceBtn").addEventListener("click", copyLicenseDeviceId);
    $("supportAdviceBtn").addEventListener("click", openCurrentSupportAdvice);
    $("supportReportBtn").addEventListener("click", reportCurrentSupportIssue);
    $("supportReportBottomBtn").addEventListener("click", reportCurrentSupportIssue);
    if ($("editInstanceNameBtn")) $("editInstanceNameBtn").addEventListener("click", editCurrentInstanceName);
    new MutationObserver(() => handleSaveStateChanged()).observe($("saveState"), { childList: true, characterData: true, subtree: true });
    $("versionBackupBtn").addEventListener("click", () => runVersionAction("backup"));
    $("versionUpdateBtn").addEventListener("click", () => runVersionAction("update"));
    $("versionRollbackBtn").addEventListener("click", () => runVersionAction("rollback"));
    $("versionOpenBackupBtn").addEventListener("click", () => runVersionAction("open-backup-dir"));
    $("previewRestoreBtn").addEventListener("click", restorePreviousPreview);
    $("previewRestoreCancelBtn").addEventListener("click", cancelPreviewRestore);
    $("refreshLibraryBtn").addEventListener("click", () => loadPreviewLibrary({ manual: true }));
    $("openLibraryManagerBtn").addEventListener("click", openLibraryManager);
    $("openSharedLibraryBtn").addEventListener("click", openSharedLibraryManager);
    $("selectVisibleLibraryBtn").addEventListener("click", selectVisibleLibraryItems);
    $("clearLibrarySelectionBtn").addEventListener("click", clearLibrarySelection);
    $("batchShareLibraryBtn").addEventListener("click", uploadSelectedSharedPreviewLibraryItems);
    $("closeLibraryManagerBtn").addEventListener("click", closeLibraryManager);
    $("closeSharedLibraryBtn").addEventListener("click", closeSharedLibraryManager);
    $("importSharedPackageBtn").addEventListener("click", () => {
      if (activeSharedImportXhr) {
        activeSharedImportXhr.abort();
        return;
      }
      $("sharedPackageFileInput").click();
    });
    $("sharedPackageFileInput").addEventListener("change", async (event) => {
      const file = event.target.files && event.target.files[0];
      if (file) await importSharedPackageFile(file);
      event.target.value = "";
    });
    $("refreshLibraryManagerBtn").addEventListener("click", () => loadPreviewLibrary({ manual: true }));
    $("refreshSharedLibraryBtn").addEventListener("click", () => loadSharedLibrary({ manual: true }));
    $("librarySearchInput").addEventListener("input", renderPreviewLibrary);
    $("libraryManagerSearchInput").addEventListener("input", renderLibraryManager);
    $("sharedLibrarySearchInput").addEventListener("input", renderSharedLibrary);
    $("sharedLibraryGroupFilter").addEventListener("change", renderSharedLibrary);
    document.addEventListener("change", (event) => {
      const checkbox = event.target.closest && event.target.closest("input[data-library-select]");
      if (!checkbox) return;
      const id = checkbox.dataset.librarySelect || "";
      if (!id) return;
      if (checkbox.checked) selectedLibraryShareIds.add(id);
      else selectedLibraryShareIds.delete(id);
      syncLibrarySelectionControls();
    });
    $("libraryManagerModal").addEventListener("click", (event) => {
      if (event.target === $("libraryManagerModal")) closeLibraryManager();
    });
    $("sharedLibraryModal").addEventListener("click", (event) => {
      if (event.target === $("sharedLibraryModal")) closeSharedLibraryManager();
    });
    $("consoleActionModal").addEventListener("click", (event) => {
      if (event.target === $("consoleActionModal")) closeConsoleAction(false);
    });
    $("consoleActionCancelBtn").addEventListener("click", () => closeConsoleAction(false));
    $("consoleActionExtraBtn").addEventListener("click", () => closeConsoleAction(false, "extra"));
    $("consoleActionConfirmBtn").addEventListener("click", submitConsoleAction);
    $("consoleActionInput").addEventListener("keydown", (event) => {
      if (event.key === "Enter") submitConsoleAction();
      if (event.key === "Escape") closeConsoleAction(false);
    });
    $("saveTuoRosterLibraryBtn").addEventListener("click", saveCurrentTuoRosterToLibrary);
    $("openTuoRosterManagerBtn").addEventListener("click", openTuoRosterManager);
    $("closeTuoRosterManagerBtn").addEventListener("click", closeTuoRosterManager);
    $("refreshTuoRosterManagerBtn").addEventListener("click", () => loadTuoRosterLibrary({ manual: true }));
    $("tuoRosterManagerSearchInput").addEventListener("input", renderTuoRosterManager);
    $("tuoRosterManagerModal").addEventListener("click", (event) => {
      if (event.target === $("tuoRosterManagerModal")) closeTuoRosterManager();
    });
    $("saveCmsConfigLibraryBtn").addEventListener("click", toggleCmsConfigWizard);
    $("openCmsConfigManagerBtn").addEventListener("click", openCmsConfigManager);
    $("closeCmsConfigManagerBtn").addEventListener("click", closeCmsConfigManager);
    $("refreshCmsConfigLibraryBtn").addEventListener("click", () => loadCmsConfigLibrary({ manual: true }));
    $("refreshCmsConfigManagerBtn").addEventListener("click", () => loadCmsConfigLibrary({ manual: true }));
    $("cmsConfigManagerSearchInput").addEventListener("input", renderCmsConfigManager);
    $("cmsConfigManagerModal").addEventListener("click", (event) => {
      if (event.target === $("cmsConfigManagerModal")) closeCmsConfigManager();
    });
    $("cmsWizardBackBtn").addEventListener("click", () => setCmsConfigWizardPage("tuo"));
    $("cmsWizardNextBtn").addEventListener("click", () => {
      if (validateCmsWizardTuoPage()) setCmsConfigWizardPage("douma");
    });
    $("cmsWizardCancelBtn").addEventListener("click", () => setCmsConfigWizardOpen(false));
    $("cmsWizardSaveBtn").addEventListener("click", submitCmsConfigWizard);
    document.querySelectorAll('input[name="cmsDoumaGroupSearchMode"], input[name="cmsDoumaRobotSearchMode"]').forEach((input) => {
      input.addEventListener("change", updateCmsWizardDoumaLabels);
    });
    setCmsConfigWizardPage("tuo");
    setCmsConfigWizardOpen(false, { resetPage: false, silent: true });
    updateCmsWizardTuoMode();
    updateCmsWizardDoumaLabels();
    initCmsWizardInputHistory();
    $("feishuUrl").addEventListener("input", handleFeishuUrlChanged);
    $("feishuUrl").addEventListener("paste", () => setTimeout(handleFeishuUrlChanged, 0));
    $("refreshFeishuConnectionBtn").addEventListener("click", () => refreshFeishuConnection({ retryMetadata: true }));
    $("authorizeFeishuBtn").addEventListener("click", startFeishuAuthorization);
    window.addEventListener("focus", async () => {
      if (!feishuAuthorizationPending) return;
      const status = await refreshFeishuConnection({ retryMetadata: false });
      if (status?.personalAuthorized) {
        feishuAuthorizationPending = false;
        scheduleFeishuMetadataRead({ immediate: true });
      }
    });
    $("feishuTitle").addEventListener("input", handleFeishuTitleEdited);
    $("documentInputMode").addEventListener("change", updateDocumentInputModeVisibility);
    $("documentImportRichPaste").addEventListener("paste", handleDocumentImportPaste);
    $("documentImportRichPaste").addEventListener("input", syncDocumentImportRichPaste);
    $("readHeadingStructureBtn").addEventListener("click", readHeadingStructure);
    $("headingDay").addEventListener("change", () => {
      updateHeadingRhythmOptions();
      setButtons(latestStatus?.status || "ready");
    });
    $("headingRhythm").addEventListener("change", () => {
      updateHeadingRangeHint();
      setButtons(latestStatus?.status || "ready");
    });
    $("headingStartDay").addEventListener("change", () => {
      updateHeadingEndDayOptions();
      setButtons(latestStatus?.status || "ready");
    });
    $("headingEndDay").addEventListener("change", () => {
      updateHeadingRangeHint();
      setButtons(latestStatus?.status || "ready");
    });
    $("pauseBtn").addEventListener("click", () => sendControl("pause"));
    $("resumeBtn").addEventListener("click", handleResumeClick);
    $("stopBtn").addEventListener("click", () => sendControl("stop"));
    $("retryCurrentTaskBtn").addEventListener("click", () => sendControl("retry_current"));
    $("editFailedTaskPreviewBtn").addEventListener("click", openPreviewToEditFailedTask);
    $("skipCurrentTaskBtn").addEventListener("click", () => sendControl("skip_current"));
    $("stopCurrentRunBtn").addEventListener("click", () => sendControl("stop"));
    $("expiredScheduleDirectBtn").addEventListener("click", () => sendControl("expired_schedule_direct"));
    $("expiredScheduleEditBtn").addEventListener("click", openExpiredScheduleEditor);
    $("expiredScheduleStopBtn").addEventListener("click", () => sendControl("stop"));
    $("continueFromCurrentBtn").addEventListener("click", () => continueFromSelected("current"));
    $("continueFromNextBtn").addEventListener("click", () => continueFromSelected("next"));
    $("continueOpenPreviewBtn").addEventListener("click", openPreviewFromContinuePanel);
    $("robotNotInGroupMaxRetries").addEventListener("input", updateRobotNotInGroupVisibility);
    $("preciseTuoRosterEnabled").addEventListener("change", () => {
      $("robotStrategy").value = $("preciseTuoRosterEnabled").checked ? "precise" : "fixed";
      syncRobotStrategyGroup();
    });
    $("tuoRosterDropZone").addEventListener("click", () => $("tuoRosterFileInput").click());
    $("tuoRosterDropZone").addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        $("tuoRosterFileInput").click();
      }
    });
    $("tuoRosterFileInput").addEventListener("change", () => {
      const file = $("tuoRosterFileInput").files?.[0];
      if (file) uploadTuoRosterFile(file);
    });
    $("tuoRosterDropZone").addEventListener("dragover", (event) => {
      event.preventDefault();
      $("tuoRosterDropZone").classList.add("is-dragging");
    });
    $("tuoRosterDropZone").addEventListener("dragleave", () => $("tuoRosterDropZone").classList.remove("is-dragging"));
    $("tuoRosterDropZone").addEventListener("drop", (event) => {
      event.preventDefault();
      $("tuoRosterDropZone").classList.remove("is-dragging");
      const file = event.dataTransfer?.files?.[0];
      if (file) uploadTuoRosterFile(file);
    });
    $("clearTuoRosterBtn").addEventListener("click", clearCurrentTuoRoster);
    $("clearIntervalsBtn").addEventListener("click", clearCustomIntervals);
    $("intervalPresetSelect").addEventListener("change", applySelectedIntervalPreset);
    $("saveIntervalPresetBtn").addEventListener("click", saveCurrentIntervalPreset);
    $("manageIntervalPresetBtn").addEventListener("click", toggleIntervalPresetPanel);
    $("closeIntervalPresetPanelBtn").addEventListener("click", () => $("intervalPresetPanel").classList.remove("is-open"));
    $("discardBtn").addEventListener("click", async () => {
      const confirmed = await askConsoleConfirm({
        title: "放弃本轮，重新设置",
        note: "主动放弃，不记录失败。",
        message: [
          "确认放弃当前 run？",
          "",
          "会执行：",
          "1. 停止当前流程",
          "2. 清空本轮运行记录",
          "3. 关闭当前预览页",
          "",
          "不会删除：",
          "- 文案库内容",
          "- 已保存的预览内容",
          "",
          "下一步：重新设置后，再生成预览。"
        ].join("\\n"),
        confirmText: "放弃本轮",
        danger: true
      });
      if (!confirmed) return;
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再操作。";
        return;
      }
      setButtons("running");
      $("discardBtn").disabled = true;
      $("saveState").textContent = "正在放弃本轮，清空预览状态并关闭预览页。";
      let result;
      try {
        result = await submitAbandonCurrentRun();
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，放弃本轮未完成。请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (!result.ok) {
        setButtons(latestStatus?.status || "ready");
        $("saveState").textContent = result.error || "放弃本轮失败。";
        await refreshStatus({ manual: true }).catch(() => {});
        return;
      }
      if (result.accepted && result.state?.status === "cancelling") {
        latestStatus = result.state;
        manualStatusFeedbackUntil = 0;
        applyStatusSnapshot(latestStatus, { taskStarted: true });
        $("saveState").textContent = result.message || "正在取消并结束本轮；后台退出后会自动回到设置，无需重复点击。";
        return;
      }
      clearCurrentRunId();
      latestStatus = result.state || {
        ...(latestStatus || {}),
        status: "ready",
        step: "idle",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        activeLibraryItemId: "",
        activeLibraryItemName: ""
      };
      syncActiveLibraryItemFromStatus(latestStatus);
      setContentSourceMode("", { silent: true });
      updateLibraryGeneratedSettingsDisabledMode();
      setButtons(latestStatus.status || "ready");
      $("saveState").textContent = "本轮已放弃，请重新设置文档、时间和读取范围，然后点击“保存设置，生成预览”。";
      await refreshStatus({ manual: true });
    });
    $("exitBtn").addEventListener("click", async () => {
      const confirmed = await askConsoleConfirm({
        title: "退出 2.0 程序",
        note: "主动退出，不记录失败。",
        message: [
          "确认退出 2.0 程序？",
          "",
          "会执行：",
          "1. 停止当前流程",
          "2. 关闭控制台和预览页",
          "3. 关闭后台服务",
          "",
          "不会删除：",
          "- 已保存的预览内容",
          "",
          "下次启动：可恢复上次预览。"
        ].join("\\n"),
        confirmText: "退出程序",
        danger: true
      });
      if (!confirmed) return;
      $("exitBtn").disabled = true;
      $("exitBtn").textContent = "正在退出...";
      $("saveState").textContent = "正在退出 2.0 程序；本次不记录失败，已保存的预览内容不会删除。";
      try {
        await postJson("/api/shutdown", {});
        try { window.close(); } catch {}
        setTimeout(() => {
          document.body.innerHTML = "<main><section><h2>已退出 2.0 程序</h2><p class='hint'>本次主动退出不记录失败。已保存的预览内容不会删除；如果当前标签页未自动关闭，可以直接关闭它；下次使用请重新双击 2.0 可视化控制台入口，并按需恢复上次预览。</p></section></main>";
        }, 300);
      } catch (error) {
        $("saveState").textContent = "退出程序请求失败：" + (error?.message || error) + "。如果页面已断开，可以直接关闭标签页后重新双击启动。";
        $("exitBtn").disabled = false;
        $("exitBtn").textContent = "退出";
      }
    });
    $("generateBtn").addEventListener("click", async () => {
      if (contentSourceMode !== "feishu") {
        $("saveState").textContent = contentSourceMode === "library"
          ? "当前选择使用文案库，请在文案库列表里点“使用”打开预览。"
          : "请先在第 1 步选择“读取新内容”或“使用文案库”。";
        return;
      }
      const headingRequirement = headingRangeGenerationRequirement();
      if (headingRequirement.blocked) {
        $("saveState").textContent = headingRequirement.message;
        $("headingRangeHint").textContent = headingRequirement.message;
        return;
      }
      if (!ensurePreciseRosterBeforeGenerate()) return;
      const documentMode = normalizeActiveDocumentInputMode();
      const importMode = documentMode === "document-paste";
      const feishuApiMode = documentMode === "feishu-api";
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      let documentInput = null;
      if (importMode) {
        try {
          documentInput = readDocumentImportInput();
        } catch (error) {
          $("saveState").textContent = error?.message || String(error);
          return;
        }
      } else if (feishuApiMode) {
        const documentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
        if (!documentUrl) {
          $("saveState").textContent = "请填写有效的飞书文档链接。";
          return;
        }
        documentInput = { mode: "feishu-api", documentUrl };
      }
      setButtons("running");
      $("saveState").textContent = importMode
        ? "已保存设置，正在解析粘贴内容并生成预览。"
        : feishuApiMode
          ? "正在通过公司飞书后台读取文档并生成预览。"
          : "已保存设置，正在生成预览。";
      let result;
      try {
        result = await submitImportDocumentPreview(documentInput);
      } catch (error) {
        if (["PRECISE_TUO_ROSTER_REQUIRED", "PRECISE_TUO_ROSTER_INVALID"].includes(error?.code)) {
          markPreciseRosterRequired(error?.message || "请先上传或选择托人设名单");
          setButtons(latestStatus?.status || "ready");
          return;
        }
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，生成预览不会继续。请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (result.code === "preview_dirty") return;
      if (!result.ok) $("saveState").textContent = result.error || "保存设置失败。";
      else {
        acceptStartedTaskStatus(result.state);
        if (feishuApiMode) {
          savedFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
          titleReadForFeishuUrl = savedFeishuUrl;
          $("feishuTitleUrl").value = savedFeishuUrl;
          $("feishuLinkFeedback").textContent = "链接状态：已通过 API 提交读取";
          $("feishuLinkFeedback").className = "link-feedback good";
        }
        $("feishuTitleBadge").textContent = feishuApiMode ? "API 读取中" : "已粘贴";
        $("feishuTitleBadge").className = "field-badge good";
      }
      await refreshStatus();
    });

    async function submitGeneratePreview(options = {}) {
      const cooldownChoice = options.previousSuccessTuoChoice || await askPreviousSuccessTuoCooldown();
      const result = await postJson("/api/generate-preview", {
        settings: readSettings(),
        forceRegeneratePreview: options.forceRegeneratePreview === true,
        previousSuccessTuoCooldown: cooldownChoice.enabled === true,
        previousSuccessTuoNicknames: cooldownChoice.nicknames || []
      });
      if (result.code !== "preview_dirty") return result;
      setButtons("ready");
      const confirmed = confirm(result.error || "已有预览页有未保存修改。确认放弃这些修改并重新生成预览？");
      if (!confirmed) {
        $("saveState").textContent = "已取消重新生成，当前预览页未保存修改仍保留。";
        await refreshStatus({ manual: true });
        return result;
      }
      setButtons("running");
      $("saveState").textContent = "已确认放弃旧预览未保存修改，正在重新生成预览。";
      return submitGeneratePreview({
        forceRegeneratePreview: true,
        previousSuccessTuoChoice: cooldownChoice
      });
    }

    async function submitImportDocumentPreview(documentInput, options = {}) {
      const cooldownChoice = options.previousSuccessTuoChoice || await askPreviousSuccessTuoCooldown();
      const result = await postJson("/api/import-document-preview", {
        settings: readSettings(),
        document: documentInput,
        forceRegeneratePreview: options.forceRegeneratePreview === true,
        previousSuccessTuoCooldown: cooldownChoice.enabled === true,
        previousSuccessTuoNicknames: cooldownChoice.nicknames || []
      });
      if (result.code !== "preview_dirty") return result;
      setButtons("ready");
      const confirmed = confirm(result.error || "已有预览页有未保存修改。确认放弃这些修改并重新生成预览？");
      if (!confirmed) {
        $("saveState").textContent = "已取消重新生成，当前预览页未保存修改仍保留。";
        await refreshStatus({ manual: true });
        return result;
      }
      setButtons("running");
      $("saveState").textContent = "已确认放弃旧预览未保存修改，正在导入文档生成预览。";
      return submitImportDocumentPreview(documentInput, {
        forceRegeneratePreview: true,
        previousSuccessTuoChoice: cooldownChoice
      });
    }

    async function askPreviousSuccessTuoCooldown() {
      if ($("robotStrategy")?.value !== "precise") return { enabled: false, nicknames: [] };
      let result;
      try {
        result = await fetchJson("/api/previous-success-tuo-cooldown");
      } catch {
        return { enabled: false, nicknames: [] };
      }
      const candidate = result?.candidate || {};
      const nicknames = Array.isArray(candidate.nicknames) ? candidate.nicknames.filter(Boolean) : [];
      if (!candidate.available || !nicknames.length) return { enabled: false, nicknames: [] };
      const preview = nicknames.slice(0, 8).join("、") + (nicknames.length > 8 ? " 等" : "");
      const confirmed = await askConsoleConfirm({
        title: "上一轮成功托冷却",
        note: "只影响本次精准托预览分配。",
        message: [
          "检测到上一轮已成功创建的托：" + preview,
          "",
          "是否把这些托加入本轮冷却池？",
          "选择“是”后，短时间内会优先避开这些托；候选不够时才会兜底使用。"
        ].join("\\n"),
        confirmText: "是，加入冷却",
        cancelText: "否，正常生成"
      });
      return confirmed ? { enabled: true, nicknames } : { enabled: false, nicknames: [] };
    }

    async function submitAbandonCurrentRun() {
      return postJsonResult("/api/abandon-current-run", {});
    }
    $("startCmsBtn").addEventListener("click", async () => {
      if (latestStatus?.status === "paused" || latestStatus?.control === "paused") {
        await startCmsWithSettings(readSettings(), "当前创建已暂停，正在继续。");
        return;
      }
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再开始创建。";
        return;
      }
      await startCmsWithSettings(readSettings(), "已确认云中客设置，正在开始正式创建。");
    });
    $("cmsRecoveryCurrentBtn").addEventListener("click", () => startFromCmsRecovery("retry_current"));
    $("cmsRecoveryNextBtn").addEventListener("click", () => startFromCmsRecovery("start_next"));
    $("cmsRecoveryRestartBtn").addEventListener("click", () => startFromCmsRecovery("restart"));
    $("cmsStartRecoveryBoundarySelect").addEventListener("change", renderCmsRecoveryOptions);
    $("resetCmsPageBtn").addEventListener("click", async () => {
      const choice = await openConsoleAction({
        title: "只重新设置异常页面",
        note: "正常页面的绑定和设置会保留；执行中的整轮会停在当前条。",
        message: "请选择需要重新建立可信绑定的页面。系统不会按标签顺序、当前焦点或相同网址猜测角色。",
        confirmText: "重新设置托页",
        extraText: "重新设置豆妈页",
        cancelText: "取消"
      });
      const repairCmsRole = choice.action === "confirm" ? "tuo" : choice.action === "extra" ? "douma" : "";
      if (!repairCmsRole) return;
      setButtons("running");
      $("saveState").textContent = "正在只重建" + (repairCmsRole === "douma" ? "豆妈页" : "托页") + "，另一页面保持不变。";
      try {
        const result = await postJson("/api/prepare-cms", { settings: readSettings(), repairCmsRole });
        if (!result.ok) throw new Error(result.error || "重新设置云中客页面失败。");
        await refreshStatus({ manual: true });
      } catch (error) {
        $("saveState").textContent = "重新设置云中客页面失败：" + (error?.message || error);
      }
    });
    $("nextRunBtn").addEventListener("click", async () => {
      if (latestStatus && (latestStatus.status === "running" || latestStatus.status === "paused")) {
        $("saveState").textContent = "当前流程还在运行，不能开始下一轮。";
        return;
      }
      setButtons("running");
      $("saveState").textContent = "正在准备下一轮，保留当前配置。";
      let result;
      try {
        result = await postJson("/api/next-run", {});
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (!result.ok) {
        $("saveState").textContent = result.error || "开始下一轮失败。";
        await refreshStatus({ manual: true });
        return;
      }
      clearCurrentRunId();
      statusUiRound += 1;
      latestAppliedStatusSequence = 0;
      cmsStartFeedback = null;
      cmsRecoverySummary = null;
      cmsRecoveryLoadingRequestId = "";
      cmsStartRequestInFlight = false;
      saveCmsStartFeedback();
      renderCmsStartFeedback(null);
      latestStatus = result.state || {
        ...(latestStatus || {}),
        status: "ready",
        step: "idle",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        successCount: 0,
        failureCount: 0,
        currentIndex: 0,
        totalCount: 0
      };
      acceptedRunGeneration = Number(latestStatus.runGeneration || acceptedRunGeneration || 0);
      applyStatusSnapshot(latestStatus, { taskStarted: true });
      manualStatusFeedbackUntil = Date.now() + 5000;
      $("saveState").textContent = "已进入下一轮，可以修改飞书链接、时间模式，或直接生成新预览。";
      await refreshStatus({ manual: true });
    });
    $("robotDirectCreateBtn").addEventListener("click", async () => {
      const mode = $("robotDirectCreateMode").value === "always" ? "always" : "once";
      if (mode === "always") {
        if (!confirm("确认以后一直直接创建？这会把“机器人不在群”设置保存为“不用管，直接创建”。")) return;
        $("robotNotInGroupPolicy").value = "ignore";
        syncCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
        updateRobotNotInGroupVisibility();
        await startCmsWithSettings(readSettings(), "已保存为以后一直直接创建，正在用当前 run 重新开始正式创建。");
        return;
      }
      if (!confirm("确认只允许这次直接创建？本次会忽略机器人不在群提示，但不会修改以后默认设置。")) return;
      await startCmsWithSettings(readSettings(), "已选择本次直接创建，正在用当前 run 重新开始正式创建。", {
        robotNotInGroupPolicy: "ignore"
      });
    });
    $("robotRetryMoreBtn").addEventListener("click", async () => {
      const settings = {
        ...readSettings(),
        robotNotInGroupPolicy: "switch_robot",
        robotNotInGroupMaxRetries: Math.max(1, Number($("robotNotInGroupMaxRetries").value || 5))
      };
      await startCmsWithSettings(settings, "已选择继续更换机器人重试，正在用当前 run 重新开始正式创建。");
    });

    async function loadCmsRecoveryPanel(record) {
      if (!feedbackBelongsToCurrentRun(record) || !["failed", "unknown", "recovery_required"].includes(record?.status)) return;
      $("cmsStartRecoveryPanel").classList.add("is-open");
      if (cmsRecoverySummary && String(cmsRecoverySummary.requestId || "") === String(record.requestId || "")) {
        populateCmsRecoveryBoundary();
        renderCmsRecoveryOptions();
        return;
      }
      if (cmsRecoveryLoadingRequestId === record.requestId) return;
      cmsRecoveryLoadingRequestId = record.requestId;
      $("cmsStartRecoveryWarning").textContent = "正在读取上次创建记录和预览内容。";
      try {
        const result = await fetchJson("/api/start-cms-recovery?runId=" + encodeURIComponent(record.runId) + "&requestId=" + encodeURIComponent(record.requestId));
        cmsRecoverySummary = result.recovery;
        populateCmsRecoveryBoundary();
        renderCmsRecoveryOptions();
      } catch (error) {
        cmsRecoverySummary = null;
        $("cmsStartRecoveryWarning").textContent = "无法读取续发内容：" + (error?.message || error);
      } finally {
        cmsRecoveryLoadingRequestId = "";
      }
    }

    function populateCmsRecoveryBoundary() {
      const summary = cmsRecoverySummary;
      const select = $("cmsStartRecoveryBoundarySelect");
      select.innerHTML = "";
      const none = document.createElement("option");
      none.value = "0";
      none.textContent = "没有确认创建任何一条";
      select.appendChild(none);
      for (const task of summary?.tasks || []) {
        const option = document.createElement("option");
        option.value = String(task.index);
        option.textContent = "第 " + task.index + " 条｜" + recoveryTaskTitle(task);
        select.appendChild(option);
      }
      $("cmsStartRecoveryBoundary").classList.toggle("is-open", Boolean(summary?.requiresBoundarySelection));
    }

    function renderCmsRecoveryOptions() {
      const summary = cmsRecoverySummary;
      if (!summary) return;
      const lastConfirmedIndex = summary.requiresBoundarySelection
        ? Number($("cmsStartRecoveryBoundarySelect").value || 0)
        : 0;
      const boundaryIndex = summary.requiresBoundarySelection
        ? lastConfirmedIndex + 1
        : Number(summary.boundary?.index || 0);
      const currentTask = summary.tasks.find((task) => task.index === boundaryIndex) || null;
      const nextTask = summary.tasks.find((task) => task.index === boundaryIndex + 1) || null;
      const restartTask = summary.tasks[0] || null;
      const confirmed = summary.requiresBoundarySelection
        ? summary.tasks.filter((task) => task.index <= lastConfirmedIndex)
        : summary.confirmedTasks;

      $("cmsStartRecoveryWarning").textContent = summary.warning || "请选择本次创建起点。点击任意一个选项后会立即开始创建任务。";
      $("cmsStartRecoveryCounts").textContent = "上次已确认 CMS 创建 " + confirmed.length + " 条；预览共 " + summary.total + " 条。没有群发送回执时，这里只代表 CMS 创建状态。";
      const list = $("cmsStartRecoveryConfirmed");
      list.innerHTML = "";
      if (!confirmed.length) {
        const empty = document.createElement("div");
        empty.textContent = "没有可确认的已创建内容。";
        list.appendChild(empty);
      } else {
        for (const task of confirmed) list.appendChild(createRecoveryTaskElement(task, "已确认 CMS 创建"));
      }
      const currentStatus = currentTask && /结果未知/.test(currentTask.statusLabel || "")
        ? "将重新提交结果未知的当前条，可能产生重复"
        : currentTask?.statusLabel;
      renderRecoveryTaskBox("cmsRecoveryCurrentTask", currentTask, currentTask ? currentStatus : "没有可继续的任务");
      renderRecoveryTaskBox("cmsRecoveryNextTask", nextTask, currentTask ? "将跳过第 " + currentTask.index + " 条，下一条为" : "没有边界任务");
      renderRecoveryTaskBox("cmsRecoveryRestartTask", restartTask, "将从第1条重新创建，可能产生重复");
      $("cmsRecoveryCurrentBtn").disabled = !currentTask;
      $("cmsRecoveryNextBtn").disabled = !nextTask;
      $("cmsRecoveryRestartBtn").disabled = !restartTask;
    }

    function createRecoveryTaskElement(task, statusText) {
      const box = document.createElement("div");
      box.className = "cms-recovery-task";
      const title = document.createElement("strong");
      title.textContent = "第 " + task.index + " 条｜" + recoveryTaskTitle(task) + "｜" + (statusText || task.statusLabel);
      const content = document.createElement("div");
      content.className = "cms-recovery-content";
      content.textContent = task.content || task.mediaName || "（无文字内容）";
      box.append(title, content);
      return box;
    }

    function renderRecoveryTaskBox(id, task, statusText) {
      const target = $(id);
      target.innerHTML = "";
      if (!task) {
        target.textContent = statusText;
        return;
      }
      const content = createRecoveryTaskElement(task, statusText);
      target.replaceWith(Object.assign(content, { id }));
    }

    function recoveryTaskTitle(task) {
      return [task.role === "douma" ? "豆妈" : task.role === "tuo" ? "托" : task.role, task.speaker, task.date, task.time, task.type]
        .filter(Boolean).join(" / ");
    }

    async function startFromCmsRecovery(mode) {
      const summary = cmsRecoverySummary;
      if (!summary || !feedbackBelongsToCurrentRun(cmsStartFeedback) || !["failed", "unknown", "recovery_required"].includes(cmsStartFeedback?.status)) return;
      const lastConfirmedIndex = summary.requiresBoundarySelection
        ? Number($("cmsStartRecoveryBoundarySelect").value || 0)
        : 0;
      const recoveryDecision = {
        oldRequestId: cmsStartFeedback.requestId,
        mode,
        previewSignature: summary.previewSignature,
        lastConfirmedIndex
      };
      await startCmsWithSettings(readSettings(), "已按选择的位置开始创建任务。", null, { recoveryDecision });
    }

    async function startCmsWithSettings(settings, message, temporarySettings = null, startOptions = {}) {
      const recoveryDecision = startOptions?.recoveryDecision || null;
      const activeRecoveryBeingResolved = recoveryDecision && feedbackBelongsToCurrentRun(cmsStartFeedback) && ["failed", "unknown", "recovery_required"].includes(cmsStartFeedback?.status);
      if (cmsStartRequestInFlight || (!activeRecoveryBeingResolved && feedbackBelongsToCurrentRun(cmsStartFeedback) && ["received", "checking", "accepted", "running", "unknown", "recovery_required"].includes(cmsStartFeedback?.status))) {
        renderCmsStartFeedback(cmsStartFeedback || { status: "checking", message: "正在检查创建条件，请勿重复点击。" });
        return;
      }
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再开始创建。";
        return;
      }
      setButtons("running");
      updateRobotRecoveryActions(null);
      const requestId = crypto.randomUUID();
      cmsStartRequestInFlight = true;
      cmsStartFeedback = { requestId, runId: currentRunId(), status: "checking", message: "正在检查创建条件，后台确认前不会重复启动。" };
      saveCmsStartFeedback();
      renderCmsStartFeedback(cmsStartFeedback);
      let result;
      try {
        result = await postJson("/api/start-cms", { settings, temporarySettings, recoveryDecision, runId: currentRunId(), requestId }, 15000);
      } catch (error) {
        if (error?.data?.recovery) {
          cmsRecoverySummary = error.data.recovery;
          const prior = error.data.request || {};
          cmsStartFeedback = {
            ...prior,
            requestId: String(prior.requestId || cmsRecoverySummary.requestId || ""),
            runId: currentRunId(),
            status: "recovery_required",
            message: error?.message || "检测到历史创建记录，请先选择从哪一条开始。"
          };
          saveCmsStartFeedback();
          renderCmsStartFeedback(cmsStartFeedback);
          cmsStartRequestInFlight = false;
          setButtons(latestStatus?.status || "waiting");
          return;
        }
        if (error?.data?.request) {
          cmsStartFeedback = error.data.request;
          saveCmsStartFeedback();
          renderCmsStartFeedback(cmsStartFeedback);
          cmsStartRequestInFlight = false;
          setButtons(latestStatus?.status || "waiting");
          return;
        }
        if (error?.network || error?.code === "CLIENT_TIMEOUT") {
          cmsStartFeedback = { ...cmsStartFeedback, status: "unknown", message: "请求响应中断，正在按请求编号核对后台是否已受理。" };
          saveCmsStartFeedback();
          renderCmsStartFeedback(cmsStartFeedback);
          await reconcileCmsStartRequest(cmsStartFeedback);
          cmsStartRequestInFlight = false;
          setButtons(latestStatus?.status || "waiting");
          return;
        }
        cmsStartFeedback = { ...cmsStartFeedback, status: "rejected", message: error?.message || "本次启动未成功。" };
        saveCmsStartFeedback();
        renderCmsStartFeedback(cmsStartFeedback);
        cmsStartRequestInFlight = false;
        setButtons(latestStatus?.status || "waiting");
        return;
      }
      cmsStartRequestInFlight = false;
      cmsStartFeedback = result.request || { ...cmsStartFeedback, status: "accepted", message: message || "创建请求已受理。" };
      saveCmsStartFeedback();
      renderCmsStartFeedback(cmsStartFeedback);
      if (!result.ok) {
        cmsStartFeedback = { ...cmsStartFeedback, status: "rejected", message: result.error || "开始创建失败。" };
        saveCmsStartFeedback();
        renderCmsStartFeedback(cmsStartFeedback);
        await refreshStatus({ manual: true });
        return;
      }
      await refreshStatus({ manual: true });
    }

    function cmsStartStorageKey() {
      return "mq-cms-start:" + location.port;
    }

    function loadCmsStartFeedback() {
      try { return JSON.parse(sessionStorage.getItem("mq-cms-start:" + location.port) || "null"); } catch { return null; }
    }

    function saveCmsStartFeedback() {
      try {
        if (cmsStartFeedback?.requestId) sessionStorage.setItem(cmsStartStorageKey(), JSON.stringify(cmsStartFeedback));
        else sessionStorage.removeItem(cmsStartStorageKey());
      } catch {}
    }

    function renderCmsStartFeedback(record) {
      const recoveryOpen = feedbackBelongsToCurrentRun(record) && ["failed", "unknown", "recovery_required"].includes(record?.status);
      $("cmsStartRecoveryPanel").classList.toggle("is-open", recoveryOpen);
      if (recoveryOpen) {
        loadCmsRecoveryPanel(record);
      } else if (cmsRecoverySummary?.requestId !== record?.requestId) {
        cmsRecoverySummary = null;
      }
      if (!record?.message) return;
      const labels = { received: "后台已收到", checking: "正在检查", accepted: "已受理", running: "已启动", rejected: "本次未启动", failed: "创建未完成", unknown: "请选择续发位置", recovery_required: "请选择续发位置", completed: "创建完成" };
      $("saveState").textContent = (labels[record.status] || "创建请求") + "：" + record.message + (record.requestId ? "（请求 " + record.requestId.slice(0, 8) + "）" : "");
    }

    function feedbackBelongsToCurrentRun(record) {
      const runId = currentRunId();
      return Boolean(record && runId && record.runId === runId);
    }

    async function reconcileCmsStartRequest(record) {
      if (!record?.requestId || !record?.runId) return;
      try {
        const result = await fetchJson("/api/start-cms-request?runId=" + encodeURIComponent(record.runId) + "&requestId=" + encodeURIComponent(record.requestId));
        cmsStartFeedback = result.request;
      } catch (error) {
        cmsStartFeedback = { ...record, status: "unknown", message: "无法确认后台是否已受理；为避免重复创建，已阻止再次启动。请恢复后台后按该请求编号核对。" };
      }
      saveCmsStartFeedback();
      renderCmsStartFeedback(cmsStartFeedback);
    }

    async function recoverCmsStartRequest() {
      if (!cmsStartFeedback?.requestId) return;
      if (cmsStartFeedback.runId && currentRunId() && cmsStartFeedback.runId !== currentRunId()) return;
      await reconcileCmsStartRequest(cmsStartFeedback);
      setButtons(latestStatus?.status || "waiting");
    }

    async function checkControlledBrowser(attempt = 0) {
      const hasControlledFlag = new URLSearchParams(location.search).get("controlled") === "1";
      try {
        const result = await fetchJson("/api/browser-state");
        controlledBrowserReady = Boolean(result.ok && result.controlled && hasControlledFlag);
        controlledBrowserCdpUrl = String(result.cdpUrl || "");
        controlledTabDisplayReady = Boolean(result.tabDisplayReady && result.tabDisplayStatus === "ready");
        if (!controlledBrowserReady && hasControlledFlag && attempt < 6) {
          setTimeout(() => checkControlledBrowser(attempt + 1), 500);
        }
        if ($("cdpUrl") && controlledBrowserCdpUrl) $("cdpUrl").value = controlledBrowserCdpUrl;
        $("browserWarning").style.display = controlledBrowserReady ? "none" : "block";
        const followWarning = $("browserFollowWarning");
        if (controlledBrowserReady && !controlledTabDisplayReady) {
          const detail = String(result.tabDisplayError || result.browserComponentError || "内部切页模块尚未完成真实握手");
          followWarning.textContent = "专用浏览器已连接，但自动切页不可用：" + detail + "。创建仍按可信页面执行，不会改用抢焦点方式。";
          followWarning.style.display = "block";
        } else {
          followWarning.style.display = "none";
          followWarning.textContent = "";
        }
        if (cmsStartFeedback && ["rejected", "failed", "unknown"].includes(cmsStartFeedback.status)) {
          renderCmsStartFeedback(cmsStartFeedback);
        } else if (controlledBrowserReady && controlledTabDisplayReady) {
          $("saveState").textContent = "已连接 2.0 专用可控浏览器，自动切页真实握手已就绪。";
        } else if (controlledBrowserReady) {
          $("saveState").textContent = "已连接 2.0 专用可控浏览器；自动切页当前不可用。";
        } else {
          $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从“2.0可视化控制台”正式入口启动。";
        }
      } catch (error) {
        controlledBrowserReady = false;
        if (cmsStartFeedback && ["rejected", "failed", "unknown"].includes(cmsStartFeedback.status)) {
          renderCmsStartFeedback(cmsStartFeedback);
          return;
        }
        $("browserWarning").style.display = "block";
        $("saveState").textContent = "无法确认可控浏览器状态：" + (error?.message || error);
      }
      setButtons("idle");
    }

    async function loadSettings() {
      const result = await fetchJson("/api/settings");
      if (!result.ok) return;
      if (result.settings.headingDay) setSelectOptions($("headingDay"), [{ value: result.settings.headingDay, label: result.settings.headingDay }]);
      if (result.settings.headingRhythm) setSelectOptions($("headingRhythm"), [{ value: "", label: "整天" }, { value: result.settings.headingRhythm, label: result.settings.headingRhythm }]);
      if (result.settings.headingStartDay) setSelectOptions($("headingStartDay"), [{ value: result.settings.headingStartDay, label: result.settings.headingStartDay }]);
      if (result.settings.headingEndDay) setSelectOptions($("headingEndDay"), [{ value: result.settings.headingEndDay, label: result.settings.headingEndDay }]);
      for (const id of ids) if ($(id) && result.settings[id] !== undefined) $(id).value = String(result.settings[id]);
      if ($("cdpUrl") && controlledBrowserCdpUrl) $("cdpUrl").value = controlledBrowserCdpUrl;
      if ($("date")) $("date").value = toDateInputValue(result.settings.date || "");
      savedFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      titleReadForFeishuUrl = normalizeFeishuUrlInput($("feishuTitleUrl").value);
      clearStaleFeishuTitleIfNeeded();
      updateFeishuLinkFeedback();
      syncFeishuTitleFromStatus(latestStatus);
      syncCardGroups();
      updateDocumentInputModeVisibility();
      updateHeadingSelectionVisibility();
      updateTuoRosterUploadDisplay();
      activeCmsConfigId = $("cmsConfigId")?.value || "";
      renderCmsConfigLibrary();
    }

    function readSettings() {
      const data = {};
      for (const id of ids) data[id] = $(id)?.value || "";
      data.date = fromDateInputValue(data.date);
      data.restoreSelection = data.restoreSelection !== "false";
      data.robotNotInGroupMaxRetries = Number(data.robotNotInGroupMaxRetries || 5);
      for (const key of ["sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"]) {
        if (String(data[key] || "").trim() !== "") data[key] = Number(data[key]);
      }
      if (($("contentSourceMode")?.value || contentSourceMode) === "feishu" && $("documentInputMode")?.value === "document-paste") {
        data.rangeMode = "full";
        data.startKeyword = "";
        data.endKeyword = "";
        data.headingDay = "";
        data.headingRhythm = "";
        data.headingStartDay = "";
        data.headingEndDay = "";
      }
      return data;
    }

    function toDateInputValue(value) {
      const text = String(value || "").trim();
      const iso = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
      if (iso) return iso[1] + "-" + String(Number(iso[2])).padStart(2, "0") + "-" + String(Number(iso[3])).padStart(2, "0");
      const md = text.match(/^(\d{1,2})\s*[\/月-]\s*(\d{1,2})(?:日|号)?$/);
      if (!md) return "";
      return new Date().getFullYear() + "-" + String(Number(md[1])).padStart(2, "0") + "-" + String(Number(md[2])).padStart(2, "0");
    }

    function fromDateInputValue(value) {
      const text = String(value || "").trim();
      const iso = text.match(/^\d{4}-(\d{1,2})-(\d{1,2})$/);
      if (iso) return Number(iso[1]) + "/" + Number(iso[2]);
      return text;
    }

    function handleFeishuUrlChanged() {
      headingStructure = null;
      resetHeadingStructureOptions("请先读取标题结构");
      clearStaleFeishuTitleIfNeeded();
      updateFeishuLinkFeedback();
      setButtons(latestStatus?.status || "ready");
      scheduleFeishuMetadataRead();
    }

    function handleFeishuTitleEdited() {
      const title = $("feishuTitle").value.trim();
      if (!title || isPlaceholderFeishuTitle(title)) {
        titleReadForFeishuUrl = "";
        $("feishuTitleUrl").value = "";
        return;
      }
      titleReadForFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      $("feishuTitleUrl").value = titleReadForFeishuUrl;
    }

    function clearStaleFeishuTitleIfNeeded() {
      const currentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      const titleUrl = normalizeFeishuUrlInput($("feishuTitleUrl").value || titleReadForFeishuUrl);
      const currentTitle = $("feishuTitle").value.trim();
      if (!currentTitle || isPlaceholderFeishuTitle(currentTitle)) return false;
      if (currentUrl && titleUrl && sameFeishuDocument(currentUrl, titleUrl)) return false;
      $("feishuTitle").value = "待读取";
      titleReadForFeishuUrl = "";
      $("feishuTitleUrl").value = "";
      return true;
    }

    function updateFeishuLinkFeedback() {
      const input = $("feishuUrl").value;
      const normalized = normalizeFeishuUrlInput(input);
      const dirty = isFeishuUrlDirty();
      $("readHeadingStructureBtn").disabled = !normalized;
      if (!String(input || "").trim()) {
        $("feishuTitleBadge").textContent = "待读取";
        $("feishuTitleBadge").className = "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接状态：请粘贴飞书文档链接";
        $("feishuLinkFeedback").className = "link-feedback warn";
        return;
      }
      if (!normalized) {
        $("feishuTitleBadge").textContent = "待更新";
        $("feishuTitleBadge").className = "field-badge bad";
        $("feishuLinkFeedback").textContent = "链接格式可能不正确，请检查";
        $("feishuLinkFeedback").className = "link-feedback bad";
        return;
      }
      if (dirty) {
        clearStaleFeishuTitleIfNeeded();
        $("feishuTitleBadge").textContent = "待更新";
        $("feishuTitleBadge").className = "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接已识别。检测到新的文档链接，尚未保存；链接状态：已修改，未生成预览。";
        $("feishuLinkFeedback").className = "link-feedback warn";
        $("generateBtn").classList.add("primary");
        setButtons(latestStatus?.status || "ready");
      } else {
        $("feishuTitleBadge").textContent = $("feishuTitle").value.trim() ? "已保存" : "待读取";
        $("feishuTitleBadge").className = $("feishuTitle").value.trim() ? "field-badge good" : "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接已识别。链接状态：已保存";
        $("feishuLinkFeedback").className = "link-feedback good";
      }
    }

    function normalizeActiveDocumentInputMode() {
      const select = $("documentInputMode");
      const mode = select?.value || "feishu-api";
      if (["feishu-api", "document-paste"].includes(mode)) return mode;
      if (select) select.value = "feishu-api";
      return "feishu-api";
    }

    function updateDocumentInputModeVisibility() {
      const selectedMode = $("documentInputMode")?.value || "feishu-api";
      const retiredMode = !["feishu-api", "document-paste"].includes(selectedMode);
      const mode = normalizeActiveDocumentInputMode();
      if (mode !== "feishu-api") cancelFeishuMetadataRead();
      $("feishuTitle").readOnly = mode === "feishu-api";
      for (const el of document.querySelectorAll(".document-import-field")) {
        el.style.display = mode === "document-paste" ? "" : "none";
      }
      for (const el of document.querySelectorAll(".feishu-api-field")) {
        el.style.display = mode === "feishu-api" ? "" : "none";
      }
      syncCardGroup("documentInputModeChoice", "documentInputMode");
      if (retiredMode) {
        $("saveState").textContent = "原先选择的内容读取入口已停用，已切换为飞书 API 读取；也可以选择直接粘贴内容。";
      } else if (mode === "document-paste") {
        $("saveState").textContent = "已选择直接粘贴内容。请从飞书复制富文本并粘贴后生成预览。";
      } else if (mode === "feishu-api") {
        $("saveState").textContent = "已选择飞书 API 读取。链接输入完成后会自动获取标题；仍按当前范围设置生成预览。";
        scheduleFeishuMetadataRead();
      }
      updateRangeVisibility();
      setButtons(latestStatus?.status || "ready");
    }

    async function handleDocumentImportPaste(event) {
      const clipboard = event.clipboardData;
      if (!clipboard) return;
      event.preventDefault();
      const html = clipboard.getData("text/html") || "";
      const plain = clipboard.getData("text/plain") || "";
      const imageFiles = Array.from(clipboard.items || [])
        .filter((item) => item.kind === "file" && /^image\//i.test(item.type || ""))
        .map((item) => item.getAsFile())
        .filter(Boolean);
      let insertHtml = html ? sanitizeDocumentImportHtml(html) : plainTextToHtml(plain);
      if (imageFiles.length) {
        const imageHtml = [];
        for (let index = 0; index < imageFiles.length; index += 1) {
          const file = imageFiles[index];
          const dataUrl = await fileToDataUrl(file);
          const alt = /gif/i.test(file.type || file.name || "") ? "动态表情" : "粘贴图片" + (index + 1);
          imageHtml.push('<p><img src="' + escapeHtmlAttribute(dataUrl) + '" alt="' + escapeHtmlAttribute(alt) + '"></p>');
        }
        insertHtml += imageHtml.join("");
      }
      if (insertHtml) {
        document.execCommand("insertHTML", false, insertHtml);
      }
      syncDocumentImportRichPaste({ pastedImageCount: imageFiles.length, fromPaste: true, plainText: plain });
    }

    function syncDocumentImportRichPaste(options = {}) {
      const editor = $("documentImportRichPaste");
      const text = editor.textContent || "";
      const html = sanitizeDocumentImportHtml(editor.innerHTML || "");
      const imageCount = editor.querySelectorAll("img").length;
      const hasContent = Boolean(text.trim() || imageCount);
      if (options.fromPaste) {
        pastedDocumentPlainText = String(options.plainText || "");
        pastedDocumentPlainHtml = html;
      } else if (options?.type === "input" && pastedDocumentPlainHtml && html !== pastedDocumentPlainHtml) {
        pastedDocumentPlainText = "";
        pastedDocumentPlainHtml = "";
      }
      if (!hasContent) {
        pastedDocumentPlainText = "";
        pastedDocumentPlainHtml = "";
      }
      $("documentImportText").value = hasContent ? html : "";
      pastedDocumentImport = hasContent ? {
        fileName: $("feishuTitle").value.trim() || "富文本粘贴导入文档",
        contentType: "text/html",
        content: html,
        ...(pastedDocumentPlainText.trim() ? {
          pasteSource: "rich-text-clipboard",
          pastedPlainText: pastedDocumentPlainText
        } : {})
      } : null;
      updateDocumentImportStatusForPaste({
        hasContent,
        imageCount,
        pastedImageCount: options.pastedImageCount || 0,
        plainText: options.plainText || text
      });
    }

    function updateDocumentImportStatusForPaste({ hasContent, imageCount, pastedImageCount, plainText }) {
      if (hasContent) {
        const placeholderWarning = hasUnrecoverableMediaPlaceholder(plainText) && !imageCount;
        const prefix = "已粘贴内容。";
        const imageText = imageCount ? " 已识别可导入图片 " + imageCount + " 张。" : "";
        if (placeholderWarning) {
          $("documentImportStatus").textContent = prefix + imageText + " 但检测到 [图片]/[表情包] 这类占位文字，没有拿到真实图片数据，无法自动恢复原图。";
          $("documentImportStatus").className = "roster-upload-status bad";
          return;
        }
        $("documentImportStatus").textContent = prefix + imageText + (pastedImageCount ? " 本次粘贴新增图片 " + pastedImageCount + " 张。" : "");
        $("documentImportStatus").className = "roster-upload-status good";
        return;
      }
      $("documentImportStatus").textContent = "尚未粘贴内容。";
      $("documentImportStatus").className = "roster-upload-status";
    }

    function hasUnrecoverableMediaPlaceholder(text) {
      return /[\\[【](?:图片|表情包|动态表情|视频|素材)[\\]】]/.test(String(text || ""));
    }

    function sanitizeDocumentImportHtml(html) {
      const template = document.createElement("template");
      template.innerHTML = String(html || "");
      template.content.querySelectorAll("script,style,iframe,object,embed,link,meta").forEach((node) => node.remove());
      template.content.querySelectorAll("*").forEach((node) => {
        for (const attr of Array.from(node.attributes)) {
          const name = attr.name.toLowerCase();
          if (name.startsWith("on") || name === "srcdoc") node.removeAttribute(attr.name);
        }
      });
      return template.innerHTML;
    }

    function plainTextToHtml(text) {
      return escapeHtml(String(text || "")).replace(/\\n/g, "<br>");
    }

    function escapeHtml(text) {
      return String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
    }

    function escapeHtmlAttribute(text) {
      return escapeHtml(text).replace(new RegExp(String.fromCharCode(96), "g"), "&#96;");
    }

    function fileToDataUrl(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = () => reject(reader.error || new Error("读取粘贴图片失败。"));
        reader.readAsDataURL(file);
      });
    }

    function readDocumentImportInput() {
      syncDocumentImportRichPaste();
      if (pastedDocumentImport?.content?.trim()) {
        return {
          ...pastedDocumentImport,
          mode: "document-paste",
          fileName: $("feishuTitle").value.trim() || pastedDocumentImport.fileName || "富文本粘贴导入文档"
        };
      }
      throw new Error("请先把文档内容或图片粘贴到输入框。");
    }

    function isFeishuUrlDirty() {
      return normalizeFeishuUrlInput($("feishuUrl").value) !== savedFeishuUrl;
    }

    function normalizeFeishuUrlInput(value) {
      const text = String(value || "")
        .replace(/[<>]/g, " ")
        .replace(/[“”]/g, '"')
        .replace(/[‘’]/g, "'")
        .trim();
      if (!text) return "";
      const markdown = text.match(/\\((https?:\\/\\/[^)]+)\\)/);
      const source = markdown?.[1] || text;
      const compactSource = source.replace(/\\s+/g, "");
      const match = compactSource.match(/https:\\/\\/\\S*feishu\\.cn\\/(?:docx|wiki)\\/[A-Za-z0-9]+/i);
      const url = (match?.[0] || "").replace(/[)\\]};,，。；]+$/g, "");
      return /^https:\\/\\/[^/]*feishu\\.cn\\/(?:docx|wiki)\\/[A-Za-z0-9]+\\/?$/i.test(url) ? url.replace(/\\/$/, "") : "";
    }

    function cancelFeishuMetadataRead() {
      clearTimeout(feishuMetadataTimer);
      feishuMetadataTimer = null;
      feishuMetadataRequestId += 1;
      feishuMetadataController?.abort();
      feishuMetadataController = null;
    }

    function scheduleFeishuMetadataRead(options = {}) {
      cancelFeishuMetadataRead();
      if (normalizeActiveDocumentInputMode() !== "feishu-api") return;
      const documentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      if (!documentUrl) return;
      $("feishuTitle").value = "待读取";
      $("feishuTitleUrl").value = "";
      titleReadForFeishuUrl = "";
      $("feishuTitleBadge").textContent = "正在获取";
      $("feishuTitleBadge").className = "field-badge warn";
      $("feishuLinkFeedback").textContent = "正在自动获取当前文档标题...";
      $("feishuLinkFeedback").className = "link-feedback warn";
      const requestId = feishuMetadataRequestId;
      feishuMetadataTimer = setTimeout(() => readFeishuMetadata(documentUrl, requestId), options.immediate ? 0 : 450);
    }

    async function readFeishuMetadata(documentUrl, requestId) {
      const controller = new AbortController();
      feishuMetadataController = controller;
      try {
        const response = await fetch("/api/feishu-metadata", {
          method: "POST", headers: { "content-type": "application/json" },
          body: JSON.stringify({ documentUrl }), signal: controller.signal
        });
        const result = await response.json().catch(() => ({ ok: false, error: "后台接口返回内容不是 JSON。" }));
        if (!response.ok || result.ok === false) {
          const error = new Error(result.error || result.message || "读取标题失败。");
          error.code = result.code || "";
          throw error;
        }
        const currentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
        if (requestId !== feishuMetadataRequestId || normalizeActiveDocumentInputMode() !== "feishu-api" ||
          !sameFeishuDocument(currentUrl, documentUrl)) return;
        const canonicalUrl = normalizeFeishuUrlInput(result.feishuUrl || documentUrl);
        $("feishuTitle").value = result.title || "未命名文档";
        $("feishuTitleUrl").value = canonicalUrl;
        titleReadForFeishuUrl = canonicalUrl;
        savedFeishuUrl = canonicalUrl;
        $("feishuUrl").value = canonicalUrl;
        $("feishuTitleBadge").textContent = "已自动获取";
        $("feishuTitleBadge").className = "field-badge good";
        $("feishuLinkFeedback").textContent = "已连接公司飞书后台，标题与当前文档一致。";
        $("feishuLinkFeedback").className = "link-feedback good";
        await postJson("/api/settings", { settings: readSettings() });
      } catch (error) {
        if (error?.name === "AbortError" || requestId !== feishuMetadataRequestId) return;
        const currentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
        if (normalizeActiveDocumentInputMode() !== "feishu-api" || !sameFeishuDocument(currentUrl, documentUrl)) return;
        $("feishuTitle").value = "待读取";
        $("feishuTitleUrl").value = "";
        titleReadForFeishuUrl = "";
        $("feishuTitleBadge").textContent = "获取失败";
        $("feishuTitleBadge").className = "field-badge bad";
        $("feishuLinkFeedback").textContent = "自动获取标题失败：" + (error?.message || error);
        $("feishuLinkFeedback").className = "link-feedback bad";
        $("authorizeFeishuBtn").hidden = !["PERSONAL_AUTH_REQUIRED", "OAUTH_REAUTHORIZE_REQUIRED", "FEISHU_USER_SCOPE_MISSING"].includes(error?.code);
      }
    }

    async function refreshFeishuConnection(options = {}) {
      try {
        const result = await fetchJson("/api/feishu-connection");
        $("feishuConnectionState").textContent = result.configured
          ? (result.personalAuthorized ? "公司应用已连接；本人授权有效" : "公司应用已连接")
          : "管理员尚未配置";
        $("authorizeFeishuBtn").hidden = !result.oauthConfigured;
        if (options.retryMetadata) scheduleFeishuMetadataRead({ immediate: true });
        return result;
      } catch (error) {
        $("feishuConnectionState").textContent = "连接检查失败：" + (error?.message || error);
        return null;
      }
    }

    async function startFeishuAuthorization() {
      try {
        const result = await postJson("/api/feishu-oauth/start", {});
        const link = document.createElement("a");
        link.href = result.authorizeUrl;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        feishuAuthorizationPending = true;
        link.click();
        $("feishuConnectionState").textContent = "授权页面已打开；完成后回到这里会自动刷新。";
      } catch (error) {
        $("feishuConnectionState").textContent = "无法开始本人授权：" + (error?.message || error);
      }
    }

    async function readHeadingStructure() {
      const feishuUrl = $("feishuUrl").value;
      const documentUrl = normalizeFeishuUrlInput(feishuUrl);
      if (!documentUrl) {
        $("headingStructureBadge").textContent = "链接无效";
        $("headingStructureBadge").className = "field-badge bad";
        $("headingRangeHint").textContent = "请填写有效的飞书文档链接。";
        return;
      }
      $("readHeadingStructureBtn").disabled = true;
      $("headingStructureBadge").textContent = "读取中";
      $("headingStructureBadge").className = "field-badge warn";
      $("headingRangeHint").textContent = "正在通过飞书 API 读取标题结构，不下载素材。";
      try {
        const result = await postJson("/api/heading-structure", {
          document: { mode: "feishu-api", documentUrl }
        });
        if (!result.ok) throw new Error(result.error || "识别标题结构失败。");
        headingStructure = result.structure || null;
        if (result.title) {
          $("feishuTitle").value = result.title;
          syncFeishuTitleFromStatus({ feishuTitle: result.title, feishuUrl: result.feishuUrl || feishuUrl });
        }
        fillHeadingOptions(headingStructure);
        $("headingStructureBadge").textContent = "已读取";
        $("headingStructureBadge").className = "field-badge good";
        updateHeadingRangeHint();
      } catch (error) {
        $("headingStructureBadge").textContent = "读取失败";
        $("headingStructureBadge").className = "field-badge bad";
        $("headingRangeHint").textContent = "识别标题结构失败：" + (error?.message || error);
      } finally {
        updateFeishuLinkFeedback();
        setButtons(latestStatus?.status || "ready");
      }
    }

    function fillHeadingOptions(structure) {
      const days = Array.isArray(structure?.days) ? structure.days : [];
      if ($("headingDayLabel")) $("headingDayLabel").textContent = structure?.dayMode === "implicit" ? "内容范围" : "第几天";
      const previousDay = $("headingDay").value;
      const previousStartDay = $("headingStartDay").value;
      const previousEndDay = $("headingEndDay").value;
      setSelectOptions($("headingDay"), days.length ? days : [{ value: "", label: "未识别到天数" }]);
      if (days.some((item) => item.value === previousDay)) $("headingDay").value = previousDay;
      else if (days[0]) $("headingDay").value = days[0].value;
      setSelectOptions($("headingStartDay"), days.length ? days : [{ value: "", label: "未识别到天数" }]);
      if (days.some((item) => item.value === previousStartDay)) $("headingStartDay").value = previousStartDay;
      else if (days[0]) $("headingStartDay").value = days[0].value;
      updateHeadingEndDayOptions(previousEndDay);
      updateHeadingRhythmOptions();
    }

    function updateHeadingRhythmOptions() {
      const day = $("headingDay").value;
      const choices = Array.isArray(headingStructure?.choices) ? headingStructure.choices : [];
      const wholeLabel = headingStructure?.dayMode === "implicit" ? "整段内容" : "整天";
      const rhythms = [];
      for (const choice of choices) {
        if (choice.day !== day || !choice.rhythm) continue;
        if (!rhythms.some((item) => item.value === choice.rhythm)) rhythms.push({ value: choice.rhythm, label: choice.rhythm });
      }
      setSelectOptions($("headingRhythm"), [{ value: "", label: wholeLabel }, ...rhythms]);
      updateHeadingRangeHint();
    }

    function updateHeadingEndDayOptions(preferredValue) {
      const days = Array.isArray(headingStructure?.days) ? headingStructure.days : [];
      const startDay = $("headingStartDay").value;
      const startIndex = days.findIndex((item) => item.value === startDay);
      const candidates = startIndex >= 0 ? days.slice(startIndex) : days;
      const previousEndDay = preferredValue !== undefined ? preferredValue : $("headingEndDay").value;
      setSelectOptions($("headingEndDay"), candidates.length ? candidates : [{ value: "", label: "未识别到天数" }]);
      if (candidates.some((item) => item.value === previousEndDay)) $("headingEndDay").value = previousEndDay;
      else if (candidates[0]) $("headingEndDay").value = candidates[0].value;
      updateHeadingRangeHint();
    }

    function updateHeadingRangeHint() {
      const selectionMode = $("headingSelectionMode").value || "single";
      if (selectionMode === "range") {
        const startDay = $("headingStartDay").value || "未选择";
        const endDay = $("headingEndDay").value || "未选择";
        if (!headingStructure) {
          $("headingRangeHint").textContent = "范围模式：选择开始第几天和结束第几天，读取中间整天内容；朋友圈默认跳过。";
          return;
        }
        $("headingRangeHint").textContent = "自动范围：" + startDay + " 到 " + endDay + "；读取中间整天内容；朋友圈默认跳过。";
        return;
      }
      const day = $("headingDay").value || "未选择";
      const rhythm = $("headingRhythm").value || (headingStructure?.dayMode === "implicit" ? "整段内容" : "整天");
      if (!headingStructure) {
        $("headingRangeHint").textContent = "从选中标题下方开始，到下一个同级标题前；朋友圈默认跳过。";
        return;
      }
      $("headingRangeHint").textContent = "自动范围：" + day + " / " + rhythm + "；从对应标题下方开始，到下一个同级标题前；朋友圈默认跳过。";
    }

    function resetHeadingStructureOptions(message) {
      if (!$("headingDay") || !$("headingRhythm") || !$("headingStartDay") || !$("headingEndDay")) return;
      if ($("headingDayLabel")) $("headingDayLabel").textContent = "第几天";
      setSelectOptions($("headingDay"), [{ value: "", label: message || "请先读取标题结构" }]);
      setSelectOptions($("headingRhythm"), [{ value: "", label: "整天" }]);
      setSelectOptions($("headingStartDay"), [{ value: "", label: message || "请先读取标题结构" }]);
      setSelectOptions($("headingEndDay"), [{ value: "", label: message || "请先读取标题结构" }]);
      if ($("headingStructureBadge")) {
        $("headingStructureBadge").textContent = "待读取";
        $("headingStructureBadge").className = "field-badge warn";
      }
      if ($("headingRangeHint")) updateHeadingRangeHint();
    }

    function setSelectOptions(select, options) {
      const previous = select.value;
      select.innerHTML = "";
      for (const option of options) {
        const item = document.createElement("option");
        item.value = option.value || "";
        item.textContent = option.label || option.value || "";
        select.appendChild(item);
      }
      if (options.some((option) => option.value === previous)) select.value = previous;
    }

    async function checkPreviewRestoreCandidate() {
      if (previewRestoreDismissed) return;
      try {
        const result = await fetchJson("/api/preview/restore-candidate");
        const candidate = result.candidate || {};
        const history = Array.isArray(candidate.history) ? candidate.history : [];
        if (!result.ok || (!candidate.available && !history.length && !candidate.warning)) {
          $("previewRestorePanel").classList.remove("is-open");
          return;
        }
        const select = $("previewRestoreSelect");
        select.innerHTML = "";
        const placeholder = document.createElement("option");
        placeholder.value = "";
        placeholder.textContent = history.length ? "请选择历史预览" : "暂无有效历史预览";
        select.appendChild(placeholder);
        history.forEach((item) => {
          const option = document.createElement("option");
          option.value = item.runId || "";
          option.textContent = (item.documentName || item.runId || "未命名") + "｜" + (item.source || "未知来源") + "｜" + formatRecoveryTime(item.generatedAt) + "｜" + (item.taskCount || 0) + "条";
          select.appendChild(option);
        });
        if (candidate.available && candidate.runId) select.value = candidate.runId;
        $("previewRestoreText").textContent = candidate.warning || ("当前实例“" + (candidate.instanceName || "默认实例") + "”最近成功生成的预览如下：");
        const updateMeta = () => {
          const selected = history.find((item) => item.runId === select.value);
          $("previewRestoreMeta").textContent = selected
            ? "文档：" + (selected.documentName || "未命名") + "；来源：" + (selected.source || "未知") + "；生成：" + formatRecoveryTime(selected.generatedAt) + "；最后保存：" + formatRecoveryTime(selected.lastSavedAt) + "；任务：" + (selected.taskCount || 0) + " 条。"
            : "请选择要恢复的历史预览。";
          $("previewRestoreBtn").disabled = Boolean(result.locked) || !selected;
          $("previewRestoreBtn").title = result.locked ? "当前流程或创建运行锁尚未结束，只能查看历史，不能切换预览。" : "";
        };
        select.onchange = updateMeta;
        updateMeta();
        $("previewRestorePanel").classList.add("is-open");
      } catch {
        $("previewRestorePanel").classList.remove("is-open");
      }
    }

    async function restorePreviousPreview() {
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再恢复预览。";
        return;
      }
      $("previewRestoreBtn").disabled = true;
      $("previewRestoreCancelBtn").disabled = true;
      $("saveState").textContent = "正在恢复上次预览。";
      try {
        const runId = $("previewRestoreSelect").value;
        if (!runId) throw new Error("请先选择要恢复的预览。");
        const result = await postJson("/api/preview/restore", { settings: readSettings(), runId });
        if (!result.ok) throw new Error(result.error || "恢复上次预览失败。");
        previewRestoreDismissed = true;
        $("previewRestorePanel").classList.remove("is-open");
        $("saveState").textContent = "已恢复上次预览，请检查预览页。";
        await refreshStatus({ manual: true });
      } catch (error) {
        $("saveState").textContent = "恢复上次预览失败：" + (error?.message || error);
        $("previewRestoreBtn").disabled = false;
        $("previewRestoreCancelBtn").disabled = false;
      }
    }

    function formatRecoveryTime(value) {
      const date = new Date(value || "");
      if (Number.isNaN(date.getTime())) return "时间未知";
      return date.toLocaleString("zh-CN", { hour12: false });
    }

    async function loadPreviewLibrary(options = {}) {
      const list = $("previewLibraryList");
      if (options.manual) {
        list.innerHTML = "<div class='library-empty'>正在刷新文案库...</div>";
        $("saveState").textContent = "正在刷新文案库。";
      }
      try {
        const result = await fetchJson("/api/preview-library");
        previewLibraryItems = Array.isArray(result.items) ? result.items : [];
        renderPreviewLibrary();
        if (options.manual) $("saveState").textContent = "文案库已刷新。";
      } catch (error) {
        list.innerHTML = "<div class='library-empty'>读取文案库失败：" + escapeText(error?.message || error) + "</div>";
      }
    }

    function renderPreviewLibrary() {
      const list = $("previewLibraryList");
      const query = normalizeSearchQuery($("librarySearchInput")?.value || "");
      list.innerHTML = "";
      if (!previewLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无已保存文案。先在预览页点击“存入文案库”。</div>";
        renderLibraryManager();
        syncLibrarySelectionControls();
        return;
      }
      const visibleItems = previewLibraryItems.filter((item) => matchesLibrarySearch(item, query));
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的文案。</div>";
        renderLibraryManager();
        syncLibrarySelectionControls();
        return;
      }
      visibleItems.forEach((item) => {
        const isActive = item.id && item.id === activeLibraryItemId;
        const row = document.createElement("div");
        row.className = "library-row" + (isActive ? " is-active" : "");
        row.draggable = true;
        row.dataset.libraryRowId = item.id || "";
        row.innerHTML =
          "<div><div class='library-item-title'>" + librarySelectionCheckbox(item) + "<strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名文案") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + (item.taskCount || 0) + " 条 · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-actions'>" +
          sharedLibraryButton(item) +
          "<button class='primary' data-library-open='" + escapeAttr(item.id || "") + "' type='button'>使用</button>" +
          libraryMoreMenu(item) +
          "</div>" +
          "<div class='library-share-status' data-library-share-status='" + escapeAttr(item.id || "") + "'></div>";
        list.appendChild(row);
      });
      bindLibraryDrag(list);
      renderLibraryManager();
      applyStoredSharedUploadStates();
      syncLibrarySelectionControls();
    }

    function renderLibraryManager() {
      const list = $("libraryManagerList");
      if (!list) return;
      const query = normalizeSearchQuery($("libraryManagerSearchInput")?.value || "");
      list.innerHTML = "";
      if (!previewLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无已保存文案。先在预览页点击“存入文案库”。</div>";
        syncLibrarySelectionControls();
        return;
      }
      const visibleItems = previewLibraryItems.filter((item) => matchesLibrarySearch(item, query));
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的文案。</div>";
        syncLibrarySelectionControls();
        return;
      }
      visibleItems.forEach((item) => {
        const isActive = item.id && item.id === activeLibraryItemId;
        const row = document.createElement("div");
        row.className = "library-manager-row" + (isActive ? " is-active" : "");
        row.draggable = true;
        row.dataset.libraryRowId = item.id || "";
        row.innerHTML =
          "<div><div class='library-item-title'>" + librarySelectionCheckbox(item) + "<strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名文案") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + (item.taskCount || 0) + " 条 · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-manager-actions'>" +
          libraryPinButton(item) +
          sharedLibraryButton(item) +
          "<button data-library-export-shared='" + escapeAttr(item.id || "") + "' type='button'>导出共享包</button>" +
          "<button class='primary' data-library-open='" + escapeAttr(item.id || "") + "' type='button'>使用</button>" +
          "<button data-library-rename='" + escapeAttr(item.id || "") + "' type='button'>改名</button>" +
          "<button class='outline-danger' data-library-delete='" + escapeAttr(item.id || "") + "' type='button'>删除</button>" +
          "</div>" +
          "<div class='library-share-status' data-library-share-status='" + escapeAttr(item.id || "") + "'></div>";
        list.appendChild(row);
      });
      bindLibraryDrag(list);
      applyStoredSharedUploadStates();
      syncLibrarySelectionControls();
    }

    function librarySelectionCheckbox(item) {
      const id = item.id || "";
      const checked = id && selectedLibraryShareIds.has(id) ? " checked" : "";
      return "<label class='library-select'><input type='checkbox' data-library-select='" + escapeAttr(id) + "'" + checked + "><span>选择</span></label>";
    }

    function sharedLibraryButton(item) {
      const shared = item.shared || {};
      const label = sharedLibraryButtonLabel(item);
      const cls = shared.cloudId && label === "已共享" ? "" : "primary";
      return "<button class='" + cls + "' data-library-share='" + escapeAttr(item.id || "") + "' type='button' data-default-label='" + escapeAttr(label) + "'>" + label + "</button>";
    }

    function sharedLibraryButtonLabel(item) {
      const shared = item?.shared || {};
      if (!shared.cloudId) return "上传共享";
      return sharedLibraryNeedsUpload(item) ? "更新上传" : "已共享";
    }

    function sharedLibraryNeedsUpload(item) {
      const updatedAt = Date.parse(item?.updatedAt || "");
      const uploadedAt = Date.parse(item?.shared?.uploadedAt || "");
      if (!Number.isFinite(updatedAt) || !Number.isFinite(uploadedAt)) return false;
      return updatedAt - uploadedAt > 1000;
    }

    function libraryPinButton(item) {
      const id = item.id || "";
      const index = previewLibraryItems.findIndex((entry) => entry.id === id);
      const disabled = index <= 0 ? " disabled" : "";
      return "<button data-library-move='" + escapeAttr(id) + "' data-library-move-direction='top' type='button'" + disabled + ">置顶</button>";
    }

    function libraryMoreMenu(item) {
      return "<details class='library-more'><summary>更多</summary><div class='library-more-menu'>" +
        libraryPinButton(item) +
        "<button data-library-export-shared='" + escapeAttr(item.id || "") + "' type='button'>导出共享包</button>" +
        "</div></details>";
    }

    function bindLibraryDrag(list) {
      if (!list) return;
      list.querySelectorAll("[data-library-row-id]").forEach((row) => {
        row.addEventListener("dragstart", (event) => {
          if (event.target.closest("button,summary,details,input,select,textarea,a")) {
            event.preventDefault();
            return;
          }
          draggedLibraryId = row.dataset.libraryRowId || "";
          if (!draggedLibraryId) {
            event.preventDefault();
            return;
          }
          row.classList.add("is-dragging");
          event.dataTransfer.effectAllowed = "move";
          event.dataTransfer.setData("text/plain", draggedLibraryId);
        });
        row.addEventListener("dragover", (event) => {
          const targetId = row.dataset.libraryRowId || "";
          if (!draggedLibraryId || !targetId || draggedLibraryId === targetId) return;
          event.preventDefault();
          event.dataTransfer.dropEffect = "move";
          autoScrollLibraryList(list, event);
          document.querySelectorAll(".is-drop-target").forEach((node) => {
            if (node !== row) node.classList.remove("is-drop-target");
          });
          row.classList.add("is-drop-target");
        });
        row.addEventListener("dragleave", (event) => {
          if (!row.contains(event.relatedTarget)) row.classList.remove("is-drop-target");
        });
        row.addEventListener("drop", async (event) => {
          event.preventDefault();
          const sourceId = draggedLibraryId || event.dataTransfer.getData("text/plain");
          const targetId = row.dataset.libraryRowId || "";
          const rect = row.getBoundingClientRect();
          const position = event.clientY > rect.top + rect.height / 2 ? "after" : "before";
          clearLibraryDragState();
          if (!sourceId || !targetId || sourceId === targetId) return;
          await movePreviewLibraryItem(sourceId, { targetId, position });
        });
        row.addEventListener("dragend", clearLibraryDragState);
      });
    }

    function clearLibraryDragState() {
      draggedLibraryId = "";
      document.querySelectorAll(".is-dragging,.is-drop-target").forEach((node) => {
        node.classList.remove("is-dragging", "is-drop-target");
      });
    }

    function autoScrollLibraryList(list, event) {
      const rect = list.getBoundingClientRect();
      const margin = 42;
      if (event.clientY < rect.top + margin) list.scrollTop -= 18;
      else if (event.clientY > rect.bottom - margin) list.scrollTop += 18;
    }

    function visibleLocalLibraryIds() {
      const ids = [];
      const seen = new Set();
      document.querySelectorAll("#previewLibraryList [data-library-row-id], #libraryManagerList [data-library-row-id]").forEach((row) => {
        const id = row.dataset.libraryRowId || "";
        if (!id || seen.has(id)) return;
        seen.add(id);
        ids.push(id);
      });
      return ids;
    }

    function validSelectedLibraryIds() {
      const validIds = new Set(previewLibraryItems.map((item) => item.id).filter(Boolean));
      selectedLibraryShareIds = new Set([...selectedLibraryShareIds].filter((id) => validIds.has(id)));
      return [...selectedLibraryShareIds];
    }

    function selectedPreviewLibraryItems() {
      const selectedIds = new Set(validSelectedLibraryIds());
      return previewLibraryItems.filter((item) => item.id && selectedIds.has(item.id));
    }

    function syncLibrarySelectionControls() {
      const count = validSelectedLibraryIds().length;
      const summary = count ? "已选择 " + count + " 份文案" : "未选择文案";
      if ($("librarySelectionSummary")) $("librarySelectionSummary").textContent = summary;
      document.querySelectorAll("[data-library-selection-summary]").forEach((node) => {
        node.textContent = summary;
      });
      document.querySelectorAll("input[data-library-select]").forEach((input) => {
        input.checked = selectedLibraryShareIds.has(input.dataset.librarySelect || "");
        input.disabled = sharedBatchUploading;
      });
      document.querySelectorAll("button[data-library-share]").forEach((button) => {
        const state = sharedUploadStates.get(button.dataset.libraryShare || "");
        button.disabled = sharedBatchUploading || state?.busy === true;
      });
      document.querySelectorAll("#selectVisibleLibraryBtn, button[data-library-select-visible], #clearLibrarySelectionBtn, button[data-library-clear-selection]").forEach((button) => {
        button.disabled = sharedBatchUploading;
      });
      document.querySelectorAll("#batchShareLibraryBtn, button[data-library-batch-share]").forEach((button) => {
        button.disabled = sharedBatchUploading || count === 0;
        button.textContent = sharedBatchUploading ? "正在上传..." : "批量上传共享";
      });
    }

    function selectVisibleLibraryItems() {
      visibleLocalLibraryIds().forEach((id) => selectedLibraryShareIds.add(id));
      syncLibrarySelectionControls();
    }

    function clearLibrarySelection() {
      selectedLibraryShareIds.clear();
      syncLibrarySelectionControls();
    }

    function normalizeSearchQuery(value) {
      return String(value || "").trim().toLowerCase();
    }

    function matchesLibrarySearch(item, query) {
      if (!query) return true;
      return String(item.name || "未命名文案").toLowerCase().includes(query);
    }

    function openLibraryManager() {
      renderLibraryManager();
      $("libraryManagerModal").classList.add("is-open");
      $("libraryManagerModal").setAttribute("aria-hidden", "false");
    }

    function closeLibraryManager() {
      $("libraryManagerModal").classList.remove("is-open");
      $("libraryManagerModal").setAttribute("aria-hidden", "true");
    }

    async function openSharedLibraryManager() {
      $("sharedLibraryModal").classList.add("is-open");
      $("sharedLibraryModal").setAttribute("aria-hidden", "false");
      await loadSharedLibrary({ manual: false });
    }

    function closeSharedLibraryManager() {
      $("sharedLibraryModal").classList.remove("is-open");
      $("sharedLibraryModal").setAttribute("aria-hidden", "true");
    }

    async function loadSharedLibrary(options = {}) {
      const list = $("sharedLibraryList");
      list.innerHTML = "<div class='library-empty'>正在读取云端文案...</div>";
      if (options.manual) $("saveState").textContent = "正在刷新云端文案。";
      try {
        const result = await fetchJson("/api/preview-library/shared");
        if (!result.ok) throw new Error(result.error || "读取云端文案失败。");
        sharedLibraryItems = Array.isArray(result.items) ? result.items : [];
        sharedLibraryGroups = normalizeSharedLibraryGroups(result.groups, sharedLibraryItems);
        renderSharedLibraryGroupOptions();
        renderSharedLibrary();
        if (options.manual) $("saveState").textContent = "云端文案已刷新。";
      } catch (error) {
        const message = error?.message || error;
        list.innerHTML = "<div class='library-empty'>读取云端文案失败：" + escapeText(message) + "</div>";
        $("saveState").textContent = "读取云端文案失败：" + message;
      }
    }

    function renderSharedLibrary() {
      const list = $("sharedLibraryList");
      list.innerHTML = "";
      const query = normalizeSearchQuery($("sharedLibrarySearchInput")?.value || "");
      const group = String($("sharedLibraryGroupFilter")?.value || "");
      const visibleItems = sharedLibraryItems.filter((item) => {
        const nameMatch = !query || String(item.name || "未命名文案").toLowerCase().includes(query);
        const groupMatch = !group || (group === "__ungrouped" ? !String(item.groupName || "") : String(item.groupName || "") === group);
        return nameMatch && groupMatch;
      });
      if (!sharedLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无云端共享文案。需要共享时，先在本机文案库点“上传共享”。</div>";
        return;
      }
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的云端文案。</div>";
        return;
      }
      visibleItems.forEach((item) => {
        const row = document.createElement("div");
        row.className = "library-manager-row";
        const statusLabel = item.localStatus === "update_available"
          ? "有更新"
          : item.localStatus === "current"
            ? "已是最新"
            : "未下载";
        const downloading = activeSharedDownload?.cloudId === item.cloudId;
        const buttonLabel = downloading ? "取消下载" : (item.localStatus === "update_available" ? "更新到本机" : (item.localStatus === "current" ? "已下载" : "下载使用"));
        const disabled = item.localStatus === "current" && !downloading ? " disabled" : "";
        const showGroupLabel = !group && item.groupName;
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名文案") + "</strong>" +
          "<span class='library-active-label'>" + statusLabel + "</span>" +
          (showGroupLabel ? "<span class='library-active-label'>" + escapeText(item.groupName) + "</span>" : "") +
          "</div>" +
          "<span>" + (item.taskCount || 0) + " 条 · 云端版本 " + (item.cloudVersion || 0) + " · 上传 " + formatLibraryTime(item.uploadedAt || item.updatedAt) + "</span></div>" +
          "<div class='library-manager-actions'>" +
          "<button class='primary' data-library-cloud-download='" + escapeAttr(item.cloudId || "") + "' type='button'" + disabled + ">" + buttonLabel + "</button>" +
          "<button class='outline-danger' data-library-cloud-delete='" + escapeAttr(item.cloudId || "") + "' type='button'>删除</button>" +
          "</div>";
        list.appendChild(row);
      });
    }

    function normalizeSharedLibraryGroups(groups, items) {
      const result = [];
      ["开群组", "老群组", "合集组"].forEach((name) => {
        if (!result.includes(name)) result.push(name);
      });
      (Array.isArray(groups) ? groups : []).forEach((name) => {
        const clean = String(name || "").trim();
        if (clean && !result.includes(clean)) result.push(clean);
      });
      (Array.isArray(items) ? items : []).forEach((item) => {
        const clean = String(item.groupName || item.shared?.groupName || "").trim();
        if (clean && !result.includes(clean)) result.push(clean);
      });
      return result;
    }

    function renderSharedLibraryGroupOptions() {
      const selected = $("sharedLibraryGroupFilter").value || "";
      $("sharedLibraryGroupFilter").innerHTML = "<option value=''>全部分组</option>" +
        sharedLibraryGroups.map((name) => "<option value='" + escapeAttr(name) + "'>" + escapeText(name) + "</option>").join("") +
        "<option value='__ungrouped'>未分组</option>";
      $("sharedLibraryGroupFilter").value = selected === "__ungrouped" || sharedLibraryGroups.includes(selected) ? selected : "";
      $("sharedLibraryGroupOptions").innerHTML = sharedLibraryGroups
        .map((name) => "<option value='" + escapeAttr(name) + "'></option>")
        .join("");
    }

    document.addEventListener("click", async (event) => {
      const openButton = event.target.closest && event.target.closest("button[data-library-open]");
      if (openButton) {
        await openPreviewLibraryItem(openButton.dataset.libraryOpen);
        return;
      }
      const renameButton = event.target.closest && event.target.closest("button[data-library-rename]");
      if (renameButton) {
        await renamePreviewLibraryItem(renameButton.dataset.libraryRename);
        return;
      }
      const shareButton = event.target.closest && event.target.closest("button[data-library-share]");
      if (shareButton) {
        await uploadSharedPreviewLibraryItem(shareButton.dataset.libraryShare);
        return;
      }
      const retryShareButton = event.target.closest && event.target.closest("button[data-library-share-retry]");
      if (retryShareButton) {
        const id = retryShareButton.dataset.libraryShareRetry || "";
        const state = sharedUploadStates.get(id) || {};
        await uploadSharedPreviewLibraryItemWithGroup(id, state.groupName || "", { batchPrefix: "" });
        return;
      }
      const reportShareButton = event.target.closest && event.target.closest("button[data-library-share-report]");
      if (reportShareButton) {
        await reportSharedUploadIssue(reportShareButton.dataset.libraryShareReport || "");
        return;
      }
      const openRepairButton = event.target.closest && event.target.closest("button[data-library-share-open-preview]");
      if (openRepairButton) {
        const state = sharedUploadStates.get(openRepairButton.dataset.libraryShareOpenPreview || "") || {};
        if (state.repairPreviewUrl) window.open(state.repairPreviewUrl, "_blank");
        return;
      }
      const selectVisibleButton = event.target.closest && event.target.closest("button[data-library-select-visible]");
      if (selectVisibleButton) {
        selectVisibleLibraryItems();
        return;
      }
      const clearSelectionButton = event.target.closest && event.target.closest("button[data-library-clear-selection]");
      if (clearSelectionButton) {
        clearLibrarySelection();
        return;
      }
      const batchShareButton = event.target.closest && event.target.closest("button[data-library-batch-share]");
      if (batchShareButton) {
        await uploadSelectedSharedPreviewLibraryItems();
        return;
      }
      const exportSharedButton = event.target.closest && event.target.closest("button[data-library-export-shared]");
      if (exportSharedButton) {
        await exportSharedPreviewLibraryItem(exportSharedButton.dataset.libraryExportShared);
        return;
      }
      const cloudDownloadButton = event.target.closest && event.target.closest("button[data-library-cloud-download]");
      if (cloudDownloadButton) {
        await downloadSharedPreviewLibraryItem(cloudDownloadButton.dataset.libraryCloudDownload);
        return;
      }
      const cloudDeleteButton = event.target.closest && event.target.closest("button[data-library-cloud-delete]");
      if (cloudDeleteButton) {
        await deleteSharedPreviewLibraryItem(cloudDeleteButton.dataset.libraryCloudDelete);
        return;
      }
      const moveButton = event.target.closest && event.target.closest("button[data-library-move]");
      if (moveButton) {
        await movePreviewLibraryItem(moveButton.dataset.libraryMove, moveButton.dataset.libraryMoveDirection);
        return;
      }
      const deleteButton = event.target.closest && event.target.closest("button[data-library-delete]");
      if (deleteButton) {
        await deletePreviewLibraryItem(deleteButton.dataset.libraryDelete);
        return;
      }
      const tuoUseButton = event.target.closest && event.target.closest("button[data-tuo-roster-use]");
      if (tuoUseButton) {
        event.preventDefault();
        event.stopPropagation();
        await useTuoRosterLibraryItem(tuoUseButton.dataset.tuoRosterUse);
        return;
      }
      const tuoRenameButton = event.target.closest && event.target.closest("button[data-tuo-roster-rename]");
      if (tuoRenameButton) {
        event.preventDefault();
        event.stopPropagation();
        await renameTuoRosterLibraryItem(tuoRenameButton.dataset.tuoRosterRename);
        return;
      }
      const tuoDeleteButton = event.target.closest && event.target.closest("button[data-tuo-roster-delete]");
      if (tuoDeleteButton) {
        event.preventDefault();
        event.stopPropagation();
        await deleteTuoRosterLibraryItem(tuoDeleteButton.dataset.tuoRosterDelete);
        return;
      }
      const cmsUseButton = event.target.closest && event.target.closest("button[data-cms-config-use]");
      if (cmsUseButton) {
        event.preventDefault();
        event.stopPropagation();
        await useCmsConfigLibraryItem(cmsUseButton.dataset.cmsConfigUse);
        return;
      }
      const cmsEditButton = event.target.closest && event.target.closest("button[data-cms-config-edit]");
      if (cmsEditButton) {
        event.preventDefault();
        event.stopPropagation();
        editCmsConfigLibraryItem(cmsEditButton.dataset.cmsConfigEdit);
        return;
      }
      const cmsRenameButton = event.target.closest && event.target.closest("button[data-cms-config-rename]");
      if (cmsRenameButton) {
        event.preventDefault();
        event.stopPropagation();
        await renameCmsConfigLibraryItem(cmsRenameButton.dataset.cmsConfigRename);
        return;
      }
      const cmsDeleteButton = event.target.closest && event.target.closest("button[data-cms-config-delete]");
      if (cmsDeleteButton) {
        event.preventDefault();
        event.stopPropagation();
        await deleteCmsConfigLibraryItem(cmsDeleteButton.dataset.cmsConfigDelete);
        return;
      }
    });

    async function openPreviewLibraryItem(id) {
      if (!id) return;
      if (contentSourceMode !== "library") {
        $("saveState").textContent = "请先在第 1 步选择“使用文案库”，再打开文案库预览。";
        return;
      }
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再打开文案库预览。";
        return;
      }
      const configMode = await confirmLibraryConfigReady();
      if (!configMode) return;
      setButtons("running");
      $("saveState").textContent = "正在打开文案库预览页，请稍等...";
      try {
        const settings = readSettings();
        const reassignPreciseTuo = configMode === "current"
          ? await confirmLibraryPreciseTuoReassign(settings)
          : false;
        const result = await postJson("/api/preview-library/open", { id, settings, configMode, reassignPreciseTuo });
        if (!result.ok) throw new Error(result.error || "打开文案库预览失败。");
        activeLibraryItemId = result.item?.id || id;
        renderPreviewLibrary();
        const configText = configMode === "current"
          ? "，已按当前页面配置打开"
          : (result.hasSavedSettings === false ? "，已按保存的预览内容打开；这份旧文案没有原配置快照" : "，已按文案库原配置打开");
        $("saveState").textContent = "已打开文案库预览：" + (result.item?.name || "未命名文案") + configText + (reassignPreciseTuo ? "，已按当前托名单重新分配。" : "。") + "如果没有自动切换，请点浏览器里的“妙券自动发单 - 预览确认”标签页。";
        updateLibraryGeneratedSettingsDisabledMode();
        await refreshStatus({ manual: true });
      } catch (error) {
        setButtons(latestStatus?.status || "ready");
        $("saveState").textContent = "打开文案库预览失败：" + (error?.message || error);
      }
    }

    async function confirmLibraryPreciseTuoReassign(settings) {
      if (settings.robotStrategy !== "precise" || !settings.tuoRosterPath) return false;
      return askConsoleConfirm({
        title: "文案库托名单",
        note: "只会修改本次打开的预览工作副本，不会覆盖文案库原件。",
        message: "当前已选择精准托名单。是否用当前托名单重新分配这份文案里的托？选择取消则沿用文案库保存时的托。",
        confirmText: "重新分配",
        cancelText: "沿用原托"
      });
    }

    async function confirmLibraryConfigReady() {
      const result = await openConsoleAction({
        title: "使用文案库",
        note: "默认按文案库保存时的内容和配置打开，避免被当前页面残留配置影响。",
        message: "如果要套用当前页面的发单版本、机器人不在群、时间模式、云中客配置，请先确认这些配置已经改好。",
        confirmText: "按文案库原配置打开",
        extraText: "按当前页面配置打开",
        cancelText: "先修改配置"
      });
      if (result.action === "confirm") return "saved";
      if (result.action === "extra") {
        const confirmedCurrent = await askConsoleConfirm({
          title: "按当前页面配置打开",
          note: "当前页面可能残留上一次的发单版本、时间模式、机器人不在群、云中客配置。",
          message: "请先确认这些配置已经改成本次需要的；否则打开出来的预览或后续发单会沿用残留配置。",
          confirmText: "我已确认，按当前配置打开",
          cancelText: "先修改配置",
          danger: true
        });
        if (confirmedCurrent) return "current";
      }
      $("saveState").textContent = "请先修改发单配置。文案库内容固定，飞书读取相关设置不需要修改；改完后再点文案库“使用”。";
      return "";
    }

    function openConsoleAction(options = {}) {
      if (consoleActionResolver) consoleActionResolver({ confirmed: false, value: "" });
      consoleActionOptions = options;
      $("consoleActionTitle").textContent = options.title || "确认操作";
      $("consoleActionNote").textContent = options.note || "";
      $("consoleActionMessage").textContent = options.message || "";
      $("consoleActionError").textContent = "";
      $("consoleActionInput").style.display = options.input ? "block" : "none";
      $("consoleActionInput").value = options.defaultValue || "";
      $("consoleActionInput").placeholder = options.placeholder || "";
      if (options.inputList) $("consoleActionInput").setAttribute("list", options.inputList);
      else $("consoleActionInput").removeAttribute("list");
      $("consoleActionCancelBtn").textContent = options.cancelText || "取消";
      $("consoleActionExtraBtn").textContent = options.extraText || "";
      $("consoleActionExtraBtn").style.display = options.extraText ? "" : "none";
      $("consoleActionConfirmBtn").textContent = options.confirmText || "确定";
      $("consoleActionConfirmBtn").className = options.danger ? "outline-danger" : "primary";
      $("consoleActionModal").classList.add("is-open");
      $("consoleActionModal").setAttribute("aria-hidden", "false");
      return new Promise((resolve) => {
        consoleActionResolver = resolve;
        setTimeout(() => {
          if (options.input) {
            $("consoleActionInput").focus();
            $("consoleActionInput").select();
          } else {
            $("consoleActionConfirmBtn").focus();
          }
        }, 0);
      });
    }

    function submitConsoleAction() {
      if (!consoleActionResolver) return;
      const value = $("consoleActionInput").value;
      const error = consoleActionOptions?.validate?.(value);
      if (error) {
        $("consoleActionError").textContent = error;
        return;
      }
      closeConsoleAction(true);
    }

    function closeConsoleAction(confirmed, action = "") {
      $("consoleActionModal").classList.remove("is-open");
      $("consoleActionModal").setAttribute("aria-hidden", "true");
      $("consoleActionCancelBtn").textContent = "取消";
      $("consoleActionExtraBtn").textContent = "";
      $("consoleActionExtraBtn").style.display = "none";
      $("consoleActionInput").removeAttribute("list");
      if (consoleActionResolver) {
        const resolve = consoleActionResolver;
        const value = $("consoleActionInput").value;
        consoleActionResolver = null;
        consoleActionOptions = null;
        resolve({ confirmed: Boolean(confirmed), value, action: action || (confirmed ? "confirm" : "cancel") });
      }
    }

    async function askConsoleConfirm(options = {}) {
      const result = await openConsoleAction({ ...options, input: false });
      return Boolean(result.confirmed);
    }

    async function askConsoleText(options = {}) {
      const result = await openConsoleAction({
        ...options,
        input: true,
        validate: (value) => {
          const normalized = String(value || "").replace(/\s+/g, " ").trim();
          if (!normalized) return options.emptyMessage || "名称不能为空。";
          return options.validate?.(normalized) || "";
        }
      });
      return result.confirmed ? String(result.value || "").trim() : null;
    }

    async function editCurrentInstanceName() {
      const currentName = $("instanceDisplayName")?.textContent || "";
      const name = await askConsoleText({
        title: "修改实例名称",
        note: "只修改当前实例的显示名称，不改变实例编号、端口、登录账号、设置或历史任务。",
        message: "请输入容易区分的名称，例如“主号”或“备用号”。",
        defaultValue: currentName,
        placeholder: "实例名称",
        confirmText: "保存名称",
        emptyMessage: "实例名称不能为空。",
        validate: (value) => value.length > 40 ? "实例名称不能超过 40 个字符。" : ""
      });
      if (name === null) return;
      try {
        const result = await postJson("/api/instance-name", { name });
        if ($("instanceDisplayName")) $("instanceDisplayName").textContent = result.instance.label;
        syncInstanceIdentityTitle();
        $("saveState").textContent = "实例名称已保存为“" + result.instance.label + "”。关闭重开后仍会保留。";
      } catch (error) {
        $("saveState").textContent = "实例名称保存失败：" + (error?.message || error);
      }
    }

    function syncInstanceIdentityTitle() {
      const displayName = $("instanceDisplayName")?.textContent?.trim() || "";
      const stableLabel = $("instanceStableLabel")?.textContent?.trim() || "";
      if (!stableLabel) return;
      document.title = (displayName && displayName !== stableLabel ? displayName + "｜" : "") + stableLabel + "｜妙券2.0";
    }

    async function renamePreviewLibraryItem(id) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const name = await askConsoleText({
        title: "修改文案名称",
        note: "只修改文案库里保存的名称，不会重新生成预览。",
        message: "请输入新的文案名称。",
        defaultValue: item.name || "未命名文案",
        confirmText: "保存名称",
        emptyMessage: "文案名称不能为空。"
      });
      if (name === null) return;
      $("saveState").textContent = "正在修改文案名称。";
      try {
        const result = await postJson("/api/preview-library/rename", { id, name });
        if (!result.ok) throw new Error(result.error || "修改文案名称失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = "已修改文案名称：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "修改文案名称失败：" + (error?.message || error);
      }
    }

    async function uploadSharedPreviewLibraryItem(id) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      renderSharedLibraryGroupOptions();
      const action = await openConsoleAction({
        input: true,
        inputList: "sharedLibraryGroupOptions",
        title: item.shared?.cloudId ? "更新共享文案" : "上传共享文案",
        note: "只上传这一份文案。分组可留空；输入新分组后，云端和授权总控都会同步显示。",
        message: "把“" + (item.name || "未命名文案") + "”上传到云端共享，并选择它属于哪个分组。",
        defaultValue: item.shared?.groupName || "",
        placeholder: "开群组 / 老群组 / 合集组，或自定义分组",
        confirmText: item.shared?.cloudId ? "更新上传" : "上传共享"
      });
      if (!action.confirmed) return;
      const groupName = String(action.value || "").trim();
      await uploadSharedPreviewLibraryItemWithGroup(id, groupName);
    }

    async function uploadSelectedSharedPreviewLibraryItems() {
      if (sharedBatchUploading) return;
      const items = selectedPreviewLibraryItems();
      if (!items.length) {
        $("saveState").textContent = "请先勾选要上传共享的文案。";
        return;
      }
      renderSharedLibraryGroupOptions();
      const groupNames = [...new Set(items.map((item) => item.shared?.groupName || "").filter(Boolean))];
      const action = await openConsoleAction({
        input: true,
        inputList: "sharedLibraryGroupOptions",
        title: "批量上传共享",
        note: "会逐条复用单份文案的素材检查和上传流程；某一条失败不会阻止后面的文案继续上传。",
        message: "把已勾选的 " + items.length + " 份文案上传到云端共享，并选择它们属于哪个分组。",
        defaultValue: groupNames.length === 1 ? groupNames[0] : "",
        placeholder: "开群组 / 老群组 / 合集组，或自定义分组",
        confirmText: "上传 " + items.length + " 份共享"
      });
      if (!action.confirmed) return;
      const groupName = String(action.value || "").trim();
      sharedBatchUploading = true;
      syncLibrarySelectionControls();
      items.forEach((item) => {
        if (item.id) setSharedUploadState(item.id, { busy: true, label: "等待上传...", message: "等待批量上传。" });
      });
      let successCount = 0;
      let failureCount = 0;
      for (let index = 0; index < items.length; index += 1) {
        const item = items[index];
        if (!item.id) continue;
        const prefix = "批量上传共享 " + (index + 1) + "/" + items.length + "：";
        setSharedUploadState(item.id, { busy: true, label: "检查素材...", message: prefix + "正在检查“" + (item.name || "未命名文案") + "”。" });
        const outcome = await uploadSharedPreviewLibraryItemWithGroup(item.id, groupName, { batchPrefix: prefix });
        if (outcome.ok) successCount += 1;
        else failureCount += 1;
      }
      sharedBatchUploading = false;
      syncLibrarySelectionControls();
      const doneMessage = "批量上传共享完成：成功 " + successCount + " 条，失败 " + failureCount + " 条。";
      $("saveState").textContent = doneMessage;
    }

    async function uploadSharedPreviewLibraryItemWithGroup(id, groupName, options = {}) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return { ok: false, error: "文案不存在。" };
      const checkingMessage = "正在检查共享素材，请稍等。";
      const checkingText = options.batchPrefix ? options.batchPrefix + checkingMessage : checkingMessage;
      $("saveState").textContent = checkingText;
      setSharedUploadState(id, { busy: true, label: "检查素材...", message: checkingText });
      try {
        const prepare = await postJsonResult("/api/preview-library/prepare-shared-upload", { id });
        if (!prepare.ok) {
          const problem = Array.isArray(prepare.problems) && prepare.problems.length ? prepare.problems[0] : null;
          const repairMessage = problem
            ? (problem.message || "素材无法打包") + "。已打开预览页并标红定位，请重新上传这一条素材后保存，再重新上传共享。"
            : (prepare.error || "素材检查失败。");
          const openNote = prepare.repairOpenError ? " 预览页打开失败：" + prepare.repairOpenError : "";
          const failure = sharedUploadFailureView("上传共享文案失败：" + repairMessage + openNote, item, {
            problem,
            repairPreviewUrl: prepare.repairPreviewUrl || "",
            repairOpenError: prepare.repairOpenError || "",
            groupName
          });
          $("saveState").textContent = failure.message;
          setSharedUploadState(id, { busy: false, message: failure.message, tone: "error", actions: failure.actions, retryLabel: failure.retryLabel, supportContext: failure.supportContext, repairPreviewUrl: failure.repairPreviewUrl, groupName });
          showSupportAdvice(failure.supportContext);
          recordSupportDiagnostic(failure.supportContext);
          return { ok: false, error: failure.message };
        }
        if (Number(prepare.repairedCount || 0) > 0) {
          const repairMessage = "发现部分素材在临时目录，正在自动整理到文案库。";
          const repairText = options.batchPrefix ? options.batchPrefix + repairMessage : repairMessage;
          $("saveState").textContent = repairText;
          setSharedUploadState(id, { busy: true, label: "整理素材...", message: repairText });
          await new Promise((resolve) => setTimeout(resolve, 250));
        }
        const pendingMessage = Number(prepare.repairedCount || 0) > 0
          ? "素材已整理完成，正在上传共享。"
          : "素材检查通过，正在上传共享。";
        const pendingText = options.batchPrefix ? options.batchPrefix + pendingMessage : pendingMessage;
        $("saveState").textContent = pendingText;
        setSharedUploadState(id, { busy: true, label: "上传中...", message: pendingText });
        const result = await postJsonResult("/api/preview-library/upload-shared", { id, groupName });
        if (!result.ok) {
          const pending = normalizePendingSharedUploadProgress(result.pendingSharedUploadProgress, id);
          if (pending) {
            $("saveState").textContent = pending.message;
            setSharedUploadState(id, { busy: true, label: pending.label, message: pending.message, tone: "" });
            return { ok: false, error: pending.message, pending: true };
          }
          const problem = Array.isArray(result.problems) && result.problems.length ? result.problems[0] : null;
          const rawMessage = problem
            ? "上传共享文案失败：" + (problem.message || result.error || "素材无法打包") + "。已打开预览页并标红定位，请重新上传这一条素材后保存，再重新上传共享。"
            : "上传共享文案失败：" + (result.error || "上传共享文案失败。");
          const openNote = result.repairOpenError ? " 预览页打开失败：" + result.repairOpenError : "";
          const failure = sharedUploadFailureView(rawMessage + openNote, item, {
            problem,
            repairPreviewUrl: result.repairPreviewUrl || "",
            repairOpenError: result.repairOpenError || "",
            groupName
          });
          $("saveState").textContent = failure.message;
          setSharedUploadState(id, { busy: false, message: failure.message, tone: "error", actions: failure.actions, retryLabel: failure.retryLabel, supportContext: failure.supportContext, repairPreviewUrl: failure.repairPreviewUrl, groupName });
          showSupportAdvice(failure.supportContext);
          recordSupportDiagnostic(failure.supportContext);
          return { ok: false, error: failure.message };
        }
        const savedGroup = result.item?.shared?.groupName || groupName || "";
        const successMessage = "上传成功，其他人可以下载使用：" + (result.item?.name || item.name || "未命名文案") + (savedGroup ? "（" + savedGroup + "）" : "") + "。";
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        sharedLibraryGroups = normalizeSharedLibraryGroups(savedGroup ? [...sharedLibraryGroups, savedGroup] : sharedLibraryGroups, previewLibraryItems);
        renderSharedLibraryGroupOptions();
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = successMessage;
        setSharedUploadState(id, { busy: false, label: "已共享", message: successMessage, tone: "success" });
        return { ok: true, item: result.item };
      } catch (error) {
        const failure = sharedUploadFailureView("上传共享文案失败：" + (error?.message || error), item, { groupName });
        $("saveState").textContent = failure.message;
        setSharedUploadState(id, { busy: false, message: failure.message, tone: "error", actions: failure.actions, retryLabel: failure.retryLabel, supportContext: failure.supportContext, repairPreviewUrl: failure.repairPreviewUrl, groupName });
        showSupportAdvice(failure.supportContext);
        recordSupportDiagnostic(failure.supportContext);
        return { ok: false, error: failure.message };
      }
    }

    async function exportSharedPreviewLibraryItem(id) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      $("saveState").textContent = "正在导出共享包。";
      try {
        const result = await postJson("/api/preview-library/export-shared", { id });
        if (!result.ok) throw new Error(result.error || "导出共享包失败。");
        $("saveState").textContent = "共享包已导出：" + (result.filePath || result.fileName || "已保存") + "。可以把这个文件手动发给别人导入。";
      } catch (error) {
        $("saveState").textContent = "导出共享包失败：" + (error?.message || error);
      }
    }

    function sharedUploadFailureView(rawMessage, item = {}, options = {}) {
      const text = String(rawMessage || "");
      const kind = classifySharedUploadFailure(text, options.problem);
      const config = sharedUploadFailureConfig(kind);
      const supportContext = buildSharedUploadSupportContext(kind, text, item, options);
      return {
        kind,
        message: config.message,
        actions: config.actions,
        retryLabel: config.retryLabel || "重新上传",
        supportContext,
        repairPreviewUrl: options.repairPreviewUrl || ""
      };
    }

    function classifySharedUploadFailure(message, problem) {
      const text = String(message || "");
      if (problem || /素材.*(没有|缺失|不存在|未落地|无法打包|路径为空|文件无效)|标红|重新上传.*素材/.test(text)) return "material";
      if (/没有上传共享文案权限|没有上传.*权限|权限/.test(text)) return "permission";
      if (/太大|超过.*上限|超过服务器限制|250MB|413|BODY_SIZE|内容过大/.test(text)) return "too-large";
      if (/504|Gateway Time-out|网关超时|服务器.*超时|处理.*时间较长|APISIX|服务.*繁忙/.test(text)) return "server-timeout";
      if (/网络中断|网络未返回响应|连接授权总控失败|Failed to fetch|fetch failed|ECONN|ENOTFOUND|EAI_AGAIN|network|VPN/.test(text)) return "network";
      return "server-timeout";
    }

    function sharedUploadFailureConfig(kind) {
      if (kind === "too-large") return {
        message: "这份文案内容太多，系统自动处理后仍然超过上限。请先减少视频/大图，或联系管理员处理。",
        actions: ["report"],
        suggestions: ["先减少视频/大图后再上传。", "如果仍然失败，点击“上报给管理员”。"]
      };
      if (kind === "network") return {
        message: "上传时网络中断了，请检查网络后重新点击上传。系统会先检查服务器上已成功的分片，有的话自动跳过；如果第 1 片还没成功，就会从第 1 片重新传。",
        actions: ["retry", "report"],
        retryLabel: "重新上传",
        suggestions: ["检查网络后重新点击上传。", "系统会先检查服务器上已成功的分片，有的话自动跳过。", "如果第 1 片还没成功，就会从第 1 片重新传。"]
      };
      if (kind === "server-timeout") return {
        message: "服务器处理这份文案时间较长，刚才没有完成。请稍后重新点击上传，系统会先检查服务器上已成功的分片，再继续上传或合并。",
        actions: ["retry", "report"],
        retryLabel: "重试上传",
        suggestions: ["稍后点击“重试上传”。", "系统会先检查服务器上已成功的分片，再继续上传或合并。"]
      };
      if (kind === "permission") return {
        message: "这台电脑还没有上传共享文案权限，请联系管理员开通。",
        actions: ["report"],
        suggestions: ["点击“上报给管理员”，等待开通上传共享文案权限。"]
      };
      if (kind === "material") return {
        message: "有素材没有保存到本机，无法上传共享。系统已打开预览页并标红，请重新上传标红素材后再试。",
        actions: ["open-preview", "report"],
        suggestions: ["点击“打开预览页”，重新上传标红素材后保存。", "如果仍然失败，点击“上报给管理员”。"]
      };
      return {
        message: "上传共享文案失败。请稍后重新点击上传；如果仍然失败，请上报给管理员。",
        actions: ["retry", "report"],
        retryLabel: "重新上传",
        suggestions: ["稍后重新点击上传。", "如果仍然失败，点击“上报给管理员”。"]
      };
    }

    function buildSharedUploadSupportContext(kind, rawMessage, item = {}, options = {}) {
      const support = sharedUploadFailureConfig(kind);
      const diagnostics = parseSharedUploadDiagnostics(rawMessage);
      const taskCount = Number(item.taskCount || item.tasks?.length || 0);
      const packageSize = diagnostics.packageSize || "";
      const detailParts = [
        "文案：" + (item.name || "未命名文案"),
        taskCount ? "条数：" + taskCount : "",
        packageSize ? "包体：" + packageSize : "",
        diagnostics.phase ? "失败阶段：" + diagnostics.phase : "",
        diagnostics.httpStatus ? "HTTP：" + diagnostics.httpStatus : "",
        diagnostics.summary ? "错误摘要：" + diagnostics.summary : ""
      ].filter(Boolean);
      return {
        stage: "云端文案上传",
        category: "shared-library",
        message: support.message,
        lastAction: "上传共享文案",
        runId: currentRunId(),
        previewName: item.name || item.id || activeLibraryItemId || "",
        suggestions: support.suggestions || (support.actions.includes("retry")
          ? ["检查网络后重新点击上传。", "如果仍然失败，点击“上报给管理员”。"]
          : ["点击“上报给管理员”，等待管理员处理。"]),
        logs: [
          ...detailParts,
          "原始错误：" + String(rawMessage || "").replace(/\s+/g, " ").slice(0, 240)
        ].filter(Boolean),
        userNote: options.repairOpenError || ""
      };
    }

    function parseSharedUploadDiagnostics(message) {
      const text = String(message || "").replace(/\s+/g, " ");
      const http = text.match(/HTTP\s*(\d{3})/i);
      const size = text.match(/包体\s*([0-9.]+\s*(?:MB|KB|B))/i);
      let phase = "";
      const chunkUpload = text.match(new RegExp("分片上传第\\s*\\d+\\s*/\\s*\\d+\\s*片"));
      if (chunkUpload) phase = chunkUpload[0];
      else if (text.includes("分片上传")) phase = "分片上传";
      else if (text.includes("分片合并阶段")) phase = "分片合并阶段";
      else if (text.includes("直传阶段")) phase = "直传阶段";
      const summary = text
        .replace(/返回前缀\s*/g, "")
        .replace(/[<>]/g, "")
        .slice(0, 180);
      return {
        httpStatus: http ? http[1] : "",
        packageSize: size ? size[1].replace(/\s+/g, "") : "",
        phase,
        summary
      };
    }

    async function reportSharedUploadIssue(id) {
      const state = sharedUploadStates.get(id) || {};
      const context = state.supportContext;
      if (!context?.message) return;
      latestSupportContext = context;
      showSupportAdvice(context);
      recordSupportDiagnostic(context);
      await reportCurrentSupportIssue();
    }

    function sharedUploadActionButtons(id, options = {}) {
      const actions = Array.isArray(options.actions) ? options.actions : [];
      if (!actions.length) return "";
      const buttons = [];
      if (actions.includes("retry")) {
        buttons.push("<button type='button' data-library-share-retry='" + escapeAttr(id) + "'>" + escapeHtml(options.retryLabel || "重新上传") + "</button>");
      }
      if (actions.includes("open-preview") && options.repairPreviewUrl) {
        buttons.push("<button type='button' data-library-share-open-preview='" + escapeAttr(id) + "'>打开预览页</button>");
      }
      if (actions.includes("report")) {
        buttons.push("<button type='button' data-library-share-report='" + escapeAttr(id) + "'>上报给管理员</button>");
      }
      return buttons.length ? "<span class='library-share-status-actions'>" + buttons.join("") + "</span>" : "";
    }

    function setSharedUploadState(id, options = {}) {
      if (!id) return;
      sharedUploadStates.set(id, {
        busy: options.busy === true,
        label: options.label || "",
        message: options.message || "",
        tone: options.tone || "",
        actions: Array.isArray(options.actions) ? options.actions : [],
        retryLabel: options.retryLabel || "",
        supportContext: options.supportContext || null,
        repairPreviewUrl: options.repairPreviewUrl || "",
        groupName: options.groupName || ""
      });
      applyStoredSharedUploadStates();
    }

    function shouldClearSharedUploadState(id, options = {}) {
      if (!id || options.busy === true || options.tone !== "error") return false;
      const item = previewLibraryItems.find((entry) => entry?.id === id);
      return Boolean(item?.shared?.cloudId && !sharedLibraryNeedsUpload(item));
    }

    function applyStoredSharedUploadStates() {
      for (const [id, options] of sharedUploadStates.entries()) {
        if (shouldClearSharedUploadState(id, options)) sharedUploadStates.delete(id);
      }
      document.querySelectorAll("button[data-library-share]").forEach((button) => {
        const id = button.dataset.libraryShare || "";
        const options = sharedUploadStates.get(id);
        if (!button.dataset.defaultLabel) button.dataset.defaultLabel = button.textContent || "上传共享";
        if (!options) {
          button.disabled = false;
          button.textContent = button.dataset.defaultLabel || button.textContent || "上传共享";
          return;
        }
        button.disabled = options.busy === true;
        if (options.label) button.textContent = options.label;
        else button.textContent = button.dataset.defaultLabel || "上传共享";
      });
      document.querySelectorAll("[data-library-share-status]").forEach((node) => {
        const id = node.dataset.libraryShareStatus || "";
        const options = sharedUploadStates.get(id);
        if (!options) {
          node.innerHTML = "";
          node.className = "library-share-status";
          return;
        }
        node.innerHTML = escapeHtml(options.message || "") + sharedUploadActionButtons(id, options);
        node.className = "library-share-status" + (options.tone ? " " + options.tone : "");
      });
    }

    async function downloadSharedPreviewLibraryItem(cloudId) {
      if (!cloudId) return;
      if (activeSharedDownload?.cloudId === cloudId) {
        activeSharedDownload.controller.abort();
        $("saveState").textContent = "正在取消云端文案下载。";
        return;
      }
      if (activeSharedDownload) {
        $("saveState").textContent = "已有一份云端文案正在下载，请先完成或取消。";
        return;
      }
      const controller = new AbortController();
      activeSharedDownload = { cloudId, controller };
      renderSharedLibrary();
      $("saveState").textContent = "正在下载云端文案。";
      try {
        const result = await postNdjson("/api/preview-library/download-shared-stream", { cloudId }, controller.signal, (progress) => {
          const received = Number(progress.receivedBytes || 0);
          const total = Number(progress.totalBytes || 0);
          const size = (received / 1024 / 1024).toFixed(1) + "MiB";
          const percent = total > 0 ? " " + Math.min(100, Math.floor(received * 100 / total)) + "%" : "";
          $("saveState").textContent = progress.stage === "validating" ? "下载完成，正在校验和还原素材。" : "正在下载云端文案：" + size + percent + "。";
        });
        if (!result.ok) throw new Error(result.error || "下载云端文案失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        await loadSharedLibrary();
        $("saveState").textContent = "云端文案已保存到本机文案库：" + (result.item?.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = error?.name === "AbortError" ? "已取消云端文案下载，未导入任何半成品。" : "下载云端文案失败：" + (error?.message || error);
      } finally {
        if (activeSharedDownload?.controller === controller) activeSharedDownload = null;
        renderSharedLibrary();
      }
    }

    async function deleteSharedPreviewLibraryItem(cloudId) {
      if (!cloudId) return;
      const item = sharedLibraryItems.find((entry) => entry.cloudId === cloudId);
      const confirmed = await askConsoleConfirm({
        title: "删除云端文案",
        note: "只删除云端共享副本，不影响别人已经下载到本机的文案。",
        message: "确认删除云端文案“" + (item?.name || "未命名文案") + "”？",
        confirmText: "删除",
        danger: true
      });
      if (!confirmed) return;
      $("saveState").textContent = "正在删除云端文案。";
      try {
        const result = await postJson("/api/preview-library/delete-shared", { cloudId });
        if (!result.ok) throw new Error(result.error || "删除云端文案失败。");
        sharedLibraryItems = Array.isArray(result.items) ? result.items : sharedLibraryItems.filter((entry) => entry.cloudId !== cloudId);
        renderSharedLibrary();
        $("saveState").textContent = "云端文案已删除：" + (result.deleted?.name || item?.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = "删除云端文案失败：" + (error?.message || error);
      }
    }

    async function importSharedPackageFile(file) {
      if (!/\.json$/i.test(file.name || "")) {
        $("saveState").textContent = "导入共享包失败：请选择 .json 共享包文件。";
        return;
      }
      $("saveState").textContent = "正在导入共享包：" + file.name + "。";
      try {
        const result = await uploadSharedPackageFile(file, (loaded, total) => {
          const percent = total > 0 ? Math.min(100, Math.floor(loaded * 100 / total)) : 0;
          $("saveState").textContent = "正在上传本地共享包：" + percent + "%。";
        });
        if (!result.ok) throw new Error(result.error || "导入共享包失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = "共享包已导入本机文案库：" + (result.item?.name || file.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = error?.name === "AbortError" ? "已取消共享包导入，未保留半成品。" : "导入共享包失败：" + (error?.message || error);
      } finally {
        activeSharedImportXhr = null;
        $("importSharedPackageBtn").textContent = "导入共享包";
      }
    }

    async function postNdjson(url, body, signal, onProgress) {
      const response = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body), signal });
      if (!response.ok) throw new Error("本机下载服务返回 HTTP " + response.status + "。");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let pending = "";
      let result = null;
      while (true) {
        const { done, value } = await reader.read();
        pending += decoder.decode(value || new Uint8Array(), { stream: !done });
        const lines = pending.split("\\n");
        pending = lines.pop() || "";
        for (const line of lines) {
          if (!line.trim()) continue;
          const message = JSON.parse(line);
          if (message.type === "progress") onProgress?.(message);
          if (message.type === "result") result = message;
        }
        if (done) break;
      }
      if (!result) throw new Error("本机下载服务未返回完整结果。");
      return result;
    }

    function uploadSharedPackageFile(file, onProgress) {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        activeSharedImportXhr = xhr;
        $("importSharedPackageBtn").textContent = "取消导入";
        xhr.open("POST", "/api/preview-library/import-shared-file?fileName=" + encodeURIComponent(file.name || "shared.json"));
        xhr.setRequestHeader("Content-Type", "application/octet-stream");
        xhr.upload.onprogress = (event) => onProgress?.(event.loaded, event.lengthComputable ? event.total : file.size);
        xhr.onerror = () => reject(new Error("本地共享包上传中断。"));
        xhr.onabort = () => reject(new DOMException("已取消共享包导入。", "AbortError"));
        xhr.onload = () => {
          let body = null;
          try { body = JSON.parse(xhr.responseText || "{}"); } catch {}
          if (xhr.status < 200 || xhr.status >= 300) reject(new Error(body?.error || "导入共享包失败：HTTP " + xhr.status + "。"));
          else resolve(body || { ok: false, error: "本机导入服务返回内容无效。" });
        };
        xhr.send(file);
      });
    }

    async function movePreviewLibraryItem(id, move) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      $("saveState").textContent = "正在调整文案库顺序。";
      try {
        const payload = typeof move === "string" ? { id, direction: move } : { id, ...(move || {}) };
        const result = await postJson("/api/preview-library/move", payload);
        if (!result.ok) throw new Error(result.error || "调整文案库顺序失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = "已调整文案顺序：" + (result.item?.name || item.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = "调整文案库顺序失败：" + (error?.message || error);
      }
    }

    async function deletePreviewLibraryItem(id) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const confirmed = await askConsoleConfirm({
        title: "删除文案",
        note: "只删除文案库里的副本，不删除原始 run。",
        message: "确认删除文案库里的“" + (item.name || "未命名文案") + "”？这会删除这份文案和它在文案库里的素材。",
        confirmText: "删除",
        danger: true
      });
      if (!confirmed) return;
      $("saveState").textContent = "正在删除文案库条目。";
      try {
        const result = await postJson("/api/preview-library/delete", { id });
        if (!result.ok) throw new Error(result.error || "删除文案失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems.filter((entry) => entry.id !== id);
        if (activeLibraryItemId === id) activeLibraryItemId = "";
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = "已删除文案：" + (result.deleted?.name || item.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = "删除文案失败：" + (error?.message || error);
      }
    }

    async function loadTuoRosterLibrary(options = {}) {
      const list = $("tuoRosterManagerList");
      if (options.manual) {
        if (list) list.innerHTML = "<div class='library-empty'>正在刷新托人设...</div>";
        $("saveState").textContent = "正在刷新托人设。";
      }
      try {
        const result = await fetchJson("/api/tuo-roster-library");
        tuoRosterLibraryItems = Array.isArray(result.items) ? result.items : [];
        updateTuoRosterUploadDisplay();
        renderTuoRosterManager();
        if (options.manual) $("saveState").textContent = "托人设已刷新。";
      } catch (error) {
        if (list) list.innerHTML = "<div class='library-empty'>读取托人设失败：" + escapeText(error?.message || error) + "</div>";
      }
    }

    function renderTuoRosterManager() {
      const list = $("tuoRosterManagerList");
      if (!list) return;
      const query = normalizeSearchQuery($("tuoRosterManagerSearchInput")?.value || "");
      list.innerHTML = "";
      if (!tuoRosterLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无已保存托人设。先上传托名单，再点击“保存托人设”。</div>";
        return;
      }
      const visibleItems = tuoRosterLibraryItems.filter((item) => matchesLibrarySearch(item, query));
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的托人设。</div>";
        return;
      }
      visibleItems.forEach((item) => {
        const isActive = sameLocalPath(item.filePath, activeTuoRosterPath || $("tuoRosterPath")?.value || "");
        const row = document.createElement("div");
        row.className = "library-manager-row" + (isActive ? " is-active" : "");
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名托人设") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + (item.rosterCount || 0) + " 个托 · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-manager-actions'>" +
          "<button class='primary' data-tuo-roster-use='" + escapeAttr(item.id || "") + "' type='button'>使用</button>" +
          "<button data-tuo-roster-rename='" + escapeAttr(item.id || "") + "' type='button'>改名</button>" +
          "<button class='outline-danger' data-tuo-roster-delete='" + escapeAttr(item.id || "") + "' type='button'>删除</button>" +
          "</div>";
        list.appendChild(row);
      });
    }

    function openTuoRosterManager() {
      renderTuoRosterManager();
      $("tuoRosterManagerModal").classList.add("is-open");
      $("tuoRosterManagerModal").setAttribute("aria-hidden", "false");
    }

    function closeTuoRosterManager() {
      $("tuoRosterManagerModal").classList.remove("is-open");
      $("tuoRosterManagerModal").setAttribute("aria-hidden", "true");
    }

    async function saveCurrentTuoRosterToLibrary() {
      const sourcePath = $("tuoRosterPath")?.value || "";
      if (!sourcePath) {
        setTuoRosterUploadStatus("请先上传或从托人设库选择名单。", true);
        return;
      }
      const defaultName = rosterNameFromPath(sourcePath);
      const name = await askConsoleText({
        title: "保存托人设名称",
        note: "保存到托人设库后，后续可以直接选择这套名单。",
        message: "请输入这套托人设的名称。",
        defaultValue: defaultName,
        confirmText: "保存",
        emptyMessage: "托人设名称不能为空。"
      });
      if (name === null) return;
      if (!String(name || "").trim()) {
        $("saveState").textContent = "托人设名称不能为空。";
        return;
      }
      $("saveState").textContent = "正在保存托人设。";
      try {
        const result = await postJson("/api/tuo-roster-library/save", { sourcePath, name, scopeId: $("tuoRosterScopeId")?.value || "" });
        if (!result.ok) throw new Error(result.error || "保存托人设失败。");
        tuoRosterLibraryItems = Array.isArray(result.items) ? result.items : tuoRosterLibraryItems;
        $("tuoRosterScopeId").value = result.item?.scopeId || $("tuoRosterScopeId")?.value || "";
        activeTuoRosterPath = sourcePath;
        renderTuoRosterManager();
        $("saveState").textContent = "已保存托人设：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "保存托人设失败：" + (error?.message || error);
      }
    }

    async function useTuoRosterLibraryItem(id) {
      if (!id) return;
      $("saveState").textContent = "正在使用托人设。";
      try {
        const result = await postJson("/api/tuo-roster-library/use", { id });
        if (!result.ok) throw new Error(result.error || "使用托人设失败。");
        $("tuoRosterPath").value = result.item?.filePath || "";
        $("tuoRosterScopeId").value = result.item?.scopeId || "";
        $("robotStrategy").value = "precise";
        $("preciseTuoRosterEnabled").checked = true;
        activeTuoRosterPath = $("tuoRosterPath").value;
        syncRobotStrategyGroup();
        updateTuoRosterUploadDisplay();
        renderTuoRosterManager();
        $("saveState").textContent = "已使用托人设：" + (result.item?.name || "未命名托人设") + "。";
      } catch (error) {
        $("saveState").textContent = "使用托人设失败：" + (error?.message || error);
      }
    }

    async function renameTuoRosterLibraryItem(id) {
      const item = tuoRosterLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const name = await askConsoleText({
        title: "修改托人设名称",
        note: "只修改托人设库里显示的名称，不会改原始名单文件。",
        message: "请输入新的托人设名称。",
        defaultValue: item.name || "未命名托人设",
        confirmText: "保存名称",
        emptyMessage: "托人设名称不能为空。"
      });
      if (name === null) return;
      if (!String(name || "").trim()) {
        $("saveState").textContent = "托人设名称不能为空。";
        return;
      }
      $("saveState").textContent = "正在修改托人设名称。";
      try {
        const result = await postJson("/api/tuo-roster-library/rename", { id, name });
        if (!result.ok) throw new Error(result.error || "修改托人设名称失败。");
        tuoRosterLibraryItems = Array.isArray(result.items) ? result.items : tuoRosterLibraryItems;
        renderTuoRosterManager();
        $("saveState").textContent = "已修改托人设名称：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "修改托人设名称失败：" + (error?.message || error);
      }
    }

    async function deleteTuoRosterLibraryItem(id) {
      const item = tuoRosterLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const confirmed = await askConsoleConfirm({
        title: "删除托人设",
        note: "只删除托人设库里的副本，不会删除你原始名单文件。",
        message: "确认删除托人设“" + (item.name || "未命名托人设") + "”？",
        confirmText: "删除",
        danger: true
      });
      if (!confirmed) return;
      $("saveState").textContent = "正在删除托人设。";
      try {
        const result = await postJson("/api/tuo-roster-library/delete", { id });
        if (!result.ok) throw new Error(result.error || "删除托人设失败。");
        tuoRosterLibraryItems = Array.isArray(result.items) ? result.items : tuoRosterLibraryItems.filter((entry) => entry.id !== id);
        if (sameLocalPath(item.filePath, activeTuoRosterPath)) activeTuoRosterPath = "";
        renderTuoRosterManager();
        $("saveState").textContent = "已删除托人设：" + (result.deleted?.name || item.name || "未命名托人设") + "。";
      } catch (error) {
        $("saveState").textContent = "删除托人设失败：" + (error?.message || error);
      }
    }

    async function clearCurrentTuoRoster() {
      $("tuoRosterPath").value = "";
      $("tuoRosterScopeId").value = "";
      activeTuoRosterPath = "";
      updateTuoRosterUploadDisplay();
      renderTuoRosterManager();
      try {
        await postJson("/api/settings", { settings: readSettings() });
        $("saveState").textContent = "已清空当前托名单。";
      } catch (error) {
        $("saveState").textContent = "已清空当前托名单，但保存设置失败：" + (error?.message || error);
      }
    }

    async function loadCmsConfigLibrary(options = {}) {
      const list = $("cmsConfigLibraryList");
      if (options.manual) {
        if (list) list.innerHTML = "<div class='library-empty'>正在刷新云中客配置...</div>";
        $("saveState").textContent = "正在刷新云中客配置。";
      }
      try {
        const result = await fetchJson("/api/cms-config-library");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : [];
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        if (options.manual) $("saveState").textContent = "云中客配置已刷新。";
      } catch (error) {
        if (list) list.innerHTML = "<div class='library-empty'>读取云中客配置失败：" + escapeText(error?.message || error) + "</div>";
      }
    }

    function renderCmsConfigLibrary() {
      const list = $("cmsConfigLibraryList");
      if (!list) return;
      activeCmsConfigId = $("cmsConfigId")?.value || activeCmsConfigId || "";
      const activeItem = cmsConfigLibraryItems.find((item) => item.id === activeCmsConfigId);
      const badge = $("cmsConfigStatusBadge");
      badge.textContent = activeItem ? "已选择配置" : "未选择配置";
      badge.className = "cms-config-badge" + (activeItem ? " is-active" : "");
      $("cmsConfigActiveText").textContent = activeItem
        ? "当前使用：" + (activeItem.name || "未命名配置") + "。恢复后会停在云中客页面等待你确认。"
        : "进入云中客设置后，需要手动检查确认。";
      list.innerHTML = "";
      if (!cmsConfigLibraryItems.length) {
        list.innerHTML =
          "<div class='cms-config-empty'>" +
          "<strong>暂无已保存配置</strong>" +
          "<div>点击右上角“新增配置”，填写托页面和豆妈页面后保存，以后可直接选用这套设置。</div>" +
          "</div>" +
          "<div class='cms-config-warning'>选择配置后，进入云中客设置时会自动应用；应用成功、失败和待核对状态会明确显示。</div>";
        renderCmsConfigManager();
        return;
      }
      const visibleItems = cmsConfigLibraryItems;
      visibleItems.forEach((item) => {
        const isActive = item.id && item.id === activeCmsConfigId;
        const row = document.createElement("div");
        row.className = "library-row" + (isActive ? " is-active" : "");
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名云中客配置") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + cmsConfigSummary(item) + " · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-actions'>" +
          (isActive
            ? "<button class='primary' data-cms-config-use='" + escapeAttr(item.id || "") + "' type='button' disabled>已使用</button>"
            : "<button class='primary' data-cms-config-use='" + escapeAttr(item.id || "") + "' type='button'>使用</button>") +
          "</div>";
        list.appendChild(row);
      });
      const warning = document.createElement("div");
      warning.className = "cms-config-warning";
      warning.textContent = "选择配置后，进入云中客设置时会自动应用；应用完成后请人工核对群、机器人、备注和发送设置。";
      list.appendChild(warning);
      renderCmsConfigManager();
    }

    function renderCmsConfigManager() {
      const list = $("cmsConfigManagerList");
      if (!list) return;
      const query = normalizeSearchQuery($("cmsConfigManagerSearchInput")?.value || "");
      list.innerHTML = "";
      if (!cmsConfigLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无已保存云中客配置。</div>";
        return;
      }
      const visibleItems = cmsConfigLibraryItems.filter((item) => matchesLibrarySearch(item, query));
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的云中客配置。</div>";
        return;
      }
      visibleItems.forEach((item) => {
        const isActive = item.id && item.id === activeCmsConfigId;
        const row = document.createElement("div");
        row.className = "library-manager-row" + (isActive ? " is-active" : "");
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名云中客配置") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + cmsConfigSummary(item) + " · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-manager-actions'>" +
          "<button class='primary' data-cms-config-use='" + escapeAttr(item.id || "") + "' type='button'>使用</button>" +
          "<button data-cms-config-edit='" + escapeAttr(item.id || "") + "' type='button'>查看编辑</button>" +
          "<button data-cms-config-rename='" + escapeAttr(item.id || "") + "' type='button'>改名</button>" +
          "<button class='outline-danger' data-cms-config-delete='" + escapeAttr(item.id || "") + "' type='button'>删除</button>" +
          "</div>";
        list.appendChild(row);
      });
    }

    function openCmsConfigManager() {
      renderCmsConfigManager();
      $("cmsConfigManagerModal").classList.add("is-open");
      $("cmsConfigManagerModal").setAttribute("aria-hidden", "false");
    }

    function closeCmsConfigManager() {
      $("cmsConfigManagerModal").classList.remove("is-open");
      $("cmsConfigManagerModal").setAttribute("aria-hidden", "true");
    }

    function setCmsConfigWizardOpen(open, options = {}) {
      cmsConfigWizardOpen = Boolean(open);
      if (cmsConfigWizardOpen) {
        if (options.editItemId) cmsConfigWizardEditItemId = String(options.editItemId || "");
        else if (!options.keepEdit) cmsConfigWizardEditItemId = "";
        if (!cmsConfigWizardEditItemId && options.resetForm !== false) resetCmsConfigWizardForm();
      } else {
        cmsConfigWizardEditItemId = "";
        cmsConfigWizardModeOverride = "";
      }
      const form = $("cmsConfigWizardForm");
      const button = $("saveCmsConfigLibraryBtn");
      if (form) form.classList.toggle("is-hidden", !cmsConfigWizardOpen);
      if (button) button.textContent = cmsConfigWizardOpen ? (cmsConfigWizardEditItemId ? "正在编辑配置" : "收起表单") : "新增配置";
      if ($("cmsWizardSaveBtn")) $("cmsWizardSaveBtn").textContent = cmsConfigWizardEditItemId ? "保存" : "保存配置";
      if (cmsConfigWizardOpen && options.resetPage !== false) setCmsConfigWizardPage("tuo");
      updateCmsWizardTuoMode();
      updateCmsWizardDoumaLabels();
      if (!options.silent) {
        $("saveState").textContent = cmsConfigWizardOpen
          ? (cmsConfigWizardEditItemId ? "正在查看编辑云中客配置，修改后点击右下角“保存”。" : "正在新增云中客配置，请填写托页面和豆妈页面设置。")
          : "已收起云中客配置表单。";
      }
    }

    function toggleCmsConfigWizard() {
      setCmsConfigWizardOpen(!cmsConfigWizardOpen);
    }

    function setCmsConfigWizardPage(page) {
      cmsConfigWizardPage = page === "douma" ? "douma" : "tuo";
      $("cmsConfigWizardForm").classList.toggle("is-douma", cmsConfigWizardPage === "douma");
      $("cmsWizardTuoPage").classList.toggle("is-active", cmsConfigWizardPage === "tuo");
      $("cmsWizardDoumaPage").classList.toggle("is-active", cmsConfigWizardPage === "douma");
      $("cmsWizardPageTitle").textContent = cmsConfigWizardPage === "douma" ? "豆妈页面设置" : "托页面设置";
      $("cmsWizardPageHint").textContent = cmsConfigWizardPage === "douma" ? "第 2 步，共 2 步" : "第 1 步，共 2 步";
      $("cmsWizardBackBtn").style.display = cmsConfigWizardPage === "douma" ? "" : "none";
      $("cmsWizardNextBtn").style.display = cmsConfigWizardPage === "tuo" ? "" : "none";
      $("cmsWizardSaveBtn").style.display = cmsConfigWizardPage === "douma" ? "" : "none";
      $("cmsConfigWizardError").textContent = "";
    }

    function updateCmsWizardTuoMode() {
      const mode = selectedCmsWizardTuoMode();
      $("cmsWizardTuoModeDisplay").value = mode === "precise" ? "跟随上方发单版本：精准托" : "跟随上方发单版本：粗略托";
      $("cmsWizardRoughFields").style.display = mode === "rough" ? "" : "none";
      $("cmsWizardPreciseFields").style.display = mode === "precise" ? "" : "none";
    }

    function cmsWizardRadioValue(name, fallback) {
      return document.querySelector('input[name="' + name + '"]:checked')?.value || fallback;
    }

    function updateCmsWizardDoumaLabels() {
      const groupMode = cmsWizardRadioValue("cmsDoumaGroupSearchMode", "group");
      const robotMode = cmsWizardRadioValue("cmsDoumaRobotSearchMode", "group");
      $("cmsDoumaGroupValueLabel").textContent = groupMode === "keyword" ? "群关键词" : "群分组名称";
      $("cmsDoumaGroupValue").placeholder = groupMode === "keyword" ? "填写关键词，默认选择第一个" : "填写分组名字";
      $("cmsDoumaGroupSelectDefault").textContent = groupMode === "keyword" ? "默认选择第一个" : "默认全选";
      $("cmsDoumaRobotValueLabel").textContent = robotMode === "keyword" ? "机器人关键词" : "机器人分组名称";
      $("cmsDoumaRobotValue").placeholder = robotMode === "keyword" ? "填写关键词，默认选择第一个" : "填写分组名字";
      $("cmsDoumaRobotSelectDefault").textContent = robotMode === "keyword" ? "默认选择第一个" : "默认 1";
    }

    function setCmsWizardRadioValue(name, value) {
      const target = document.querySelector('input[name="' + name + '"][value="' + value + '"]');
      if (target) target.checked = true;
    }

    function resetCmsConfigWizardForm() {
      cmsConfigWizardModeOverride = "";
      $("cmsRoughManagementGroup").value = "";
      $("cmsRoughRobotSwitchMode").value = "random";
      $("cmsRoughTaskRemark").value = "";
      $("cmsPreciseGroupFilter").value = "";
      $("cmsPreciseGroupSelectCount").value = "";
      $("cmsPreciseRobotGroup").value = "";
      $("cmsPreciseTaskRemark").value = "";
      setCmsWizardRadioValue("cmsDoumaGroupSearchMode", "group");
      $("cmsDoumaGroupValue").value = "";
      setCmsWizardRadioValue("cmsDoumaRobotSearchMode", "group");
      $("cmsDoumaRobotValue").value = "";
      $("cmsDoumaTaskRemark").value = "";
      $("cmsConfigWizardError").textContent = "";
    }

    function fillCmsConfigWizardForm(form = {}) {
      const tuo = form.tuo || {};
      const rough = tuo.rough || {};
      const precise = tuo.precise || {};
      const douma = form.douma || {};
      cmsConfigWizardModeOverride = tuo.mode === "precise" ? "precise" : "rough";
      $("cmsRoughManagementGroup").value = rough.managementGroup || "";
      $("cmsRoughRobotSwitchMode").value = rough.robotSwitchMode || "random";
      $("cmsRoughTaskRemark").value = rough.taskRemark || "";
      $("cmsPreciseGroupFilter").value = precise.groupFilter || "";
      $("cmsPreciseGroupSelectCount").value = precise.groupSelectCount === "all" ? "" : (precise.groupSelectCount || "");
      $("cmsPreciseRobotGroup").value = precise.robotGroup || "";
      $("cmsPreciseTaskRemark").value = precise.taskRemark || "";
      setCmsWizardRadioValue("cmsDoumaGroupSearchMode", douma.groupSearchMode === "keyword" ? "keyword" : "group");
      $("cmsDoumaGroupValue").value = douma.groupValue || "";
      setCmsWizardRadioValue("cmsDoumaRobotSearchMode", douma.robotSearchMode === "keyword" ? "keyword" : "group");
      $("cmsDoumaRobotValue").value = douma.robotValue || "";
      $("cmsDoumaTaskRemark").value = douma.taskRemark || "";
      $("cmsConfigWizardError").textContent = "";
      updateCmsWizardTuoMode();
      updateCmsWizardDoumaLabels();
    }

    const cmsWizardHistoryPrefix = "fd-auto-tool.cms-config-form-history.";

    function readCmsWizardHistory(key) {
      try {
        const raw = localStorage.getItem(cmsWizardHistoryPrefix + key);
        const values = JSON.parse(raw || "[]");
        return Array.isArray(values) ? values.filter(Boolean).map(String) : [];
      } catch {
        return [];
      }
    }

    function writeCmsWizardHistory(key, values) {
      try {
        localStorage.setItem(cmsWizardHistoryPrefix + key, JSON.stringify(values.slice(0, 12)));
      } catch {}
    }

    function renderCmsWizardHistoryList(input) {
      const listId = input.getAttribute("list");
      const key = input.dataset.cmsHistoryKey;
      const list = listId ? $(listId) : null;
      if (!list || !key) return;
      list.innerHTML = "";
      readCmsWizardHistory(key).forEach((value) => {
        const option = document.createElement("option");
        option.value = value;
        list.appendChild(option);
      });
    }

    function rememberCmsWizardInput(input) {
      const key = input.dataset.cmsHistoryKey;
      const value = String(input.value || "").trim();
      if (!key || !value) return;
      const values = readCmsWizardHistory(key).filter((item) => item !== value);
      values.unshift(value);
      writeCmsWizardHistory(key, values);
      renderCmsWizardHistoryList(input);
    }

    function rememberCmsWizardInputHistory() {
      document.querySelectorAll("[data-cms-history-key]").forEach((input) => rememberCmsWizardInput(input));
    }

    function initCmsWizardInputHistory() {
      document.querySelectorAll("[data-cms-history-key]").forEach((input) => {
        if (input.dataset.cmsHistoryReady === "1") return;
        input.dataset.cmsHistoryReady = "1";
        renderCmsWizardHistoryList(input);
        input.addEventListener("focus", () => renderCmsWizardHistoryList(input));
        input.addEventListener("blur", () => rememberCmsWizardInput(input));
        input.addEventListener("change", () => rememberCmsWizardInput(input));
      });
    }

    function selectedCmsWizardTuoMode() {
      if (cmsConfigWizardModeOverride === "precise" || cmsConfigWizardModeOverride === "rough") return cmsConfigWizardModeOverride;
      return $("robotStrategy")?.value === "random" ? "rough" : "precise";
    }

    function readCmsConfigWizardForm() {
      const countValue = (id, fallback) => {
        const value = String($(id)?.value || "").trim();
        return value || fallback;
      };
      return {
        tuo: {
          mode: selectedCmsWizardTuoMode(),
          rough: {
            managementGroup: $("cmsRoughManagementGroup").value,
            robotSwitchMode: $("cmsRoughRobotSwitchMode").value,
            groupSelectCount: countValue("cmsRoughGroupSelectCount", "all"),
            taskRemark: $("cmsRoughTaskRemark").value
          },
          precise: {
            groupFilter: $("cmsPreciseGroupFilter").value,
            groupSelectCount: countValue("cmsPreciseGroupSelectCount", "all"),
            robotGroup: $("cmsPreciseRobotGroup").value,
            taskRemark: $("cmsPreciseTaskRemark").value
          }
        },
        douma: {
          groupSearchMode: cmsWizardRadioValue("cmsDoumaGroupSearchMode", "group"),
          groupValue: $("cmsDoumaGroupValue").value,
          groupSelectCount: cmsWizardRadioValue("cmsDoumaGroupSearchMode", "group") === "keyword" ? "1" : countValue("cmsDoumaGroupSelectCount", "all"),
          robotSearchMode: cmsWizardRadioValue("cmsDoumaRobotSearchMode", "group"),
          robotValue: $("cmsDoumaRobotValue").value,
          robotSelectCount: countValue("cmsDoumaRobotSelectCount", "1"),
          taskRemark: $("cmsDoumaTaskRemark").value
        }
      };
    }

    function validateCmsWizardTuoPage() {
      const form = readCmsConfigWizardForm();
      const errors = [];
      if (form.tuo.mode === "rough") {
        if (!String(form.tuo.rough.managementGroup || "").trim()) errors.push("请填写粗略托页面的管理分组。");
        if (!String(form.tuo.rough.taskRemark || "").trim()) errors.push("请填写粗略托页面的任务备注。");
      } else {
        if (!String(form.tuo.precise.groupFilter || "").trim()) errors.push("请填写精准托页面的群包含分组。");
        if (!String(form.tuo.precise.robotGroup || "").trim()) errors.push("请填写精准托页面的机器人分组。");
        if (!String(form.tuo.precise.taskRemark || "").trim()) errors.push("请填写精准托页面的任务备注。");
      }
      $("cmsConfigWizardError").textContent = errors[0] || "";
      return errors.length === 0;
    }

    function validateCmsWizardDoumaPage() {
      const form = readCmsConfigWizardForm();
      const errors = [];
      if (!String(form.douma.groupValue || "").trim()) errors.push("请填写豆妈页面的群输入内容。");
      if (!String(form.douma.robotValue || "").trim()) errors.push("请填写豆妈页面的机器人输入内容。");
      if (!String(form.douma.taskRemark || "").trim()) errors.push("请填写豆妈页面的任务备注。");
      $("cmsConfigWizardError").textContent = errors[0] || "";
      return errors.length === 0;
    }

    async function submitCmsConfigWizard() {
      if (!validateCmsWizardTuoPage() || !validateCmsWizardDoumaPage()) return;
      const editingItem = cmsConfigWizardEditItemId
        ? cmsConfigLibraryItems.find((entry) => entry.id === cmsConfigWizardEditItemId)
        : null;
      let name = editingItem?.name || "";
      if (!editingItem) {
        name = await askConsoleText({
          title: "保存云中客配置",
          note: "给这份托页面和豆妈页面设置起一个名称，后续可以在“管理配置”里复用。",
          message: "请输入这份云中客配置名称。",
          defaultValue: defaultCmsConfigName(),
          confirmText: "保存配置",
          emptyMessage: "云中客配置名称不能为空。"
        });
        if (name === null) return;
      }
      if (!String(name || "").trim()) {
        $("saveState").textContent = "云中客配置名称不能为空。";
        return;
      }
      rememberCmsWizardInputHistory();
      $("saveState").textContent = editingItem ? "正在保存云中客配置修改。" : "正在保存云中客配置。";
      $("cmsWizardSaveBtn").disabled = true;
      try {
        const result = await postJson("/api/cms-config-library/save", {
          id: editingItem?.id || "",
          name,
          form: readCmsConfigWizardForm(),
          settings: readSettings(),
          runDir: latestStatus?.runDir || ""
        });
        if (!result.ok) throw new Error(result.error || "保存云中客配置失败。");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : cmsConfigLibraryItems;
        $("cmsConfigId").value = result.settings && Object.prototype.hasOwnProperty.call(result.settings, "cmsConfigId")
          ? (result.settings.cmsConfigId || "")
          : (result.item?.id || "");
        activeCmsConfigId = $("cmsConfigId").value;
        setCmsConfigWizardOpen(false, { resetPage: false, silent: true });
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = editingItem
          ? "已保存云中客配置修改：" + (result.item?.name || name) + "。"
          : "已保存云中客配置：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("cmsConfigWizardError").textContent = error?.message || String(error);
        $("saveState").textContent = "保存云中客配置失败：" + (error?.message || error);
      } finally {
        $("cmsWizardSaveBtn").disabled = false;
      }
    }

    async function saveCurrentCmsConfigToLibraryFromPageBinding() {
      const name = defaultCmsConfigName();
      if (!String(name || "").trim()) {
        $("saveState").textContent = "云中客配置名称不能为空。";
        return;
      }
      $("saveState").textContent = "正在保存云中客配置。";
      try {
        const result = await postJson("/api/cms-config-library/save", { name, settings: readSettings(), runDir: latestStatus?.runDir || "" });
        if (!result.ok) throw new Error(result.error || "保存云中客配置失败。");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : cmsConfigLibraryItems;
        $("cmsConfigId").value = result.item?.id || "";
        activeCmsConfigId = $("cmsConfigId").value;
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已保存云中客配置：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "保存云中客配置失败：" + (error?.message || error);
      }
    }

    async function useCmsConfigLibraryItem(id) {
      if (!id) return;
      $("saveState").textContent = "正在使用云中客配置。";
      try {
        const result = await postJson("/api/cms-config-library/use", { id });
        if (!result.ok) throw new Error(result.error || "使用云中客配置失败。");
        $("cmsConfigId").value = result.item?.id || id;
        activeCmsConfigId = $("cmsConfigId").value;
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已选择云中客配置：" + (result.item?.name || "未命名配置") + "。进入云中客设置时将应用这份配置；应用完成后请人工核对。";
      } catch (error) {
        $("saveState").textContent = "使用云中客配置失败：" + (error?.message || error);
      }
    }

    function editCmsConfigLibraryItem(id) {
      const item = cmsConfigLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      if (!item.configForm) {
        $("saveState").textContent = "这份云中客配置是旧版页面绑定记录，没有可编辑表单。请用“新增配置”重新保存一份。";
        return;
      }
      closeCmsConfigManager();
      fillCmsConfigWizardForm(item.configForm);
      setCmsConfigWizardOpen(true, { editItemId: item.id, keepEdit: true, resetForm: false });
      $("saveState").textContent = "正在查看编辑云中客配置：" + (item.name || "未命名配置") + "。修改后点击右下角“保存”。";
      $("cmsConfigWizardForm").scrollIntoView({ behavior: "smooth", block: "start" });
    }

    async function renameCmsConfigLibraryItem(id) {
      const item = cmsConfigLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const name = await askConsoleText({
        title: "修改云中客配置名称",
        note: "只修改配置库里的显示名称。",
        message: "请输入新的云中客配置名称。",
        defaultValue: item.name || "未命名云中客配置",
        confirmText: "保存名称",
        emptyMessage: "云中客配置名称不能为空。"
      });
      if (name === null) return;
      if (!String(name || "").trim()) {
        $("saveState").textContent = "云中客配置名称不能为空。";
        return;
      }
      $("saveState").textContent = "正在修改云中客配置名称。";
      try {
        const result = await postJson("/api/cms-config-library/rename", { id, name });
        if (!result.ok) throw new Error(result.error || "修改云中客配置名称失败。");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : cmsConfigLibraryItems;
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已修改云中客配置名称：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "修改云中客配置名称失败：" + (error?.message || error);
      }
    }

    async function deleteCmsConfigLibraryItem(id) {
      const item = cmsConfigLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const confirmed = await askConsoleConfirm({
        title: "删除云中客配置",
        note: "只删除配置库记录，不会删除 run，也不会影响已生成的预览。",
        message: "确认删除云中客配置“" + (item.name || "未命名配置") + "”？",
        confirmText: "删除",
        danger: true
      });
      if (!confirmed) return;
      $("saveState").textContent = "正在删除云中客配置。";
      try {
        const result = await postJson("/api/cms-config-library/delete", { id });
        if (!result.ok) throw new Error(result.error || "删除云中客配置失败。");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : cmsConfigLibraryItems.filter((entry) => entry.id !== id);
        if ($("cmsConfigId").value === id) $("cmsConfigId").value = result.settings?.cmsConfigId || "";
        activeCmsConfigId = $("cmsConfigId").value;
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已删除云中客配置：" + (result.deleted?.name || item.name || "未命名配置") + "。";
      } catch (error) {
        $("saveState").textContent = "删除云中客配置失败：" + (error?.message || error);
      }
    }

    function cmsConfigSummary(item = {}) {
      const count = item.summary?.roleCount || item.roleCount || 0;
      const roles = Array.isArray(item.summary?.roles) ? item.summary.roles : [];
      const roleText = roles.map((role) => {
        const label = role.label || role.role || "";
        const mode = role.modeLabel ? "（" + role.modeLabel + "）" : "";
        return label ? label + mode : "";
      }).filter(Boolean).join(" / ");
      return (count ? count + " 个页面" : "未记录页面") + (roleText ? " · " + roleText : "");
    }

    function cmsConfigRoleCards(item = {}) {
      const roleMap = new Map((Array.isArray(item.summary?.roles) ? item.summary.roles : []).map((role) => [role.role, role]));
      return ["tuo", "douma"].map((role) => {
        const data = roleMap.get(role) || {};
        const label = role === "tuo" ? "托页面" : "豆妈页面";
        const group = data.group || "未记录群";
        const robot = data.robot || "未记录机器人";
        const quick = role === "tuo" && typeof data.multiQuickMode === "boolean"
          ? " / 多快捷：" + (data.multiQuickMode ? "已开" : "未开")
          : "";
        const fields = Array.isArray(data.fields) ? data.fields : [];
        if (fields.length) {
          return "<div class='cms-config-role'><b>" + label + "</b><ul>" +
            fields.map((field) => "<li><strong>" + escapeText(field[0] || "") + "：</strong>" + escapeText(field[1] || "") + "</li>").join("") +
            "</ul></div>";
        }
        return "<div class='cms-config-role'><b>" + label + "</b><span>" + escapeText(group) + " / " + escapeText(robot) + escapeText(quick) + "</span></div>";
      });
    }

    function defaultCmsConfigName() {
      const now = new Date();
      const pad = (value) => String(value).padStart(2, "0");
      return "云中客配置 " + pad(now.getMonth() + 1) + "-" + pad(now.getDate()) + " " + pad(now.getHours()) + ":" + pad(now.getMinutes());
    }

    function rosterNameFromPath(filePath) {
      const fileName = String(filePath || "").split(/[\\\\/]/).filter(Boolean).pop() || "托人设";
      return fileName.replace(/\.(xlsx|csv|json)$/i, "").replace(/^\\d{8}-\\d{6}-/, "") || "托人设";
    }

    function fileNameFromPath(filePath) {
      return String(filePath || "").split(/[\\\\/]/).filter(Boolean).pop() || String(filePath || "");
    }

    function currentTuoRosterLibraryItem(filePath) {
      const target = filePath || activeTuoRosterPath || $("tuoRosterPath")?.value || "";
      return tuoRosterLibraryItems.find((item) => sameLocalPath(item.filePath, target)) || null;
    }

    function sameLocalPath(a, b) {
      return String(a || "").replace(/\\\\/g, "/").toLowerCase() === String(b || "").replace(/\\\\/g, "/").toLowerCase();
    }

    function formatLibraryTime(value) {
      if (!value) return "未记录时间";
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return value;
      const pad = (number) => String(number).padStart(2, "0");
      return pad(date.getMonth() + 1) + "/" + pad(date.getDate()) + " " + pad(date.getHours()) + ":" + pad(date.getMinutes());
    }

    function escapeText(value) {
      return String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    function escapeAttr(value) {
      return escapeText(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }


    function cancelPreviewRestore() {
      previewRestoreDismissed = true;
      $("previewRestorePanel").classList.remove("is-open");
      $("saveState").textContent = "已取消恢复上次预览。";
    }

    async function refreshStatusManually() {
      $("refreshBtn").disabled = true;
      $("saveState").textContent = "正在刷新运行状态...";
      try {
        const status = await refreshStatus({ manual: true });
        manualStatusFeedbackUntil = Date.now() + 5000;
        if (shouldClearStaleStatus(status)) {
          const cleared = await postJson("/api/status/clear-stale", {});
          if (cleared.ok && cleared.cleared) {
            await refreshStatus({ manual: true });
            await checkPreviewRestoreCandidate();
            $("saveState").textContent = "已清理旧状态，可继续操作；预览可从恢复入口打开。";
            return;
          }
        }
        $("saveState").textContent = "运行状态已刷新：" + currentClockText() + "，当前状态：" + labelStatus(status?.status);
      } catch (error) {
        manualStatusFeedbackUntil = Date.now() + 5000;
        $("saveState").textContent = "刷新运行状态失败：" + (error?.message || error);
      } finally {
        $("refreshBtn").disabled = false;
      }
    }

    function shouldClearStaleStatus(status) {
      if (!status) return false;
      if (status.status === "running" || status.control === "running") return false;
      if (status.status === "completed") return false;
      return ["failed", "stopped", "paused", "waiting"].includes(status.status)
        || ["awaiting_error_action", "paused", "stopped"].includes(status.control)
        || Boolean(status.failureReason);
    }

    async function refreshStatus(options = {}) {
      if (statusRefreshInFlight) {
        const currentRequest = statusRefreshInFlight;
        const currentResult = await currentRequest;
        if (!options.manual) return currentResult;
      }
      const request = {
        round: statusUiRound,
        sequence: ++statusRequestSequence,
        acceptedRunGeneration
      };
      const pending = refreshStatusOnce(options, request).finally(() => {
        if (statusRefreshInFlight === pending) statusRefreshInFlight = null;
      });
      statusRefreshInFlight = pending;
      return pending;
    }

    async function refreshStatusOnce(options = {}, request = {}) {
      let result;
      try {
        const runId = currentRunId();
        result = await fetchJson(runId ? "/api/status?runId=" + encodeURIComponent(runId) : "/api/status");
      } catch (error) {
        if (request.round !== statusUiRound) return latestStatus;
        statusFetchFailureCount += 1;
        if (options.manual) throw error;
        if (shouldMarkStatusRefreshAsDisconnected(latestStatus, statusFetchFailureCount)) {
          markBackendDisconnected(error);
        } else if (Date.now() >= manualStatusFeedbackUntil) {
          $("saveState").textContent = "状态刷新暂时失败，后台可能还在运行；请稍后点“刷新运行状态”确认。";
        }
        return null;
      }
      if (!result.ok) {
        if (options.manual) throw new Error(result.error || "状态接口返回失败。");
        return null;
      }
      if (request.round !== statusUiRound || request.sequence <= latestAppliedStatusSequence) return latestStatus;
      const responseRunGeneration = Number(result.state?.runGeneration || 0);
      if (request.acceptedRunGeneration && responseRunGeneration && responseRunGeneration < request.acceptedRunGeneration) {
        return latestStatus;
      }
      latestAppliedStatusSequence = request.sequence;
      if (responseRunGeneration > acceptedRunGeneration) acceptedRunGeneration = responseRunGeneration;
      statusFetchFailureCount = 0;
      if (backendDisconnected) {
        backendDisconnected = false;
        await checkControlledBrowser();
      }
      const s = result.state;
      if (result.cmsStartRequest && feedbackBelongsToCurrentRun(result.cmsStartRequest)) {
        cmsStartFeedback = result.cmsStartRequest;
        saveCmsStartFeedback();
      }
      applyStatusSnapshot(s, options);
      return s;
    }

    function acceptStartedTaskStatus(status) {
      if (!status) return;
      statusUiRound += 1;
      latestAppliedStatusSequence = 0;
      acceptedRunGeneration = Number(status.runGeneration || 0) || (acceptedRunGeneration + 1);
      applyStatusSnapshot(status, { taskStarted: true });
    }

    function applyStatusSnapshot(s, options = {}) {
      const previousStatus = latestStatus;
      latestStatus = s;
      if (s.status === "ready" && !s.runDir && previousStatus?.status === "cancelling" && previousStatus?.cancellationIntent === "abandon") {
        clearCurrentRunId();
      }
      const sharedUploadProgress = syncSharedUploadProgressFromStatus(s);
      syncActiveLibraryItemFromStatus(s);
      syncFeishuTitleFromStatus(s);
      if (normalizeActiveDocumentInputMode() === "feishu-api") {
        if (s.status === "cancelling") $("feishuTitleBadge").textContent = "正在取消";
        else if (s.status === "running") $("feishuTitleBadge").textContent = "API 读取中";
        else if (s.status === "stopped" && s.cancellationReason) $("feishuTitleBadge").textContent = "已停止";
      }
      $("step").textContent = s.step || "-";
      $("status").textContent = labelStatus(s.status);
      $("status").className = "v " + (s.status === "failed" ? "failed" : s.status === "waiting" ? "waiting" : s.status === "completed" ? "done" : "");
      $("current").textContent = s.currentIndex
        ? "第 " + s.currentIndex + " 条 / 共 " + (s.totalCount || "?") + " 条"
        : (s.feishuProgress?.display || "-");
      $("counts").textContent = (s.successCount || 0) + " / " + (s.failureCount || 0);
      $("waiting").textContent = s.waitingReason || "-";
      $("missing").textContent = (s.missingFiles || []).join("、") || "-";
      $("runDir").textContent = s.runDir || "-";
      $("previewPath").textContent = s.previewPath || "-";
      $("failure").textContent = s.failureReason || "-";
      maybeShowCmsAutoSetupFailure(s);
      updateRobotRecoveryActions(s);
      const link = $("previewLink");
      if (s.previewUrl) {
        link.href = s.previewUrl;
        link.style.display = "";
      } else {
        link.style.display = "none";
      }
      $("logs").textContent = (s.logs || []).map((item) => "[" + item.time.replace("T", " ").slice(0, 19) + "] " + item.message).join("\\n");
      updateMainActionButtons(s);
      updateTaskErrorDecisionPanel(s);
      updateExpiredScheduleDecisionPanel(s);
      if (s.status !== "paused" || s.control !== "paused") $("continueDecisionPanel")?.classList.remove("is-open");
      if ((options.taskStarted || !options.manual) && (options.taskStarted || Date.now() >= manualStatusFeedbackUntil)) {
        if (sharedUploadProgress) $("saveState").textContent = sharedUploadProgress.message;
        else if (s.status === "running" || s.status === "cancelling") $("saveState").textContent = s.feishuProgress?.display || s.waitingReason || (s.status === "cancelling" ? "正在取消本轮。" : (s.step ? "正在" + s.step + "。" : "本轮正在运行。"));
        else if (s.status === "failed") $("saveState").textContent = s.failureReason
          ? "流程失败：" + s.failureReason
          : "流程失败，请看失败原因和 run 目录。";
        else if (s.status === "waiting") $("saveState").textContent = s.waitingReason || "预览已生成，请打开预览页检查并保存预览内容。";
        else if (s.status === "completed") $("saveState").textContent = "本轮已创建完成，可以核对任务列表，或开始下一轮发单。";
        else if (s.status === "stopped" && s.cancellationReason) $("saveState").textContent = s.waitingReason || "本轮已停止。";
      }
      if (cmsStartFeedback && feedbackBelongsToCurrentRun(cmsStartFeedback)) {
        if (s.status === "running" && ["received", "checking", "accepted"].includes(cmsStartFeedback.status)) {
          cmsStartFeedback = { ...cmsStartFeedback, status: "running", message: "后台已受理并启动本轮创建，请查看真实进度。" };
          saveCmsStartFeedback();
        }
        renderCmsStartFeedback(cmsStartFeedback);
      }
      if (isActionableSupportState(s)) {
        showSupportAdvice(buildSupportContextFromStatus(s, s.failureReason || $("saveState").textContent), { open: true });
      } else {
        clearSupportAdvice();
      }
      setButtons(s.status);
    }

    function syncSharedUploadProgressFromStatus(status = {}) {
      const id = String(status.sharedUploadItemId || "");
      const message = String(status.waitingReason || "").trim();
      if (!id || !isSharedUploadProgressMessage(message)) return null;
      const label = /正在合并云端文案/.test(message) ? "合并中..." : "上传中...";
      setSharedUploadState(id, {
        busy: true,
        label,
        message,
        tone: ""
      });
      return { id, message, label };
    }

    function normalizePendingSharedUploadProgress(progress = {}, fallbackId = "") {
      const id = String(progress?.itemId || fallbackId || "");
      const message = String(progress?.message || "").trim();
      if (!id || !isSharedUploadProgressMessage(message)) return null;
      return {
        id,
        message,
        label: /正在合并云端文案/.test(message) ? "合并中..." : "上传中..."
      };
    }

    function isSharedUploadProgressMessage(message = "") {
      return /正在上传共享文案|已检测到之前上传过|自动复用|分片上传完成，正在合并云端文案/.test(String(message || ""));
    }

    function handleSaveStateChanged() {
      const message = String($("saveState")?.textContent || "").trim();
      if (!message || !isSupportWorthyMessage(message)) return;
      if (!isActionableSupportState(latestStatus)) return;
      showSupportAdvice(buildSupportContextFromStatus(latestStatus, latestStatus?.failureReason || message), { open: true });
    }

    function isSupportWorthyMessage(message) {
      if (!message) return false;
      if (/不能为空|请先选择|正在|已保存|已打开|已进入|已取消|状态刷新暂时失败/.test(message)) return false;
      return /失败|断开|错误|超时|无法|未授权|不可用|没有找到|素材缺失|机器人不在群/.test(message);
    }

    function isActionableSupportState(state) {
      if (!state) return false;
      if (state.status === "stopped" && state.cancellationReason) return false;
      if (["failed", "stopped", "disconnected"].includes(state.status)) return true;
      if (state.control === "awaiting_error_action") return true;
      return false;
    }

    function hasUsablePreviewResult(state) {
      return Boolean(state?.previewUrl || state?.previewPath);
    }

    function shouldMarkStatusRefreshAsDisconnected(state, failureCount) {
      if (failureCount < 3) return false;
      if (state?.status === "waiting" || state?.status === "completed") return false;
      if (state?.previewUrl || state?.previewPath) return false;
      if (state?.control === "awaiting_preview_confirmation") return false;
      return true;
    }

    function buildSupportContextFromStatus(state, message) {
      const text = String(message || state?.failureReason || state?.waitingReason || "").trim();
      const category = supportCategory(text, state);
      return {
        stage: supportStage(category, state),
        category,
        message: text || "控制台出现异常。",
        lastAction: state?.step || labelStatus(state?.status || "") || "控制台操作",
        runId: currentRunId(),
        previewName: activeLibraryItemId || "",
        suggestions: supportSuggestions(category, text, state),
        logs: collectSupportLogs(state)
      };
    }

    function supportCategory(message, state) {
      const text = String(message || "");
      if (state?.status === "disconnected" ||
        (!hasUsablePreviewResult(state) && /后台服务.*断开|后台.*断开|Failed to fetch|响应超时/.test(text))) {
        return "backend-disconnected";
      }
      if (/授权|未授权|公司网络|VPN|DNS/.test(text)) return "license-network";
      if (/云端文案|共享文案|共享包|上传共享|下载云端/.test(text)) return "shared-library";
      if (/文案库|预览|飞书|素材缺失|素材/.test(text)) return "preview-material";
      if (/云中客|CMS|机器人|精准托|托名单|创建任务|机器人不在群/.test(text)) return "cms";
      return "console";
    }

    function supportStage(category, state) {
      if (category === "backend-disconnected") return "后台断开";
      if (category === "license-network") return "授权/网络";
      if (category === "shared-library") return "云端文案";
      if (category === "preview-material") return "预览/素材";
      if (category === "cms") return state?.step || "云中客创建";
      return state?.step || "控制台";
    }

    function supportSuggestions(category, message, state) {
      if (category === "backend-disconnected") return [
        "关闭旧的 2.0 控制台页面，重新双击正式入口打开。",
        "如果启动很久打不开，先确认没有重复运行的 2.0 后台服务。",
        "重新打开后点“刷新运行状态”，仍然断开再上报给管理员。"
      ];
      if (category === "license-network") return [
        "确认电脑连接公司内网或 VPN，再点“重新检查”。",
        "如果设备未授权，先点“申请授权”，等管理员通过后再检查。",
        "如果 DNS 或授权服务不可用，重启网络后仍不行再上报。"
      ];
      if (category === "shared-library") return [
        "先点云端文案弹窗里的“刷新”，再重新下载或上传。",
        "如果提示素材缺失，按自动打开的预览页标红行重新补传素材后保存。",
        "如果上传包过大或网络不稳，改用“导出共享包”手动发送给对方导入。"
      ];
      if (category === "preview-material") return [
        ...(hasUsablePreviewResult(state) ? [
          "打开本轮预览页，检查系统定位的标红行或缺失素材提示。",
          "确认当前素材，或重新拖拽、点击选择、Ctrl+V 粘贴补传后保存。",
          "未处理完也会保存修复草稿；全部解决后才能确认并进入创建。"
        ] : [
          "本轮预览尚未生成，当前没有可打开和修改的预览页。",
          "按失败原因重新读取或重新生成；相同错误重复出现时请上报管理员。",
          "不要恢复旧预览来替代本轮内容，以免使用到错误文案。"
        ])
      ];
      if (category === "cms") return [
        "先确认云中客页面已经打开并登录，群、机器人和任务配置能手动看到。",
        "精准托问题先确认托昵称存在；搜索后右侧标题应显示已选 1/任意数字。",
        "机器人不在群时先按控制台提示重试、跳过或停止本轮；仍反复失败再上报。"
      ];
      return [
        "先点“刷新运行状态”，确认当前状态是否恢复。",
        "按页面失败原因处理后重试当前操作。",
        "如果同一个错误重复出现，再点击“上报给管理员”。"
      ];
    }

    function collectSupportLogs(state) {
      return (Array.isArray(state?.logs) ? state.logs : []).slice(-20).map((item) => {
        const time = String(item?.time || "").replace("T", " ").slice(0, 19);
        return (time ? "[" + time + "] " : "") + String(item?.message || "");
      }).filter(Boolean);
    }

    function showSupportAdvice(context, options = {}) {
      if (!context || !context.message) return;
      latestSupportContext = context;
      $("supportTitle").textContent = "处理办法：" + (context.stage || "控制台问题");
      $("supportMessage").textContent = context.message + "。先按下面步骤处理；如果仍不行，再上报给管理员。";
      $("supportSuggestions").innerHTML = (context.suggestions || []).map((item) => "<li>" + escapeHtml(item) + "</li>").join("");
      $("supportAdviceBtn").classList.add("is-open");
      $("supportReportBottomBtn").classList.add("is-open");
      if (options.open) $("supportPanel").classList.add("is-open");
    }

    function clearSupportAdvice() {
      latestSupportContext = null;
      $("supportPanel").classList.remove("is-open");
      $("supportAdviceBtn").classList.remove("is-open");
      $("supportReportBottomBtn").classList.remove("is-open");
      $("supportReportState").textContent = "";
    }

    function openCurrentSupportAdvice() {
      if (latestSupportContext?.message && isActionableSupportState(latestStatus)) {
        showSupportAdvice(latestSupportContext, { open: true });
        return;
      }
      const message = String($("saveState")?.textContent || "").trim();
      if (isActionableSupportState(latestStatus) && isSupportWorthyMessage(message)) {
        showSupportAdvice(buildSupportContextFromStatus(latestStatus, message), { open: true });
        return;
      }
      showSupportAdvice({
        stage: "当前状态",
        category: "none",
        message: "当前没有需要处理的异常",
        lastAction: latestStatus?.step || "控制台",
        runId: currentRunId(),
        previewName: activeLibraryItemId || "",
        suggestions: ["如果页面状态不对，先点“刷新运行状态”。", "如果已有预览结果，请继续检查预览内容。"],
        logs: collectSupportLogs(latestStatus)
      }, { open: true });
    }

    async function reportCurrentSupportIssue() {
      if (supportReportInFlight) return;
      const context = latestSupportContext || buildSupportContextFromStatus(latestStatus, $("saveState").textContent);
      if (!context?.message) return;
      recordSupportDiagnostic(context);
      supportReportInFlight = true;
      $("supportReportBtn").disabled = true;
      $("supportReportBottomBtn").disabled = true;
      $("supportReportState").textContent = "正在上报...";
      try {
        const result = await postJson("/api/support/report", { support: context });
        $("supportReportState").textContent = result.message || result.report?.message || "已上报给管理员。";
        $("saveState").textContent = $("supportReportState").textContent;
      } catch (error) {
        $("supportReportState").textContent = "上报失败：" + (error?.message || error);
      } finally {
        supportReportInFlight = false;
        $("supportReportBtn").disabled = false;
        $("supportReportBottomBtn").disabled = false;
      }
    }

    function recordSupportDiagnostic(context) {
      if (!context?.message) return;
      postJson("/api/support/diagnostic", { support: context }).catch(() => {});
    }

    function escapeHtml(value) {
      return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
    }

    function maybeShowCmsAutoSetupFailure(state) {
      const reason = String(state?.failureReason || "");
      const shouldShow = state?.status === "waiting" && reason.includes("云中客配置自动设置失败");
      if (!shouldShow) {
        if (!reason.includes("云中客配置自动设置失败")) lastCmsAutoSetupFailureReason = "";
        $("saveState").classList.remove("is-error");
        return;
      }
      $("saveState").textContent = "自动设置失败，请人工设置后继续。";
      $("saveState").classList.add("is-error");
      if (reason === lastCmsAutoSetupFailureReason || consoleActionResolver) return;
      lastCmsAutoSetupFailureReason = reason;
      manualStatusFeedbackUntil = Date.now() + 15000;
      openConsoleAction({
        title: "云中客配置自动设置失败",
        note: "请在云中客页面人工补好失败项，补好后直接点击“我已设置好，开始创建任务”。",
        message: reason,
        cancelText: "关闭",
        confirmText: "知道了",
        danger: true
      });
    }

    function syncActiveLibraryItemFromStatus(status) {
      const nextId = String(status?.activeLibraryItemId || "");
      if (nextId === activeLibraryItemId) return;
      activeLibraryItemId = nextId;
      if (nextId) setContentSourceMode("library", { silent: true, skipButtons: true });
      renderPreviewLibrary();
      updateLibraryGeneratedSettingsDisabledMode();
    }

    function setControlsDisabledByReason(section, dataKey, disabled) {
      if (!section) return;
      section.querySelectorAll("input,select,textarea,button").forEach((control) => {
        if (disabled) control.dataset[dataKey] = "1";
        else delete control.dataset[dataKey];
        control.disabled = control.dataset.libraryDisabled === "1" || control.dataset.documentImportRangeDisabled === "1";
      });
    }

    function updateLibraryGeneratedSettingsDisabledMode() {
      const disabled = isLibrarySourceModeActive() || Boolean(activeLibraryItemId);
      for (const sectionId of ["feishuSourceCard", "rangeSettingsSection"]) {
        const section = $(sectionId);
        if (!section) continue;
        section.classList.toggle("is-library-disabled", disabled);
        setControlsDisabledByReason(section, "libraryDisabled", disabled);
      }
      updateDocumentImportRangeDisabledMode();
    }

    function isDocumentImportInputModeActive() {
      return contentSourceMode === "feishu" && $("documentInputMode")?.value === "document-paste";
    }

    function lockRangeModeForDocumentImport() {
      if (!isDocumentImportInputModeActive()) return false;
      if ($("rangeMode")?.value !== "full") {
        $("rangeMode").value = "full";
        isolateRangeModeFields("full");
        syncCardGroup("rangeModeChoice", "rangeMode");
        return true;
      }
      return false;
    }

    function updateDocumentImportRangeDisabledMode() {
      const section = $("rangeSettingsSection");
      if (!section) return;
      const disabled = isDocumentImportInputModeActive();
      if (disabled) lockRangeModeForDocumentImport();
      section.classList.toggle("is-import-range-disabled", disabled);
      setControlsDisabledByReason(section, "documentImportRangeDisabled", disabled);
    }

    function bindContentSourceMode() {
      document.querySelectorAll("input[name='contentSourceModeChoice']").forEach((input) => {
        input.addEventListener("change", () => {
          if (!input.checked) return;
          setContentSourceMode(input.value, { manual: true });
        });
      });
      setContentSourceMode($("contentSourceMode")?.value || "feishu", { silent: true });
    }

    function setContentSourceMode(mode, options = {}) {
      contentSourceMode = mode === "library" ? "library" : "feishu";
      if ($("contentSourceMode")) $("contentSourceMode").value = contentSourceMode;
      document.querySelectorAll("input[name='contentSourceModeChoice']").forEach((input) => {
        input.checked = input.value === contentSourceMode;
      });
      $("feishuSourcePanel")?.classList.toggle("is-open", contentSourceMode === "feishu");
      $("librarySourcePanel")?.classList.toggle("is-open", contentSourceMode === "library");
      updateLibraryGeneratedSettingsDisabledMode();
      if (!options.skipButtons) setButtons(latestStatus?.status || "ready");
      if (!options.silent && options.manual) {
        $("saveState").textContent = contentSourceMode === "library"
          ? "已选择使用文案库。请在文案库列表中选择文案；下面不需要改的配置已禁用。"
          : "已选择飞书文档入口。请填写或确认飞书链接后生成预览。";
      }
    }

    function isLibrarySourceModeActive() {
      return contentSourceMode === "library";
    }

    function currentRunId() {
      if (initialRunId) return initialRunId;
      if (latestStatus?.runId) return String(latestStatus.runId);
      const runDir = String(latestStatus?.runDir || "").replace(/[\\\\/]+$/, "");
      return runDir ? runDir.split(/[\\\\/]/).pop() : "";
    }

    function clearCurrentRunId() {
      initialRunId = "";
      const url = new URL(location.href);
      if (!url.searchParams.has("runId")) return;
      url.searchParams.delete("runId");
      history.replaceState(null, "", url.pathname + url.search + url.hash);
    }

    function updateMainActionButtons(s) {
      const completed = s.status === "completed";
      const cmsReady = s.step === "CMS 准备";
      const awaitingCmsLogin = s.control === "awaiting_cms_login";
      const paused = s.status === "paused" || s.control === "paused";
      $("generateBtn").style.display = cmsReady || awaitingCmsLogin ? "none" : "";
      $("resetCmsPageBtn").style.display = cmsReady || awaitingCmsLogin || s.status === "failed" ? "" : "none";
      $("startCmsBtn").style.display = cmsReady || awaitingCmsLogin || completed ? "" : "none";
      $("startCmsBtn").textContent = completed
        ? "本轮已创建完成"
        : awaitingCmsLogin
          ? "我已登录，重新检查"
          : (paused ? "当前已暂停，请点继续" : "我已设置好，开始创建任务");
      $("nextRunBtn").style.display = completed ? "" : "none";
    }

    function updateRobotRecoveryActions(state) {
      const panel = $("robotRecoveryPanel");
      if (!panel) return;
      const show = Boolean(state && state.status === "failed" && isRobotNotInGroupRetryFailure(state.failureReason));
      panel.classList.toggle("is-open", show);
      $("robotDirectCreateBtn").disabled = !show || !controlledBrowserReady || !licenseAllowed;
      $("robotDirectCreateMode").disabled = !show || !controlledBrowserReady || !licenseAllowed;
      $("robotRetryMoreBtn").disabled = !show || !controlledBrowserReady || !licenseAllowed;
    }

    function updateTaskErrorDecisionPanel(state) {
      const panel = $("taskErrorDecisionPanel");
      if (!panel) return;
      const manual = state?.manualAction?.type === "task_error" && state.control === "awaiting_error_action";
      panel.classList.toggle("is-open", manual);
      if (manual) {
        const action = state.manualAction || {};
        const accountMismatch = action.errorCode === "CMS_FINAL_ACCOUNT_MISMATCH";
        const title = "已完成 " + (action.completedCount || state.lastCompletedIndex || 0) + "/" + (action.totalCount || state.totalCount || "?") + " 条；第 " + (action.taskIndex || state.currentIndex || "?") + " 条尚未提交";
        const detail = [
          action.role ? "角色：" + (action.role === "douma" ? "豆妈" : "托") : "",
          action.speaker ? "说话人：" + action.speaker : "",
          action.taskType ? "类型：" + action.taskType : ""
        ].filter(Boolean).join("；");
        $("taskErrorDecisionText").textContent = title + (detail ? "；" + detail : "") + "。原因：" + (action.reason || state.failureReason || "-");
        $("retryCurrentTaskBtn").textContent = accountMismatch ? "核对托账号并从本条继续" : "重试这一条";
        $("editFailedTaskPreviewBtn").textContent = "修改未提交内容";
      }
      const disabled = !manual || !controlledBrowserReady || !licenseAllowed;
      $("retryCurrentTaskBtn").disabled = disabled;
      $("editFailedTaskPreviewBtn").disabled = disabled;
      $("skipCurrentTaskBtn").disabled = disabled;
      $("stopCurrentRunBtn").disabled = !manual;
    }

    function updateExpiredScheduleDecisionPanel(state) {
      const panel = $("expiredScheduleDecisionPanel");
      if (!panel) return;
      const action = state?.manualAction || {};
      const manual = action.type === "expired_schedule"
        && ["awaiting_expired_schedule", "awaiting_expired_schedule_edit"].includes(state?.control);
      panel.classList.toggle("is-open", manual);
      if (manual) {
        const lines = [
          "第 " + (action.completedIndex || "?") + " 条已经创建成功，下一条是第 " + (action.nextIndex || "?") + " 条。",
          "原计划结束：" + (action.originalEnd || "未记录") + "；当前顺延后结束：" + (action.projectedEnd || "未记录") + "。",
          state.control === "awaiting_expired_schedule_edit" ? "续排页面已打开，保存确认后会自动继续。" : "请选择直接顺延，或只修改未执行任务的间隔。"
        ];
        $("expiredScheduleDecisionText").textContent = lines.join(" ");
      }
      const choosing = manual && state.control === "awaiting_expired_schedule";
      $("expiredScheduleDirectBtn").disabled = !choosing || !controlledBrowserReady || !licenseAllowed;
      $("expiredScheduleEditBtn").disabled = !choosing || !controlledBrowserReady || !licenseAllowed;
      $("expiredScheduleStopBtn").disabled = !manual;
    }

    async function handleResumeClick() {
      if (latestStatus?.status === "paused" && latestStatus?.control === "paused") {
        await showContinueDecisionPanel();
        return;
      }
      await sendControl("resume");
    }

    async function showContinueDecisionPanel() {
      const panel = $("continueDecisionPanel");
      panel.classList.add("is-open");
      $("continueDecisionTitle").textContent = "正在判断从哪一条继续...";
      $("continueDecisionText").textContent = "正在读取本轮预览和创建日志。";
      $("continueFromCurrentBtn").disabled = true;
      $("continueFromNextBtn").disabled = true;
      await updateContinuePreviewButton();
      try {
        const result = await fetchJson("/api/continue-candidate");
        if (!result.ok || !result.current) throw new Error(result.error || "没有找到可继续的条目。");
        const current = result.current;
        const next = result.next || null;
        panel.dataset.currentIndex = String(current.index || "");
        panel.dataset.nextIndex = next?.index ? String(next.index) : "";
        $("continueDecisionTitle").textContent = "是否从第 " + current.index + " 条开始创建？";
        $("continueDecisionText").textContent = "当前条：" + formatContinueTask(current) + (next ? "。下一条：" + formatContinueTask(next) : "。后面没有下一条。");
        $("continueFromCurrentBtn").disabled = !current.index || !controlledBrowserReady || !licenseAllowed;
        $("continueFromNextBtn").disabled = !next?.index || !controlledBrowserReady || !licenseAllowed;
      } catch (error) {
        $("continueDecisionTitle").textContent = "无法判断续跑条目";
        $("continueDecisionText").textContent = (error?.message || error) + "；可以打开预览页面重新确认。";
        panel.dataset.currentIndex = "";
        panel.dataset.nextIndex = "";
      }
    }

    async function updateContinuePreviewButton() {
      const button = $("continueOpenPreviewBtn");
      button.disabled = true;
      button.textContent = "正在检查预览...";
      try {
        const result = await fetchJson("/api/preview/restore-candidate");
        const candidate = result.candidate || {};
        if (result.ok && candidate.available) {
          button.disabled = false;
          button.textContent = "打开预览页面";
          button.title = "打开已保存的上次预览；如果预览服务已关闭，会自动重新恢复。";
          return true;
        }
      } catch {}
      button.disabled = true;
      button.textContent = "暂无可恢复预览";
      button.title = "当前没有找到已保存的预览内容。";
      return false;
    }

    function formatContinueTask(task) {
      return [
        "第 " + (task.index || "?") + " 条",
        task.date || task.time ? "时间：" + [task.date, task.time].filter(Boolean).join(" ") : "",
        task.roleLabel || task.speaker ? "角色：" + [task.roleLabel, task.speaker].filter(Boolean).join(" / ") : "",
        task.type ? "类型：" + task.type : "",
        task.summary ? "内容：" + task.summary : ""
      ].filter(Boolean).join("；");
    }

    async function continueFromSelected(which) {
      const panel = $("continueDecisionPanel");
      const targetIndex = Number(which === "next" ? panel.dataset.nextIndex : panel.dataset.currentIndex);
      if (!targetIndex) {
        $("saveState").textContent = "没有可继续的条目，请打开预览页面重新确认。";
        return;
      }
      $("continueFromCurrentBtn").disabled = true;
      $("continueFromNextBtn").disabled = true;
      $("continueOpenPreviewBtn").disabled = true;
      try {
        await postJson("/api/control", { action: "resume_from_index", targetIndex });
        panel.classList.remove("is-open");
        $("saveState").textContent = "已选择从第 " + targetIndex + " 条开始继续创建。";
        await refreshStatus({ manual: true });
      } catch (error) {
        $("saveState").textContent = "继续创建失败：" + (error?.message || error);
        $("continueFromCurrentBtn").disabled = false;
        $("continueFromNextBtn").disabled = !panel.dataset.nextIndex;
        $("continueOpenPreviewBtn").disabled = false;
      }
    }

    async function openPreviewFromContinuePanel() {
      if ($("continueOpenPreviewBtn").disabled) {
        $("saveState").textContent = "暂无可恢复预览。";
        return;
      }
      $("continueFromCurrentBtn").disabled = true;
      $("continueFromNextBtn").disabled = true;
      $("continueOpenPreviewBtn").disabled = true;
      $("continueOpenPreviewBtn").textContent = "正在打开预览...";
      $("saveState").textContent = "正在打开已保存的预览页面。";
      try {
        await postJson("/api/control", { action: "stop" });
        await waitUntilWorkflowIdle();
        const result = await postJson("/api/preview/restore", { settings: readSettings() });
        if (!result.ok) throw new Error(result.error || "打开预览页面失败。");
        $("continueDecisionPanel").classList.remove("is-open");
        $("saveState").textContent = "已打开上次预览页面，请确认后再创建。";
        await refreshStatus({ manual: true });
      } catch (error) {
        $("saveState").textContent = "打开预览页面失败：" + (error?.message || error);
        await updateContinuePreviewButton();
      }
    }

    async function waitUntilWorkflowIdle(timeoutMs = 5000) {
      const deadline = Date.now() + timeoutMs;
      while (Date.now() < deadline) {
        const state = await refreshStatus({ manual: true });
        if (!state || (state.status !== "running" && state.status !== "paused")) return;
        await new Promise((resolve) => setTimeout(resolve, 250));
      }
    }

    function isRobotNotInGroupRetryFailure(reason) {
      const text = String(reason || "");
      return text.includes("机器人不在群") && (
        text.includes("已尝试更换机器人") ||
        text.includes("更换机器人后仍检测到机器人不在群")
      );
    }

    function markBackendDisconnected(error, options = {}) {
      backendDisconnected = true;
      controlledBrowserReady = false;
      const reason = error?.message || String(error || "无法连接后台服务");
      const saveMessage = options.saveMessage || "控制台后台服务已断开，请重新双击 2.0 可视化控制台正式入口。当前操作不会继续生成预览。";
      latestStatus = {
        ...(latestStatus || {}),
        step: "后台断开",
        status: "disconnected",
        waitingReason: "后台服务已断开，请重新打开正式入口。",
        failureReason: reason
      };
      $("step").textContent = "后台断开";
      $("status").textContent = "后台断开";
      $("status").className = "v failed";
      $("waiting").textContent = "后台服务已断开，请重新打开正式入口。";
      $("failure").textContent = reason;
      $("saveState").textContent = saveMessage;
      $("previewLink").style.display = "none";
      updateRobotRecoveryActions(null);
      updateTaskErrorDecisionPanel(null);
      $("continueDecisionPanel")?.classList.remove("is-open");
      showSupportAdvice(buildSupportContextFromStatus(latestStatus, saveMessage + " 原因：" + reason), { open: true });
      setButtons("ready");
    }

    function syncFeishuTitleFromStatus(state) {
      const title = String(state?.feishuTitle || "").trim();
      if (!title || isPlaceholderFeishuTitle(title)) return;
      const activeSource = $("contentSourceMode")?.value || contentSourceMode;
      if (activeSource !== "feishu" || normalizeActiveDocumentInputMode() !== "feishu-api") return;
      const currentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      const statusUrl = normalizeFeishuUrlInput(state?.feishuTitleUrl || state?.feishuUrl || "");
      if (!currentUrl || !statusUrl || !sameFeishuDocument(statusUrl, currentUrl)) return;
      if (["正在获取", "获取失败"].includes($("feishuTitleBadge").textContent.trim())) return;
      const currentTitle = $("feishuTitle").value.trim();
      if (currentTitle === title) return;
      if (currentTitle && !isPlaceholderFeishuTitle(currentTitle)) return;
      $("feishuTitle").value = title;
      titleReadForFeishuUrl = statusUrl;
      $("feishuTitleUrl").value = titleReadForFeishuUrl;
      $("feishuTitleBadge").textContent = "已读取";
      $("feishuTitleBadge").className = "field-badge good";
    }

    function isPlaceholderFeishuTitle(value) {
      return ["待读取", "未读取到标题"].includes(String(value || "").trim());
    }

    function sameFeishuDocument(left, right) {
      const leftKey = feishuDocumentKey(left);
      const rightKey = feishuDocumentKey(right);
      return Boolean(leftKey && rightKey && leftKey === rightKey);
    }

    function feishuDocumentKey(value) {
      const url = normalizeFeishuUrlInput(value);
      if (!url) return "";
      const match = url.match(/^https:\\/\\/([^/]*feishu\\.cn)\\/(docx|wiki)\\/([^?#]+)/i);
      return match ? (match[1].toLowerCase() + "/" + match[2].toLowerCase() + "/" + match[3]) : "";
    }

    async function refreshLicenseDiagnostics(options = {}) {
      if (licenseCheckInFlight) return;
      licenseCheckInFlight = true;
      if (licenseAutoRefreshTimer) {
        clearTimeout(licenseAutoRefreshTimer);
        licenseAutoRefreshTimer = null;
      }
      $("licenseRefreshBtn").disabled = true;
      if (!options.auto) $("licenseRequestState").textContent = "正在检查授权和公司网络...";
      try {
        const result = await fetchJson("/api/license/diagnostics" + (options.auto ? "" : "?refresh=1"));
        if (!result.ok) throw new Error(result.error || "授权检查失败。");
        latestLicenseDiagnostics = result.diagnostics || null;
        renderLicenseDiagnostics(latestLicenseDiagnostics);
      } catch (error) {
        licenseAllowed = false;
        $("licensePanel").className = "license-panel is-open";
        $("licenseMainText").textContent = "授权检查失败";
        $("licenseDns").textContent = "-";
        $("licenseService").textContent = error?.message || String(error);
        $("licenseDevice").textContent = "-";
        $("licenseAdvice").textContent = "请确认已连接公司网络后重新检查。";
        $("licenseRequestBtn").disabled = true;
        $("licenseCopyDeviceBtn").disabled = true;
      } finally {
        licenseCheckInFlight = false;
        $("licenseRefreshBtn").disabled = false;
        setButtons(latestStatus?.status || "ready");
        scheduleLicenseAutoRefresh();
      }
    }

    function scheduleLicenseAutoRefresh() {
      if (licenseAllowed || licenseAutoRefreshTimer) return;
      licenseAutoRefreshTimer = setTimeout(() => {
        licenseAutoRefreshTimer = null;
        refreshLicenseDiagnostics({ auto: true }).catch(() => {});
      }, 5000);
    }

    function renderLicenseDiagnostics(diagnostics) {
      const license = diagnostics?.license || {};
      licenseAllowed = license.allowed === true;
      $("licensePanel").className = licenseAllowed ? "license-panel is-open authorized" : "license-panel is-open";
      $("licenseMainText").textContent = licenseAllowed
        ? (license.state === "refresh_unavailable" ? "授权有效，刷新暂不可用" : license.shared ? "授权有效（本机共享）" : "授权通过（旧服务实时检查）")
        : (license.state === "expired" ? "共享授权已到期" : license.state === "revoked" ? "授权已撤销" : (license.message || "当前设备未授权"));
      $("licenseDns").textContent = diagnostics?.dns?.message || "-";
      $("licenseService").textContent = diagnostics?.service?.message || "-";
      $("licenseDevice").textContent = diagnostics?.deviceId || "-";
      const canRequest = Boolean(diagnostics?.deviceId && diagnostics?.dns?.ok && diagnostics?.service?.ok && !licenseAllowed);
      $("licenseRequestBtn").disabled = !canRequest;
      $("licenseCopyDeviceBtn").disabled = !diagnostics?.deviceId;
      $("licenseAdvice").textContent = licenseAllowed
        ? (license.message || "可以正常使用。")
        : canRequest
          ? "点击申请授权，管理员在总控页面通过后，再点重新检查。"
          : "请先处理 DNS、公司网络或设备号读取问题。";
      $("licenseRequestState").textContent = licenseAllowed
        ? (license.shared ? ("本机多个实例可复用到 " + (license.expiresAt ? new Date(license.expiresAt).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" }) : "凭证到期") + "。") : "服务器尚未升级共享凭证，当前仍会实时检查。")
        : "未授权时可以提交申请，由管理员在总控页面审批。";
    }

    async function requestLicenseAccess() {
      $("licenseRequestBtn").disabled = true;
      $("licenseRequestState").textContent = "正在提交授权申请...";
      try {
        const result = await postJson("/api/license/request", {});
        if (!result.ok || !result.request?.ok) throw new Error(result.request?.message || result.error || "申请提交失败。");
        $("licenseRequestState").textContent = result.request.message || "申请已提交，请等待管理员审批。";
        if (result.request.deviceId) {
          latestLicenseDiagnostics = { ...(latestLicenseDiagnostics || {}), deviceId: result.request.deviceId };
          $("licenseDevice").textContent = result.request.deviceId;
        }
      } catch (error) {
        $("licenseRequestState").textContent = "申请失败：" + (error?.message || error);
      } finally {
        await refreshLicenseDiagnostics();
      }
    }

    async function copyLicenseDeviceId() {
      const deviceId = latestLicenseDiagnostics?.deviceId || $("licenseDevice").textContent;
      if (!deviceId || deviceId === "-") return;
      try {
        await navigator.clipboard.writeText(deviceId);
        $("licenseRequestState").textContent = "设备号已复制。";
      } catch {
        $("licenseRequestState").textContent = "复制失败，可以手动选中设备号复制。";
      }
    }

    async function refreshVersionStatus(options = {}) {
      $("versionState").textContent = options.startup ? "正在自动检查更新..." : "正在检查更新...";
      $("versionRefreshBtn").disabled = true;
      try {
        const [versionResult, licenseResult] = await Promise.all([
          fetchJson("/api/version/status"),
          fetchJson("/api/license/status")
        ]);
        if (!versionResult.ok) {
          throw new Error(versionResult.error || "检查失败，可稍后重试。");
        }
        const v = versionResult.version || {};
        const license = licenseResult.license || {};
        renderVersionStatus(v, license, options);
      } catch (error) {
        $("versionMainState").textContent = "检查失败，可稍后重试";
        $("versionMainState").className = "version-main-state failed";
        $("versionUpdateHint").textContent = "没有完成更新检查，不会影响当前使用。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
        $("versionState").textContent = "检查失败，可稍后重试：" + (error?.message || error);
      } finally {
        $("versionRefreshBtn").disabled = false;
      }
    }

    function renderVersionStatus(v, license, options = {}) {
      latestVersionInfo = v || {};
      licenseAllowed = license.allowed === true;
      const current = v.currentDisplayVersion || v.currentVersion || "-";
      const latest = v.latestRemoteDisplayVersion || v.latestRemoteVersion || "";
      const currentIsBeta = /-/.test(String(v.currentVersion || current || ""));
      const updateCheckError = v.updateCheckError || "";
      const updateCheckDetail = formatVersionUpdateCheckDetail(v, updateCheckError);
      $("versionNumber").textContent = current;
      if (v.pendingUpdateReady) {
        $("versionMainState").textContent = "新版本已准备好：" + latest;
        $("versionMainState").className = "version-main-state has-update";
        $("versionUpdateHint").textContent = "新版本已下载好。本次可以继续使用当前版本，下次双击启动会自动更新。";
        $("versionUpdateBtn").dataset.updateAvailable = "1";
        $("versionUpdateBtn").disabled = false;
        if (!versionNoticeDismissed) {
          $("versionNoticeText").textContent = "新版本 " + latest + " 已下载好，下次启动会自动更新。";
          $("versionNotice").classList.add("is-open");
        }
      } else if (v.updateAvailable) {
        $("versionMainState").textContent = "发现新版本：" + latest;
        $("versionMainState").className = "version-main-state has-update";
        $("versionUpdateHint").textContent = options.startup && v.updateMode === "patch"
          ? "正在后台下载新版本，不影响当前操作；下载好后会提示下次启动自动更新。"
          : "发现新版本 " + latest + "，可以立即更新，也可以等待后台准备后下次启动自动更新。";
        $("versionUpdateBtn").dataset.updateAvailable = "1";
        $("versionUpdateBtn").disabled = false;
        if (!options.startup && !versionNoticeDismissed) {
          $("versionNoticeText").textContent = "发现新版本 " + latest + "，可前往版本更新。";
          $("versionNotice").classList.add("is-open");
        }
        maybePrepareUpdateInBackground(v, options);
      } else if (updateCheckError) {
        $("versionMainState").textContent = "更新检查未完成";
        $("versionMainState").className = "version-main-state failed";
        $("versionUpdateHint").textContent = "检查更新超时或失败，不影响当前使用。点“检查更新”会重新请求并刷新这里的结果。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
      } else if (currentIsBeta && latest) {
        $("versionMainState").textContent = "当前为内测版：" + current;
        $("versionMainState").className = "version-main-state";
        $("versionUpdateHint").textContent = "正式源最新是 " + latest + "，低于当前内测版；当前无需更新，不要点击立即更新。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
      } else {
        $("versionMainState").textContent = "已是最新版本";
        $("versionMainState").className = "version-main-state";
        $("versionUpdateHint").textContent = "当前已是最新版本。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
      }
      $("versionCommit").textContent = v.currentCommit || "-";
      $("versionProjectDir").textContent = v.projectDir || "-";
      const sourceCount = Array.isArray(v.updateSourceUrls) ? v.updateSourceUrls.length : 0;
      $("versionRemote").textContent = v.hasUpdateSource
        ? ("补丁源：" + (v.updateSourceUrl || "已配置") + (sourceCount > 1 ? "（含备用源）" : ""))
        : (v.hasGitRemote ? (v.remoteUrl || "已连接") : "未连接");
      $("versionLocalChanges").textContent = v.hasLocalChanges ? "有本地修改" : "干净";
      $("versionLatestBackup").textContent = v.latestBackup ? v.latestBackup.path : "-";
      $("versionStableTag").textContent = v.latestStableTag || "-";
      $("licenseStatus").textContent = license.message || "-";
      $("versionState").textContent = updateCheckError
        ? "检查更新未完成：" + updateCheckDetail
        : (v.updateFallbackUsed ? "检查更新完成，已自动切换备用更新源。" : (options.startup ? "已自动检查更新。" : "检查更新完成。"));
      setButtons(latestStatus?.status || "ready");
    }

    function formatVersionUpdateCheckDetail(v, fallback) {
      const errors = Array.isArray(v.updateSourceErrors) ? v.updateSourceErrors : [];
      if (!errors.length) return fallback || "未知原因";
      const detail = errors.map((item, index) => {
        const url = item.updateSourceUrl || ("更新地址" + (index + 1));
        const error = item.error || "请求失败";
        return (index + 1) + ". " + url + "：" + error;
      }).join("；");
      return (fallback || "更新源检查失败") + "；地址明细：" + detail;
    }

    function maybePrepareUpdateInBackground(v, options = {}) {
      if (!options.startup && !options.autoPreparePoll) return;
      if (v.updateMode !== "patch" || !v.updateAvailable || v.pendingUpdateReady || versionAutoPrepareStarted) return;
      versionAutoPrepareStarted = true;
      $("versionState").textContent = "发现新版本，正在后台下载；不影响当前操作。";
      postJson("/api/version/prepare-update", {}).catch((error) => {
        $("versionState").textContent = "后台自动下载更新失败，可手动检查更新：" + (error?.message || error);
      });
      scheduleVersionPreparePoll(1);
    }

    function scheduleVersionPreparePoll(attempt) {
      if (versionPreparePollTimer) clearTimeout(versionPreparePollTimer);
      if (attempt > 90) return;
      versionPreparePollTimer = setTimeout(async () => {
        await refreshVersionStatus({ autoPreparePoll: true }).catch(() => {});
        if (latestVersionInfo?.pendingUpdateReady || !latestVersionInfo?.updateAvailable) return;
        scheduleVersionPreparePoll(attempt + 1);
      }, 4000);
    }

    async function runVersionAction(action) {
      const prompts = {
        backup: "确认创建当前稳定备份？",
        update: "更新前会自动备份当前版本，是否继续？",
        rollback: "回退前会自动备份当前版本，是否继续？",
        "open-backup-dir": ""
      };
      const endpoints = {
        backup: "/api/version/backup",
        update: "/api/version/update",
        rollback: "/api/version/rollback",
        "open-backup-dir": "/api/version/open-backup-dir"
      };
      if (prompts[action] && !confirm(prompts[action])) return;
      setVersionButtons(true);
      $("versionState").textContent = action === "open-backup-dir" ? "正在打开备份目录。" : "正在执行版本操作，请等待。";
      try {
        const result = await postJson(endpoints[action], {});
        if (!result.ok) throw new Error(result.error || "版本操作失败。");
        $("versionState").textContent = result.message || result.result?.backupPath || "版本操作完成。";
        await refreshVersionStatus();
      } catch (error) {
        $("versionState").textContent = "版本操作失败：" + (error?.message || error);
      } finally {
        setVersionButtons(false);
      }
    }

    function setVersionButtons(disabled) {
      for (const id of ["versionRefreshBtn","versionBackupBtn","versionUpdateBtn","versionRollbackBtn","versionOpenBackupBtn"]) {
        if (id === "versionUpdateBtn" && !disabled) {
          $(id).disabled = $(id).dataset.updateAvailable !== "1";
        } else {
          $(id).disabled = disabled;
        }
      }
    }

    function currentClockText() {
      return new Date().toLocaleTimeString("zh-CN", { hour12: false });
    }

    function labelStatus(status) {
      if (status === "running") return "运行中";
      if (status === "cancelling") return "正在取消";
      if (status === "paused") return "已暂停";
      if (status === "stopped") return "已停止";
      if (status === "waiting") return "等待人工确认";
      if (status === "completed") return "完成";
      if (status === "failed") return "失败";
      if (status === "disconnected") return "后台断开";
      return "就绪";
    }

    function setButtons(status) {
      const awaitingErrorAction = latestStatus?.control === "awaiting_error_action";
      const awaitingExpiredSchedule = ["awaiting_expired_schedule", "awaiting_expired_schedule_edit"].includes(latestStatus?.control);
      const busy = status === "running" || status === "paused" || status === "cancelling";
      const paused = status === "paused" || latestStatus?.control === "paused";
      const documentMode = normalizeActiveDocumentInputMode();
      const canGenerateWithoutBrowser = documentMode === "document-paste" || documentMode === "feishu-api";
      const headingRequirement = headingRangeGenerationRequirement();
      $("generateBtn").disabled = backendDisconnected || busy || (!controlledBrowserReady && !canGenerateWithoutBrowser) || !licenseAllowed || contentSourceMode !== "feishu" || headingRequirement.blocked;
      $("generateBtn").textContent = headingRequirement.blocked ? "请先读取并选择范围" : "保存设置，生成预览";
      $("generateBtn").title = headingRequirement.blocked ? headingRequirement.message : "";
      const completed = latestStatus && latestStatus.status === "completed";
      const startRequestBlocked = cmsStartRequestInFlight || (feedbackBelongsToCurrentRun(cmsStartFeedback) && ["received", "checking", "accepted", "running", "unknown", "recovery_required"].includes(cmsStartFeedback?.status));
      $("startCmsBtn").disabled = completed || startRequestBlocked || (busy && !paused) || !controlledBrowserReady || !licenseAllowed;
      const recoveryButtonsDisabled = busy || !controlledBrowserReady || !licenseAllowed || cmsStartRequestInFlight;
      $("cmsRecoveryCurrentBtn").disabled = recoveryButtonsDisabled || !$("cmsRecoveryCurrentTask")?.querySelector("strong");
      $("cmsRecoveryNextBtn").disabled = recoveryButtonsDisabled || !$("cmsRecoveryNextTask")?.querySelector("strong");
      $("cmsRecoveryRestartBtn").disabled = recoveryButtonsDisabled || !$("cmsRecoveryRestartTask")?.querySelector("strong");
      $("nextRunBtn").disabled = busy || !controlledBrowserReady;
      $("discardBtn").disabled = !controlledBrowserReady;
      $("exitBtn").disabled = !controlledBrowserReady;
      if ($("robotRecoveryPanel")?.classList.contains("is-open")) {
        $("robotDirectCreateBtn").disabled = busy || !controlledBrowserReady || !licenseAllowed;
        $("robotDirectCreateMode").disabled = busy || !controlledBrowserReady || !licenseAllowed;
        $("robotRetryMoreBtn").disabled = busy || !controlledBrowserReady || !licenseAllowed;
      }
      $("pauseBtn").disabled = status !== "running";
      $("resumeBtn").disabled = status !== "paused" || awaitingErrorAction || awaitingExpiredSchedule;
      $("stopBtn").disabled = !busy || status === "cancelling";
      if ($("taskErrorDecisionPanel")?.classList.contains("is-open")) {
        $("retryCurrentTaskBtn").disabled = !awaitingErrorAction || !controlledBrowserReady || !licenseAllowed;
        $("editFailedTaskPreviewBtn").disabled = !awaitingErrorAction || !controlledBrowserReady || !licenseAllowed;
        $("skipCurrentTaskBtn").disabled = !awaitingErrorAction || !controlledBrowserReady || !licenseAllowed;
        $("stopCurrentRunBtn").disabled = !awaitingErrorAction;
      }
      if ($("expiredScheduleDecisionPanel")?.classList.contains("is-open")) {
        const choosing = latestStatus?.control === "awaiting_expired_schedule";
        $("expiredScheduleDirectBtn").disabled = !choosing || !controlledBrowserReady || !licenseAllowed;
        $("expiredScheduleEditBtn").disabled = !choosing || !controlledBrowserReady || !licenseAllowed;
        $("expiredScheduleStopBtn").disabled = !awaitingExpiredSchedule;
      }
      if ($("continueDecisionPanel")?.classList.contains("is-open")) {
        $("continueFromCurrentBtn").disabled = status !== "paused" || !controlledBrowserReady || !licenseAllowed || !$("continueDecisionPanel").dataset.currentIndex;
        $("continueFromNextBtn").disabled = status !== "paused" || !controlledBrowserReady || !licenseAllowed || !$("continueDecisionPanel").dataset.nextIndex;
      }
      updateLibraryGeneratedSettingsDisabledMode();
    }

    function headingRangeGenerationRequirement() {
      if (contentSourceMode !== "feishu"
        || normalizeActiveDocumentInputMode() !== "feishu-api"
        || $("rangeMode")?.value !== "heading") {
        return { blocked: false, message: "" };
      }
      if (!headingStructure) {
        return { blocked: true, message: "请先通过 API 读取标题结构，再选择读取范围。" };
      }
      const selectionMode = $("headingSelectionMode")?.value || "single";
      if (selectionMode === "range") {
        if (!$("headingStartDay")?.value || !$("headingEndDay")?.value) {
          return { blocked: true, message: "请先选择读取范围的开始和结束天数。" };
        }
      } else if (!$("headingDay")?.value) {
        return { blocked: true, message: "请先选择要读取的天数或内容范围。" };
      }
      return { blocked: false, message: "" };
    }

    function bindCardGroup(name, selectId) {
      for (const radio of document.querySelectorAll("input[name='" + name + "']")) {
        radio.addEventListener("change", () => {
          if (radio.checked) $(selectId).value = selectId === "robotStrategy" && radio.value === "fixed" ? "precise" : radio.value;
          if (selectId === "rangeMode") isolateRangeModeFields(radio.value);
          if (selectId === "rangeMode") updateRangeVisibility();
          if (selectId === "headingSelectionMode") isolateHeadingSelectionModeFields(radio.value);
          if (selectId === "headingSelectionMode") updateHeadingSelectionVisibility();
          if (selectId === "robotStrategy") syncRobotStrategyGroup();
          if (selectId === "robotNotInGroupPolicy") updateRobotNotInGroupVisibility();
          if (selectId === "documentInputMode") updateDocumentInputModeVisibility();
          if (selectId === "scheduleMode") updateScheduleModeVisibility();
          if (["rangeMode", "headingSelectionMode", "documentInputMode"].includes(selectId)) {
            setButtons(latestStatus?.status || "ready");
          }
        });
      }
    }

    function syncCardGroups() {
      syncRobotStrategyGroup();
      syncCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
      syncCardGroup("documentInputModeChoice", "documentInputMode");
      syncCardGroup("rangeModeChoice", "rangeMode");
      syncCardGroup("headingSelectionModeChoice", "headingSelectionMode");
      syncCardGroup("scheduleModeChoice", "scheduleMode");
      updateRangeVisibility();
      updateHeadingSelectionVisibility();
      updateRobotNotInGroupVisibility();
      updateScheduleModeVisibility();
    }

    function syncCardGroup(name, selectId) {
      const value = $(selectId)?.value || "";
      const radio = document.querySelector("input[name='" + name + "'][value='" + value + "']");
      if (radio) radio.checked = true;
    }

    function updateRangeVisibility() {
      const importLocked = isDocumentImportInputModeActive();
      if (importLocked) lockRangeModeForDocumentImport();
      const mode = $("rangeMode").value;
      const full = mode === "full";
      const heading = mode === "heading";
      $("rangeInputs").style.display = mode === "range" ? "grid" : "none";
      $("headingRangeInputs").style.display = heading ? "grid" : "none";
      const libraryNote = "直接使用文案库保存的预览时，一般不用改这里。";
      const importNote = "直接粘贴模式会使用当前粘贴内容全文；如果只要部分内容，请只粘贴需要生成的那一段。";
      $("rangeHint").textContent = importLocked
        ? importNote
        : full
          ? "本次读取：全文。不会显示开始位置/结束位置，也不会使用节奏标题。" + libraryNote
          : heading
            ? "本次读取：按节奏/天数选择。先通过飞书 API 读取标题结构；生成预览时会重新读取正文和素材。" + libraryNote
            : "本次选择指定范围：按当前填写的开始位置和结束位置读取；结束位置为空表示读到文档末尾。" + libraryNote;
      if (heading) updateHeadingSelectionVisibility();
      updateDocumentImportRangeDisabledMode();
    }

    function isolateRangeModeFields(mode) {
      if (mode === "full") {
        $("startKeyword").value = "";
        $("endKeyword").value = "";
        headingStructure = null;
        resetHeadingStructureOptions("请先读取标题结构");
      } else if (mode === "range") {
        headingStructure = null;
        resetHeadingStructureOptions("请先读取标题结构");
      } else if (mode === "heading") {
        $("startKeyword").value = "";
        $("endKeyword").value = "";
      }
    }

    function isolateHeadingSelectionModeFields(mode) {
      if (mode === "range") {
        $("headingRhythm").value = "";
      } else {
        $("headingStartDay").value = "";
        $("headingEndDay").value = "";
      }
      updateHeadingRangeHint();
    }

    function updateHeadingSelectionVisibility() {
      const range = $("headingSelectionMode").value === "range";
      for (const el of document.querySelectorAll(".heading-single-field")) {
        el.style.display = range ? "none" : "";
      }
      for (const el of document.querySelectorAll(".heading-range-field")) {
        el.style.display = range ? "" : "none";
      }
      syncCardGroup("headingSelectionModeChoice", "headingSelectionMode");
      updateHeadingRangeHint();
    }

    function updateRobotNotInGroupVisibility() {
      const switchRobot = $("robotNotInGroupPolicy").value === "switch_robot";
      $("robotNotInGroupRetryConfig").style.display = switchRobot ? "grid" : "none";
      $("robotNotInGroupHint").style.display = switchRobot ? "block" : "none";
      $("robotNotInGroupHint").textContent = "连续 " + ($("robotNotInGroupMaxRetries").value || "5") + " 次仍不在群，就停止当前批次并提示人工处理。";
    }

    function updateRobotStrategyVisibility() {
      const strategy = $("robotStrategy").value;
      const preciseTopSelected = strategy === "precise";
      $("preciseTuoConfig").style.display = preciseTopSelected ? "block" : "none";
      $("preciseTuoRosterConfig").style.display = preciseTopSelected ? "block" : "none";
      $("preciseTuoRosterEnabled").checked = strategy === "precise";
      if (!preciseTopSelected) clearPreciseRosterRequired();
      updateTuoRosterUploadDisplay();
      updateCmsWizardTuoMode();
    }

    function syncRobotStrategyGroup() {
      let strategy = $("robotStrategy").value;
      if (strategy === "fixed") {
        strategy = "precise";
        $("robotStrategy").value = strategy;
      }
      const topValue = strategy === "random" ? "random" : "fixed";
      const radio = document.querySelector("input[name='robotStrategyChoice'][value='" + topValue + "']");
      if (radio) radio.checked = true;
      updateRobotStrategyVisibility();
    }

    function updateScheduleModeVisibility() {
      const mode = $("scheduleMode").value;
      const isDoc = mode === "doc";
      const isRealtime = mode === "realtime";
      const isCatchup = mode === "catchup";
      const libraryNote = "直接使用文案库保存的预览时，不会按这里重新排时间；需要改时间请在预览页里调整，或重新读取飞书生成预览。";
      $("timeFields").style.display = "grid";
      $("customIntervals").style.display = isDoc ? "none" : "block";
      $("intervalDefaultHint").style.display = isDoc ? "none" : "block";
      $("realtimeStartField").style.display = isRealtime ? "grid" : "none";
      $("realtimeEndField").style.display = isRealtime ? "grid" : "none";
      $("catchupStartField").style.display = isCatchup ? "grid" : "none";
      $("dateField").style.display = "grid";
      if (isDoc) {
        $("timeModeHint").textContent = "文档时间：只取文档里的时分秒；日期使用第一天发单日期，遇到第一天/第二天或换天标题会自动顺延。预览顺序可以按互动逻辑调整，但每条时间不能改。" + libraryNote;
      } else if (isRealtime) {
        $("timeModeHint").textContent = "实时跟发：按开始时间重新生成发送时间；结束时间可留空。设置结束时间后会尽量铺满到结束时间，排不进去的条目仍生成预览并标红提示。" + libraryNote;
      } else {
        $("timeModeHint").textContent = "补发到文档时间：过期内容从开始时间补发，后面能接回文档原时间时就回到文档时间，不会把后面所有时间重新顺一遍。" + libraryNote;
      }
    }

    const visibleIntervalFields = ["differentTuoMin","differentTuoMax","sameTuoMin","sameTuoMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"];
    const intervalPresetGroups = [
      ["不同托", "differentTuoMin", "differentTuoMax"],
      ["同托", "sameTuoMin", "sameTuoMax"],
      ["豆妈连续", "doumaSameMin", "doumaSameMax"],
      ["豆妈托切换", "roleSwitchMin", "roleSwitchMax"]
    ];

    async function loadIntervalPresets(selectedId = "") {
      const result = await fetchJson("/api/interval-presets");
      intervalPresets = Array.isArray(result.presets) ? result.presets : [];
      renderIntervalPresetOptions(selectedId);
    }

    function renderIntervalPresetOptions(selectedId = "") {
      const select = $("intervalPresetSelect");
      if (!select) return;
      select.innerHTML = "";
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = intervalPresets.length ? "选择已保存方案" : "暂无已保存方案";
      select.appendChild(placeholder);
      for (const preset of intervalPresets) {
        const option = document.createElement("option");
        option.value = preset.id;
        option.textContent = preset.name || "未命名方案";
        select.appendChild(option);
      }
      select.value = selectedId && intervalPresets.some((item) => item.id === selectedId) ? selectedId : "";
      renderIntervalPresetList();
    }

    function renderIntervalPresetList() {
      const list = $("intervalPresetList");
      if (!list) return;
      list.innerHTML = "";
      if (!intervalPresets.length) {
        const empty = document.createElement("div");
        empty.className = "interval-preset-empty";
        empty.textContent = "暂无已保存方案。先填写上面的间隔，再点“保存当前为方案”。";
        list.appendChild(empty);
        return;
      }
      for (const preset of intervalPresets) {
        const row = document.createElement("div");
        row.className = "interval-preset-row";

        const nameInput = document.createElement("input");
        nameInput.value = preset.name || "";
        nameInput.placeholder = "方案名称";
        nameInput.dataset.presetId = preset.id;

        const summary = document.createElement("div");
        summary.className = "interval-preset-summary";
        summary.textContent = intervalPresetSummary(preset.intervals || {});

        const actions = document.createElement("div");
        actions.className = "interval-preset-actions";

        const renameBtn = document.createElement("button");
        renameBtn.type = "button";
        renameBtn.textContent = "保存名称";
        renameBtn.addEventListener("click", () => renameIntervalPreset(preset.id, nameInput.value));

        const updateBtn = document.createElement("button");
        updateBtn.type = "button";
        updateBtn.textContent = "更新为当前填写";
        updateBtn.addEventListener("click", () => updateIntervalPresetFromCurrent(preset.id, nameInput.value));

        const deleteBtn = document.createElement("button");
        deleteBtn.type = "button";
        deleteBtn.className = "outline-danger";
        deleteBtn.textContent = "删除";
        deleteBtn.addEventListener("click", () => deleteIntervalPresetById(preset.id));

        actions.append(renameBtn, updateBtn, deleteBtn);
        row.append(nameInput, summary, actions);
        list.appendChild(row);
      }
    }

    function intervalPresetSummary(intervals) {
      return intervalPresetGroups
        .map(([label, minKey, maxKey]) => {
          const min = intervals[minKey];
          const max = intervals[maxKey];
          return String(min ?? "").trim() && String(max ?? "").trim() ? label + " " + min + "-" + max + "秒" : "";
        })
        .filter(Boolean)
        .join("；") || "未填写间隔";
    }

    function toggleIntervalPresetPanel() {
      const panel = $("intervalPresetPanel");
      panel.classList.toggle("is-open");
      if (panel.classList.contains("is-open")) renderIntervalPresetList();
    }

    function readVisibleIntervalValues() {
      const values = {};
      for (const key of visibleIntervalFields) values[key] = $(key)?.value || "";
      values.mediaMin = "";
      values.mediaMax = "";
      return values;
    }

    function hasVisibleIntervalValues(values) {
      return visibleIntervalFields.some((key) => String(values[key] || "").trim() !== "");
    }

    function defaultIntervalPresetName(values) {
      const filled = intervalPresetGroups
        .map(([label, minKey, maxKey]) => ({ label, min: values[minKey], max: values[maxKey] }))
        .filter((item) => String(item.min || "").trim() && String(item.max || "").trim());
      if (filled.length === 1) return filled[0].label + " " + filled[0].min + "-" + filled[0].max + "秒";
      if (filled.length > 1 && filled.every((item) => item.min === filled[0].min && item.max === filled[0].max)) {
        return "统一间隔 " + filled[0].min + "-" + filled[0].max + "秒";
      }
      const now = new Date();
      const pad = (value) => String(value).padStart(2, "0");
      return "间隔方案 " + pad(now.getMonth() + 1) + "-" + pad(now.getDate()) + " " + pad(now.getHours()) + ":" + pad(now.getMinutes());
    }

    async function uploadTuoRosterFile(file) {
      const allowed = /\\.(xlsx|csv|json)$/i.test(file.name || "");
      if (!allowed) {
        setTuoRosterUploadStatus("只支持 XLSX、CSV、JSON 名单文件。", true);
        return;
      }
      setTuoRosterUploadStatus("正在上传：" + file.name + "。", false);
      try {
        const previousScopeId = $("tuoRosterScopeId")?.value || "";
        let nextScopeId = "";
        const result = await postJson("/api/tuo-roster/upload", {
          fileName: file.name,
          contentBase64: await fileToBase64(file)
        });
        if (!result.ok) throw new Error(result.error || "上传失败。");
        if (previousScopeId) {
          const identityDecision = await openConsoleAction({
            title: "确认托名单身份",
            note: "增删账号、修改备注、调整顺序或移动文件，应继续原名单；明确换成另一套业务名单，才建立新范围。",
            message: "刚上传的是当前托名单的修改版吗？",
            confirmText: "继续原名单",
            extraText: "这是新业务名单",
            cancelText: "取消使用"
          });
          if (identityDecision.action === "cancel") {
            setTuoRosterUploadStatus("已取消使用刚上传的名单，当前名单未改变。", false);
            return;
          }
          nextScopeId = identityDecision.action === "confirm" ? previousScopeId : "";
        }
        $("tuoRosterPath").value = result.filePath || "";
        $("tuoRosterScopeId").value = nextScopeId;
        activeTuoRosterPath = $("tuoRosterPath").value;
        clearPreciseRosterRequired();
        setTuoRosterUploadStatus("已上传：" + (result.fileName || file.name) + "。", false);
        $("saveState").textContent = "已上传托名单：" + (result.fileName || file.name) + "。";
        renderTuoRosterManager();
        await postJson("/api/settings", { settings: readSettings() }).catch(() => null);
      } catch (error) {
        setTuoRosterUploadStatus("上传托名单失败：" + (error?.message || error), true);
      } finally {
        $("tuoRosterFileInput").value = "";
      }
    }

    function fileToBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const bytes = new Uint8Array(reader.result || new ArrayBuffer(0));
          let binary = "";
          const chunkSize = 0x8000;
          for (let index = 0; index < bytes.length; index += chunkSize) {
            binary += String.fromCharCode(...bytes.slice(index, index + chunkSize));
          }
          resolve(btoa(binary));
        };
        reader.onerror = () => reject(reader.error || new Error("读取文件失败。"));
        reader.readAsArrayBuffer(file);
      });
    }

    function updateTuoRosterUploadDisplay() {
      const filePath = $("tuoRosterPath")?.value || "";
      if (!filePath) {
        activeTuoRosterPath = "";
        setTuoRosterUploadStatus("尚未上传名单。", false);
        return;
      }
      activeTuoRosterPath = filePath;
      clearPreciseRosterRequired();
      const fileName = fileNameFromPath(filePath);
      const libraryItem = currentTuoRosterLibraryItem(filePath);
      if (libraryItem?.name) {
        setTuoRosterUploadStatus("已选择：" + libraryItem.name + "\\n文件：" + fileName, false);
      } else {
        setTuoRosterUploadStatus("已选择：" + fileName + "。", false);
      }
      renderTuoRosterManager();
    }

    function setTuoRosterUploadStatus(message, error) {
      $("tuoRosterUploadStatus").textContent = message;
      $("tuoRosterUploadStatus").classList.toggle("roster-upload-error", Boolean(error));
    }

    function ensurePreciseRosterBeforeGenerate() {
      if ($("robotStrategy")?.value !== "precise") {
        clearPreciseRosterRequired();
        return true;
      }
      if (String($("tuoRosterPath")?.value || "").trim()) {
        clearPreciseRosterRequired();
        return true;
      }
      markPreciseRosterRequired("请先上传或选择托人设名单");
      return false;
    }

    function markPreciseRosterRequired(message) {
      $("preciseTuoConfig").style.display = "block";
      $("preciseTuoRosterConfig").style.display = "block";
      $("tuoRosterDropZone").classList.add("is-required");
      setTuoRosterUploadStatus(message || "请先上传或选择托人设名单", true);
      $("saveState").textContent = message || "请先上传或选择托人设名单";
      $("tuoRosterDropZone").scrollIntoView({ behavior: "smooth", block: "center" });
    }

    function clearPreciseRosterRequired() {
      $("tuoRosterDropZone")?.classList.remove("is-required");
    }

    function applySelectedIntervalPreset() {
      const id = $("intervalPresetSelect").value;
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "请先选择一个已保存的间隔方案。";
        return;
      }
      const intervals = preset.intervals || {};
      for (const key of visibleIntervalFields) {
        if ($(key)) $(key).value = intervals[key] === undefined ? "" : String(intervals[key] || "");
      }
      if ($("mediaMin")) $("mediaMin").value = "";
      if ($("mediaMax")) $("mediaMax").value = "";
      $("saveState").textContent = "已应用间隔方案：" + (preset.name || "未命名方案") + "。";
    }

    async function saveCurrentIntervalPreset() {
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      const intervals = readVisibleIntervalValues();
      if (!hasVisibleIntervalValues(intervals)) {
        $("saveState").textContent = "请先填写至少一组自定义间隔，再保存为方案。";
        return;
      }
      const defaultName = defaultIntervalPresetName(intervals);
      const name = prompt("方案名称", defaultName);
      if (name === null) return;
      try {
        const result = await postJson("/api/interval-presets/save", { preset: { name, intervals } });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(result.preset?.id || "");
        $("saveState").textContent = "已保存间隔方案：" + (result.preset?.name || name || defaultName) + "。";
      } catch (error) {
        $("saveState").textContent = "保存间隔方案失败：" + (error?.message || error);
      }
    }

    async function renameIntervalPreset(id, name) {
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "没有找到这个间隔方案。";
        return;
      }
      try {
        const result = await postJson("/api/interval-presets/save", {
          preset: { id, name, intervals: preset.intervals || {} }
        });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(id);
        $("saveState").textContent = "已保存方案名称。";
      } catch (error) {
        $("saveState").textContent = "保存方案名称失败：" + (error?.message || error);
      }
    }

    async function updateIntervalPresetFromCurrent(id, name) {
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      const intervals = readVisibleIntervalValues();
      if (!hasVisibleIntervalValues(intervals)) {
        $("saveState").textContent = "请先填写至少一组自定义间隔，再更新方案。";
        return;
      }
      try {
        const result = await postJson("/api/interval-presets/save", {
          preset: { id, name, intervals }
        });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(id);
        $("saveState").textContent = "已用当前填写更新方案：" + (result.preset?.name || name || "未命名方案") + "。";
      } catch (error) {
        $("saveState").textContent = "更新间隔方案失败：" + (error?.message || error);
      }
    }

    async function deleteIntervalPresetById(id) {
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "没有找到这个间隔方案。";
        return;
      }
      if (!confirm("确认删除间隔方案“" + (preset.name || "未命名方案") + "”？当前输入框内容不会被清空。")) return;
      try {
        const result = await postJson("/api/interval-presets/delete", { id });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions();
        $("saveState").textContent = "已删除间隔方案。";
      } catch (error) {
        $("saveState").textContent = "删除间隔方案失败：" + (error?.message || error);
      }
    }

    function clearCustomIntervals() {
      for (const key of ["sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"]) {
        if ($(key)) $(key).value = "";
      }
      $("saveState").textContent = "已清空，将使用默认间隔规则";
    }

    function validateIntervalInputs() {
      if ($("scheduleMode").value === "doc") return "";
      const groups = [
        ["differentTuoMin", "differentTuoMax"],
        ["sameTuoMin", "sameTuoMax"],
        ["doumaSameMin", "doumaSameMax"],
        ["roleSwitchMin", "roleSwitchMax"]
      ];
      for (const [minId, maxId] of groups) {
        const min = String($(minId)?.value || "").trim();
        const max = String($(maxId)?.value || "").trim();
        if (!min && !max) continue;
        if (!min || !max) return "自定义间隔的最短和最长要么都填，要么都不填。";
        if (!/^\\d+$/.test(min) || !/^\\d+$/.test(max) || Number(min) <= 0 || Number(max) <= 0) return "自定义间隔只能填写正整数秒数。";
        if (Number(min) > Number(max)) return "自定义间隔的最短不能大于最长。";
      }
      return "";
    }

    async function sendControl(action) {
      const label = controlActionLabel(action);
      manualStatusFeedbackUntil = Date.now() + 5000;
      $("saveState").textContent = "已提交" + label + "，正在等待后台响应。";
      setControlButtonsBusy(true);
      try {
        const result = await postJsonResult("/api/control", { action });
        if (!result.ok) throw new Error(result.error || result.message || (label + "失败。"));
        if (result.message) $("saveState").textContent = result.message;
        await refreshStatus({ manual: true });
        if (result.message) {
          manualStatusFeedbackUntil = Date.now() + 5000;
          $("saveState").textContent = result.message;
        }
      } catch (error) {
        manualStatusFeedbackUntil = Date.now() + 5000;
        $("saveState").textContent = label + "失败：" + (error?.message || error);
        await refreshStatus({ manual: true }).catch(() => {});
      } finally {
        setControlButtonsBusy(false);
      }
    }

    async function openPreviewToEditFailedTask() {
      manualStatusFeedbackUntil = Date.now() + 15000;
      setControlButtonsBusy(true);
      $("saveState").textContent = "正在安全退出当前创建，并开放本轮预览修改。";
      try {
        const result = await postJson("/api/preview/edit-after-error", {}, 20000);
        if (!result.ok || !result.previewUrl) throw new Error(result.error || "没有可打开的预览页。");
        location.href = result.previewUrl;
      } catch (error) {
        $("saveState").textContent = "返回预览修改失败：" + (error?.message || error);
        await refreshStatus({ manual: true }).catch(() => {});
        setControlButtonsBusy(false);
      }
    }

    async function openExpiredScheduleEditor() {
      manualStatusFeedbackUntil = Date.now() + 15000;
      setControlButtonsBusy(true);
      $("saveState").textContent = "正在打开续排页面；已成功任务不会改动。";
      try {
        const result = await postJson("/api/preview/edit-expired-schedule", {}, 20000);
        if (!result.ok || !result.previewUrl) throw new Error(result.error || "没有可打开的续排页面。");
        location.href = result.previewUrl;
      } catch (error) {
        $("saveState").textContent = "打开续排页面失败：" + (error?.message || error);
        await refreshStatus({ manual: true }).catch(() => {});
        setControlButtonsBusy(false);
      }
    }

    function setControlButtonsBusy(busy) {
      if (!busy) {
        updateTaskErrorDecisionPanel(latestStatus);
        setButtons(latestStatus?.status || "ready");
        return;
      }
      for (const id of ["retryCurrentTaskBtn", "editFailedTaskPreviewBtn", "skipCurrentTaskBtn", "stopCurrentRunBtn", "expiredScheduleDirectBtn", "expiredScheduleEditBtn", "expiredScheduleStopBtn", "pauseBtn", "resumeBtn", "stopBtn"]) {
        const button = $(id);
        if (button) button.disabled = true;
      }
    }

    function controlActionLabel(action) {
      if (action === "pause") return "暂停";
      if (action === "resume") return "继续";
      if (action === "resume_from_index") return "继续创建";
      if (action === "expired_schedule_direct") return "直接顺延";
      if (action === "retry_current") return "重试这一条";
      if (action === "skip_current") return "跳过这一条";
      if (action === "stop") return "停止本轮";
      return "控制操作";
    }

    async function fetchJson(url) {
      const response = await fetchWithTimeout(url, {}, 15000);
      const data = await response.json().catch(() => ({ ok: false, error: "后台接口返回内容不是 JSON。" }));
      if (!response.ok || data?.ok === false) throw new Error(data?.error || data?.message || ("后台接口返回失败：" + response.status));
      return data;
    }

    async function fetchWithTimeout(url, options, timeoutMs) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        return await fetch(url, { ...options, signal: controller.signal });
      } catch (error) {
        if (error?.name === "AbortError") throw Object.assign(new Error("后台接口响应超时，正在核对后台受理状态。"), { code: "CLIENT_TIMEOUT", network: true });
        throw Object.assign(error instanceof Error ? error : new Error(String(error)), { network: true });
      } finally {
        clearTimeout(timer);
      }
    }

    async function postJson(url, body, timeoutMs = 15000) {
      const response = await fetchWithTimeout(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      }, timeoutMs);
      let data;
      try {
        data = await response.json();
      } catch {
        throw Object.assign(new Error("后台接口返回内容不是 JSON，当前操作结果需要核对。"), { code: "CLIENT_NON_JSON", status: response.status, responseReceived: true });
      }
      if (!response.ok || data?.ok === false) {
        throw Object.assign(new Error(data?.error || data?.message || ("后台接口返回失败：" + response.status)), {
          code: data?.code || "HTTP_" + response.status,
          status: response.status,
          data,
          responseReceived: true
        });
      }
      return data;
    }

    async function postJsonResult(url, body) {
      const response = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await response.json().catch(() => ({ ok: false, error: "后台接口返回内容不是 JSON。" }));
      if (!response.ok) return { ok: false, status: response.status, ...data };
      return data;
    }
  </script>
</body>
</html>`;
}

async function readJsonBody(req, options = {}) {
  let body = "";
  const limitBytes = Number(options.limitBytes || 5 * 1024 * 1024);
  for await (const chunk of req) {
    body += chunk;
    if (Buffer.byteLength(body, "utf8") > limitBytes) {
      const error = new Error("请求内容太大。");
      error.statusCode = 413;
      throw error;
    }
  }
  if (!body.trim()) return {};
  return JSON.parse(body);
}

function writeNdjson(res, value) {
  if (!res.destroyed && !res.writableEnded) res.write(`${JSON.stringify(value)}\n`);
}

async function receiveSharedPackageFile(projectRoot, instanceId, req, fileName) {
  if (!/\.json$/i.test(fileName)) {
    const error = new Error("导入失败：共享包只支持 .json 文件。");
    error.statusCode = 400;
    throw error;
  }
  const contentType = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
  if (contentType !== "application/octet-stream") {
    const error = new Error("导入失败：文件上传类型无效。");
    error.statusCode = 415;
    throw error;
  }
  const maxBytes = 250 * 1024 * 1024;
  const declared = Number(req.headers["content-length"] || 0);
  if (!Number.isSafeInteger(declared) || declared <= 0 || declared > maxBytes) {
    const error = new Error(declared > maxBytes ? "导入失败：共享包超过 250MiB 上限。" : "导入失败：无法确认文件大小。");
    error.statusCode = 413;
    throw error;
  }
  const safeInstance = String(instanceId || "default").replace(/[^A-Za-z0-9_.-]/g, "_").slice(0, 64) || "default";
  const dir = path.join(projectRoot, "data", "shared-package-transfers", safeInstance, `import-${randomUUID()}`);
  await fs.mkdir(dir, { recursive: true });
  const filePath = path.join(dir, "package.json.part");
  let output;
  let received = 0;
  try {
    const disk = await fs.statfs(dir).catch(() => null);
    if (disk) {
      const available = Number(disk.bavail) * Number(disk.bsize);
      if (Number.isFinite(available) && available < declared + 32 * 1024 * 1024) throw Object.assign(new Error("磁盘剩余空间不足，无法导入共享包。"), { code: "ENOSPC" });
    }
    output = await fs.open(filePath, "wx");
    for await (const chunk of req) {
      received += chunk.length;
      if (received > maxBytes || received > declared) throw new Error("导入失败：实际文件大小与声明不符。");
      await output.write(chunk);
    }
    if (received !== declared) throw new Error(`导入失败：文件未完整接收，应收 ${declared} 字节，实收 ${received} 字节。`);
    await output.sync();
    await output.close();
    output = null;
    return { dir, filePath, bytes: received };
  } catch (error) {
    await output?.close().catch(() => {});
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
    if (error?.code === "ENOSPC") throw new Error("磁盘剩余空间不足，共享包未导入。");
    throw error;
  }
}

async function saveUploadedTuoRoster(projectRoot, body = {}) {
  const originalName = String(body.fileName || "").trim();
  const ext = path.extname(originalName).toLowerCase();
  if (![".xlsx", ".csv", ".json"].includes(ext)) {
    throw new Error("托名单只支持 XLSX、CSV、JSON 文件。");
  }
  const contentBase64 = String(body.contentBase64 || "").replace(/^data:[^,]+,/, "");
  if (!contentBase64) throw new Error("上传的托名单内容为空。");
  const buffer = Buffer.from(contentBase64, "base64");
  if (!buffer.length) throw new Error("上传的托名单内容为空。");
  if (buffer.length > 20 * 1024 * 1024) throw new Error("托名单文件不能超过 20MB。");
  const uploadDir = path.join(projectRoot, "data", "tuo-rosters");
  await fs.mkdir(uploadDir, { recursive: true });
  const baseName = sanitizeUploadFileBase(path.basename(originalName, ext)) || "tuo-roster";
  const fileName = `${timestampForFile()}-${baseName}${ext}`;
  const filePath = path.join(uploadDir, fileName);
  await fs.writeFile(filePath, buffer);
  return {
    fileName,
    originalName,
    filePath,
    size: buffer.length
  };
}

function sanitizeUploadFileBase(value) {
  return String(value || "")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
    .replace(/\s+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 80);
}

function timestampForFile() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate()),
    "-",
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

function isWorkflowBusy(state) {
  const status = state.snapshot().status;
  return status === "running" || status === "paused";
}

function isClearableStaleConsoleState(snapshot = {}) {
  if (snapshot.status === "running" || snapshot.control === "running") return false;
  if (snapshot.status === "completed") return false;
  return ["failed", "stopped", "paused", "waiting"].includes(snapshot.status)
    || ["awaiting_error_action", "paused", "stopped"].includes(snapshot.control)
    || Boolean(snapshot.failureReason);
}

function resetTerminalConsoleStateOnOpen(state) {
  const status = state.snapshot().status;
  if (!["failed", "stopped", "disconnected"].includes(status)) return false;
  state.resetTerminalState?.("重新打开控制台：已清理上次失败/停止状态");
  return true;
}

function resetStartupConsoleStateOnOpen(state, workflow) {
  if (workflow?.isRunning?.()) return false;
  const snapshot = state.snapshot();
  if (snapshot.status === "ready" && snapshot.step === "idle" && !snapshot.failureReason && !snapshot.runDir) return false;
  state.resetForStartup?.("正式入口重新打开：已清理上次运行状态，预览文件仍可恢复");
  return true;
}

function applyControlAction(state, action, body = {}) {
  const before = state.snapshot();
  if (action === "pause") {
    if (before.status !== "running") return controlRejected(before, "当前没有正在运行的任务，不能暂停。");
    return controlAccepted(state.pause(), "已暂停。");
  }
  if (action === "resume") {
    if (before.control !== "awaiting_error_action" && before.status !== "paused") {
      return controlRejected(before, "当前没有暂停或等待人工处理的任务，不能继续。");
    }
    return controlAccepted(state.resume(), before.control === "awaiting_error_action" ? "已选择重试当前失败条。" : "已继续运行。");
  }
  if (action === "resume_from_index") {
    const targetIndex = Number(body.targetIndex || 0);
    if (!targetIndex || targetIndex < 1) return controlRejected(before, "没有选择有效的继续条目。", 400);
    if (before.status !== "paused" && before.control !== "paused") {
      return controlRejected(before, "当前不在普通暂停状态，不能选择从指定条目继续。");
    }
    return controlAccepted(state.resumeFromIndex(targetIndex), `已选择从第 ${targetIndex} 条继续。`);
  }
  if (action === "expired_schedule_direct") {
    if (before.control !== "awaiting_expired_schedule") {
      return controlRejected(before, "当前不在过期排程选择状态，不能直接顺延。", 409);
    }
    return controlAccepted(state.resumeExpiredScheduleDirect(), "已选择直接顺延，后台会从下一条未执行任务继续。");
  }
  if (action === "retry_current") {
    if (before.control !== "awaiting_error_action") {
      return controlRejected(before, controlUnavailableMessage(before, "重试这一条"));
    }
    return controlAccepted(state.retryCurrentTask("人工选择重试当前失败条"), "已选择重试当前失败条，后台正在处理。");
  }
  if (action === "skip_current") {
    if (before.control !== "awaiting_error_action") {
      return controlRejected(before, controlUnavailableMessage(before, "跳过这一条"));
    }
    return controlAccepted(state.skipCurrentTask("人工选择跳过当前失败条"), `已选择跳过第 ${before.currentIndex || "?"} 条，后台将继续下一条。`);
  }
  if (action === "stop") {
    if (!["running", "paused", "waiting"].includes(before.status) && !["awaiting_error_action", "paused"].includes(before.control)) {
      return controlRejected(before, "当前没有正在运行或等待处理的任务，不能停止。");
    }
    return controlAccepted(state.stop(), "已停止本轮。");
  }
  return { ok: false, statusCode: 400, error: "unknown control action", state: before };
}

function controlAccepted(snapshot, message) {
  return { ok: true, message, state: snapshot };
}

function controlRejected(snapshot, error, statusCode = 409) {
  return { ok: false, statusCode, error, state: snapshot };
}

function controlUnavailableMessage(snapshot = {}, actionLabel) {
  return [
    `当前不在“失败后等待人工处理”状态，不能${actionLabel}。`,
    `当前状态：${labelControlState(snapshot)}。`,
    "请先点“刷新运行状态”，如果后台已继续运行，等它再次停在失败处理面板后再操作。"
  ].join("");
}

function labelControlState(snapshot = {}) {
  const status = snapshot.status || "-";
  const control = snapshot.control || "-";
  const index = snapshot.currentIndex ? `第 ${snapshot.currentIndex} 条` : "未定位到具体条目";
  if (control === "awaiting_error_action") return `${index}正在等待人工处理`;
  if (status === "running" || control === "running") return `${index}正在运行`;
  if (status === "paused" || control === "paused") return `${index}已暂停`;
  if (status === "completed") return "本轮已完成";
  if (status === "failed") return "本轮已失败";
  if (status === "stopped" || control === "stopped") return "本轮已停止";
  return `${status}/${control}`;
}

function runIdFromRunDir(runDir = "") {
  const match = String(runDir || "").match(/(?:^|[\\/])(v2_(?:real_flow|library_work)_\d{8}_\d{6}[A-Za-z0-9_-]*)$/);
  return match ? match[1] : "";
}

function buildSupportReportPayload(input = {}, snapshot = {}, lastResult = null) {
  const text = (value, limit = 160) => String(value || "").replace(/\s+/g, " ").trim().slice(0, limit);
  const list = (value, maxItems, maxChars) => Array.isArray(value)
    ? value.slice(0, maxItems).map((item) => text(item, maxChars)).filter(Boolean)
    : [];
  const logs = list(input.logs?.length ? input.logs : (snapshot.logs || []).map((item) => item?.message || ""), 30, 260);
  return {
    stage: text(input.stage || snapshot.step || "控制台", 80),
    category: text(input.category || "console", 40),
    message: text(input.message || snapshot.failureReason || lastResult?.error || "控制台问题", 300),
    lastAction: text(input.lastAction || snapshot.waitingReason || snapshot.step || "", 120),
    runId: text(input.runId || runIdFromRunDir(snapshot.runDir), 96),
    previewName: text(input.previewName || "", 120),
    suggestions: list(input.suggestions, 8, 180),
    logs,
    userNote: text(input.userNote || "", 300)
  };
}

async function buildCmsConfigSnapshotAfterRefresh({ workflow, state, runDir, settings, name }) {
  await workflow.refreshCurrentCmsPageBindings?.({ runDir }).catch((error) => {
    state.log("云中客配置：保存前刷新当前页面选择失败，改用已有绑定记录。" + (error?.message ? ` 原因：${error.message}` : ""));
  });
  return buildCmsConfigSnapshot({ runDir, settings, name });
}

function sendWorkflowBusy(res, state) {
  sendJson(res, 409, {
    ok: false,
    error: "已有流程正在运行，请等当前流程结束。",
    state: state.snapshot()
  });
}

async function waitForWorkflowIdle(workflow, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  while (workflow?.isRunning?.() && Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
}

async function buildContinueCandidate(snapshot = {}) {
  const previewPath = snapshot.previewPath || (snapshot.runDir ? path.join(snapshot.runDir, "preview.json") : "");
  if (!previewPath) return { ok: false, error: "没有找到当前预览文件，不能判断从哪一条继续。" };
  const preview = await readJsonIfExists(previewPath);
  const tasks = normalizePreviewTasks(preview).map((task, index) => ({
    ...task,
    index: Number(task.index || index + 1)
  }));
  if (!tasks.length) return { ok: false, error: "预览文件里没有可创建任务。" };
  const lastCompletedIndex = deriveLastCompletedIndex(snapshot);
  const expectedIndex = Math.max(1, lastCompletedIndex + 1);
  const activeTasks = tasks
    .filter((task) => !task.skip)
    .sort((a, b) => Number(a.index || a.order || 0) - Number(b.index || b.order || 0));
  const current = activeTasks.find((task) => Number(task.index || 0) >= expectedIndex) || activeTasks[0];
  if (!current) return { ok: false, error: "预览文件里没有待创建任务。" };
  const currentPosition = activeTasks.findIndex((task) => Number(task.index || 0) === Number(current.index || 0));
  const next = currentPosition >= 0 ? activeTasks[currentPosition + 1] : null;
  return {
    ok: true,
    lastCompletedIndex,
    current: summarizeContinueTask(current),
    next: next ? summarizeContinueTask(next) : null
  };
}

async function buildPreviousSuccessTuoCooldownCandidate(snapshot = {}) {
  const previewPath = snapshot.previewPath || (snapshot.runDir ? path.join(snapshot.runDir, "preview.json") : "");
  const lastCompletedIndex = deriveLastCompletedIndex(snapshot);
  if (!previewPath || !lastCompletedIndex) {
    return { available: false, nicknames: [], lastCompletedIndex: 0 };
  }
  const preview = await readJsonIfExists(previewPath);
  const tasks = normalizePreviewTasks(preview).map((task, index) => ({
    ...task,
    index: Number(task.index || index + 1)
  }));
  const seen = new Set();
  const nicknames = [];
  for (const task of tasks) {
    if (task.skip || task.role !== "tuo" || Number(task.index || 0) > lastCompletedIndex) continue;
    const name = String(task?.tuoAssignment?.primary?.nickname || task.speaker || task.cleanSpeaker || "").trim();
    const key = name.replace(/\s+/g, "");
    if (!name || seen.has(key)) continue;
    seen.add(key);
    nicknames.push(name);
  }
  return {
    available: nicknames.length > 0,
    nicknames,
    lastCompletedIndex,
    runName: snapshot.runDir ? path.basename(snapshot.runDir) : "",
    previewPath
  };
}

function normalizePreviewTasks(preview) {
  if (Array.isArray(preview)) return preview;
  if (Array.isArray(preview?.tasks)) return preview.tasks;
  if (Array.isArray(preview?.preview)) return preview.preview;
  return [];
}

function deriveLastCompletedIndex(snapshot = {}) {
  const direct = Number(snapshot.lastCompletedIndex || 0);
  if (direct > 0) return direct;
  const logs = Array.isArray(snapshot.logs) ? snapshot.logs : [];
  for (let i = logs.length - 1; i >= 0; i -= 1) {
    const message = String(logs[i]?.message || "");
    const byPreviewIndex = message.match(/第\s*(\d+)\s*条创建成功/);
    if (byPreviewIndex) return Number(byPreviewIndex[1]);
    const byOldPlanIndex = message.match(/创建成功：\s*(\d+)\s*\//);
    if (byOldPlanIndex) return Number(byOldPlanIndex[1]);
  }
  return 0;
}

function summarizeContinueTask(task = {}) {
  return {
    index: Number(task.index || 0),
    date: task.date || "",
    time: task.time || "",
    role: task.role || "",
    roleLabel: task.role === "douma" ? "豆妈" : task.role === "tuo" ? "托" : task.role || "",
    speaker: task.speaker || task.cleanSpeaker || "",
    type: task.type || "",
    summary: summarizeTaskContent(task)
  };
}

function summarizeTaskContent(task = {}) {
  if (task.type === "text" || task.type === "finder") return compactText(task.text || task.sourceText || "");
  const media = task.mediaPath || task.materialPath || task.localPath || task.path || "";
  return media ? path.basename(String(media)) : compactText(task.text || task.sourceText || "");
}

function compactText(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (text.length <= 80) return text;
  return `${text.slice(0, 80)}...`;
}

function backupOptions(body = {}) {
  return {
    name: body.name,
    backupRoot: body.backupRoot
  };
}

function versionActionOptions(body = {}) {
  return {
    ...backupOptions(body),
    backupName: body.backupName,
    installCommand: body.installCommand,
    installArgs: body.installArgs,
    checkCommand: body.checkCommand,
    checkArgs: body.checkArgs
  };
}

function pickLicenseOptions(options = {}) {
  return {
    fetch: options.licenseFetch,
    licenseConfig: options.licenseConfig,
    appVersion: options.appVersion,
    sharedLicenseCacheRoot: options.sharedLicenseCacheRoot,
    sharedLicenseLockWaitMs: options.sharedLicenseLockWaitMs,
    sharedLicenseLockStaleMs: options.sharedLicenseLockStaleMs,
    sharedLicenseRefreshBeforeMs: options.sharedLicenseRefreshBeforeMs,
    sharedLicenseRefreshJitterMs: options.sharedLicenseRefreshJitterMs
  };
}

function startLicenseHeartbeat(projectRoot, options = {}) {
  const intervalMs = Number.isFinite(Number(options.intervalMs)) ? Math.max(5000, Number(options.intervalMs)) : 60000;
  const initialDelayMs = Number.isFinite(Number(options.initialDelayMs)) ? Math.max(0, Number(options.initialDelayMs)) : 2000;
  let stopped = false;
  let inFlight = false;
  let timer = null;
  const beat = async () => {
    if (stopped || inFlight) return;
    inFlight = true;
    try {
      const version = options.versionStatusProvider
        ? await options.versionStatusProvider()
        : await getVersionStatus(projectRoot).catch((error) => ({ status: "failed", error: error?.message || String(error) }));
      const diagnostic = options.diagnosticProvider ? options.diagnosticProvider() : null;
      const operator = options.operatorProvider ? options.operatorProvider() : null;
      await submitLicenseHeartbeat(projectRoot, {
        ...options.licenseOptions,
        ...(operator || {}),
        updateStatus: summarizeHeartbeatVersion(version),
        monitorStatus: summarizeHeartbeatMonitor(options.stateProvider?.()),
        diagnostic
      }).catch(() => {});
      if (Array.isArray(options.licenseOptions?.licenseConfig?.licenseSigningKeys)
        && options.licenseOptions.licenseConfig.licenseSigningKeys.length) {
        await getLicenseStatus(projectRoot, { ...options.licenseOptions, action: "launch" }).catch(() => {});
      }
    } finally {
      inFlight = false;
      if (!stopped) timer = setTimeout(beat, intervalMs);
    }
  };
  timer = setTimeout(beat, initialDelayMs);
  return () => {
    stopped = true;
    if (timer) clearTimeout(timer);
  };
}

function summarizeHeartbeatVersion(version = {}) {
  return {
    currentVersion: version.currentVersion || "",
    latestVersion: version.latestRemoteVersion || "",
    updateAvailable: version.updateAvailable === true,
    pendingUpdateReady: version.pendingUpdateReady === true,
    updateMode: version.updateMode || "",
    status: version.error ? "failed" : "ok"
  };
}

function summarizeHeartbeatMonitor(snapshot = {}) {
  const runDir = String(snapshot.runDir || "");
  return {
    status: snapshot.status || "ready",
    step: snapshot.step || "idle",
    waitingReason: snapshot.waitingReason || snapshot.failureReason || "",
    runId: runDir ? path.basename(runDir) : "",
    currentIndex: snapshot.currentIndex || snapshot.lastCompletedIndex || 0,
    totalCount: snapshot.totalCount || 0,
    successCount: snapshot.successCount || 0,
    failureCount: snapshot.failureCount || 0,
    updatedAt: snapshot.updatedAt || ""
  };
}

function installConsoleProcessGuards({ state, setLastResult } = {}) {
  const recordRecoverable = (error, source) => {
    const message = [
      "浏览器弹窗处理异常已忽略，后台服务已保持运行。",
      "原因：弹窗出现后又被页面关闭，Playwright 收到 No dialog is showing。",
      "如果当前条随后失败，可在控制台选择重试或跳过。"
    ].join(" ");
    setLastResult?.({ ok: false, error: message, source });
    state?.log?.(`后台保护：${message}`, {
      source,
      rawError: error?.message || String(error || "")
    });
    const snapshot = state?.snapshot?.() || {};
    if (["running", "paused", "waiting"].includes(snapshot.status)) {
      state.update({
        waitingReason: snapshot.waitingReason || "后台已忽略一次浏览器弹窗异常，流程仍在继续。"
      });
    }
  };

  const onUnhandledRejection = (reason) => {
    if (isRecoverableBrowserDialogError(reason)) {
      recordRecoverable(reason, "unhandledRejection");
      return;
    }
    process.removeListener("unhandledRejection", onUnhandledRejection);
    setImmediate(() => {
      throw reason instanceof Error ? reason : new Error(String(reason));
    });
  };

  const onUncaughtException = (error) => {
    if (isRecoverableBrowserDialogError(error)) {
      recordRecoverable(error, "uncaughtException");
      return;
    }
    process.removeListener("uncaughtException", onUncaughtException);
    throw error;
  };

  process.on("unhandledRejection", onUnhandledRejection);
  process.on("uncaughtException", onUncaughtException);
  return () => {
    process.removeListener("unhandledRejection", onUnhandledRejection);
    process.removeListener("uncaughtException", onUncaughtException);
  };
}

export function isRecoverableBrowserDialogError(error) {
  const message = error?.message || String(error || "");
  return /Page\.handleJavaScriptDialog/i.test(message) && /No dialog is showing/i.test(message);
}

function scheduleConsoleRestart(projectRoot, closeServer, instanceConfig = {}) {
  setTimeout(() => {
    const scriptPath = path.join(projectRoot, "src", "v2", "tools", "launch-console-hidden.ps1");
    const args = [
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      scriptPath,
      "-ProjectRoot",
      projectRoot,
      "-Port",
      String(instanceConfig?.port || 62230),
      "-WaitForPortClosed"
    ];
    if (instanceConfig?.enabled && instanceConfig.id) {
      args.push("-Instance", instanceConfig.id);
    }
    const child = spawn("powershell.exe", args, {
      cwd: projectRoot,
      detached: true,
      stdio: "ignore",
      windowsHide: true
    });
    child.unref();
    closeServer().catch(() => {});
  }, 500);
}

function sendJson(res, status, data) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function normalizeCmsStartRequestId(value) {
  const text = String(value || "").trim();
  return /^[a-f0-9-]{16,64}$/i.test(text) ? text : "";
}

function cmsStartRequestPath(runDir) {
  return runDir ? path.join(runDir, "cms-start-request.json") : "";
}

async function readCmsStartRequest(runDir) {
  const file = cmsStartRequestPath(runDir);
  if (!file) return null;
  try {
    const raw = await fs.readFile(file, "utf8");
    if (raw.length > 32 * 1024) return null;
    const value = JSON.parse(raw);
    return value && value.version === 1 && normalizeCmsStartRequestId(value.requestId) ? value : null;
  } catch {
    return null;
  }
}

async function writeCmsStartRequest(runDir, value) {
  const file = cmsStartRequestPath(runDir);
  if (!file) return;
  const stat = await fs.stat(runDir).catch(() => null);
  if (!stat?.isDirectory()) return;
  const temp = `${file}.${process.pid}.${randomUUID()}.tmp`;
  await fs.writeFile(temp, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await fs.rename(temp, file);
}

async function updateCmsStartRequest(runDir, current, updates = {}) {
  const next = { ...current, ...updates, updatedAt: new Date().toISOString() };
  await writeCmsStartRequest(runDir, next);
  return next;
}

async function acquireKeyedAdmission(queues, key) {
  const previous = queues.get(key) || Promise.resolve();
  let releaseCurrent;
  const current = new Promise((resolve) => { releaseCurrent = resolve; });
  queues.set(key, current);
  await previous.catch(() => {});
  let released = false;
  return () => {
    if (released) return;
    released = true;
    releaseCurrent();
    if (queues.get(key) === current) queues.delete(key);
  };
}

async function reconcileCmsStartRequestRecord({
  runDir, record, workflow, snapshot = {}, launchSessionId = "", activeAcceptance = null
} = {}) {
  if (!record || !["received", "checking", "accepted", "running"].includes(record.status)) return record;
  const recordRunId = String(record.runId || "");
  const currentRunId = snapshot.runDir ? path.basename(snapshot.runDir) : "";
  const sameProcessGeneration = Boolean(record.launchSessionId) && record.launchSessionId === launchSessionId;
  const activelyAccepting = sameProcessGeneration && recordRunId === currentRunId
    && activeAcceptance?.requestId === record.requestId
    && activeAcceptance?.runId === recordRunId
    && activeAcceptance?.launchSessionId === launchSessionId;
  if (activelyAccepting) return record;
  const activelyRunning = sameProcessGeneration && recordRunId === currentRunId
    && workflow.isRunning?.() && workflow.isCmsExecutionLocked?.();
  if (activelyRunning) return record;

  if (["received", "checking"].includes(record.status) && !record.acceptedAt) {
    return updateCmsStartRequest(runDir, record, {
      status: "rejected",
      stage: "启动前流程已结束",
      code: "CMS_START_ENDED_BEFORE_ACCEPT",
      message: "该请求在正式受理前已结束，没有启动 CMS 创建；可以重新点击开始创建。",
      finishedAt: new Date().toISOString(),
      reconciledLaunchSessionId: launchSessionId
    });
  }

  return updateCmsStartRequest(runDir, record, {
    status: "unknown",
    stage: "遗留请求待人工核对",
    code: "CMS_START_RESULT_UNKNOWN",
    message: "该请求曾被受理，但不属于当前仍在运行的后台流程，无法确认是否已提交。请先核对 CMS 队列；确认未创建后再人工结算，系统不会自动重提。",
    reconciledAt: new Date().toISOString(),
    reconciledLaunchSessionId: launchSessionId
  });
}

function cmsStartRequestHttpStatus(record = {}) {
  if (record.status === "rejected") return record.code === "WORKFLOW_BUSY" || record.code === "CMS_START_REQUEST_ACTIVE" ? 409 : 403;
  if (["failed", "unknown"].includes(record.status)) return 409;
  return ["received", "checking", "accepted", "running"].includes(record.status) ? 202 : 200;
}

function cmsStartStatusLabel(status) {
  return ({ received: "已收到", checking: "正在检查", accepted: "已受理", running: "运行中", waiting_login: "等待登录", unknown: "结果待确认" })[status] || status || "未知";
}

function isUnknownCmsStartResult(value = {}) {
  return /UNKNOWN|RESULT_UNKNOWN|ACTION_NOT_DRAINED/.test(String(value?.code || ""))
    || /结果未知|待确认|无法确认是否/.test(String(value?.error || value?.message || ""));
}

function sendHtml(res, html) {
  res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  res.end(html);
}

async function openControlledConsole(projectRoot, url, instanceConfig = {}) {
  const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
  await ensureV2ControlledBrowser({
    projectRoot,
    config,
    url,
    port: instanceConfig.cmsDebugPort,
    profileDir: instanceConfig.profileDir,
    runsDir: instanceConfig.runsDir,
    instanceId: instanceConfig.id || "",
    bringToFront: false
  });
}

function escapeHtmlText(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function withControlledFlag(url) {
  const parsed = new URL(url);
  parsed.searchParams.set("controlled", "1");
  return parsed.toString();
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function buildConsoleServiceInfo(projectRoot, instanceConfig = {}) {
  return {
    protocol: "v2-console-service-v2-license",
    projectRoot: path.resolve(projectRoot),
    instanceId: instanceConfig?.id || "",
    instanceLabel: instanceConfig?.label || "默认",
    consolePort: instanceConfig?.port || "",
    runsDir: instanceConfig?.runsDir || path.join(projectRoot, "runs"),
    profileDir: instanceConfig?.profileDir || "",
    cmsDebugPort: instanceConfig?.cmsDebugPort || "",
    codeRevision: await readGitRevision(projectRoot),
    startedAt: new Date().toISOString()
  };
}

async function readGitRevision(projectRoot) {
  try {
    const gitDir = path.join(projectRoot, ".git");
    const head = String(await fs.readFile(path.join(gitDir, "HEAD"), "utf8")).trim();
    if (head.startsWith("ref:")) {
      const refPath = head.slice(5).trim().replace(/\//g, path.sep);
      return String(await fs.readFile(path.join(gitDir, refPath), "utf8")).trim();
    }
    return head;
  } catch {
    return "";
  }
}

import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import dns from "node:dns/promises";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { TRUSTED_LICENSE_SERVERS, LICENSE_COMPANY_ID } from "./license-policy.js";
import { resolveSharedLicenseAuthorization } from "./shared-license-cache.js";
import { buildFeishuEnrollment, ensureDeviceProofKey } from "../feishu-api/device-proof-store.js";

const ACTION_LABELS = {
  launch: "启动程序",
  "generate-preview": "生成预览",
  "prepare-cms": "进入云中客设置",
  "start-cms": "正式发单",
  "cli-start-cms": "CLI 正式发单"
};
const MAX_BYTES = 4096;
const MAX_SHARED_RESPONSE_BYTES = 250 * 1024 * 1024;
const REQUEST_ACCESS_ACTION = "request-access";
const HEARTBEAT_ACTION = "heartbeat";
const USAGE_REPORT_ACTION = "usage-report";
const SUPPORT_REPORT_ACTION = "support-report";
const OPS_EVENT_ACTION = "ops-event";
const EMPLOYEE_DIRECTORY_ACTION = "employee-directory";
const OPERATOR_LOGIN_ACTION = "operator-login";

let deviceId;
export function getDeviceId() {
  if (deviceId) return deviceId;
  let identity = `${os.platform()}|${os.hostname().toLowerCase()}`;
  if (os.platform() === "win32") {
    identity = `windows|${readWindowsMachineGuid()}`;
  }
  deviceId = createHash("sha256").update(`miaoquan-device-v1|${identity}`).digest("hex");
  return deviceId;
}

function readWindowsMachineGuid() {
  const regArgs = ["query", "HKLM\\SOFTWARE\\Microsoft\\Cryptography", "/v", "MachineGuid"];
  for (const timeout of [3000, 8000]) {
    try {
      const output = execFileSync("reg.exe", regArgs, { encoding: "utf8", timeout, windowsHide: true });
      const match = output.match(/MachineGuid\s+REG_SZ\s+([0-9a-f-]+)/i);
      if (match) return match[1].toLowerCase();
    } catch {}
  }
  try {
    const ps = [
      "-NoProfile",
      "-ExecutionPolicy", "Bypass",
      "-Command",
      "(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Cryptography').MachineGuid"
    ];
    const output = execFileSync("powershell.exe", ps, { encoding: "utf8", timeout: 8000, windowsHide: true });
    const match = output.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    if (match) return match[0].toLowerCase();
  } catch {}
  throw new Error("无法读取本机设备标识，请联系管理员。");
}

function denied(message, state = "unauthorized") {
  return { enabled: true, allowed: false, state, company: "", expiresAt: "", message };
}
function safeMessage(body, fallback) {
  const value = body?.message || body?.reason;
  if (typeof value !== "string" || value.length > 160 || /[<>\r\n]/.test(value)) return fallback;
  return value.trim() || fallback;
}

export async function getLicenseStatus(projectRoot, options = {}) {
  const action = options.action || "launch";
  if (!Object.hasOwn(ACTION_LABELS, action)) return denied("授权操作不受支持。");
  let config, version;
  try {
    config = options.licenseConfig || JSON.parse(await fs.readFile(options.licensePath || path.join(projectRoot, "license.json"), "utf8"));
    version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  } catch {
    return denied("授权配置缺失或损坏，请联系管理员。", "not_configured");
  }
  if (!config || config.enabled !== true || config.mode !== "apisix-intranet" || config.companyId !== LICENSE_COMPANY_ID) {
    return denied("公司授权未正确配置，请联系管理员。", "not_configured");
  }
  let endpoint;
  try {
    endpoint = new URL(config.licenseServer);
    if (endpoint.protocol !== "https:" || endpoint.username || endpoint.password || endpoint.search || endpoint.hash
      || !TRUSTED_LICENSE_SERVERS.includes(endpoint.href)) throw new Error();
  } catch {
    return denied("授权服务地址未获批准，请联系管理员。", "not_configured");
  }
  if (typeof version !== "string" || !version.trim() || version.length > 32) return denied("程序版本信息无效。");
  const timeoutMs = Number(config.timeoutMs ?? 3000);
  if (!Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 3000) return denied("授权等待时间配置无效。");
  const controller = new AbortController();
  let timedOut = false;
  let timer;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(() => { timedOut = true; controller.abort(); reject(new Error("deadline")); }, timeoutMs);
  });
  const request = async () => resolveSharedLicenseAuthorization({
    companyId: LICENSE_COMPANY_ID,
    endpoint: endpoint.href,
    deviceId: getDeviceId(),
    action,
    appVersion: version,
    signingKeys: config.licenseSigningKeys,
    sharedLicenseCacheRoot: options.sharedLicenseCacheRoot || path.join(projectRoot, "data", "license-cache-v2"),
    lockWaitMs: options.sharedLicenseLockWaitMs,
    lockStaleMs: options.sharedLicenseLockStaleMs,
    refreshBeforeMs: options.sharedLicenseRefreshBeforeMs,
    refreshJitterMs: options.sharedLicenseRefreshJitterMs,
    maxCredentialTtlSeconds: config.maxCredentialTtlSeconds,
    forceRefresh: options.forceRefresh === true,
    now: options.now,
    fetchRemote: () => fetchRemoteLicenseDecision(endpoint, {
      fetch: options.fetch || globalThis.fetch,
      signal: controller.signal,
      payload: { companyId: LICENSE_COMPANY_ID, deviceId: getDeviceId(), appVersion: version, action },
      maxBytes: MAX_BYTES
    })
  });
  try {
    const status = await Promise.race([request(), deadline]);
    return { enabled: true, company: LICENSE_COMPANY_ID, ...status };
  } catch (error) {
    const message = timedOut
      ? "授权检查超时；若本机共享凭证仍有效可继续，否则请连接公司网络或 VPN 后重试。"
      : (error?.message || "无法确认公司授权，请检查公司网络或 VPN。");
    return denied(message, timedOut ? "timeout" : "unavailable");
  } finally {
    clearTimeout(timer);
    controller.abort();
  }
}

async function fetchRemoteLicenseDecision(endpoint, { fetch, signal, payload, maxBytes }) {
  let retryCount = 0;
  while (true) {
    let response;
    try {
      response = await fetch(endpoint, {
        method: "POST", redirect: "error", cache: "no-store", signal,
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(payload)
      });
    } catch (error) {
      return { kind: "unavailable", errorCode: signal.aborted ? "LICENSE_TIMEOUT" : "LICENSE_NETWORK_ERROR", message: signal.aborted ? "授权检查超时。" : "授权服务网络暂不可用。" };
    }
    let body;
    try {
      body = await readBoundedJsonResponse(response, maxBytes);
    } catch (error) {
      return { kind: "unavailable", errorCode: error.code || "LICENSE_RESPONSE_INVALID", message: error.message || "授权服务响应无效。" };
    }
    if (response.status === 429) {
      const retryAfterMs = parseRetryAfter(response.headers.get("retry-after"));
      if (retryCount++ === 0 && retryAfterMs >= 0 && retryAfterMs <= 1500) {
        try {
          await abortableDelay(retryAfterMs, signal);
          continue;
        } catch {
          return { kind: "unavailable", errorCode: "LICENSE_RATE_LIMITED", message: "授权服务当前繁忙，请稍后重试。" };
        }
      }
      return { kind: "unavailable", errorCode: "LICENSE_RATE_LIMITED", message: "授权服务当前繁忙，请稍后重试。" };
    }
    if (response.status >= 500) return { kind: "unavailable", errorCode: "LICENSE_SERVICE_ERROR", message: `授权服务暂不可用（HTTP ${response.status}）。` };
    if (response.status !== 200 || body.allowed !== true) {
      return { kind: "denied", code: typeof body.code === "string" ? body.code : "LICENSE_DENIED", message: safeMessage(body, "公司授权未通过，请联系管理员。") };
    }
    if (typeof body.credential === "string" && body.credential) return { kind: "signed", credential: body.credential };
    return { kind: "legacy_allowed", company: typeof body.company === "string" ? body.company.slice(0, 64) : "" };
  }
}

async function readBoundedJsonResponse(response, maxBytes) {
  if (Number(response.headers.get("content-length")) > maxBytes) throw Object.assign(new Error("授权服务响应过大。"), { code: "LICENSE_RESPONSE_TOO_LARGE" });
  const reader = response.body?.getReader();
  if (!reader) throw Object.assign(new Error("授权服务响应为空。"), { code: "LICENSE_RESPONSE_EMPTY" });
  let size = 0;
  const chunks = [];
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) throw Object.assign(new Error("授权服务响应过大。"), { code: "LICENSE_RESPONSE_TOO_LARGE" });
      chunks.push(Buffer.from(value));
    }
  } finally {
    void reader.cancel().catch(() => {});
  }
  try {
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("shape");
    return body;
  } catch {
    throw Object.assign(new Error(`授权服务返回非 JSON（HTTP ${response.status}）。`), { code: "LICENSE_NON_JSON_RESPONSE" });
  }
}

function parseRetryAfter(value) {
  if (value == null || value === "") return -1;
  if (/^\d+(?:\.\d+)?$/.test(value)) return Math.max(0, Math.round(Number(value) * 1000));
  const at = Date.parse(value);
  return Number.isFinite(at) ? Math.max(0, at - Date.now()) : -1;
}

function abortableDelay(ms, signal) {
  if (signal.aborted) return Promise.reject(new Error("aborted"));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(done, ms);
    function done() { signal.removeEventListener("abort", aborted); resolve(); }
    function aborted() { clearTimeout(timer); signal.removeEventListener("abort", aborted); reject(new Error("aborted")); }
    signal.addEventListener("abort", aborted, { once: true });
  });
}

export async function getLicenseDiagnostics(projectRoot, options = {}) {
  const diagnostics = {
    deviceId: "",
    computerName: os.hostname(),
    dns: { ok: false, expected: "10.6.1.250", addresses: [], message: "" },
    service: { ok: false, message: "" },
    license: null
  };
  try {
    diagnostics.deviceId = getDeviceId();
  } catch (error) {
    diagnostics.service.message = error?.message || "无法读取本机设备标识。";
    diagnostics.license = denied(diagnostics.service.message, "device_unavailable");
    return diagnostics;
  }
  try {
    const records = await dns.resolve4("api.qzmq.cn");
    diagnostics.dns.addresses = records;
    diagnostics.dns.ok = records.includes(diagnostics.dns.expected);
    diagnostics.dns.message = diagnostics.dns.ok
      ? "授权域名解析正常。"
      : `授权域名解析异常，当前返回：${records.join(", ") || "-"}`;
  } catch {
    diagnostics.dns.message = "授权域名无法解析，请检查公司网络或 DNS。";
  }
  diagnostics.license = await getLicenseStatus(projectRoot, options);
  diagnostics.service.ok = !["unavailable", "timeout", "busy"].includes(diagnostics.license.state);
  diagnostics.service.message = diagnostics.license.state === "refresh_unavailable"
    ? "授权刷新暂不可用；有效凭证到期前仍可使用。"
    : diagnostics.license.shared && diagnostics.license.cached
      ? "已使用本机共享签名凭证，本次无需重复联网。"
      : diagnostics.service.ok ? "授权服务已响应。" : diagnostics.license.message;
  return diagnostics;
}

export async function submitLicenseRequest(projectRoot, options = {}) {
  const config = await readLicenseConfig(projectRoot, options);
  const endpoint = trustedEndpoint(config);
  const version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  const proofKey = await ensureDeviceProofKey({
    deviceId: getDeviceId(),
    proofKey: process.env.MIAOQUAN_DEVICE_PROOF_KEY || "",
    persistProvided: true,
    ...(options.deviceProofOptions || {})
  });
  const payload = {
    companyId: LICENSE_COMPANY_ID,
    deviceId: getDeviceId(),
    appVersion: version,
    action: REQUEST_ACCESS_ACTION,
    computerName: os.hostname(),
    ...buildFeishuEnrollment({
      companyId: LICENSE_COMPANY_ID,
      deviceId: getDeviceId(),
      appVersion: version,
      computerName: os.hostname(),
      proofKey,
      now: options.now ? options.now() : Date.now()
    })
  };
  const body = await postLicenseJson(endpoint, payload, Number(config.timeoutMs ?? 3000), options);
  return {
    ok: body.code === "REQUEST_RECORDED" || body.code === "ALREADY_ALLOWED",
    deviceId: payload.deviceId,
    message: safeMessage(body, "授权申请已提交。"),
    code: body.code || ""
  };
}

export async function submitLicenseHeartbeat(projectRoot, options = {}) {
  const config = await readLicenseConfig(projectRoot, options);
  const endpoint = trustedEndpoint(config);
  const version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  const payload = {
    companyId: LICENSE_COMPANY_ID,
    deviceId: getDeviceId(),
    appVersion: String(version || "").slice(0, 32),
    action: HEARTBEAT_ACTION,
    computerName: os.hostname(),
    instanceId: String(options.instanceId || "").slice(0, 64),
    operatorToken: String(options.operatorToken || "").slice(0, 2048),
    launchSessionId: String(options.launchSessionId || "").slice(0, 80),
    update: sanitizeHeartbeatUpdate(options.updateStatus || {}),
    monitor: sanitizeHeartbeatMonitor(options.monitorStatus || {}),
    diagnostic: sanitizeHeartbeatDiagnostic(options.diagnostic || {})
  };
  const body = await postLicenseJson(endpoint, payload, Number(config.timeoutMs ?? 3000), options);
  return {
    ok: body.code === "HEARTBEAT_RECORDED" || body.allowed === true,
    deviceId: payload.deviceId,
    message: safeMessage(body, "心跳已上报。"),
    code: body.code || ""
  };
}

export async function submitLicenseUsageReport(projectRoot, options = {}) {
  const config = await readLicenseConfig(projectRoot, options);
  const endpoint = trustedEndpoint(config);
  const version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  const payload = {
    companyId: LICENSE_COMPANY_ID,
    deviceId: getDeviceId(),
    appVersion: String(version || "").slice(0, 32),
    action: USAGE_REPORT_ACTION,
    computerName: os.hostname(),
    instanceId: String(options.instanceId || "").slice(0, 64),
    operatorToken: String(options.operatorToken || "").slice(0, 2048),
    launchSessionId: String(options.launchSessionId || "").slice(0, 80),
    clientEventId: String(options.clientEventId || "").slice(0, 128),
    usage: sanitizeUsageReport(options.usage || {})
  };
  const body = await postLicenseJson(endpoint, payload, Number(config.timeoutMs ?? 3000), options);
  return {
    ok: body.code === "USAGE_RECORDED" || body.allowed === true,
    deviceId: payload.deviceId,
    message: safeMessage(body, "使用记录已上报。"),
    code: body.code || ""
  };
}

export async function submitLicenseOpsEvent(projectRoot, options = {}) {
  const event = options.event && typeof options.event === "object" ? options.event : {};
  const body = await postLicenseServicePayload(projectRoot, {
    action: OPS_EVENT_ACTION,
    instanceId: String(options.instanceId || "").slice(0, 64),
    operatorToken: String(options.operatorToken || "").slice(0, 2048),
    event: {
      eventId: String(event.eventId || "").slice(0, 128),
      type: String(event.type || "").slice(0, 40),
      occurredAt: String(event.occurredAt || new Date().toISOString()).slice(0, 40),
      launchSessionId: String(event.launchSessionId || options.launchSessionId || "").slice(0, 80),
      runId: String(event.runId || "").slice(0, 96),
      status: String(event.status || "").slice(0, 24),
      source: String(event.source || "").slice(0, 32),
      stage: String(event.stage || "").slice(0, 80),
      reason: String(event.reason || "").slice(0, 240),
      plannedCount: Math.max(0, Number(event.plannedCount || 0)),
      successCount: Math.max(0, Number(event.successCount || 0)),
      failureCount: Math.max(0, Number(event.failureCount || 0)),
      documentName: String(event.documentName || "").slice(0, 160),
      readRange: String(event.readRange || "").slice(0, 160),
      sendDate: String(event.sendDate || "").slice(0, 32),
      timeMode: String(event.timeMode || "").slice(0, 80),
      tuoStrategy: String(event.tuoStrategy || "").slice(0, 80),
      targetGroup: String(event.targetGroup || "").slice(0, 120),
      requestId: String(event.requestId || "").slice(0, 128),
      snapshotVersion: String(event.snapshotVersion || "").slice(0, 128),
      unknownCount: Math.max(0, Number(event.unknownCount || 0)),
      skippedCount: Math.max(0, Number(event.skippedCount || 0)),
      taskItems: sanitizeOpsTaskItems(event.taskItems)
    }
  }, options);
  return { ok: body.code === "OPS_EVENT_RECORDED" || body.code === "OPS_EVENT_DUPLICATE", code: body.code || "" };
}

function sanitizeOpsTaskItems(items) {
  if (!Array.isArray(items)) return [];
  const text = (value, max) => typeof value === "string" ? value.slice(0, max) : "";
  return items.slice(0, 500).map((item = {}) => ({
    index: Math.max(0, Number(item.index || 0)),
    role: text(item.role, 32),
    actualAccount: text(item.actualAccount, 100),
    plannedAt: text(item.plannedAt, 40),
    contentSummary: text(item.contentSummary, 180),
    materialType: text(item.materialType, 32),
    result: text(item.result, 24),
    attempt: Math.max(0, Number(item.attempt || 0)),
    errorCode: text(item.errorCode, 80),
    reason: text(item.reason, 240),
    taskId: text(item.taskId, 128),
    requestId: text(item.requestId, 128)
  }));
}

export async function getLicenseEmployeeDirectory(projectRoot, options = {}) {
  const body = await postLicenseServicePayload(projectRoot, { action: EMPLOYEE_DIRECTORY_ACTION }, options);
  return { ok: body.code === "EMPLOYEE_DIRECTORY", employees: Array.isArray(body.employees) ? body.employees : [], code: body.code || "" };
}

export async function confirmLicenseOperator(projectRoot, employeeId, pin, options = {}) {
  const body = await postLicenseServicePayload(projectRoot, {
    action: OPERATOR_LOGIN_ACTION,
    instanceId: String(options.instanceId || "").slice(0, 64),
    employeeId: String(employeeId || "").slice(0, 64),
    pin: String(pin || "").slice(0, 24)
  }, options);
  return {
    ok: body.code === "OPERATOR_CONFIRMED",
    code: body.code || "",
    message: safeMessage(body, "当前员工已确认。"),
    operatorToken: typeof body.operatorToken === "string" ? body.operatorToken : "",
    employee: body.employee && typeof body.employee === "object" ? body.employee : null
  };
}

export async function submitLicenseSupportReport(projectRoot, options = {}) {
  const body = await postLicenseServicePayload(projectRoot, {
    action: SUPPORT_REPORT_ACTION,
    instanceId: String(options.instanceId || "").slice(0, 64),
    support: sanitizeSupportReport(options.support || {})
  }, {
    ...options,
    timeoutMs: options.timeoutMs ?? 30000,
    maxResponseBytes: MAX_BYTES
  });
  return {
    ok: body.code === "SUPPORT_RECORDED" || body.allowed === true,
    message: safeMessage(body, "问题已上报给管理员。"),
    code: body.code || "",
    reportId: typeof body.reportId === "string" ? body.reportId.slice(0, 80) : ""
  };
}

export async function postLicenseServicePayload(projectRoot, payload = {}, options = {}) {
  const config = await readLicenseConfig(projectRoot, options);
  const endpoint = trustedEndpoint(config);
  const version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  const timeoutMs = normalizeServiceTimeout(options.timeoutMs ?? config.sharedLibraryTimeoutMs ?? config.timeoutMs ?? 30000);
  const body = {
    ...payload,
    companyId: LICENSE_COMPANY_ID,
    deviceId: getDeviceId(),
    appVersion: String(version || "").slice(0, 32),
    computerName: os.hostname()
  };
  return postLicenseJson(endpoint, body, timeoutMs, {
    ...options,
    maxResponseBytes: options.maxResponseBytes ?? MAX_SHARED_RESPONSE_BYTES
  });
}

export async function downloadLicenseServicePayloadToFile(projectRoot, payload = {}, filePath, options = {}) {
  const config = await readLicenseConfig(projectRoot, options);
  const endpoint = trustedEndpoint(config);
  const version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  const body = {
    ...payload,
    companyId: LICENSE_COMPANY_ID,
    deviceId: getDeviceId(),
    appVersion: String(version || "").slice(0, 32),
    computerName: os.hostname()
  };
  return streamLicenseResponseToFile(endpoint, body, filePath, options);
}

async function readLicenseConfig(projectRoot, options = {}) {
  try {
    const config = options.licenseConfig || JSON.parse(await fs.readFile(options.licensePath || path.join(projectRoot, "license.json"), "utf8"));
    if (!config || config.enabled !== true || config.mode !== "apisix-intranet" || config.companyId !== LICENSE_COMPANY_ID) {
      throw new Error("bad config");
    }
    return config;
  } catch {
    const error = new Error("授权配置缺失或损坏，请联系管理员。");
    error.statusCode = 400;
    throw error;
  }
}

function trustedEndpoint(config) {
  const endpoint = new URL(config.licenseServer);
  if (endpoint.protocol !== "https:" || endpoint.username || endpoint.password || endpoint.search || endpoint.hash
    || !TRUSTED_LICENSE_SERVERS.includes(endpoint.href)) {
    const error = new Error("授权服务地址未获批准，请联系管理员。");
    error.statusCode = 400;
    throw error;
  }
  return endpoint;
}

function sanitizeHeartbeatUpdate(update = {}) {
  return {
    currentVersion: typeof update.currentVersion === "string" ? update.currentVersion.slice(0, 32) : "",
    latestVersion: typeof update.latestVersion === "string" ? update.latestVersion.slice(0, 32) : "",
    updateAvailable: update.updateAvailable === true,
    pendingUpdateReady: update.pendingUpdateReady === true,
    updateMode: typeof update.updateMode === "string" ? update.updateMode.slice(0, 16) : "",
    status: typeof update.status === "string" ? update.status.slice(0, 32) : ""
  };
}

function sanitizeHeartbeatMonitor(monitor = {}) {
  const text = (value, max = 160) => typeof value === "string" ? value.slice(0, max) : "";
  const number = (value, max = 1000000) => {
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed < 0) return 0;
    return Math.min(max, Math.floor(parsed));
  };
  return {
    status: text(monitor.status, 24),
    step: text(monitor.step, 80),
    waitingReason: text(monitor.waitingReason, 180),
    runId: text(monitor.runId, 96),
    currentIndex: number(monitor.currentIndex),
    totalCount: number(monitor.totalCount),
    successCount: number(monitor.successCount),
    failureCount: number(monitor.failureCount),
    updatedAt: text(monitor.updatedAt, 40)
  };
}

function sanitizeHeartbeatDiagnostic(diagnostic = {}) {
  const text = (value, max = 160) => typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, max) : "";
  const list = (value, maxItems, maxChars) => Array.isArray(value)
    ? value.slice(0, maxItems).map((item) => String(item || "").replace(/\s+/g, " ").trim().slice(0, maxChars)).filter(Boolean)
    : [];
  return {
    stage: text(diagnostic.stage, 80),
    category: text(diagnostic.category, 40),
    message: text(diagnostic.message, 300),
    lastAction: text(diagnostic.lastAction, 120),
    runId: text(diagnostic.runId, 96),
    previewName: text(diagnostic.previewName, 120),
    suggestions: list(diagnostic.suggestions, 8, 180),
    logs: list(diagnostic.logs, 20, 220),
    userNote: text(diagnostic.userNote, 300),
    recordedAt: text(diagnostic.recordedAt, 40)
  };
}

function sanitizeUsageReport(usage = {}) {
  const number = (value, max = 1000000) => {
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed < 0) return 0;
    return Math.min(max, Math.floor(parsed));
  };
  const text = (value, max = 80) => typeof value === "string" ? value.slice(0, max) : "";
  return {
    event: ["start", "finish"].includes(usage.event) ? usage.event : "finish",
    source: text(usage.source || "cms", 32),
    runId: text(usage.runId, 96),
    status: ["running", "completed", "failed", "stopped"].includes(usage.status) ? usage.status : "completed",
    startedAt: text(usage.startedAt, 40),
    finishedAt: text(usage.finishedAt, 40),
    durationMs: number(usage.durationMs, 7 * 24 * 60 * 60 * 1000),
    plannedCount: number(usage.plannedCount),
    successCount: number(usage.successCount),
    failureCount: number(usage.failureCount),
    stopped: usage.stopped === true,
    stage: text(usage.stage, 80),
    reason: text(usage.reason, 240),
    action: text(usage.action, 80),
    taskIndex: number(usage.taskIndex),
    totalCount: number(usage.totalCount),
    taskRole: text(usage.taskRole, 24),
    taskType: text(usage.taskType, 24),
    taskDate: text(usage.taskDate, 24),
    taskTime: text(usage.taskTime, 24),
    sendTimeRange: sanitizeUsageSendTimeRange(usage.sendTimeRange),
    modeSummary: sanitizeUsageModeSummary(usage.modeSummary),
    documentName: text(usage.documentName, 160),
    readRange: text(usage.readRange, 160),
    sendDate: text(usage.sendDate, 32),
    timeMode: text(usage.timeMode, 80),
    tuoStrategy: text(usage.tuoStrategy, 80),
    targetGroup: text(usage.targetGroup, 120),
    snapshotVersion: text(usage.snapshotVersion, 128),
    unknownCount: number(usage.unknownCount),
    skippedCount: number(usage.skippedCount),
    taskItems: sanitizeOpsTaskItems(usage.taskItems)
  };
}

function sanitizeUsageModeSummary(value = {}) {
  if (!value || typeof value !== "object") return {};
  const text = (raw, max = 80) => typeof raw === "string" ? raw.replace(/\s+/g, " ").trim().slice(0, max) : "";
  const result = {
    sourceMode: text(value.sourceMode),
    rangeMode: text(value.rangeMode),
    scheduleMode: text(value.scheduleMode),
    robotStrategy: text(value.robotStrategy),
    configMode: text(value.configMode),
    createMode: text(value.createMode),
    summary: text(value.summary, 240)
  };
  if (!Object.values(result).some(Boolean)) return {};
  return result;
}

function sanitizeUsageSendTimeRange(range = {}) {
  const text = (value, max = 24) => typeof value === "string" ? value.slice(0, max) : "";
  const point = (value = {}) => {
    const index = Number(value.index);
    return {
      index: Number.isFinite(index) && index > 0 ? Math.min(1000000, Math.floor(index)) : 0,
      date: text(value.date),
      time: text(value.time),
      role: text(value.role),
      type: text(value.type)
    };
  };
  if (!range || typeof range !== "object") return {};
  const first = point(range.first);
  const last = point(range.last);
  if (!first.date && !first.time && !last.date && !last.time) return {};
  return { first, last };
}

function sanitizeSupportReport(support = {}) {
  const text = (value, max = 160) => typeof value === "string" ? value.slice(0, max) : "";
  const list = (value, maxItems, maxChars) => Array.isArray(value)
    ? value.slice(0, maxItems).map((item) => String(item || "").slice(0, maxChars)).filter(Boolean)
    : [];
  return {
    stage: text(support.stage, 80),
    category: text(support.category, 40),
    message: text(support.message, 300),
    lastAction: text(support.lastAction, 120),
    runId: text(support.runId, 96),
    previewName: text(support.previewName, 120),
    suggestions: list(support.suggestions, 8, 180),
    logs: list(support.logs, 30, 260),
    userNote: text(support.userNote, 300)
  };
}

function normalizeServiceTimeout(value) {
  const timeoutMs = Number(value);
  if (!Number.isFinite(timeoutMs) || timeoutMs < 1) return 30000;
  return Math.min(Math.max(timeoutMs, 1000), 120000);
}

async function postLicenseJson(endpoint, payload, timeoutMs, options = {}) {
  if (!Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000) throw new Error("授权等待时间配置无效。");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await raceTransferAbort((options.fetch || globalThis.fetch)(endpoint, {
      method: "POST",
      redirect: "error",
      cache: "no-store",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    }), controller.signal);
    const text = await response.text();
    const maxResponseBytes = Number(options.maxResponseBytes || 0);
    if (maxResponseBytes > 0 && Buffer.byteLength(text, "utf8") > maxResponseBytes) {
      const error = new Error(`授权服务返回内容过大：HTTP ${response.status}；Content-Type ${response.headers.get("content-type") || "-"}`);
      error.code = "LICENSE_RESPONSE_TOO_LARGE";
      error.responseStatus = response.status;
      error.contentType = response.headers.get("content-type") || "";
      throw error;
    }
    try {
      return JSON.parse(text || "{}");
    } catch (parseError) {
      const error = new Error(`授权服务返回非 JSON：HTTP ${response.status}；Content-Type ${response.headers.get("content-type") || "-"}；返回前缀 ${safeResponseSnippet(text) || "-"}`);
      error.code = "LICENSE_NON_JSON_RESPONSE";
      error.responseStatus = response.status;
      error.contentType = response.headers.get("content-type") || "";
      error.responseSnippet = safeResponseSnippet(text);
      error.cause = parseError;
      throw error;
    }
  } finally {
    clearTimeout(timer);
    controller.abort();
  }
}

async function streamLicenseResponseToFile(endpoint, payload, filePath, options = {}) {
  const firstResponseTimeoutMs = boundedTransferTimeout(options.firstResponseTimeoutMs, 30000, 1000, 120000);
  const idleTimeoutMs = boundedTransferTimeout(options.idleTimeoutMs, 60000, 1000, 180000);
  const totalTimeoutMs = boundedTransferTimeout(options.totalTimeoutMs, 10 * 60 * 1000, 1000, 15 * 60 * 1000);
  const maxResponseBytes = Math.min(Number(options.maxResponseBytes || MAX_SHARED_RESPONSE_BYTES), MAX_SHARED_RESPONSE_BYTES + 1024 * 1024);
  const controller = new AbortController();
  const abortFromCaller = () => controller.abort(options.signal?.reason || new Error("用户取消下载。"));
  if (options.signal?.aborted) abortFromCaller();
  else options.signal?.addEventListener?.("abort", abortFromCaller, { once: true });
  let phase = "first-response";
  let firstTimer = setTimeout(() => controller.abort(new Error("等待服务器响应超时。")), firstResponseTimeoutMs);
  const totalTimer = setTimeout(() => controller.abort(new Error("云端文案下载超过总时限。")), totalTimeoutMs);
  let idleTimer = null;
  let output = null;
  let receivedBytes = 0;
  let completed = false;
  const armIdleTimer = () => {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => controller.abort(new Error("云端文案连续一段时间没有新数据。")), idleTimeoutMs);
  };
  try {
    const response = await (options.fetch || globalThis.fetch)(endpoint, {
      method: "POST",
      redirect: "error",
      cache: "no-store",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    });
    clearTimeout(firstTimer);
    firstTimer = null;
    phase = "transfer";
    if (!response.ok) {
      const errorText = (await response.text()).slice(0, 65536);
      let message = "";
      try { message = JSON.parse(errorText)?.message || JSON.parse(errorText)?.error || ""; } catch {}
      const error = new Error(message || `下载云端文案失败：HTTP ${response.status}。`);
      error.statusCode = response.status;
      error.responseStatus = response.status;
      throw error;
    }
    const contentType = String(response.headers.get("content-type") || "").toLowerCase();
    if (contentType && !contentType.includes("application/json") && !contentType.startsWith("text/plain")) {
      throw new Error(`授权服务返回非 JSON：HTTP ${response.status}；Content-Type ${contentType || "-"}。`);
    }
    const lengthHeader = response.headers.get("content-length");
    const expectedBytes = lengthHeader && /^\d+$/.test(lengthHeader) ? Number(lengthHeader) : 0;
    if (expectedBytes > maxResponseBytes) throw new Error("云端文案包超过 250MiB 限制。");
    if (expectedBytes > 0) {
      const disk = await fs.statfs(path.dirname(filePath)).catch(() => null);
      if (disk) {
        const available = Number(disk.bavail) * Number(disk.bsize);
        if (Number.isFinite(available) && available < expectedBytes + 32 * 1024 * 1024) {
          throw Object.assign(new Error("磁盘剩余空间不足，无法保存云端文案。"), { code: "ENOSPC" });
        }
      }
    }
    output = await fs.open(filePath, "wx");
    armIdleTimer();
    options.onProgress?.({ stage: "receiving", receivedBytes: 0, totalBytes: expectedBytes });
    const reader = response.body?.getReader?.();
    if (!reader) throw new Error("授权服务未返回可读取的下载内容。");
    while (true) {
      const { done, value } = await readTransferChunk(reader, controller.signal);
      if (done) break;
      armIdleTimer();
      const buffer = Buffer.from(value);
      receivedBytes += buffer.length;
      if (receivedBytes > maxResponseBytes) throw new Error("云端文案包超过 250MiB 限制。");
      await output.write(buffer);
      options.onProgress?.({ stage: "receiving", receivedBytes, totalBytes: expectedBytes });
    }
    clearTimeout(idleTimer);
    if (expectedBytes && receivedBytes !== expectedBytes) {
      throw new Error(`云端文案接收不完整：应收 ${expectedBytes} 字节，实收 ${receivedBytes} 字节。`);
    }
    await output.sync();
    await output.close();
    output = null;
    completed = true;
    return { ok: true, filePath, receivedBytes, totalBytes: expectedBytes, contentType };
  } catch (error) {
    if (controller.signal.aborted) {
      const aborted = new Error(options.signal?.aborted ? "已取消云端文案下载。" : (controller.signal.reason?.message || (phase === "first-response" ? "等待服务器响应超时。" : "云端文案下载超时。")));
      aborted.code = options.signal?.aborted ? "SHARED_DOWNLOAD_CANCELLED" : "SHARED_DOWNLOAD_TIMEOUT";
      throw aborted;
    }
    if (error?.code === "ENOSPC") throw new Error("磁盘剩余空间不足，无法保存云端文案临时文件。");
    throw error;
  } finally {
    clearTimeout(firstTimer);
    clearTimeout(idleTimer);
    clearTimeout(totalTimer);
    options.signal?.removeEventListener?.("abort", abortFromCaller);
    await output?.close().catch(() => {});
    if (!completed) await fs.unlink(filePath).catch(() => {});
  }
}

function boundedTransferTimeout(value, fallback, minimum, maximum) {
  const number = Number(value ?? fallback);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(Math.max(number, minimum), maximum);
}

async function readTransferChunk(reader, signal) {
  if (signal.aborted) throw signal.reason || new Error("下载已取消。");
  let onAbort;
  const aborted = new Promise((_, reject) => {
    onAbort = () => {
      reader.cancel(signal.reason).catch(() => {});
      reject(signal.reason || new Error("下载已取消。"));
    };
    signal.addEventListener("abort", onAbort, { once: true });
  });
  try {
    const result = await Promise.race([reader.read(), aborted]);
    if (signal.aborted) throw signal.reason || new Error("下载已取消。");
    return result;
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}

async function raceTransferAbort(promise, signal) {
  if (signal.aborted) throw signal.reason || new Error("下载已取消。");
  let onAbort;
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(signal.reason || new Error("下载已取消。"));
    signal.addEventListener("abort", onAbort, { once: true });
  });
  try {
    return await Promise.race([promise, aborted]);
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}

function safeResponseSnippet(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .replace(/[<>\r\n]/g, " ")
    .trim()
    .slice(0, 200);
}

export async function assertCompanyAccessAllowed(projectRoot, action, options = {}) {
  const status = await getLicenseStatus(projectRoot, { ...options, action });
  if (!status.allowed) {
    const error = new Error(`当前未授权，不能${ACTION_LABELS[action] || "使用核心功能"}：${status.message}`);
    error.code = "LICENSE_DENIED";
    error.statusCode = 403;
    error.license = status;
    throw error;
  }
  return status;
}

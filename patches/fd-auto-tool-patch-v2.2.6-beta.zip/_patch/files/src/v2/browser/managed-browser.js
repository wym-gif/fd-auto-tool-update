import { spawn } from "node:child_process";
import crypto from "node:crypto";
import { createReadStream, createWriteStream } from "node:fs";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";

export const MANAGED_BROWSER_COMPONENT_ID = "chrome-for-testing";
export const MANAGED_BROWSER_STATE_FILE = "current.json";
export const MANAGED_BROWSER_MANIFEST_FILE = "managed-browser-manifest.json";

export function managedBrowserRoot(projectRoot, options = {}) {
  return path.resolve(projectRoot, options.componentRoot || "browser-components/controlled-browser");
}

export async function loadManagedBrowserManifest(projectRoot, options = {}) {
  if (options.manifest) return validateManagedBrowserManifest(options.manifest);
  const manifestPath = path.resolve(
    projectRoot,
    options.manifestPath || `src/v2/browser/${MANAGED_BROWSER_MANIFEST_FILE}`
  );
  let value;
  try {
    value = JSON.parse(await fs.readFile(manifestPath, "utf8"));
  } catch (error) {
    const wrapped = new Error(`专用浏览器发布清单不可用：${manifestPath}。当前版本尚未配置可验证的浏览器组件。`);
    wrapped.code = "MANAGED_BROWSER_MANIFEST_UNAVAILABLE";
    wrapped.cause = error;
    throw wrapped;
  }
  return validateManagedBrowserManifest(value);
}

export function validateManagedBrowserManifest(value = {}) {
  const manifest = {
    schemaVersion: Number(value.schemaVersion || 1),
    componentId: String(value.componentId || MANAGED_BROWSER_COMPONENT_ID).trim(),
    version: String(value.version || "").trim(),
    platform: String(value.platform || "win64").trim(),
    archiveUrl: String(value.archiveUrl || "").trim(),
    archiveSha256: String(value.archiveSha256 || "").trim().toLowerCase(),
    executableRelativePath: String(value.executableRelativePath || "chrome-win64/chrome.exe").trim(),
    archiveBytes: Number(value.archiveBytes || 0) || 0,
    extractedBytes: Number(value.extractedBytes || 0) || 0
  };
  if (!manifest.version || !manifest.archiveUrl || !/^[a-f0-9]{64}$/.test(manifest.archiveSha256)) {
    const error = new Error("专用浏览器发布清单缺少固定版本、下载地址或有效 SHA-256，已禁止下载未锁定组件。");
    error.code = "MANAGED_BROWSER_MANIFEST_INVALID";
    throw error;
  }
  if (path.isAbsolute(manifest.executableRelativePath) || manifest.executableRelativePath.split(/[\\/]/).includes("..")) {
    const error = new Error("专用浏览器可执行文件路径超出组件目录，已停止准备。");
    error.code = "MANAGED_BROWSER_PATH_INVALID";
    throw error;
  }
  return manifest;
}

export async function inspectManagedBrowserComponent(projectRoot, options = {}) {
  const root = managedBrowserRoot(projectRoot, options);
  const state = await readJson(path.join(root, MANAGED_BROWSER_STATE_FILE));
  if (!state?.version || !state?.executablePath) {
    return { ok: false, status: "missing", root };
  }
  const executablePath = path.resolve(String(state.executablePath));
  if (!isInside(root, executablePath)) {
    return { ok: false, status: "invalid", code: "MANAGED_BROWSER_STATE_PATH_INVALID", root };
  }
  try {
    await fs.access(executablePath);
    return { ok: true, status: "ready", root, ...state, executablePath };
  } catch {
    return { ok: false, status: "missing", root, version: state.version, executablePath };
  }
}

export async function ensureManagedBrowserComponent(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const manifest = await loadManagedBrowserManifest(projectRoot, options);
  const root = managedBrowserRoot(projectRoot, options);
  const versionDir = path.join(root, "versions", safeSegment(manifest.version));
  const executablePath = path.resolve(versionDir, manifest.executableRelativePath);
  if (!isInside(versionDir, executablePath)) {
    const error = new Error("专用浏览器可执行文件路径超出版本目录，已停止准备。");
    error.code = "MANAGED_BROWSER_PATH_INVALID";
    throw error;
  }
  await fs.mkdir(root, { recursive: true });
  options.onProgress?.({ stage: "checking", version: manifest.version });
  const ready = await validateVersionExecutable(executablePath, manifest, options);
  if (ready) {
    const state = await activateManagedVersion(root, manifest, executablePath, options);
    return { ...state, reused: true };
  }

  const release = await acquireComponentLock(root, options);
  try {
    const readyAfterLock = await validateVersionExecutable(executablePath, manifest, options);
    if (readyAfterLock) {
      const state = await activateManagedVersion(root, manifest, executablePath, options);
      return { ...state, reused: true, waitedForOtherInstance: true };
    }
    await cleanupAbandonedPreparationArtifacts(root);
    await ensureDiskCapacity(root, manifest, options);
    const nonce = crypto.randomUUID();
    const archivePath = path.join(root, `download-${safeSegment(manifest.version)}-${nonce}.zip.part`);
    const extractPath = path.join(root, `extract-${safeSegment(manifest.version)}-${nonce}`);
    try {
      options.onProgress?.({ stage: "downloading", version: manifest.version, receivedBytes: 0, totalBytes: manifest.archiveBytes || null });
      await (options.downloadArchive || downloadArchive)(manifest.archiveUrl, archivePath, {
        expectedBytes: manifest.archiveBytes,
        onProgress: (progress) => options.onProgress?.({ stage: "downloading", version: manifest.version, ...progress })
      });
      options.onProgress?.({ stage: "verifying", version: manifest.version });
      const actualHash = await (options.hashFile || sha256File)(archivePath);
      if (actualHash.toLowerCase() !== manifest.archiveSha256) {
        const error = new Error(`专用浏览器下载校验失败：期望 ${manifest.archiveSha256}，实际 ${actualHash}。`);
        error.code = "MANAGED_BROWSER_HASH_MISMATCH";
        throw error;
      }
      options.onProgress?.({ stage: "extracting", version: manifest.version });
      await fs.mkdir(extractPath, { recursive: true });
      await (options.extractArchive || extractZipArchive)(archivePath, extractPath);
      const extractedExecutable = path.resolve(extractPath, manifest.executableRelativePath);
      if (!isInside(extractPath, extractedExecutable)) {
        const error = new Error("专用浏览器解压结果超出临时组件目录，已停止启用。");
        error.code = "MANAGED_BROWSER_EXTRACT_PATH_INVALID";
        throw error;
      }
      options.onProgress?.({ stage: "self-testing", version: manifest.version });
      await (options.selfTestExecutable || selfTestBrowserExecutable)(extractedExecutable, manifest, options);
      await fs.mkdir(path.dirname(versionDir), { recursive: true });
      await replaceDirectoryAtomically(extractPath, versionDir);
      const state = await activateManagedVersion(root, manifest, executablePath, options);
      options.onProgress?.({ stage: "ready", version: manifest.version });
      return { ...state, reused: false };
    } finally {
      await fs.rm(archivePath, { force: true }).catch(() => {});
      await fs.rm(extractPath, { recursive: true, force: true }).catch(() => {});
    }
  } finally {
    await release();
  }
}

async function validateVersionExecutable(executablePath, manifest, options) {
  try {
    await fs.access(executablePath);
    if (options.skipExistingSelfTest !== true) {
      await (options.selfTestExecutable || selfTestBrowserExecutable)(executablePath, manifest, options);
    }
    return true;
  } catch {
    return false;
  }
}

async function activateManagedVersion(root, manifest, executablePath, options = {}) {
  const previous = await readJson(path.join(root, MANAGED_BROWSER_STATE_FILE));
  const state = {
    schemaVersion: 1,
    componentId: manifest.componentId,
    version: manifest.version,
    platform: manifest.platform,
    executablePath,
    archiveSha256: manifest.archiveSha256,
    activatedAt: new Date().toISOString(),
    previousVersion: previous?.version && previous.version !== manifest.version ? previous.version : previous?.previousVersion || ""
  };
  await atomicWriteJson(path.join(root, MANAGED_BROWSER_STATE_FILE), state);
  options.onProgress?.({ stage: "ready", version: manifest.version });
  return { ok: true, status: "ready", root, ...state };
}

async function ensureDiskCapacity(root, manifest, options = {}) {
  const required = Math.max(0, manifest.archiveBytes + manifest.extractedBytes);
  if (!required) return;
  const available = options.getAvailableBytes
    ? await options.getAvailableBytes(root)
    : await getAvailableBytes(root);
  if (Number.isFinite(available) && available < required) {
    const error = new Error(`专用浏览器准备空间不足：需要约 ${required} 字节，可用 ${available} 字节。`);
    error.code = "MANAGED_BROWSER_DISK_SPACE_LOW";
    throw error;
  }
}

async function getAvailableBytes(target) {
  if (typeof fs.statfs !== "function") return Number.POSITIVE_INFINITY;
  const stat = await fs.statfs(target);
  return Number(stat.bavail) * Number(stat.bsize);
}

async function acquireComponentLock(root, options = {}) {
  const lockDir = path.join(root, ".prepare.lock");
  const gateDir = path.join(root, ".prepare-lock-gate");
  const timeoutMs = Math.max(1000, Number(options.lockTimeoutMs || 120000));
  const staleMs = Math.max(5000, Number(options.lockStaleMs || 15 * 60 * 1000));
  const startedAt = Date.now();
  const owner = { pid: process.pid, nonce: crypto.randomUUID(), createdAt: new Date().toISOString() };
  while (Date.now() - startedAt < timeoutMs) {
    const gateRelease = await tryAcquireDirectory(gateDir);
    if (!gateRelease) {
      await delay(100);
      continue;
    }
    try {
      const lockRelease = await tryAcquireDirectory(lockDir);
      if (lockRelease) {
        await atomicWriteJson(path.join(lockDir, "owner.json"), owner);
        await lockRelease({ keepDirectory: true });
        return async () => {
          const current = await readJson(path.join(lockDir, "owner.json"));
          if (current?.nonce === owner.nonce) await fs.rm(lockDir, { recursive: true, force: true });
        };
      }
      const current = await readJson(path.join(lockDir, "owner.json"));
      if (await lockOwnerIsStale(current, lockDir, staleMs, options)) {
        const quarantine = path.join(root, `.prepare.lock.stale-${crypto.randomUUID()}`);
        await fs.rename(lockDir, quarantine).catch(() => {});
        await fs.rm(quarantine, { recursive: true, force: true }).catch(() => {});
      }
    } finally {
      await gateRelease();
    }
    options.onProgress?.({ stage: "waiting-lock" });
    await delay(150);
  }
  const error = new Error("另一个实例正在准备专用浏览器，等待超时；没有启用半成品。");
  error.code = "MANAGED_BROWSER_LOCK_TIMEOUT";
  throw error;
}

async function tryAcquireDirectory(dir) {
  try {
    await fs.mkdir(dir);
    return async (options = {}) => {
      if (!options.keepDirectory) await fs.rm(dir, { recursive: true, force: true });
    };
  } catch (error) {
    if (error?.code === "EEXIST") return null;
    throw error;
  }
}

async function lockOwnerIsStale(owner, lockDir, staleMs, options = {}) {
  const stat = await fs.stat(lockDir).catch(() => null);
  if (!stat) return false;
  if (owner?.pid) {
    const isProcessAlive = options.isProcessAlive || defaultIsProcessAlive;
    return !await isProcessAlive(Number(owner.pid));
  }
  return Date.now() - stat.mtimeMs >= staleMs;
}

async function cleanupAbandonedPreparationArtifacts(root) {
  const entries = await fs.readdir(root, { withFileTypes: true }).catch(() => []);
  await Promise.all(entries.map(async (entry) => {
    const abandonedDownload = entry.isFile() && /^download-.+\.zip\.part$/i.test(entry.name);
    const abandonedExtraction = entry.isDirectory() && /^extract-.+/i.test(entry.name);
    if (!abandonedDownload && !abandonedExtraction) return;
    await fs.rm(path.join(root, entry.name), { recursive: abandonedExtraction, force: true });
  }));
}

function defaultIsProcessAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

async function downloadArchive(url, destination, options = {}) {
  const response = await fetch(url, { redirect: "follow", signal: AbortSignal.timeout(10 * 60 * 1000) });
  if (!response.ok || !response.body) throw new Error(`专用浏览器下载失败：HTTP ${response.status}`);
  const totalBytes = Number(response.headers.get("content-length") || options.expectedBytes || 0) || null;
  let receivedBytes = 0;
  const source = Readable.fromWeb(response.body);
  source.on("data", (chunk) => {
    receivedBytes += chunk.length;
    options.onProgress?.({ receivedBytes, totalBytes });
  });
  await pipeline(source, createWriteStream(destination, { flags: "wx" }));
  if (options.expectedBytes && receivedBytes !== Number(options.expectedBytes)) {
    throw new Error(`专用浏览器下载大小不一致：期望 ${options.expectedBytes}，实际 ${receivedBytes}。`);
  }
}

async function sha256File(filePath) {
  const hash = crypto.createHash("sha256");
  await pipeline(createReadStream(filePath), hash);
  return hash.digest("hex");
}

function extractZipArchive(archivePath, destination) {
  if (process.platform === "win32") {
    return spawnAndWait("tar.exe", ["-xf", archivePath, "-C", destination], "专用浏览器解压失败");
  }
  return spawnAndWait("unzip", ["-q", archivePath, "-d", destination], "专用浏览器解压失败");
}

async function selfTestBrowserExecutable(executablePath, manifest = {}, options = {}) {
  const selfTestRoot = await fs.mkdtemp(path.join(os.tmpdir(), "fd-managed-browser-selftest-"));
  const profileDir = path.join(selfTestRoot, "profile");
  const child = spawn(executablePath, [
    "--headless=new",
    "--remote-debugging-port=0",
    "--remote-debugging-address=127.0.0.1",
    `--user-data-dir=${profileDir}`,
    "--no-first-run",
    "--no-default-browser-check",
    "--no-sandbox",
    "about:blank"
  ], { windowsHide: true, stdio: "ignore" });
  let earlyExit = null;
  child.once("exit", (code, signal) => { earlyExit = { code, signal }; });
  try {
    const deadline = Date.now() + Math.max(3000, Number(options.selfTestTimeoutMs || 15000));
    let port = 0;
    while (Date.now() < deadline) {
      if (earlyExit) {
        throw managedBrowserError(
          "MANAGED_BROWSER_SELF_TEST_EXITED",
          `专用浏览器启动自检提前退出（退出码 ${earlyExit.code ?? "未知"}）。`
        );
      }
      const activePort = await fs.readFile(path.join(profileDir, "DevToolsActivePort"), "utf8").catch(() => "");
      port = Number(String(activePort).split(/\r?\n/)[0] || 0);
      if (port > 0) break;
      await delay(100);
    }
    if (!port) {
      throw managedBrowserError("MANAGED_BROWSER_SELF_TEST_TIMEOUT", "专用浏览器启动自检超时，没有取得本地调试端口。");
    }
    const response = await fetch(`http://127.0.0.1:${port}/json/version`, {
      signal: AbortSignal.timeout(3000)
    });
    if (!response.ok) {
      throw managedBrowserError("MANAGED_BROWSER_SELF_TEST_CDP_FAILED", `专用浏览器启动自检无法读取版本：HTTP ${response.status}。`);
    }
    const versionInfo = await response.json();
    const actualVersion = String(versionInfo?.Browser || "").trim();
    if (manifest.version && !actualVersion.includes(manifest.version)) {
      throw managedBrowserError(
        "MANAGED_BROWSER_VERSION_MISMATCH",
        `专用浏览器版本自检不一致：期望 ${manifest.version}，实际 ${actualVersion || "未知"}。`
      );
    }
  } finally {
    await stopSelfTestBrowser(child);
    await fs.rm(selfTestRoot, { recursive: true, force: true }).catch(() => {});
  }
}

function spawnAndWait(command, args, label) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { windowsHide: true, stdio: "ignore" });
    child.once("error", (error) => reject(new Error(`${label}：${error.message}`)));
    child.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`${label}：退出码 ${code}`)));
  });
}

async function atomicWriteJson(filePath, value) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  const previous = `${filePath}.${process.pid}.${crypto.randomUUID()}.previous`;
  await fs.writeFile(temporary, JSON.stringify(value, null, 2), "utf8");
  let movedPrevious = false;
  try {
    try {
      await fs.rename(filePath, previous);
      movedPrevious = true;
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
    await fs.rename(temporary, filePath);
    if (movedPrevious) await fs.rm(previous, { force: true });
  } catch (error) {
    await fs.rm(temporary, { force: true }).catch(() => {});
    if (movedPrevious) await fs.rename(previous, filePath).catch(() => {});
    throw error;
  }
}

async function replaceDirectoryAtomically(source, target) {
  const previous = `${target}.previous-${crypto.randomUUID()}`;
  let movedPrevious = false;
  try {
    try {
      await fs.rename(target, previous);
      movedPrevious = true;
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
    await fs.rename(source, target);
    if (movedPrevious) await fs.rm(previous, { recursive: true, force: true });
  } catch (error) {
    if (movedPrevious) await fs.rename(previous, target).catch(() => {});
    throw error;
  }
}

async function stopSelfTestBrowser(child) {
  if (!child?.pid) return;
  child.kill();
  const stopped = await Promise.race([
    new Promise((resolve) => child.once("exit", () => resolve(true))),
    delay(2000).then(() => false)
  ]);
  if (stopped || process.platform !== "win32") return;
  await spawnAndWait("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], "专用浏览器自检进程清理失败").catch(() => {});
}

function managedBrowserError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

async function readJson(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return null;
  }
}

function isInside(root, target) {
  const relative = path.relative(path.resolve(root), path.resolve(target));
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function safeSegment(value) {
  return String(value || "").replace(/[^a-zA-Z0-9._-]/g, "_");
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

const BRIDGE_VERSION = "2";
const SESSION_INSTANCE_KEY = "fdControlledTabDisplayInstanceId";

globalThis.__FD_CONTROLLED_TAB_DISPLAY_BRIDGE_VERSION = BRIDGE_VERSION;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !["fd-tab-display-handshake", "fd-tab-display-activate"].includes(message.type)) {
    return false;
  }
  handleBridgeMessage(message, sender)
    .then(sendResponse)
    .catch((error) => sendResponse({
      ok: false,
      code: error?.code || "TAB_DISPLAY_EXTENSION_ERROR",
      message: error?.message || String(error),
      requestId: message.requestId || ""
    }));
  return true;
});

async function handleBridgeMessage(message, sender) {
  const requestId = String(message.requestId || "");
  const instanceId = String(message.instanceId || "").trim();
  if (message.bridgeVersion !== BRIDGE_VERSION) {
    return response(false, "TAB_DISPLAY_EXTENSION_VERSION_MISMATCH", "内部切页模块版本不一致。", requestId, instanceId);
  }
  if (!requestId || !instanceId || !sender?.tab?.id) {
    return response(false, "TAB_DISPLAY_HANDSHAKE_IDENTITY_MISSING", "内部切页握手缺少请求、实例或页面身份。", requestId, instanceId);
  }
  const bound = await readBoundInstanceId();
  if (bound && bound !== instanceId) {
    return response(false, "TAB_DISPLAY_INSTANCE_MISMATCH", "内部切页模块已经绑定到另一个程序实例。", requestId, instanceId);
  }
  if (!bound) await chrome.storage.session.set({ [SESSION_INSTANCE_KEY]: instanceId });

  if (message.type === "fd-tab-display-handshake") {
    return {
      ok: true,
      requestId,
      bridgeVersion: BRIDGE_VERSION,
      instanceId,
      senderTabId: sender.tab.id
    };
  }
  return activateBoundTab(message, requestId, instanceId);
}

async function activateBoundTab(message, requestId, instanceId) {
  const token = String(message.token || "");
  const role = String(message.role || "");
  if (!token || !["tuo", "douma"].includes(role)) {
    return response(false, "TAB_DISPLAY_PAGE_IDENTITY_MISSING", "内部切页请求缺少可信页面标记。", requestId, instanceId);
  }
  const tabs = await chrome.tabs.query({ url: "https://cms.iyunzk.com/*" });
  const matches = [];
  for (const tab of tabs) {
    if (!Number.isInteger(tab.id)) continue;
    const marker = await chrome.tabs.sendMessage(tab.id, { type: "fd-read-tab-binding" }).catch(() => null);
    if (marker?.token === token && marker?.instanceId === instanceId && marker?.role === role) {
      matches.push(tab);
    }
  }
  if (matches.length !== 1) {
    return response(
      false,
      matches.length ? "TAB_DISPLAY_TARGET_AMBIGUOUS" : "TAB_DISPLAY_TARGET_NOT_FOUND",
      matches.length
        ? `内部切页找到 ${matches.length} 个相同绑定标签，已禁止猜测。`
        : "内部切页没有找到本条任务绑定的标签。",
      requestId,
      instanceId
    );
  }
  const target = matches[0];
  await chrome.tabs.update(target.id, { active: true });
  const updated = await chrome.tabs.get(target.id);
  if (!updated?.active) {
    return response(false, "TAB_DISPLAY_NOT_ACTIVE", "目标标签切换后未读回活动状态。", requestId, instanceId);
  }
  return {
    ok: true,
    requestId,
    bridgeVersion: BRIDGE_VERSION,
    token,
    instanceId,
    role,
    tabId: target.id,
    windowId: target.windowId,
    active: updated.active === true
  };
}

async function readBoundInstanceId() {
  const stored = await chrome.storage.session.get(SESSION_INSTANCE_KEY);
  return String(stored?.[SESSION_INSTANCE_KEY] || "").trim();
}

function response(ok, code, message, requestId, instanceId) {
  return { ok, code, message, requestId, bridgeVersion: BRIDGE_VERSION, instanceId };
}

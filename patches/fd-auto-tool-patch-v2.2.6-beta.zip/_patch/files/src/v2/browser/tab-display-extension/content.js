const REQUEST_EVENT = "fd-controlled-tab-display-request";
const RESPONSE_EVENT = "fd-controlled-tab-display-response";
const REQUEST_META = "fd-controlled-tab-command";
const RESPONSE_META = "fd-controlled-tab-response";
const handled = new Set();

window.addEventListener(REQUEST_EVENT, async () => {
  const marker = document.head?.querySelector?.(`meta[name="${REQUEST_META}"]`);
  const requestId = marker?.getAttribute("data-request-id") || "";
  if (!requestId || handled.has(requestId)) return;
  handled.add(requestId);
  let response;
  try {
    response = await chrome.runtime.sendMessage({
      type: marker.getAttribute("data-command") === "activate"
        ? "fd-tab-display-activate"
        : "fd-tab-display-handshake",
      requestId,
      bridgeVersion: marker.getAttribute("data-bridge-version") || "",
      instanceId: marker.getAttribute("data-instance-id") || "",
      token: marker.getAttribute("content") || "",
      role: marker.getAttribute("data-role") || ""
    });
  } catch (error) {
    response = {
      ok: false,
      code: "TAB_DISPLAY_EXTENSION_UNAVAILABLE",
      message: error?.message || String(error),
      requestId
    };
  }
  let result = document.head?.querySelector?.(`meta[name="${RESPONSE_META}"]`);
  if (!result && document.head) {
    result = document.createElement("meta");
    result.setAttribute("name", RESPONSE_META);
    document.head.appendChild(result);
  }
  if (!result) return;
  result.setAttribute("data-request-id", requestId);
  result.setAttribute("content", JSON.stringify(response || {}));
  window.dispatchEvent(new Event(RESPONSE_EVENT));
  if (handled.size > 100) handled.clear();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "fd-read-tab-binding") return false;
  const marker = document.head?.querySelector?.('meta[name="fd-controlled-tab-binding"]');
  sendResponse({
    token: marker?.getAttribute("content") || "",
    instanceId: marker?.getAttribute("data-instance-id") || "",
    role: marker?.getAttribute("data-role") || ""
  });
  return false;
});

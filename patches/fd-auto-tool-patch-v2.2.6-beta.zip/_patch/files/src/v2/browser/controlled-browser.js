import { spawn } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { chromium } from "playwright";
import {
  ensureManagedBrowserComponent,
  inspectManagedBrowserComponent,
  managedBrowserRoot
} from "./managed-browser.js";

export const DEFAULT_CONTROLLED_BROWSER_PORT = 9333;
export const CONTROLLED_BROWSER_STATE_FILE = "v2-controlled-cms-browser.json";
export const DEFAULT_CONTROLLED_PROFILE_DIR = "./browser-profile";
export const CONTROLLED_CONSOLE_TITLE = "2.0 可视化控制台";
export const CONTROLLED_TAB_DISPLAY_BRIDGE_VERSION = "2";
export const CONTROLLED_TAB_DISPLAY_EXTENSION_DIR = "src/v2/browser/tab-display-extension";
const DEFAULT_BROWSER_LAUNCH_ATTEMPTS = 3;
const DEFAULT_BROWSER_RETRY_DELAY_MS = 2000;

export function controlledBrowserStatePath(projectRoot, options = {}) {
  return path.join(options.runsDir || path.join(projectRoot, "runs"), CONTROLLED_BROWSER_STATE_FILE);
}

export function controlledTabDisplayExtensionPath(projectRoot = process.cwd()) {
  return path.resolve(projectRoot, CONTROLLED_TAB_DISPLAY_EXTENSION_DIR);
}

export async function activateControlledPageTab(page, options = {}) {
  if (!page || page.isClosed?.()) {
    throw controlledTabDisplayError("TAB_DISPLAY_PAGE_UNAVAILABLE", "当前任务页面已经关闭，无法在程序浏览器内部切换标签。请重新确认该页面。");
  }
  const instanceId = String(options.instanceId || page.__v2CmsTrustedInstanceId || "").trim();
  const role = String(options.role || page.__v2CmsTrustedRole || page.__v2CmsRole || "").trim();
  if (!instanceId || !["tuo", "douma"].includes(role)) {
    throw controlledTabDisplayError("TAB_DISPLAY_PAGE_IDENTITY_MISSING", "当前页面缺少可信实例或托/豆妈身份，已禁止按网址或标签顺序猜测。");
  }
  const token = crypto.randomUUID();
  await page.evaluate(({ token, instanceId, role }) => {
    const name = "fd-controlled-tab-binding";
    let marker = document.head?.querySelector?.(`meta[name="${name}"]`);
    if (!marker && document.head) {
      marker = document.createElement("meta");
      marker.setAttribute("name", name);
      document.head.appendChild(marker);
    }
    if (!marker) throw new Error("页面没有可写入绑定标记的 head 元素");
    marker.setAttribute("content", token);
    marker.setAttribute("data-instance-id", instanceId);
    marker.setAttribute("data-role", role);
  }, { token, instanceId, role });

  const bridgeRequest = options.bridgeRequest || requestControlledTabDisplayBridge;
  const result = await bridgeRequest(page, "activate", {
    token,
    instanceId,
    role,
    bridgeVersion: CONTROLLED_TAB_DISPLAY_BRIDGE_VERSION
  }, options);
  if (!result?.ok) {
    throw controlledTabDisplayError(
      result?.code || "TAB_DISPLAY_ACTIVATION_FAILED",
      result?.message || "程序浏览器内部切页模块没有确认目标标签，未使用置前接口兜底。"
    );
  }
  if (result.token !== token || result.instanceId !== instanceId || result.role !== role) {
    throw controlledTabDisplayError("TAB_DISPLAY_IDENTITY_MISMATCH", "内部切页模块返回的实例或页面身份不一致，已停止展示切换。");
  }
  page.__fdControlledTabDisplay = {
    tabId: result.tabId,
    windowId: result.windowId,
    token,
    instanceId,
    role
  };
  return { ...result, ok: true };
}

export async function handshakeControlledTabDisplay(page, options = {}) {
  const instanceId = String(options.instanceId || "").trim();
  if (!instanceId) {
    throw controlledTabDisplayError("TAB_DISPLAY_HANDSHAKE_IDENTITY_MISSING", "内部切页握手缺少当前程序实例身份。");
  }
  const bridgeRequest = options.bridgeRequest || requestControlledTabDisplayBridge;
  const result = await bridgeRequest(page, "handshake", {
    instanceId,
    bridgeVersion: CONTROLLED_TAB_DISPLAY_BRIDGE_VERSION
  }, options);
  if (!result?.ok) {
    throw controlledTabDisplayError(
      result?.code || "TAB_DISPLAY_EXTENSION_UNAVAILABLE",
      result?.message || "程序浏览器内部切页模块没有完成真实消息握手。"
    );
  }
  if (result.bridgeVersion !== CONTROLLED_TAB_DISPLAY_BRIDGE_VERSION || result.instanceId !== instanceId) {
    throw controlledTabDisplayError("TAB_DISPLAY_IDENTITY_MISMATCH", "内部切页握手返回的模块版本或实例身份不一致。");
  }
  return result;
}

async function requestControlledTabDisplayBridge(page, command, payload, options = {}) {
  const requestId = crypto.randomUUID();
  await page.evaluate(({ requestId, command, payload }) => {
    const name = "fd-controlled-tab-command";
    let marker = document.head?.querySelector?.(`meta[name="${name}"]`);
    if (!marker && document.head) {
      marker = document.createElement("meta");
      marker.setAttribute("name", name);
      document.head.appendChild(marker);
    }
    if (!marker) throw new Error("页面没有可写入握手命令的 head 元素");
    marker.setAttribute("data-request-id", requestId);
    marker.setAttribute("data-command", command);
    marker.setAttribute("data-bridge-version", payload.bridgeVersion || "");
    marker.setAttribute("data-instance-id", payload.instanceId || "");
    marker.setAttribute("data-role", payload.role || "");
    marker.setAttribute("content", payload.token || "");
    window.dispatchEvent(new Event("fd-controlled-tab-display-request"));
  }, { requestId, command, payload });
  const handle = await page.waitForFunction((expectedRequestId) => {
    const marker = document.head?.querySelector?.('meta[name="fd-controlled-tab-response"]');
    return marker?.getAttribute("data-request-id") === expectedRequestId ? marker.getAttribute("content") : "";
  }, requestId, { timeout: Math.max(500, Number(options.timeoutMs || 5000)) });
  try {
    const serialized = await handle.jsonValue();
    return JSON.parse(String(serialized || "{}"));
  } finally {
    await handle.dispose?.().catch(() => {});
  }
}

function controlledTabDisplayError(code, message) {
  const error = new Error(String(message || "程序浏览器内部切页失败。").trim());
  error.code = code;
  return error;
}

export async function ensureV2ControlledBrowser(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const config = options.config || {};
  const port = Number(options.port || config.cmsDebugPort || DEFAULT_CONTROLLED_BROWSER_PORT);
  const cdpUrl = options.cdpUrl || `http://127.0.0.1:${port}`;
  const requestedProfileDir = path.resolve(projectRoot, options.profileDir || config.profileDir || DEFAULT_CONTROLLED_PROFILE_DIR);
  const statePath = controlledBrowserStatePath(projectRoot, options);
  const targetUrl = String(options.url || "").trim();
  const cdpProbe = options.cdpProbe || canReachCdp;
  const rawInstanceId = String(options.instanceId || config.id || "");
  const bridgeInstanceId = rawInstanceId || "default";
  const previousState = await readJsonIfExists(statePath);
  let launchedWithTargetUrl = false;
  let environment = null;
  let extensionLoad = { ok: true, method: "command-line", extensionId: "", error: "" };

  await fs.mkdir(path.dirname(statePath), { recursive: true });
  const cdpReady = await cdpProbe(cdpUrl);
  if (cdpReady) {
    const recordedRequestedProfile = path.resolve(previousState?.requestedProfileDir || previousState?.profileDir || "");
    const identityMatches = previousState
      && Number(previousState.port || 0) === port
      && recordedRequestedProfile === requestedProfileDir
      && String(previousState.instanceId || "") === rawInstanceId;
    if (!identityMatches) {
      const error = new Error(`端口 ${port} 已有浏览器，但无法证明属于当前实例和 profile。为避免串用页面，已停止复用。请关闭冲突浏览器后重试。`);
      error.code = "CONTROLLED_BROWSER_IDENTITY_MISMATCH";
      throw error;
    }
    environment = {
      browserKind: previousState.browserKind || "legacy",
      browserVersion: previousState.browserVersion || "",
      executablePath: previousState.browserExecutablePath || "",
      profileDir: path.resolve(previousState.profileDir),
      requestedProfileDir,
      componentStatus: previousState.browserComponentStatus || "reused",
      componentError: previousState.browserComponentError || "",
      fallbackUsed: previousState.browserFallbackUsed === true
    };
  } else {
    environment = await resolveControlledBrowserLaunchEnvironment({
      ...options,
      projectRoot,
      instanceId: bridgeInstanceId,
      requestedProfileDir
    });
    await fs.mkdir(environment.profileDir, { recursive: true });
    const extensionPath = controlledTabDisplayExtensionPath(projectRoot);
    await fs.access(path.join(extensionPath, "manifest.json")).catch(() => {
      const error = new Error(`2.0 可控浏览器启动失败：缺少程序内部切页模块：${extensionPath}`);
      error.code = "TAB_DISPLAY_EXTENSION_FILES_MISSING";
      throw error;
    });
    const args = [
      `--remote-debugging-port=${port}`,
      "--remote-debugging-address=127.0.0.1",
      `--user-data-dir=${environment.profileDir}`,
      `--load-extension=${extensionPath}`,
      "--no-first-run",
      "--no-default-browser-check",
      "--no-sandbox"
    ];
    if (environment.browserKind === "managed-chrome-for-testing") {
      args.push(`--disable-extensions-except=${extensionPath}`);
      args.push("--enable-unsafe-extension-debugging");
    }
    if (targetUrl && environment.browserKind !== "managed-chrome-for-testing") {
      args.push(targetUrl);
      launchedWithTargetUrl = true;
    }
    await launchControlledBrowserWithRetry({
      chromePath: environment.executablePath,
      args,
      cdpUrl,
      timeoutMs: options.timeoutMs || 15000,
      attempts: options.launchAttempts || DEFAULT_BROWSER_LAUNCH_ATTEMPTS,
      retryDelayMs: options.launchRetryDelayMs ?? DEFAULT_BROWSER_RETRY_DELAY_MS,
      spawnBrowser: options.spawnBrowser,
      waitForAttempt: options.waitForLaunchAttempt,
      cdpProbe,
      sleep: options.sleep
    });
  }

  const tabDisplayExtensionPath = controlledTabDisplayExtensionPath(projectRoot);
  if (environment.browserKind === "managed-chrome-for-testing") {
    const loader = options.tabDisplayExtensionLoader || loadControlledTabDisplayExtension;
    try {
      const loaded = await loader(cdpUrl, tabDisplayExtensionPath, options);
      extensionLoad = {
        ok: true,
        method: loaded?.method || "cdp-load-unpacked",
        extensionId: loaded?.extensionId || "",
        error: ""
      };
    } catch (error) {
      extensionLoad = {
        ok: false,
        method: "cdp-load-unpacked",
        extensionId: "",
        error: error?.message || String(error)
      };
    }
  }

  if (targetUrl && options.openUrl !== false && !launchedWithTargetUrl) {
    await openControlledTargetPage(cdpUrl, targetUrl, {
      ...options,
      bringToFront: false,
      reuseInitialBrowserTab: !cdpReady
    }).catch(() => {});
  }
  const handshake = await performControlledTabDisplayHandshake(cdpUrl, {
    ...options,
    targetUrl,
    instanceId: bridgeInstanceId
  });
  const fallbackEnvironment = buildFallbackEnvironment(previousState, requestedProfileDir);
  const state = {
    cdpUrl,
    port,
    profileDir: environment.profileDir,
    requestedProfileDir,
    instanceId: rawInstanceId,
    browserKind: environment.browserKind,
    browserVersion: environment.browserVersion,
    browserExecutablePath: environment.executablePath,
    browserComponentStatus: environment.componentStatus,
    browserComponentError: environment.componentError || "",
    browserFallbackUsed: environment.fallbackUsed === true,
    fallbackEnvironment,
    tabDisplayExtensionConfigured: handshake.ok,
    tabDisplayExtensionStatus: handshake.ok ? "ready" : "unavailable",
    tabDisplayExtensionError: handshake.ok ? "" : [extensionLoad.error, handshake.error].filter(Boolean).join("；"),
    tabDisplayExtensionLoadMethod: extensionLoad.ok
      ? extensionLoad.method
      : (handshake.ok ? "command-line-fallback" : extensionLoad.method),
    tabDisplayExtensionId: extensionLoad.extensionId,
    tabDisplayExtensionLoadError: extensionLoad.error,
    tabDisplayBridgeVersion: handshake.ok ? CONTROLLED_TAB_DISPLAY_BRIDGE_VERSION : "",
    tabDisplayCheckedAt: new Date().toISOString(),
    tabDisplayExtensionPath,
    openedAt: new Date().toISOString()
  };
  await writeJsonAtomically(statePath, state);
  return state;
}

export async function loadControlledTabDisplayExtension(cdpUrl, extensionPath, options = {}) {
  try {
    const sendCommand = options.sendBrowserCdpCommand || sendBrowserCdpCommand;
    const result = await sendCommand(cdpUrl, "Extensions.loadUnpacked", { path: path.resolve(extensionPath) });
    const extensionId = String(result?.id || "").trim();
    if (!extensionId) {
      throw controlledTabDisplayError("TAB_DISPLAY_EXTENSION_LOAD_FAILED", "浏览器没有返回已加载扩展的身份标识。");
    }
    return { method: "cdp-load-unpacked", extensionId };
  } catch (error) {
    if (error?.code === "TAB_DISPLAY_EXTENSION_LOAD_FAILED") throw error;
    throw controlledTabDisplayError(
      "TAB_DISPLAY_EXTENSION_LOAD_FAILED",
      `专用浏览器内部切页模块加载失败：${error?.message || error}`
    );
  }
}

async function sendBrowserCdpCommand(cdpUrl, method, params = {}) {
  const response = await fetch(`${String(cdpUrl).replace(/\/$/, "")}/json/version`, {
    signal: AbortSignal.timeout(3000)
  });
  if (!response.ok) throw new Error(`读取浏览器调试入口失败（HTTP ${response.status}）`);
  const version = await response.json();
  const webSocketUrl = String(version?.webSocketDebuggerUrl || "").trim();
  if (!webSocketUrl) throw new Error("浏览器调试入口没有返回 WebSocket 地址");
  const socket = new WebSocket(webSocketUrl);
  const requestId = 1;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => finish(reject, new Error(`${method} 等待响应超时`)), 8000);
    const finish = (complete, value) => {
      clearTimeout(timer);
      try { socket.close(); } catch {}
      complete(value);
    };
    socket.addEventListener("open", () => {
      socket.send(JSON.stringify({ id: requestId, method, params }));
    });
    socket.addEventListener("message", (event) => {
      let message;
      try { message = JSON.parse(String(event.data || "{}")); } catch { return; }
      if (message.id !== requestId) return;
      if (message.error) {
        finish(reject, new Error(message.error.message || JSON.stringify(message.error)));
        return;
      }
      finish(resolve, message.result || {});
    });
    socket.addEventListener("error", () => finish(reject, new Error("浏览器调试 WebSocket 连接失败")), { once: true });
  });
}

async function resolveControlledBrowserLaunchEnvironment(options = {}) {
  if (options.chromePath) {
    return {
      browserKind: "explicit",
      browserVersion: "",
      executablePath: path.resolve(String(options.chromePath)),
      profileDir: options.requestedProfileDir,
      requestedProfileDir: options.requestedProfileDir,
      componentStatus: "explicit",
      componentError: "",
      fallbackUsed: false
    };
  }
  let preparationError = null;
  try {
    const component = await ensureManagedBrowserComponent({
      projectRoot: options.projectRoot,
      ...(options.managedBrowserOptions || {}),
      onProgress: options.onBrowserPreparationProgress
    });
    return managedControlledBrowserEnvironment(options, component, false, "");
  } catch (error) {
    preparationError = error;
  }
  const previousManaged = await inspectManagedBrowserComponent(options.projectRoot, options.managedBrowserOptions || {});
  if (previousManaged.ok) {
    return managedControlledBrowserEnvironment(
      options,
      previousManaged,
      true,
      preparationError?.message || String(preparationError)
    );
  }
  const legacyChromePath = await findLegacyChromePath();
  if (!legacyChromePath) {
    const error = new Error(`专用浏览器准备失败，且没有找到可配合旧 profile 回退的原 Chrome：${preparationError?.message || preparationError}`);
    error.code = preparationError?.code || "CONTROLLED_BROWSER_ENVIRONMENT_UNAVAILABLE";
    throw error;
  }
  return {
    browserKind: "legacy-fallback",
    browserVersion: "",
    executablePath: legacyChromePath,
    profileDir: options.requestedProfileDir,
    requestedProfileDir: options.requestedProfileDir,
    componentStatus: "failed",
    componentError: preparationError?.message || String(preparationError),
    fallbackUsed: true
  };
}

function managedControlledBrowserEnvironment(options, component, fallbackUsed, componentError) {
  const safeInstance = safePathSegment(options.instanceId || "default");
  const safeVersion = safePathSegment(component.version || "unknown");
  return {
    browserKind: "managed-chrome-for-testing",
    browserVersion: component.version || "",
    executablePath: path.resolve(component.executablePath),
    profileDir: path.join(managedBrowserRoot(options.projectRoot, options.managedBrowserOptions || {}), "profiles", safeInstance, safeVersion),
    requestedProfileDir: options.requestedProfileDir,
    componentStatus: fallbackUsed ? "fallback-ready" : "ready",
    componentError,
    fallbackUsed
  };
}

async function performControlledTabDisplayHandshake(cdpUrl, options = {}) {
  const handshake = options.tabDisplayHandshake || probeControlledTabDisplayBridge;
  try {
    const result = await handshake(cdpUrl, options);
    return { ok: true, result };
  } catch (error) {
    return {
      ok: false,
      code: error?.code || "TAB_DISPLAY_EXTENSION_UNAVAILABLE",
      error: error?.message || String(error)
    };
  }
}

export async function probeControlledTabDisplayBridge(cdpUrl, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  const timeoutMs = Math.max(1000, Number(options.handshakeTimeoutMs || 8000));
  const deadline = Date.now() + timeoutMs;
  let lastError = null;
  try {
    while (Date.now() < deadline) {
      const pages = browser.contexts().flatMap((context) => context.pages())
        .filter((page) => !page.isClosed?.() && isTabDisplayBridgePage(page.url?.() || "", options.targetUrl));
      for (const page of pages) {
        try {
          return await handshakeControlledTabDisplay(page, {
            ...options,
            timeoutMs: Math.min(2500, Math.max(500, deadline - Date.now()))
          });
        } catch (error) {
          lastError = error;
        }
      }
      await delay(150);
    }
  } finally {
    await disconnectControlledBrowser(browser);
  }
  throw controlledTabDisplayError(
    lastError?.code || "TAB_DISPLAY_EXTENSION_UNAVAILABLE",
    lastError?.message || "专用浏览器已连接，但内部切页模块没有在限定时间内完成真实消息握手。"
  );
}

function isTabDisplayBridgePage(currentUrl, targetUrl = "") {
  try {
    const current = new URL(currentUrl);
    if (current.hostname === "cms.iyunzk.com" && current.protocol === "https:") return true;
    if (["127.0.0.1", "localhost"].includes(current.hostname) && current.protocol === "http:") return true;
    return targetUrl ? sameBrowserTarget(currentUrl, targetUrl) : false;
  } catch {
    return false;
  }
}

function buildFallbackEnvironment(previousState, requestedProfileDir) {
  if (previousState?.fallbackEnvironment?.profileDir) {
    return {
      ...previousState.fallbackEnvironment,
      profileDir: path.resolve(previousState.fallbackEnvironment.profileDir),
      requestedProfileDir: path.resolve(previousState.fallbackEnvironment.requestedProfileDir || requestedProfileDir)
    };
  }
  if (!previousState?.profileDir) {
    return {
      browserKind: "legacy",
      browserVersion: "",
      executablePath: "",
      profileDir: requestedProfileDir
    };
  }
  return {
    browserKind: previousState.browserKind || "legacy",
    browserVersion: previousState.browserVersion || "",
    executablePath: previousState.browserExecutablePath || "",
    profileDir: path.resolve(previousState.profileDir),
    requestedProfileDir: path.resolve(previousState.requestedProfileDir || requestedProfileDir)
  };
}

function safePathSegment(value) {
  return String(value || "default").replace(/[^a-zA-Z0-9._-]/g, "_");
}

export async function launchControlledBrowserWithRetry(options = {}) {
  const attempts = Math.max(1, Number(options.attempts) || DEFAULT_BROWSER_LAUNCH_ATTEMPTS);
  const retryDelayMs = options.retryDelayMs === undefined
    ? DEFAULT_BROWSER_RETRY_DELAY_MS
    : Math.max(0, Number(options.retryDelayMs) || 0);
  const spawnBrowser = options.spawnBrowser || spawn;
  const waitForAttempt = options.waitForAttempt || waitForCdpOrBrowserExit;
  const sleep = options.sleep || delay;
  let lastOutcome = null;

  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    let child;
    try {
      child = spawnBrowser(options.chromePath, options.args || [], {
        detached: true,
        stdio: "ignore",
        windowsHide: false
      });
    } catch (error) {
      throw new Error(`2.0 可控浏览器启动失败：Chrome 进程无法创建：${error?.message || error}`);
    }
    child.unref?.();
    lastOutcome = await waitForAttempt(
      options.cdpUrl,
      child,
      options.timeoutMs || 15000,
      options.cdpProbe || canReachCdp
    );
    if (lastOutcome?.ready) return { attempts: attempt };
    if (lastOutcome?.error) {
      throw new Error(`2.0 可控浏览器启动失败：Chrome 进程错误：${lastOutcome.error?.message || lastOutcome.error}`);
    }
    if (!lastOutcome?.exited) break;
    if (attempt < attempts) await sleep(retryDelayMs);
  }

  if (lastOutcome?.exited) {
    const exitCode = lastOutcome.code === null || lastOutcome.code === undefined ? "未知" : lastOutcome.code;
    throw new Error(`2.0 可控浏览器启动失败：Chrome 启动后提前退出（退出码 ${exitCode}），已自动尝试 ${attempts} 次，仍无法连接 ${options.cdpUrl}`);
  }
  throw new Error(`2.0 可控浏览器启动失败：无法连接 ${options.cdpUrl}`);
}

export async function loadV2ControlledBrowserState(projectRoot, config = {}, options = {}) {
  const state = await readJsonIfExists(controlledBrowserStatePath(projectRoot, options));
  if (!state) return {};
  const port = Number(state.port || options.port || config.cmsDebugPort || DEFAULT_CONTROLLED_BROWSER_PORT);
  const cdpUrl = state.cdpUrl || `http://127.0.0.1:${port}`;
  if (await canReachCdp(cdpUrl)) {
    return {
      cdpUrl,
      port,
      profileDir: state.profileDir || path.resolve(projectRoot, config.profileDir || DEFAULT_CONTROLLED_PROFILE_DIR),
      requestedProfileDir: state.requestedProfileDir || "",
      browserKind: state.browserKind || "",
      browserVersion: state.browserVersion || "",
      browserComponentStatus: state.browserComponentStatus || "",
      browserComponentError: state.browserComponentError || "",
      browserFallbackUsed: state.browserFallbackUsed === true,
      fallbackEnvironment: state.fallbackEnvironment || null,
      tabDisplayExtensionConfigured: state.tabDisplayExtensionConfigured === true,
      tabDisplayExtensionStatus: state.tabDisplayExtensionStatus || "unknown",
      tabDisplayExtensionError: state.tabDisplayExtensionError || "",
      tabDisplayExtensionLoadMethod: state.tabDisplayExtensionLoadMethod || "",
      tabDisplayExtensionId: state.tabDisplayExtensionId || "",
      tabDisplayExtensionLoadError: state.tabDisplayExtensionLoadError || "",
      tabDisplayBridgeVersion: state.tabDisplayBridgeVersion || "",
      tabDisplayCheckedAt: state.tabDisplayCheckedAt || ""
    };
  }
  return {};
}

export async function openOrFocusControlledPage(cdpUrl, url, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  try {
    const context = browser.contexts()[0] || await browser.newContext();
    const page = await reuseOrOpenControlledPageInContext(context, url, {
      reuseSameTarget: true,
      navigateExisting: false,
      ...options
    });
    return page.url?.() || url;
  } finally {
    await disconnectControlledBrowser(browser);
  }
}

export async function openOrFocusConsolePage(cdpUrl, url, options = {}) {
  return openOrReplaceControlledPage(cdpUrl, url, {
    titleIncludes: CONTROLLED_CONSOLE_TITLE,
    onlyLocalhost: true,
    closeExtra: true,
    preferLatest: true,
    ...options
  });
}

export async function openOrReplaceControlledPage(cdpUrl, url, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  try {
    const context = browser.contexts()[0] || await browser.newContext();
    const page = await reuseOrOpenControlledPageInContext(context, url, {
      ...options,
      reuseSameTarget: true,
      navigateExisting: true
    });
    return page.url?.() || url;
  } finally {
    await disconnectControlledBrowser(browser);
  }
}

export async function inspectControlledPages(cdpUrl, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  try {
    const context = browser.contexts()[0] || await browser.newContext();
    return collectControlledPageInfos(context, options);
  } finally {
    await disconnectControlledBrowser(browser);
  }
}

export async function closeMatchingControlledPages(cdpUrl, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  let closed = 0;
  try {
    const context = browser.contexts()[0] || await browser.newContext();
    for (const page of context.pages?.() || []) {
      if (page.isClosed?.()) continue;
      const info = await pageInfo(page, options);
      if (!matchesPageInfoOptions(info, options)) continue;
      try {
        await page.close?.();
        closed += 1;
      } catch {}
    }
    return { closed };
  } finally {
    await disconnectControlledBrowser(browser);
  }
}

export async function closeV2ControlledBrowser(projectRoot, config = {}, options = {}) {
  const statePath = controlledBrowserStatePath(projectRoot, options);
  const state = await readJsonIfExists(statePath);
  if (!state?.cdpUrl && !state?.port && options.allowPortFallback !== true) return { closed: false };
  const port = Number(state?.port || options.port || config.cmsDebugPort || DEFAULT_CONTROLLED_BROWSER_PORT);
  const cdpUrl = state?.cdpUrl || `http://127.0.0.1:${port}`;
  let closed = false;
  if (await canReachCdp(cdpUrl)) {
    const browser = await chromium.connectOverCDP(cdpUrl);
    try {
      if (!state?.cdpUrl && !state?.port && !await browserHasV2ControlledPage(browser)) {
        await disconnectControlledBrowser(browser);
        return { closed: false };
      }
      closed = await requestBrowserProcessClose(browser);
      if (!closed) {
        const pageCloseResult = await closeV2ControlledPagesInBrowser(browser);
        await browser.close().catch(() => {});
        closed = pageCloseResult.closed > 0;
      }
    } catch {
      await disconnectControlledBrowser(browser);
    }
  }
  await fs.unlink(statePath).catch((error) => {
    if (error?.code !== "ENOENT") throw error;
  });
  return { closed };
}

async function requestBrowserProcessClose(browser) {
  if (typeof browser?.newBrowserCDPSession !== "function") return false;
  try {
    const session = await browser.newBrowserCDPSession();
    await session.send("Browser.close");
    return true;
  } catch (error) {
    return isBrowserClosingError(error);
  }
}

function isBrowserClosingError(error) {
  const message = String(error?.message || error || "");
  return /Target closed|Browser has been closed|Connection closed|WebSocket is not open|closed/i.test(message);
}

async function closeV2ControlledPagesInBrowser(browser) {
  let closed = 0;
  for (const context of browser.contexts?.() || []) {
    for (const page of context.pages?.() || []) {
      if (page.isClosed?.()) continue;
      const title = await page.title?.().catch(() => "") || "";
      const url = page.url?.() || "";
      const isV2Page = String(title).includes(CONTROLLED_CONSOLE_TITLE)
        || String(title).includes("妙券自动发单 - 预览确认")
        || (isLocalhostUrl(url) && /[?&]controlled=1\b/.test(url));
      if (!isV2Page) continue;
      await page.close?.().then(() => { closed += 1; }).catch(() => {});
    }
  }
  return { closed };
}

async function browserHasV2ControlledPage(browser) {
  for (const context of browser.contexts?.() || []) {
    for (const page of context.pages?.() || []) {
      if (page.isClosed?.()) continue;
      const title = await page.title?.().catch(() => "") || "";
      const url = page.url?.() || "";
      if (String(title).includes(CONTROLLED_CONSOLE_TITLE)) return true;
      if (String(title).includes("妙券自动发单 - 预览确认")) return true;
      if (isLocalhostUrl(url) && /[?&]controlled=1\b/.test(url)) return true;
    }
  }
  return false;
}

export async function reuseOrOpenControlledPageInContext(context, url, options = {}) {
  const pages = (context.pages?.() || []).filter((page) => !page.isClosed?.());
  const matches = [];
  for (let index = 0; index < pages.length; index++) {
    const page = pages[index];
    const info = await pageInfo(page, options);
    const score = reusablePageScore(info, url, options);
    if (score > 0) matches.push({ page, score, index });
  }
  if (matches.length) {
    matches.sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      if (options.preferLatest) return right.index - left.index;
      return left.index - right.index;
    });
    const page = matches[0].page;
    for (const extra of matches.slice(1)) {
      if (options.closeExtra) await extra.page.close?.().catch(() => {});
    }
    if (options.navigateExisting && !sameExactUrl(page.url?.() || "", url)) {
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: options.timeoutMs || 30000 });
    }
    if (options.closeOtherPages) await closeOtherPagesInContext(context, page);
    if (options.bringToFront !== false) await page.bringToFront?.().catch(() => {});
    return page;
  }
  const blank = pages.find((page) => {
    const pageUrl = String(page.url?.() || "");
    if (pageUrl === "about:blank") return true;
    return options.reuseInitialBrowserTab === true
      && (pageUrl === "chrome://newtab/" || pageUrl === "chrome://new-tab-page/");
  });
  const page = blank || await context.newPage();
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: options.timeoutMs || 30000 });
  if (options.closeOtherPages) await closeOtherPagesInContext(context, page);
  if (options.bringToFront !== false) await page.bringToFront?.().catch(() => {});
  return page;
}

async function closeOtherPagesInContext(context, keepPage) {
  for (const page of context.pages?.() || []) {
    if (!page || page === keepPage || page.isClosed?.()) continue;
    await page.close?.().catch(() => {});
  }
}

export async function collectControlledPageInfos(context, options = {}) {
  const infos = [];
  for (const page of (context.pages?.() || [])) {
    if (page.isClosed?.()) continue;
    infos.push(await pageInfo(page, options));
  }
  return infos.filter((info) => matchesPageInfoOptions(info, options));
}

async function openControlledTargetPage(cdpUrl, url, options = {}) {
  if (options.pageKind === "console" || options.consolePage === true) {
    return openOrFocusConsolePage(cdpUrl, url, options);
  }
  return openOrFocusControlledPage(cdpUrl, url, options);
}

export async function canReachCdp(cdpUrl) {
  try {
    const response = await fetch(`${String(cdpUrl).replace(/\/$/, "")}/json/version`, { signal: AbortSignal.timeout(1500) });
    return response.ok;
  } catch {
    return false;
  }
}

async function waitForCdpOrBrowserExit(cdpUrl, child, timeoutMs, cdpProbe = canReachCdp) {
  let exitOutcome = null;
  const onExit = (code, signal) => {
    exitOutcome = { ready: false, exited: true, code, signal };
  };
  const onError = (error) => {
    exitOutcome = { ready: false, exited: true, error };
  };
  child.once?.("exit", onExit);
  child.once?.("error", onError);
  const start = Date.now();
  try {
    while (Date.now() - start < timeoutMs) {
      if (await cdpProbe(cdpUrl)) return { ready: true, exited: false };
      if (exitOutcome) return exitOutcome;
      await delay(250);
    }
    if (await cdpProbe(cdpUrl)) return { ready: true, exited: false };
    if (exitOutcome) return exitOutcome;
    return { ready: false, exited: false, timeout: true };
  } finally {
    child.removeListener?.("exit", onExit);
    child.removeListener?.("error", onError);
  }
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function findLegacyChromePath() {
  const candidates = [
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
  ];
  for (const candidate of candidates) {
    try {
      await fs.access(candidate);
      return candidate;
    } catch {}
  }
  return "";
}

function sameBrowserTarget(current, target) {
  try {
    const currentUrl = new URL(current);
    const targetUrl = new URL(target);
    return currentUrl.origin === targetUrl.origin && currentUrl.pathname === targetUrl.pathname;
  } catch {
    return current === target;
  }
}

function sameExactUrl(current, target) {
  try {
    return new URL(current).href === new URL(target).href;
  } catch {
    return current === target;
  }
}

async function pageInfo(page, options = {}) {
  const url = page.url?.() || "";
  const title = await page.title?.().catch(() => "") || "";
  const previewDirty = options.includeDirty
    ? await page.evaluate?.(() => Boolean(window.__v2PreviewDirty)).catch(() => false)
    : false;
  return { page, url, title, previewDirty };
}

function reusablePageScore(info, targetUrl, options = {}) {
  if (options.replaceUrl && sameBrowserTarget(info.url, options.replaceUrl)) return 5;
  if (options.reuseSameTarget !== false && sameExactUrl(info.url, targetUrl)) return 4;
  if (options.reuseSameTarget !== false && sameBrowserTarget(info.url, targetUrl)) return 3;
  return matchesPageInfoOptions(info, options) ? 1 : 0;
}

function matchesPageInfoOptions(info, options = {}) {
  const hasIdentityMatcher = Boolean(options.titleIncludes || options.urlIncludes);
  if (!hasIdentityMatcher) return false;
  if (options.onlyLocalhost && !isLocalhostUrl(info.url)) return false;
  if (options.titleIncludes && !String(info.title || "").includes(options.titleIncludes)) return false;
  if (options.urlIncludes && !String(info.url || "").includes(options.urlIncludes)) return false;
  return true;
}

function isLocalhostUrl(value) {
  try {
    const url = new URL(value);
    return ["127.0.0.1", "localhost"].includes(url.hostname);
  } catch {
    return false;
  }
}

async function disconnectControlledBrowser(browser) {
  if (typeof browser?.disconnect === "function") {
    browser.disconnect();
    return;
  }
  await browser?.close?.().catch(() => {});
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return null;
  }
}

async function writeJsonAtomically(filePath, value) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  const previous = `${filePath}.${process.pid}.${crypto.randomUUID()}.previous`;
  await fs.writeFile(temporary, JSON.stringify(value, null, 2), "utf8");
  let movedPrevious = false;
  try {
    try {
      await fs.rename(filePath, previous);
      movedPrevious = true;
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
    await fs.rename(temporary, filePath);
    if (movedPrevious) await fs.rm(previous, { force: true });
  } catch (error) {
    await fs.rm(temporary, { force: true }).catch(() => {});
    if (movedPrevious) await fs.rename(previous, filePath).catch(() => {});
    throw error;
  }
}

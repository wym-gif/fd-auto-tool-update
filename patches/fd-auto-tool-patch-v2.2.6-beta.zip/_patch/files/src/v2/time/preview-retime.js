import { createPreviewTask, validatePreviewTaskShape } from "../contracts/preview-task.js";
import { clockInputToSeconds } from "./clock-input.js";

const DEFAULT_INTERVALS = {
  sameTuo: { min: 20, max: 45 },
  differentTuo: { min: 15, max: 15 },
  media: { min: 30, max: 50 },
  doumaSame: { min: 45, max: 45 },
  roleSwitch: { min: 120, max: 120 }
};

export function retimePreviewTasks(tasks, options = {}) {
  const input = tasks.map((task) => {
    validatePreviewTaskShape(task);
    return createPreviewTask({ ...task });
  });
  const sendableIndexes = input
    .map((task, index) => ({ task, index }))
    .filter(({ task }) => !task.skip)
    .map(({ index }) => index);
  if (!sendableIndexes.length) {
    return { tasks: input, diagnostics: [{ code: "no_sendable_tasks", message: "没有可发送的预览条目，未重排时间。" }] };
  }

  const startSeconds = timeToSeconds(options.startTime);
  if (startSeconds === null) throw new Error("重排时间需要有效开始时间。");
  const endSeconds = timeToSeconds(options.endTime);
  const absoluteEndSeconds = endSeconds === null ? null : endSeconds >= startSeconds ? endSeconds : endSeconds + 86400;
  const baseDate = String(options.startDate || input[sendableIndexes[0]]?.date || "").trim();
  const result = input.map((task) => createPreviewTask({ ...task }));
  const gaps = [];
  let cursor = startSeconds;

  for (let position = 0; position < sendableIndexes.length; position += 1) {
    const taskIndex = sendableIndexes[position];
    const previousIndex = position > 0 ? sendableIndexes[position - 1] : null;
    if (previousIndex !== null) {
      const gap = gapBetween(result[previousIndex], result[taskIndex], options);
      gaps.push(gap);
      cursor += gap;
    }
    const dayDelta = Math.floor(cursor / 86400);
    result[taskIndex] = createPreviewTask({
      ...result[taskIndex],
      date: shiftMonthDay(baseDate, dayDelta) || result[taskIndex].date,
      time: secondsToClock(cursor),
      ...endTimeWarningFields(result[taskIndex], cursor, absoluteEndSeconds)
    });
  }

  return {
    tasks: result,
    diagnostics: [],
    gaps
  };
}

function gapBetween(prev, next, options = {}) {
  if (!prev || !next) return 0;
  if (sameInteractionGroup(prev, next)) return pickInterval("sameTuo", options);
  if (prev.role !== next.role) return pickRoleSwitchInterval(options);
  if (isMedia(prev) || isMedia(next)) {
    if (customInterval("media", options) || !hasAnyCustomIntervals(options)) return pickInterval("media", options);
  }
  if (next.role === "douma") return pickInterval("doumaSame", options);
  if (prev.speaker === next.speaker) return pickInterval("sameTuo", options);
  return pickInterval("differentTuo", options);
}

function pickRoleSwitchInterval(options = {}) {
  if (customInterval("roleSwitch", options)) return pickInterval("roleSwitch", options);
  return Math.max(DEFAULT_INTERVALS.roleSwitch.min, pickInterval("roleSwitch", options));
}

function pickInterval(key, options = {}) {
  const defaults = DEFAULT_INTERVALS[key] || { min: 0, max: 0 };
  const custom = customInterval(key, options);
  const low = Number.isFinite(Number(custom?.min)) ? Number(custom.min) : defaults.min;
  const high = Number.isFinite(Number(custom?.max)) ? Number(custom.max) : defaults.max;
  return Math.round((low + high) / 2);
}

function customInterval(key, options = {}) {
  return options.intervals?.[key];
}

function hasAnyCustomIntervals(options = {}) {
  return Boolean(options.intervals && Object.keys(options.intervals).length);
}

function isMedia(task) {
  return task.type === "image" || task.type === "sticker" || task.type === "video";
}

function sameInteractionGroup(prev, next) {
  return Boolean(prev?.interactionGroup && next?.interactionGroup && prev.interactionGroup === next.interactionGroup);
}

function timeToSeconds(time) {
  return clockInputToSeconds(time);
}

function secondsToClock(totalSeconds) {
  const seconds = ((Math.round(Number(totalSeconds) || 0) % 86400) + 86400) % 86400;
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(Math.floor(seconds / 3600))}:${pad(Math.floor((seconds % 3600) / 60))}:${pad(seconds % 60)}`;
}

function endTimeWarningFields(task, absoluteSeconds, absoluteEndSeconds) {
  const next = { timeOverEnd: false, timeWarning: "" };
  if (absoluteEndSeconds === null || absoluteSeconds <= absoluteEndSeconds) return next;
  const order = task?.order || "";
  return {
    timeOverEnd: true,
    timeWarning: `超过结束时间：第 ${order || "?"} 条 ${secondsToClock(absoluteSeconds)} 晚于 ${secondsToClock(absoluteEndSeconds)}，请调整间隔后再次点击“按间隔重排”。`
  };
}

function shiftMonthDay(value, dayDelta) {
  const text = String(value || "").trim();
  if (!text) return "";
  const match = text.match(/^(\d{1,2})\s*[\/月-]\s*(\d{1,2})\s*日?$/);
  if (!match) return text;
  const date = new Date(new Date().getFullYear(), Number(match[1]) - 1, Number(match[2]));
  if (Number.isNaN(date.getTime())) return text;
  date.setDate(date.getDate() + Number(dayDelta || 0));
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

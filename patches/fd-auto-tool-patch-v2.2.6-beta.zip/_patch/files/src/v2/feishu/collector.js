import fs from "node:fs/promises";
import path from "node:path";
import { normalizeRawEvents } from "../contracts/raw-event.js";
import { isRoleHeader, parseRangeAnchorKeyword } from "../range/locate-range.js";
import { clickFeishuOutlineHeading } from "../range/heading-range.js";
import {
  isRemoteMediaPath,
  isTemporaryBrowserMediaPath,
  localizeMediaItemsFromPage
} from "../media/media-cache.js";
import { collectError } from "./collect-errors.js";

const COLLECT_HEADER_TIME_RE = /(?:(\d{1,2})[\/月](\d{1,2})(?:日)?\s*)?(\d{1,2})[：:](\d{1,2})(?:[：:](\d{1,2}))?/;
const MEDIA_EVENT_TYPES = new Set(["image", "sticker", "video"]);

export async function collectRawEventsFromPage(page, options = {}) {
  const result = await collectRawEventsFromPageWithDiagnostics(page, options);
  return result.events;
}

export async function collectRawEventsFromPageWithDiagnostics(page, options = {}) {
  const overlayClosures = [];
  const firstOverlayClose = await closeFeishuMediaPreviewOverlay(page);
  if (firstOverlayClose.detected) overlayClosures.push({ stage: "before-snapshot", ...firstOverlayClose });
  const snapshot = options.scanFullPage
    ? await readFullPageSnapshot(page, options)
    : await page.evaluate(readPageSnapshot);
  if (Array.isArray(snapshot)) {
    const snapshotWithCopiedFinder = await replaceFinderCodeBlocksWithCopiedXml(page, snapshot, options);
    const localizedSnapshotWithCopiedFinder = await materializeSnapshotMediaFromPage(page, snapshotWithCopiedFinder, options);
    const events = dedupeMaterializedMediaEvents(collectRawEventsFromSnapshot(localizedSnapshotWithCopiedFinder));
    return {
      events,
      diagnostics: buildCollectDiagnostics({
        logs: [collectLogEntry(0, events, options)],
        stoppedBecause: "visible-only",
        finderCodeBlocks: summarizeFinderCodeBlockCopyDiagnostics(options.__finderCodeBlockCopyDiagnostics),
        overlayClosures
      })
    };
  }
  const snapshotItemsWithCopiedFinder = snapshot.finderCodeBlocksReplaced
    ? snapshot.items
    : await replaceFinderCodeBlocksWithCopiedXml(page, snapshot.items, options);
  const rawEvents = collectRawEventsFromSnapshot(snapshotItemsWithCopiedFinder);
  const events = options.deferMediaMaterialization
    ? rawEvents
    : dedupeMaterializedMediaEvents(await materializeCollectedMediaFromPage(page, rawEvents, options));
  return {
    events,
    diagnostics: {
      ...snapshot.diagnostics,
      overlayClosures: [
        ...overlayClosures,
        ...(snapshot.diagnostics?.overlayClosures || [])
      ]
    }
  };
}

export function collectRawEventsFromSnapshot(snapshot = []) {
  const events = normalizeSnapshotItems(snapshot).map((item, index) => {
    const type = inferCollectedItemType(item);
    return {
      sourceId: item.sourceId || `feishu-block-${index + 1}`,
      kind: type,
      type,
      text: String(item.text || ""),
      sourceText: String(item.sourceText || item.text || ""),
      highlighted: Boolean(item.highlighted),
      assetUrl: String(item.assetUrl || item.src || ""),
      mediaPath: String(item.mediaPath || item.assetUrl || item.src || ""),
      sourceUrl: String(item.sourceUrl || item.originalMediaPath || item.originalBlobMediaPath || item.assetUrl || item.src || ""),
      inlineMediaDataUrl: String(item.inlineMediaDataUrl || item.raw?.inlineMediaDataUrl || ""),
      inlineMediaMime: String(item.inlineMediaMime || item.raw?.inlineMediaMime || ""),
      materializedHash: String(item.materializedHash || item.raw?.materializedHash || ""),
      collectSpeaker: String(item.collectSpeaker || ""),
      collectTime: String(item.collectTime || ""),
      previewError: String(item.previewError || item.raw?.previewError || ""),
      previewWarning: String(item.previewWarning || item.raw?.previewWarning || ""),
      blockIndex: Number.isFinite(Number(item.blockIndex)) ? Number(item.blockIndex) : index,
      boundingInfo: normalizeBoundingInfo(item.boundingInfo),
      y: Number.isFinite(Number(item.y)) ? Number(item.y) : index,
      order: index
    };
  });
  return normalizeRawEvents(events);
}

export function validateCollectedRawEvents(events = [], checks = {}) {
  const normalized = collectRawEventsFromSnapshot(events);
  const withCollectContext = attachCollectContext(normalized);
  if (!checks.allowTemporaryMedia) {
    const temporaryMedia = withCollectContext.filter((event) => {
      const type = inferCollectedItemType(event);
      return MEDIA_EVENT_TYPES.has(type) && isTemporaryBrowserMediaPath(event.mediaPath || event.assetUrl);
    });
    if (temporaryMedia.length) {
      const details = temporaryMedia
        .slice(0, 5)
        .map(formatTemporaryMediaFailure)
        .join("；");
      throw collectError("temporary_media_url", `采到了浏览器临时素材地址，不能生成正式预览。请重新真实采集；如果仍出现，说明飞书页面没有暴露真实素材地址：${details}`);
    }
  }
  if (checks.requireLocalMedia) {
    const remoteMedia = withCollectContext.filter((event) => {
      const type = inferCollectedItemType(event);
      return MEDIA_EVENT_TYPES.has(type) && isRemoteMediaPath(event.mediaPath || event.assetUrl);
    });
    if (remoteMedia.length) {
      const details = remoteMedia
        .slice(0, 5)
        .map(formatRemoteMediaFailure)
        .join("；");
      throw collectError("remote_media_not_localized", `采到了飞书远程素材地址但没有落地到本地 media-cache，不能生成正式预览：${details}`);
    }
  }
  if (checks.startKeyword && !containsKeyword(normalized, checks.startKeyword)) {
    throw collectError("missing_start_keyword", "没有采到开始关键词");
  }
  if (checks.endKeyword && !containsKeyword(normalized, checks.endKeyword)) {
    throw collectError("missing_end_keyword", "没有采到结束关键词");
  }
  if (checks.requireFirstImage && !firstContentImageExists(normalized)) {
    throw collectError("missing_first_image", "没有采到第一张图片");
  }
  if (checks.requireSticker && !normalized.some((event) => event.type === "sticker" || event.kind === "sticker")) {
    throw collectError("missing_sticker", "没有采到表情包");
  }
  if (checks.requireVideo && !normalized.some((event) => event.type === "video" || event.kind === "video")) {
    throw collectError("missing_video", "没有采到视频");
  }
  return normalized;
}

export async function materializeRawEventMediaFromPage(page, events = [], options = {}) {
  return collectRawEventsFromSnapshot(await materializeCollectedMediaFromPage(page, events, options));
}

async function materializeCollectedMediaFromPage(page, events = [], options = {}) {
  return localizeMediaItemsFromPage(page, events, {
    ...options,
    mediaCacheDir: mediaCacheDirFromOptions(options),
    getType: inferCollectedItemType
  });
}

async function materializeSnapshotMediaFromPage(page, items = [], options = {}) {
  return localizeMediaItemsFromPage(page, items, {
    ...options,
    mediaCacheDir: mediaCacheDirFromOptions(options),
    getType: inferCollectedItemType
  });
}

function mediaCacheDirFromOptions(options = {}) {
  return options.mediaCacheDir || options.blobMediaDir || options.materializeBlobMediaDir || "";
}

export async function saveRawEvents(runRoot, events, options = {}) {
  const runDir = path.join(runRoot, options.runName || `v2_collect_${timestamp()}`);
  await fs.mkdir(runDir, { recursive: true });
  const filePath = path.join(runDir, "raw-events.json");
  await fs.writeFile(filePath, JSON.stringify(events, null, 2), "utf8");
  return { runDir, filePath };
}

export function summarizeRawEvents(events = []) {
  const summary = {
    total: events.length,
    line: 0,
    title: 0,
    image: 0,
    sticker: 0,
    video: 0,
    divider: 0,
    firstEvent: events[0] || null,
    lastEvent: events.at(-1) || null
  };
  for (const event of events) {
    const type = event.type || event.kind;
    if (Object.prototype.hasOwnProperty.call(summary, type)) summary[type] += 1;
  }
  return summary;
}

async function readPageSnapshot() {
  const normalize = (text) => String(text || "").replace(/\u200b/g, "").replace(/\u00a0/g, " ").trim();
  const isVisible = (el) => {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  };
  const yellowish = (color) => {
    const nums = String(color || "").match(/\d+/g)?.map(Number) || [];
    if (nums.length < 3) return false;
    const [r, g, b] = nums;
    return r > 180 && g > 150 && b < 170;
  };
  const hasYellow = (el) => {
    const nodes = [el, ...Array.from(el.querySelectorAll("*"))];
    return nodes.some((node) => {
      const style = getComputedStyle(node);
      return yellowish(style.backgroundColor) || yellowish(style.background);
    });
  };
  const sourceIdFor = (el, index) => (
    el.getAttribute("data-source-id") ||
    el.getAttribute("data-block-id") ||
    el.getAttribute("data-id") ||
    el.getAttribute("data-uuid") ||
    el.getAttribute("id") ||
    `dom-block-${index + 1}`
  );
  const readSrc = (el) => {
    const candidates = [];
    const push = (value, weight = 0) => {
      for (const url of extractMediaUrls(value)) {
        if (!url) continue;
        candidates.push({ url, weight });
      }
    };
    const collectFromElement = (node, weight = 0) => {
      if (!node) return;
      push(node.currentSrc, weight + 8);
      push(node.src, weight + 7);
      push(node.href, weight + 5);
      push(node.poster, weight + 5);
      push(node.getAttribute?.("src"), weight + 6);
      push(node.getAttribute?.("href"), weight + 4);
      push(node.getAttribute?.("poster"), weight + 4);
      push(node.getAttribute?.("srcset"), weight + 6);
      push(node.getAttribute?.("data-src"), weight + 12);
      push(node.getAttribute?.("data-origin-src"), weight + 14);
      push(node.getAttribute?.("data-original-src"), weight + 14);
      push(node.getAttribute?.("data-original"), weight + 12);
      push(node.getAttribute?.("data-download"), weight + 12);
      push(node.getAttribute?.("data-url"), weight + 12);
      push(node.getAttribute?.("data-file-url"), weight + 12);
      push(node.getAttribute?.("data-preview-url"), weight + 12);
      push(node.getAttribute?.("data-token"), weight + 8);
      const computedStyle = getComputedStyle(node);
      push(computedStyle.backgroundImage, weight + 6);
      for (const attr of Array.from(node.attributes || [])) {
        const name = String(attr.name || "").toLowerCase();
        if (
          name.startsWith("data-") ||
          ["src", "href", "poster", "srcset", "style", "aria-label", "title"].includes(name)
        ) {
          push(attr.value, weight + (name.startsWith("data-") ? 10 : 3));
        }
      }
    };

    collectFromElement(el, 20);
    for (const child of Array.from(el.querySelectorAll?.("video,source,img,a,[data-src],[data-origin-src],[data-original-src],[data-url],[data-original],[data-download],[data-file-url],[data-preview-url]") || [])) {
      collectFromElement(child, 10);
    }
    let parent = el.parentElement;
    for (let depth = 0; parent && depth < 4; depth += 1, parent = parent.parentElement) {
      collectFromElement(parent, 2 - depth);
    }

    const unique = [];
    for (const candidate of candidates) {
      if (!unique.some((item) => item.url === candidate.url)) unique.push(candidate);
    }
    unique.sort((a, b) => mediaUrlScore(b.url, b.weight) - mediaUrlScore(a.url, a.weight));
    return unique[0]?.url || "";
  };
  const toItem = async (el, index) => {
    const rect = el.getBoundingClientRect();
    const y = absoluteYFor(el, rect);
    const explicitKind = el.getAttribute("data-v2-kind");
    const tag = el.tagName.toLowerCase();
    const type = inferTypeInPage(el, explicitKind || tag);
    const src = readSrc(el);
    const childBlockCount = countChildBlocks(el);
    const sourceText = normalize(el.innerText || el.textContent || "");
    const finderXmlText = type === "line" ? extractFinderXmlFromCodeBlock(el) : "";
    return {
      sourceId: sourceIdFor(el, index),
      type,
      text: type === "image" || type === "sticker" || type === "video" ? "" : (finderXmlText || sourceText),
      sourceText,
      mediaPath: type === "image" || type === "sticker" || type === "video" ? src : "",
      assetUrl: src,
      inlineMediaDataUrl: type === "image" || type === "sticker" || type === "video" ? await inlineMediaDataUrlFromElement(el, type, src) : "",
      highlighted: hasYellow(el),
      childBlockCount,
      blockIndex: index,
      order: index,
      y,
      boundingInfo: {
        x: rect.x,
        y,
        width: rect.width,
        height: rect.height
      }
    };
  };
  const selectors = [
    "h1",
    "h2",
    "h3",
    ".ace-line",
    "[class*='ace-line']",
    "[data-block-id]",
    "[data-uuid]",
    "[data-offset-key]",
    "[contenteditable='true'] p",
    "[contenteditable='true'] div",
    "img",
    "video",
    "source[type*='video']",
    ".docx-file-block",
    ".file-block",
    "[class*='preview-type-video']",
    "[class*='is-in-video']",
    "[class*='xgplayer']",
    "[class*='video']",
    "[data-card-type*='video']",
    "[data-type*='video']",
    "pre",
    "code",
    "[class*='code-block' i]",
    "[class*='codeblock' i]",
    "[class*='code_block' i]",
    "[class*='codeMirror' i]",
    "[class*='cm-editor' i]",
    "hr",
    "[data-v2-kind]"
  ].join(",");
  const editorRoots = [
    "[data-v2-feishu-fixture]",
    "[class*='editor']",
    "[class*='docx']",
    "[contenteditable='true']",
    "main",
    "article",
    "body"
  ].map((selector) => document.querySelector(selector)).filter(Boolean);
  const root = chooseSnapshotRoot(editorRoots, selectors);
  const elements = Array.from(new Set(root.querySelectorAll(selectors)))
    .filter(isVisible)
    .filter((el) => !isChromeNoise(el))
    .filter((el) => !isInMediaPreviewOverlay(el))
    .filter((el) => !isNestedCodeBlockElement(el));
  const items = (await Promise.all(elements.map(toItem)))
    .filter((item) => item.text || item.mediaPath || item.type === "divider" || isDocumentBlankLineItem(item))
    .filter((item) => !isContainerItem(item))
    .sort((a, b) => a.y - b.y || a.blockIndex - b.blockIndex);
  const collected = dropMediaPlaceholderLines(markImagesWithNearbyStickerPlaceholderInPage(dedupeCollectedItems(attachCollectContextInPage(items))));
  await attachInlineBlobMediaData(collected);
  return collected.map((item, index) => ({ ...item, order: index }));

  function absoluteYFor(el, rect) {
    const scrollParent = nearestScrollParent(el) || root;
    if (scrollParent && scrollParent !== document.body && scrollParent !== document.documentElement) {
      const parentRect = scrollParent.getBoundingClientRect();
      return rect.top - parentRect.top + scrollParent.scrollTop;
    }
    return rect.top + window.scrollY;
  }

  function nearestScrollParent(el) {
    let current = el?.parentElement;
    while (current && current !== document.body && current !== document.documentElement) {
      const style = getComputedStyle(current);
      if (/(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && current.scrollHeight > current.clientHeight + 20) {
        return current;
      }
      current = current.parentElement;
    }
    return null;
  }

  function inferTypeInPage(el, value) {
    const name = String(value || "").toLowerCase();
    const src = readSrc(el);
    const classTextForVideo = `${el.className || ""} ${el.closest("[class*='video']")?.className || ""}`.toLowerCase();
    const textForVideo = normalize(el.innerText || el.textContent || "").toLowerCase();
    const attrsForVideo = [
      el.getAttribute("data-card-type"),
      el.getAttribute("data-type"),
      el.getAttribute("data-file-type"),
      el.getAttribute("aria-label"),
      el.getAttribute("title")
    ].filter(Boolean).join(" ").toLowerCase();
    if (/preview-type-video|is-in-video|xgplayer|video|视频/.test(`${classTextForVideo} ${attrsForVideo}`)) return "video";
    if (/^video\(.+\)|\.mp4|点击按住可拖动视频|进入全屏/.test(textForVideo)) return "video";
    const mediaClassText = `${el.className || ""} ${el.closest("[class]")?.className || ""}`.toLowerCase();
    const mediaAttrs = [
      el.getAttribute("data-card-type"),
      el.getAttribute("data-type"),
      el.getAttribute("data-file-type"),
      el.getAttribute("aria-label"),
      el.getAttribute("title")
    ].filter(Boolean).join(" ").toLowerCase();
    if (src && /docx-image|image-block|image|img|picture|图片/.test(`${mediaClassText} ${mediaAttrs}`)) {
      if (/\.gif(?:\?|#|$)/i.test(src) || /sticker|emoji|emoticon|表情/.test(`${mediaClassText} ${mediaAttrs}`)) return "sticker";
      return "image";
    }
    if (src && /^(blob:|image-blob:|data:image\/)/i.test(src)) return "image";
    if (src && isStickerMarkerTextInPage(normalize(el.innerText || el.textContent || ""))) return "sticker";
    if (src && /^视频$/.test(normalize(el.innerText || el.textContent || ""))) return "video";
    if (name === "h1" || name === "h2" || name === "h3" || name === "title") return "title";
    if (name === "hr" || name === "divider") return "divider";
    if (name === "video" || name === "source") return "video";
    if (name === "sticker") return "sticker";
    if (name === "img" || name === "image") {
      const alt = `${el.getAttribute("alt") || ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
      const classText = `${el.className || ""} ${el.closest("[class]")?.className || ""}`.toLowerCase();
      if (/\.gif(?:\?|#|$)/i.test(src) || /sticker|emoji|emoticon|表情/.test(`${alt} ${classText}`)) return "sticker";
      if (el.closest("video,[class*='video'],[data-card-type*='video'],[data-type*='video']")) return "video";
      return "image";
    }
    return "line";
  }

  function extractFinderXmlFromCodeBlock(el) {
    if (!el || !isCodeBlockElement(el)) return "";
    return extractFinderXmlFromText(el.innerText || el.textContent || "");
  }

  function isCodeBlockElement(el) {
    const tag = String(el.tagName || "").toLowerCase();
    if (tag === "pre" || tag === "code") return true;
    const classText = String(el.className || "");
    const role = String(el.getAttribute?.("role") || "");
    const attrs = [
      el.getAttribute?.("data-lang"),
      el.getAttribute?.("data-language"),
      el.getAttribute?.("data-code"),
      el.getAttribute?.("data-block-type"),
      el.getAttribute?.("data-card-type"),
      el.getAttribute?.("aria-label"),
      el.getAttribute?.("title")
    ].filter(Boolean).join(" ");
    return /code|hljs|cm-editor|codemirror|代码/i.test(`${classText} ${role} ${attrs}`);
  }

  function isNestedCodeBlockElement(el) {
    if (!isCodeBlockElement(el)) return false;
    let parent = el.parentElement;
    while (parent && parent !== root) {
      if (isCodeBlockElement(parent) && isVisible(parent)) return true;
      parent = parent.parentElement;
    }
    return false;
  }

  function extractFinderXmlFromText(value) {
    const raw = String(value || "")
      .replace(/\r\n?/g, "\n")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&amp;/g, "&");
    if (!looksLikeFinderXml(raw)) return "";
    const cleanedLines = raw.split("\n")
      .map((line) => line.replace(/^\s*\d+\s(?=\s*(?:<|\{))/, "").trimEnd())
      .filter((line) => {
        const text = normalize(line);
        if (!text) return true;
        return !/^(示例代码|复制|自动换行|Python|JavaScript|Markdown|代码块)$/.test(text);
      });
    const start = cleanedLines.findIndex((line) => /^\s*(?:<\?xml\b|<msg\b)/i.test(line));
    if (start < 0) return "";
    let end = cleanedLines.length - 1;
    for (let index = cleanedLines.length - 1; index >= start; index -= 1) {
      if (/<\/msg>\s*$/i.test(cleanedLines[index]) || /<\/appmsg>\s*$/i.test(cleanedLines[index])) {
        end = index;
        break;
      }
    }
    const xml = cleanedLines.slice(start, end + 1).join("\n").trim();
    return looksLikeFinderXml(xml) ? xml : "";
  }

  function looksLikeFinderXml(value) {
    const text = String(value || "");
    return /<msg\b/i.test(text) &&
      /<appmsg\b/i.test(text) &&
      (/<finderFeed\b/i.test(text) || /<type>\s*51\s*<\/type>/i.test(text));
  }

  async function inlineMediaDataUrlFromElement(el, type, src) {
    if (!/^blob:/i.test(String(src || ""))) return "";
    try {
      const image = el.tagName?.toLowerCase() === "img" ? el : el.querySelector?.("img");
      if (image?.complete && image.naturalWidth > 0 && image.naturalHeight > 0) {
        return imageElementToDataUrl(image, type);
      }
      const canvas = el.tagName?.toLowerCase() === "canvas" ? el : el.querySelector?.("canvas");
      if (canvas?.width > 0 && canvas?.height > 0) {
        return canvas.toDataURL(type === "sticker" ? "image/gif" : "image/png");
      }
      const blobDataUrl = await blobUrlToDataUrlWithXhr(src, type);
      if (blobDataUrl) return blobDataUrl;
      return await blobImageUrlToDataUrl(src, type);
    } catch {
      // Keep the blob URL. Node-side validation reports unresolved media if normal blob fetch also fails.
    }
    return "";
  }

  function imageElementToDataUrl(image, type) {
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const context = canvas.getContext("2d");
    context.drawImage(image, 0, 0);
    return canvas.toDataURL(type === "sticker" ? "image/gif" : "image/png");
  }

  async function blobUrlToDataUrlWithXhr(src, type) {
    if (type === "video") return "";
    return await new Promise((resolve) => {
      try {
        const request = new XMLHttpRequest();
        request.open("GET", src, true);
        request.responseType = "blob";
        request.onload = () => {
          const blob = request.response;
          if (!blob || !blob.size) {
            resolve("");
            return;
          }
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ""));
          reader.onerror = () => resolve("");
          reader.readAsDataURL(blob);
        };
        request.onerror = () => resolve("");
        request.ontimeout = () => resolve("");
        request.timeout = 2500;
        request.send();
      } catch {
        resolve("");
      }
    });
  }

  async function blobImageUrlToDataUrl(src, type) {
    if (type === "video") return "";
    const image = new Image();
    const loaded = new Promise((resolve, reject) => {
      image.onload = () => resolve(true);
      image.onerror = () => reject(new Error("blob image decode failed"));
    });
    image.src = src;
    await loaded;
    if (!image.naturalWidth || !image.naturalHeight) return "";
    return imageElementToDataUrl(image, type);
  }

  function isChromeNoise(el) {
    const text = normalize(el.innerText || el.textContent || "");
    if (!text) return false;
    if (isCodeBlockElement(el) && looksLikeFinderXml(text)) return false;
    if (text.length > 500) return true;
    const role = el.getAttribute("role") || "";
    if (role === "button" || role === "menuitem" || role === "dialog") return true;
    const classText = String(el.className || "").toLowerCase();
    return /toolbar|menu|sidebar|comment|popover|tooltip|header|footer/.test(classText);
  }

  function isInMediaPreviewOverlay(el) {
    const overlay = el.closest("[role='dialog'],[class*='modal' i],[class*='preview' i],[class*='player' i],[class*='xgplayer' i],[class*='viewer' i]");
    if (!overlay) return false;
    const classText = String(overlay.className || "").toLowerCase();
    const role = overlay.getAttribute("role") || "";
    const style = getComputedStyle(overlay);
    const rect = overlay.getBoundingClientRect();
    const fixedLayer = style.position === "fixed" || rect.width >= window.innerWidth * 0.45 && rect.height >= window.innerHeight * 0.35;
    const mediaLike = overlay.querySelector("video,img,canvas,[class*='xgplayer' i],[class*='player' i],[class*='preview' i]") ||
      /xgplayer|player|viewer|preview|modal|image|video|media|图片|视频/.test(classText);
    if (role === "dialog" && mediaLike && fixedLayer) return true;
    return Boolean(mediaLike && fixedLayer && (style.zIndex === "auto" || Number(style.zIndex) >= 100 || /modal|preview|viewer|player/.test(classText)));
  }

  function countChildBlocks(el) {
    return el.querySelectorAll([
      "h1",
      "h2",
      "h3",
      ".ace-line",
      "[class*='ace-line']",
      "[data-block-id]",
      "[data-uuid]",
      "img",
      "video",
      ".docx-file-block",
      ".file-block",
      "[class*='preview-type-video']",
      "hr",
      "[data-v2-kind]"
    ].join(",")).length;
  }

  function isContainerItem(item) {
    if (item.type !== "line" && item.type !== "title") return false;
    if (item.childBlockCount <= 1) return false;
    const text = normalize(item.text);
    const lineCount = text.split(/\n+/).filter(Boolean).length;
    return lineCount > 1 || text.length > 300;
  }

  function dedupeCollectedItems(items) {
    const result = [];
    for (const item of items) {
      const duplicateIndex = result.findIndex((existing) => sameVisibleBlock(existing, item));
      if (duplicateIndex === -1) {
        result.push(item);
        continue;
      }
      const existing = result[duplicateIndex];
      if (item.type === "title" && existing.type === "line") {
        result[duplicateIndex] = item;
      } else if (item.type === "video" && existing.type === "video" && preferVideoItem(item, existing)) {
        result[duplicateIndex] = item;
      }
    }
    return result.map((item, index) => ({ ...item, order: index, blockIndex: index }));
  }

  function dropMediaPlaceholderLines(items) {
    return items
      .filter((item, index) => {
        if (item.type !== "line") return true;
        const text = normalize(item.text);
        if (!isMediaPlaceholderTextInPage(text)) return true;
        return !items.some((other, otherIndex) => (
          otherIndex !== index &&
          ((isStickerMarkerTextInPage(text) && other.type === "sticker") || (text === "视频" && other.type === "video")) &&
          (
            sameCollectContextInPage(item, other) ||
            Math.abs(Number(other.y || 0) - Number(item.y || 0)) <= 220 ||
            Math.abs(Number(other.order ?? other.blockIndex ?? 0) - Number(item.order ?? item.blockIndex ?? 0)) <= 2
          )
        ));
      })
      .map((item, index) => ({ ...item, order: index, blockIndex: index }));
  }

  function isMediaPlaceholderTextInPage(text) {
    return isStickerMarkerTextInPage(text) || text === "视频";
  }

  function isStickerMarkerTextInPage(text) {
    return text === "表情包" || text === "动态表情";
  }

  function markImagesWithNearbyStickerPlaceholderInPage(items) {
    return items.map((item, index) => {
      if (item.type !== "image") return item;
      const marker = items.find((other, otherIndex) => (
        otherIndex !== index &&
        other.type === "line" &&
        isStickerMarkerTextInPage(normalize(other.text || other.sourceText)) &&
        (
          sameCollectContextInPage(item, other) ||
          Math.abs(Number(other.y || 0) - Number(item.y || 0)) <= 220 ||
          Math.abs(Number(other.order ?? other.blockIndex ?? 0) - Number(item.order ?? item.blockIndex ?? 0)) <= 2
        )
      ));
      if (!marker) return item;
      return {
        ...item,
        type: "sticker",
        kind: "sticker",
        sourceText: item.sourceText || marker.text || marker.sourceText || "动态表情"
      };
    });
  }

  function sameVisibleBlock(a, b) {
    const textA = normalizeSearchTextInPage(a.text || a.sourceText);
    const textB = normalizeSearchTextInPage(b.text || b.sourceText);
    const mediaA = String(a.mediaPath || a.assetUrl || "");
    const mediaB = String(b.mediaPath || b.assetUrl || "");
    const sameContent = mediaA || mediaB ? mediaA && mediaA === mediaB : textA && textA === textB;
    if (sameTitleAndLineInPage(a, b) && sameContent) {
      return Math.abs(Number(a.y || 0) - Number(b.y || 0)) <= 80;
    }
    if (a.type === "video" && b.type === "video") {
      return Math.abs(Number(a.y || 0) - Number(b.y || 0)) <= 100;
    }
    if (!sameContent) return false;
    if (mediaA || mediaB) return sameCollectContextInPage(a, b) || Math.abs(Number(a.y || 0) - Number(b.y || 0)) <= 80;
    return sameCollectContextInPage(a, b) && sameTextBlockIdentityInPage(a, b);
  }

  function normalizeSearchTextInPage(value) {
    return normalize(value).replace(/\s+/g, "");
  }

  function isDocumentBlankLineItem(item) {
    if ((item.type || item.kind) !== "line") return false;
    if (normalize(item.text || item.sourceText || "")) return false;
    const box = item.boundingInfo || {};
    return Number(box.height) > 0 && Number(box.width) >= 0;
  }

  function sameTextBlockIdentityInPage(a, b) {
    return sameExactVisualPositionInPage(a, b) || sameStableSourceIdInPage(a, b);
  }

  function sameStableSourceIdInPage(a, b) {
    const idA = String(a?.sourceId || "");
    const idB = String(b?.sourceId || "");
    return Boolean(idA && idB && idA === idB && !idA.startsWith("dom-block-"));
  }

  function sameExactVisualPositionInPage(a, b) {
    const boxA = a.boundingInfo || {};
    const boxB = b.boundingInfo || {};
    const yA = Number(a.y ?? boxA.y);
    const yB = Number(b.y ?? boxB.y);
    const xA = Number(boxA.x);
    const xB = Number(boxB.x);
    if (!Number.isFinite(yA) || !Number.isFinite(yB) || Math.abs(yA - yB) > 1) return false;
    if (Number.isFinite(xA) && Number.isFinite(xB) && Math.abs(xA - xB) > 1) return false;
    const hA = Number(boxA.height);
    const hB = Number(boxB.height);
    const wA = Number(boxA.width);
    const wB = Number(boxB.width);
    return (!Number.isFinite(hA) || !Number.isFinite(hB) || Math.abs(hA - hB) <= 1) &&
      (!Number.isFinite(wA) || !Number.isFinite(wB) || Math.abs(wA - wB) <= 1);
  }

  function preferVideoItem(candidate, current) {
    return videoMediaScore(candidate.mediaPath || candidate.assetUrl) > videoMediaScore(current.mediaPath || current.assetUrl);
  }

  function videoMediaScore(value) {
    const src = String(value || "").toLowerCase();
    if (/^(blob:|image-blob:)/.test(src)) return 0;
    if (/\/video\/|\.mp4(?:\?|#|$)|quality=/.test(src)) return 3;
    if (src) return 1;
    return 0;
  }

  function extractMediaUrls(value) {
    const raw = String(value || "").trim();
    if (!raw) return [];
    const normalized = raw.replace(/\\\//g, "/").replace(/&amp;/g, "&");
    const urls = [];
    const add = (url) => {
      const cleaned = String(url || "").trim().replace(/[),;]+$/, "");
      if (cleaned && !urls.includes(cleaned)) urls.push(cleaned);
    };
    if (/^(blob:|image-blob:|https?:|file:|sample:|data:image\/)/i.test(normalized)) add(normalized.split(/\s+\d+[wx](?:,|$)/)[0]);
    for (const part of normalized.split(",")) {
      const srcsetUrl = part.trim().split(/\s+/)[0];
      if (/^(blob:|image-blob:|https?:|file:|sample:|data:image\/)/i.test(srcsetUrl)) add(srcsetUrl);
    }
    const matches = normalized.match(/(?:https?:|blob:|image-blob:|file:|sample:|data:image\/)[^\s"'<>\\]+/gi) || [];
    for (const match of matches) add(match);
    return urls;
  }

  function mediaUrlScore(url, weight = 0) {
    const src = String(url || "").toLowerCase();
    if (!src) return 0;
    let score = weight;
    if (/^(blob:|image-blob:)/.test(src)) score -= 1000;
    if (/internal-api-drive-stream\.feishu\.cn|\/space\/api\/box\/stream\/download\//.test(src)) score += 120;
    if (/\/video\/|\.mp4(?:\?|#|$)|quality=/.test(src)) score += 60;
    if (/\/v2\/cover\//.test(src)) score += 50;
    if (/\/preview\//.test(src)) score += 40;
    if (/\.(?:jpe?g|png|gif|webp|bmp|mp4|mov|webm)(?:[?#]|$)/.test(src)) score += 35;
    if (/^(https?:|file:|sample:|data:image\/)/.test(src)) score += 20;
    return score;
  }

  async function attachInlineBlobMediaData(items) {
    for (const item of items) {
      if (!["image", "sticker", "video"].includes(item.type)) continue;
      const source = String(item.mediaPath || item.assetUrl || "");
      if (!/^blob:/i.test(source)) continue;
      try {
        const response = await fetch(source);
        if (!response.ok) continue;
        const blob = await response.blob();
        const buffer = await blob.arrayBuffer();
        item.inlineMediaDataUrl = `data:${blob.type || mimeForItem(item)};base64,${arrayBufferToBase64(buffer)}`;
        item.inlineMediaMime = blob.type || "";
      } catch {
        // Keep the blob URL. Node-side validation reports the exact unresolved media item.
      }
    }
  }

  function mimeForItem(item) {
    if (item.type === "video") return "video/mp4";
    if (item.type === "sticker") return "image/gif";
    return "image/png";
  }

  function arrayBufferToBase64(buffer) {
    let binary = "";
    const bytes = new Uint8Array(buffer);
    const chunkSize = 0x8000;
    for (let offset = 0; offset < bytes.length; offset += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
    }
    return btoa(binary);
  }

  function chooseSnapshotRoot(roots, selectors) {
    if (!roots.length) return document.body;
    const scored = roots.map((root) => ({
      root,
      score: root.querySelectorAll(selectors).length,
      mediaScore: root.querySelectorAll("img,video,.docx-file-block,.file-block,[class*='video']").length
    }));
    scored.sort((a, b) => (b.score + b.mediaScore * 3) - (a.score + a.mediaScore * 3));
    return scored[0]?.root || document.body;
  }

  function attachCollectContextInPage(items) {
    let current = { speaker: "", time: "" };
    return items.map((item) => {
      const header = parseCollectHeaderInPage(item);
      if (header) current = header;
      return {
        ...item,
        collectSpeaker: header?.speaker || current.speaker || "",
        collectTime: header?.time || current.time || ""
      };
    });
  }

  function parseCollectHeaderInPage(item) {
    if ((item.type || item.kind) !== "line") return null;
    const text = normalize(item.text || item.sourceText || "");
    if (!text || /^https?:\/\//i.test(text)) return null;
    const withoutHint = text
      .replace(/（[^）]*下面还说话[^）]*）/g, "")
      .replace(/\([^)]*下面还说话[^)]*\)/g, "")
      .replace(/【[^】]*下面还说话[^】]*】/g, "")
      .replace(/\[[^\]]*下面还说话[^\]]*\]/g, "")
      .replace(/下面还说话/g, "")
      .trim();
    const timeMatch = withoutHint.match(/(?:(\d{1,2})[\/月](\d{1,2})(?:日)?\s*)?(\d{1,2})[：:](\d{1,2})(?:[：:](\d{1,2}))?/);
    if (!timeMatch) return null;
    const speaker = cleanCollectSpeakerTextInPage(withoutHint.slice(0, timeMatch.index));
    if (!speaker) return null;
    return {
      speaker: speaker.replace(/\s+/g, ""),
      time: `${String(timeMatch[3]).padStart(2, "0")}:${String(timeMatch[4]).padStart(2, "0")}:${String(timeMatch[5] || "00").padStart(2, "0")}`
    };
  }

  function sameCollectContextInPage(a, b) {
    const speakerA = normalize(String(a.collectSpeaker || "")).replace(/\s+/g, "");
    const speakerB = normalize(String(b.collectSpeaker || "")).replace(/\s+/g, "");
    const timeA = String(a.collectTime || "");
    const timeB = String(b.collectTime || "");
    return Boolean(speakerA && speakerB && speakerA === speakerB && timeA && timeB && timeA === timeB);
  }

  function cleanCollectSpeakerTextInPage(value) {
    return normalize(value)
      .replace(/(?:[:：]|[!！?？])+\s*[(（]\s*$/, "")
      .replace(/[，,。；;：:]+$/, "")
      .trim();
  }

  function sameTitleAndLineInPage(a, b) {
    const pair = new Set([a.type || a.kind, b.type || b.kind]);
    return pair.has("title") && pair.has("line");
  }
}

async function readFullPageSnapshot(page, options = {}) {
  const stepPixels = Number(options.stepPixels || 850);
  const waitMs = Number(options.waitMs || 650);
  const maxSteps = Number(options.maxSteps || 80);
  const rescanPasses = Math.max(1, Number(options.rescanPasses ?? 2));
  const isRangeCollect = Boolean(options.startKeyword || options.endKeyword);
  const snapshots = [];
  const logs = [];
  const keywordJumps = [];
  const overlayClosures = [];
  let bottomConfirmations = 0;
  let stoppedBecause = "max-steps";
  const requireDocumentEnd = Boolean(options.requireDocumentEnd);

  if (isRangeCollect && options.startKeyword) {
    const startJump = await jumpToFeishuDocumentKeyword(page, options.startKeyword, "start", {
      maxFocusScans: options.requireStartKeywordSearch ? 4 : undefined,
      allowOutlineHeadingJump: !options.requireStartKeywordSearch,
      diagnosticsDir: options.diagnosticsDir,
      mediaCacheDir: options.mediaCacheDir
    });
    keywordJumps.push(startJump);
    if (options.requireStartKeywordSearch && !startJump.foundVisibleAfterJump) {
      if (shouldUseStartKeywordFallback(startJump)) {
        const fallback = await fallbackLocateKeywordFromCollectedText(page, {
          ...options,
          keyword: options.startKeyword,
          label: "start"
        }, {
          snapshots,
          logs,
          keywordJumps,
          overlayClosures,
          stepPixels,
          waitMs,
          maxSteps
        });
        startJump.fallback = fallback.summary;
        if (fallback.found) {
          startJump.foundVisibleAfterJump = true;
          startJump.visibleMatch = fallback.visibleMatch;
          startJump.reason = `${startJump.reason || "飞书文档内查找失败"}；${fallback.reason}`;
        } else {
          const diagnostics = buildCollectDiagnostics({
            logs,
            stoppedBecause: "start-keyword-search-failed",
            startKeyword: options.startKeyword,
            endKeyword: options.endKeyword,
            keywordJumps,
            finderCodeBlocks: summarizeFinderCodeBlockCopyDiagnostics(options.__finderCodeBlockCopyDiagnostics),
            overlayClosures
          });
          diagnostics.failure = fallback.reason;
          return { items: [], diagnostics };
        }
      } else {
        const diagnostics = buildCollectDiagnostics({
          logs: [collectLogEntry(0, [], options, null, keywordJumps)],
          stoppedBecause: "start-keyword-search-failed",
          startKeyword: options.startKeyword,
          endKeyword: options.endKeyword,
          keywordJumps,
          finderCodeBlocks: summarizeFinderCodeBlockCopyDiagnostics(options.__finderCodeBlockCopyDiagnostics),
          overlayClosures
        });
        diagnostics.failure = `开始位置搜索定位失败：${startJump.reason || "没有通过飞书文档内查找命中开始位置"}`;
        return { items: [], diagnostics };
      }
    }
  } else {
    await page.evaluate(() => {
      window.scrollTo(0, 0);
      const candidates = Array.from(document.querySelectorAll("*"))
        .filter((el) => {
          const style = getComputedStyle(el);
          return /(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && el.scrollHeight > el.clientHeight + 20;
        })
        .sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight));
      for (const el of candidates.slice(0, 4)) el.scrollTop = 0;
    }).catch(() => {});
  }
  const initialOverlayClose = await closeFeishuMediaPreviewOverlay(page);
  if (initialOverlayClose.detected) overlayClosures.push({ stage: "before-full-scan", ...initialOverlayClose });
  await page.waitForTimeout(waitMs).catch(() => {});

  for (let pass = 1; pass <= rescanPasses; pass += 1) {
    const passSnapshots = pass === 1 ? snapshots : [];
    const scanResult = await scanFullPagePass(page, {
      options,
      snapshots: passSnapshots,
      logs,
      keywordJumps,
      overlayClosures,
      pass,
      stepPixels,
      waitMs,
      maxSteps,
      isRangeCollect,
      requireDocumentEnd,
      bottomConfirmations: pass === 1 ? bottomConfirmations : 0
    });
    stoppedBecause = scanResult.stoppedBecause || stoppedBecause;
    if (pass === 1) bottomConfirmations = scanResult.bottomConfirmations;
    if (pass > 1) {
      mergeSnapshotItems(snapshots, passSnapshots);
      const mergedEvents = collectRawEventsFromSnapshot(snapshots);
      logs.push(collectLogEntry(logs.length, mergedEvents, { ...options, collectPass: pass, collectPhase: "merged" }, null, keywordJumps));
    }
    if (pass >= rescanPasses) break;
    const shouldRescan = shouldRunSecondCollectPass({
      pass,
      rescanPasses,
      isRangeCollect,
      options,
      stoppedBecause,
      finalEvents: collectRawEventsFromSnapshot(snapshots)
    });
    if (!shouldRescan) break;
    const reset = await resetFullScanPositionForRescan(page, options, { isRangeCollect, pass });
    keywordJumps.push(reset);
    await page.waitForTimeout(waitMs).catch(() => {});
  }

  let finalEvents = collectRawEventsFromSnapshot(snapshots);
  if (options.endKeyword && keywordSatisfiedByCollectedEvents(finalEvents, options.startKeyword, keywordJumps, "start") && !collectHasKeyword(finalEvents, options.endKeyword)) {
    const endJump = await jumpToFeishuDocumentKeyword(page, options.endKeyword, "end", {
      diagnosticsDir: options.diagnosticsDir,
      mediaCacheDir: options.mediaCacheDir
    });
    keywordJumps.push(endJump);
    if (endJump.foundVisibleAfterJump) {
      mergeSnapshotItems(snapshots, await readSnapshotItemsForFullScan(page, options));
      finalEvents = collectRawEventsFromSnapshot(snapshots);
      logs.push(collectLogEntry(logs.length, finalEvents, options, null, keywordJumps));
    }
    if (!collectHasKeyword(finalEvents, options.endKeyword)) {
      const fallback = await fallbackLocateKeywordFromCollectedText(page, {
        ...options,
        keyword: options.endKeyword,
        label: "end",
        keywordFallbackMaxSteps: options.endKeywordFallbackMaxSteps ?? options.startKeywordFallbackMaxSteps
      }, {
        snapshots,
        logs,
        keywordJumps,
        overlayClosures,
        stepPixels,
        waitMs,
        maxSteps
      });
      endJump.fallback = fallback.summary;
      if (fallback.found) {
        endJump.foundVisibleAfterJump = true;
        endJump.visibleMatch = fallback.visibleMatch;
        endJump.reason = `${endJump.reason || "结束关键词未通过飞书查找定位"}；${fallback.reason}`;
        finalEvents = collectRawEventsFromSnapshot(snapshots);
        stoppedBecause = "keywords-found";
      }
    }
  }
  if (options.endKeyword && collectHasKeyword(finalEvents, options.endKeyword)) {
    let endJump = keywordJumps.find((item) => item.label === "end");
    if (!endJump) {
      endJump = {
        label: "end",
        keyword: String(options.endKeyword || ""),
        openedFindBox: false,
        foundVisibleAfterJump: true,
        attempts: 0,
        reason: "已采集到结束关键词",
        searchTrace: []
      };
      keywordJumps.push(endJump);
    }
    await addSearchTrace(page, endJump, "collected-end-keyword", "已采集到结束关键词", {
      matched: true,
      eventCount: finalEvents.length
    });
  }

  const finalSnapshotItems = applyCopiedFinderCodeBlockItems(snapshots, copiedFinderCodeBlockItemsFromOptions(options));
  if (finalSnapshotItems !== snapshots) {
    snapshots.splice(0, snapshots.length, ...finalSnapshotItems);
    finalEvents = collectRawEventsFromSnapshot(snapshots);
  }

  const diagnostics = buildCollectDiagnostics({
    logs,
    stoppedBecause,
    startKeyword: options.startKeyword,
    endKeyword: options.endKeyword,
    keywordJumps,
    bottomConfirmations,
    finderCodeBlocks: summarizeFinderCodeBlockCopyDiagnostics(options.__finderCodeBlockCopyDiagnostics),
    overlayClosures
  });
  if (options.startKeyword && !keywordSatisfiedByCollectedEvents(finalEvents, options.startKeyword, keywordJumps, "start")) {
    const startJump = keywordJumps.find((item) => item.label === "start");
    const reason = startJump?.reason ? `；${startJump.reason}` : "";
    diagnostics.failure = `没有采到开始关键词${reason}`;
  } else if (options.endKeyword && !collectHasKeyword(finalEvents, options.endKeyword)) {
    diagnostics.failure = `滚动 ${diagnostics.scrollCount} 次后仍没有采到结束关键词`;
  } else if (requireDocumentEnd && !diagnostics.documentEndConfirmed) {
    diagnostics.failure = `全文读取未确认到达文档末尾，停止原因：${stoppedBecause}，滚动次数：${diagnostics.scrollCount}`;
  }
  return { items: snapshots, diagnostics, finderCodeBlocksReplaced: true };
}

async function scanFullPagePass(page, state) {
  const {
    options,
    snapshots,
    logs,
    keywordJumps,
    overlayClosures,
    pass,
    stepPixels,
    waitMs,
    maxSteps,
    isRangeCollect,
    requireDocumentEnd
  } = state;
  let previousSignature = "";
  let stableCount = 0;
  let bottomConfirmations = state.bottomConfirmations || 0;
  let stoppedBecause = "max-steps";
  let endRoleHeaderTailScans = 0;

  for (let passStep = 0; passStep < maxSteps; passStep += 1) {
    const step = logs.length;
    const beforeSnapshotOverlayClose = await closeFeishuMediaPreviewOverlay(page);
    if (beforeSnapshotOverlayClose.detected) overlayClosures.push({ stage: `pass-${pass}-before-snapshot-${passStep}`, ...beforeSnapshotOverlayClose });
    mergeSnapshotItems(snapshots, await readSnapshotItemsForFullScan(page, options));
    const events = collectRawEventsFromSnapshot(snapshots);
    logs.push(collectLogEntry(step, events, { ...options, collectPass: pass }, null, keywordJumps));

    const foundStart = !options.startKeyword || keywordSatisfiedByCollectedEvents(events, options.startKeyword, pass === 1 ? keywordJumps : [], "start");
    const foundEnd = !options.endKeyword || collectHasKeyword(events, options.endKeyword);
    if (isRangeCollect && foundStart && foundEnd) {
      const endStatus = endKeywordRecordCollectionStatus(events, options.endKeyword, options);
      const maxTailScans = Math.max(0, Number(options.endKeywordTailMaxScans ?? 4));
      const minRescanSteps = pass > 1 ? Math.max(1, Number(options.secondCollectMinSteps ?? 1)) : 0;
      const canStopAtEnd = !endStatus.needsTailCollection ||
        endStatus.complete ||
        (endStatus.hasPayload && endRoleHeaderTailScans >= 1) ||
        endRoleHeaderTailScans >= maxTailScans;
      if (canStopAtEnd && passStep >= minRescanSteps) {
        stoppedBecause = endStatus.needsTailCollection && endRoleHeaderTailScans > 0
          ? "keywords-found-end-record-complete"
          : "keywords-found";
        break;
      }
      endRoleHeaderTailScans += 1;
    }

    const signature = eventListSignature(events);
    if (signature === previousSignature) {
      stableCount += 1;
    } else {
      stableCount = 0;
      previousSignature = signature;
    }

    const scrollState = await scrollFeishuPage(page, stepPixels);
    await page.waitForTimeout(waitMs).catch(() => {});
    const afterScrollOverlayClose = await closeFeishuMediaPreviewOverlay(page);
    if (afterScrollOverlayClose.detected) overlayClosures.push({ stage: `pass-${pass}-after-scroll-${passStep}`, ...afterScrollOverlayClose });

    if (!options.endKeyword && requireDocumentEnd) {
      bottomConfirmations = scrollState.atBottom ? bottomConfirmations + 1 : 0;
      if (bottomConfirmations >= Number(options.bottomConfirmations || 2)) {
        mergeSnapshotItems(snapshots, await readSnapshotItemsForFullScan(page, options));
        const finalEvents = collectRawEventsFromSnapshot(snapshots);
        logs.push(collectLogEntry(logs.length, finalEvents, { ...options, collectPass: pass }, scrollState, keywordJumps));
        stoppedBecause = "bottom-confirmed";
        break;
      }
      continue;
    }

    if (!options.endKeyword && (scrollState.atBottom || stableCount >= 3)) {
      mergeSnapshotItems(snapshots, await readSnapshotItemsForFullScan(page, options));
      const finalEvents = collectRawEventsFromSnapshot(snapshots);
      logs.push(collectLogEntry(logs.length, finalEvents, { ...options, collectPass: pass }, scrollState, keywordJumps));
      stoppedBecause = scrollState.atBottom ? "bottom" : "no-new-content";
      break;
    }

    if (options.endKeyword && scrollState.atBottom && stableCount >= 4) {
      stoppedBecause = "bottom-before-end";
      break;
    }
  }

  return { stoppedBecause, bottomConfirmations };
}

function shouldRunSecondCollectPass({ pass, rescanPasses, isRangeCollect, options, stoppedBecause, finalEvents }) {
  if (pass >= rescanPasses) return false;
  if (options.disableSecondCollectPass === true) return false;
  if (isRangeCollect && options.startKeyword && !keywordSatisfiedByCollectedEvents(finalEvents, options.startKeyword, [], "start")) return false;
  if (isRangeCollect && options.endKeyword && !collectHasKeyword(finalEvents, options.endKeyword)) return false;
  return ["bottom", "bottom-confirmed", "keywords-found", "keywords-found-end-record-complete", "no-new-content"].includes(stoppedBecause);
}

async function resetFullScanPositionForRescan(page, options = {}, context = {}) {
  const keyword = context.isRangeCollect ? options.startKeyword : "";
  if (keyword) {
    const jump = await jumpToFeishuDocumentKeyword(page, keyword, `rescan-${context.pass || 1}-start`, {
      maxFocusScans: options.requireStartKeywordSearch ? 4 : undefined,
      allowOutlineHeadingJump: !options.requireStartKeywordSearch,
      diagnosticsDir: options.diagnosticsDir,
      mediaCacheDir: options.mediaCacheDir
    });
    return {
      ...jump,
      rescan: true,
      reason: jump.reason || "第二遍复扫回到开始位置"
    };
  }
  await page.evaluate(() => {
    window.scrollTo(0, 0);
    const candidates = Array.from(document.querySelectorAll("*"))
      .filter((el) => {
        const style = getComputedStyle(el);
        return /(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && el.scrollHeight > el.clientHeight + 20;
      })
      .sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight));
    for (const el of candidates.slice(0, 4)) el.scrollTop = 0;
  }).catch(() => {});
  return {
    label: `rescan-${context.pass || 1}-top`,
    keyword: "",
    openedFindBox: false,
    foundVisibleAfterJump: true,
    attempts: 0,
    reason: "第二遍复扫回到文档顶部",
    rescan: true,
    searchTrace: []
  };
}

async function readSnapshotItemsForFullScan(page, options = {}) {
  const snapshotItems = await replaceFinderCodeBlocksWithCopiedXml(page, await page.evaluate(readPageSnapshot), options);
  return options.deferMediaMaterialization
    ? snapshotItems
    : materializeSnapshotMediaFromPage(page, snapshotItems, options);
}

async function replaceFinderCodeBlocksWithCopiedXml(page, snapshotItems = [], options = {}) {
  if (!page || page.isClosed?.()) return snapshotItems;
  const copiedItems = await collectCopiedFinderCodeBlockItems(page, options);
  if (!copiedItems.length) return snapshotItems;
  return applyCopiedFinderCodeBlockItems(snapshotItems, copiedItems);
}

async function collectCopiedFinderCodeBlockItems(page, options = {}) {
  const candidates = await page.evaluate(markFinderCodeBlockCandidates).catch(() => []);
  recordFinderCodeBlockCopyDiagnostic(options, {
    stage: "scan",
    candidateCount: Array.isArray(candidates) ? candidates.length : 0,
    forceCopy: options.forceFinderCodeBlockCopy === true
  });
  if (!Array.isArray(candidates) || !candidates.length) return [];

  await grantClipboardPermissions(page).catch(() => {});
  const previousClipboard = await readBrowserClipboard(page);
  const copiedItems = [];
  const processedKeys = options.__copiedFinderCodeBlockKeys || (options.__copiedFinderCodeBlockKeys = new Set());
  const copiedCache = options.__copiedFinderCodeBlockItems || (options.__copiedFinderCodeBlockItems = new Map());
  const forcePageCopy = options.forceFinderCodeBlockCopy === true;
  try {
    for (const candidate of candidates.slice(0, Math.max(1, Number(options.finderCodeBlockCopyLimit || 12)))) {
      if (candidate.stableKey && processedKeys.has(candidate.stableKey)) {
        const cached = copiedCache.get(candidate.stableKey);
        if (cached) {
          recordFinderCodeBlockCopyDiagnostic(options, {
            stage: "reused-current-run",
            stableKey: candidate.stableKey,
            sourceId: cached.sourceId,
            y: candidate.y
          });
          copiedItems.push({
            ...cached,
            y: candidate.y,
            order: Number.isFinite(Number(candidate.order)) ? Number(candidate.order) : Number(candidate.index || copiedItems.length),
            blockIndex: Number.isFinite(Number(candidate.index)) ? Number(candidate.index) : copiedItems.length,
            boundingInfo: candidate.boundingInfo || cached.boundingInfo,
            copiedFinderCodeBlock: {
              id: candidate.id,
              top: candidate.top,
              bottom: candidate.bottom
            }
          });
        }
        continue;
      }
      const pageCachedText = !forcePageCopy && candidate.stableKey
        ? await readCachedFinderCodeBlockText(page, candidate.stableKey)
        : "";
      const pageCachedXml = bestFinderXmlFromCopiedText(pageCachedText);
      if (pageCachedXml) {
        if (candidate.stableKey) processedKeys.add(candidate.stableKey);
        const copiedItem = buildCopiedFinderCodeBlockItem(candidate, pageCachedXml, copiedItems.length);
        if (candidate.stableKey) copiedCache.set(candidate.stableKey, copiedItem);
        recordFinderCodeBlockCopyDiagnostic(options, {
          stage: "reused-page-cache",
          stableKey: candidate.stableKey,
          sourceId: copiedItem.sourceId,
          y: candidate.y
        });
        copiedItems.push(copiedItem);
        continue;
      }
      const copyResult = await copyFinderCodeBlockText(page, candidate, options);
      const finderXml = bestFinderXmlFromCopiedText(copyResult.text);
      if (!finderXml) {
        recordFinderCodeBlockCopyDiagnostic(options, {
          stage: "copy-failed",
          stableKey: candidate.stableKey,
          reason: copyResult.reason || "no_finder_xml",
          attempts: copyResult.attempts || 0,
          copiedTextCount: copyResult.copiedTextCount || 0,
          y: candidate.y
        });
        continue;
      }
      if (candidate.stableKey) processedKeys.add(candidate.stableKey);
      const copiedItem = buildCopiedFinderCodeBlockItem(candidate, finderXml, copiedItems.length);
      if (candidate.stableKey) copiedCache.set(candidate.stableKey, copiedItem);
      if (candidate.stableKey) await writeCachedFinderCodeBlockText(page, candidate.stableKey, finderXml).catch(() => {});
      recordFinderCodeBlockCopyDiagnostic(options, {
        stage: "copied",
        stableKey: candidate.stableKey,
        sourceId: copiedItem.sourceId,
        attempts: copyResult.attempts || 0,
        copiedTextCount: copyResult.copiedTextCount || 0,
        y: candidate.y
      });
      copiedItems.push(copiedItem);
    }
  } finally {
    if (previousClipboard.available) {
      await writeBrowserClipboard(page, previousClipboard.text).catch(() => {});
    }
    await page.evaluate(() => {
      for (const el of Array.from(document.querySelectorAll("[data-v2-finder-code-block-id],[data-v2-finder-copy-button-id]"))) {
        el.removeAttribute("data-v2-finder-code-block-id");
        el.removeAttribute("data-v2-finder-copy-button-id");
      }
    }).catch(() => {});
  }
  return copiedItems;
}

function buildCopiedFinderCodeBlockItem(candidate, finderXml, fallbackIndex = 0) {
  return {
    sourceId: `feishu-copied-finder-${shortHash(finderXml)}`,
    type: "line",
    kind: "line",
    text: finderXml,
    sourceText: finderXml,
    mediaPath: "",
    assetUrl: "",
    highlighted: false,
    y: candidate.y,
    order: Number.isFinite(Number(candidate.order)) ? Number(candidate.order) : Number(candidate.index || fallbackIndex),
    blockIndex: Number.isFinite(Number(candidate.index)) ? Number(candidate.index) : fallbackIndex,
    boundingInfo: candidate.boundingInfo || { x: 0, y: candidate.y, width: 0, height: 0 },
    copiedFinderCodeBlock: {
      id: candidate.id,
      top: candidate.top,
      bottom: candidate.bottom
    }
  };
}

async function readCachedFinderCodeBlockText(page, stableKey) {
  if (!stableKey) return "";
  return page.evaluate((key) => String(window.__v2CopiedFinderCodeBlockTextByKey?.[key] || ""), stableKey).catch(() => "");
}

async function writeCachedFinderCodeBlockText(page, stableKey, text) {
  if (!stableKey || !text) return;
  await page.evaluate(({ key, value }) => {
    window.__v2CopiedFinderCodeBlockTextByKey = window.__v2CopiedFinderCodeBlockTextByKey || {};
    window.__v2CopiedFinderCodeBlockTextByKey[key] = String(value || "");
  }, { key: stableKey, value: text });
}

async function copyFinderCodeBlockText(page, candidate, options = {}) {
  const blockSelector = `[data-v2-finder-code-block-id="${cssEscape(candidate.id)}"]`;
  const block = page.locator(blockSelector).first();
  const scrollPosition = await readFeishuMainScrollPosition(page);
  try {
    let visible = await isLocatorVisiblyInViewport(block).catch(() => false);
    if (!visible) {
      await block.scrollIntoViewIfNeeded({ timeout: 1800 }).catch(() => {});
      await page.waitForTimeout(180).catch(() => {});
      visible = await isLocatorVisiblyInViewport(block).catch(() => false);
    }
    if (!visible) return { text: "", reason: "not_visible", attempts: 0, copiedTextCount: 0 };
    await block.hover({ timeout: 1200 }).catch(() => {});
    await page.waitForTimeout(120).catch(() => {});

    const buttonId = await page.evaluate(findAndMarkFinderCodeBlockCopyButton, candidate.id).catch(() => "");
    if (!buttonId) return { text: "", reason: "copy_button_not_found", attempts: 0, copiedTextCount: 0 };
    const button = page.locator(`[data-v2-finder-copy-button-id="${cssEscape(buttonId)}"]`).first();
    const attempts = Math.max(1, Math.min(5, Number(options.finderCodeBlockCopyAttempts || 5)));
    const copies = [];
    for (let index = 0; index < attempts; index += 1) {
      await page.evaluate(() => {
        window.__v2FeishuCopiedText = "";
        window.__v2LastCopiedText = "";
      }).catch(() => {});
      await writeBrowserClipboard(page, "").catch(() => {});
      await block.hover({ timeout: 1200 }).catch(() => {});
      await button.click({ timeout: 1500 }).catch(() => {});
      await page.waitForTimeout(180).catch(() => {});
      const copied = await readBrowserClipboardTextOrPageCopy(page);
      if (copied) copies.push(copied);
    }
    const text = chooseBestCopiedFinderText(copies);
    return {
      text,
      reason: text ? "copied" : (copies.length ? "copied_without_complete_finder_xml" : "clipboard_empty"),
      attempts,
      copiedTextCount: copies.length
    };
  } finally {
    await restoreFeishuMainScrollPosition(page, scrollPosition).catch(() => {});
  }
}

function recordFinderCodeBlockCopyDiagnostic(options = {}, entry = {}) {
  if (!options || typeof options !== "object") return;
  const list = options.__finderCodeBlockCopyDiagnostics || (options.__finderCodeBlockCopyDiagnostics = []);
  if (list.length >= 400) return;
  list.push({
    stage: String(entry.stage || ""),
    reason: String(entry.reason || ""),
    stableKeyHash: entry.stableKey ? shortHash(entry.stableKey) : "",
    sourceId: String(entry.sourceId || ""),
    candidateCount: Number.isFinite(Number(entry.candidateCount)) ? Number(entry.candidateCount) : undefined,
    attempts: Number.isFinite(Number(entry.attempts)) ? Number(entry.attempts) : undefined,
    copiedTextCount: Number.isFinite(Number(entry.copiedTextCount)) ? Number(entry.copiedTextCount) : undefined,
    y: Number.isFinite(Number(entry.y)) ? Number(entry.y) : undefined,
    forceCopy: entry.forceCopy === true ? true : undefined
  });
}

function summarizeFinderCodeBlockCopyDiagnostics(entries = []) {
  const list = Array.isArray(entries) ? entries : [];
  if (!list.length) {
    return {
      scanCount: 0,
      maxVisibleCandidates: 0,
      copiedCount: 0,
      reusedCurrentRunCount: 0,
      reusedPageCacheCount: 0,
      failedCount: 0,
      forceCopy: false,
      failures: []
    };
  }
  const scanEntries = list.filter((entry) => entry.stage === "scan");
  const failed = list.filter((entry) => entry.stage === "copy-failed");
  return {
    scanCount: scanEntries.length,
    maxVisibleCandidates: Math.max(0, ...scanEntries.map((entry) => Number(entry.candidateCount) || 0)),
    copiedCount: list.filter((entry) => entry.stage === "copied").length,
    reusedCurrentRunCount: list.filter((entry) => entry.stage === "reused-current-run").length,
    reusedPageCacheCount: list.filter((entry) => entry.stage === "reused-page-cache").length,
    failedCount: failed.length,
    forceCopy: list.some((entry) => entry.forceCopy === true),
    failures: failed.slice(0, 12).map((entry) => ({
      reason: entry.reason || "unknown",
      stableKeyHash: entry.stableKeyHash || "",
      attempts: entry.attempts || 0,
      copiedTextCount: entry.copiedTextCount || 0,
      y: entry.y
    }))
  };
}

async function isLocatorVisiblyInViewport(locator) {
  const box = await locator.boundingBox({ timeout: 800 }).catch(() => null);
  if (!box) return false;
  return box.width > 0 && box.height > 0 && box.y < 900 && box.y + box.height > 40;
}

async function readFeishuMainScrollPosition(page) {
  return page.evaluate(() => {
    const target = findMainScrollable();
    return {
      windowY: window.scrollY,
      targetPath: target ? elementPath(target) : "",
      targetScrollTop: target ? target.scrollTop : 0
    };

    function elementPath(el) {
      const parts = [];
      let current = el;
      while (current && current !== document.documentElement) {
        const parent = current.parentElement;
        if (!parent) break;
        const index = Array.from(parent.children).indexOf(current);
        parts.unshift(`${current.tagName || "node"}:${index}`);
        current = parent;
      }
      return parts.join("/");
    }
    function findMainScrollable() {
      const visible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" &&
          rect.left < innerWidth && rect.right > 0 && rect.top < innerHeight && rect.bottom > 0;
      };
      return Array.from(document.querySelectorAll("*"))
        .map((el) => {
          const style = getComputedStyle(el);
          const scrollable = /(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && el.scrollHeight > el.clientHeight + 20;
          if (!scrollable || !visible(el)) return null;
          const rect = el.getBoundingClientRect();
          const text = String(el.className || "") + " " + String(el.id || "");
          let score = el.scrollHeight - el.clientHeight;
          score += rect.width * rect.height / 10000;
          if (/editor|docx|scroll|content|reader|page/i.test(text)) score += 500;
          if (rect.left > innerWidth * 0.75 || rect.right < innerWidth * 0.15) score -= 1000;
          return { el, score };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score)[0]?.el || null;
    }
  }).catch(() => ({ windowY: 0, targetPath: "", targetScrollTop: 0 }));
}

async function restoreFeishuMainScrollPosition(page, position = {}) {
  await page.evaluate((position) => {
    window.scrollTo(0, Number(position.windowY || 0));
    const target = findByPath(position.targetPath || "");
    if (target) target.scrollTop = Number(position.targetScrollTop || 0);

    function findByPath(path) {
      if (!path) return null;
      let current = document.documentElement;
      for (const part of String(path).split("/")) {
        const index = Number(part.split(":").pop());
        if (!Number.isInteger(index) || !current?.children?.[index]) return null;
        current = current.children[index];
      }
      return current;
    }
  }, position);
}

async function grantClipboardPermissions(page) {
  const context = page.context?.();
  if (!context?.grantPermissions) return;
  let origin = "";
  try {
    origin = new URL(page.url()).origin;
  } catch {}
  if (!origin || origin === "null") return;
  await context.grantPermissions(["clipboard-read", "clipboard-write"], { origin });
}

async function readBrowserClipboard(page) {
  const result = await page.evaluate(async () => {
    try {
      if (!navigator.clipboard?.readText) return { available: false, text: "" };
      return { available: true, text: await navigator.clipboard.readText() };
    } catch {
      return { available: false, text: "" };
    }
  }).catch(() => ({ available: false, text: "" }));
  return {
    available: Boolean(result?.available),
    text: String(result?.text || "")
  };
}

async function writeBrowserClipboard(page, text) {
  await page.evaluate(async (value) => {
    if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(String(value || ""));
  }, text);
}

async function readBrowserClipboardTextOrPageCopy(page) {
  return page.evaluate(async () => {
    try {
      const text = await navigator.clipboard?.readText?.();
      if (text) return String(text);
    } catch {}
    return String(window.__v2FeishuCopiedText || window.__v2LastCopiedText || "");
  }).catch(() => "");
}

function applyCopiedFinderCodeBlockItems(snapshotItems = [], copiedItems = []) {
  const copied = dedupeCopiedFinderItemsByMessageSegment(snapshotItems, copiedItems);
  if (!copied.length) return snapshotItems;
  const result = Array.isArray(snapshotItems)
    ? snapshotItems.filter((item) => !copied.some((copiedItem) => shouldDropRawCodeBlockItem(item, copiedItem)))
    : [];
  for (const copiedItem of copied) {
    const context = copiedItem.collectContext || nearestCollectContext(snapshotItems, copiedItem);
    result.push({
      ...copiedItem,
      collectSpeaker: context.collectSpeaker,
      collectTime: context.collectTime
    });
  }
  return result.sort((a, b) => Number(a.y || 0) - Number(b.y || 0) || Number(a.order || 0) - Number(b.order || 0))
    .map((item, index) => ({ ...item, order: index, blockIndex: Number.isFinite(Number(item.blockIndex)) ? Number(item.blockIndex) : index }));
}

function copiedFinderCodeBlockItemsFromOptions(options = {}) {
  const cache = options.__copiedFinderCodeBlockItems;
  if (!(cache instanceof Map)) return [];
  return [...cache.values()];
}

function shouldDropRawCodeBlockItem(item, copiedItem) {
  if (sameCopiedFinderMessageSegment(item, copiedItem)) {
    const type = inferCollectedItemType(item);
    if (type !== "line" && type !== "title") return false;
    const text = String(item?.text || item?.sourceText || "").trim();
    return isCodeBlockChromeText(text) || looksLikeXmlCodeLine(text);
  }
  const range = copiedItem.copiedFinderCodeBlock || {};
  const y = Number(item?.y ?? item?.boundingInfo?.y);
  if (!Number.isFinite(y)) return false;
  const top = Number(range.top);
  const bottom = Number(range.bottom);
  if (!Number.isFinite(top) || !Number.isFinite(bottom)) return false;
  if (y < top - 8 || y > bottom + 8) return false;
  const type = inferCollectedItemType(item);
  if (type !== "line" && type !== "title") return false;
  const text = String(item?.text || item?.sourceText || "").trim();
  return isCodeBlockChromeText(text) || looksLikeXmlCodeLine(text);
}

function dedupeCopiedFinderItemsByMessageSegment(snapshotItems = [], copiedItems = []) {
  const segments = buildCollectMessageSegments(snapshotItems);
  const bestBySegment = new Map();
  for (const copiedItem of copiedItems) {
    const finderXml = bestFinderXmlFromCopiedText(copiedItem.text);
    if (!finderXml) continue;
    const segment = findMessageSegmentForCopiedItem(segments, copiedItem);
    if (!segment) continue;
    const normalizedItem = {
      ...copiedItem,
      text: finderXml,
      sourceText: finderXml,
      y: Number.isFinite(Number(copiedItem.y)) ? Number(copiedItem.y) : segment.startY + 1,
      collectSpeaker: segment.collectSpeaker,
      collectTime: segment.collectTime,
      collectContext: {
        collectSpeaker: segment.collectSpeaker,
        collectTime: segment.collectTime
      },
      copiedFinderMessageSegmentId: segment.id
    };
    const current = bestBySegment.get(segment.id);
    if (!current || finderXmlScore(normalizedItem.text) > finderXmlScore(current.text)) {
      bestBySegment.set(segment.id, normalizedItem);
    }
  }
  return [...bestBySegment.values()];
}

function buildCollectMessageSegments(snapshotItems = []) {
  const items = sortCollectedItemsByDocumentPosition(snapshotItems);
  const segments = [];
  let current = null;
  for (const item of items) {
    const header = parseCollectHeader(item);
    const y = Number(item?.y ?? item?.boundingInfo?.y ?? 0);
    if (header) {
      if (current) current.endY = y;
      current = {
        id: `segment-${segments.length + 1}`,
        collectSpeaker: header.speaker,
        collectTime: header.time,
        startY: y,
        endY: Number.POSITIVE_INFINITY
      };
      segments.push(current);
      continue;
    }
    if (!current && (item.collectSpeaker || item.collectTime)) {
      current = {
        id: `segment-${segments.length + 1}`,
        collectSpeaker: String(item.collectSpeaker || ""),
        collectTime: String(item.collectTime || ""),
        startY: y,
        endY: Number.POSITIVE_INFINITY
      };
      segments.push(current);
    }
  }
  return segments;
}

function findMessageSegmentForCopiedItem(segments = [], copiedItem = {}) {
  const y = Number(copiedItem?.y ?? copiedItem?.boundingInfo?.y);
  if (Number.isFinite(y)) {
    const byY = segments.find((segment) => y >= segment.startY - 8 && y < segment.endY - 1);
    if (byY) return byY;
  }
  const speaker = normalizeCollectSpeaker(copiedItem.collectSpeaker || copiedItem.collectContext?.collectSpeaker || "");
  const time = String(copiedItem.collectTime || copiedItem.collectContext?.collectTime || "");
  if (speaker && time) {
    const byContext = segments.find((segment) => segment.collectSpeaker === speaker && segment.collectTime === time);
    if (byContext) return byContext;
  }
  if (Number.isFinite(y)) {
    return [...segments].reverse().find((segment) => y >= segment.startY - 8) || null;
  }
  return null;
}

function sameCopiedFinderMessageSegment(item, copiedItem) {
  const segmentId = copiedItem.copiedFinderMessageSegmentId;
  if (!segmentId) return false;
  const itemY = Number(item?.y ?? item?.boundingInfo?.y);
  const copiedRange = copiedItem.copiedFinderCodeBlock || {};
  if (Number.isFinite(itemY) && Number.isFinite(Number(copiedRange.top)) && Number.isFinite(Number(copiedRange.bottom))) {
    if (itemY >= Number(copiedRange.top) - 8 && itemY <= Number(copiedRange.bottom) + 8) return true;
  }
  const itemSpeaker = normalizeCollectSpeaker(item?.collectSpeaker || "");
  const copiedSpeaker = normalizeCollectSpeaker(copiedItem.collectSpeaker || copiedItem.collectContext?.collectSpeaker || "");
  const itemTime = String(item?.collectTime || "");
  const copiedTime = String(copiedItem.collectTime || copiedItem.collectContext?.collectTime || "");
  return Boolean(itemSpeaker && copiedSpeaker && itemSpeaker === copiedSpeaker && itemTime && copiedTime && itemTime === copiedTime);
}

function nearestCollectContext(snapshotItems = [], copiedItem = {}) {
  const copiedY = Number(copiedItem.y || copiedItem.boundingInfo?.y || 0);
  const inRange = snapshotItems.find((item) => {
    const y = Number(item?.y ?? item?.boundingInfo?.y);
    const range = copiedItem.copiedFinderCodeBlock || {};
    return Number.isFinite(y) &&
      y >= Number(range.top || copiedY) - 8 &&
      y <= Number(range.bottom || copiedY) + 8 &&
      (item.collectSpeaker || item.collectTime);
  });
  if (inRange) {
    return {
      collectSpeaker: String(inRange.collectSpeaker || ""),
      collectTime: String(inRange.collectTime || "")
    };
  }
  const before = [...snapshotItems]
    .filter((item) => Number(item?.y ?? item?.boundingInfo?.y) <= copiedY && (item.collectSpeaker || item.collectTime))
    .sort((a, b) => Number(b.y ?? b.boundingInfo?.y ?? 0) - Number(a.y ?? a.boundingInfo?.y ?? 0))[0];
  return {
    collectSpeaker: String(before?.collectSpeaker || ""),
    collectTime: String(before?.collectTime || "")
  };
}

function chooseBestCopiedFinderText(copies = []) {
  const items = copies
    .map((text, index) => ({ index, text: String(text || ""), xml: bestFinderXmlFromCopiedText(text) }))
    .filter((item) => item.xml);
  if (!items.length) return "";
  const groups = new Map();
  for (const item of items) {
    const key = normalizeCopiedFinderXmlForSimilarity(item.xml);
    const current = groups.get(key) || {
      key,
      count: 0,
      items: [],
      bestXml: "",
      bestScore: Number.NEGATIVE_INFINITY,
      completeness: 0
    };
    const score = finderXmlScore(item.xml);
    current.count += 1;
    current.items.push(item);
    if (!current.bestXml || score > current.bestScore || (score === current.bestScore && item.xml.length > current.bestXml.length)) {
      current.bestXml = item.xml;
      current.bestScore = score;
      current.completeness = finderXmlCompletenessScore(item.xml);
    }
    groups.set(key, current);
  }
  const grouped = [...groups.values()];
  const completeGroups = grouped.filter((group) => isCompleteFinderXml(group.bestXml));
  const pool = completeGroups.length ? completeGroups : grouped;
  return pool.sort((a, b) =>
    b.count - a.count ||
    b.completeness - a.completeness ||
    b.bestScore - a.bestScore ||
    b.bestXml.length - a.bestXml.length
  )[0]?.bestXml || "";
}

function bestFinderXmlFromCopiedText(text) {
  const raw = String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
  const xmls = extractAllFinderXmlFromCopiedText(raw);
  const xml = xmls.sort((a, b) => finderXmlScore(b) - finderXmlScore(a) || b.length - a.length)[0] || "";
  return sanitizeFinderXmlEntities(xml);
}

function extractAllFinderXmlFromCopiedText(raw) {
  const lines = String(raw || "").split("\n")
    .map((line) => line.replace(/^\s*\d+\s(?=\s*(?:<|\{))/, "").trimEnd())
    .filter((line) => {
      const compact = line.trim().replace(/\s+/g, "");
      return !compact || !isCodeBlockChromeText(compact);
    });
  const xmls = [];
  for (let start = 0; start < lines.length; start += 1) {
    if (!/^\s*(?:<\?xml\b|<msg\b)/i.test(lines[start])) continue;
    let appmsgEnd = -1;
    let finalEnd = -1;
    for (let end = start; end < lines.length; end += 1) {
      if (appmsgEnd < 0 && /<\/appmsg>\s*$/i.test(lines[end])) appmsgEnd = end;
      if (/<\/msg>\s*$/i.test(lines[end])) {
        finalEnd = end;
        break;
      }
    }
    if (finalEnd < 0) finalEnd = appmsgEnd;
    if (finalEnd >= start) {
      const xml = lines.slice(start, finalEnd + 1).join("\n").trim();
      if (looksLikeCopiedFinderXml(xml)) xmls.push(xml);
      start = finalEnd;
    }
  }
  return xmls;
}

function extractFinderXmlFromCopiedCodeBlock(text) {
  return bestFinderXmlFromCopiedText(text);
}

function finderXmlScore(text) {
  const value = String(text || "");
  let score = value.length;
  for (const token of ["<?xml", "<msg", "</msg>", "<appmsg", "</appmsg>", "<finderFeed", "</finderFeed>", "<type>51</type>", "<objectId", "<objectNonceId"]) {
    if (new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i").test(value)) score += 10000;
  }
  return score;
}

function normalizeCopiedFinderXmlForSimilarity(text) {
  return String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/>\s+</g, "><")
    .replace(/\s*\n\s*/g, "\n")
    .trim()
    .toLowerCase();
}

function isCompleteFinderXml(text) {
  const value = String(text || "");
  return /<msg\b/i.test(value) &&
    /<\/msg>/i.test(value) &&
    /<appmsg\b/i.test(value) &&
    /<\/appmsg>/i.test(value) &&
    (/<finderFeed\b/i.test(value) || /<type>\s*51\s*<\/type>/i.test(value)) &&
    /<objectId\b/i.test(value);
}

function finderXmlCompletenessScore(text) {
  const value = String(text || "");
  let score = 0;
  for (const token of ["<?xml", "<msg", "</msg>", "<appmsg", "</appmsg>", "<finderFeed", "</finderFeed>", "<type>51</type>", "<objectId", "<objectNonceId", "<commenturl", "</commenturl>"]) {
    if (new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i").test(value)) score += 1;
  }
  if (isCompleteFinderXml(value)) score += 20;
  return score;
}

function looksLikeCopiedFinderXml(text) {
  const value = String(text || "");
  return /<msg\b/i.test(value) &&
    /<appmsg\b/i.test(value) &&
    (/<finderFeed\b/i.test(value) || /<type>\s*51\s*<\/type>/i.test(value));
}

function sanitizeFinderXmlEntities(text) {
  return String(text || "").replace(/&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9a-fA-F]+;)/g, "&amp;");
}

function isCodeBlockChromeText(text) {
  const compact = String(text || "").trim().replace(/\s+/g, "");
  const codeLanguage = "(?:Python|JavaScript|Markdown|XML|HTML|JSON)";
  return /^(示例代码|复制|自动换行|Python|JavaScript|Markdown|XML|HTML|JSON|代码块)$/i.test(compact) ||
    new RegExp(`^(?:${codeLanguage})?自动换行复制$`, "i").test(compact) ||
    new RegExp(`^(?:示例代码|代码块)(?:${codeLanguage})?(?:自动换行)?(?:复制)?$`, "i").test(compact);
}

function looksLikeXmlCodeLine(text) {
  const value = String(text || "").trim();
  return /^\d+\s*</.test(value) || /^<\??[a-z!/]/i.test(value) || /^<\/[a-z]/i.test(value);
}

function shortHash(text) {
  let hash = 0;
  for (const char of String(text || "")) {
    hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
  }
  return Math.abs(hash).toString(36);
}

function cssEscape(value) {
  return String(value || "").replace(/["\\]/g, "\\$&");
}

function markFinderCodeBlockCandidates() {
  const visible = (el) => {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  };
  const normalize = (text) => String(text || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .trim();
  const looksFinder = (text) => /<msg\b/i.test(text) &&
    /<appmsg\b/i.test(text) &&
    (/<finderFeed\b/i.test(text) || /<type>\s*51\s*<\/type>/i.test(text));
  const nearestScrollParent = (el) => {
    let current = el?.parentElement;
    while (current && current !== document.body && current !== document.documentElement) {
      const style = getComputedStyle(current);
      if (/(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && current.scrollHeight > current.clientHeight + 20) {
        return current;
      }
      current = current.parentElement;
    }
    return null;
  };
  const absoluteYFor = (el, rect) => {
    const scrollParent = nearestScrollParent(el);
    if (scrollParent && scrollParent !== document.body && scrollParent !== document.documentElement) {
      const parentRect = scrollParent.getBoundingClientRect();
      return rect.top - parentRect.top + scrollParent.scrollTop;
    }
    return rect.top + window.scrollY;
  };
  const isCodeLike = (el) => {
    const tag = String(el.tagName || "").toLowerCase();
    const attrs = [
      el.className,
      el.getAttribute?.("role"),
      el.getAttribute?.("data-lang"),
      el.getAttribute?.("data-language"),
      el.getAttribute?.("data-code"),
      el.getAttribute?.("data-block-type"),
      el.getAttribute?.("data-card-type"),
      el.getAttribute?.("aria-label"),
      el.getAttribute?.("title")
    ].filter(Boolean).join(" ");
    return tag === "pre" || tag === "code" || /code|hljs|cm-editor|codemirror|代码/i.test(attrs);
  };
  const codeRootFor = (el) => {
    let best = el;
    let current = el;
    for (let depth = 0; current?.parentElement && depth < 7; depth += 1, current = current.parentElement) {
      const parent = current.parentElement;
      const bestRect = best.getBoundingClientRect();
      const parentRect = parent.getBoundingClientRect();
      if (parentRect.height > Math.max(bestRect.height + 360, window.innerHeight * 1.6)) continue;
      if (parent.querySelectorAll?.("pre,code,[class*='code' i],[class*='cm-editor' i],[class*='codemirror' i]").length > 1) continue;
      const text = normalize(parent.innerText || parent.textContent || "");
      if (!text || text.length > 12000) continue;
      const classText = String(parent.className || "");
      const parentCodeLike = isCodeLike(parent) || /code|代码/i.test(classText);
      if (parentCodeLike || (/示例代码|代码块|复制|自动换行|Python|JavaScript|Markdown/.test(text) && parent.querySelector?.("pre,code,[class*='code' i]"))) best = parent;
    }
    return best;
  };
  const roots = [];
  const hashText = (value) => {
    let hash = 0;
    for (const char of String(value || "")) hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
    return Math.abs(hash).toString(36);
  };
  const finderStableSignature = (text) => {
    const value = normalize(text)
      .replace(/示例代码|代码块|复制|自动换行|Python|JavaScript|Markdown/g, "")
      .replace(/^\s*\d+\s+/gm, "")
      .replace(/\s+/g, "");
    const objectId = value.match(/<objectId>([^<]+)<\/objectId>/i)?.[1] || "";
    const nonce = value.match(/<objectNonceId>([^<]+)<\/objectNonceId>/i)?.[1] || "";
    const username = value.match(/<username>([^<]+)<\/username>/i)?.[1] || "";
    if (objectId || nonce || username) return [objectId, nonce, username].filter(Boolean).join("|");
    return value.slice(0, 2000);
  };
  const nearestHeaderText = (root) => {
    const rootRect = root.getBoundingClientRect();
    const rootTop = absoluteYFor(root, rootRect);
    const headers = Array.from(document.querySelectorAll("body *"))
      .map((el) => {
        if (!visible(el) || el.contains(root) || root.contains(el)) return null;
        const text = normalize(el.innerText || el.textContent || "");
        if (!text || text.length > 120) return null;
        if (!/(?:(\d{1,2})[\/月](\d{1,2})(?:日)?\s*)?(\d{1,2})[：:](\d{1,2})(?:[：:](\d{1,2}))?/.test(text)) return null;
        const rect = el.getBoundingClientRect();
        const bottom = absoluteYFor(el, rect) + rect.height;
        if (bottom > rootTop + 8) return null;
        return { text, bottom };
      })
      .filter(Boolean)
      .sort((a, b) => b.bottom - a.bottom);
    return headers[0]?.text || "";
  };
  for (const el of Array.from(document.querySelectorAll("pre,code,[class*='code' i],[class*='cm-editor' i],[class*='codemirror' i]"))) {
    if (!visible(el)) continue;
    const root = codeRootFor(el);
    if (!visible(root)) continue;
    const text = normalize(root.innerText || root.textContent || "");
    if (!looksFinder(text)) continue;
    const nestedIndex = roots.findIndex((existing) => existing === root || existing.contains(root) || root.contains(existing));
    if (nestedIndex >= 0) {
      if (root.contains(roots[nestedIndex])) roots[nestedIndex] = root;
      continue;
    }
    roots.push(root);
  }
  return roots.map((root, index) => {
    const rect = root.getBoundingClientRect();
    const y = absoluteYFor(root, rect);
    const text = normalize(root.innerText || root.textContent || "");
    const id = `finder-code-block-${Date.now()}-${index}`;
    root.setAttribute("data-v2-finder-code-block-id", id);
    return {
      id,
      stableKey: `${nearestHeaderText(root)}:${hashText(finderStableSignature(text))}`,
      index,
      order: index,
      top: y,
      bottom: y + rect.height,
      y,
      boundingInfo: {
        x: rect.x,
        y,
        width: rect.width,
        height: rect.height
      }
    };
  });
}

function findAndMarkFinderCodeBlockCopyButton(candidateId) {
  const block = document.querySelector(`[data-v2-finder-code-block-id="${candidateId}"]`);
  if (!block) return "";
  const visible = (el) => {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  };
  const blockRect = block.getBoundingClientRect();
  const candidates = Array.from(document.querySelectorAll("button,[role='button'],a,span,div"))
    .filter(visible)
    .map((el) => {
      const text = String(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title") || "").replace(/\s+/g, "").trim();
      const clickTarget = el.closest("button,[role='button'],a") || el;
      const rect = clickTarget.getBoundingClientRect();
      const insideBlock = block.contains(clickTarget);
      const nearBlock = rect.right >= blockRect.left - 20 &&
        rect.left <= blockRect.right + 80 &&
        rect.bottom >= blockRect.top - 40 &&
        rect.top <= blockRect.bottom + 40;
      if (!/复制|Copy/i.test(text) || !nearBlock) return null;
      let score = 0;
      if (insideBlock) score += 100;
      if (rect.top <= blockRect.top + 80) score += 30;
      if (rect.left >= blockRect.right - 160) score += 30;
      if (clickTarget.matches("button,[role='button'],a")) score += 20;
      return { el: clickTarget, score };
    })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score);
  const target = candidates[0]?.el;
  if (!target) return "";
  const id = `finder-copy-button-${Date.now()}`;
  target.setAttribute("data-v2-finder-copy-button-id", id);
  return id;
}

function containsKeyword(events, keyword) {
  return findLiteralKeywordMatch(events, keyword).index >= 0;
}

function collectHasKeyword(events, keyword) {
  return containsKeyword(events, keyword);
}

function endKeywordRecordCollectionStatus(events = [], keyword = "", options = {}) {
  const match = findLiteralKeywordMatch(events, keyword);
  const index = match.index;
  if (index < 0) {
    return { needsTailCollection: false, complete: false, hasPayload: false, index: -1 };
  }
  if (!isRoleHeader(events, index, options)) {
    return { needsTailCollection: false, complete: true, hasPayload: true, index };
  }
  let hasPayload = false;
  for (let cursor = index + 1; cursor < events.length; cursor += 1) {
    if (isRoleHeader(events, cursor, options)) {
      return { needsTailCollection: true, complete: true, hasPayload, index, nextHeaderIndex: cursor };
    }
    if (eventHasCollectedPayload(events[cursor])) hasPayload = true;
  }
  return { needsTailCollection: true, complete: false, hasPayload, index };
}

function eventHasCollectedPayload(event) {
  if (!event) return false;
  if (MEDIA_EVENT_TYPES.has(event.type || event.kind)) return true;
  return Boolean(String(event.text || event.sourceText || "").trim());
}

function findLiteralKeywordMatch(events, keyword) {
  const needle = normalizeSearchText(keyword);
  if (!needle) return { index: -1, selected: null };
  for (let index = 0; index < events.length; index += 1) {
    const event = events[index];
    const haystack = normalizeSearchText([
      event.text,
      event.sourceText,
      event.mediaPath,
      event.assetUrl
    ].filter(Boolean).join(" "));
    if (haystack.includes(needle)) {
      return {
        index,
        selected: {
          index,
          text: event.text || event.sourceText || "",
          sourceId: event.sourceId || ""
        }
      };
    }
  }
  return { index: -1, selected: null };
}

function shouldUseStartKeywordFallback(keywordJump) {
  if (!keywordJump) return false;
  if (keywordJump.openedFindBox) return false;
  return /没有打开飞书文档内查找框/.test(String(keywordJump.reason || ""));
}

async function fallbackLocateKeywordFromCollectedText(page, options, state) {
  const keyword = String(options.keyword || "").trim();
  const label = options.label || "keyword";
  const maxFallbackSteps = Math.max(0, Math.min(
    Number(options.keywordFallbackMaxSteps ?? options.startKeywordFallbackMaxSteps ?? 6),
    Math.max(0, Number(state.maxSteps || 0))
  ));
  const timeoutMs = Math.max(1000, Number(options.keywordFallbackTimeoutMs || options.startKeywordFallbackTimeoutMs || 15000));
  const startedAt = Date.now();
  const summary = {
    attempted: true,
    source: "raw-events-page-text",
    label,
    keyword,
    maxSteps: maxFallbackSteps,
    timeoutMs,
    scans: 0,
    scrolls: 0,
    found: false,
    stoppedBecause: ""
  };

  const scanCurrentView = async (scrollState = null) => {
    const step = state.logs.length;
    const overlayClose = await closeFeishuMediaPreviewOverlay(page);
    if (overlayClose.detected) state.overlayClosures.push({ stage: `fallback-before-snapshot-${step}`, ...overlayClose });
    mergeSnapshotItems(state.snapshots, await readSnapshotItemsForFullScan(page, options));
    const events = collectRawEventsFromSnapshot(state.snapshots);
    state.logs.push(collectLogEntry(step, events, options, scrollState, state.keywordJumps));
    summary.scans += 1;
    const match = findLiteralKeywordMatch(events, keyword);
    const found = match.index >= 0;
    return { found, match, events };
  };

  let current = await scanCurrentView();
  if (current.found) {
    summary.found = true;
    summary.stoppedBecause = "current-collected-text";
    return {
      found: true,
      reason: `已通过当前已采集页面内容命中${formatKeywordLabel(label)}关键词`,
      summary,
      visibleMatch: buildFallbackVisibleMatch(current.match, `当前已采集页面内容命中${formatKeywordLabel(label)}关键词`)
    };
  }

  for (let i = 0; i < maxFallbackSteps; i += 1) {
    if (Date.now() - startedAt >= timeoutMs) {
      summary.stoppedBecause = "timeout";
      break;
    }
    const direction = i % 2 === 0 ? 1 : -1;
    const scrollState = await scrollFeishuPage(page, state.stepPixels * direction);
    summary.scrolls += scrollState?.moved ? 1 : 0;
    await page.waitForTimeout(state.waitMs).catch(() => {});
    current = await scanCurrentView(scrollState);
    if (current.found) {
      summary.found = true;
      summary.stoppedBecause = "limited-scroll";
      return {
        found: true,
        reason: `已通过备用有限滚动扫描命中${formatKeywordLabel(label)}关键词（${summary.scrolls}/${maxFallbackSteps}）`,
        summary,
        visibleMatch: buildFallbackVisibleMatch(current.match, `备用有限滚动扫描命中${formatKeywordLabel(label)}关键词`)
      };
    }
    if (!scrollState?.moved || (direction > 0 && scrollState.atBottom) || (direction < 0 && scrollState.atTop)) {
      summary.stoppedBecause = scrollState?.atBottom ? "bottom" : (scrollState?.atTop ? "top" : "no-scroll");
      break;
    }
  }

  if (!summary.stoppedBecause) summary.stoppedBecause = "max-steps";
  return {
    found: false,
    reason: `${formatKeywordLabel(label)}位置搜索定位失败：飞书查找框打不开，备用扫描也没找到${formatKeywordLabel(label)}关键词：${keyword}`,
    summary,
    visibleMatch: buildFallbackVisibleMatch(null, `备用扫描没有命中${formatKeywordLabel(label)}关键词`)
  };
}

function formatKeywordLabel(label) {
  if (label === "start") return "开始";
  if (label === "end") return "结束";
  return "";
}

async function addSearchTrace(page, result, stage, message, details = {}) {
  if (!result.searchTrace) result.searchTrace = [];
  const context = await readSearchPageContext(page, details.keyword || result.keyword || "");
  result.searchTrace.push({
    index: result.searchTrace.length + 1,
    stage,
    message,
    ok: details.ok !== undefined ? Boolean(details.ok) : !/^未|输入框内容未/.test(message),
    url: context.url,
    title: context.title,
    activeElement: details.activeElement || context.activeElement,
    visibleTextContainsKeyword: details.visibleTextContainsKeyword ?? context.visibleTextContainsKeyword,
    ...details
  });
}

async function readSearchPageContext(page, keyword = "") {
  let url = "";
  try {
    url = page.url();
  } catch {
    url = "";
  }
  const [title, activeElement, visibleTextContains] = await Promise.all([
    page.title().catch(() => ""),
    readActiveElementSummary(page),
    visibleTextContainsKeyword(page, keyword)
  ]);
  return {
    url,
    title,
    activeElement,
    visibleTextContainsKeyword: visibleTextContains
  };
}

async function readActiveElementSummary(page) {
  return page.evaluate(() => {
    const el = document.activeElement;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    return {
      tag: el.tagName || "",
      type: el.getAttribute?.("type") || "",
      placeholder: el.getAttribute?.("placeholder") || "",
      ariaLabel: el.getAttribute?.("aria-label") || "",
      className: String(el.className || "").slice(0, 180),
      text: String(el.value || el.innerText || el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 180),
      rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
    };
  }).catch((error) => ({ error: error?.message || String(error) }));
}

async function visibleTextContainsKeyword(page, keyword = "") {
  const needle = normalizeSearchText(keyword);
  if (!needle) return null;
  return page.evaluate((wanted) => {
    const normalize = (text) => String(text || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/[：]/g, ":")
      .replace(/\s+/g, "");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom >= 0 &&
        rect.top <= window.innerHeight &&
        style.visibility !== "hidden" &&
        style.display !== "none";
    };
    const text = Array.from(document.querySelectorAll(".ace-line,[class*='ace-line' i],main,article,[contenteditable='true']"))
      .filter(visible)
      .map((el) => el.innerText || el.textContent || "")
      .join("\n");
    return normalize(text).includes(wanted);
  }, needle).catch(() => false);
}

async function captureSearchFailureScreenshot(page, options = {}, label = "keyword", stage = "failed") {
  const dir = options.diagnosticsDir || (options.mediaCacheDir ? path.join(path.dirname(options.mediaCacheDir), "diagnostics") : "");
  if (!dir || !page?.screenshot) return "";
  try {
    await fs.mkdir(dir, { recursive: true });
    const safe = `${String(label || "keyword").replace(/[^\w-]/g, "_")}-${String(stage || "failed").replace(/[^\w-]/g, "_")}-${Date.now()}.png`;
    const filePath = path.join(dir, safe);
    await page.screenshot({ path: filePath, fullPage: false });
    return filePath;
  } catch {
    return "";
  }
}

function buildFallbackVisibleMatch(match, reason) {
  return {
    ok: Boolean(match?.index >= 0),
    candidateCount: match?.index >= 0 ? 1 : 0,
    selected: match?.selected || null,
    reason
  };
}

function keywordSatisfiedByCollectedEvents(events, keyword, keywordJumps = [], label = "") {
  if (collectHasKeyword(events, keyword)) return true;
  const jump = keywordJumps.find((item) => item.label === label);
  return Boolean(label === "start" && jump?.foundVisibleAfterJump && (jump?.outlineJump?.ok || jump?.fallback?.found));
}

async function jumpToFeishuDocumentKeyword(page, keyword, label, options = {}) {
  const target = String(keyword || "").trim();
  const parsedKeyword = parseRangeAnchorKeyword(target);
  const result = {
    label,
    keyword: target,
    parsedKeyword,
    openedFindBox: false,
    foundVisibleAfterJump: false,
    attempts: 0,
    reason: "",
    searchTrace: []
  };
  await addSearchTrace(page, result, "opened-link", "已打开飞书链接", { keyword: target });
  await addSearchTrace(page, result, "detected-title", "已检测到飞书标题");
  if (!target) {
    result.reason = "未指定关键词";
    await addSearchTrace(page, result, "empty-keyword", "未指定关键词", { ok: false });
    return result;
  }

  if (label === "start" && options.allowOutlineHeadingJump) {
    const outlineJump = await clickFeishuOutlineHeading(page, target).catch((error) => ({ ok: false, reason: error?.message || String(error) }));
    result.outlineJump = outlineJump;
    if (outlineJump?.ok) {
      result.foundVisibleAfterJump = true;
      result.reason = `已通过飞书左侧目录定位：${outlineJump.matchedText || target}`;
      await addSearchTrace(page, result, "outline-jump", "已通过飞书左侧目录定位", { matchedText: outlineJump.matchedText || target });
      return result;
    }
  }

  const variants = [target];
  const rejectedFocusTargets = [];
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    result.attempts = attempt;
    const searchText = variants[Math.min(attempt - 1, variants.length - 1)] || target;
    const overlayClose = await closeFeishuMediaPreviewOverlay(page);
    if (overlayClose.detected) result.mediaOverlayClose = overlayClose;
    await page.keyboard.press("Escape").catch(() => {});
    await page.waitForTimeout(120).catch(() => {});
    const focusResult = await focusFeishuDocumentBodyForFind(page, attempt, {
      maxScans: options.maxFocusScans,
      rejectedTargets: rejectedFocusTargets
    });
    result.focus = focusResult;
    await addSearchTrace(page, result, "body-candidates", focusResult.ok ? "已检测到正文候选区域" : "未检测到可点击正文候选区域", {
      attempt,
      ok: focusResult.ok,
      candidateCount: focusResult.candidateCount,
      bodyContainerCount: focusResult.bodyContainerCount,
      reason: focusResult.reason || ""
    });
    if (!focusResult.ok) {
      result.reason = result.reason || focusResult.reason || "没有找到可点击的飞书正文文字区域";
      result.failureScreenshot = await captureSearchFailureScreenshot(page, options, label, "body-candidates");
      return result;
    }
    await addSearchTrace(page, result, "clicked-body", "已点击正文文字块", {
      attempt,
      point: focusResult.point,
      text: focusResult.text || ""
    });
    await addSearchTrace(page, result, "shortcut-ready", "已确认页面/正文可接收快捷键", {
      attempt,
      activeElement: await readActiveElementSummary(page)
    });
    await pressFindShortcut(page);
    await addSearchTrace(page, result, "sent-find-shortcut", "已发送 Ctrl+F", {
      attempt,
      activeElement: await readActiveElementSummary(page)
    });
    await page.waitForTimeout(500).catch(() => {});

    const filled = await fillVisibleFeishuFindBox(page, searchText);
    result.findInput = filled.summary || null;
    result.findInputCandidates = filled.candidates || [];
    await addSearchTrace(page, result, "find-box-candidates", filled.candidateCount ? "已检测到查找相关面板/输入框" : "未检测到查找相关面板/输入框", {
      attempt,
      ok: Boolean(filled.candidateCount),
      candidateCount: filled.candidateCount || 0,
      candidates: (filled.candidates || []).slice(0, 5)
    });
    await addSearchTrace(page, result, "document-find-box", filled.ok ? "已确认这是飞书文档内查找框" : "未确认这是飞书文档内查找框", {
      attempt,
      ok: filled.ok,
      selected: filled.summary || null
    });
    if (!filled.ok) {
      result.reason = "没有打开飞书文档内查找框";
      result.failureScreenshot = await captureSearchFailureScreenshot(page, options, label, "find-box");
      if (focusResult?.point || focusResult?.text) {
        rejectedFocusTargets.push({
          text: focusResult.text || "",
          point: focusResult.point || null
        });
      }
      await page.keyboard.press("Escape").catch(() => {});
      await page.waitForTimeout(160).catch(() => {});
      continue;
    }

    result.openedFindBox = true;
    result.searchText = searchText;
    await addSearchTrace(page, result, "typed-keyword", `已输入${formatKeywordLabel(label)}关键词`, {
      attempt,
      searchText,
      inputValue: filled.value || ""
    });
    await addSearchTrace(page, result, "confirmed-input", filled.valueOk ? "已确认输入框内容正确" : "输入框内容未确认正确", {
      attempt,
      ok: filled.valueOk,
      expected: searchText,
      actual: filled.value || ""
    });
    if (!filled.valueOk) {
      result.reason = "飞书文档内查找框已打开，但输入内容未确认正确";
      result.failureScreenshot = await captureSearchFailureScreenshot(page, options, label, "input-value");
      return result;
    }
    await page.keyboard.press("Enter").catch(() => {});
    await addSearchTrace(page, result, "triggered-search", "已触发搜索/跳转", {
      attempt,
      activeElement: await readActiveElementSummary(page)
    });
    await page.waitForTimeout(900).catch(() => {});
    result.findPanelText = await readFeishuFindPanelText(page);
    result.loginHint = await readFeishuLoginHint(page);
    result.visibleMatch = await findVisibleRangeAnchorMatch(page, parsedKeyword, variants, result.findPanelText);
    result.foundVisibleAfterJump = result.visibleMatch.ok;
    await addSearchTrace(page, result, "visible-keyword-match", result.foundVisibleAfterJump ? `已在可见正文附近命中${formatKeywordLabel(label)}关键词` : `未在可见正文附近命中${formatKeywordLabel(label)}关键词`, {
      attempt,
      ok: result.foundVisibleAfterJump,
      findPanelText: result.findPanelText || "",
      visibleMatch: result.visibleMatch || null,
      visibleTextContainsKeyword: await visibleTextContainsKeyword(page, searchText)
    });
    await page.keyboard.press("Escape").catch(() => {});
    await page.waitForTimeout(300).catch(() => {});
    if (result.foundVisibleAfterJump) {
      result.reason = "已通过飞书文档内查找定位，并完成结构化候选校验";
      await addSearchTrace(page, result, "collect-from-match", `已从命中位置开始采集${formatKeywordLabel(label) ? `（${formatKeywordLabel(label)}关键词）` : ""}`);
      return result;
    }
    if (/\b0\s*\/\s*0\b|无结果|未找到|没有找到/.test(result.findPanelText || "")) {
      result.reason = `飞书文档内查找返回 0/0，搜索词：${searchText}`;
    } else {
      result.reason = result.visibleMatch.reason || "飞书查找框打开了，但当前正文还没显示匹配的结构化候选";
    }
    result.failureScreenshot = await captureSearchFailureScreenshot(page, options, label, "visible-match");
  }

  return result;
}

async function closeFeishuMediaPreviewOverlay(page) {
  const detected = await detectFeishuMediaPreviewOverlay(page);
  if (!detected.detected) return detected;
  await page.keyboard.press("Escape").catch(() => {});
  await page.waitForTimeout(180).catch(() => {});
  let afterEscape = await detectFeishuMediaPreviewOverlay(page);
  if (!afterEscape.detected) {
    return { ...detected, closed: true, method: "escape" };
  }

  const clicked = await page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom >= 0 &&
        rect.top <= window.innerHeight &&
        style.visibility !== "hidden" &&
        style.display !== "none";
    };
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const overlay = findMediaOverlay();
    if (!overlay) return false;
    const buttons = Array.from(overlay.querySelectorAll("button,[role='button'],[aria-label],[title],svg"))
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = clean(`${el.innerText || el.textContent || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("title") || ""} ${el.className || ""}`);
        const nearCorner = rect.top <= overlay.getBoundingClientRect().top + 90 || rect.right >= overlay.getBoundingClientRect().right - 120;
        const closeLike = /关闭|close|取消|×|x/i.test(text);
        return { el, score: (closeLike ? 20 : 0) + (nearCorner ? 5 : 0) };
      })
      .filter((item) => item.score >= 20)
      .sort((a, b) => b.score - a.score);
    const selected = buttons[0];
    if (!selected) return false;
    selected.el.click();
    return true;

    function findMediaOverlay() {
      const candidates = Array.from(document.querySelectorAll("[role='dialog'],[class*='modal' i],[class*='preview' i],[class*='player' i],[class*='xgplayer' i],[class*='viewer' i]"))
        .filter(visible)
        .filter(isMediaOverlay)
        .sort((a, b) => Number(getComputedStyle(b).zIndex || 0) - Number(getComputedStyle(a).zIndex || 0));
      return candidates[0] || null;
    }

    function isMediaOverlay(el) {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      const classText = String(el.className || "").toLowerCase();
      const fixedLayer = style.position === "fixed" || rect.width >= window.innerWidth * 0.45 && rect.height >= window.innerHeight * 0.35;
      const mediaLike = el.querySelector("video,img,canvas,[class*='xgplayer' i],[class*='player' i],[class*='preview' i]") ||
        /xgplayer|player|viewer|preview|modal|image|video|media|图片|视频/.test(classText);
      return Boolean(fixedLayer && mediaLike);
    }
  }).catch(() => false);
  if (clicked) {
    await page.waitForTimeout(180).catch(() => {});
    afterEscape = await detectFeishuMediaPreviewOverlay(page);
    if (!afterEscape.detected) return { ...detected, closed: true, method: "close-button" };
  }
  return { ...detected, closed: false, method: clicked ? "close-button" : "escape", reason: "媒体预览浮层仍然可见" };
}

async function detectFeishuMediaPreviewOverlay(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom >= 0 &&
        rect.top <= window.innerHeight &&
        style.visibility !== "hidden" &&
        style.display !== "none";
    };
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const candidates = Array.from(document.querySelectorAll("[role='dialog'],[class*='modal' i],[class*='preview' i],[class*='player' i],[class*='xgplayer' i],[class*='viewer' i]"))
      .filter(visible)
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        const classText = String(el.className || "").toLowerCase();
        const fixedLayer = style.position === "fixed" || rect.width >= window.innerWidth * 0.45 && rect.height >= window.innerHeight * 0.35;
        const mediaLike = el.querySelector("video,img,canvas,[class*='xgplayer' i],[class*='player' i],[class*='preview' i]") ||
          /xgplayer|player|viewer|preview|modal|image|video|media|图片|视频/.test(classText);
        if (!fixedLayer || !mediaLike) return false;
        const text = clean(el.innerText || el.textContent || "");
        if (/在文档内查找|查找\s*替换/.test(text) && !el.querySelector("video,img,canvas")) return false;
        return true;
      })
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          className: String(el.className || "").slice(0, 160),
          role: el.getAttribute("role") || "",
          text: clean(el.innerText || el.textContent || "").slice(0, 160),
          rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
        };
      })
      .sort((a, b) => b.rect.width * b.rect.height - a.rect.width * a.rect.height);
    const first = candidates[0];
    return first
      ? { detected: true, closed: false, summary: first }
      : { detected: false, closed: false };
  }).catch((error) => ({ detected: false, closed: false, reason: error?.message || String(error) }));
}

async function focusFeishuDocumentBodyForFind(page, attempt = 1, options = {}) {
  const maxScans = Math.max(1, Number(options.maxScans || 6));
  const rejectedTargets = Array.isArray(options.rejectedTargets) ? options.rejectedTargets : [];
  for (let scan = 0; scan < maxScans; scan += 1) {
    const point = await page.evaluate(({ tryIndex, scanIndex, rejectedTargets }) => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom >= 100 &&
        rect.top <= window.innerHeight - 60 &&
        style.visibility !== "hidden" &&
        style.display !== "none";
    };
    const elementText = (el) => String(el?.innerText || el?.textContent || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .trim();
    const compact = (value) => String(value || "").replace(/\s+/g, "");
    const isDocumentMetaText = (value) => {
      const text = compact(value);
      return /^(今天修改|昨天修改|前天修改|刚刚修改|最近修改|最后修改|上次修改|\d{1,2}分钟前修改|\d{1,2}小时前修改)$/.test(text);
    };
    const isRejectedTarget = (text, rect) => {
      const compactText = compact(text);
      return (rejectedTargets || []).some((item) => {
        if (compact(item?.text) && compact(item.text) === compactText) return true;
        const point = item?.point;
        if (!point || !rect) return false;
        const x = Number(point.x);
        const y = Number(point.y);
        const candidateX = Math.min(rect.right - 3, Math.max(rect.left + 3, rect.left + rect.width * 0.35));
        const candidateY = Math.min(rect.bottom - 3, Math.max(rect.top + 3, rect.top + rect.height * 0.5));
        return Number.isFinite(x) &&
          Number.isFinite(y) &&
          Math.abs(x - candidateX) <= 12 &&
          Math.abs(y - candidateY) <= 8;
      });
    };
    const closestWithin = (el, selector, maxDepth = 4) => {
      let node = el;
      for (let depth = 0; node && depth <= maxDepth; depth += 1, node = node.parentElement) {
        if (node.matches?.(selector)) return node;
      }
      return null;
    };
    const isForbiddenArea = (el) => {
      if (!el?.closest) return true;
      if (el.closest([
        "button",
        "a",
        "input",
        "textarea",
        "select",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "img",
        "video",
        "canvas",
        "svg",
        "[data-v2-kind='title']",
        "[role='button']",
        "[role='tab']",
        "[role='dialog']",
        "[role='navigation']"
      ].join(","))) return true;
      return Boolean(closestWithin(el, [
        "[class*='toolbar' i]",
        "[class*='menu' i]",
        "[class*='catalog' i]",
        "[class*='catalogue' i]",
        "[class*='outline' i]",
        "[class*='sidebar' i]",
        "[class*='popover' i]",
        "[class*='modal' i]",
        "[class*='tooltip' i]",
        "[class*='preview' i]",
        "[class*='player' i]",
        "[class*='xgplayer' i]",
        "[class*='viewer' i]",
        "[class*='video' i]",
        "[class*='sticker' i]",
        "[data-testid*='catalog' i]",
        "[data-testid*='outline' i]",
        "[data-testid*='comment' i]"
      ].join(","), 4));
    };
    const documentSideBounds = () => {
      const sideRegions = Array.from(document.querySelectorAll([
        "[class*='catalog' i]",
        "[class*='catalogue' i]",
        "[class*='outline' i]",
        "[class*='sidebar' i]",
        "[class*='comment' i]",
        "[aria-label*='目录' i]",
        "[aria-label*='评论' i]",
        "[data-testid*='catalog' i]",
        "[data-testid*='outline' i]",
        "[data-testid*='comment' i]",
        "[role='navigation']"
      ].join(",")))
        .filter(visible)
        .map((item) => item.getBoundingClientRect())
        .filter((item) => item.height > 120 && item.width > 80 && item.width < window.innerWidth * 0.55);
      const leftSidebarRight = Math.max(0, ...sideRegions
        .filter((item) => item.left <= 80 && item.right < window.innerWidth * 0.55)
        .map((item) => item.right));
      const rightSidebarLeft = Math.min(window.innerWidth, ...sideRegions
        .filter((item) => item.right >= window.innerWidth - 80 && item.left > window.innerWidth * 0.45)
        .map((item) => item.left));
      const leftBoundary = leftSidebarRight ? Math.min(leftSidebarRight + 12, window.innerWidth * 0.45) : 0;
      const rightBoundary = rightSidebarLeft < window.innerWidth ? Math.max(rightSidebarLeft - 12, window.innerWidth * 0.55) : window.innerWidth;
      return { leftBoundary, rightBoundary };
    };
    const findBodyContainers = () => Array.from(document.querySelectorAll([
      "[data-v2-feishu-fixture]",
      "[contenteditable='true']",
      "[class*='ace_editor' i]",
      "[class*='ace-line' i]",
      "[class*='docx' i]",
      "[class*='editor' i]",
      "[class*='reader' i]",
      "[class*='render' i]",
      "main",
      "article"
    ].join(",")))
      .filter((el) => visible(el) && !isForbiddenArea(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return { el, rect, area: rect.width * rect.height };
      })
      .filter((item) => item.rect.width > 180 && item.rect.height > 10 && item.rect.right > 360 && item.rect.bottom > 120)
      .sort((a, b) => b.area - a.area);
    const bodyContainers = findBodyContainers();
    const inBodyContainer = (el) => bodyContainers.some((item) => item.el === el || item.el.contains(el));
    const inDoc = (el) => {
      if (!el?.closest) return false;
      if (isForbiddenArea(el)) return false;
      if (!inBodyContainer(el)) return false;
      const rect = el.getBoundingClientRect();
      const { leftBoundary } = documentSideBounds();
      return rect.left > leftBoundary + 4 &&
        rect.top > 90 &&
        rect.bottom < window.innerHeight - 30;
    };
    const scrollMainDocument = () => {
      const candidates = bodyContainers.map((item) => item.el)
        .filter((el) => !isForbiddenArea(el))
        .map((el) => {
          const rect = el.getBoundingClientRect();
          const style = getComputedStyle(el);
          const scrollable = /(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && el.scrollHeight > el.clientHeight + 20;
          return { el, rect, scrollable, area: rect.width * rect.height };
        })
        .filter((item) => item.rect.width > 300 && item.rect.height > 180 && item.rect.right > 420)
        .sort((a, b) => Number(b.scrollable) - Number(a.scrollable) || b.area - a.area);
      const distance = 220;
      for (const item of candidates.slice(0, 3)) {
        if (item.scrollable) {
          const before = item.el.scrollTop;
          item.el.scrollTop += distance;
          if (item.el.scrollTop !== before) return true;
        }
      }
      const before = window.scrollY;
      window.scrollBy(0, distance);
      return window.scrollY !== before;
    };
    const pushCandidate = (items, rect, text, score) => {
      const cleanText = String(text || "").trim();
      const compactText = cleanText.replace(/\s+/g, "");
      if (!cleanText || cleanText.length < 2 || cleanText.length > 160) return;
      if (/^(评论[（(]?\d*[）)]?|查找|替换|上一处|下一处|登录|注册|分享|复制)$/.test(compactText)) return;
      if (isDocumentMetaText(compactText)) return;
      const { leftBoundary, rightBoundary } = documentSideBounds();
      if (rect.width <= 0 || rect.height <= 0 || rect.top < 110 || rect.top > window.innerHeight - 80) return;
      if (rect.left <= leftBoundary + 4 || rect.right >= rightBoundary - 4) return;
      if (isRejectedTarget(cleanText, rect)) return;
      items.push({
        x: Math.min(rect.right - 3, Math.max(rect.left + 3, rect.left + rect.width * 0.35)),
        y: Math.min(rect.bottom - 3, Math.max(rect.top + 3, rect.top + rect.height * 0.5)),
        text: cleanText.slice(0, 120),
        score
      });
    };
    const textNodes = [];
    for (const el of Array.from(document.querySelectorAll([
      "[data-v2-kind='line']",
      ".ace-line",
      "[class*='ace-line' i]"
    ].join(",")))) {
      if (!visible(el) || !inDoc(el)) continue;
      pushCandidate(textNodes, el.getBoundingClientRect(), elementText(el), 140);
    }
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const text = String(node.nodeValue || "").trim();
      const parent = node.parentElement;
      if (!text || text.length < 2 || text.length > 160 || !parent || !visible(parent) || !inDoc(parent)) continue;
      const range = document.createRange();
      range.selectNodeContents(node);
      const rect = range.getBoundingClientRect();
      range.detach();
      pushCandidate(textNodes, rect, elementText(parent) || text, rect.top > 160 ? 120 : 80);
    }
    textNodes.sort((a, b) => b.score - a.score);
    if (textNodes[0]) {
      return {
        ...textNodes[0],
        candidateCount: textNodes.length,
        bodyContainerCount: bodyContainers.length
      };
    }
    if ((rejectedTargets || []).length) {
      return { moved: false, reason: "当前可见区域没有剩余可点击的飞书正文文字" };
    }
    const moved = scrollMainDocument();
    return {
      moved,
      candidateCount: textNodes.length,
      bodyContainerCount: bodyContainers.length,
      reason: moved ? "当前可见区域没有正文文字，已小幅滚动正文区域继续查找" : "当前可见区域没有可点击的正文文字"
    };
  }, { tryIndex: attempt, scanIndex: scan, rejectedTargets }).catch((error) => ({ error: error?.message || String(error) }));
    if (point?.x && point?.y) {
      await page.mouse.click(point.x, point.y).catch(() => {});
      await page.waitForTimeout(100).catch(() => {});
      return {
        ok: true,
        point: { x: point.x, y: point.y },
        text: point.text || "",
        candidateCount: point.candidateCount ?? null,
        bodyContainerCount: point.bodyContainerCount ?? null
      };
    }
    if (point?.error) return { ok: false, reason: point.error };
    if (!point?.moved) return { ok: false, reason: point?.reason || "当前可见区域没有可点击的正文文字" };
    await page.waitForTimeout(160).catch(() => {});
  }
  return { ok: false, reason: `连续 ${maxScans} 次小幅滚动后仍没有找到可点击的飞书正文文字` };
}

async function pressFindShortcut(page) {
  const modifier = process.platform === "darwin" ? "Meta" : "Control";
  await page.keyboard.down(modifier).catch(() => {});
  await page.keyboard.press("KeyF").catch(() => {});
  await page.keyboard.up(modifier).catch(() => {});
}

async function fillVisibleFeishuFindBox(page, keyword) {
  const match = await page.evaluate(() => {
    const isVisible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom >= 0 &&
        rect.top <= window.innerHeight &&
        style.visibility !== "hidden" &&
        style.display !== "none";
    };
    const candidates = Array.from(document.querySelectorAll("input, textarea"))
      .filter(isVisible)
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        const classText = String(el.className || "").toLowerCase();
        if (rect.left < 0 || rect.top < 0 || rect.width < 40 || rect.height < 12) return false;
        if (/selection-hidden|hidden-textarea/.test(classText)) return false;
        return true;
      })
      .map((el, index) => {
        const rect = el.getBoundingClientRect();
        const panel = el.closest("[role='dialog'],[class*='find'],[class*='search'],[class*='modal'],[class*='popover'],[class*='panel']") || el.parentElement;
        const text = [
          el.getAttribute("placeholder"),
          el.getAttribute("aria-label"),
          el.getAttribute("data-placeholder"),
          el.className,
          panel?.innerText,
          panel?.textContent
        ].filter(Boolean).join(" ");
        const isDocumentFind = /在文档内查找/.test(text) || (/查找/.test(text) && /替换/.test(text));
        const isGlobalSearch = /高级搜索|搜索历史|最近浏览|搜索文档名称|查看更多最近浏览页面|所有者|最近修改/.test(text);
        if (!isDocumentFind || isGlobalSearch) {
          return {
            el,
            index,
            score: -1000,
            isDocumentFind,
            summary: {
              tag: el.tagName,
              placeholder: el.getAttribute("placeholder") || "",
              ariaLabel: el.getAttribute("aria-label") || "",
              className: String(el.className || ""),
              panelClass: String(panel?.className || ""),
              panelText: String(panel?.innerText || panel?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 300),
              rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
            }
          };
        }
        const panelClass = String(panel?.className || "").toLowerCase();
        let score = 0;
        if (document.activeElement === el) score += 50;
        if (/在文档内查找/.test(String(el.getAttribute("placeholder") || ""))) score += 220;
        if (/在文档内查找/.test(text)) score += 160;
        if (/查找/.test(text) && /替换/.test(text)) score += 90;
        if (/find|search/.test(panelClass)) score += 50;
        if (rect.top < 260) score += 20;
        if (rect.left < window.innerWidth * 0.7 && rect.top < window.innerHeight * 0.5) score += 10;
        return {
          el,
          index,
          score,
          isDocumentFind,
          summary: {
            tag: el.tagName,
            placeholder: el.getAttribute("placeholder") || "",
            ariaLabel: el.getAttribute("aria-label") || "",
            className: String(el.className || ""),
            panelClass: String(panel?.className || ""),
            panelText: String(panel?.innerText || panel?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 300),
            rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
          }
        };
      })
      .sort((a, b) => b.score - a.score);
    const best = candidates[0];
    const summaries = candidates.slice(0, 8).map((item) => ({ ...item.summary, score: item.score }));
    if (!best || best.score < 180 || !best.isDocumentFind) {
      return { id: "", summary: best?.summary || null, candidateCount: candidates.length, candidates: summaries };
    }
    const marker = `v2-feishu-find-${Date.now()}-${best.index}`;
    best.el.setAttribute("data-v2-feishu-find-input", marker);
    return { id: marker, summary: best.summary, candidateCount: candidates.length, candidates: summaries };
  }).catch(() => ({ id: "", summary: null, candidateCount: 0, candidates: [] }));

  if (!match.id) {
    return {
      ok: false,
      summary: match.summary || null,
      candidateCount: match.candidateCount || 0,
      candidates: match.candidates || [],
      valueOk: false,
      value: ""
    };
  }
  const id = match.id;
  const locator = page.locator(`[data-v2-feishu-find-input="${id}"]`).first();
  await locator.click({ timeout: 1200 }).catch(() => {});
  await page.keyboard.press(process.platform === "darwin" ? "Meta+A" : "Control+A").catch(() => {});
  await page.keyboard.press("Backspace").catch(() => {});
  await page.waitForTimeout(80).catch(() => {});
  await page.keyboard.insertText(keyword).catch(() => {});
  await page.waitForTimeout(160).catch(() => {});
  const valueOk = await locator.evaluate((el, wanted) => String(el.value || el.textContent || "").includes(wanted), keyword).catch(() => false);
  if (!valueOk) {
    await locator.fill(keyword).catch(() => {});
    await page.waitForTimeout(160).catch(() => {});
  }
  const value = await locator.evaluate((el) => String(el.value || el.textContent || "")).catch(() => "");
  const finalValueOk = String(value || "").includes(keyword);
  return {
    ok: true,
    summary: match.summary || null,
    candidateCount: match.candidateCount || 0,
    candidates: match.candidates || [],
    valueOk: finalValueOk,
    value
  };
}

async function readFeishuFindPanelText(page) {
  return page.evaluate(() => {
    const isVisible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom >= 0 &&
        rect.top <= window.innerHeight &&
        style.visibility !== "hidden" &&
        style.display !== "none";
    };
    const candidates = Array.from(document.querySelectorAll("[role='dialog'],[class*='find'],[class*='search'],[class*='popover'],[class*='panel']"))
      .filter(isVisible)
      .map((el) => String(el.innerText || el.textContent || "").replace(/\s+/g, " ").trim())
      .filter((text) => /查找|替换|上一处|下一处|无结果|未找到|没有找到|\d+\s*\/\s*\d+/.test(text))
      .sort((a, b) => b.length - a.length);
    return candidates[0]?.slice(0, 500) || "";
  }).catch(() => "");
}

async function readFeishuLoginHint(page) {
  return page.evaluate(() => {
    const text = String(document.body?.innerText || document.body?.textContent || "");
    if (/登录\/注册|登录|立即编辑/.test(text)) return "页面出现登录/注册或立即编辑提示";
    return "";
  }).catch(() => "");
}

async function findVisibleRangeAnchorMatch(page, anchor, fallbackKeywords = [], findPanelText = "") {
  return page.evaluate(({ anchor, fallbackKeywords, findPanelText }) => {
    const normalize = (text) => String(text || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/[：]/g, ":")
      .replace(/\s+/g, "");
    const clean = (text) => String(text || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    const normalizeTime = (value) => {
      const match = String(value || "").match(/(\d{1,2})[：:](\d{2})(?:[：:](\d{2}))?/);
      if (!match) return "";
      return `${String(match[1]).padStart(2, "0")}:${match[2]}:${String(match[3] || "00").padStart(2, "0")}`;
    };
    const normalizeDate = (value) => {
      const match = String(value || "").match(/(\d{1,2})\s*[\/月]\s*(\d{1,2})(?:日|号)?/);
      return match ? `${Number(match[1])}/${Number(match[2])}` : "";
    };
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom >= 80 &&
        rect.top <= window.innerHeight + 120 &&
        style.visibility !== "hidden" &&
        style.display !== "none";
    };
    const closestWithin = (el, selector, maxDepth = 4) => {
      let node = el;
      for (let depth = 0; node && depth <= maxDepth; depth += 1, node = node.parentElement) {
        if (node.matches?.(selector)) return node;
      }
      return null;
    };
    const forbidden = (el) => {
      if (!el?.closest) return true;
      if (el.closest([
        "button",
        "a",
        "input",
        "textarea",
        "select",
        "img",
        "video",
        "canvas",
        "svg",
        "[role='button']",
        "[role='tab']",
        "[role='dialog']",
        "[role='navigation']"
      ].join(","))) return true;
      return Boolean(closestWithin(el, [
        "[class*='toolbar' i]",
        "[class*='menu' i]",
        "[class*='catalog' i]",
        "[class*='catalogue' i]",
        "[class*='outline' i]",
        "[class*='sidebar' i]",
        "[class*='popover' i]",
        "[class*='modal' i]",
        "[class*='tooltip' i]",
        "[class*='preview' i]",
        "[class*='player' i]",
        "[class*='xgplayer' i]",
        "[class*='viewer' i]",
        "[class*='video' i]",
        "[class*='sticker' i]",
        "[data-testid*='catalog' i]",
        "[data-testid*='outline' i]",
        "[data-testid*='comment' i]"
      ].join(","), 4));
    };
    const findPanelUnique = /\b1\s*\/\s*1\b/.test(String(findPanelText || ""));
    const lineElements = Array.from(document.querySelectorAll(".ace-line,[class*='ace-line' i],h1,h2,h3,[data-block-id],[data-uuid],[contenteditable='true'] p,[contenteditable='true'] div,main p,main div"))
      .filter(visible)
      .filter((el) => !forbidden(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          text: clean(el.innerText || el.textContent || ""),
          top: rect.top,
          left: rect.left
        };
      })
      .filter((item) => item.text && item.text.length <= 260)
      .sort((a, b) => a.top - b.top || a.left - b.left);

    const targets = [anchor?.original, ...fallbackKeywords].map(normalize).filter(Boolean);
    const visibleText = normalize(lineElements.map((item) => item.text).join("\n"));
    const matched = targets.find((target) => visibleText.includes(target));
    if (matched) {
      return { ok: true, candidateCount: 1, selected: { text: matched }, reason: "原始关键词可见" };
    }
    const structured = Boolean(anchor?.time || anchor?.date);
    if (!structured) {
      return { ok: false, candidateCount: 0, reason: "当前正文可见区域没有原始搜索关键词" };
    }
    if (findPanelUnique) {
      return { ok: true, candidateCount: 1, selected: { text: fallbackKeywords[0] || anchor?.original || "" }, reason: "飞书查找结果唯一，按原始关键词命中" };
    }
    return { ok: false, candidateCount: 0, reason: "当前正文可见区域没有原始搜索关键词" };

    const candidates = [];
    const speakerTargets = [anchor.speaker, anchor.cleanSpeaker].map(normalize).filter(Boolean);
    for (let index = 0; index < lineElements.length; index += 1) {
      const item = lineElements[index];
      const current = normalize(item.text);
      const nearby = [
        lineElements[index - 3]?.text,
        lineElements[index - 2]?.text,
        lineElements[index - 1]?.text,
        item.text,
        lineElements[index + 1]?.text,
        lineElements[index + 2]?.text
      ].filter(Boolean).join(" ");
      const direct = Boolean(anchor.original && current.includes(normalize(anchor.original)));
      const date = normalizeDate(item.text);
      const time = normalizeTime(item.text);
      const reasons = [];
      if (anchor.time) {
        if (time !== anchor.time && !current.includes(normalize(anchor.time))) continue;
        reasons.push("time");
      }
      if (anchor.date) {
        if (date !== anchor.date && !current.includes(normalize(anchor.date))) continue;
        reasons.push("date");
      }
      if (speakerTargets.length) {
        if (!speakerTargets.some((speaker) => current.includes(speaker))) continue;
        reasons.push("speaker");
      }
      candidates.push({
        index,
        text: item.text,
        nearby: clean(nearby).slice(0, 180),
        date: date || "",
        time: time || "",
        reasons,
        direct
      });
    }
    const directCandidates = candidates.filter((candidate) => candidate.direct);
    if (directCandidates.length === 1) {
      return { ok: true, candidateCount: candidates.length, selected: directCandidates[0], candidates: candidates.slice(0, 8), reason: "结构化候选按原始输入唯一匹配" };
    }
    if (candidates.length > 1 && findPanelUnique) {
      return { ok: true, candidateCount: candidates.length, selected: directCandidates[0] || candidates[0], candidates: candidates.slice(0, 8), reason: "飞书查找结果唯一，DOM 重复候选已合并" };
    }
    if (candidates.length === 1) {
      return { ok: true, candidateCount: 1, selected: candidates[0], reason: "结构化候选唯一匹配" };
    }
    if (candidates.length > 1) {
      return { ok: false, candidateCount: candidates.length, candidates: candidates.slice(0, 8), reason: "结构化候选不唯一，需要人工确认" };
    }
    if (findPanelUnique) {
      return { ok: true, candidateCount: 1, selected: { text: fallbackKeywords[0] || anchor?.original || "" }, reason: "飞书查找结果唯一，按原始关键词命中" };
    }
    return { ok: false, candidateCount: 0, reason: "当前正文可见区域没有匹配 speaker/date/time 的候选" };
  }, { anchor, fallbackKeywords, findPanelText }).catch((error) => ({ ok: false, candidateCount: 0, reason: error?.message || String(error) }));
}

async function isAnyDocumentKeywordVisible(page, keywords) {
  return page.evaluate((wantedList) => {
    const normalize = (text) => String(text || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/[：]/g, ":")
      .replace(/\s+/g, "");
    const targets = wantedList.map(normalize).filter(Boolean);
    if (!targets.length) return false;
    const isVisible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom >= 80 &&
        rect.top <= window.innerHeight + 120 &&
        style.visibility !== "hidden" &&
        style.display !== "none";
    };
    const text = Array.from(document.querySelectorAll("body *"))
      .filter(isVisible)
      .map((el) => {
        const value = String(el.innerText || el.textContent || "");
        if (/查找|替换|上一处|下一处|在文档内查找/.test(value)) return "";
        return value;
      })
      .join("\n");
    const normalizedText = normalize(text);
    return targets.some((target) => normalizedText.includes(target));
  }, keywords).catch(() => false);
}

async function scrollFeishuPage(page, distance) {
  return page.evaluate((scrollDistance) => {
    const findMainScrollable = () => {
      const visible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 &&
          rect.height > 0 &&
          style.visibility !== "hidden" &&
          style.display !== "none" &&
          rect.left < innerWidth &&
          rect.right > 0 &&
          rect.top < innerHeight &&
          rect.bottom > 0;
      };
      return Array.from(document.querySelectorAll("*"))
      .map((el) => {
        const style = getComputedStyle(el);
        const scrollable = /(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && el.scrollHeight > el.clientHeight + 20;
        if (!scrollable || !visible(el)) return null;
        const rect = el.getBoundingClientRect();
        const text = String(el.className || "") + " " + String(el.id || "");
        let score = el.scrollHeight - el.clientHeight;
        score += rect.width * rect.height / 10000;
        if (/editor|docx|scroll|content|reader|page/i.test(text)) score += 500;
        if (rect.left > innerWidth * 0.75 || rect.right < innerWidth * 0.15) score -= 1000;
        return {
          el,
          score
        };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score)[0]?.el || null;
    };

    const beforeWindow = window.scrollY;
    const target = findMainScrollable();
    const targetBefore = target ? target.scrollTop : 0;
    const targetMax = target ? Math.max(0, target.scrollHeight - target.clientHeight) : 0;

    if (target) {
      target.scrollTop = Math.max(0, Math.min(targetMax, target.scrollTop + scrollDistance));
    } else {
      window.scrollBy(0, scrollDistance);
    }

    const afterWindow = window.scrollY;
    const targetAfter = target ? target.scrollTop : 0;
    const windowMax = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) - window.innerHeight;
    const anyMoved = afterWindow !== beforeWindow || targetAfter !== targetBefore;
    const scrollingDown = scrollDistance >= 0;
    const anyCanMoveMoreDown = target ? targetAfter < targetMax - 5 : afterWindow < windowMax - 5;
    const anyCanMoveMoreUp = target ? targetAfter > 5 : afterWindow > 5;
    return {
      moved: anyMoved,
      atBottom: !anyCanMoveMoreDown,
      atTop: !anyCanMoveMoreUp,
      windowBefore: beforeWindow,
      windowAfter: afterWindow,
      targetBefore,
      targetAfter,
      targetMax,
      direction: scrollingDown ? "down" : "up",
      scrollTarget: target ? "element" : "window",
      scrolledElements: target ? 1 : 0
    };
  }, distance).catch(() => ({ moved: false, atBottom: false, scrolledElements: 0 }));
}

function collectLogEntry(scrollCount, events, options = {}, scrollState = null, keywordJumps = []) {
  const last = events.at(-1) || null;
  return {
    scrollCount,
    collectPass: Number(options.collectPass || 1),
    collectPhase: options.collectPhase || "scan",
    collectedEventCount: events.length,
    foundStartKeyword: options.startKeyword ? keywordSatisfiedByCollectedEvents(events, options.startKeyword, keywordJumps, "start") : null,
    foundEndKeyword: options.endKeyword ? collectHasKeyword(events, options.endKeyword) : null,
    lastEvent: summarizeCollectedEvent(last),
    scrollState: scrollState ? {
      moved: Boolean(scrollState.moved),
      atBottom: Boolean(scrollState.atBottom),
      windowBefore: scrollState.windowBefore,
      windowAfter: scrollState.windowAfter,
      targetBefore: scrollState.targetBefore,
      targetAfter: scrollState.targetAfter,
      targetMax: scrollState.targetMax,
      scrollTarget: scrollState.scrollTarget,
      scrolledElements: scrollState.scrolledElements
    } : null
  };
}

function buildCollectDiagnostics({ logs = [], stoppedBecause = "", startKeyword = "", endKeyword = "", keywordJumps = [], bottomConfirmations = 0, finderCodeBlocks = null, overlayClosures = [] } = {}) {
  const lastLog = logs.at(-1) || collectLogEntry(0, [], { startKeyword, endKeyword });
  const startJump = keywordJumps.find((item) => item.label === "start");
  const reportFindPositionScrollCount = Boolean(startKeyword && !endKeyword && startJump?.openedFindBox && startJump?.foundVisibleAfterJump);
  return {
    scrollCount: reportFindPositionScrollCount ? 0 : Math.max(0, lastLog.scrollCount),
    collectedEventCount: lastLog.collectedEventCount,
    foundStartKeyword: lastLog.foundStartKeyword,
    foundEndKeyword: lastLog.foundEndKeyword,
    lastEvent: lastLog.lastEvent,
    stoppedBecause,
    documentEndConfirmed: stoppedBecause === "bottom-confirmed" || stoppedBecause === "bottom",
    bottomConfirmations,
    lastScrollState: lastLog.scrollState,
    keywordJumps,
    finderCodeBlocks: finderCodeBlocks || summarizeFinderCodeBlockCopyDiagnostics([]),
    overlayClosures,
    logs
  };
}

function summarizeCollectedEvent(event) {
  if (!event) return null;
  return {
    sourceId: event.sourceId,
    order: event.order,
    type: event.type || event.kind,
    text: event.text,
    mediaPath: event.mediaPath || event.assetUrl || ""
  };
}

function eventListSignature(events = []) {
  const last = events.at(-1) || {};
  return [
    events.length,
    last.sourceId || "",
    last.type || last.kind || "",
    normalizeSearchText(last.text || last.sourceText || ""),
    last.mediaPath || last.assetUrl || ""
  ].join("|");
}

function firstContentImageExists(events) {
  const firstMedia = events.find((event) => ["image", "sticker", "video"].includes(event.type || event.kind));
  return Boolean(firstMedia && (firstMedia.type === "image" || firstMedia.kind === "image"));
}

function normalizeType(type) {
  const name = String(type || "line").toLowerCase();
  if (["line", "title", "image", "sticker", "video", "divider"].includes(name)) return name;
  return "line";
}

function inferCollectedItemType(item) {
  const explicit = normalizeType(item.type || item.kind);
  const text = normalizeSearchText(item.text || item.sourceText);
  const media = String(item.mediaPath || item.assetUrl || item.src || "");
  if (explicit === "image" && hasStickerMediaEvidence(text, media)) return "sticker";
  if (explicit !== "line") return explicit;
  if (!media) return explicit;
  if (!text && /^(blob:|image-blob:)/i.test(media)) return "image";
  if (hasStickerMediaEvidence(text, media)) return "sticker";
  if (text === "视频" || /\/video\/|\.mp4(?:\?|#|$)|quality=/i.test(media)) return "video";
  if (isLikelyImageMediaUrl(media)) return "image";
  return explicit;
}

function hasStickerMediaEvidence(text, media) {
  return isStickerMarkerText(text) ||
    /\.(?:gif|webp)(?:\?|#|$)/i.test(media) ||
    /sticker|emoji|emoticon|表情/i.test(media);
}

function isStickerMarkerText(text) {
  return text === "表情包" || text === "动态表情";
}

function isLikelyImageMediaUrl(value) {
  const text = String(value || "");
  return /^data:image\//i.test(text) ||
    /\.(?:jpe?g|png|webp)(?:\?|#|$)/i.test(text) ||
    /internal-api-drive-stream\.feishu\.cn\/space\/api\/box\/stream\/download\/preview\//i.test(text) ||
    /\/space\/api\/box\/stream\/download\/v2\/cover\//i.test(text) ||
    /\/space\/api\/box\/stream\/download\/preview\/[^?#/]+\/?\?[^#]*preview_type=16/i.test(text);
}

function mergeSnapshotItems(target, snapshotItems = []) {
  for (const item of Array.isArray(snapshotItems) ? snapshotItems : []) {
    const duplicateIndex = target.findIndex((existing) => sameRawItemAcrossSnapshots(existing, item));
    if (duplicateIndex >= 0) {
      const existing = target[duplicateIndex];
      if (preferRawSnapshotItem(item, existing)) {
        target[duplicateIndex] = {
          ...item,
          order: existing.order,
          blockIndex: existing.blockIndex
        };
      }
      continue;
    }
    const order = target.length;
    target.push({
      ...item,
      order,
      blockIndex: Number.isFinite(Number(item.blockIndex)) ? Number(item.blockIndex) : order
    });
  }
}

function sameRawItemAcrossSnapshots(a, b) {
  const typeA = inferCollectedItemType(a);
  const typeB = inferCollectedItemType(b);
  if (sameTitleAndLine(a, b)) {
    return normalizeSearchText(a.text || a.sourceText) === normalizeSearchText(b.text || b.sourceText) && areNearbyCollectedItems(a, b);
  }
  if (typeA !== typeB) return false;
  if (typeA === "video") return sameDuplicateVideoMedia(a, b);
  if (["image", "sticker"].includes(typeA) && sameDuplicateImageLikeMedia(a, b)) return true;
  const mediaA = mediaIdentity(a);
  const mediaB = mediaIdentity(b);
  if (mediaA && mediaB) return mediaA === mediaB && hasDuplicateMediaEvidence(a, b);

  const sourceA = String(a.sourceId || "");
  const sourceB = String(b.sourceId || "");
  if (sourceA && sourceB && sourceA === sourceB && !sourceA.startsWith("dom-block-")) {
    return normalizeSearchText(a.text || a.sourceText) === normalizeSearchText(b.text || b.sourceText);
  }

  const textA = normalizeSearchText(a.text || a.sourceText);
  const textB = normalizeSearchText(b.text || b.sourceText);
  return Boolean(textA && textA === textB && hasDuplicateTextEvidence(a, b));
}

function preferRawSnapshotItem(candidate, current) {
  const candidateType = inferCollectedItemType(candidate);
  const currentType = inferCollectedItemType(current);
  if (candidateType === "title" && currentType === "line") return true;
  if (candidateType !== currentType) {
    if (["image", "sticker", "video"].includes(candidateType) && currentType === "line") return true;
    return false;
  }
  const candidateMedia = String(candidate.mediaPath || candidate.assetUrl || candidate.src || "");
  const currentMedia = String(current.mediaPath || current.assetUrl || current.src || "");
  if (["image", "sticker", "video"].includes(candidateType)) {
    const candidateTemporary = isTemporaryBrowserMediaPath(candidateMedia);
    const currentTemporary = isTemporaryBrowserMediaPath(currentMedia);
    if (!candidateTemporary && currentTemporary) return true;
    if (candidateTemporary && !currentTemporary) return false;
  }
  if (candidateType === "video") return mediaQualityScore(candidateMedia) > mediaQualityScore(currentMedia);
  if (["image", "sticker"].includes(candidateType)) {
    if (candidateType === "sticker") {
      if (isGifMedia(candidateMedia) && !isGifMedia(currentMedia)) return true;
      if (!isGifMedia(candidateMedia) && isGifMedia(currentMedia)) return false;
    }
    const candidateOriginal = mediaOriginalSource(candidate) || candidateMedia;
    const currentOriginal = mediaOriginalSource(current) || currentMedia;
    const candidateScore = mediaQualityScore(candidateOriginal);
    const currentScore = mediaQualityScore(currentOriginal);
    if (candidateScore !== currentScore) return candidateScore > currentScore;
    if (/\/preview\//.test(currentMedia) && !/\/preview\//.test(candidateMedia)) return true;
    if (!currentMedia && candidateMedia) return true;
  }
  if (["line", "title"].includes(candidateType) && sameVisualTextBlockDuplicate(candidate, current)) {
    return textBlockSpecificityScore(candidate) > textBlockSpecificityScore(current);
  }
  return false;
}

function dedupeSnapshotItems(items) {
  const result = [];
  for (const item of items) {
    const duplicateIndex = result.findIndex((existing) => sameRawItemAcrossSnapshots(existing, item));
    if (duplicateIndex >= 0) {
      if (preferRawSnapshotItem(item, result[duplicateIndex])) result[duplicateIndex] = item;
      continue;
    }
    result.push(item);
  }
  return result;
}

function normalizeSnapshotItems(items = []) {
  const rawItems = attachCollectContext(sortCollectedItemsByDocumentPosition(Array.isArray(items) ? items : []));
  const contentItems = rawItems.filter((item) =>
    !isNonContentMediaItem(item) &&
    !isNonSendableDocumentSectionTitleItem(item) &&
    !isNonSendableFeishuUiTextItem(item)
  );
  const normalizedItems = markImagesWithNearbyStickerPlaceholder(dropLeadingDocumentChromeItems(dedupeSnapshotItems(contentItems)));
  return dropMediaPlaceholderSnapshotItems(dropDuplicateContextMessageGroups(normalizedItems));
}

function markImagesWithNearbyStickerPlaceholder(items = []) {
  return items.map((item, index) => {
    if (inferCollectedItemType(item) !== "image") return item;
    const marker = items.find((other, otherIndex) => (
      otherIndex !== index &&
      isStickerPlaceholderLineItem(other) &&
      (sameCollectContext(item, other) || areNearbyCollectedItems(item, other))
    ));
    if (!marker) return item;
    return {
      ...item,
      type: "sticker",
      kind: "sticker",
      sourceText: item.sourceText || marker.text || marker.sourceText || "动态表情"
    };
  });
}

function isNonSendableFeishuUiTextItem(item) {
  const type = inferCollectedItemType(item);
  if (!["line", "title"].includes(type)) return false;
  if (parseCollectHeader(item)) return false;
  const text = normalizeTextForCollect(item.text || item.sourceText || "");
  const compact = normalizeSearchText(text);
  return compact === "添加图标" ||
    compact === "添加封面" ||
    compact === "添加图标添加封面";
}

function isNonContentMediaItem(item) {
  const type = inferCollectedItemType(item);
  if (!MEDIA_EVENT_TYPES.has(type)) return false;
  const text = normalizeSearchText(`${item?.text || ""} ${item?.sourceText || ""} ${item?.raw?.text || ""} ${item?.raw?.sourceText || ""}`);
  if (/本文暂未被其它文档引用|本文暂未被其他文档引用/.test(text)) return true;
  const source = String(
    item?.sourceUrl ||
    item?.originalMediaPath ||
    item?.originalBlobMediaPath ||
    item?.assetUrl ||
    item?.mediaPath ||
    item?.src ||
    item?.raw?.sourceUrl ||
    item?.raw?.assetUrl ||
    item?.raw?.mediaPath ||
    ""
  );
  const box = item?.boundingInfo || {};
  const x = Number(box.x ?? item?.x);
  const width = Number(box.width ?? box.w ?? item?.w ?? 0);
  const farOffscreenLeft = Number.isFinite(x) && x + Math.max(0, Number.isFinite(width) ? width : 0) < -200;
  return farOffscreenLeft && /^data:image\/svg\+xml/i.test(source);
}

function isNonSendableDocumentSectionTitleItem(item) {
  const type = inferCollectedItemType(item);
  if (!["line", "title"].includes(type)) return false;
  if (parseCollectHeader(item)) return false;
  const text = normalizeTextForCollect(item.text || item.sourceText || "");
  if (!text || text.includes("\n")) return false;
  return /^日常合集文案(?:[（(][^）)]{1,12}[）)])?$/.test(text);
}

function dropLeadingDocumentChromeItems(items = []) {
  const firstChatIndex = items.findIndex(isRealCollectedChatStart);
  if (firstChatIndex <= 0) return items;
  const leading = items.slice(0, firstChatIndex);
  const body = items.slice(firstChatIndex);
  const shouldDropLeading = leading.some(isLeadingFeishuDocumentChromeItem) &&
    body.some((item) => Boolean(collectContextKey(item)) || Boolean(parseCollectHeader(item)));
  if (!shouldDropLeading) return items;
  return [
    ...leading.filter((item) => !isLeadingFeishuDocumentChromeItem(item)),
    ...body
  ];
}

function isRealCollectedChatStart(item) {
  if (collectContextKey(item)) return true;
  return Boolean(parseCollectHeader(item));
}

function isLeadingFeishuDocumentChromeItem(item) {
  const type = inferCollectedItemType(item);
  const text = normalizeTextForCollect(item.text || item.sourceText || "");
  const compact = normalizeSearchText(text);
  if (!collectContextKey(item) && ["sticker", "image"].includes(type)) {
    if (!text) return true;
    if (/^[\u4e00-\u9fa5]{2,4}$/.test(text)) return true;
  }
  if (compact === "添加图标" || compact === "添加封面") return true;
  if (/^\d{1,2}月\d{1,2}日修改$/.test(text)) return true;
  return /^(今天修改|昨天修改|前天修改|刚刚修改|最近修改|最后修改|上次修改|\d{1,2}分钟前修改|\d{1,2}小时前修改)$/.test(text);
}

function dropMediaPlaceholderSnapshotItems(items = []) {
  return items.filter((item, index) => {
    if (inferCollectedItemType(item) !== "line") return true;
    const text = normalizeSearchText(item.text || item.sourceText);
    if (!isMediaPlaceholderText(text)) return true;
    return !items.some((other, otherIndex) =>
      otherIndex !== index &&
      ((isStickerMarkerText(text) && inferCollectedItemType(other) === "sticker") || (text === "视频" && inferCollectedItemType(other) === "video")) &&
      (sameCollectContext(item, other) || areNearbyCollectedItems(item, other))
    );
  });
}

function dropDuplicateContextMessageGroups(items = []) {
  const groups = [];
  let current = null;
  for (const item of items) {
    const header = parseCollectHeader(item);
    if (header) {
      current = {
        key: collectContextKey({ collectSpeaker: header.speaker, collectTime: header.time }),
        items: [item]
      };
      groups.push(current);
      continue;
    }
    if (!current) {
      groups.push({ key: "", items: [item] });
      continue;
    }
    current.items.push(item);
  }

  const duplicateContextKeys = new Set();
  const contextCounts = new Map();
  for (const group of groups) {
    if (!group.key) continue;
    const next = (contextCounts.get(group.key) || 0) + 1;
    contextCounts.set(group.key, next);
    if (next > 1) duplicateContextKeys.add(group.key);
  }
  if (!duplicateContextKeys.size) return items;

  const keptSignatures = new Set();
  return groups
    .filter((group, groupIndex) => {
      if (!group.key || !duplicateContextKeys.has(group.key)) return true;
      if (isMediaPlaceholderOnlyGroup(group) && groups.some((other, otherIndex) =>
        otherIndex !== groupIndex &&
        other.key === group.key &&
        hasRealMediaGroupItem(other, groupPlaceholderMediaKinds(group))
      )) {
        return false;
      }
      if (isRescanDuplicateHeaderOnlyGroup(group) && groups.some((other, otherIndex) =>
        otherIndex < groupIndex &&
        other.key === group.key
      )) {
        return false;
      }
      const signature = contextMessageGroupSignature(group);
      if (!signature) return true;
      const duplicateKey = `${group.key}|${signature}`;
      if (keptSignatures.has(duplicateKey)) return false;
      keptSignatures.add(duplicateKey);
      return true;
    })
    .flatMap((group) => group.items);
}

function isRescanDuplicateHeaderOnlyGroup(group) {
  if (!group?.items?.length) return false;
  const headerItems = group.items.filter((item) => Boolean(parseCollectHeader(item)));
  const bodyItems = group.items.filter((item) => !parseCollectHeader(item) && hasMeaningfulCollectedContent(item));
  if (headerItems.length !== group.items.length || bodyItems.length) return false;
  return headerItems.some((item) => isDomBlockSource(item?.sourceId || item?.raw?.sourceId) || /下面还说话/.test(String(item?.text || item?.sourceText || "")));
}

function isMediaPlaceholderOnlyGroup(group) {
  const bodyItems = group.items.filter((item) => !parseCollectHeader(item) && hasMeaningfulCollectedContent(item));
  return Boolean(bodyItems.length && bodyItems.every(isMediaPlaceholderLineItem));
}

function groupPlaceholderMediaKinds(group) {
  return new Set(group.items
    .filter(isMediaPlaceholderLineItem)
    .map((item) => normalizeSearchText(item.text || item.sourceText) === "视频" ? "video" : "sticker"));
}

function hasRealMediaGroupItem(group, placeholderKinds) {
  return group.items.some((item) => {
    const type = inferCollectedItemType(item);
    if (type === "video") return placeholderKinds.has("video");
    if (["image", "sticker"].includes(type)) return placeholderKinds.has("sticker");
    return false;
  });
}

function contextMessageGroupSignature(group) {
  const parts = group.items
    .filter((item) => !parseCollectHeader(item) && hasMeaningfulCollectedContent(item) && !isMediaPlaceholderLineItem(item))
    .map((item) => {
      const type = inferCollectedItemType(item);
      if (["image", "sticker", "video"].includes(type)) return `${type}:${mediaIdentity(item) || mediaSourceIdentity(item) || normalizeSearchText(item.sourceText || "")}`;
      return `text:${normalizeSearchText(item.text || item.sourceText)}`;
    });
  return parts.length ? parts.join("|") : "";
}

function hasMeaningfulCollectedContent(item) {
  if (["image", "sticker", "video"].includes(inferCollectedItemType(item))) return true;
  return Boolean(normalizeSearchText(item.text || item.sourceText));
}

function isMediaPlaceholderLineItem(item) {
  if (inferCollectedItemType(item) !== "line") return false;
  const text = normalizeSearchText(item.text || item.sourceText);
  return isMediaPlaceholderText(text);
}

function isStickerPlaceholderLineItem(item) {
  if (inferCollectedItemType(item) !== "line") return false;
  return isStickerMarkerText(normalizeSearchText(item.text || item.sourceText));
}

function isMediaPlaceholderText(text) {
  return isStickerMarkerText(text) || text === "视频";
}

function hasDuplicateTextEvidence(a, b) {
  if (sameVisualTextBlockDuplicate(a, b)) return true;
  if (sameLooseVisualTextBlockDuplicate(a, b)) return true;
  return sameCollectContext(a, b) && (sameExactVisualPosition(a, b) || sameStableSourceId(a, b));
}

function hasDuplicateMediaEvidence(a, b) {
  if (sameCollectContext(a, b) && areNearbyCollectedItems(a, b)) return true;
  return !collectContextKey(a) && !collectContextKey(b) && areNearbyCollectedItems(a, b);
}

function sameDuplicateVideoMedia(a, b) {
  const hashA = mediaContentHash(a);
  const hashB = mediaContentHash(b);
  if (!hashA || !hashB || hashA !== hashB) return false;
  if (!sameVideoSourceOrBlock(a, b)) return false;
  if (hasIndependentDifferentVideoMessageBinding(a, b)) return false;
  return areNearbyCollectedItems(a, b) || sameCollectContext(a, b) || sameVideoControlArea(a, b);
}

function sameDuplicateImageLikeMedia(a, b) {
  const hashA = mediaContentHash(a);
  const hashB = mediaContentHash(b);
  const sameHash = Boolean(hashA && hashB && hashA === hashB);
  const sameSource = sameMediaSourceOrBlock(a, b);
  if (!sameHash && !sameSource && sameCollectContext(a, b) && sameVisualMediaRender(a, b)) {
    if (hasIndependentDifferentMediaMessageBinding(a, b)) return false;
    return true;
  }
  if (!sameHash && !sameSource) return false;
  if (!sameSource && !sameExactVisualPosition(a, b)) return false;
  if (hasIndependentDifferentMediaMessageBinding(a, b)) return false;
  return sameCollectContext(a, b) || areNearbyCollectedItems(a, b) || sameExactVisualPosition(a, b) || sameStableSourceId(a, b);
}

function sameVideoSourceOrBlock(a, b) {
  const sourceA = videoSourceIdentity(a);
  const sourceB = videoSourceIdentity(b);
  if (sourceA && sourceB && sourceA === sourceB) return true;
  const idA = stableVideoBlockId(a);
  const idB = stableVideoBlockId(b);
  return Boolean(idA && idB && idA === idB);
}

function hasIndependentDifferentVideoMessageBinding(a, b) {
  const contextA = collectContextKey(a);
  const contextB = collectContextKey(b);
  if (!contextA || !contextB || contextA === contextB) return false;
  if (sameExactVisualPosition(a, b) || sameStableSourceId(a, b)) return false;
  if (isVirtualVideoControlItem(a) || isVirtualVideoControlItem(b)) return false;
  return true;
}

function hasIndependentDifferentMediaMessageBinding(a, b) {
  const contextA = collectContextKey(a);
  const contextB = collectContextKey(b);
  if (!contextA || !contextB || contextA === contextB) return false;
  if (sameExactVisualPosition(a, b) || sameStableSourceId(a, b)) return false;
  return true;
}

function sameVideoControlArea(a, b) {
  if (!(isVideoPlayerControlText(a) || isVideoPlayerControlText(b))) return false;
  const idA = String(a.sourceId || "");
  const idB = String(b.sourceId || "");
  if (idA && idB && idA === idB) return true;
  return isVirtualVideoControlItem(a) || isVirtualVideoControlItem(b);
}

function sameMediaSourceOrBlock(a, b) {
  const sourceA = mediaSourceIdentity(a);
  const sourceB = mediaSourceIdentity(b);
  if (sourceA && sourceB && sourceA === sourceB) return true;
  return sameStableSourceId(a, b);
}

function sameStableSourceId(a, b) {
  const idA = String(a?.sourceId || a?.raw?.sourceId || "");
  const idB = String(b?.sourceId || b?.raw?.sourceId || "");
  return Boolean(idA && idB && idA === idB && !idA.startsWith("dom-block-"));
}

function sameVisualMediaRender(a, b) {
  const boxA = mediaBox(a);
  const boxB = mediaBox(b);
  if (!boxA || !boxB) return false;
  const verticalOverlap = overlapLength(boxA.y, boxA.y + boxA.height, boxB.y, boxB.y + boxB.height);
  const minHeight = Math.min(boxA.height, boxB.height);
  if (!minHeight || verticalOverlap / minHeight < 0.9) return false;
  const horizontalOverlap = overlapLength(boxA.x, boxA.x + boxA.width, boxB.x, boxB.x + boxB.width);
  const minWidth = Math.min(boxA.width, boxB.width);
  if (!minWidth || horizontalOverlap / minWidth < 0.85) return false;
  const minArea = Math.min(boxA.width * boxA.height, boxB.width * boxB.height);
  const overlapArea = verticalOverlap * horizontalOverlap;
  return minArea > 0 && overlapArea / minArea >= 0.8;
}

function mediaBox(item) {
  const box = item?.boundingInfo || {};
  const x = Number(box.x);
  const y = Number(item?.y ?? box.y);
  const width = Number(box.width);
  const height = Number(box.height);
  if (![x, y, width, height].every(Number.isFinite)) return null;
  if (width <= 0 || height <= 0) return null;
  return { x, y, width, height };
}

function overlapLength(startA, endA, startB, endB) {
  return Math.max(0, Math.min(endA, endB) - Math.max(startA, startB));
}

function sameVisualTextBlockDuplicate(a, b) {
  if (!sameStrictVisualRow(a, b)) return false;
  const idA = String(a?.sourceId || a?.raw?.sourceId || "");
  const idB = String(b?.sourceId || b?.raw?.sourceId || "");
  if (sameStableSourceId(a, b)) return true;
  if (isDomBlockSource(idA) || isDomBlockSource(idB)) return true;
  return false;
}

function sameLooseVisualTextBlockDuplicate(a, b) {
  if (!sameCollectContext(a, b)) return false;
  if (!hasDuplicateTextSourceEvidence(a, b)) return false;
  const boxA = textBox(a);
  const boxB = textBox(b);
  if (!boxA || !boxB) return false;
  const verticalOverlap = overlapLength(boxA.y, boxA.y + boxA.height, boxB.y, boxB.y + boxB.height);
  const minHeight = Math.min(boxA.height, boxB.height);
  if (minHeight > 0 && verticalOverlap / minHeight >= 0.8) {
    const horizontalOverlap = overlapLength(boxA.x, boxA.x + boxA.width, boxB.x, boxB.x + boxB.width);
    const minWidth = Math.min(boxA.width || 0, boxB.width || 0);
    return minWidth <= 0 || horizontalOverlap / minWidth >= 0.7;
  }
  return Math.abs(boxA.y - boxB.y) <= 6 && Math.abs(boxA.x - boxB.x) <= 12;
}

function hasDuplicateTextSourceEvidence(a, b) {
  return sameStableSourceId(a, b) || isDomBlockSource(a?.sourceId || a?.raw?.sourceId) || isDomBlockSource(b?.sourceId || b?.raw?.sourceId);
}

function textBox(item) {
  const box = item?.boundingInfo || {};
  const x = Number(box.x);
  const y = Number(item?.y ?? box.y);
  const width = Number(box.width);
  const height = Number(box.height);
  if (![x, y].every(Number.isFinite)) return null;
  return {
    x,
    y,
    width: Number.isFinite(width) && width > 0 ? width : 0,
    height: Number.isFinite(height) && height > 0 ? height : 24
  };
}

function sameStrictVisualRow(a, b) {
  const yA = Number(a.y ?? a.boundingInfo?.y);
  const yB = Number(b.y ?? b.boundingInfo?.y);
  if (!Number.isFinite(yA) || !Number.isFinite(yB) || Math.abs(yA - yB) > 1) return false;
  const boxA = a.boundingInfo || {};
  const boxB = b.boundingInfo || {};
  const xA = Number(boxA.x);
  const xB = Number(boxB.x);
  if (Number.isFinite(xA) && Number.isFinite(xB) && Math.abs(xA - xB) > 4) return false;
  return true;
}

function textBlockSpecificityScore(item) {
  const id = String(item?.sourceId || item?.raw?.sourceId || "");
  const box = item?.boundingInfo || {};
  const height = Number(box.height);
  let score = 0;
  if (isDomBlockSource(id)) score += 4;
  if (Number.isFinite(height) && height <= 32) score += 3;
  if (collectContextKey(item)) score += 1;
  return score;
}

function isDomBlockSource(id) {
  return String(id || "").startsWith("dom-block-");
}

function sameExactVisualPosition(a, b) {
  const yA = Number(a.y ?? a.boundingInfo?.y);
  const yB = Number(b.y ?? b.boundingInfo?.y);
  if (Number.isFinite(yA) && Number.isFinite(yB) && Math.abs(yA - yB) <= 1) return true;
  const boxA = a.boundingInfo || {};
  const boxB = b.boundingInfo || {};
  const xA = Number(boxA.x);
  const xB = Number(boxB.x);
  if (!Number.isFinite(xA) || !Number.isFinite(xB) || Math.abs(xA - xB) > 1) return false;
  const hA = Number(boxA.height);
  const hB = Number(boxB.height);
  const wA = Number(boxA.width);
  const wB = Number(boxB.width);
  return Number.isFinite(yA) && Number.isFinite(yB) &&
    Math.abs(yA - yB) <= 1 &&
    (!Number.isFinite(hA) || !Number.isFinite(hB) || Math.abs(hA - hB) <= 1) &&
    (!Number.isFinite(wA) || !Number.isFinite(wB) || Math.abs(wA - wB) <= 1);
}

function isVirtualVideoControlItem(item) {
  return isVideoPlayerControlText(item) && String(item?.sourceId || "").startsWith("dom-block-");
}

function sameCollectContext(a, b) {
  const speakerA = normalizeCollectSpeaker(a.collectSpeaker);
  const speakerB = normalizeCollectSpeaker(b.collectSpeaker);
  const timeA = normalizeCollectTime(a.collectTime);
  const timeB = normalizeCollectTime(b.collectTime);
  return Boolean(speakerA && speakerB && speakerA === speakerB && timeA && timeB && timeA === timeB);
}

function collectContextKey(item) {
  const speaker = normalizeCollectSpeaker(item.collectSpeaker);
  const time = normalizeCollectTime(item.collectTime);
  return speaker && time ? `${speaker}@${time}` : "";
}

function areNearbyCollectedItems(a, b) {
  const yA = Number(a.y ?? a.boundingInfo?.y);
  const yB = Number(b.y ?? b.boundingInfo?.y);
  if (Number.isFinite(yA) && Number.isFinite(yB) && Math.abs(yA - yB) <= 80) return true;
  const orderA = Number(a.order ?? a.blockIndex);
  const orderB = Number(b.order ?? b.blockIndex);
  return Number.isFinite(orderA) && Number.isFinite(orderB) && Math.abs(orderA - orderB) <= 2;
}

function attachCollectContext(items = []) {
  let current = { speaker: "", time: "" };
  return items.map((item) => {
    const header = parseCollectHeader(item);
    if (header) current = header;
    return {
      ...item,
      collectSpeaker: item.collectSpeaker || header?.speaker || current.speaker || "",
      collectTime: item.collectTime || header?.time || current.time || ""
    };
  });
}

function sortCollectedItemsByDocumentPosition(items = []) {
  return [...items].sort((a, b) => {
    const orderA = Number(a.order);
    const orderB = Number(b.order);
    if (Number.isFinite(orderA) && Number.isFinite(orderB) && orderA !== orderB) return orderA - orderB;
    const blockA = Number(a.blockIndex);
    const blockB = Number(b.blockIndex);
    if (Number.isFinite(blockA) && Number.isFinite(blockB) && blockA !== blockB) return blockA - blockB;
    const yA = Number(a.y ?? a.boundingInfo?.y);
    const yB = Number(b.y ?? b.boundingInfo?.y);
    if (Number.isFinite(yA) && Number.isFinite(yB) && Math.abs(yA - yB) > 1) return yA - yB;
    return 0;
  });
}

function sameTitleAndLine(a, b) {
  const pair = new Set([inferCollectedItemType(a), inferCollectedItemType(b)]);
  return pair.has("title") && pair.has("line");
}

function parseCollectHeader(item) {
  if (inferCollectedItemType(item) !== "line") return null;
  const text = normalizeTextForCollect(item.text || item.sourceText || "");
  if (!text || /^https?:\/\//i.test(text)) return null;
  const withoutHint = text
    .replace(/（[^）]*下面还说话[^）]*）/g, "")
    .replace(/\([^)]*下面还说话[^)]*\)/g, "")
    .replace(/【[^】]*下面还说话[^】]*】/g, "")
    .replace(/\[[^\]]*下面还说话[^\]]*\]/g, "")
    .replace(/下面还说话/g, "")
    .trim();
  const match = withoutHint.match(COLLECT_HEADER_TIME_RE);
  if (!match) return null;
  const speaker = cleanCollectSpeakerText(withoutHint.slice(0, match.index));
  if (!speaker) return null;
  return {
    speaker: normalizeCollectSpeaker(speaker),
    time: `${String(match[3]).padStart(2, "0")}:${String(match[4]).padStart(2, "0")}:${String(match[5] || "00").padStart(2, "0")}`
  };
}

function normalizeCollectSpeaker(value) {
  return cleanCollectSpeakerText(value).replace(/\s+/g, "");
}

function cleanCollectSpeakerText(value) {
  return normalizeTextForCollect(value)
    .replace(/(?:[:：]|[!！?？])+\s*[(（]\s*$/, "")
    .replace(/[，,。；;：:]+$/, "")
    .trim();
}

function normalizeCollectTime(value) {
  const match = String(value || "").match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
  if (!match) return "";
  return `${String(match[1]).padStart(2, "0")}:${String(match[2]).padStart(2, "0")}:${String(match[3] || "00").padStart(2, "0")}`;
}

function normalizeTextForCollect(value) {
  return String(value || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .trim();
}

function mediaIdentity(item) {
  const raw = String(
    item?.sourceUrl ||
    item?.originalMediaPath ||
    item?.originalBlobMediaPath ||
    item?.raw?.sourceUrl ||
    item?.raw?.originalMediaPath ||
    item?.raw?.originalBlobMediaPath ||
    item?.mediaPath ||
    item?.assetUrl ||
    item?.src ||
    ""
  );
  if (!raw) return "";
  let decoded = raw;
  try {
    decoded = decodeURIComponent(raw);
  } catch {
    decoded = raw;
  }
  const token = decoded.match(/\/(?:cover|preview|video)\/([^/?#]+)/i)?.[1];
  if (token) return token;
  const mountToken = decoded.match(/[?&]mount_node_token=([^&#]+)/i)?.[1];
  if (mountToken) return mountToken;
  const materializedHash = String(item?.materializedHash || item?.raw?.materializedHash || "").trim();
  if (materializedHash) return `hash:${materializedHash}`;
  const localHash = decoded.match(/[\\/]\d+-(?:image|sticker|video)-([a-z0-9]+)\.[a-z0-9]+$/i)?.[1];
  if (localHash) return `hash:${localHash}`;
  return decoded.replace(/[?&#].*$/, "");
}

function mediaContentHash(item) {
  const materializedHash = String(item?.materializedHash || item?.raw?.materializedHash || "").trim();
  if (materializedHash) return `hash:${materializedHash}`;
  return localMediaHashFromValue(item?.mediaPath) ||
    localMediaHashFromValue(item?.assetUrl) ||
    localMediaHashFromValue(item?.src) ||
    localMediaHashFromValue(item?.raw?.mediaPath) ||
    localMediaHashFromValue(item?.raw?.assetUrl) ||
    localMediaHashFromValue(item?.raw?.src);
}

function mediaSourceIdentity(item) {
  const raw = String(
    item?.sourceUrl ||
    item?.originalMediaPath ||
    item?.originalBlobMediaPath ||
    item?.raw?.sourceUrl ||
    item?.raw?.originalMediaPath ||
    item?.raw?.originalBlobMediaPath ||
    item?.assetUrl ||
    item?.src ||
    item?.raw?.assetUrl ||
    item?.raw?.src ||
    ""
  );
  if (!raw) return "";
  let decoded = raw;
  try {
    decoded = decodeURIComponent(raw);
  } catch {
    decoded = raw;
  }
  const token = decoded.match(/\/(?:cover|preview|video)\/([^/?#]+)/i)?.[1];
  if (token) return `token:${token}`;
  const mountToken = decoded.match(/[?&]mount_node_token=([^&#]+)/i)?.[1];
  if (mountToken) return `mount:${mountToken}`;
  if (/^blob:/i.test(decoded)) return decoded.replace(/[?#].*$/, "");
  return decoded.replace(/[?&#].*$/, "");
}

function mediaOriginalSource(item) {
  return String(
    item?.sourceUrl ||
    item?.originalMediaPath ||
    item?.originalBlobMediaPath ||
    item?.raw?.sourceUrl ||
    item?.raw?.originalMediaPath ||
    item?.raw?.originalBlobMediaPath ||
    item?.assetUrl ||
    item?.src ||
    item?.raw?.assetUrl ||
    item?.raw?.src ||
    ""
  );
}

function localMediaHashFromValue(value) {
  const raw = String(value || "");
  if (!raw) return "";
  let decoded = raw;
  try {
    decoded = decodeURIComponent(raw);
  } catch {
    decoded = raw;
  }
  const match = decoded.match(/[\\/]\d+-(?:image|sticker|video)-([a-z0-9]+)\.[a-z0-9]+$/i);
  return match ? `hash:${match[1]}` : "";
}

function videoSourceIdentity(item) {
  const raw = String(
    item?.sourceUrl ||
    item?.originalMediaPath ||
    item?.originalBlobMediaPath ||
    item?.raw?.sourceUrl ||
    item?.raw?.originalMediaPath ||
    item?.raw?.originalBlobMediaPath ||
    ""
  );
  if (!raw) return "";
  let decoded = raw;
  try {
    decoded = decodeURIComponent(raw);
  } catch {
    decoded = raw;
  }
  const token = decoded.match(/\/video\/([^/?#]+)/i)?.[1];
  if (token) return `video:${token}`;
  const mountToken = decoded.match(/[?&]mount_node_token=([^&#]+)/i)?.[1];
  if (mountToken) return `mount:${mountToken}`;
  if (/^blob:/i.test(decoded)) return decoded.replace(/[?#].*$/, "");
  return decoded.replace(/[?&#].*$/, "");
}

function stableVideoBlockId(item) {
  const id = String(item?.sourceId || item?.raw?.sourceId || "");
  if (!id || id.startsWith("dom-block-")) return "";
  return id;
}

function dedupeMaterializedMediaEvents(events = []) {
  return normalizeSnapshotItems(events)
    .map((event, index) => ({
      ...event,
      order: index,
      blockIndex: Number.isFinite(Number(event.blockIndex)) ? Number(event.blockIndex) : index
    }));
}

function isVideoPlayerControlText(item) {
  const text = normalizeSearchText(item?.text || item?.sourceText || "");
  return /^video\(\d+\)\d{1,2}:\d{2}$/.test(text) ||
    /^\d{1,2}:\d{2}\/\d{1,2}:\d{2}(?:480p|720p|1080p)?(?:1x|1\.0x)?$/.test(text) ||
    /^(?:\d{1,2}:\d{2}){2}(?:480p|720p|1080p)(?:1x|1\.0x)?$/.test(text);
}

function mediaQualityScore(value) {
  const src = String(value || "").toLowerCase();
  if (isTemporaryBrowserMediaPath(src)) return 0;
  if (/\/video\/|\.mp4(?:\?|#|$)|quality=/.test(src)) return 4;
  if (/\/v2\/cover\//.test(src)) return 3;
  if (/\/preview\//.test(src)) return 2;
  if (src) return 1;
  return 0;
}

function isGifMedia(value) {
  return /\.gif(?:[?#].*)?$/i.test(String(value || ""));
}

function formatTemporaryMediaFailure(event) {
  const identity = parseCollectHeader(event) || {
    speaker: event.collectSpeaker || "",
    time: event.collectTime || ""
  };
  return [
    `第 ${Number(event.order ?? event.blockIndex ?? 0) + 1} 条`,
    `说话人=${identity.speaker || "未识别"}`,
    `时间=${identity.time || "未识别"}`,
    `类型=${event.type || event.kind}`,
    `原始地址=${event.mediaPath || event.assetUrl}`
  ].join(" ");
}

function formatRemoteMediaFailure(event) {
  const identity = parseCollectHeader(event) || {
    speaker: event.collectSpeaker || "",
    time: event.collectTime || ""
  };
  return [
    `第 ${Number(event.order ?? event.blockIndex ?? 0) + 1} 条`,
    `说话人=${identity.speaker || "未识别"}`,
    `时间=${identity.time || "未识别"}`,
    `类型=${event.type || event.kind}`,
    `远程地址=${event.mediaPath || event.assetUrl}`
  ].join(" ");
}

function normalizeBoundingInfo(value) {
  const box = Object(value || {});
  return {
    x: numberOrZero(box.x),
    y: numberOrZero(box.y),
    width: numberOrZero(box.width ?? box.w),
    height: numberOrZero(box.height ?? box.h)
  };
}

function keywordSearchVariants(value) {
  const text = String(value || "").trim();
  const variants = [];
  const add = (item) => {
    const normalized = String(item || "").trim();
    if (normalized && !variants.includes(normalized)) variants.push(normalized);
  };
  add(text);

  const dateTime = text.match(/\d{1,2}\s*\/\s*\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?/);
  if (dateTime) add(dateTime[0]);
  const time = text.match(/\d{1,2}:\d{2}(?::\d{2})?/);
  if (time) add(time[0]);

  return variants;
}

function normalizeSearchText(value) {
  return String(value || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/[：]/g, ":")
    .replace(/\s+/g, "")
    .trim();
}

function numberOrZero(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

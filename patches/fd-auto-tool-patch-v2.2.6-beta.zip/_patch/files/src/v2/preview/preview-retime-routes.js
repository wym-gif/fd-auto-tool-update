import { retimePreviewTasks } from "../time/preview-retime.js";

export function buildPreviewRetimeResponse(body = {}) {
  const result = retimePreviewTasks(Array.isArray(body.tasks) ? body.tasks : [], {
    startTime: body.startTime,
    endTime: body.endTime,
    startDate: body.startDate,
    intervals: body.intervals || {}
  });
  return {
    ok: true,
    tasks: result.tasks,
    diagnostics: result.diagnostics || [],
    gaps: result.gaps || []
  };
}

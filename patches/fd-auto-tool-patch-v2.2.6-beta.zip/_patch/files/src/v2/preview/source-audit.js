import { detectRoleHeader, isNonSendableRemark } from "../parser/role-header.js";
import { sourceOccurrenceIdsFrom } from "../feishu-api/source-identity.js";

const EXPLICIT_NON_SEND_DIAGNOSTICS = new Set([
  "change_day_marker",
  "ignored_day_marker",
  "dropped_collected_date_heading_residue",
  "dropped_finder_code_block_chrome"
]);

export function buildPreviewSourceAudit(events = [], tasks = [], diagnostics = []) {
  const sourceEvents = Array.isArray(events) ? events : [];
  const previewTasks = Array.isArray(tasks) ? tasks : [];
  const accounted = new Map();
  for (const [taskIndex, task] of previewTasks.entries()) {
    if (/^restored-/.test(String(task?.sourceId || "")) && !sourceOccurrenceIdsFrom(task).length) continue;
    for (const ref of sourceRefsForTask(task)) {
      if (!accounted.has(ref)) accounted.set(ref, []);
      accounted.get(ref).push({ taskIndex, submitIdentity: String(task?.submitIdentity || "") });
    }
  }

  const diagnosticBySource = new Map();
  for (const diagnostic of Array.isArray(diagnostics) ? diagnostics : []) {
    for (const sourceId of splitSourceIds(diagnostic?.sourceId)) {
      if (!diagnosticBySource.has(sourceId)) diagnosticBySource.set(sourceId, []);
      diagnosticBySource.get(sourceId).push(diagnostic);
    }
  }

  const rawRefCounts = new Map();
  for (const event of sourceEvents) {
    for (const ref of sourceRefsForEvent(event)) rawRefCounts.set(ref, Number(rawRefCounts.get(ref) || 0) + 1);
  }
  const duplicateInputRefs = [...rawRefCounts.entries()].filter(([, count]) => count > 1).map(([sourceOccurrenceId, count]) => ({ sourceOccurrenceId, count }));
  const duplicateInputSet = new Set(duplicateInputRefs.map((item) => item.sourceOccurrenceId));

  const outcomes = sourceEvents.map((event, eventIndex) => {
    const refs = sourceRefsForEvent(event);
    const emittedRefs = refs.filter((ref) => accounted.has(ref));
    const missingRefs = refs.filter((ref) => !accounted.has(ref));
    const duplicateRefs = refs.filter((ref) => duplicateInputSet.has(ref));
    const sourceIntegrityError = String(event?.previewError || "").trim();
    if (sourceIntegrityError) {
      return sourceOutcome(event, eventIndex, refs, "unresolved", sourceIntegrityError, emittedRefs, refs);
    }
    if (!missingRefs.length && !duplicateRefs.length) {
      return sourceOutcome(event, eventIndex, refs, "emitted", "已进入预览", emittedRefs);
    }
    if (duplicateRefs.length) {
      return sourceOutcome(event, eventIndex, refs, "unresolved", "同一原文位置被重复读取，需核对出现次数", emittedRefs, duplicateRefs);
    }
    const excluded = explicitNonSendReason(event, diagnosticBySource.get(String(event?.sourceId || "")) || []);
    if (excluded) return sourceOutcome(event, eventIndex, refs, "excluded", excluded, emittedRefs);
    return sourceOutcome(event, eventIndex, refs, "unresolved", "原文位置未进入预览，也没有明确的不发送依据", emittedRefs, missingRefs);
  });

  const unresolved = outcomes.filter((item) => item.status === "unresolved");
  return {
    schemaVersion: 1,
    complete: unresolved.length === 0,
    sourceEventCount: sourceEvents.length,
    sourceOccurrenceCount: outcomes.reduce((sum, item) => sum + item.sourceOccurrenceIds.length, 0),
    emittedCount: outcomes.filter((item) => item.status === "emitted").length,
    excludedCount: outcomes.filter((item) => item.status === "excluded").length,
    unresolvedCount: unresolved.length,
    duplicateInputRefs,
    unresolved,
    outcomes
  };
}

export function sourceRefsForEvent(event = {}) {
  const refs = sourceOccurrenceIdsFrom(event);
  return refs.length ? refs : legacySourceRefs(event?.sourceId);
}

export function sourceRefsForTask(task = {}) {
  const refs = sourceOccurrenceIdsFrom(task);
  return refs.length ? refs : legacySourceRefs(task?.sourceId);
}

function sourceOutcome(event, eventIndex, refs, status, reason, emittedRefs = [], issueRefs = []) {
  return {
    eventIndex,
    sourceId: String(event?.sourceId || ""),
    sourceOccurrenceIds: refs,
    kind: String(event?.kind || ""),
    blockId: String(event?.blockId || ""),
    blockOrder: Number(event?.feishuBlockOrder || event?.order || 0),
    status,
    reason,
    emittedRefs,
    issueRefs
  };
}

function explicitNonSendReason(event, diagnostics) {
  if (String(event?.previewError || "").trim()) return "";
  if (event?.kind === "divider" || event?.kind === "title") return "结构标题或分隔线不发送";
  if (event?.kind === "line") {
    const text = String(event?.text || event?.sourceText || "");
    if (!text.trim()) return "空段落仅保留结构，不单独发送";
    const header = detectRoleHeader(event, {});
    if (header && !String(header.inlineBodyText || "").trim()) return "角色时间标题仅用于确定内容边界";
    if (isNonSendableRemark(text, { insideRoleSegment: true })) return "依据明确备注规则不发送";
  }
  const diagnostic = diagnostics.find((item) => EXPLICIT_NON_SEND_DIAGNOSTICS.has(String(item?.code || "")));
  return diagnostic ? String(diagnostic.message || diagnostic.code) : "";
}

function legacySourceRefs(value) {
  return splitSourceIds(value).map((sourceId) => `source-id:${sourceId}`);
}

function splitSourceIds(value) {
  return String(value || "").split(",").map((item) => item.trim()).filter(Boolean);
}

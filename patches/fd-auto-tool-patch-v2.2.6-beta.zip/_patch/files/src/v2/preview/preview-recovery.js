import crypto from "node:crypto";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { finalPreviewPath, readPreviewTasks } from "./preview-store.js";

export const PREVIEW_RECOVERY_INDEX_FILE = "preview-recovery-index.json";
export const PREVIEW_RECOVERY_RETENTION_MS = 24 * 60 * 60 * 1000;
export const PREVIEW_MEDIA_CLEANUP_INTERVAL_MS = 60 * 60 * 1000;
const SUPPORTED_RUN_PREFIXES = [
  "v2_real_flow_",
  "v2_feishu_api_",
  "v2_doc_import_",
  "v2_library_work_",
  "v2_flow_"
];

export function previewRecoveryIndexPath(runsRoot) {
  return path.join(runsRoot, PREVIEW_RECOVERY_INDEX_FILE);
}

export function isSupportedPreviewRunId(runId = "") {
  const value = String(runId || "").trim();
  return Boolean(value)
    && !value.includes("/")
    && !value.includes("\\")
    && !value.includes("..")
    && SUPPORTED_RUN_PREFIXES.some((prefix) => value.startsWith(prefix));
}

export async function recordCreatedPreview(runsRoot, runDir, details = {}) {
  return updateRecoveryIndex(runsRoot, runDir, details, { setLatestCreated: true });
}

export async function recordSavedPreview(runsRoot, runDir, details = {}) {
  return updateRecoveryIndex(runsRoot, runDir, details, { setLatestCreated: false });
}

export async function loadPreviewRecoveryState(runsRoot, instance = {}, options = {}) {
  const indexResult = await readRecoveryIndex(runsRoot);
  const history = await scanPreviewHistory(runsRoot, indexResult.index?.records || [], options);
  const latestRunId = String(indexResult.index?.latestCreatedRunId || "");
  const latest = latestRunId ? history.find((item) => item.runId === latestRunId) || null : null;
  let status = "ready";
  let warning = "";
  if (indexResult.status === "missing") {
    status = history.length ? "legacy_selection_required" : "empty";
    warning = history.length ? "尚未建立恢复记录，请选择历史预览。" : "当前实例没有找到已保存的预览。";
  } else if (indexResult.status === "corrupt") {
    status = "index_corrupt";
    warning = "最近预览恢复记录已损坏，请从当前实例的历史预览中选择。";
  } else if (!latestRunId) {
    status = history.length ? "legacy_selection_required" : "empty";
    warning = history.length ? "尚未建立恢复记录，请选择历史预览。" : "当前实例没有找到已保存的预览。";
  } else if (!latest) {
    status = "latest_invalid";
    warning = "最近预览记录指向的文件不存在或已损坏，请从当前实例的历史预览中选择。";
  }
  return {
    available: Boolean(latest),
    status,
    warning,
    instanceId: String(instance.id || ""),
    instanceName: String(instance.label || (instance.id ? `实例${instance.id}` : "默认实例")),
    candidate: latest,
    history
  };
}

export async function resolvePreviewHistoryRun(runsRoot, runId, options = {}) {
  const safeRunId = String(runId || "").trim();
  if (!isSupportedPreviewRunId(safeRunId)) return null;
  const runDir = path.join(runsRoot, safeRunId);
  const resolvedRoot = path.resolve(runsRoot);
  const resolvedRun = path.resolve(runDir);
  if (!resolvedRun.startsWith(`${resolvedRoot}${path.sep}`)) return null;
  return await inspectPreviewRun(runDir, [], { ...options, requireRecoverable: true }) ? runDir : null;
}

export async function cleanupExpiredPreviewMedia(runsRoot, options = {}) {
  const nowMs = timeValue(options.now, Date.now());
  const retentionMs = positiveDuration(options.retentionMs, PREVIEW_RECOVERY_RETENTION_MS);
  const protectedRuns = new Set((options.protectedRunDirs || [])
    .map((item) => String(item || "").trim())
    .filter(Boolean)
    .map((item) => path.resolve(item)));
  const report = { scanned: 0, expired: 0, cleaned: 0, protected: 0, failures: [] };
  const entries = await fs.readdir(runsRoot, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    if (!entry.isDirectory() || !isSupportedPreviewRunId(entry.name)) continue;
    report.scanned += 1;
    const runDir = path.join(runsRoot, entry.name);
    const generatedAtMs = await previewRunGeneratedAtMs(runDir, entry.name);
    if (!isExpired(generatedAtMs, nowMs, retentionMs)) continue;
    report.expired += 1;
    if (protectedRuns.has(path.resolve(runDir)) || await hasUnresolvedCmsActivity(runDir)) {
      report.protected += 1;
      continue;
    }
    let removed = false;
    for (const directoryName of ["media-cache", "manual-media-cache"]) {
      const target = path.join(runDir, directoryName);
      try {
        const stat = await fs.lstat(target).catch(() => null);
        if (!stat?.isDirectory() || stat.isSymbolicLink()) continue;
        await fs.rm(target, { recursive: true, force: true });
        removed = true;
      } catch (error) {
        report.failures.push({ runId: entry.name, directory: directoryName, code: String(error?.code || "CLEANUP_FAILED") });
      }
    }
    if (removed) report.cleaned += 1;
  }
  return report;
}

async function updateRecoveryIndex(runsRoot, runDir, details, options) {
  const runId = path.basename(path.resolve(runDir));
  if (!isSupportedPreviewRunId(runId) || path.dirname(path.resolve(runDir)) !== path.resolve(runsRoot)) {
    throw new Error("预览恢复记录只能登记当前实例 runs 目录中的受支持运行记录。");
  }
  const inspected = await inspectPreviewRun(runDir, []);
  if (!inspected) throw new Error("预览恢复记录更新失败：preview.json 不存在、损坏或内容无效。");
  await fs.mkdir(runsRoot, { recursive: true });
  const filePath = previewRecoveryIndexPath(runsRoot);
  const release = await acquireFileLock(`${filePath}.lock`, Number(details.lockTimeoutMs || 10000));
  try {
    const current = await readRecoveryIndex(runsRoot);
    const index = current.status === "ok" ? current.index : { version: 1, latestCreatedRunId: "", records: [] };
    const previous = Array.isArray(index.records) ? index.records.find((item) => item.runId === runId) : null;
    const now = new Date().toISOString();
    const record = {
      ...inspected,
      ...previous,
      ...normalizeDetails(details),
      runId,
      generatedAt: previous?.generatedAt || details.generatedAt || inspected.generatedAt || now,
      lastSavedAt: details.lastSavedAt || inspected.lastSavedAt || now,
      taskCount: Number(details.taskCount ?? inspected.taskCount ?? previous?.taskCount ?? 0)
    };
    const records = [record, ...(index.records || []).filter((item) => item.runId !== runId)].slice(0, 200);
    const next = {
      version: 1,
      instanceId: String(details.instanceId ?? index.instanceId ?? ""),
      instanceName: String(details.instanceName ?? index.instanceName ?? ""),
      latestCreatedRunId: options.setLatestCreated ? runId : String(index.latestCreatedRunId || ""),
      updatedAt: now,
      records
    };
    await atomicWriteJson(filePath, next);
    return record;
  } finally {
    await release();
  }
}

async function scanPreviewHistory(runsRoot, indexedRecords, options = {}) {
  const entries = await fs.readdir(runsRoot, { withFileTypes: true }).catch(() => []);
  const indexed = new Map((indexedRecords || []).map((item) => [item.runId, item]));
  const history = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || !isSupportedPreviewRunId(entry.name)) continue;
    const inspected = await inspectPreviewRun(path.join(runsRoot, entry.name), indexedRecords, {
      ...options,
      requireRecoverable: true
    });
    if (!inspected) continue;
    history.push({
      ...inspected,
      ...(indexed.get(entry.name) || {}),
      runId: entry.name,
      lastSavedAt: inspected.lastSavedAt,
      taskCount: inspected.taskCount
    });
  }
  return history.sort((left, right) => String(right.generatedAt || "").localeCompare(String(left.generatedAt || "")));
}

async function inspectPreviewRun(runDir, _indexedRecords = [], options = {}) {
  const previewPath = finalPreviewPath(runDir);
  let tasks;
  try {
    tasks = await readPreviewTasks(previewPath);
  } catch {
    return null;
  }
  const stat = await fs.stat(previewPath).catch(() => null);
  if (!stat?.isFile()) return null;
  const runId = path.basename(runDir);
  const report = await readJson(path.join(runDir, "console-generate-report.json"));
  const library = await readJson(path.join(runDir, "library-source.json"));
  const generatedAt = String(library?.openedAt || timestampFromRunId(runId) || stat.birthtime?.toISOString?.() || stat.mtime.toISOString());
  if (options.requireRecoverable === true) {
    const nowMs = timeValue(options.now, Date.now());
    const retentionMs = positiveDuration(options.retentionMs, PREVIEW_RECOVERY_RETENTION_MS);
    if (isExpired(Date.parse(generatedAt), nowMs, retentionMs)) return null;
    if (!await previewMediaIsComplete(runDir, tasks)) return null;
  }
  return {
    runId,
    runDir,
    previewPath,
    source: sourceForRun(runId, report, library),
    documentName: String(report?.documentTitle || library?.name || runId),
    generatedAt,
    lastSavedAt: stat.mtime.toISOString(),
    taskCount: tasks.length
  };
}

async function previewMediaIsComplete(runDir, tasks) {
  for (const task of tasks) {
    if (task?.skip === true) continue;
    if (!["image", "sticker", "video", "unknown-media"].includes(String(task?.type || ""))) continue;
    const mediaPath = String(task?.mediaPath || "").trim();
    if (!mediaPath || /^(?:https?|blob|image-blob|sample):/i.test(mediaPath)) return false;
    if (/^data:/i.test(mediaPath)) continue;
    const resolved = path.isAbsolute(mediaPath) ? mediaPath : path.resolve(runDir, mediaPath);
    const stat = await fs.stat(resolved).catch(() => null);
    if (!stat?.isFile() || stat.size <= 0) return false;
  }
  return true;
}

async function previewRunGeneratedAtMs(runDir, runId) {
  const library = await readJson(path.join(runDir, "library-source.json"));
  const fromMetadata = Date.parse(String(library?.openedAt || timestampFromRunId(runId) || ""));
  if (Number.isFinite(fromMetadata)) return fromMetadata;
  const stat = await fs.stat(runDir).catch(() => null);
  return Number(stat?.birthtimeMs || stat?.mtimeMs || 0);
}

async function hasUnresolvedCmsActivity(runDir) {
  const startPath = path.join(runDir, "cms-start-request.json");
  const startRequest = await readJson(startPath);
  if (!startRequest && await pathExists(startPath)) return true;
  if (["received", "checking", "accepted", "running", "unknown", "recovery_required"].includes(String(startRequest?.status || ""))) return true;
  const submitPath = path.join(runDir, "cms-submit-state.json");
  const submitState = await readJson(submitPath);
  if (!submitState && await pathExists(submitPath)) return true;
  const uncertain = new Set(["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown"]);
  return Object.values(submitState?.tasks && typeof submitState.tasks === "object" ? submitState.tasks : {})
    .some((record) => uncertain.has(String(record?.status || "")));
}

function timeValue(value, fallback) {
  if (value instanceof Date) return value.getTime();
  const parsed = typeof value === "number" ? value : Date.parse(String(value || ""));
  return Number.isFinite(parsed) ? parsed : fallback;
}

function positiveDuration(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function isExpired(generatedAtMs, nowMs, retentionMs) {
  return !Number.isFinite(generatedAtMs) || generatedAtMs > nowMs + 5 * 60 * 1000 || nowMs - generatedAtMs >= retentionMs;
}

function sourceForRun(runId, report, library) {
  if (runId.startsWith("v2_feishu_api_")) return "飞书 API";
  if (runId.startsWith("v2_doc_import_")) return report?.readRange?.sourceMode || "粘贴/文件导入";
  if (runId.startsWith("v2_library_work_") || library?.id) return "文案库";
  if (runId.startsWith("v2_real_flow_")) return "浏览器采集";
  return "旧版预览";
}

function timestampFromRunId(runId) {
  const match = String(runId).match(/_(\d{8})_(\d{6})(?:_|$)/);
  if (!match) return "";
  const date = `${match[1].slice(0, 4)}-${match[1].slice(4, 6)}-${match[1].slice(6, 8)}`;
  const time = `${match[2].slice(0, 2)}:${match[2].slice(2, 4)}:${match[2].slice(4, 6)}`;
  const parsed = new Date(`${date}T${time}`);
  return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString();
}

function normalizeDetails(details) {
  return Object.fromEntries(Object.entries({
    source: details.source,
    documentName: details.documentName,
    instanceId: details.instanceId,
    instanceName: details.instanceName
  }).filter(([, value]) => value !== undefined && value !== null && String(value) !== ""));
}

async function readRecoveryIndex(runsRoot) {
  try {
    const index = JSON.parse(await fs.readFile(previewRecoveryIndexPath(runsRoot), "utf8"));
    if (index?.version !== 1 || !Array.isArray(index.records)) return { status: "corrupt", index: null };
    return { status: "ok", index };
  } catch (error) {
    return error?.code === "ENOENT" ? { status: "missing", index: null } : { status: "corrupt", index: null };
  }
}

async function readJson(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return null;
  }
}

async function atomicWriteJson(filePath, value) {
  const tempPath = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  let handle;
  try {
    handle = await fs.open(tempPath, "wx");
    await handle.writeFile(JSON.stringify(value, null, 2), "utf8");
    await handle.sync();
    await handle.close();
    handle = null;
    await fs.rename(tempPath, filePath);
  } finally {
    await handle?.close().catch(() => {});
    await fs.unlink(tempPath).catch(() => {});
  }
}

async function acquireFileLock(lockPath, timeoutMs = 10000) {
  const started = Date.now();
  const reclaimPath = `${lockPath}.reclaim`;
  const token = crypto.randomUUID();
  while (true) {
    if (await pathExists(reclaimPath)) {
      await removeAbandonedOwnerFile(reclaimPath);
      if (Date.now() - started >= timeoutMs) throw new Error("等待预览恢复记录锁超时，请稍后重试。");
      await new Promise((resolve) => setTimeout(resolve, 30));
      continue;
    }
    try {
      const handle = await fs.open(lockPath, "wx");
      const owner = { pid: process.pid, hostname: os.hostname(), token, createdAt: new Date().toISOString() };
      await handle.writeFile(JSON.stringify(owner), "utf8");
      await handle.sync();
      return async () => {
        await handle.close().catch(() => {});
        const current = await readLockOwner(lockPath);
        if (current?.token === token) await fs.unlink(lockPath).catch(() => {});
      };
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      await reclaimAbandonedLock(lockPath, reclaimPath);
      if (Date.now() - started >= timeoutMs) throw new Error("等待预览恢复记录锁超时，请稍后重试。");
      await new Promise((resolve) => setTimeout(resolve, 30));
    }
  }
}

async function reclaimAbandonedLock(lockPath, reclaimPath) {
  let reclaimHandle;
  try {
    reclaimHandle = await fs.open(reclaimPath, "wx");
    await reclaimHandle.writeFile(JSON.stringify({
      pid: process.pid,
      hostname: os.hostname(),
      token: crypto.randomUUID(),
      createdAt: new Date().toISOString()
    }), "utf8");
    await reclaimHandle.sync();
  } catch (error) {
    if (error?.code === "EEXIST") return false;
    throw error;
  }
  try {
    const beforeText = await fs.readFile(lockPath, "utf8").catch(() => "");
    const before = parseLockOwner(beforeText);
    const stat = await fs.stat(lockPath).catch(() => null);
    if (!await lockOwnerIsAbandoned(before, stat)) return false;
    const currentText = await fs.readFile(lockPath, "utf8").catch(() => "");
    if (currentText !== beforeText) return false;
    await fs.unlink(lockPath).catch((error) => {
      if (error?.code !== "ENOENT") throw error;
    });
    return true;
  } finally {
    await reclaimHandle.close().catch(() => {});
    await fs.unlink(reclaimPath).catch(() => {});
  }
}

async function removeAbandonedOwnerFile(filePath) {
  const beforeText = await fs.readFile(filePath, "utf8").catch(() => "");
  const owner = parseLockOwner(beforeText);
  const stat = await fs.stat(filePath).catch(() => null);
  if (!await lockOwnerIsAbandoned(owner, stat)) return false;
  const currentText = await fs.readFile(filePath, "utf8").catch(() => "");
  if (currentText !== beforeText) return false;
  await fs.unlink(filePath).catch(() => {});
  return true;
}

async function lockOwnerIsAbandoned(owner, stat) {
  if (owner?.hostname === os.hostname() && Number.isInteger(Number(owner.pid)) && Number(owner.pid) > 0) {
    return !processIsAlive(Number(owner.pid));
  }
  if (owner?.hostname && owner.hostname !== os.hostname()) return false;
  return Boolean(stat && Date.now() - stat.mtimeMs > 30000);
}

function processIsAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

async function readLockOwner(lockPath) {
  return parseLockOwner(await fs.readFile(lockPath, "utf8").catch(() => ""));
}

function parseLockOwner(text) {
  try {
    const parsed = JSON.parse(text);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

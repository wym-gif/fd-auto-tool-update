import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";

const UNCERTAIN = new Set(["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown"]);

export async function buildCmsRecoverySummary(runDir, request = {}) {
  const previewPath = path.join(runDir, "preview.json");
  const submitPath = path.join(runDir, "cms-submit-state.json");
  const preview = JSON.parse(await fs.readFile(previewPath, "utf8"));
  if (!Array.isArray(preview)) throw recoveryError("CMS_RECOVERY_PREVIEW_INVALID", "当前预览内容无法读取，不能确定续发位置。");

  let submitState = null;
  let hasSubmitState = true;
  try {
    submitState = JSON.parse(await fs.readFile(submitPath, "utf8"));
  } catch (error) {
    if (error?.code !== "ENOENT") throw recoveryError("CMS_RECOVERY_SUBMIT_STATE_INVALID", "逐条创建记录损坏，不能自动判断续发位置。");
    hasSubmitState = false;
  }
  if (hasSubmitState && (!submitState || submitState.version !== 1 || !submitState.tasks || typeof submitState.tasks !== "object")) {
    throw recoveryError("CMS_RECOVERY_SUBMIT_STATE_INVALID", "逐条创建记录格式异常，不能自动判断续发位置。");
  }

  const records = submitState?.tasks || {};
  const recordList = Object.values(records);
  const tasks = preview.filter((task) => !task?.skip).map((task, offset) => {
    const index = offset + 1;
    const expectedTaskKey = String(task?.submitIdentity || (String(index) + ":" + String(task?.sourceId || "")));
    const record = records[expectedTaskKey]
      || recordList.find((item) => Number(item?.index) === index && String(item?.sourceId || "") === String(task?.sourceId || ""))
      || null;
    const taskKey = String(record?.taskKey || expectedTaskKey);
    return {
      index,
      taskKey,
      sourceId: String(task?.sourceId || ""),
      role: String(task?.role || ""),
      speaker: String(task?.speaker || ""),
      date: String(task?.date || ""),
      time: String(task?.time || ""),
      type: String(task?.type || ""),
      content: taskContent(task),
      mediaName: task?.mediaPath ? path.basename(String(task.mediaPath)) : "",
      status: String(record?.status || (hasSubmitState ? "not_started" : "not_collected")),
      statusLabel: recoveryStatusLabel(record?.status, hasSubmitState),
      attempt: Number(record?.attempt || 0),
      reason: String(record?.reason || record?.action || "")
    };
  });
  if (!tasks.length) throw recoveryError("CMS_RECOVERY_NO_TASKS", "当前预览没有可创建任务。");

  const confirmed = tasks.filter((task) => task.status === "succeeded");
  const boundary = hasSubmitState
    ? tasks.find((task) => UNCERTAIN.has(task.status))
      || tasks.find((task) => !["succeeded", "skipped"].includes(task.status))
      || null
    : null;
  return {
    version: 1,
    runId: path.basename(path.resolve(runDir)),
    requestId: String(request?.requestId || ""),
    requestStatus: String(request?.status || ""),
    hasSubmitState,
    hasHistory: recordList.length > 0,
    requiresBoundarySelection: !hasSubmitState,
    warning: hasSubmitState
      ? (boundary && UNCERTAIN.has(boundary.status) ? "当前边界任务的 CMS 创建结果未知；重新处理可能重复，跳过可能漏发。" : "")
      : "旧请求没有逐条创建记录，系统无法自动判断上次处理到哪一条。请先选择最后一条已确认创建的内容。",
    previewSignature: recoveryPreviewSignature(tasks),
    total: tasks.length,
    confirmedCount: confirmed.length,
    confirmedTasks: confirmed,
    boundary,
    tasks
  };
}

export function resolveCmsRecoveryDecision(summary, input = {}) {
  const mode = String(input.mode || "");
  if (!["retry_current", "start_next", "restart"].includes(mode)) {
    throw recoveryError("CMS_RECOVERY_DECISION_INVALID", "请选择从当前条、下一条或第1条开始。");
  }
  if (String(input.previewSignature || "") !== summary.previewSignature) {
    throw recoveryError("CMS_RECOVERY_PREVIEW_CHANGED", "预览内容已经变化，请刷新后重新选择续发位置。");
  }
  const total = Number(summary.total || 0);
  let boundaryIndex = Number(summary.boundary?.index || 0);
  let lastConfirmedIndex = 0;
  if (summary.requiresBoundarySelection) {
    lastConfirmedIndex = Number(input.lastConfirmedIndex);
    if (!Number.isInteger(lastConfirmedIndex) || lastConfirmedIndex < 0 || lastConfirmedIndex > total) {
      throw recoveryError("CMS_RECOVERY_BOUNDARY_REQUIRED", "请选择上次最后一条已确认创建的内容。");
    }
    boundaryIndex = lastConfirmedIndex + 1;
  }
  const startTaskIndex = mode === "restart" ? 1 : mode === "start_next" ? boundaryIndex + 1 : boundaryIndex;
  if (!Number.isInteger(startTaskIndex) || startTaskIndex < 1 || startTaskIndex > total) {
    throw recoveryError("CMS_RECOVERY_START_OUT_OF_RANGE", "所选位置之后没有可创建任务，请重新选择。");
  }
  return {
    version: 1,
    decisionId: String(input.decisionId || ""),
    oldRequestId: String(input.oldRequestId || summary.requestId || ""),
    mode,
    previewSignature: summary.previewSignature,
    boundaryTaskIndex: boundaryIndex,
    lastConfirmedIndex,
    startTaskIndex,
    forceRestart: mode === "restart",
    retriesUnknownBoundary: mode === "retry_current" && UNCERTAIN.has(String(summary.boundary?.status || "")),
    resubmitsConfirmedSuccess: mode === "restart",
    duplicateRiskAcknowledgement: mode === "restart"
      ? "重新开始会重新提交已确认成功、已跳过及结果未知的条目，可能产生重复任务。"
      : mode === "retry_current" && UNCERTAIN.has(String(summary.boundary?.status || ""))
        ? "从这条开始会重新提交结果未知的当前条，可能产生重复任务。"
        : "",
    selectedAt: new Date().toISOString()
  };
}

export function recoveryTaskForStart(summary, decision) {
  return summary.tasks.find((task) => task.index === decision.startTaskIndex) || null;
}

function recoveryPreviewSignature(tasks) {
  return createHash("sha256").update(JSON.stringify(tasks.map((task) => [
    task.taskKey, task.index, task.role, task.speaker, task.date, task.time, task.type, task.content, task.mediaName
  ]))).digest("hex");
}

function taskContent(task) {
  if (task?.type === "text" || task?.type === "finder") return String(task?.text || "");
  return String(task?.sourceText || task?.mediaPath || "");
}

function recoveryStatusLabel(status, hasSubmitState) {
  if (!hasSubmitState) return "未采集逐条状态";
  if (status === "succeeded") return "已确认 CMS 创建";
  if (UNCERTAIN.has(status)) return "CMS 创建结果未知";
  if (status === "failed") return "创建失败";
  if (status === "skipped") return "已跳过";
  if (status === "cancelled_before_submit") return "提交前已取消";
  if (status === "ready") return "准备提交时中断";
  return "尚未提交";
}

function recoveryError(code, message) {
  const error = new Error(message);
  error.code = code;
  error.statusCode = 409;
  return error;
}

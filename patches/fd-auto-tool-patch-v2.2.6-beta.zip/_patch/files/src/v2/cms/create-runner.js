import fs from "node:fs/promises";
import path from "node:path";
import { assertCmsAdapterShape, createFakeCmsAdapter } from "./cms-adapter.js";
import { findLatestV2DryRunSource, runCreateDryRun } from "./create-plan.js";
import {
  applyPersistedRuntimePlan,
  assertRuntimeScheduleCompatible,
  createRuntimeScheduleBaseline,
  shiftRemainingScheduleByPreviewOffset
} from "./runtime-preview-gap.js";
import { createCmsActionLifecycle, createCmsSubmitStateStore, createUnknownSubmitError } from "./submit-state.js";
import { recordTuoUsageEvent, usageEventFromSubmitRecord } from "../tuo/tuo-usage-history.js";

export async function runCreateRunner(runDir, options = {}) {
  const projectRoot = options.projectRoot || await findProjectRoot(runDir);
  const dryRun = options.dryRunResult || await runCreateDryRun(runDir, options);
  const defaultAdapter = options.adapter || createFakeCmsAdapter();
  const adapterForTask = typeof options.adapterForTask === "function"
    ? options.adapterForTask
    : () => defaultAdapter;
  const actionCursors = new Map();
  const adapterActions = [];
  const allowRealSubmit = options.allowRealSubmit === true;
  const plan = (dryRun.plan || []).map((item) => ({ ...item }));
  const submitState = await createCmsSubmitStateStore(runDir);
  const recoveryDecision = normalizeRecoveryDecision(options.recoveryDecision, plan);
  if (allowRealSubmit) {
    submitState.assertPlanCompatible(plan, { allowUncertain: Boolean(recoveryDecision) });
    if (recoveryDecision) await submitState.recordRecoveryDecision(recoveryDecision);
  }

  let persistedRuntimeSchedule = allowRealSubmit ? await loadRuntimeScheduleState(runDir) : null;
  let runtimeScheduleRebased = false;
  let runtimeScheduleRebaseReason = "";
  if (persistedRuntimeSchedule) {
    try {
      assertRuntimeScheduleCompatible(plan, persistedRuntimeSchedule);
    } catch (error) {
      if (error?.code !== "CMS_RUNTIME_SCHEDULE_BASELINE_MISMATCH") throw error;
      runtimeScheduleRebased = true;
      runtimeScheduleRebaseReason = error.message;
      persistedRuntimeSchedule = null;
    }
  }
  const runtimeScheduleBaseline = persistedRuntimeSchedule?.version === 2 && Array.isArray(persistedRuntimeSchedule.baseline)
    ? persistedRuntimeSchedule.baseline.map((item) => ({ ...item }))
    : createRuntimeScheduleBaseline(plan);
  if (persistedRuntimeSchedule?.version === 2) {
    applyPersistedRuntimePlan(plan, persistedRuntimeSchedule.plan);
  }
  const runtimeScheduleEvents = persistedRuntimeSchedule?.version === 2 && Array.isArray(persistedRuntimeSchedule.events)
    ? persistedRuntimeSchedule.events.map((event) => ({ ...event }))
    : [];
  let runtimeScheduleOffsetSeconds = Number.isFinite(Number(persistedRuntimeSchedule?.offsetSeconds))
    ? Number(persistedRuntimeSchedule.offsetSeconds)
    : null;
  let expiredScheduleCount = 0;
  const logs = [
    "2.0 CMS 创建执行骨架",
    "",
    "创建执行骨架来源：已保存的预览内容 -> 创建前校对 -> 创建计划",
    `预览总数：${dryRun.total}`,
    `跳过不发：${dryRun.skipped}`,
    `待创建：${dryRun.createCount}`,
    `真实提交：${allowRealSubmit ? "允许" : "关闭"}`,
    ""
  ];
  const completed = [];
  const outcomes = [];
  if (allowRealSubmit && persistedRuntimeSchedule?.blockedReason) {
    const error = new Error(String(persistedRuntimeSchedule.blockedReason));
    error.code = "CMS_RUNTIME_SCHEDULE_CONFLICT";
    throw error;
  }
  if (allowRealSubmit && runtimeScheduleRebased) {
    const rebasedAt = resolveRuntimeNow(options).toISOString();
    runtimeScheduleEvents.push({
      event: "final_preview_rebased",
      rebasedAt,
      reason: runtimeScheduleRebaseReason
    });
    await saveRuntimeScheduleOutputs(runDir, {
      version: 2,
      runDir,
      previewPath: dryRun.previewPath,
      adjustedAt: rebasedAt,
      baseline: runtimeScheduleBaseline,
      offsetSeconds: null,
      events: runtimeScheduleEvents,
      plan
    });
    logs.push("检测到最终预览已由用户重新保存：旧运行时排程已作废，剩余任务按当前最终预览重新排程；已成功任务仍按逐条记录跳过。");
  }

  const pendingExpiredDecision = allowRealSubmit && !runtimeScheduleRebased
    ? persistedRuntimeSchedule?.pendingDecision
    : null;
  if (pendingExpiredDecision?.nextIndex) {
    const completedPlanIndex = plan.findIndex((item) => (
      String(item?.submitIdentity || "") === String(pendingExpiredDecision.completedSubmitIdentity || "")
      || Number(item?.index || 0) === Number(pendingExpiredDecision.completedIndex || 0)
    ));
    if (completedPlanIndex < 0 || completedPlanIndex >= plan.length - 1) {
      const error = new Error("上次暂停的过期排程选择无法对应当前最终预览，已停止，避免从错误位置继续。");
      error.code = "CMS_EXPIRED_SCHEDULE_RESUME_MISMATCH";
      throw error;
    }
    logs.push(`恢复上次未完成的过期排程选择：第 ${pendingExpiredDecision.completedIndex} 条已成功，尚未对第 ${pendingExpiredDecision.nextIndex} 条执行任何 CMS 页面动作。`);
    const decision = await handleExpiredScheduleDecision(options.control, {
      ...pendingExpiredDecision,
      runDir
    });
    if (decision.action === "stop") throw new Error("用户在过期排程选择处停止了本轮。");
    if (decision.action === "edited") {
      await applyEditedRemainingSchedule(dryRun.previewPath, plan, runtimeScheduleBaseline, completedPlanIndex);
      runtimeScheduleOffsetSeconds = null;
      runtimeScheduleEvents.push({
        event: "expired_schedule_intervals_edited_after_restart",
        taskIndex: Number(pendingExpiredDecision.completedIndex || 0),
        resumedAt: resolveRuntimeNow(options).toISOString(),
        adjustedRange: { first: plan[completedPlanIndex + 1]?.index || null, last: plan.at(-1)?.index || null }
      });
      logs.push(`程序重开后已按用户修改的剩余间隔继续；下一条为第 ${plan[completedPlanIndex + 1]?.index || "?"} 条。`);
    } else {
      const resumedAt = resolveRuntimeNow(options);
      const resumed = adjustRemainingScheduleAfterExpired(plan, runtimeScheduleBaseline, completedPlanIndex, resumedAt, options);
      runtimeScheduleOffsetSeconds = resumed.offsetSeconds;
      runtimeScheduleEvents.push({
        event: "expired_schedule_direct_resume_after_restart",
        taskIndex: Number(pendingExpiredDecision.completedIndex || 0),
        resumedAt: resumedAt.toISOString(),
        offsetSeconds: resumed.offsetSeconds,
        adjustedRange: resumed.range,
        adjustedTasks: resumed.adjustedTasks
      });
      logs.push(`程序重开后用户选择直接顺延；剩余任务已从 ${dateTimeForLog(resumedAt)} 重新锚定并继续。`);
    }
    await saveRuntimeScheduleOutputs(runDir, {
      version: 2,
      runDir,
      previewPath: dryRun.previewPath,
      adjustedAt: resolveRuntimeNow(options).toISOString(),
      baseline: runtimeScheduleBaseline,
      offsetSeconds: runtimeScheduleOffsetSeconds,
      events: runtimeScheduleEvents,
      plan,
      pendingDecision: null
    });
  }

  for (let planIndex = 0; planIndex < plan.length; planIndex += 1) {
    const item = plan[planIndex];
    const beforeRecoveryStart = recoveryDecision && Number(item.index) < recoveryDecision.startTaskIndex;
    const previousSubmit = allowRealSubmit
      ? submitState.assertRetryAllowed(item, { allowUncertain: Boolean(recoveryDecision) })
      : null;
    if (beforeRecoveryStart) {
      const recoveredSuccess = previousSubmit?.status === "succeeded";
      if (allowRealSubmit && !recoveredSuccess) {
        await submitState.update(item, "skipped", {
          attempt: Number(previousSubmit?.attempt || 1),
          action: "续发选择持久跳过",
          reason: "按续发选择从第 " + recoveryDecision.startTaskIndex + " 条开始",
          recoveryDecisionId: recoveryDecision.decisionId,
          recoveryMode: recoveryDecision.mode,
          skipPersisted: true
        });
      }
      logs.push("第 " + item.index + " 条：按续发选择从第 " + recoveryDecision.startTaskIndex + " 条开始，本条" + (recoveredSuccess ? "保留原成功记录" : "不再创建") + "。");
      completed.push({ ...item, submitted: recoveredSuccess, recoveredSuccess, skippedByRecovery: !recoveredSuccess });
      outcomes.push(createTaskOutcome(item, recoveredSuccess ? "succeeded" : "skipped", "按续发选择从第 " + recoveryDecision.startTaskIndex + " 条开始"));
      continue;
    }
    if (allowRealSubmit && previousSubmit?.status === "succeeded" && !recoveryDecision?.forceRestart) {
      await recordSuccessfulTuoUsage(submitState, item, projectRoot);
      logs.push(`第 ${item.index} 条：状态记录显示此前已确认创建成功，本次恢复不重复提交。`);
      completed.push({ ...item, submitted: true, recoveredSuccess: true });
      outcomes.push(createTaskOutcome(item, "succeeded", "从提交状态记录恢复，未重复提交"));
      continue;
    }
    if (allowRealSubmit && previousSubmit?.status === "skipped" && !recoveryDecision?.forceRestart) {
      logs.push(`第 ${item.index} 条：状态记录显示此前已确认跳过，本次恢复不提交；只有“重新开始”会重发。`);
      completed.push({ ...item, submitted: false, recoveredSkip: true });
      outcomes.push(createTaskOutcome(item, "skipped", previousSubmit.reason || "从提交状态记录恢复跳过"));
      continue;
    }
    let itemDone = false;
    while (!itemDone) {
      try {
        await checkpoint(options.control, `准备创建：${planIndex + 1}/${plan.length} / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.time || ""} / ${item.type || ""}`);
        const adapter = adapterForTask(item);
        assertCmsAdapterShape(adapter);
        if (typeof adapter.locateTaskPageForBackground === "function") {
          const located = await adapter.locateTaskPageForBackground(item);
          logs.push(`第 ${item.index} 条：已${located?.visible ? "切换" : "后台定位"}到${roleLabel(item.role)}云中客页面。`);
        }
        collectNewAdapterActions(adapter, actionCursors, adapterActions);
        if (typeof options.validateTaskBinding === "function") {
          const binding = await options.validateTaskBinding(item, adapter, { phase: "before-task" });
          if (binding) {
            logs.push(`第 ${item.index} 条：${roleLabel(item.role)} 使用第 ${binding.pageIndex || "?"} 个云中客创建页；runId=${binding.runId || ""}`);
            await checkpoint(options.control, `第 ${item.index} 条页面校验通过：${roleLabel(item.role)} -> ${binding.roleLabel || roleLabel(item.role)}页面（第 ${binding.pageIndex || "?"} 页）`);
          }
        }
        await checkpoint(options.control, `第 ${item.index} 条开始前`);
        if (typeof adapter.beforeTask === "function") {
          logs.push(`第 ${item.index} 条：清理上一条残留`);
          await runTimedTaskStep(item, options, {
            checkBeforeAction: false,
            waiting: "正在等待 CMS 页面可编辑",
            logLabel: "等待 CMS 页面可编辑",
            suggestion: "请确认云中客创建页没有弹窗遮挡，页面仍停留在创建任务页，并且网络正常。",
            action: () => adapter.beforeTask(item, { completedCount: completed.length })
          });
        }
        logs.push(`第 ${item.index} 条：选择角色/机器人`);
        await runTimedTaskStep(item, options, {
          checkBeforeAction: false,
          waiting: "正在选择角色/机器人",
          logLabel: "选择角色/机器人",
          suggestion: "请确认托/豆妈页面绑定正确，当前页面已选好分组和机器人。",
          action: () => adapter.selectRole(item)
        });
        if (typeof options.validateTaskBinding === "function") {
          await options.validateTaskBinding(item, adapter, { phase: "before-fill" });
          logs.push(`第 ${item.index} 条：填入前页面身份、配置和最终账号校验通过`);
        }
        if (typeof adapter.setScheduleTime === "function") {
          logs.push(`第 ${item.index} 条：设置发送时间 ${item.date || "空"} ${item.time || "空"}`);
          const scheduleResult = await runTimedTaskStep(item, options, {
            checkBeforeAction: false,
            waiting: "正在设置时间",
            logLabel: "设置发送时间",
            suggestion: "请确认云中客创建页的定时发送控件可见、未被弹窗遮挡，并检查任务时间是否有效。",
            action: () => adapter.setScheduleTime(item)
          });
          if (scheduleResult) {
            logs.push(formatCmsScheduleSetLog(item, scheduleResult));
          }
        }

        if (item.type === "text") {
          logs.push(`第 ${item.index} 条：文本校验`);
          await checkpoint(options.control, `第 ${item.index} 条文本填入前`);
          await runTimedTaskStep(item, options, {
            waiting: "正在填写内容",
            logLabel: "填写正文",
            suggestion: "请确认云中客文本编辑框可见且没有弹窗遮挡。",
            action: () => adapter.fillText(item)
          });
        } else if (item.type === "finder") {
          logs.push(`第 ${item.index} 条：视频号参数校验`);
          await checkpoint(options.control, `第 ${item.index} 条视频号参数填入前`);
          await runTimedTaskStep(item, options, {
            waiting: "正在填写视频号参数",
            logLabel: "填写视频号参数",
            suggestion: "请确认云中客视频号编辑框可见且没有弹窗遮挡。",
            action: () => {
              if (typeof adapter.fillFinderFeed !== "function") {
                throw new Error(`第 ${item.index} 条需要填写视频号参数，但当前 CMS adapter 不支持“视频号”。`);
              }
              return adapter.fillFinderFeed(item);
            }
          });
        } else {
          logs.push(`第 ${item.index} 条：媒体上传`);
          await checkpoint(options.control, `第 ${item.index} 条上传前`);
          await runTimedTaskStep(item, options, {
            waiting: "正在上传/填写内容",
            logLabel: "上传素材",
            suggestion: "请确认素材文件存在、云中客上传控件可见，且页面没有弹窗遮挡。",
            action: () => adapter.uploadMedia(item)
          });
          logs.push(`第 ${item.index} 条：等待极速就绪`);
          await runTimedTaskStep(item, options, {
            waiting: "正在等待素材极速就绪",
            logLabel: "等待素材极速就绪",
            timeoutMs: options.mediaReadyTimeoutMs || options.taskStepTimeoutMs || 90000,
            suggestion: "请确认素材上传成功，云中客页面出现预览且极速状态变绿；如果素材过大或网络慢，请重新上传或稍后再试。",
            action: () => adapter.waitMediaReady(item)
          });
        }

        if (allowRealSubmit) {
          logs.push(`第 ${item.index} 条：提交`);
          await checkpoint(options.control, `第 ${item.index} 条点击提交前`);
          if (typeof options.assertAuthorization === "function") {
            await options.assertAuthorization({ item, phase: "before-submit" });
            logs.push(`第 ${item.index} 条：本机共享授权仍有效`);
          }
          if (typeof options.validateTaskBinding === "function") {
            await options.validateTaskBinding(item, adapter, { phase: "before-submit" });
            logs.push(`第 ${item.index} 条：提交前页面身份、配置和最终账号校验通过`);
          }
          if (typeof adapter.verifyScheduleTime === "function") {
            const finalSchedule = await runTimedTaskStep(item, options, {
              checkBeforeAction: false,
              waiting: "正在提交前复核日期时间",
              logLabel: "提交前复核日期时间",
              suggestion: "请检查本条最终预览日期时间与云中客定时发送控件；日期过期或控件被修改时不会自动提交。",
              action: () => adapter.verifyScheduleTime(item)
            });
            logs.push(formatCmsScheduleVerifyLog(item, finalSchedule));
          }
          await checkpoint(options.control, `第 ${item.index} 条点击执行发送`);
          const attempt = Number(submitState.get(item)?.attempt || 0) + 1;
          const resetSuccessAt = Boolean(recoveryDecision && ["succeeded", ...UNCERTAIN_RECOVERY_STATUSES].includes(previousSubmit?.status));
          await submitState.update(item, "ready", { attempt, action: "准备提交", resetSuccessAt });
          const actionLifecycle = createCmsActionLifecycle({ task: item, submitState, attempt });
          const submitResult = await runTimedTaskStep(item, options, {
            waiting: "正在等待确认弹窗/确认创建",
            logLabel: "确认创建",
            timeoutMs: options.submitStepTimeoutMs || options.submitSuccessTimeoutMs || options.taskStepTimeoutMs || 60000,
            suggestion: "请查看云中客是否弹出确认框、过期定时提示或机器人不在群提示；如果页面卡住，请手动关闭异常弹窗后重试。",
            actionLifecycle,
            action: (lifecycle) => adapter.submit(item, { actionContext: lifecycle })
          });
          if (actionLifecycle.submitStatus !== "succeeded") {
            await actionLifecycle.markSucceeded("检测到创建成功", preciseSubmitIdentity(item, submitResult));
          }
          syncRemainingPreciseGroupPlan(plan, planIndex, item, submitResult?.actualCandidate || item?.tuoAssignment?.runtimeSelected);
          await recordSuccessfulTuoUsage(submitState, item, projectRoot);
          completed.push({ ...item, submitted: true });
          outcomes.push(createTaskOutcome(item, "succeeded"));
          let successCheckpointed = false;
          if (submitResult?.expiredScheduleConfirmed) {
            expiredScheduleCount += 1;
            const limit = Math.max(1, Number(options.maxExpiredScheduleAdjustments || 4));
            const anchor = resolveExpiredScheduleAnchor(submitResult, options);
            let adjusted;
            try {
              adjusted = adjustRemainingScheduleAfterExpired(plan, runtimeScheduleBaseline, planIndex, anchor.date, options);
            } catch (error) {
              if (error?.code === "CMS_RUNTIME_SCHEDULE_CONFLICT") {
                runtimeScheduleEvents.push({
                  event: "runtime_schedule_conflict",
                  taskIndex: item.index,
                  anchorAt: anchor.date.toISOString(),
                  anchorEvidence: anchor.evidence,
                  message: error.message
                });
                await saveRuntimeScheduleOutputs(runDir, {
                  version: 2,
                  runDir,
                  previewPath: dryRun.previewPath,
                  adjustedAt: anchor.date.toISOString(),
                  baseline: runtimeScheduleBaseline,
                  offsetSeconds: runtimeScheduleOffsetSeconds,
                  events: runtimeScheduleEvents,
                  plan,
                  blockedReason: error.message
                });
              }
              throw error;
            }
            runtimeScheduleOffsetSeconds = adjusted.offsetSeconds;
            const original = baselineForTask(runtimeScheduleBaseline, item) || item;
            runtimeScheduleEvents.push({
              event: "expired_schedule_confirmed",
              taskIndex: item.index,
              role: item.role,
              speaker: item.speaker,
              originalDate: original.date || "",
              originalTime: submitResult.originalTime || submitResult.expiredSchedule?.originalTime || original.time || "",
              immediateAt: dateTimeForLog(anchor.date),
              anchorAt: anchor.date.toISOString(),
              anchorEvidence: anchor.evidence,
              adjustedRange: adjusted.range,
              startTime: adjusted.startTime,
              intervalRules: adjusted.intervalRules,
              offsetSeconds: adjusted.offsetSeconds,
              adjustedTasks: adjusted.adjustedTasks,
              dialogText: submitResult.dialogText || submitResult.expiredSchedule?.dialogText || ""
            });
            logs.push(`第 ${item.index} 条：CMS 提示定时时间已过期，原时间=${original.date || ""} ${submitResult.originalTime || original.time || ""}，已点击“是”改成立即执行；顺延锚点=${dateTimeForLog(anchor.date)}（${anchor.evidenceLabel}）。`);
            if (adjusted.adjustedTasks.length) {
              logs.push(`后续第 ${adjusted.range.first} 条到第 ${adjusted.range.last} 条按最终保存预览基线应用固定偏移 ${formatSignedSeconds(adjusted.offsetSeconds)}；仅原始时间无效时使用默认间隔：${formatIntervalRules(adjusted.intervalRules)}。`);
              for (const detail of adjusted.adjustedTasks) {
                logs.push(formatRuntimeScheduleAdjustment(detail));
              }
            } else {
              logs.push("后续没有未创建任务，不需要重新顺延。");
            }
            await saveRuntimeScheduleOutputs(runDir, {
              version: 2,
              runDir,
              previewPath: dryRun.previewPath,
              adjustedAt: anchor.date.toISOString(),
              baseline: runtimeScheduleBaseline,
              offsetSeconds: runtimeScheduleOffsetSeconds,
              events: runtimeScheduleEvents,
              plan,
              ...(expiredScheduleCount >= limit && adjusted.adjustedTasks.length ? {
                pendingDecision: expiredScheduleDecisionPayload(item, plan, planIndex, expiredScheduleCount, runtimeScheduleBaseline)
              } : {})
            });
            if (expiredScheduleCount >= limit && adjusted.adjustedTasks.length) {
              await checkpoint(options.control, `第 ${item.index} 条创建成功：${planIndex + 1}/${plan.length} / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.time || ""} / ${item.type || ""}`);
              successCheckpointed = true;
              const decision = await handleExpiredScheduleDecision(options.control, {
                ...expiredScheduleDecisionPayload(item, plan, planIndex, expiredScheduleCount, runtimeScheduleBaseline),
                runDir
              });
              if (decision.action === "stop") throw new Error("用户在过期排程选择处停止了本轮。");
              if (decision.action === "edited") {
                await applyEditedRemainingSchedule(dryRun.previewPath, plan, runtimeScheduleBaseline, planIndex);
                runtimeScheduleOffsetSeconds = null;
                runtimeScheduleEvents.push({
                  event: "expired_schedule_intervals_edited",
                  taskIndex: item.index,
                  resumedAt: resolveRuntimeNow(options).toISOString(),
                  adjustedRange: { first: plan[planIndex + 1]?.index || null, last: plan.at(-1)?.index || null }
                });
                logs.push(`连续 ${expiredScheduleCount} 次遇到过期时间后，已按用户修改的剩余间隔继续；已成功到第 ${item.index} 条，下一条为第 ${plan[planIndex + 1]?.index || "?"} 条。`);
              } else {
                const resumedAt = resolveRuntimeNow(options);
                const resumed = adjustRemainingScheduleAfterExpired(plan, runtimeScheduleBaseline, planIndex, resumedAt, options);
                runtimeScheduleOffsetSeconds = resumed.offsetSeconds;
                runtimeScheduleEvents.push({
                  event: "expired_schedule_direct_resume",
                  taskIndex: item.index,
                  resumedAt: resumedAt.toISOString(),
                  offsetSeconds: resumed.offsetSeconds,
                  adjustedRange: resumed.range,
                  adjustedTasks: resumed.adjustedTasks
                });
                logs.push(`连续 ${expiredScheduleCount} 次遇到过期时间后，用户选择直接顺延；剩余任务已从 ${dateTimeForLog(resumedAt)} 重新锚定并继续。`);
              }
              expiredScheduleCount = 0;
              await saveRuntimeScheduleOutputs(runDir, {
                version: 2,
                runDir,
                previewPath: dryRun.previewPath,
                adjustedAt: resolveRuntimeNow(options).toISOString(),
                baseline: runtimeScheduleBaseline,
                offsetSeconds: runtimeScheduleOffsetSeconds,
                events: runtimeScheduleEvents,
                plan,
                pendingDecision: null
              });
            }
          } else {
            expiredScheduleCount = 0;
          }
          if (!successCheckpointed) {
            await checkpoint(options.control, `第 ${item.index} 条创建成功：${planIndex + 1}/${plan.length} / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.time || ""} / ${item.type || ""}`);
          }
        } else {
          await checkpoint(options.control, `第 ${item.index} 条点击执行发送前`);
          logs.push(`第 ${item.index} 条：提交前停止`);
          completed.push({ ...item, submitted: false });
          outcomes.push(createTaskOutcome(item, "not_submitted", "dry-run 未真实提交"));
        }
        collectNewAdapterActions(adapter, actionCursors, adapterActions);
        itemDone = true;
      } catch (error) {
        if (allowRealSubmit && submitState.get(item)?.status === "succeeded") {
          const bookkeepingError = new Error(`第 ${item.index} 条已经确认创建成功，但成功后的本地记账或排程处理失败；为避免重复创建，本次停止且不会重试该条。原错误：${error?.message || String(error)}`);
          bookkeepingError.code = "CMS_POST_SUBMIT_BOOKKEEPING_FAILED";
          bookkeepingError.cause = error;
          throw bookkeepingError;
        }
        const resumeDecision = handleResumeFromIndexDecision(error, item, plan, planIndex, options, logs);
        if (resumeDecision === "retry") continue;
        if (resumeDecision && Number.isInteger(resumeDecision.nextPlanIndex)) {
          planIndex = resumeDecision.nextPlanIndex;
          itemDone = true;
          continue;
        }
        const decision = await handleTaskErrorDecision(error, item, planIndex, plan.length, options, logs);
        if (decision === "retry") {
          logs.push(`第 ${item.index} 条：人工选择重试当前条。`);
          await focusTaskPageForRetry(item, options, logs);
          continue;
        }
        if (decision === "skip") {
          logs.push(`第 ${item.index} 条：人工选择跳过当前条。原因：${error?.message || String(error)}`);
          completed.push({ ...item, submitted: false, skippedAfterError: true, error: error?.message || String(error) });
          outcomes.push(createTaskOutcome(item, "skipped", error?.message || String(error)));
          if (allowRealSubmit) await submitState.update(item, "skipped", {
            attempt: Number(submitState.get(item)?.attempt || 1),
            action: "人工跳过",
            reason: error?.message || String(error)
          });
          itemDone = true;
          continue;
        }
        throw error;
      }
    }
  }

  logs.push("");
  logs.push(allowRealSubmit
    ? "执行骨架完成：已按 adapter 提交。"
    : "执行骨架完成：默认 dry-run，没有真实提交。");

  const result = {
    ok: true,
    source: dryRun.source,
    previewPath: dryRun.previewPath,
    runDir,
    total: dryRun.total,
    skipped: dryRun.skipped,
    createCount: dryRun.createCount,
    allowRealSubmit,
    completed,
    outcomes,
    summary: summarizeTaskOutcomes(outcomes),
    runtimeScheduleEvents,
    runtimeScheduleState: runtimeScheduleEvents.length ? {
      version: 2,
      runDir,
      previewPath: dryRun.previewPath,
      baseline: runtimeScheduleBaseline,
      offsetSeconds: runtimeScheduleOffsetSeconds,
      events: runtimeScheduleEvents,
      plan
    } : null,
    adjustedPlan: plan,
    adapterActions,
    log: logs.join("\n")
  };
  await saveRunnerOutputs(runDir, result);
  return result;
}

async function recordSuccessfulTuoUsage(submitState, item, projectRoot) {
  if (item?.role !== "tuo" || item?.tuoAssignment?.mode !== "precise_roster") return null;
  const record = submitState.get(item);
  if (record?.status !== "succeeded" || record.usageRecordedAt) return record;
  if (!record.scopeId || !record.accountId || !record.successAt || !record.tuoGroupKey) {
    return submitState.update(item, "succeeded", {
      reconciliationStatus: "manual_required",
      reconciliationReason: "成功记录缺少可靠的名单范围、账号身份、原始说话人组或成功时间，不能自动记账"
    });
  }
  const written = await recordTuoUsageEvent({ projectRoot, event: usageEventFromSubmitRecord({ runId: record.runIdentity }, record) });
  return submitState.update(item, "succeeded", {
    usageRecordedAt: new Date().toISOString(),
    usageEventId: written.event?.eventId || "",
    reconciliationStatus: "recorded"
  });
}

function preciseSubmitIdentity(item = {}, submitResult = {}) {
  if (item?.tuoAssignment?.mode !== "precise_roster") return {};
  const selected = submitResult?.actualCandidate
    || item.tuoAssignment.runtimeSelected
    || item.tuoAssignment.primary
    || {};
  return {
    scopeId: item.tuoAssignment.scopeId || selected.scopeId || "",
    accountId: selected.accountId || "",
    externalAccountId: selected.externalAccountId || "",
    cmsAccountIdentity: selected.cmsAccountIdentity || selected.externalAccountId || "",
    actualRobotNickname: selected.nickname || item.speaker || "",
    tuoGroupKey: item.tuoAssignment.groupKey || "",
    successAt: submitResult.successAt || new Date().toISOString()
  };
}

function syncRemainingPreciseGroupPlan(plan, currentIndex, item, selected) {
  const groupKey = String(item?.tuoAssignment?.groupKey || "");
  if (!groupKey || !selected?.accountId) return 0;
  let changed = 0;
  for (let index = currentIndex + 1; index < plan.length; index += 1) {
    const next = plan[index];
    if (next?.tuoAssignment?.groupKey !== groupKey) continue;
    next.speaker = selected.nickname || next.speaker;
    next.cleanSpeaker = String(selected.nickname || next.cleanSpeaker || "").replace(/\s+/g, "");
    next.tuoAssignment = { ...next.tuoAssignment, primary: { ...selected }, runtimeSelected: { ...selected } };
    changed += 1;
  }
  return changed;
}

async function findProjectRoot(runDir) {
  let current = path.resolve(runDir);
  for (let depth = 0; depth < 5; depth += 1) {
    try {
      await fs.access(path.join(current, "package.json"));
      return current;
    } catch {}
    const parent = path.dirname(current);
    if (parent === current) break;
    current = parent;
  }
  return path.dirname(path.resolve(runDir));
}

export async function findLatestV2RunnerSource(runsRoot) {
  return findLatestV2DryRunSource(runsRoot);
}

export function buildCreateRunnerReport(result) {
  return [
    result.log,
    "",
    `create-runner.log：${path.join(result.runDir, "create-runner.log")}`,
    `create-runner-actions.json：${path.join(result.runDir, "create-runner-actions.json")}`
  ].join("\n");
}

async function saveRunnerOutputs(runDir, result) {
  await fs.writeFile(path.join(runDir, "create-runner.log"), result.log, "utf8");
  await fs.writeFile(path.join(runDir, "create-runner-actions.json"), JSON.stringify(result.adapterActions, null, 2), "utf8");
  if (result.runtimeScheduleState) {
    await saveRuntimeScheduleOutputs(runDir, result.runtimeScheduleState);
  }
}

function collectNewAdapterActions(adapter, actionCursors, adapterActions) {
  const actions = adapter.actions || [];
  const cursor = actionCursors.get(adapter) || 0;
  if (actions.length > cursor) {
    adapterActions.push(...actions.slice(cursor));
    actionCursors.set(adapter, actions.length);
  }
}

async function checkpoint(control, label) {
  if (!control?.checkpoint) return;
  await control.checkpoint(label);
}

async function runTimedTaskStep(task, options, step) {
  const waiting = step.waiting || step.logLabel || "执行 CMS 动作";
  if (step.checkBeforeAction !== false) {
    await checkpoint(options.control, `第 ${task.index} 条${waiting}`);
  }
  const actionLifecycle = step.actionLifecycle;
  const actionToken = Symbol(`cms-action-${task.index}-${step.logLabel || waiting}`);
  options.onPageActionState?.({ active: true, token: actionToken, task, label: step.logLabel || waiting });
  const actionPromise = Promise.resolve().then(() => step.action(actionLifecycle));
  actionPromise.then(
    () => options.onPageActionState?.({ active: false, token: actionToken, task, label: step.logLabel || waiting }),
    () => options.onPageActionState?.({ active: false, token: actionToken, task, label: step.logLabel || waiting })
  );
  return withTaskStepTimeout(task, options, actionPromise, {
    waiting,
    timeoutMs: step.timeoutMs || options.taskStepTimeoutMs || 120000,
    suggestion: step.suggestion || "请确认当前 CMS 页面可操作后重试。",
    actionLifecycle
  });
}

async function handleTaskErrorDecision(error, task, planIndex, totalCount, options, logs) {
  if (error?.code === "skip_current") return "skip";
  if (shouldBypassManualErrorHandling(error)) throw error;
  if (typeof options.control?.handleTaskError !== "function") throw error;
  const decision = await options.control.handleTaskError({
    task,
    planIndex,
    totalCount,
    error,
    message: error?.message || String(error)
  });
  if (decision === "retry" || decision === "skip") return decision;
  if (decision === "stop") {
    throw new Error(`用户选择停止本轮，停在第 ${task.index} 条。原始错误：${error?.message || String(error)}`);
  }
  logs.push(`第 ${task.index} 条：人工处理返回未知选择 ${decision || "空"}，按停止处理。`);
  throw error;
}

function handleResumeFromIndexDecision(error, task, plan, planIndex, options, logs) {
  if (error?.code !== "resume_from_index") return null;
  const targetIndex = Number(error.targetIndex || 0);
  if (!targetIndex) return null;
  if (typeof options.control?.clearResumeFromIndex === "function") {
    options.control.clearResumeFromIndex(targetIndex);
  }
  const targetPlanIndex = plan.findIndex((entry) => Number(entry.index) >= targetIndex);
  if (targetPlanIndex < 0) {
    logs.push(`人工选择从第 ${targetIndex} 条继续，但后面没有待创建任务，本轮结束。`);
    return { nextPlanIndex: plan.length - 1 };
  }
  if (targetPlanIndex <= planIndex) {
    logs.push(`人工选择从第 ${targetIndex} 条继续，重新开始第 ${task.index} 条。`);
    return "retry";
  }
  logs.push(`人工选择从第 ${targetIndex} 条继续，跳到第 ${plan[targetPlanIndex].index} 条。`);
  return { nextPlanIndex: targetPlanIndex - 1 };
}

async function focusTaskPageForRetry(task, options, logs) {
  const adapter = typeof options.adapterForTask === "function" ? options.adapterForTask(task) : options.adapter;
  if (typeof adapter?.focusTaskPageForRetry !== "function") return;
  await adapter.focusTaskPageForRetry(task);
  logs.push(`第 ${task.index} 条：已定位到${roleLabel(task.role)}云中客页面，准备后台重试。`);
}

function shouldBypassManualErrorHandling(error) {
  const message = error?.message || String(error || "");
  return error?.code === "resume_from_index"
    || error?.code === "skip_current"
    || error?.code === "CMS_SUBMIT_UNKNOWN"
    || error?.code === "CMS_SUBMIT_PLAN_MISMATCH"
    || error?.code === "CMS_PAGE_SESSION_INVALID"
    || error?.code === "CMS_PAGE_CONFIG_CHANGED"
    || error?.code === "ROBOT_ACCOUNT_IDENTITY_AMBIGUOUS"
    || error?.code === "CMS_ACTION_CANCELLED"
    || error?.code === "CMS_ACTION_NOT_DRAINED"
    || /用户已停止|已停止，后台停在检查点|控制台后台服务已断开/.test(message);
}

async function withTaskStepTimeout(task, options, promise, details = {}) {
  const timeoutMs = Math.max(1000, Number(details.timeoutMs || 120000));
  let timer;
  let finished = false;
  try {
    return await Promise.race([
      promise,
      monitorControlDuringTaskStep(task, options, details, () => finished),
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          reject(new Error(formatTaskStepTimeout(task, options, details, timeoutMs)));
        }, timeoutMs);
      })
    ]);
  } catch (error) {
    details.actionLifecycle?.cancel(error?.message || String(error));
    const drained = await waitForActionDrain(promise, options.actionDrainTimeoutMs || 250);
    if (!drained && !details.actionLifecycle) {
      const drainError = new Error(`第 ${task.index || "?"} 条旧页面动作未能结束，已停止且不会启动同页下一条。原始原因：${error?.message || String(error)}`);
      drainError.code = "CMS_ACTION_NOT_DRAINED";
      drainError.actionDrained = false;
      throw drainError;
    }
    if (details.actionLifecycle?.submitMayBeUnknown) {
      await details.actionLifecycle.markUnknown(error?.message || String(error));
      throw createUnknownSubmitError(task);
    }
    throw error;
  } finally {
    finished = true;
    if (timer) clearTimeout(timer);
  }
}

async function waitForActionDrain(promise, timeoutMs) {
  let timer;
  try {
    return await Promise.race([
      promise.then(() => true, () => true),
      new Promise((resolve) => {
        timer = setTimeout(() => resolve(false), Math.max(25, Number(timeoutMs || 250)));
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function createTaskOutcome(task, status, reason = "") {
  return {
    index: Number(task?.index || 0),
    sourceId: String(task?.sourceId || ""),
    role: String(task?.role || ""),
    type: String(task?.type || ""),
    status,
    reason: String(reason || "").slice(0, 300)
  };
}

const UNCERTAIN_RECOVERY_STATUSES = ["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown"];

function normalizeRecoveryDecision(value, plan) {
  if (!value || typeof value !== "object") return null;
  const startTaskIndex = Number(value.startTaskIndex);
  if (!Number.isInteger(startTaskIndex) || startTaskIndex < 1 || startTaskIndex > plan.length) {
    const error = new Error("续发起点无效，已停止创建。");
    error.code = "CMS_RECOVERY_START_INVALID";
    throw error;
  }
  return {
    version: 1,
    decisionId: String(value.decisionId || ""),
    oldRequestId: String(value.oldRequestId || ""),
    mode: String(value.mode || ""),
    previewSignature: String(value.previewSignature || ""),
    boundaryTaskIndex: Number(value.boundaryTaskIndex || 0),
    lastConfirmedIndex: Number(value.lastConfirmedIndex || 0),
    startTaskIndex,
    forceRestart: value.forceRestart === true,
    selectedAt: String(value.selectedAt || "")
  };
}

function summarizeTaskOutcomes(outcomes = []) {
  const summary = { succeeded: 0, failed: 0, skipped: 0, unknown: 0, notSubmitted: 0 };
  for (const outcome of outcomes) {
    if (outcome.status === "succeeded") summary.succeeded += 1;
    else if (outcome.status === "failed") summary.failed += 1;
    else if (outcome.status === "skipped") summary.skipped += 1;
    else if (outcome.status === "unknown") summary.unknown += 1;
    else summary.notSubmitted += 1;
  }
  return summary;
}

async function monitorControlDuringTaskStep(task, options = {}, details = {}, isFinished = () => false) {
  if (typeof options.control?.snapshot !== "function") return new Promise(() => {});
  while (!isFinished()) {
    const snapshot = options.control.snapshot();
    if (snapshot.control === "skip_current") {
      const error = new Error(`人工选择跳过第 ${task.index || "?"} 条`);
      error.code = "skip_current";
      throw error;
    }
    if (snapshot.control === "resume_from_index") {
      const error = new Error(`人工选择从第 ${snapshot.resumeTargetIndex || "?"} 条继续创建`);
      error.code = "resume_from_index";
      error.targetIndex = snapshot.resumeTargetIndex;
      throw error;
    }
    if (snapshot.control === "stopped") {
      throw new Error(`用户已停止，后台停在检查点：第 ${task.index || "?"} 条${details.waiting || "执行 CMS 动作"}`);
    }
    await sleep(500);
  }
  return new Promise(() => {});
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function formatTaskStepTimeout(task, options, details, timeoutMs) {
  const role = roleLabel(task.role);
  return [
    `第 ${task.index} 条 ${role} 任务超时。`,
    `当前 role=${task.role || ""}（${role}）。`,
    `当前页面=${role}页面。`,
    `当前等待=${details.waiting || "CMS 页面响应"}。`,
    `已等待=${Math.round(timeoutMs / 1000)} 秒。`,
    `建议处理：${details.suggestion || "请确认当前 CMS 页面可操作后重试。"}`
  ].join(" ");
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "未知角色";
}

function adjustRemainingScheduleAfterExpired(plan, baseline, currentPlanIndex, anchor, options = {}) {
  const intervalRules = describeIntervalRules(options);
  const adjusted = shiftRemainingScheduleByPreviewOffset({
    plan,
    baseline,
    currentPlanIndex,
    anchorDate: anchor,
    fallbackGapSeconds: (previous, next) => gapBetweenRuntimeTasks(previous, next, options)
  });
  return {
    ...adjusted,
    startTime: dateTimeForLog(anchor),
    intervalRules,
  };
}

function gapBetweenRuntimeTasks(prev, next, options = {}) {
  if (!prev || !next) return 0;
  if (sameInteractionGroup(prev, next)) return pickInterval("sameTuo", 20, 45, options);
  if (prev.role !== next.role) return pickRoleSwitchRuntimeInterval(options);
  if (isMedia(prev) || isMedia(next)) return pickInterval("media", 30, 50, options);
  if (next.role === "douma") return pickInterval("doumaSame", 45, 45, options);
  if (prev.speaker === next.speaker) return pickInterval("sameTuo", 20, 45, options);
  return pickInterval("differentTuo", 15, 15, options);
}

function pickRoleSwitchRuntimeInterval(options = {}) {
  if (hasCustomInterval("roleSwitch", options)) return pickInterval("roleSwitch", 120, 120, options);
  return Math.max(120, pickInterval("roleSwitch", 120, 120, options));
}

function formatRuntimeScheduleAdjustment(detail = {}) {
  const previewTime = `${detail.previewDate || ""} ${detail.previewTime || ""}`.trim() || "空";
  const adjustedTime = `${detail.newDate || ""} ${detail.newTime || ""}`.trim() || "空";
  return [
    `运行时重排：第 ${detail.index} 条`,
    `最终保存预览时间=${previewTime}`,
    detail.basis === "preview_fixed_offset"
      ? `固定偏移=${formatSignedSeconds(detail.offsetSeconds)}`
      : `默认兜底间隔=${detail.fallbackGapSeconds}秒`,
    `是否调整=${detail.adjusted ? "是" : "否"}`,
    `调整后时间=${adjustedTime}`,
    `原因=${detail.reason || ""}`
  ].join("；");
}

function formatCmsScheduleSetLog(item, result = {}) {
  return [
    `第 ${item.index} 条：CMS 定时已设置`,
    `preview 日期=${item.date || ""}`,
    `preview 时间=${item.time || ""}`,
    result.todayDate ? `今天日期=${result.todayDate}` : "",
    Number.isFinite(Number(result.dateOffsetDays)) ? `日期差=${Number(result.dateOffsetDays)}天` : "",
    `CMS 选择=${result.selectedDateText || result.optionText || result.date || ""}`,
    `CMS 填写时间=${result.time || item.time || ""}`
  ].filter(Boolean).join("；");
}

function formatCmsScheduleVerifyLog(item, result = {}) {
  result = result || {};
  return [
    `第 ${item.index} 条：提交前 CMS 日期时间复核通过`,
    `预期=${item.date || ""} ${item.time || ""}`.trim(),
    `实际=${result.selectedDateText || result.date || ""} ${result.selectedTime || result.time || ""}`.trim()
  ].join("；");
}

function pickInterval(key, min, max, options = {}) {
  const custom = options.intervals?.[key];
  const low = Number.isFinite(Number(custom?.min)) ? Number(custom.min) : min;
  const high = Number.isFinite(Number(custom?.max)) ? Number(custom.max) : max;
  if (options.randomizeRuntimeSchedule === true || options.randomize === true) {
    const rnd = typeof options.random === "function" ? options.random() : Math.random();
    return Math.round(low + Math.max(0, Math.min(1, rnd)) * (high - low));
  }
  return Math.round((low + high) / 2);
}

function hasCustomInterval(key, options = {}) {
  const custom = options.intervals?.[key];
  return Number.isFinite(Number(custom?.min)) || Number.isFinite(Number(custom?.max));
}

function describeIntervalRules(options = {}) {
  return {
    mode: options.scheduleMode || "doc",
    sameTuo: describeInterval("sameTuo", 20, 45, options),
    differentTuo: describeInterval("differentTuo", 15, 15, options),
    media: describeInterval("media", 30, 50, options),
    doumaSame: describeInterval("doumaSame", 45, 45, options),
    roleSwitch: describeInterval("roleSwitch", 120, 120, options)
  };
}

function describeInterval(key, min, max, options = {}) {
  const custom = options.intervals?.[key];
  const low = Number.isFinite(Number(custom?.min)) ? Number(custom.min) : min;
  const high = Number.isFinite(Number(custom?.max)) ? Number(custom.max) : max;
  return { min: low, max: high, custom: Boolean(custom) };
}

function formatIntervalRules(rules = {}) {
  const text = (key, label) => {
    const item = rules[key] || {};
    const range = item.min === item.max ? `${item.min}秒` : `${item.min}-${item.max}秒`;
    return `${label}${range}${item.custom ? "(自定义)" : ""}`;
  };
  return [
    `模式=${rules.mode || "doc"}`,
    text("sameTuo", "同托连续"),
    text("differentTuo", "不同托"),
    text("media", "素材附近"),
    text("doumaSame", "豆妈连续"),
    text("roleSwitch", "豆妈/托切换")
  ].join("，");
}

function expiredScheduleDecisionPayload(item, plan, planIndex, expiredCount, baseline) {
  const originalEnd = baseline.at(-1) || {};
  const projectedEnd = plan.at(-1) || {};
  return {
    expiredCount,
    completedIndex: Number(item?.index || 0),
    completedSubmitIdentity: String(item?.submitIdentity || ""),
    nextIndex: Number(plan[planIndex + 1]?.index || 0),
    totalCount: plan.length,
    originalEnd: [originalEnd.date, originalEnd.time].filter(Boolean).join(" "),
    projectedEnd: [projectedEnd.date, projectedEnd.time].filter(Boolean).join(" ")
  };
}

async function handleExpiredScheduleDecision(control, details) {
  if (typeof control?.handleExpiredScheduleThreshold === "function") {
    return await control.handleExpiredScheduleThreshold(details);
  }
  const error = new Error(`连续 ${details.expiredCount} 次遇到过期定时弹窗；当前条已创建成功，已在下一条前暂停。请在可视化控制台选择直接顺延或修改剩余间隔。`);
  error.code = "CMS_EXPIRED_SCHEDULE_DECISION_REQUIRED";
  throw error;
}

async function applyEditedRemainingSchedule(previewPath, plan, baseline, currentPlanIndex) {
  const tasks = JSON.parse(await fs.readFile(previewPath, "utf8"));
  const byIdentity = new Map((Array.isArray(tasks) ? tasks : []).map((task) => [String(task?.submitIdentity || ""), task]));
  for (let index = currentPlanIndex + 1; index < plan.length; index += 1) {
    const identity = String(plan[index]?.submitIdentity || "");
    const edited = byIdentity.get(identity);
    if (!identity || !edited) {
      const error = new Error(`续排保存后无法对应第 ${plan[index]?.index || "?"} 条任务，已停止，避免串轮次。`);
      error.code = "CMS_RUNTIME_SCHEDULE_EDIT_MISMATCH";
      throw error;
    }
    plan[index].date = edited.date;
    plan[index].time = edited.time;
    const base = baseline.find((entry) => String(entry?.submitIdentity || "") === identity);
    if (base) {
      base.date = edited.date;
      base.time = edited.time;
    }
  }
}

function resolveRuntimeNow(options = {}) {
  if (typeof options.now === "function") return new Date(options.now());
  if (options.now) return new Date(options.now);
  return new Date();
}

function resolveExpiredScheduleAnchor(result, options = {}) {
  const raw = result?.expiredScheduleConfirmedAt || result?.expiredSchedule?.confirmedAt;
  const parsed = raw ? new Date(raw) : null;
  if (parsed && !Number.isNaN(parsed.getTime())) {
    return {
      date: parsed,
      evidence: "local_expired_confirm_click_approximation",
      evidenceLabel: "本机点击“是”前记录的近似时刻，非远端确认发送时刻"
    };
  }
  return {
    date: resolveRuntimeNow(options),
    evidence: "runner_observed_after_submit_fallback",
    evidenceLabel: "提交返回后的本机观察时刻，非远端确认发送时刻"
  };
}

function baselineForTask(baseline = [], task = {}) {
  return baseline.find((item) => String(item?.submitIdentity || "") === String(task?.submitIdentity || "")) || null;
}

function formatSignedSeconds(value) {
  const seconds = Math.round(Number(value) || 0);
  return `${seconds >= 0 ? "+" : ""}${seconds}秒`;
}

function secondsSinceLocalMidnight(date) {
  return date.getHours() * 3600 + date.getMinutes() * 60 + date.getSeconds();
}

function secondsToClock(totalSeconds) {
  const seconds = ((Math.round(Number(totalSeconds) || 0) % 86400) + 86400) % 86400;
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(Math.floor(seconds / 3600))}:${pad(Math.floor((seconds % 3600) / 60))}:${pad(seconds % 60)}`;
}

function monthDayWithOffset(baseDate, offsetDays) {
  const date = new Date(baseDate);
  date.setDate(date.getDate() + offsetDays);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function dateTimeForLog(date) {
  return `${monthDayWithOffset(date, 0)} ${secondsToClock(secondsSinceLocalMidnight(date))}`;
}

function isMedia(task) {
  return task.type === "image" || task.type === "sticker" || task.type === "video";
}

function sameInteractionGroup(prev, next) {
  return Boolean(prev?.interactionGroup && next?.interactionGroup && prev.interactionGroup === next.interactionGroup);
}

async function saveRuntimeScheduleOutputs(runDir, payload) {
  await fs.writeFile(path.join(runDir, "runtime-schedule.json"), JSON.stringify(payload, null, 2), "utf8");
  await fs.writeFile(path.join(runDir, "adjusted-preview.json"), JSON.stringify(payload.plan || [], null, 2), "utf8");
}

async function loadRuntimeScheduleState(runDir) {
  try {
    const text = await fs.readFile(path.join(runDir, "runtime-schedule.json"), "utf8");
    const parsed = JSON.parse(text);
    return parsed?.version === 2
      ? parsed
      : { version: 0, invalidReason: "运行时排程状态版本无效" };
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    if (error instanceof SyntaxError) {
      return { version: 0, invalidReason: "运行时排程 JSON 已损坏" };
    }
    throw error;
  }
}

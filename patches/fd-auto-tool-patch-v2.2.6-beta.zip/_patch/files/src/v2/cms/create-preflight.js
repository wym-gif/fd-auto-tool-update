import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { PREVIEW_TASK_REQUIRED_FIELDS, validatePreviewTaskShape } from "../contracts/preview-task.js";
import { loadFinalPreviewForCreate } from "../preview/preview-store.js";
import { findLatestPreviewJsonRun } from "./preview-run-source.js";

export async function findLatestV2PreviewRun(runsRoot) {
  return findLatestPreviewJsonRun(runsRoot);
}

export async function runCreatePreflight(runDir, options = {}) {
  const finalPreview = await loadFinalPreviewForCreate(runDir);
  const robotStrategy = await robotStrategyForCreateRun(runDir);
  const tasks = assignSubmitIdentities(normalizeCreateTasksForRobotStrategy(finalPreview.tasks, robotStrategy));
  const errors = [];
  const createTasks = [];
  const skippedTasks = [];

  for (const [index, task] of tasks.entries()) {
    try {
      validatePreviewTaskShape(task);
      await validateCreateReadyTask(task, index, { ...options, runDir });
      if (task.skip) skippedTasks.push(task);
      else createTasks.push(task);
    } catch (error) {
      errors.push(error?.message || String(error));
    }
  }

  if (errors.length) {
    throw new Error(`创建前校对失败：${errors.join("；")}`);
  }

  return {
    ok: true,
    robotStrategy,
    source: "preview.json",
    path: finalPreview.path,
    total: tasks.length,
    skipped: skippedTasks.length,
    createCount: createTasks.length,
    tasks,
    createTasks,
    skippedTasks,
    fields: PREVIEW_TASK_REQUIRED_FIELDS
  };
}

export function assignSubmitIdentities(tasks = []) {
  const occurrences = new Map();
  const explicitIdentities = new Set();
  return (Array.isArray(tasks) ? tasks : []).map((task) => {
    const explicitIdentity = String(task?.submitIdentity || "").trim();
    if (explicitIdentity) {
      if (explicitIdentities.has(explicitIdentity)) {
        throw new Error(`创建前校对失败：存在重复的稳定任务身份 ${explicitIdentity}`);
      }
      explicitIdentities.add(explicitIdentity);
      return { ...task, submitIdentity: explicitIdentity };
    }
    const fingerprint = createHash("sha256")
      .update(JSON.stringify([
        String(task?.sourceId || ""),
        String(task?.role || ""),
        String(task?.speaker || ""),
        String(task?.type || ""),
        String(task?.text || ""),
        String(task?.mediaPath || ""),
        String(task?.interactionGroup || ""),
        Boolean(task?.continueMarker)
      ]))
      .digest("hex");
    const occurrence = Number(occurrences.get(fingerprint) || 0) + 1;
    occurrences.set(fingerprint, occurrence);
    return {
      ...task,
      submitIdentity: `v2:${fingerprint}:${occurrence}`
    };
  });
}

export async function robotStrategyForCreateRun(runDir) {
  const librarySource = await readJsonIfExists(path.join(runDir, "library-source.json"));
  const report = await readJsonIfExists(path.join(runDir, "console-generate-report.json"));
  const libraryMeta = await readJsonIfExists(path.join(runDir, "library-meta.json"));
  return normalizeRobotStrategy(
    librarySource.robotStrategy
    || report.robotStrategy
    || libraryMeta.settingsSnapshot?.robotStrategy
  );
}

function normalizeCreateTasksForRobotStrategy(tasks, robotStrategy = "") {
  const strategy = normalizeRobotStrategy(robotStrategy);
  if (strategy === "precise" || !strategy) return tasks;
  return (Array.isArray(tasks) ? tasks : []).map((task) => {
    if (task?.role !== "tuo" || !task?.tuoAssignment) return task;
    const next = { ...task };
    delete next.tuoAssignment;
    return next;
  });
}

function normalizeRobotStrategy(value) {
  const strategy = String(value || "").trim();
  return ["random", "fixed", "precise"].includes(strategy) ? strategy : "";
}

export async function validateCreateReadyTask(task, index, options = {}) {
  const label = `第 ${index + 1} 条`;
  if (task.skip) return true;
  if (task.type === "text" || task.type === "finder") {
    if (!String(task.text || "").trim()) {
      throw new Error(`${label} ${task.type === "finder" ? "视频号参数" : "文本"}为空`);
    }
    if (task.type === "finder" && !isCompleteFinderXml(task.text)) {
      throw new Error(`${label} 视频号代码块未完整采集，请先回预览页手动补录完整参数`);
    }
    assertNoPreviewError(task, label);
    return true;
  }
  if (task.type === "image" || task.type === "sticker" || task.type === "video") {
    assertNoPreviewError(task, label);
    const mediaLabel = `${label} ${task.type}`;
    const mediaPath = String(task.mediaPath || "").trim();
    if (!mediaPath) {
      throw new Error(`${mediaLabel} 素材路径为空`);
    }
    if (isBlobMediaPath(mediaPath)) {
      throw new Error(`${mediaLabel} 是浏览器临时素材地址，不能正式创建，请先在预览页点“更换素材”换成本地文件：${mediaPath}`);
    }
    if (isLocalMediaPath(mediaPath) && options.checkFileExists !== false) {
      const localPath = resolveLocalMediaPath(mediaPath, options.runDir);
      try {
        await fs.access(localPath);
      } catch {
        throw new Error(`${mediaLabel} 素材不存在：${localPath}`);
      }
    }
    return true;
  }
  throw new Error(`${label} 类型无效：${task.type}`);
}

function assertNoPreviewError(task, label) {
  if (!String(task.previewError || "").trim()) return;
  const reason = String(task.invalidReason || task.previewError || "").trim();
  throw new Error(`${label} 仍有未解决的预览问题：${reason}`);
}

export function buildCreatePreflightReport(result) {
  return [
    "2.0 创建前校对",
    "",
    `创建前校对来源：${displayPreviewSource(result.source)}`,
    `文件：${result.path}`,
    `预览总数：${result.total}`,
    `跳过不发：${result.skipped}`,
    `待创建：${result.createCount}`,
    `校对字段：${result.fields.join(" / ")}`,
    "",
    "待创建列表：",
    ...result.createTasks.map((task, index) => formatCreateLine(task, index)),
    "",
    "校对通过：正式创建阶段只使用已确认的预览内容"
  ].join("\n");
}

function displayPreviewSource(source) {
  return source === "preview.json" ? "已保存的预览内容" : source;
}

function formatCreateLine(task, index) {
  const summary = task.type === "text" || task.type === "finder"
    ? compact(task.text)
    : compact(task.mediaPath);
  return `${index + 1}. ${roleLabel(task.role)} / ${task.speaker || ""} / ${task.date || ""} ${task.time || ""} / ${task.type} / ${summary}`;
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "";
}

function compact(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > 46 ? `${text.slice(0, 45)}...` : text;
}

function isLocalMediaPath(mediaPath) {
  if (isBlobMediaPath(mediaPath)) return false;
  if (/^[a-z]+:\/\//i.test(mediaPath)) return false;
  if (/^data:/i.test(mediaPath)) return false;
  return Boolean(mediaPath);
}

function resolveLocalMediaPath(mediaPath, runDir = "") {
  if (path.isAbsolute(mediaPath)) return mediaPath;
  return path.resolve(runDir || process.cwd(), mediaPath);
}

function isBlobMediaPath(mediaPath) {
  return /^blob:/i.test(String(mediaPath || "").trim());
}

function isCompleteFinderXml(text) {
  const value = String(text || "").trim();
  return /<msg\b/i.test(value) &&
    /<appmsg\b/i.test(value) &&
    (/<finderFeed\b/i.test(value) || /<type>\s*51\s*<\/type>/i.test(value)) &&
    /<\/msg>\s*$/i.test(value);
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

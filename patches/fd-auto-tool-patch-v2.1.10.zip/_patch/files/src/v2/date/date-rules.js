const DAY_MARKER_SUFFIX = "(?:早上|早晨|上午|中午|下午|晚上|凌晨|白天|夜里|夜间|内容|安排|发单|定时|跟发|补发|节奏|福利单)*";
const DAY_OFFSET_SUFFIX = "(?:早上|早晨|上午|中午|下午|晚上|凌晨|白天|夜里|夜间|晒图|图文|内容|安排|发单|定时|跟发|补发|节奏|福利单|种草|开团|返场|收割|预热)*";

export function detectChangeDayMarkerEvent(event, baseDate = "") {
  return classifyChangeDayMarkerEvent(event, baseDate).date;
}

export function classifyChangeDayMarkerEvent(event, baseDate = "") {
  if (!event || !["line", "title"].includes(event.kind || event.type)) {
    return { isHeading: false, date: "", ignoredReason: "" };
  }
  if (!isDateHeadingEvent(event)) return { isHeading: false, date: "", ignoredReason: "" };
  return classifyChangeDayMarkerText(event.text || event.sourceText || "", baseDate, {
    allowRelativeDay: isExplicitHeadingEvent(event)
  });
}

function isDateHeadingEvent(event) {
  const kind = event.kind || event.type;
  if (kind === "title") return true;
  if (kind === "line" && isStandaloneDateHeadingText(event.text || event.sourceText || "")) return true;
  return Boolean(
    event.dayHeading ||
    event.dateHeading ||
    event.heading ||
    event.raw?.dayHeading ||
    event.raw?.dateHeading ||
    event.raw?.heading
  );
}

function isExplicitHeadingEvent(event) {
  const kind = event.kind || event.type;
  return kind === "title" || Boolean(
    event.dayHeading ||
    event.dateHeading ||
    event.heading ||
    event.raw?.dayHeading ||
    event.raw?.dateHeading ||
    event.raw?.heading
  );
}

function isStandaloneDateHeadingText(value) {
  const raw = String(value || "").trim();
  if (!raw || /\d{1,2}[:：]\d{1,2}/.test(raw)) return false;
  const text = raw.replace(/\s+/g, "");
  return new RegExp(`^\\d{1,2}[\\/月]\\d{1,2}(?:日|号)?${DAY_MARKER_SUFFIX}$`).test(text) ||
    new RegExp(`^\\d{1,2}(?:日|号)${DAY_MARKER_SUFFIX}$`).test(text) ||
    detectRelativeDayNumber(text) !== null;
}

export function detectChangeDayMarkerText(value, baseDate = "") {
  return classifyChangeDayMarkerText(value, baseDate).date;
}

export function classifyChangeDayMarkerText(value, baseDate = "", options = {}) {
  const raw = String(value || "").trim();
  if (!raw || /\d{1,2}[:：]\d{1,2}/.test(raw)) {
    return { isHeading: false, date: "", ignoredReason: "" };
  }
  const text = raw.replace(/\s+/g, "");
  let candidate = "";

  let match = text.match(new RegExp(`^(\\d{1,2})[\\/月](\\d{1,2})(?:日|号)?${DAY_MARKER_SUFFIX}$`));
  if (match) candidate = `${Number(match[1])}/${Number(match[2])}`;

  const base = parseMonthDay(baseDate) || parseMonthDay(todayMonthDay());
  if (!candidate && !base) return { isHeading: false, date: "", ignoredReason: "" };

  if (!candidate) {
    match = text.match(new RegExp(`^(\\d{1,2})(?:日|号)${DAY_MARKER_SUFFIX}$`));
    if (match) candidate = `${base.month}/${Number(match[1])}`;
  }

  const relativeDayNumber = !candidate && options.allowRelativeDay === true
    ? detectRelativeDayNumber(text) ?? detectEmbeddedRelativeDayNumber(text)
    : null;
  if (!candidate && relativeDayNumber !== null) candidate = addDaysToMonthDay(base, relativeDayNumber - 1);
  if (!candidate && new RegExp(`^(明天|明日)${DAY_MARKER_SUFFIX}$`).test(text)) candidate = addDaysToMonthDay(base, 1);
  if (!candidate && new RegExp(`^后天${DAY_MARKER_SUFFIX}$`).test(text)) candidate = addDaysToMonthDay(base, 2);
  if (!candidate) return { isHeading: false, date: "", ignoredReason: "" };
  if (isPastMonthDay(candidate, baseDate)) {
    return { isHeading: true, date: "", ignoredReason: "past_date_heading", ignoredDate: candidate };
  }
  return { isHeading: true, date: candidate, ignoredReason: "" };
}

export function normalizeSendDate(value) {
  const parsed = parseMonthDay(value);
  return parsed ? `${parsed.month}/${parsed.day}` : "";
}

export function detectRelativeDayNumber(value) {
  const text = String(value || "").trim().replace(/\s+/g, "").toLowerCase();
  if (!text || /\d{1,2}[:：]\d{1,2}/.test(text)) return null;
  let match = text.match(new RegExp(`^(?:第)?([一二三四五六七八九十两]+)天${DAY_OFFSET_SUFFIX}$`));
  if (match) return chineseDayNumber(match[1]);
  match = text.match(new RegExp(`^第?([1-9]\\d?)天${DAY_OFFSET_SUFFIX}$`));
  if (match) return Number(match[1]);
  match = text.match(new RegExp(`^(?:d|day)([1-9]\\d?)${DAY_OFFSET_SUFFIX}$`));
  if (match) return Number(match[1]);
  return null;
}

function detectEmbeddedRelativeDayNumber(value) {
  const text = String(value || "").trim().replace(/\s+/g, "").toLowerCase();
  if (!text || /\d{1,2}[:：]\d{1,2}/.test(text)) return null;
  let match = text.match(/(?:第)?([一二三四五六七八九十两]+)天/);
  if (match) return chineseDayNumber(match[1]);
  match = text.match(/第?([1-9]\d?)天/);
  if (match) return Number(match[1]);
  return null;
}

export function parseMonthDay(value) {
  const text = String(value || "").trim();
  const iso = text.match(/^\d{4}-(\d{1,2})-(\d{1,2})$/);
  if (iso) return { year: Number(text.slice(0, 4)), month: Number(iso[1]), day: Number(iso[2]) };
  const md = text.match(/(\d{1,2})\s*[\/月-]\s*(\d{1,2})(?:日|号)?/);
  if (md) return { year: new Date().getFullYear(), month: Number(md[1]), day: Number(md[2]) };
  return null;
}

function chineseDayNumber(value) {
  const text = String(value || "");
  if (!text) return null;
  const digits = {
    一: 1,
    二: 2,
    两: 2,
    三: 3,
    四: 4,
    五: 5,
    六: 6,
    七: 7,
    八: 8,
    九: 9
  };
  if (digits[text]) return digits[text];
  if (text === "十") return 10;
  const tenMatch = text.match(/^十([一二三四五六七八九])$/);
  if (tenMatch) return 10 + digits[tenMatch[1]];
  const multiMatch = text.match(/^([一二三四五六七八九两])十([一二三四五六七八九])?$/);
  if (multiMatch) return digits[multiMatch[1]] * 10 + (multiMatch[2] ? digits[multiMatch[2]] : 0);
  return null;
}

export function addDaysToMonthDay(base, days) {
  const date = new Date(base.year || new Date().getFullYear(), base.month - 1, base.day + days);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

export function todayMonthDay() {
  const now = new Date();
  return `${now.getMonth() + 1}/${now.getDate()}`;
}

function isPastMonthDay(value, baseDate = "") {
  const base = parseMonthDay(baseDate) || parseMonthDay(todayMonthDay());
  const candidate = parseMonthDay(value);
  if (!base || !candidate) return false;
  const baseTime = Date.UTC(base.year || new Date().getFullYear(), base.month - 1, base.day);
  const candidateTime = Date.UTC(base.year || new Date().getFullYear(), candidate.month - 1, candidate.day);
  const diffDays = Math.round((candidateTime - baseTime) / 86400000);
  return diffDays < 0 && diffDays >= -180;
}

import fs from "node:fs/promises";
import path from "node:path";
import { buildCmsPageSelectionSnapshot, normalizeCmsPageSelection } from "./cms-page-selection-snapshot.js";

const BINDINGS_FILE = "cms-page-bindings.json";
const SETTING_KEYS = [
  "cmsUrl",
  "cdpUrl",
  "robotStrategy",
  "robotNotInGroupPolicy",
  "robotNotInGroupMaxRetries",
  "sameTuoMin",
  "sameTuoMax",
  "differentTuoMin",
  "differentTuoMax",
  "doumaSameMin",
  "doumaSameMax",
  "roleSwitchMin",
  "roleSwitchMax"
];

export async function buildCmsConfigSnapshot({ runDir, settings = {}, name = "" } = {}) {
  if (!runDir) throw new Error("没有当前 run 目录，无法保存云中客配置。");
  const bindingsPath = path.join(runDir, BINDINGS_FILE);
  const bindings = await readJsonIfExists(bindingsPath);
  if (!bindings || !Object.keys(bindings.roles || {}).length) {
    throw new Error("当前 run 没有可保存的云中客页面绑定，请先进入云中客设置并确认托/豆妈页面。");
  }
  const sourceRunId = bindings.runId || runIdFromRunDir(runDir);
  const roles = sanitizeRoles(bindings.roles);
  const pageSelection = buildCmsPageSelectionSnapshot(roles);
  return {
    version: 1,
    name: String(name || "").trim(),
    createdAt: new Date().toISOString(),
    sourceRunId,
    settings: pickSettings(settings),
    bindings: {
      roles,
      pages: sanitizePages(bindings.pages),
      source: bindings.source || bindings.bindingSource || ""
    },
    pageSelection,
    summary: summarizeRoles(roles, pageSelection)
  };
}

function pickSettings(settings = {}) {
  const picked = {};
  for (const key of SETTING_KEYS) {
    const value = settings[key];
    if (value !== undefined && value !== null && String(value).trim() !== "") picked[key] = value;
  }
  return picked;
}

function sanitizeRoles(roles = {}) {
  const next = {};
  for (const role of ["tuo", "douma"]) {
    if (!roles[role]) continue;
    next[role] = sanitizePageInfo(roles[role]);
  }
  return next;
}

function sanitizePages(pages = []) {
  return Array.isArray(pages) ? pages.map((page) => sanitizePageInfo(page)).filter((page) => page.url || page.role) : [];
}

function sanitizePageInfo(info = {}) {
  return {
    role: String(info.role || ""),
    index: Number.isFinite(Number(info.index)) ? Number(info.index) : undefined,
    url: String(info.url || ""),
    title: String(info.title || ""),
    marker: info.marker && typeof info.marker === "object" ? { ...info.marker } : {},
    selection: sanitizeSelection(info.selection)
  };
}

function sanitizeSelection(selection = {}) {
  return normalizeCmsPageSelection(selection);
}

function summarizeRoles(roles = {}, pageSelection = {}) {
  const labels = {
    tuo: "托",
    douma: "豆妈"
  };
  const roleSummaries = Object.entries(roles).map(([role, info]) => ({
    role,
    label: labels[role] || role,
    group: pageSelection[role]?.group || info.selection?.group || "",
    robot: pageSelection[role]?.robot || info.selection?.robot || "",
    taskRemark: pageSelection[role]?.taskRemark || info.selection?.taskRemark || "",
    selectedCounts: pageSelection[role]?.selectedCounts || [],
    multiQuickMode: pageSelection[role]?.multiQuickMode ?? null
  }));
  return {
    roleCount: roleSummaries.length,
    roles: roleSummaries
  };
}

function runIdFromRunDir(runDir = "") {
  return path.basename(String(runDir || "").replace(/[\\/]+$/, ""));
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

const LIBRARY_DIR = "cms-config-library";
const INDEX_FILE = "index.json";
const CONFIG_FILE = "config.json";

export function cmsConfigLibraryRoot(projectRoot) {
  return path.join(projectRoot, LIBRARY_DIR);
}

export async function listCmsConfigLibrary(projectRoot) {
  const root = cmsConfigLibraryRoot(projectRoot);
  const index = normalizeIndex(await readJsonIfExists(path.join(root, INDEX_FILE)));
  const items = [];
  for (const item of index.items) {
    const config = await readJsonIfExists(path.join(root, item.id, CONFIG_FILE));
    const summary = config.summary || item.summary || {};
    items.push({
      ...item,
      roleCount: summary.roleCount || Object.keys(config.bindings?.roles || {}).length,
      sourceRunId: config.sourceRunId || item.sourceRunId || "",
      summary,
      configForm: config.configForm || null
    });
  }
  return items.sort((a, b) => String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")));
}

export async function saveCmsConfigToLibrary(projectRoot, snapshot, options = {}) {
  const root = cmsConfigLibraryRoot(projectRoot);
  await fs.mkdir(root, { recursive: true });
  const indexPath = path.join(root, INDEX_FILE);
  const index = normalizeIndex(await readJsonIfExists(indexPath));
  const now = new Date().toISOString();
  const id = String(options.id || snapshot.id || "").trim() || `cms_${Date.now()}_${randomUUID().slice(0, 8)}`;
  const existingIndex = index.items.findIndex((item) => item.id === id);
  const existing = existingIndex >= 0 ? index.items[existingIndex] : {};
  const name = String(options.name || snapshot.name || existing.name || "").trim() || defaultCmsConfigName(snapshot);
  const itemDir = path.join(root, id);
  await fs.mkdir(itemDir, { recursive: true });
  const config = {
    ...snapshot,
    id,
    name,
    savedAt: now
  };
  await fs.writeFile(path.join(itemDir, CONFIG_FILE), JSON.stringify(config, null, 2), "utf8");
  const item = {
    id,
    name,
    createdAt: existing.createdAt || snapshot.createdAt || now,
    updatedAt: now,
    sourceRunId: snapshot.sourceRunId || "",
    summary: snapshot.summary || {}
  };
  if (existingIndex >= 0) index.items[existingIndex] = item;
  else index.items.push(item);
  await writeIndex(indexPath, index.items);
  return { ...item, roleCount: snapshot.summary?.roleCount || Object.keys(snapshot.bindings?.roles || {}).length };
}

export async function resolveCmsConfigLibraryItem(projectRoot, id) {
  const itemId = String(id || "").trim();
  if (!itemId) throw new Error("请选择云中客配置。");
  const root = cmsConfigLibraryRoot(projectRoot);
  const index = normalizeIndex(await readJsonIfExists(path.join(root, INDEX_FILE)));
  const item = index.items.find((entry) => entry.id === itemId);
  if (!item) throw new Error("没有找到这份云中客配置。");
  const config = await readJsonIfExists(path.join(root, item.id, CONFIG_FILE));
  if (!config || !Object.keys(config).length) throw new Error("云中客配置文件不存在或已损坏。");
  return { ...item, config };
}

export async function renameCmsConfigLibraryItem(projectRoot, id, name) {
  const itemId = String(id || "").trim();
  const nextName = String(name || "").trim();
  if (!itemId) throw new Error("请选择云中客配置。");
  if (!nextName) throw new Error("云中客配置名称不能为空。");
  const root = cmsConfigLibraryRoot(projectRoot);
  const indexPath = path.join(root, INDEX_FILE);
  const index = normalizeIndex(await readJsonIfExists(indexPath));
  const itemIndex = index.items.findIndex((entry) => entry.id === itemId);
  if (itemIndex < 0) throw new Error("没有找到这份云中客配置。");
  const now = new Date().toISOString();
  index.items[itemIndex] = { ...index.items[itemIndex], name: nextName, updatedAt: now };
  const configPath = path.join(root, itemId, CONFIG_FILE);
  const config = await readJsonIfExists(configPath);
  if (Object.keys(config).length) {
    await fs.writeFile(configPath, JSON.stringify({ ...config, name: nextName, savedAt: now }, null, 2), "utf8");
  }
  await writeIndex(indexPath, index.items);
  return index.items[itemIndex];
}

export async function deleteCmsConfigLibraryItem(projectRoot, id) {
  const itemId = String(id || "").trim();
  if (!itemId) throw new Error("请选择云中客配置。");
  const root = cmsConfigLibraryRoot(projectRoot);
  const indexPath = path.join(root, INDEX_FILE);
  const index = normalizeIndex(await readJsonIfExists(indexPath));
  const item = index.items.find((entry) => entry.id === itemId);
  if (!item) throw new Error("没有找到这份云中客配置。");
  await fs.rm(path.join(root, itemId), { recursive: true, force: true });
  await writeIndex(indexPath, index.items.filter((entry) => entry.id !== itemId));
  return item;
}

function defaultCmsConfigName(snapshot = {}) {
  const roleCount = Object.keys(snapshot.bindings?.roles || {}).length;
  const source = snapshot.sourceRunId ? ` ${snapshot.sourceRunId}` : "";
  return `云中客配置${source || ""}${roleCount ? ` ${roleCount}页` : ""}`.trim();
}

function normalizeIndex(value = {}) {
  const items = Array.isArray(value.items) ? value.items : [];
  return {
    items: items
      .map((item) => ({
        id: String(item.id || "").trim(),
        name: String(item.name || "").trim() || "未命名云中客配置",
        createdAt: String(item.createdAt || ""),
        updatedAt: String(item.updatedAt || item.createdAt || ""),
        sourceRunId: String(item.sourceRunId || ""),
        summary: item.summary && typeof item.summary === "object" ? item.summary : {}
      }))
      .filter((item) => item.id)
  };
}

async function writeIndex(indexPath, items) {
  await fs.mkdir(path.dirname(indexPath), { recursive: true });
  await fs.writeFile(indexPath, JSON.stringify({ items: normalizeIndex({ items }).items }, null, 2), "utf8");
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

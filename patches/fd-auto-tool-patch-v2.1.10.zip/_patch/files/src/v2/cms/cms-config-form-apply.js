import { normalizeCmsConfigForm, robotSwitchModeLabel } from "./cms-config-form.js";

export async function applyCmsConfigFormToPages({ pages = [], form = {}, onProgress } = {}) {
  const normalized = normalizeCmsConfigForm(form);
  const pageByRole = mapPagesByRole(pages);
  const results = [];
  const errors = [];
  for (const role of ["tuo", "douma"]) {
    const page = pageByRole[role];
    if (!page || page.isClosed?.()) {
      errors.push(`${roleLabel(role)}页面没有打开，无法自动设置。`);
      continue;
    }
    const payload = role === "tuo" ? buildTuoPayload(normalized) : buildDoumaPayload(normalized);
    const startMessage = `正在按云中客配置自动设置${roleLabel(role)}页面...`;
    await onProgress?.(startMessage);
    await showCmsConfigApplyOverlay(page, startMessage, "running");
    const result = await applyCmsConfigPayloadToPage(page, payload).catch((error) => ({
      ok: false,
      errors: [error?.message || String(error)],
      actions: []
    }));
    results.push({ role, ...result });
    if (result.ok) {
      await showCmsConfigApplyOverlay(page, `${roleLabel(role)}页面自动设置完成，请检查确认。确认无误后回控制台点击“我已设置好，开始创建任务”。`, "success");
      continue;
    }
    const roleErrors = result.errors?.length ? result.errors : [`${roleLabel(role)}页面自动设置失败。`];
    errors.push(...roleErrors.map((item) => `${roleLabel(role)}页面-${item}`));
    await showCmsConfigApplyOverlay(page, `自动设置失败：${roleErrors[0]}。请人工设置好后回控制台继续。`, "error");
  }
  return {
    ok: errors.length === 0,
    errors,
    results
  };
}

export async function showCmsConfigApplyOverlay(page, message, tone = "running", options = {}) {
  if (!page || page.isClosed?.()) return;
  await page.evaluate(({ message, tone, autoHideMs }) => {
    const id = "__fd_cms_config_apply_overlay";
    let box = document.getElementById(id);
    if (!box) {
      box = document.createElement("div");
      box.id = id;
      box.style.cssText = [
        "position:fixed",
        "left:50%",
        "top:50%",
        "transform:translate(-50%,-50%)",
        "z-index:2147483647",
        "max-width:min(560px,calc(100vw - 48px))",
        "padding:18px 24px",
        "border-radius:10px",
        "box-shadow:0 18px 60px rgba(15,23,42,.35)",
        "color:#fff",
        "font:700 18px/1.55 Arial,'Microsoft YaHei',sans-serif",
        "text-align:center",
        "pointer-events:none",
        "white-space:pre-wrap"
      ].join(";");
      document.body.appendChild(box);
    }
    box.textContent = message;
    box.style.background = tone === "error"
      ? "rgba(185,28,28,.92)"
      : tone === "success"
        ? "rgba(22,101,52,.88)"
        : "rgba(15,23,42,.78)";
    clearTimeout(window.__fdCmsConfigApplyOverlayTimer);
    if (autoHideMs > 0) {
      window.__fdCmsConfigApplyOverlayTimer = setTimeout(() => {
        box.style.opacity = "0";
        box.style.transition = "opacity .22s ease";
        setTimeout(() => box.remove(), 260);
      }, autoHideMs);
    }
  }, {
    message,
    tone,
    autoHideMs: Number.isFinite(options.autoHideMs)
      ? Math.max(0, Number(options.autoHideMs))
      : tone === "error"
        ? 15000
        : tone === "success"
          ? 8000
          : 0
  }).catch(() => {});
}

function mapPagesByRole(pages = []) {
  const byRole = {};
  for (const [index, page] of pages.entries()) {
    const role = page?.__v2CmsRole === "douma" ? "douma" : page?.__v2CmsRole === "tuo" ? "tuo" : "";
    if (role && !byRole[role]) byRole[role] = page;
    if (!role && index === 0 && !byRole.tuo) byRole.tuo = page;
    if (!role && index === 1 && !byRole.douma) byRole.douma = page;
  }
  return byRole;
}

function buildTuoPayload(form) {
  if (form.tuo.mode === "precise") {
    return {
      role: "tuo",
      mode: "precise",
      group: { mode: "group", value: form.tuo.precise.groupFilter, count: form.tuo.precise.groupSelectCount, label: "群包含分组" },
      robot: { mode: "group", value: form.tuo.precise.robotGroup, count: "1", label: "机器人分组" },
      taskRemark: form.tuo.precise.taskRemark,
      steps: ["group", "robot", "taskRemark"]
    };
  }
  return {
    role: "tuo",
    mode: "rough",
    multiQuickMode: true,
    group: { mode: "group", value: form.tuo.rough.managementGroup, count: form.tuo.rough.groupSelectCount, label: "管理分组" },
    robotSwitchMode: form.tuo.rough.robotSwitchMode,
    robotSwitchModeLabel: robotSwitchModeLabel(form.tuo.rough.robotSwitchMode),
    taskRemark: form.tuo.rough.taskRemark,
    steps: ["multiQuickMode", "group", "robotSwitchMode", "taskRemark"]
  };
}

function buildDoumaPayload(form) {
  return {
    role: "douma",
    mode: "douma",
    group: { mode: form.douma.groupSearchMode, value: form.douma.groupValue, count: form.douma.groupSelectCount, label: form.douma.groupSearchMode === "keyword" ? "群关键词" : "群分组" },
    robot: { mode: form.douma.robotSearchMode, value: form.douma.robotValue, count: form.douma.robotSelectCount, label: form.douma.robotSearchMode === "keyword" ? "机器人关键词" : "机器人分组" },
    taskRemark: form.douma.taskRemark,
    steps: ["group", "robot", "taskRemark"]
  };
}

async function applyCmsConfigPayloadToPage(page, payload) {
  return await page.evaluate(async (payload) => {
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const actions = [];
    const errors = [];
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return Boolean(r && r.width > 0 && r.height > 0 && (!s || (s.visibility !== "hidden" && s.display !== "none")));
    };
    const emit = (el) => {
      for (const eventName of ["input", "change", "blur"]) {
        el.dispatchEvent(new Event(eventName, { bubbles: true }));
      }
    };
    const setValue = (el, value) => {
      if (!el) return false;
      el.focus?.();
      if (el.isContentEditable) {
        el.textContent = value;
      } else {
        const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (el.readOnly) el.removeAttribute("readonly");
        if (setter) setter.call(el, value);
        else el.value = value;
      }
      emit(el);
      return true;
    };
    const clearValue = (el) => {
      if (!el) return false;
      const wrapper = el.closest?.(".el-select,.el-input,.el-form-item,div") || el.parentElement;
      const clearButton = wrapper?.querySelector?.(".el-input__suffix .el-icon-circle-close,.el-select__caret.is-reverse,[class*='close'],[class*='clear']");
      if (clearButton && visible(clearButton)) clearButton.click?.();
      setValue(el, "");
      el.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      emit(el);
      return true;
    };
    const allInputs = () => Array.from(document.querySelectorAll("textarea,input:not([type='file']),[contenteditable='true']"))
      .filter((input) => visible(input) && !input.disabled);
    const elementText = (el) => compact([el?.innerText, el?.textContent, el?.getAttribute?.("placeholder"), el?.getAttribute?.("aria-label")].filter(Boolean).join(" "));
    const containerText = (el) => compact([
      el?.getAttribute?.("placeholder"),
      el?.getAttribute?.("aria-label"),
      el?.closest?.(".el-form-item,label,tr,.el-table__row,li,[class*='row'],[class*='filter'],[class*='search'],div")?.innerText,
      el?.parentElement?.innerText
    ].filter(Boolean).join(" "));
    const nearbyInputText = (el) => compact([
      el?.getAttribute?.("placeholder"),
      el?.getAttribute?.("aria-label"),
      el?.previousElementSibling?.innerText,
      el?.previousElementSibling?.textContent,
      el?.parentElement?.querySelector?.("label")?.innerText,
      el?.parentElement?.querySelector?.("label")?.textContent
    ].filter(Boolean).join(" "));
    const visibleTextElements = (pattern) => Array.from(document.querySelectorAll("button,a,label,span,strong,div,td,th"))
      .filter((el) => visible(el) && pattern.test(compact(el.innerText || el.textContent)));
    const findNearestInputByText = (pattern, {
      scope = null,
      avoid = /任务备注|任意时间点|发送间隔|单群随机人数|执行后清空|发送模式|群顺序|消息模式/,
      maxVertical = 52,
      preferRightHalf = false
    } = {}) => {
      const labels = visibleTextElements(pattern)
        .map((el) => ({ el, rect: el.getBoundingClientRect(), text: compact(el.innerText || el.textContent) }))
        .filter((item) => item.rect.width > 0 && item.rect.height > 0)
        .sort((a, b) => a.rect.top - b.rect.top || a.rect.left - b.rect.left);
      const inputs = allInputs().filter((input) => !scope || scope.contains(input));
      let best = null;
      for (const label of labels) {
        const labelCenterY = (label.rect.top + label.rect.bottom) / 2;
        for (const input of inputs) {
          const rect = input.getBoundingClientRect();
          const inputCenterY = (rect.top + rect.bottom) / 2;
          const vertical = Math.abs(inputCenterY - labelCenterY);
          const overlapsVertically = rect.top <= label.rect.bottom + 12 && rect.bottom >= label.rect.top - 12;
          if (vertical > maxVertical && !overlapsVertically) continue;
          const inputText = compact(`${containerText(input)} ${nearbyInputText(input)}`);
          if (avoid.test(inputText) && !pattern.test(inputText)) continue;
          const rightGap = Math.max(0, rect.left - label.rect.right);
          const leftGap = Math.max(0, label.rect.left - rect.right);
          const nearHorizontal = Math.min(rightGap, leftGap);
          if (nearHorizontal > 520 && !overlapsVertically) continue;
          const sameRowBonus = overlapsVertically ? 120 : 0;
          const rightSideBonus = rect.left >= label.rect.right - 24 ? 80 : 0;
          const leftSideBonus = rect.right <= label.rect.left + 24 ? 65 : 0;
          const rightHalfBonus = preferRightHalf && rect.left > window.innerWidth * 0.45 ? 70 : 0;
          const score = sameRowBonus + rightSideBonus + leftSideBonus + rightHalfBonus - vertical * 4 - nearHorizontal;
          if (!best || score > best.score) best = { input, score };
        }
      }
      return best?.input || null;
    };
    const waitFor = async (fn, timeoutMs = 8000, intervalMs = 180) => {
      const deadline = Date.now() + timeoutMs;
      let lastValue = null;
      while (Date.now() <= deadline) {
        lastValue = fn();
        if (lastValue) return lastValue;
        await sleep(intervalMs);
      }
      return lastValue;
    };
    await waitFor(() => {
      const text = compact(document.body?.innerText || document.body?.textContent || "");
      return text && /任务备注|快捷分组|群聊|机器人/.test(text) && allInputs().length ? true : null;
    }, 8000, 200);
    const findPanel = (type) => {
      const headingPattern = type === "group"
        ? /^(群|快捷分组)\s*[（(]|^快捷分组$/
        : /^机器人\s*[（(]/;
      const heading = Array.from(document.querySelectorAll("h1,h2,h3,h4,label,span,strong,div"))
        .filter((el) => visible(el) && headingPattern.test(compact(el.innerText || el.textContent)))
        .map((el) => {
          const r = el.getBoundingClientRect();
          return { el, top: r.top, left: r.left };
        })
        .sort((a, b) => a.top - b.top || a.left - b.left)[0]?.el;
      const ancestorCandidates = heading ? [heading] : [];
      if (heading) {
        let node = heading.parentElement;
        while (node && node !== document.body) {
          ancestorCandidates.push(node);
          node = node.parentElement;
        }
      }
      const scoped = ancestorCandidates
        .filter((el) => visible(el) && el.querySelector("input,.el-checkbox,[role='checkbox']"))
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = compact(el.innerText || el.textContent);
          return { el, area: r.width * r.height, textLength: text.length };
        })
        .filter((item) => item.area > 8000 && item.area < window.innerWidth * window.innerHeight * 0.65 && item.textLength < 5000)
        .sort((a, b) => a.area - b.area)[0]?.el;
      if (scoped) return scoped;
      const pattern = type === "group" ? /群\s*[（(]?\s*已选|群聊|快捷分组/ : /机器人\s*[（(]?\s*已选/;
      const candidates = Array.from(document.querySelectorAll("section,main,aside,div"))
        .filter((el) => visible(el) && pattern.test(compact(el.innerText || el.textContent)) && el.querySelector("input,.el-checkbox,[role='checkbox']"))
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = compact(el.innerText || el.textContent);
          const preferredSide = type === "group" ? r.left : -r.left;
          return { el, area: r.width * r.height, preferredSide, textLength: text.length };
        })
        .filter((item) => item.area > 10000 && item.textLength < 5000)
        .sort((a, b) => a.area - b.area || a.preferredSide - b.preferredSide);
      return candidates[0]?.el || document.body;
    };
    const parsePanelTotal = (type) => {
      const panel = findPanel(type);
      const headingPattern = type === "group"
        ? /(?:^|[\s（(])群(?:聊)?\s*[（(]|群\s*[（(]?\s*已选/
        : /机器人\s*[（(]/;
      const headingTexts = visibleTextElements(headingPattern)
        .map((el) => compact(el.innerText || el.textContent))
        .filter((text) => text.length <= 120);
      const text = compact([...headingTexts, panel?.innerText || panel?.textContent || ""].join(" "));
      const numbers = [];
      for (const match of text.matchAll(/已选\s*\d+\s*[/／]\s*(\d{1,7})/g)) numbers.push(Number(match[1]));
      const typePattern = type === "group"
        ? /(?:^|[\s（(])群(?:聊)?[^\d]{0,16}(\d{1,7})/g
        : /机器人[^\d]{0,16}(\d{1,7})/g;
      for (const match of text.matchAll(typePattern)) numbers.push(Number(match[1]));
      const valid = numbers.filter((value) => Number.isFinite(value) && value >= 0);
      return valid.length ? Math.max(...valid) : null;
    };
    const hasRealCmsRefreshControl = () => visibleTextElements(/刷新全部机器人群数据|检测群内机器人|管理屏蔽群/).length > 0;
    const hasIncompleteDataText = () => /暂无机器人|暂无数据|未查询到数据|当前分组下暂无机器人/.test(compact(document.body?.innerText || document.body?.textContent || ""));
    const readDataCompleteness = () => {
      const groupTotal = parsePanelTotal("group");
      const robotTotal = parsePanelTotal("robot");
      const incompleteReasons = [];
      if (groupTotal !== null && groupTotal > 0 && groupTotal < 1000) incompleteReasons.push(`群数量只有 ${groupTotal}`);
      if (payload.role === "douma" && robotTotal !== null && robotTotal < 100) incompleteReasons.push(`机器人数量只有 ${robotTotal}`);
      if (hasIncompleteDataText()) incompleteReasons.push("页面显示暂无数据或暂无机器人");
      return { groupTotal, robotTotal, incompleteReasons };
    };
    const clickCmsRefresh = async () => {
      const exact = visibleTextElements(/刷新全部机器人群数据/)[0];
      if (exact) {
        exact.click?.();
        await sleep(2600);
        return true;
      }
      const refreshes = visibleTextElements(/^刷新$/);
      for (const item of refreshes.slice(0, 2)) item.click?.();
      if (refreshes.length) {
        await sleep(2600);
        return true;
      }
      return false;
    };
    const ensurePageDataReady = async () => {
      if (!hasRealCmsRefreshControl()) return true;
      for (let attempt = 0; attempt < 3; attempt += 1) {
        const status = readDataCompleteness();
        if (!status.incompleteReasons.length) return true;
        if (attempt >= 2) {
          errors.push(`页面数据未加载完整：${status.incompleteReasons.join("，")}。请刷新云中客页面或人工设置后继续。`);
          return false;
        }
        actions.push(`${payload.role === "douma" ? "豆妈" : "托"}页面数据未加载完整，已尝试刷新第 ${attempt + 1} 次`);
        const clicked = await clickCmsRefresh();
        if (!clicked) {
          errors.push(`页面数据未加载完整：${status.incompleteReasons.join("，")}，且未找到刷新按钮。请刷新云中客页面或人工设置后继续。`);
          return false;
        }
        await waitFor(() => {
          const next = readDataCompleteness();
          return next.incompleteReasons.length ? null : true;
        }, 7000, 400);
      }
      return true;
    };
    const clickIfUnchecked = (marker) => {
      if (!marker) return false;
      const checked = marker.matches?.("input[type='checkbox']") ? marker.checked :
        marker.getAttribute?.("aria-checked") === "true" ||
        /\bis-checked\b/.test(String(marker.className || marker.closest?.(".el-checkbox,.el-checkbox__input")?.className || ""));
      if (!checked) {
        (marker.closest?.("label,.el-checkbox") || marker).click?.();
        return true;
      }
      return false;
    };
    const rowItems = (panel) => Array.from(panel.querySelectorAll("tr,.el-table__row,li,[class*='row']"))
      .filter((row) => visible(row) && !row.closest?.("thead") && compact(row.innerText || row.textContent))
      .map((row) => ({
        row,
        text: compact(row.innerText || row.textContent),
        marker: row.querySelector("input[type='checkbox'],.el-checkbox__input,[role='checkbox']")
      }))
      .filter((item) => item.marker && !/^(全选|ID|快捷分组|备注|排序|机器人|群聊|更多设置)$/.test(item.text));
    const findSendSettingsPanel = () => {
      const heading = Array.from(document.querySelectorAll("h1,h2,h3,h4,label,span,strong,div"))
        .filter((el) => visible(el) && /执行发送设置/.test(compact(el.innerText || el.textContent)))
        .map((el) => {
          const r = el.getBoundingClientRect();
          return { el, top: r.top, left: r.left };
        })
        .sort((a, b) => a.top - b.top || b.left - a.left)[0]?.el;
      const candidates = [];
      if (heading) {
        let node = heading;
        while (node && node !== document.body) {
          candidates.push(node);
          node = node.parentElement;
        }
      }
      return candidates
        .filter((el) => visible(el) && /任务备注/.test(compact(el.innerText || el.textContent)) && el.querySelector("input,textarea,[contenteditable='true']"))
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = compact(el.innerText || el.textContent);
          return { el, area: r.width * r.height, textLength: text.length, left: r.left };
        })
        .filter((item) => item.area > 12000 && item.area < window.innerWidth * window.innerHeight * 0.75 && item.textLength < 5000)
        .sort((a, b) => a.area - b.area || b.left - a.left)[0]?.el || null;
    };
    const findTaskRemarkInput = () => {
      const sendPanel = findSendSettingsPanel();
      const byLabel = findNearestInputByText(/^任务备注$/, {
        scope: sendPanel,
        avoid: /关键词|分组|任意时间点|发送间隔|单群随机人数|执行后清空|发送模式|群顺序|消息模式/,
        maxVertical: 64,
        preferRightHalf: true
      }) || findNearestInputByText(/^任务备注$/, {
        avoid: /关键词|分组|任意时间点|发送间隔|单群随机人数|执行后清空|发送模式|群顺序|消息模式/,
        maxVertical: 64,
        preferRightHalf: true
      });
      if (byLabel) return byLabel;
      const candidateInputs = allInputs().filter((input) => sendPanel ? sendPanel.contains(input) : true);
      return candidateInputs
      .map((input) => {
        const text = containerText(input);
        const nearbyText = nearbyInputText(input);
        const rect = input.getBoundingClientRect();
        const score = (sendPanel && sendPanel.contains(input) ? 90 : 0) +
          (/任务备注/.test(nearbyText) ? 130 : /任务备注/.test(text) ? 90 : 0) +
          (rect.left > window.innerWidth * 0.45 ? 20 : 0) -
          (/关键词|分组|任意时间点|发送间隔|单群随机人数/.test(nearbyText) ? 55 : 0);
        return { input, score, text };
      })
      .filter((item) => item.score >= 120)
      .sort((a, b) => b.score - a.score)[0]?.input || null;
    };
    const setTaskRemark = async (value) => {
      if (!value) return true;
      const target = await waitFor(findTaskRemarkInput, 7000, 180);
      if (!target) {
        errors.push(`任务备注输入框未找到，未能填写“${value}”。`);
        return false;
      }
      setValue(target, value);
      actions.push(`任务备注=${value}`);
      return true;
    };
    const setSwitchNearLabel = (label, wanted) => {
      const labels = Array.from(document.querySelectorAll("label,span,div"))
        .filter((el) => visible(el) && compact(el.innerText || el.textContent) === label);
      const switches = Array.from(document.querySelectorAll(".el-switch,[role='switch'],input[type='checkbox']"))
        .filter((item) => visible(item) || visible(item.closest?.(".el-switch,label,div")));
      for (const labelEl of labels) {
        const labelRect = labelEl.getBoundingClientRect();
        const found = switches
          .map((item) => {
            const rect = item.getBoundingClientRect?.() || item.closest?.(".el-switch,label,div")?.getBoundingClientRect?.();
            if (!rect) return null;
            const vertical = Math.abs((rect.top + rect.bottom) / 2 - (labelRect.top + labelRect.bottom) / 2);
            const horizontal = rect.left - labelRect.right;
            if (vertical > 28 || horizontal < -20) return null;
            return { item, score: vertical * 10 + Math.abs(horizontal) };
          })
          .filter(Boolean)
          .sort((a, b) => a.score - b.score)[0]?.item;
        if (!found) continue;
        const checked = found.matches?.("input[type='checkbox']") ? found.checked :
          found.getAttribute?.("aria-checked") === "true" ||
          /\bis-checked\b/.test(String(found.className || found.closest?.(".el-switch")?.className || ""));
        if (checked !== wanted) (found.closest?.(".el-switch,label") || found).click?.();
        actions.push(`${label}=${wanted ? "开" : "关"}`);
        return true;
      }
      errors.push(`没有找到“${label}”开关。`);
      return false;
    };
    const groupLabelPattern = (config, type) => {
      if (config.mode === "keyword") return /关键词|关键词搜索/;
      const label = compact(config.label);
      if (/管理分组/.test(label)) return /管理分组|请选择分组|选择分组|包含分组|默认分组/;
      if (type === "robot") return /机器人分组|默认分组|请选择分组|选择分组/;
      return /群分组|群包含分组|包含分组|默认分组|请选择分组|选择分组/;
    };
    const findGroupingInput = (panel, type) => {
      const wanted = type === "group"
        ? /包含分组|群分组|默认分组|请选择分组|管理分组|选择分组/
        : /机器人分组|默认分组|请选择分组|选择分组/;
      const avoid = /关键词|关键词搜索|任务备注|发送间隔|单群随机人数|任意时间点/;
      const inputs = allInputs()
        .map((input) => {
          const text = containerText(input);
          const nearbyText = nearbyInputText(input);
          const rect = input.getBoundingClientRect();
          const inPanel = panel && panel.contains(input);
          const score = (inPanel ? 80 : 0) +
            (wanted.test(nearbyText) ? 90 : wanted.test(text) ? 30 : 0) -
            (avoid.test(nearbyText) ? 100 : 0) -
            (type === "group" && rect.left > window.innerWidth * 0.55 ? 25 : 0) -
            (type === "robot" && rect.left < window.innerWidth * 0.2 ? 15 : 0);
          return { input, score, top: rect.top, left: rect.left };
        })
        .filter((item) => item.score >= 80)
        .sort((a, b) => b.score - a.score || a.top - b.top || a.left - b.left);
      return inputs[0]?.input || null;
    };
    const clearGroupingFilter = async (panel, type) => {
      const input = findGroupingInput(panel, type);
      if (!input) {
        actions.push(`${type === "group" ? "群" : "机器人"}分组筛选未找到，跳过清空`);
        return true;
      }
      clearValue(input);
      await sleep(300);
      actions.push(`${type === "group" ? "群" : "机器人"}分组筛选已清空`);
      return true;
    };
    const findManagementGroupInput = () => {
      const direct = findNearestInputByText(/^管理分组$/, {
        avoid: /使用角色|请选择角色|关键词|任务备注|发送间隔|任意时间点|单群随机人数/,
        maxVertical: 42
      });
      if (direct) return direct;
      return findNearestInputByText(/管理分组/, {
        avoid: /使用角色|请选择角色|关键词|任务备注|发送间隔|任意时间点|单群随机人数/,
        maxVertical: 56
      });
    };
    const findSearchInput = (panel, type, config) => {
      if (/管理分组/.test(compact(config?.label || ""))) {
        const managementInput = findManagementGroupInput();
        if (managementInput) return managementInput;
      }
      const wanted = groupLabelPattern(config, type);
      const avoid = /任务备注|任意时间点|发送间隔|单群随机人数|执行后清空|发送模式|群顺序|消息模式/;
      const inputs = allInputs()
        .map((input) => {
          const text = containerText(input);
          const nearbyText = nearbyInputText(input);
          const rect = input.getBoundingClientRect();
          const inPanel = panel && panel.contains(input);
          const score = (inPanel ? 80 : 0) +
            (wanted.test(nearbyText) ? 90 : wanted.test(text) ? 30 : 0) +
            (/搜索|请选择|分组|关键词/.test(nearbyText) ? 8 : 0) -
            (avoid.test(nearbyText) ? 95 : 0) -
            (type === "group" && rect.left > window.innerWidth * 0.55 ? 25 : 0) -
            (type === "robot" && rect.left < window.innerWidth * 0.2 ? 15 : 0);
          return { input, score, text, left: rect.left, top: rect.top };
        })
        .filter((item) => item.score >= 70)
        .sort((a, b) => b.score - a.score || a.top - b.top || a.left - b.left);
      return inputs[0]?.input || null;
    };
    const selectableRows = (panel, type, config) => {
      const rows = rowItems(panel);
      if (!rows.length) return [];
      const target = compact(config.value).replace(/\s+/g, "");
      const matchedRows = config.mode === "keyword"
        ? rows
        : rows.filter((item) => compact(item.text).replace(/\s+/g, "").includes(target));
      const sourceRows = matchedRows.length ? matchedRows : rows;
      const limit = config.count === "all" ? sourceRows.length : Math.max(1, Number(config.count || 1) || 1);
      return sourceRows.slice(0, limit);
    };
    const markerChecked = (marker) => {
      if (!marker) return false;
      return marker.matches?.("input[type='checkbox']") ? marker.checked :
        marker.getAttribute?.("aria-checked") === "true" ||
        /\bis-checked\b/.test(String(marker.className || marker.closest?.(".el-checkbox,.el-checkbox__input")?.className || ""));
    };
    const findHeaderCheckbox = (panel) => {
      const markers = Array.from(panel.querySelectorAll("thead input[type='checkbox'],thead .el-checkbox__input,thead [role='checkbox'],tr:first-child input[type='checkbox'],tr:first-child .el-checkbox__input,tr:first-child [role='checkbox']"))
        .filter((marker) => visible(marker) || visible(marker.closest?.("label,.el-checkbox,th,td")));
      return markers[0] || null;
    };
    const setSearchValue = async (type, config) => {
      if (!config?.value) return true;
      const found = await waitFor(() => {
        const panel = findPanel(type);
        const input = findSearchInput(panel, type, config);
        return input ? { panel, input } : null;
      }, 9000, 220);
      if (!found) {
        errors.push(`${config.label || (type === "group" ? "群输入内容" : "机器人输入内容")}输入框未找到，未能填写“${config.value}”。`);
        return false;
      }
      if (config.mode === "keyword") await clearGroupingFilter(found.panel, type);
      found.input.click?.();
      setValue(found.input, config.value);
      await sleep(500);
      actions.push(`${config.label || (type === "group" ? "群" : "机器人")}=${config.value}`);
      const selected = await selectRows(type, config);
      if (!selected) return false;
      return true;
    };
    const selectRows = async (type, config) => {
      const selection = await waitFor(() => {
        const panel = findPanel(type);
        const rows = selectableRows(panel, type, config);
        return rows.length ? { panel, rows } : null;
      }, 6000, 220);
      const finalRows = selection?.rows || [];
      if (!finalRows?.length) {
        errors.push(`${config.label || (type === "group" ? "群输入内容" : "机器人输入内容")}未找到可选行：“${config.value}”。`);
        return false;
      }
      if (config.count === "all") {
        const header = findHeaderCheckbox(selection.panel);
        if (header && !finalRows.every((item) => markerChecked(item.marker))) {
          (header.closest?.("label,.el-checkbox,th,td") || header).click?.();
          await waitFor(() => finalRows.every((item) => markerChecked(item.marker)) ? true : null, 1500, 120);
        }
      }
      for (let attempt = 0; attempt < 3; attempt += 1) {
        const missed = finalRows.filter((item) => !markerChecked(item.marker));
        if (!missed.length) break;
        for (const item of missed) clickIfUnchecked(item.marker);
        await waitFor(() => finalRows.every((item) => markerChecked(item.marker)) ? true : null, 900, 120);
      }
      const missedRows = finalRows.filter((item) => !markerChecked(item.marker));
      if (missedRows.length) {
        errors.push(`${config.label || (type === "group" ? "群输入内容" : "机器人输入内容")}有 ${missedRows.length} 行未勾选成功。`);
        return false;
      }
      actions.push(`${type === "group" ? "群" : "机器人"}已选择${finalRows.length}行`);
      return true;
    };
    const setRobotSwitchMode = (label) => {
      if (!label) return true;
      const candidates = Array.from(document.querySelectorAll("button,span,div,input"))
        .filter((el) => visible(el) && elementText(el).includes(label));
      const target = candidates[0];
      if (target) {
        target.click?.();
        actions.push(`机器人更换方式=${label}`);
        return true;
      }
      errors.push(`机器人更换方式“${label}”未找到，请人工确认。`);
      return false;
    };
    if (!(await ensurePageDataReady())) return { ok: false, errors, actions };
    if (payload.steps.includes("multiQuickMode")) setSwitchNearLabel("多快捷模式", true);
    if (payload.steps.includes("group")) await setSearchValue("group", payload.group);
    if (payload.steps.includes("robot")) await setSearchValue("robot", payload.robot);
    if (payload.steps.includes("robotSwitchMode")) setRobotSwitchMode(payload.robotSwitchModeLabel);
    if (payload.steps.includes("taskRemark")) await setTaskRemark(payload.taskRemark);
    return { ok: errors.length === 0, errors, actions };
  }, payload);
}

function roleLabel(role) {
  return role === "douma" ? "豆妈" : "托";
}

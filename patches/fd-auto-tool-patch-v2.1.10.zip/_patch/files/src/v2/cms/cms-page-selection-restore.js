import { normalizeCmsPageSelection } from "./cms-page-selection-snapshot.js";

export function restoreCmsPageSelectionToRoles(roles = {}, pageSelection = {}) {
  const restored = {};
  for (const role of ["tuo", "douma"]) {
    if (!roles[role]) continue;
    const selection = normalizeCmsPageSelection(pageSelection[role] || roles[role].selection || {});
    restored[role] = {
      ...roles[role],
      selection,
      pageSelection: selection
    };
  }
  return restored;
}

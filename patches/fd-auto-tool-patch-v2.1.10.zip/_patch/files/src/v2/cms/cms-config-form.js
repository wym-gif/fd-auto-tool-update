const TUO_MODES = new Set(["rough", "precise"]);
const ROBOT_SWITCH_MODES = new Set(["random", "sequence", "group_sequence", "preset_sequence"]);
const SEARCH_MODES = new Set(["group", "keyword"]);

export function normalizeCmsConfigForm(form = {}) {
  const tuoMode = TUO_MODES.has(form.tuo?.mode) ? form.tuo.mode : "rough";
  const rough = form.tuo?.rough || {};
  const precise = form.tuo?.precise || {};
  const douma = form.douma || {};
  return {
    version: 1,
    tuo: {
      mode: tuoMode,
      rough: {
        multiQuickMode: true,
        managementGroup: cleanText(rough.managementGroup),
        robotSwitchMode: ROBOT_SWITCH_MODES.has(rough.robotSwitchMode) ? rough.robotSwitchMode : "random",
        groupSelectCount: normalizeCount(rough.groupSelectCount, "all"),
        taskRemark: cleanText(rough.taskRemark)
      },
      precise: {
        groupFilter: cleanText(precise.groupFilter),
        groupSelectCount: normalizeCount(precise.groupSelectCount, "all"),
        robotGroup: cleanText(precise.robotGroup),
        taskRemark: cleanText(precise.taskRemark)
      }
    },
    douma: {
      groupSearchMode: SEARCH_MODES.has(douma.groupSearchMode) ? douma.groupSearchMode : "group",
      groupValue: cleanText(douma.groupValue),
      groupSelectCount: normalizeCount(douma.groupSelectCount, "all"),
      robotSearchMode: SEARCH_MODES.has(douma.robotSearchMode) ? douma.robotSearchMode : "group",
      robotValue: cleanText(douma.robotValue),
      robotSelectCount: normalizeCount(douma.robotSelectCount, "1"),
      taskRemark: cleanText(douma.taskRemark)
    }
  };
}

export function validateCmsConfigForm(form = {}) {
  const normalized = normalizeCmsConfigForm(form);
  const errors = [];
  if (normalized.tuo.mode === "rough") {
    if (!normalized.tuo.rough.managementGroup) errors.push("请填写粗略托页面的管理分组。");
    if (!normalized.tuo.rough.taskRemark) errors.push("请填写粗略托页面的任务备注。");
  } else {
    if (!normalized.tuo.precise.groupFilter) errors.push("请填写精准托页面的群包含分组。");
    if (!normalized.tuo.precise.robotGroup) errors.push("请填写精准托页面的机器人分组。");
    if (!normalized.tuo.precise.taskRemark) errors.push("请填写精准托页面的任务备注。");
  }
  if (!normalized.douma.groupValue) {
    errors.push(normalized.douma.groupSearchMode === "group" ? "请填写豆妈页面的群包含分组。" : "请填写豆妈页面的群关键词。");
  }
  if (!normalized.douma.robotValue) {
    errors.push(normalized.douma.robotSearchMode === "group" ? "请填写豆妈页面的机器人分组。" : "请填写豆妈页面的机器人关键词。");
  }
  if (!normalized.douma.taskRemark) errors.push("请填写豆妈页面的任务备注。");
  return { ok: errors.length === 0, errors, form: normalized };
}

export function summarizeCmsConfigForm(form = {}) {
  const normalized = normalizeCmsConfigForm(form);
  const tuo = normalized.tuo.mode === "precise"
    ? {
        role: "tuo",
        label: "托页面",
        mode: "precise",
        modeLabel: "精准托",
        group: normalized.tuo.precise.groupFilter,
        robot: normalized.tuo.precise.robotGroup,
        taskRemark: normalized.tuo.precise.taskRemark,
        fields: [
          ["版本", "精准托"],
          ["群包含分组", normalized.tuo.precise.groupFilter],
          ["群聊选择", formatCount(normalized.tuo.precise.groupSelectCount)],
          ["机器人分组", normalized.tuo.precise.robotGroup],
          ["任务备注", normalized.tuo.precise.taskRemark]
        ]
      }
    : {
        role: "tuo",
        label: "托页面",
        mode: "rough",
        modeLabel: "粗略托",
        group: normalized.tuo.rough.managementGroup,
        robot: robotSwitchModeLabel(normalized.tuo.rough.robotSwitchMode),
        taskRemark: normalized.tuo.rough.taskRemark,
        multiQuickMode: true,
        fields: [
          ["版本", "粗略托"],
          ["多快捷模式", "开"],
          ["管理分组", normalized.tuo.rough.managementGroup],
          ["机器人更换方式", robotSwitchModeLabel(normalized.tuo.rough.robotSwitchMode)],
          ["群聊选择", formatCount(normalized.tuo.rough.groupSelectCount)],
          ["任务备注", normalized.tuo.rough.taskRemark]
        ]
      };
  const douma = {
    role: "douma",
    label: "豆妈页面",
    group: normalized.douma.groupValue,
    robot: normalized.douma.robotValue,
    taskRemark: normalized.douma.taskRemark,
    fields: [
      ["群查找", normalized.douma.groupSearchMode === "group" ? "使用包含分组" : "使用关键词"],
      [normalized.douma.groupSearchMode === "group" ? "群包含分组" : "群关键词", normalized.douma.groupValue],
      ["群聊选择", formatCount(normalized.douma.groupSelectCount)],
      ["机器人查找", normalized.douma.robotSearchMode === "group" ? "使用机器人分组" : "使用关键词"],
      [normalized.douma.robotSearchMode === "group" ? "机器人分组" : "机器人关键词", normalized.douma.robotValue],
      ["机器人选择", formatCount(normalized.douma.robotSelectCount)],
      ["任务备注", normalized.douma.taskRemark]
    ]
  };
  return {
    source: "manual-form",
    roleCount: 2,
    roles: [tuo, douma]
  };
}

export function createCmsConfigFormSnapshot({ name = "", settings = {}, form = {}, sourceRunId = "" } = {}) {
  const validation = validateCmsConfigForm(form);
  if (!validation.ok) throw new Error(validation.errors.join(" "));
  return {
    version: 2,
    name: cleanText(name),
    createdAt: new Date().toISOString(),
    sourceRunId: cleanText(sourceRunId),
    settings: settings && typeof settings === "object" ? { ...settings } : {},
    bindings: { roles: {}, pages: [], source: "manual-form" },
    configForm: validation.form,
    summary: summarizeCmsConfigForm(validation.form)
  };
}

export function robotSwitchModeLabel(value = "") {
  return {
    random: "随机更换机器人",
    sequence: "顺序更换机器人",
    group_sequence: "分组内顺序发送",
    preset_sequence: "预设顺序发送"
  }[value] || "随机更换机器人";
}

function normalizeCount(value, fallback) {
  const text = cleanText(value || fallback);
  if (!text || text === "all" || text === "全选") return "all";
  const number = Number.parseInt(text, 10);
  return Number.isFinite(number) && number > 0 ? String(number) : fallback;
}

function formatCount(value) {
  return value === "all" ? "全选" : `${value} 个`;
}

function cleanText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

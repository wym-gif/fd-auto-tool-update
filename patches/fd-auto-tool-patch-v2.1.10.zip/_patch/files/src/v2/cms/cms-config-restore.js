import fs from "node:fs/promises";
import path from "node:path";
import { restoreCmsPageSelectionToRoles } from "./cms-page-selection-restore.js";

const BINDINGS_FILE = "cms-page-bindings.json";

export async function restoreCmsConfigForRun({ runDir, item } = {}) {
  if (!runDir) throw new Error("没有当前 run 目录，无法恢复云中客配置。");
  const config = item?.config || item || {};
  const roles = config.bindings?.roles || {};
  if (!Object.keys(roles).length && !config.configForm) throw new Error("这份云中客配置没有可恢复的页面绑定。");
  const restoredSelectionRoles = restoreCmsPageSelectionToRoles(roles, config.pageSelection || {});
  const runId = runIdFromRunDir(runDir);
  const now = new Date().toISOString();
  const restoredRoles = {};
  const pages = [];
  let index = 1;
  for (const role of ["tuo", "douma"]) {
    if (!restoredSelectionRoles[role]) continue;
    const sourceRole = restoredSelectionRoles[role];
    const page = {
      ...sourceRole,
      role,
      index: Number.isFinite(Number(sourceRole.index)) ? Number(sourceRole.index) : index,
      pageId: `${runId}:${role}`,
      runId,
      bindingSource: "cms-config-restore",
      restoredAt: now
    };
    restoredRoles[role] = page;
    pages.push(page);
    index += 1;
  }
  const payload = {
    runId,
    runDir,
    source: "cms-config-restore",
    restoredFromConfigId: item?.id || config.id || "",
    restoredFromConfigName: item?.name || config.name || "",
    createdAt: now,
    pages,
    roles: restoredRoles,
    pageSelection: config.pageSelection || {},
    configForm: config.configForm || null,
    manualSetupRequired: Boolean(config.configForm && !Object.keys(restoredRoles).length)
  };
  await fs.mkdir(runDir, { recursive: true });
  await fs.writeFile(path.join(runDir, BINDINGS_FILE), JSON.stringify(payload, null, 2), "utf8");
  return {
    ok: true,
    runId,
    roleCount: Object.keys(restoredRoles).length,
    configName: payload.restoredFromConfigName,
    summary: config.summary || {},
    configForm: payload.configForm,
    manualSetupRequired: payload.manualSetupRequired
  };
}

function runIdFromRunDir(runDir = "") {
  return path.basename(String(runDir || "").replace(/[\\/]+$/, ""));
}

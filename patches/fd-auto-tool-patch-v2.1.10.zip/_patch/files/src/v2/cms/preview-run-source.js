import fs from "node:fs/promises";
import path from "node:path";
import { finalPreviewPath } from "../preview/preview-store.js";

export async function findLatestPreviewJsonRun(runsRoot, options = {}) {
  const prefixes = options.prefixes || ["v2_real_flow_", "v2_flow_"];
  for (const prefix of prefixes) {
    const runDir = await findLatestPreviewJsonRunByPrefix(runsRoot, prefix);
    if (runDir) return runDir;
  }
  return null;
}

async function findLatestPreviewJsonRunByPrefix(runsRoot, prefix) {
  const entries = await fs.readdir(runsRoot, { withFileTypes: true }).catch(() => []);
  const candidates = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || !entry.name.startsWith(prefix)) continue;
    const runDir = path.join(runsRoot, entry.name);
    try {
      const stat = await fs.stat(finalPreviewPath(runDir));
      candidates.push({ runDir, mtimeMs: stat.mtimeMs });
    } catch {
      continue;
    }
  }
  candidates.sort((a, b) => b.mtimeMs - a.mtimeMs || b.runDir.localeCompare(a.runDir));
  return candidates[0]?.runDir || null;
}

export function missingPreviewJsonMessage() {
  return [
    "没有找到已保存的预览内容。",
    "请先运行真实采集范围解析，再打开 2.0 真实预览页并保存预览内容。",
    "预期位置类似：runs\\v2_real_flow_xxx\\preview.json"
  ].join("\n");
}

export function buildCmsPageSelectionSnapshot(roles = {}) {
  const selections = {};
  for (const role of ["tuo", "douma"]) {
    const selection = roles[role]?.selection || {};
    selections[role] = normalizeCmsPageSelection(selection);
  }
  return selections;
}

export function normalizeCmsPageSelection(selection = {}) {
  const selectedCounts = Array.isArray(selection.selectedCounts)
    ? selection.selectedCounts.map((item) => String(item || "").trim()).filter(Boolean)
    : [];
  return {
    group: String(selection.group || "").trim(),
    robot: String(selection.robot || "").trim(),
    taskRemark: String(selection.taskRemark || "").trim(),
    selectedCounts,
    multiQuickMode: typeof selection.multiQuickMode === "boolean" ? selection.multiQuickMode : null
  };
}

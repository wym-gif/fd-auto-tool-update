#!/usr/bin/env python3
import argparse
import base64
import datetime as dt
import hashlib
import hmac
import html
import ipaddress
import json
import os
import re
import secrets
import shutil
import socket
import tempfile
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ACTIONS = {"launch", "generate-preview", "prepare-cms", "start-cms", "cli-start-cms"}
REQUEST_ACTION = "request-access"
HEARTBEAT_ACTION = "heartbeat"
USAGE_REPORT_ACTION = "usage-report"
SUPPORT_REPORT_ACTION = "support-report"
SHARED_LIBRARY_ACTIONS = {
    "shared-library-list",
    "shared-library-upload",
    "shared-library-upload-status",
    "shared-library-upload-chunk",
    "shared-library-upload-complete",
    "shared-library-download",
    "shared-library-delete",
}
DEFAULT_SHARED_GROUPS = ["开群组", "老群组", "合集组"]
LIMITS = {"companyId": 64, "deviceId": 128, "appVersion": 32, "action": 32}
MAX_BODY = 4096
MAX_SHARED_BODY = 250 * 1024 * 1024
MAX_SHARED_UPLOAD_CHUNK_CHARS = 8 * 1024 * 1024
MAX_SHARED_UPLOAD_CHUNKS = 96
INTERNAL_NETS = [ipaddress.ip_network("10.0.0.0/8")]
REPORT_TZ = dt.timezone(dt.timedelta(hours=8))
DEFAULT_LATEST_CLIENT_VERSION = "2.1.6"
SUPPORT_STATUSES = {"pending", "handled", "ignored"}
ADMIN_SESSION_COOKIE = "mq_admin"
ADMIN_SESSION_TTL_SECONDS = 12 * 60 * 60
PASSWORD_HASH_ITERATIONS = 180000
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")


def now_iso():
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def result(allowed, code, message):
    return {"allowed": allowed, "code": code, "message": message}


def parse_iso(value):
    try:
        parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt.timezone.utc)
    except (ValueError, TypeError):
        return None


def nonnegative_int_value(value, limit=1000000):
    try:
        parsed = int(float(value or 0))
    except (TypeError, ValueError):
        parsed = 0
    return max(0, min(limit, parsed))


def clean_device_group(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()[:40]


def version_parts(value):
    parts = []
    for item in str(value or "").lstrip("v").split("."):
        try:
            parts.append(int("".join(ch for ch in item if ch.isdigit()) or "0"))
        except ValueError:
            parts.append(0)
    return parts[:4]


def compare_versions(left, right):
    a = version_parts(left)
    b = version_parts(right)
    size = max(len(a), len(b), 1)
    a += [0] * (size - len(a))
    b += [0] * (size - len(b))
    return (a > b) - (a < b)


def load_json(path, fallback):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return fallback


def atomic_write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def atomic_write_json_compact(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def device_ref(device_id):
    return hashlib.sha256(str(device_id).encode()).hexdigest()[:12]


def read_policy(server):
    if server.policy_path.stat().st_size > 65536:
        raise RuntimeError("policy too large")
    return json.loads(server.policy_path.read_text(encoding="utf-8"))


def write_policy(server, policy):
    backup = server.policy_path.with_name(f"policy.json.bak-{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}")
    try:
        backup.write_text(server.policy_path.read_text(encoding="utf-8"), encoding="utf-8")
    except FileNotFoundError:
        pass
    atomic_write_json(server.policy_path, policy)


def check(payload, policy, now=None):
    if not isinstance(payload, dict) or set(payload) != set(LIMITS):
        return 400, result(False, "INVALID_REQUEST", "授权请求格式错误。")
    if any(not isinstance(payload[k], str) or not payload[k].strip() or len(payload[k]) > size for k, size in LIMITS.items()):
        return 400, result(False, "INVALID_REQUEST", "授权请求格式错误。")
    if payload["action"] not in ACTIONS:
        return 400, result(False, "INVALID_ACTION", "该操作不在授权范围内。")
    if not isinstance(policy, dict) or policy.get("enabled") is not True or payload["companyId"] != policy.get("companyId"):
        return 403, result(False, "COMPANY_DENIED", "公司授权未配置。")
    device = policy.get("devices", {}).get(payload["deviceId"])
    if not isinstance(device, dict) or device.get("enabled") is not True:
        return 403, result(False, "DEVICE_DENIED", "设备未授权，请点击申请授权。")
    if payload["appVersion"] in policy.get("blockedVersions", []):
        return 403, result(False, "VERSION_BLOCKED", "当前版本已停用，请更新后再使用。")
    if payload["action"] not in device.get("actions", []):
        return 403, result(False, "ACTION_DENIED", "该设备未授权执行此操作。")
    expiry = device.get("expiresAt")
    if expiry is not None:
        try:
            end = dt.datetime.fromisoformat(expiry.replace("Z", "+00:00"))
            if end.tzinfo is None:
                raise ValueError("timezone required")
            expired = end <= (now or dt.datetime.now(dt.timezone.utc))
        except (ValueError, TypeError, AttributeError):
            return 403, result(False, "EXPIRY_INVALID", "授权有效期配置错误，请联系管理员。")
        if expired:
            return 403, result(False, "EXPIRED", "设备授权已过期。")
    response = result(True, "ALLOWED", "授权通过。")
    response["company"] = str(policy.get("company", ""))[:64]
    return 200, response


def validate_request_payload(payload, policy):
    if not isinstance(payload, dict):
        return "授权申请格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action"}
    if not required.issubset(set(payload)) or payload.get("action") != REQUEST_ACTION:
        return "授权申请格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        if key == "action":
            continue
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "授权申请格式错误。"
    computer = payload.get("computerName", "")
    if computer is not None and (not isinstance(computer, str) or len(computer) > 80):
        return "电脑名称格式错误。"
    return ""


def record_request(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_request_payload(payload, policy)
    if reason:
        return 400, {"allowed": False, "code": "INVALID_REQUEST", "message": reason}
    device_id = payload["deviceId"]
    device = policy.get("devices", {}).get(device_id)
    if isinstance(device, dict) and device.get("enabled") is True:
        return 200, {"allowed": True, "code": "ALREADY_ALLOWED", "message": "这台电脑已授权。"}
    requests = load_json(server.requests_path, {"requests": {}})
    items = requests.setdefault("requests", {})
    previous = items.get(device_id, {}) if isinstance(items.get(device_id), dict) else {}
    ts = now_iso()
    items[device_id] = {
        "deviceId": device_id,
        "deviceRef": device_ref(device_id),
        "computerName": str(payload.get("computerName") or "")[:80],
        "appVersion": str(payload.get("appVersion") or "")[:32],
        "sourceIp": source_ip,
        "status": "pending",
        "requestedAt": previous.get("requestedAt") or ts,
        "updatedAt": ts,
    }
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "request", "deviceRef": device_ref(device_id), "computerName": items[device_id]["computerName"], "sourceIp": source_ip})
    return 200, {"allowed": False, "code": "REQUEST_RECORDED", "message": "授权申请已提交，请等待管理员审批。"}


def validate_heartbeat_payload(payload, policy):
    if not isinstance(payload, dict):
        return "心跳格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action"}
    if not required.issubset(set(payload)) or payload.get("action") != HEARTBEAT_ACTION:
        return "心跳格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "心跳格式错误。"
    computer = payload.get("computerName", "")
    if computer is not None and (not isinstance(computer, str) or len(computer) > 80):
        return "电脑名称格式错误。"
    update = payload.get("update", {})
    if update is not None and not isinstance(update, dict):
        return "更新状态格式错误。"
    monitor = payload.get("monitor", {})
    if monitor is not None and not isinstance(monitor, dict):
        return "监控状态格式错误。"
    diagnostic = payload.get("diagnostic", {})
    if diagnostic is not None and not isinstance(diagnostic, dict):
        return "诊断状态格式错误。"
    return ""


def clean_device_diagnostic(payload, source_ip, recorded_at):
    diagnostic = payload.get("diagnostic") if isinstance(payload.get("diagnostic"), dict) else {}

    def text(key, limit=160):
        return str(diagnostic.get(key) or "").replace("\r", " ").replace("\n", " ")[:limit]

    def list_text(key, max_items, max_chars):
        value = diagnostic.get(key)
        if not isinstance(value, list):
            return []
        return [str(item or "").replace("\r", " ").replace("\n", " ")[:max_chars] for item in value[-max_items:] if str(item or "").strip()]

    message = text("message", 300)
    if not message:
        return None
    return {
        "recordedAt": text("recordedAt", 40) or recorded_at,
        "receivedAt": recorded_at,
        "sourceIp": source_ip,
        "stage": text("stage", 80),
        "category": text("category", 40),
        "message": message,
        "lastAction": text("lastAction", 120),
        "runId": text("runId", 96),
        "previewName": text("previewName", 120),
        "suggestions": list_text("suggestions", 8, 180),
        "logs": list_text("logs", 20, 220),
        "userNote": text("userNote", 300),
    }


def record_heartbeat(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_heartbeat_payload(payload, policy)
    if reason:
        return 400, {"allowed": False, "code": "INVALID_HEARTBEAT", "message": reason}
    device_id = payload["deviceId"]
    device = policy.get("devices", {}).get(device_id)
    authorized = isinstance(device, dict) and device.get("enabled") is True
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {
        "deviceId": device_id,
        "deviceRef": device_ref(device_id),
        "requestedAt": now_iso(),
        "status": "approved" if authorized else "pending",
    })
    update = payload.get("update") if isinstance(payload.get("update"), dict) else {}
    ts = now_iso()
    item["deviceId"] = device_id
    item["deviceRef"] = device_ref(device_id)
    item["computerName"] = str(payload.get("computerName") or item.get("computerName") or "")[:80]
    item["appVersion"] = str(payload.get("appVersion") or "")[:32]
    item["sourceIp"] = source_ip
    item["lastHeartbeatAt"] = ts
    item["lastSeenAt"] = ts
    item["updatedAt"] = ts
    item["status"] = "approved" if authorized else item.get("status") or "pending"
    item["updateStatus"] = {
        "currentVersion": str(update.get("currentVersion") or payload.get("appVersion") or "")[:32],
        "latestVersion": str(update.get("latestVersion") or "")[:32],
        "updateAvailable": update.get("updateAvailable") is True,
        "pendingUpdateReady": update.get("pendingUpdateReady") is True,
        "updateMode": str(update.get("updateMode") or "")[:16],
        "status": str(update.get("status") or "")[:32],
    }
    monitor = payload.get("monitor") if isinstance(payload.get("monitor"), dict) else {}
    item["monitorStatus"] = {
        "status": str(monitor.get("status") or "")[:24],
        "step": str(monitor.get("step") or "")[:80],
        "waitingReason": str(monitor.get("waitingReason") or "")[:180],
        "runId": str(monitor.get("runId") or "")[:96],
        "currentIndex": nonnegative_int_value(monitor.get("currentIndex"), 1000000),
        "totalCount": nonnegative_int_value(monitor.get("totalCount"), 1000000),
        "successCount": nonnegative_int_value(monitor.get("successCount"), 1000000),
        "failureCount": nonnegative_int_value(monitor.get("failureCount"), 1000000),
        "updatedAt": str(monitor.get("updatedAt") or "")[:40],
        "reportedAt": ts,
    }
    diagnostic = clean_device_diagnostic(payload, source_ip, ts)
    if diagnostic:
        item["lastDiagnostic"] = diagnostic
    atomic_write_json(server.requests_path, requests)
    append_heartbeat_event(server, item, monitor, source_ip, ts)
    return 200 if authorized else 403, {
        "allowed": authorized,
        "code": "HEARTBEAT_RECORDED" if authorized else "DEVICE_DENIED",
        "message": "心跳已记录。" if authorized else "设备未授权，请点击申请授权。"
    }


def append_heartbeat_event(server, item, monitor, source_ip, recorded_at):
    path = getattr(server, "heartbeat_events_path", None)
    if not path:
        return
    store = load_json(path, {"events": []})
    events = store.get("events", [])
    if not isinstance(events, list):
        events = []
    events.append({
        "recordedAt": recorded_at,
        "deviceId": item.get("deviceId", ""),
        "deviceRef": item.get("deviceRef", ""),
        "computerName": item.get("computerName", ""),
        "appVersion": item.get("appVersion", ""),
        "sourceIp": source_ip,
        "deviceGroup": clean_device_group(item.get("deviceGroup", "")),
        "status": str(monitor.get("status") or "")[:24] if isinstance(monitor, dict) else "",
        "step": str(monitor.get("step") or "")[:80] if isinstance(monitor, dict) else "",
    })
    store["events"] = events[-200000:]
    atomic_write_json(path, store)


def validate_usage_report_payload(payload, policy):
    if not isinstance(payload, dict):
        return "使用记录格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action", "usage"}
    if not required.issubset(set(payload)) or payload.get("action") != USAGE_REPORT_ACTION:
        return "使用记录格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "使用记录格式错误。"
    computer = payload.get("computerName", "")
    if computer is not None and (not isinstance(computer, str) or len(computer) > 80):
        return "电脑名称格式错误。"
    usage = payload.get("usage")
    if not isinstance(usage, dict):
        return "使用记录格式错误。"
    if usage.get("event") not in {"start", "finish"}:
        return "使用记录事件错误。"
    if usage.get("status") not in {"running", "completed", "failed", "stopped"}:
        return "使用记录状态错误。"
    if len(str(usage.get("runId") or "")) > 96:
        return "使用记录 runId 过长。"
    return ""


def clean_usage_report(payload, source_ip):
    usage = payload.get("usage") if isinstance(payload.get("usage"), dict) else {}
    def text(key, limit=80):
        return str(usage.get(key) or "")[:limit]
    def nonnegative_int(key, limit=1000000):
        try:
            value = int(float(usage.get(key) or 0))
        except (TypeError, ValueError):
            value = 0
        return max(0, min(limit, value))
    ts = now_iso()
    return {
        "id": f"{int(time.time() * 1000)}-{secrets.token_hex(3)}",
        "recordedAt": ts,
        "companyId": str(payload.get("companyId") or "")[:64],
        "deviceId": payload["deviceId"],
        "deviceRef": device_ref(payload["deviceId"]),
        "computerName": str(payload.get("computerName") or "")[:80],
        "appVersion": str(payload.get("appVersion") or "")[:32],
        "sourceIp": source_ip,
        "event": text("event", 16),
        "source": text("source", 32),
        "runId": text("runId", 96),
        "status": text("status", 16),
        "startedAt": text("startedAt", 40),
        "finishedAt": text("finishedAt", 40),
        "durationMs": nonnegative_int("durationMs", 7 * 24 * 60 * 60 * 1000),
        "plannedCount": nonnegative_int("plannedCount"),
        "successCount": nonnegative_int("successCount"),
        "failureCount": nonnegative_int("failureCount"),
        "stopped": usage.get("stopped") is True,
        "stage": text("stage", 80),
        "reason": text("reason", 240),
        "action": text("action", 80),
        "taskIndex": nonnegative_int("taskIndex"),
        "totalCount": nonnegative_int("totalCount"),
        "taskRole": text("taskRole", 24),
        "taskType": text("taskType", 24),
        "taskDate": text("taskDate", 24),
        "taskTime": text("taskTime", 24),
    }


def record_usage_report(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_usage_report_payload(payload, policy)
    if reason:
        return 400, {"allowed": False, "code": "INVALID_USAGE", "message": reason}
    device_id = payload["deviceId"]
    device = policy.get("devices", {}).get(device_id)
    authorized = isinstance(device, dict) and device.get("enabled") is True
    if not authorized:
        return 403, {"allowed": False, "code": "DEVICE_DENIED", "message": "设备未授权，请点击申请授权。"}
    store = load_json(server.usage_events_path, {"events": []})
    events = store.get("events", [])
    if not isinstance(events, list):
        events = []
    event = clean_usage_report(payload, source_ip)
    events.append(event)
    store["events"] = events[-50000:]
    atomic_write_json(server.usage_events_path, store)
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {
        "deviceId": device_id,
        "deviceRef": device_ref(device_id),
        "requestedAt": now_iso(),
        "status": "approved",
    })
    item["computerName"] = event["computerName"] or item.get("computerName", "")
    item["appVersion"] = event["appVersion"]
    item["sourceIp"] = source_ip
    item["lastUsageAt"] = event["recordedAt"]
    item["updatedAt"] = event["recordedAt"]
    item["status"] = "approved"
    atomic_write_json(server.requests_path, requests)
    return 200, {"allowed": True, "code": "USAGE_RECORDED", "message": "使用记录已记录。"}


def validate_support_report_payload(payload, policy):
    if not isinstance(payload, dict):
        return "问题上报格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action", "support"}
    if not required.issubset(set(payload)) or payload.get("action") != SUPPORT_REPORT_ACTION:
        return "问题上报格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "问题上报格式错误。"
    computer = payload.get("computerName", "")
    if computer is not None and (not isinstance(computer, str) or len(computer) > 80):
        return "电脑名称格式错误。"
    if not isinstance(payload.get("support"), dict):
        return "问题上报内容格式错误。"
    return ""


def clean_support_report(payload, source_ip):
    support = payload.get("support") if isinstance(payload.get("support"), dict) else {}
    def text(key, limit=160):
        return str(support.get(key) or "")[:limit]
    suggestions = support.get("suggestions")
    if not isinstance(suggestions, list):
        suggestions = []
    logs = support.get("logs")
    if not isinstance(logs, list):
        logs = []
    ts = now_iso()
    return {
        "id": f"{int(time.time() * 1000)}-{secrets.token_hex(3)}",
        "status": "pending",
        "reportedAt": ts,
        "updatedAt": ts,
        "companyId": str(payload.get("companyId") or "")[:64],
        "deviceId": payload["deviceId"],
        "deviceRef": device_ref(payload["deviceId"]),
        "computerName": str(payload.get("computerName") or "")[:80],
        "appVersion": str(payload.get("appVersion") or "")[:32],
        "sourceIp": source_ip,
        "stage": text("stage", 80),
        "category": text("category", 40),
        "message": text("message", 300),
        "lastAction": text("lastAction", 120),
        "runId": text("runId", 96),
        "previewName": text("previewName", 120),
        "suggestions": [str(item or "")[:180] for item in suggestions[:8]],
        "logs": [str(item or "")[:260] for item in logs[-30:]],
        "userNote": text("userNote", 300),
    }


def record_support_report(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_support_report_payload(payload, policy)
    if reason:
        return 400, {"allowed": False, "code": "INVALID_SUPPORT_REPORT", "message": reason}
    device_id = payload["deviceId"]
    device = policy.get("devices", {}).get(device_id)
    authorized = isinstance(device, dict) and device.get("enabled") is True
    if not authorized:
        return 403, {"allowed": False, "code": "DEVICE_DENIED", "message": "设备未授权，不能上报问题。"}
    store = load_json(server.support_reports_path, {"reports": []})
    reports = store.get("reports", [])
    if not isinstance(reports, list):
        reports = []
    report = clean_support_report(payload, source_ip)
    reports.append(report)
    store["reports"] = reports[-5000:]
    atomic_write_json(server.support_reports_path, store)
    append_audit(server, {"event": "support-report", "reportId": report["id"], "deviceRef": device_ref(device_id), "sourceIp": source_ip})
    return 200, {"allowed": True, "code": "SUPPORT_RECORDED", "message": "问题已上报给管理员。", "reportId": report["id"]}


def support_reports(server):
    store = load_json(server.support_reports_path, {"reports": []})
    reports = store.get("reports", [])
    if not isinstance(reports, list):
        return []
    return sorted(reports, key=lambda item: str(item.get("reportedAt") or ""), reverse=True)


def update_support_report_status(server, report_id, status, admin="web"):
    if not isinstance(report_id, str) or not report_id.strip() or len(report_id) > 80:
        return False, "问题编号格式错误。"
    if status not in SUPPORT_STATUSES:
        return False, "问题状态格式错误。"
    store = load_json(server.support_reports_path, {"reports": []})
    reports = store.get("reports", [])
    if not isinstance(reports, list):
        reports = []
    for item in reports:
        if isinstance(item, dict) and item.get("id") == report_id:
            item["status"] = status
            item["updatedAt"] = now_iso()
            item["handledBy"] = admin
            atomic_write_json(server.support_reports_path, {"reports": reports})
            append_audit(server, {"event": "support-report-status", "reportId": report_id, "status": status, "admin": admin})
            return True, "异常协助状态已更新。"
    return False, "没有找到这条异常协助记录。"


def validate_shared_payload(payload, policy):
    if not isinstance(payload, dict):
        return "共享文案请求格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action"}
    if not required.issubset(set(payload)) or payload.get("action") not in SHARED_LIBRARY_ACTIONS:
        return "共享文案请求格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "共享文案请求格式错误。"
    return ""


def shared_device(policy, device_id):
    device = policy.get("devices", {}).get(device_id)
    return device if isinstance(device, dict) and device.get("enabled") is True else None


def can_upload_shared_library(policy, device_id, device):
    shared = policy.get("sharedLibrary", {})
    if isinstance(shared, dict):
        upload_ids = shared.get("uploadDeviceIds", [])
        if isinstance(upload_ids, list) and device_id in upload_ids:
            return True
        if shared.get("allowAllUploads") is True:
            return True
    return device.get("sharedLibraryUpload") is True or "shared-library-upload" in device.get("actions", [])


def shared_library_root(server):
    root = getattr(server, "shared_library_root", None) or server.policy_path.with_name("shared-preview-library")
    root.mkdir(parents=True, exist_ok=True)
    return root


def shared_library_index_path(server):
    return shared_library_root(server) / "index.json"


def shared_uploads_root(server):
    root = getattr(server, "shared_uploads_root", None) or server.policy_path.with_name("shared-preview-upload-chunks")
    root.mkdir(parents=True, exist_ok=True)
    return root


def load_shared_library_index(server):
    data = load_json(shared_library_index_path(server), {"items": []})
    items = data.get("items", [])
    return {"items": items if isinstance(items, list) else []}


def write_shared_library_index(server, index):
    atomic_write_json(shared_library_index_path(server), {"items": index.get("items", [])})


def safe_cloud_id(value):
    text = str(value or "").strip()
    return text if re.match(r"^[A-Za-z0-9_.-]{1,80}$", text) else ""


def safe_shared_upload_id(value):
    text = str(value or "").strip()
    return text if re.match(r"^[A-Za-z0-9_.-]{8,96}$", text) else ""


def clean_shared_name(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()[:80] or "未命名文案"


def clean_shared_group(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()[:40]


def shared_package_hash(package):
    return hashlib.sha256(json.dumps(shared_package_identity(package), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def shared_package_identity(package):
    if not isinstance(package, dict):
        package = {}
    tasks = package.get("tasks", [])
    raw_events = package.get("rawEvents", [])
    media_files = package.get("mediaFiles", [])
    return {
        "schemaVersion": int(package.get("schemaVersion") or 1),
        "name": str(package.get("name") or ""),
        "groupName": clean_shared_group(package.get("groupName", "")),
        "taskCount": int(package.get("taskCount") or (len(tasks) if isinstance(tasks, list) else 0) or 0),
        "tasks": tasks if isinstance(tasks, list) else [],
        "rawEvents": raw_events if isinstance(raw_events, list) else [],
        "mediaFiles": media_files if isinstance(media_files, list) else [],
    }


def shared_library_groups(server):
    index = load_shared_library_index(server)
    groups = []
    for name in DEFAULT_SHARED_GROUPS:
        if name not in groups:
            groups.append(name)
    for item in index["items"]:
        name = clean_shared_group(item.get("groupName", ""))
        if name and name not in groups:
            groups.append(name)
    return groups


def shared_library_list(server):
    index = load_shared_library_index(server)
    items = sorted(index["items"], key=lambda item: str(item.get("updatedAt") or item.get("uploadedAt") or ""), reverse=True)
    return [{
        "cloudId": item.get("cloudId", ""),
        "name": item.get("name", ""),
        "groupName": clean_shared_group(item.get("groupName", "")),
        "taskCount": item.get("taskCount", 0),
        "cloudVersion": item.get("cloudVersion", 0),
        "updatedAt": item.get("updatedAt", ""),
        "uploadedAt": item.get("uploadedAt", ""),
        "packageHash": item.get("packageHash", ""),
        "packageBytes": item.get("packageBytes", 0),
        "uploadedByDeviceRef": item.get("uploadedByDeviceRef", ""),
        "sourceIp": item.get("sourceIp", "")
    } for item in items]


def shared_item_dir(server, cloud_id):
    root = shared_library_root(server)
    item_dir = root / cloud_id
    resolved = item_dir.resolve()
    if not str(resolved).startswith(str(root.resolve()) + os.sep):
        raise ValueError("bad path")
    return item_dir


def shared_upload_dir(server, upload_id):
    root = shared_uploads_root(server)
    item_dir = root / upload_id
    resolved = item_dir.resolve()
    if not str(resolved).startswith(str(root.resolve()) + os.sep):
        raise ValueError("bad upload path")
    return item_dir


def validate_shared_upload_permission(server, payload):
    policy = read_policy(server)
    reason = validate_shared_payload(payload, policy)
    if reason:
        return None, None, 400, {"ok": False, "message": reason}
    device_id = payload["deviceId"]
    device = shared_device(policy, device_id)
    if not device:
        return None, None, 403, {"ok": False, "message": "设备未授权，不能使用共享文案。"}
    if not can_upload_shared_library(policy, device_id, device):
        return None, None, 403, {"ok": False, "message": "本设备没有上传共享文案权限。"}
    return policy, device, 0, None


def receive_shared_library_upload_chunk(server, payload, source_ip):
    _, _, status, body = validate_shared_upload_permission(server, payload)
    if status:
        return status, body
    upload_id = safe_shared_upload_id(payload.get("uploadId"))
    if not upload_id:
        return 400, {"ok": False, "message": "共享文案分片标识无效。"}
    try:
        chunk_index = int(payload.get("chunkIndex"))
        chunk_count = int(payload.get("chunkCount"))
    except (TypeError, ValueError):
        return 400, {"ok": False, "message": "共享文案分片序号无效。"}
    if chunk_count <= 0 or chunk_count > MAX_SHARED_UPLOAD_CHUNKS or chunk_index < 0 or chunk_index >= chunk_count:
        return 400, {"ok": False, "message": "共享文案分片数量无效。"}
    content = payload.get("content")
    if not isinstance(content, str) or not content or len(content) > MAX_SHARED_UPLOAD_CHUNK_CHARS:
        return 413, {"ok": False, "message": "共享文案分片太大，请升级客户端或改用“导出共享包”。"}
    if not re.match(r"^[A-Za-z0-9+/=]+$", content):
        return 400, {"ok": False, "message": "共享文案分片内容无效。"}
    try:
        raw_chunk = base64.b64decode(content.encode("ascii"), validate=True)
    except Exception:
        return 400, {"ok": False, "message": "共享文案分片内容无效。"}
    if len(raw_chunk) > MAX_SHARED_BODY:
        return 413, {"ok": False, "message": "共享文案分片太大，请升级客户端或改用“导出共享包”。"}
    item_dir = shared_upload_dir(server, upload_id)
    item_dir.mkdir(parents=True, exist_ok=True)
    meta = {
        "uploadId": upload_id,
        "chunkCount": chunk_count,
        "deviceRef": device_ref(payload["deviceId"]),
        "sourceIp": source_ip,
        "groupName": clean_shared_group(payload.get("groupName", "")),
        "packageHash": str(payload.get("packageHash") or "")[:96],
        "rawHash": str(payload.get("rawHash") or "")[:96],
        "storage": "raw",
        "updatedAt": now_iso(),
    }
    atomic_write_json(item_dir / "meta.json", meta)
    (item_dir / f"chunk-{chunk_index:04d}.bin").write_bytes(raw_chunk)
    try:
        (item_dir / f"chunk-{chunk_index:04d}.txt").unlink()
    except FileNotFoundError:
        pass
    return 200, {"ok": True, "uploadId": upload_id, "chunkIndex": chunk_index, "chunkCount": chunk_count}


def shared_library_upload_status(server, payload, source_ip):
    _, _, status, body = validate_shared_upload_permission(server, payload)
    if status:
        return status, body
    upload_id = safe_shared_upload_id(payload.get("uploadId"))
    if not upload_id:
        return 400, {"ok": False, "message": "共享文案分片标识无效。"}
    try:
        chunk_count = int(payload.get("chunkCount"))
    except (TypeError, ValueError):
        return 400, {"ok": False, "message": "共享文案分片数量无效。"}
    if chunk_count <= 0 or chunk_count > MAX_SHARED_UPLOAD_CHUNKS:
        return 400, {"ok": False, "message": "共享文案分片数量无效。"}
    package_hash = str(payload.get("packageHash") or "")
    if package_hash and not re.match(r"^[a-fA-F0-9]{64}$", package_hash):
        return 400, {"ok": False, "message": "共享文案包校验值无效。"}
    if package_hash:
        index = load_shared_library_index(server)
        same_hash = next((item for item in index["items"] if item.get("packageHash") == package_hash), None)
        if same_hash:
            return 200, {
                "ok": True,
                "uploadId": upload_id,
                "chunkCount": chunk_count,
                "existingChunks": [],
                "existingCount": 0,
                "item": same_hash,
                "message": "云端已有相同文案，已按上传成功处理。"
            }
    item_dir = shared_upload_dir(server, upload_id)
    existing_chunks = []
    if item_dir.exists():
        meta = load_json(item_dir / "meta.json", {})
        meta_hash = str(meta.get("packageHash") or "")
        if not package_hash or not meta_hash or meta_hash == package_hash:
            for index in range(chunk_count):
                if (item_dir / f"chunk-{index:04d}.bin").exists() or (item_dir / f"chunk-{index:04d}.txt").exists():
                    existing_chunks.append(index)
    return 200, {
        "ok": True,
        "uploadId": upload_id,
        "chunkCount": chunk_count,
        "existingChunks": existing_chunks,
        "existingCount": len(existing_chunks)
    }


def complete_shared_library_upload(server, payload, source_ip):
    _, _, status, body = validate_shared_upload_permission(server, payload)
    if status:
        return status, body
    upload_id = safe_shared_upload_id(payload.get("uploadId"))
    if not upload_id:
        return 400, {"ok": False, "message": "共享文案分片标识无效。"}
    try:
        chunk_count = int(payload.get("chunkCount"))
    except (TypeError, ValueError):
        return 400, {"ok": False, "message": "共享文案分片数量无效。"}
    if chunk_count <= 0 or chunk_count > MAX_SHARED_UPLOAD_CHUNKS:
        return 400, {"ok": False, "message": "共享文案分片数量无效。"}
    item_dir = shared_upload_dir(server, upload_id)
    if not item_dir.exists():
        return 404, {"ok": False, "message": "共享文案分片不存在或已过期，请重新上传。"}
    chunks = []
    hasher = hashlib.sha256()
    total_bytes = 0
    for index in range(chunk_count):
        raw_path = item_dir / f"chunk-{index:04d}.bin"
        legacy_path = item_dir / f"chunk-{index:04d}.txt"
        if raw_path.exists():
            raw_chunk = raw_path.read_bytes()
        elif legacy_path.exists():
            try:
                raw_chunk = base64.b64decode(legacy_path.read_text(encoding="ascii").encode("ascii"), validate=True)
            except Exception:
                return 400, {"ok": False, "message": "共享文案分片合并失败，请重新上传。"}
        else:
            return 400, {"ok": False, "message": f"共享文案分片缺失：{index + 1}/{chunk_count}。请重新上传。"}
        total_bytes += len(raw_chunk)
        if total_bytes > MAX_SHARED_BODY:
            return 413, {"ok": False, "message": "共享文案包太大，超过服务器限制。请改用“导出共享包”手动发送。"}
        hasher.update(raw_chunk)
        chunks.append(raw_chunk)
    raw = b"".join(chunks)
    if total_bytes > MAX_SHARED_BODY:
        return 413, {"ok": False, "message": "共享文案包太大，超过服务器限制。请改用“导出共享包”手动发送。"}
    expected_hash = str(payload.get("rawHash") or payload.get("packageHash") or "")
    actual_hash = hasher.hexdigest()
    if expected_hash and expected_hash != actual_hash:
        return 400, {"ok": False, "message": "共享文案分片校验失败，请重新上传。"}
    try:
        package = json.loads(raw.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError):
        return 400, {"ok": False, "message": "共享文案包格式错误。"}
    status, body = upload_shared_library(server, {
        **payload,
        "action": "shared-library-upload",
        "groupName": payload.get("groupName", ""),
        "library": package,
        "_packageBytes": total_bytes,
    }, source_ip)
    if status == 200:
        shutil.rmtree(item_dir, ignore_errors=True)
        append_audit(server, {"event": "shared-library-upload-complete", "uploadId": upload_id, "deviceRef": device_ref(payload["deviceId"]), "sourceIp": source_ip})
    return status, body


def upload_shared_library(server, payload, source_ip):
    _, _, status, body = validate_shared_upload_permission(server, payload)
    if status:
        return status, body
    device_id = payload["deviceId"]
    package = payload.get("library")
    if not isinstance(package, dict) or int(package.get("schemaVersion") or 0) != 1:
        return 400, {"ok": False, "message": "共享文案包格式错误。"}
    if not isinstance(package.get("mediaFiles", []), list):
        return 400, {"ok": False, "message": "共享文案素材格式错误。"}
    try:
        package_bytes = int(payload.get("_packageBytes") or 0)
    except (TypeError, ValueError):
        package_bytes = 0
    if package_bytes <= 0:
        package_json = json.dumps(package, ensure_ascii=False, separators=(",", ":"))
        package_bytes = len(package_json.encode("utf-8"))
    if package_bytes > MAX_SHARED_BODY:
        return 413, {"ok": False, "message": "共享文案包太大，超过服务器限制。请改用“导出共享包”手动发送。"}
    package_hash = str(payload.get("packageHash") or package.get("packageHash") or "")
    if not re.match(r"^[a-fA-F0-9]{64}$", package_hash):
        package_hash = shared_package_hash(package)
    cloud_id = safe_cloud_id(package.get("cloudId")) or f"shared_{int(time.time() * 1000)}_{secrets.token_hex(4)}"
    index = load_shared_library_index(server)
    existing = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    if existing and existing.get("packageHash") == package_hash:
        append_audit(server, {"event": "shared-library-upload-dedup", "cloudId": cloud_id, "deviceRef": device_ref(device_id), "sourceIp": source_ip})
        return 200, {"ok": True, "item": existing, "message": "云端已有相同文案，已按上传成功处理。"}
    if not existing:
        same_hash = next((item for item in index["items"] if item.get("packageHash") == package_hash), None)
        if same_hash:
            append_audit(server, {"event": "shared-library-upload-dedup", "cloudId": same_hash.get("cloudId", ""), "deviceRef": device_ref(device_id), "sourceIp": source_ip})
            return 200, {"ok": True, "item": same_hash, "message": "云端已有相同文案，已按上传成功处理。"}
    ts = now_iso()
    group_name = clean_shared_group(payload.get("groupName") or package.get("groupName") or (existing or {}).get("groupName", ""))
    if group_name:
        package["groupName"] = group_name
    item = {
        "cloudId": cloud_id,
        "name": clean_shared_name(package.get("name")),
        "groupName": group_name,
        "taskCount": max(0, min(100000, int(package.get("taskCount") or 0))),
        "cloudVersion": int((existing or {}).get("cloudVersion") or 0) + 1,
        "updatedAt": str(package.get("updatedAt") or ts)[:40],
        "uploadedAt": ts,
        "uploadedByDeviceRef": device_ref(device_id),
        "packageHash": package_hash,
        "packageBytes": package_bytes,
        "sourceIp": source_ip,
    }
    item_dir = shared_item_dir(server, cloud_id)
    item_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json_compact(item_dir / "package.json", package)
    index["items"] = [item] + [old for old in index["items"] if old.get("cloudId") != cloud_id]
    write_shared_library_index(server, index)
    append_audit(server, {"event": "shared-library-upload", "cloudId": cloud_id, "deviceRef": device_ref(device_id), "sourceIp": source_ip})
    return 200, {"ok": True, "item": item, "message": "共享文案已上传。"}


def download_shared_library(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_shared_payload(payload, policy)
    if reason:
        return 400, {"ok": False, "message": reason}
    device_id = payload["deviceId"]
    if not shared_device(policy, device_id):
        return 403, {"ok": False, "message": "设备未授权，不能使用共享文案。"}
    cloud_id = safe_cloud_id(payload.get("cloudId"))
    if not cloud_id:
        return 400, {"ok": False, "message": "没有指定云端文案。"}
    index = load_shared_library_index(server)
    item = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    if not item:
        return 404, {"ok": False, "message": "云端文案不存在。"}
    package = load_json(shared_item_dir(server, cloud_id) / "package.json", None)
    if not isinstance(package, dict):
        return 404, {"ok": False, "message": "云端文案包缺失。"}
    append_audit(server, {"event": "shared-library-download", "cloudId": cloud_id, "deviceRef": device_ref(device_id), "sourceIp": source_ip})
    return 200, {"ok": True, "item": item, "package": package}


def delete_shared_library(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_shared_payload(payload, policy)
    if reason:
        return 400, {"ok": False, "message": reason}
    device_id = payload["deviceId"]
    if not shared_device(policy, device_id):
        return 403, {"ok": False, "message": "设备未授权，不能管理共享文案。"}
    cloud_id = safe_cloud_id(payload.get("cloudId"))
    if not cloud_id:
        return 400, {"ok": False, "message": "没有指定云端文案。"}
    index = load_shared_library_index(server)
    item = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    if not item:
        return 404, {"ok": False, "message": "云端文案不存在或已经删除。"}
    index["items"] = [old for old in index["items"] if old.get("cloudId") != cloud_id]
    write_shared_library_index(server, index)
    shutil.rmtree(shared_item_dir(server, cloud_id), ignore_errors=True)
    append_audit(server, {"event": "shared-library-delete", "cloudId": cloud_id, "deviceRef": device_ref(device_id), "sourceIp": source_ip})
    return 200, {"ok": True, "deleted": item, "message": "云端文案已删除。"}


def handle_shared_library_action(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_shared_payload(payload, policy)
    if reason:
        return 400, {"ok": False, "message": reason}
    if not shared_device(policy, payload["deviceId"]):
        return 403, {"ok": False, "message": "设备未授权，不能使用共享文案。"}
    if payload["action"] == "shared-library-list":
        return 200, {"ok": True, "items": shared_library_list(server), "groups": shared_library_groups(server)}
    if payload["action"] == "shared-library-upload":
        return upload_shared_library(server, payload, source_ip)
    if payload["action"] == "shared-library-upload-status":
        return shared_library_upload_status(server, payload, source_ip)
    if payload["action"] == "shared-library-upload-chunk":
        return receive_shared_library_upload_chunk(server, payload, source_ip)
    if payload["action"] == "shared-library-upload-complete":
        return complete_shared_library_upload(server, payload, source_ip)
    if payload["action"] == "shared-library-download":
        return download_shared_library(server, payload, source_ip)
    if payload["action"] == "shared-library-delete":
        return delete_shared_library(server, payload, source_ip)
    return 400, {"ok": False, "message": "共享文案操作不支持。"}


def admin_delete_shared_library(server, cloud_id, admin="web"):
    cloud_id = safe_cloud_id(cloud_id)
    if not cloud_id:
        return False, "没有指定云端文案。"
    index = load_shared_library_index(server)
    item = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    if not item:
        return False, "云端文案不存在或已经删除。"
    index["items"] = [old for old in index["items"] if old.get("cloudId") != cloud_id]
    write_shared_library_index(server, index)
    shutil.rmtree(shared_item_dir(server, cloud_id), ignore_errors=True)
    append_audit(server, {"event": "admin-shared-library-delete", "cloudId": cloud_id, "admin": admin})
    return True, "云端文案已删除。"


def admin_update_shared_library_group(server, cloud_id, group_name, admin="web"):
    cloud_id = safe_cloud_id(cloud_id)
    if not cloud_id:
        return False, "没有指定云端文案。"
    group_name = clean_shared_group(group_name)
    index = load_shared_library_index(server)
    item = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    if not item:
        return False, "云端文案不存在或已经删除。"
    item["groupName"] = group_name
    package_path = shared_item_dir(server, cloud_id) / "package.json"
    package = load_json(package_path, None)
    if isinstance(package, dict):
        package["groupName"] = group_name
        atomic_write_json(package_path, package)
    write_shared_library_index(server, index)
    append_audit(server, {"event": "admin-shared-library-group", "cloudId": cloud_id, "groupName": group_name, "admin": admin})
    return True, "云端文案分组已更新。"


def append_audit(server, event):
    event = {"time": now_iso(), **event}
    with server.audit_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")


def b64url(data):
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(value):
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def hash_admin_password(password, salt=None):
    password = str(password or "")
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_HASH_ITERATIONS)
    return f"pbkdf2_sha256${PASSWORD_HASH_ITERATIONS}${b64url(salt)}${b64url(digest)}"


def verify_admin_password(password, encoded):
    parts = str(encoded or "").split("$")
    if len(parts) != 4 or parts[0] != "pbkdf2_sha256":
        return False
    try:
        iterations = int(parts[1])
        salt = b64url_decode(parts[2])
        expected = b64url_decode(parts[3])
    except (ValueError, TypeError):
        return False
    digest = hashlib.pbkdf2_hmac("sha256", str(password or "").encode("utf-8"), salt, iterations)
    return secrets.compare_digest(digest, expected)


def valid_admin_username(username):
    return bool(USERNAME_RE.fullmatch(str(username or "")))


def load_admin_users(server):
    users = load_json(server.admin_users_path, {"users": {}})
    return users if isinstance(users, dict) and isinstance(users.get("users"), dict) else {"users": {}}


def write_admin_users(server, users):
    atomic_write_json(server.admin_users_path, users)
    try:
        os.chmod(server.admin_users_path, 0o640)
    except OSError:
        pass


def admin_public_user(username, user):
    return {
        "username": username,
        "displayName": str(user.get("displayName") or "")[:80],
        "role": "owner" if user.get("role") == "owner" else "manager",
        "enabled": user.get("enabled") is True,
        "createdAt": user.get("createdAt", ""),
        "updatedAt": user.get("updatedAt", ""),
        "lastLoginAt": user.get("lastLoginAt", ""),
        "lastLoginIp": user.get("lastLoginIp", ""),
        "lastLoginAgent": str(user.get("lastLoginAgent") or "")[:160],
    }


def list_admin_users(server):
    users = load_admin_users(server).get("users", {})
    items = [admin_public_user(name, user) for name, user in users.items() if isinstance(user, dict)]
    return sorted(items, key=lambda item: (item["role"] != "owner", item["username"]))


def admin_user_by_name(server, username):
    users = load_admin_users(server).get("users", {})
    user = users.get(str(username or ""))
    return user if isinstance(user, dict) else None


def set_admin_user(server, username, password="", display_name="", role="manager", enabled=True, actor="system"):
    username = str(username or "").strip()
    if not valid_admin_username(username):
        return False, "账号只能使用 3-32 位英文、数字、点、横线或下划线。"
    if password is not None and password != "" and len(str(password)) < 8:
        return False, "密码至少 8 位。"
    users = load_admin_users(server)
    item = users.setdefault("users", {}).setdefault(username, {})
    now = now_iso()
    item.setdefault("createdAt", now)
    item["displayName"] = str(display_name or item.get("displayName") or username)[:80]
    item["role"] = "owner" if role == "owner" else "manager"
    item["enabled"] = enabled is True
    item["updatedAt"] = now
    item["updatedBy"] = actor
    if password:
        item["passwordHash"] = hash_admin_password(password)
        item["passwordChangedAt"] = now
    write_admin_users(server, users)
    append_audit(server, {"event": "admin-user-set", "username": username, "role": item["role"], "enabled": item["enabled"], "admin": actor})
    return True, "管理员账号已保存。"


def update_admin_user_enabled(server, username, enabled, actor="system"):
    users = load_admin_users(server)
    item = users.get("users", {}).get(str(username or ""))
    if not isinstance(item, dict):
        return False, "管理员账号不存在。"
    if item.get("role") == "owner" and enabled is False:
        owners = [user for user in users.get("users", {}).values() if isinstance(user, dict) and user.get("role") == "owner" and user.get("enabled") is True]
        if len(owners) <= 1:
            return False, "至少保留一个启用的总管理员账号。"
    item["enabled"] = enabled is True
    item["updatedAt"] = now_iso()
    item["updatedBy"] = actor
    write_admin_users(server, users)
    append_audit(server, {"event": "admin-user-enabled", "username": username, "enabled": item["enabled"], "admin": actor})
    return True, "管理员账号状态已更新。"


def reset_admin_password(server, username, password, actor="system"):
    if len(str(password or "")) < 8:
        return False, "密码至少 8 位。"
    users = load_admin_users(server)
    item = users.get("users", {}).get(str(username or ""))
    if not isinstance(item, dict):
        return False, "管理员账号不存在。"
    item["passwordHash"] = hash_admin_password(password)
    item["passwordChangedAt"] = now_iso()
    item["updatedAt"] = item["passwordChangedAt"]
    item["updatedBy"] = actor
    write_admin_users(server, users)
    append_audit(server, {"event": "admin-user-password-reset", "username": username, "admin": actor})
    return True, "密码已重置。"


def session_signature(server, username, expires, password_hash):
    message = f"{username}|{expires}|{password_hash}".encode("utf-8")
    return hmac.new(server.admin_token.encode("utf-8"), message, hashlib.sha256).hexdigest()


def make_admin_session_cookie(server, username, user):
    expires = int(time.time()) + ADMIN_SESSION_TTL_SECONDS
    sig = session_signature(server, username, expires, user.get("passwordHash", ""))
    value = f"{username}.{expires}.{sig}"
    return f"{ADMIN_SESSION_COOKIE}={value}; Path=/admin; HttpOnly; SameSite=Lax; Max-Age={ADMIN_SESSION_TTL_SECONDS}"


def expire_admin_session_cookie():
    return f"{ADMIN_SESSION_COOKIE}=; Path=/admin; HttpOnly; SameSite=Lax; Max-Age=0"


def cookie_value(handler, name):
    header = handler.headers.get("Cookie", "")
    for part in header.split(";"):
        if "=" not in part:
            continue
        key, value = part.strip().split("=", 1)
        if key == name:
            return value
    return ""


def admin_from_session(server, handler):
    value = cookie_value(handler, ADMIN_SESSION_COOKIE)
    parts = value.split(".")
    if len(parts) != 3:
        return None
    username, expires, sig = parts
    if not valid_admin_username(username):
        return None
    try:
        expires_int = int(expires)
    except ValueError:
        return None
    if expires_int < int(time.time()):
        return None
    user = admin_user_by_name(server, username)
    if not user or user.get("enabled") is not True:
        return None
    expected = session_signature(server, username, expires_int, user.get("passwordHash", ""))
    if not secrets.compare_digest(sig, expected):
        return None
    return admin_public_user(username, user)


def admin_source_allowed(handler):
    try:
        ip = ipaddress.ip_address(handler.client_address[0])
        return any(ip in net for net in INTERNAL_NETS)
    except ValueError:
        return False


def authorized_admin(server, handler, query=None):
    query = query or parse_qs(urlparse(handler.path).query)
    token = (query.get("token") or [""])[0]
    if not token or not secrets.compare_digest(token, server.admin_token):
        return False
    return admin_source_allowed(handler)


def current_admin(server, handler, query=None):
    if not admin_source_allowed(handler):
        return None
    if authorized_admin(server, handler, query):
        return {"username": "token-admin", "displayName": "Token 管理员", "role": "owner", "enabled": True, "token": True}
    return admin_from_session(server, handler)


def require_admin(server, handler, query=None):
    admin = current_admin(server, handler, query)
    return admin if admin and admin.get("enabled") is True else None


def login_admin(server, username, password, source_ip="", user_agent=""):
    username = str(username or "").strip()
    user = admin_user_by_name(server, username)
    if not user or user.get("enabled") is not True or not verify_admin_password(password, user.get("passwordHash")):
        return False, "账号或密码错误，或账号已停用。", None
    users = load_admin_users(server)
    item = users.get("users", {}).get(username)
    if isinstance(item, dict):
        item["lastLoginAt"] = now_iso()
        item["lastLoginIp"] = source_ip
        item["lastLoginAgent"] = str(user_agent or "")[:160]
        write_admin_users(server, users)
    append_audit(server, {"event": "admin-login", "username": username, "sourceIp": source_ip})
    return True, "登录成功。", admin_public_user(username, user)


def pending_items(server):
    requests = load_json(server.requests_path, {"requests": {}}).get("requests", {})
    if not isinstance(requests, dict):
        return []
    now = dt.datetime.now(dt.timezone.utc)
    latest_client_version = configured_latest_client_version(server)
    policy = read_policy(server)
    enriched = []
    for item in requests.values():
        if not isinstance(item, dict):
            continue
        enriched.append(enrich_admin_item(item, now, latest_client_version, policy))
    return sorted(enriched, key=lambda item: item.get("updatedAt", ""), reverse=True)


def device_detail(server, device_id):
    device_id = str(device_id or "").strip()
    if not device_id or len(device_id) > 128:
        return None
    requests = load_json(server.requests_path, {"requests": {}}).get("requests", {})
    policy = read_policy(server)
    latest_client_version = configured_latest_client_version(server)
    now = dt.datetime.now(dt.timezone.utc)
    raw = requests.get(device_id, {}) if isinstance(requests, dict) else {}
    if isinstance(raw, dict) and raw:
        device = enrich_admin_item(raw, now, latest_client_version, policy)
    else:
        policy_device = policy.get("devices", {}).get(device_id, {}) if isinstance(policy.get("devices"), dict) else {}
        device = enrich_admin_item({
            "deviceId": device_id,
            "deviceRef": device_ref(device_id),
            "status": "approved" if isinstance(policy_device, dict) and policy_device.get("enabled") is True else "unknown",
        }, now, latest_client_version, policy)
    reports = [item for item in support_reports(server) if item.get("deviceId") == device_id][:10]
    usage_store = load_json(server.usage_events_path, {"events": []})
    events = usage_store.get("events", [])
    if not isinstance(events, list):
        events = []
    usage_events = [item for item in events if isinstance(item, dict) and item.get("deviceId") == device_id]
    usage_events = sorted(usage_events, key=lambda item: str(item.get("recordedAt") or item.get("finishedAt") or ""), reverse=True)[:10]
    return {
        "device": device,
        "lastDiagnostic": device.get("lastDiagnostic") if isinstance(device.get("lastDiagnostic"), dict) else {},
        "supportReports": reports,
        "usageEvents": usage_events,
    }


def usage_report(server, period="week", group=""):
    start, end, label = report_period(period)
    group = clean_device_group(group)
    requests = load_json(server.requests_path, {"requests": {}}).get("requests", {})
    store = load_json(server.usage_events_path, {"events": []})
    rows = {}
    now = dt.datetime.now(dt.timezone.utc)
    latest_client_version = configured_latest_client_version(server)
    policy = read_policy(server)
    if isinstance(requests, dict):
        for device_id, device_item in requests.items():
            if not isinstance(device_item, dict):
                continue
            enriched = enrich_admin_item(device_item, now, latest_client_version, policy)
            monitor = enriched.get("monitorStatus") if isinstance(enriched.get("monitorStatus"), dict) else {}
            last_seen = enriched.get("lastHeartbeatAt") or enriched.get("lastSeenAt") or enriched.get("lastUsageAt") or ""
            rows[device_id] = {
                "deviceId": device_id,
                "deviceRef": enriched.get("deviceRef") or device_ref(device_id),
                "computerName": enriched.get("computerName") or "",
                "deviceGroup": clean_device_group(enriched.get("deviceGroup") or "") or "未分组",
                "appVersion": enriched.get("appVersion") or "",
                "sourceIp": enriched.get("sourceIp") or "",
                "online": enriched.get("online") or {"state": "unknown", "label": "未上报", "ageSeconds": None},
                "latestState": enriched.get("latestState") or {"state": "unknown", "label": "未知"},
                "monitorStatus": monitor,
                "currentStatus": monitor.get("status") or enriched.get("status") or "",
                "currentStage": monitor.get("step") or "",
                "currentReason": monitor.get("waitingReason") or "",
                "currentProgress": {
                    "currentIndex": int(monitor.get("currentIndex") or 0),
                    "totalCount": int(monitor.get("totalCount") or 0),
                    "successCount": int(monitor.get("successCount") or 0),
                    "failureCount": int(monitor.get("failureCount") or 0),
                },
                "lastHeartbeatAt": enriched.get("lastHeartbeatAt") or "",
                "lastUsageAt": enriched.get("lastUsageAt") or "",
                "lastSeenAt": last_seen,
                "runCount": 0,
                "completedCount": 0,
                "failedCount": 0,
                "stoppedCount": 0,
                "durationMs": 0,
                "plannedCount": 0,
                "successCount": 0,
                "failureCount": 0,
            }
    for event in store.get("events", []):
      if not isinstance(event, dict) or event.get("event") != "finish":
          continue
      finished = parse_iso(event.get("finishedAt")) or parse_iso(event.get("recordedAt"))
      if not finished or finished < start or finished >= end:
          continue
      device_id = event.get("deviceId") or ""
      if not device_id:
          continue
      device_item = requests.get(device_id, {}) if isinstance(requests, dict) else {}
      row = rows.setdefault(device_id, {
          "deviceId": device_id,
          "deviceRef": event.get("deviceRef") or device_ref(device_id),
          "computerName": event.get("computerName") or device_item.get("computerName") or "",
          "deviceGroup": clean_device_group(device_item.get("deviceGroup") or "") or "未分组",
          "appVersion": event.get("appVersion") or device_item.get("appVersion") or "",
          "sourceIp": event.get("sourceIp") or device_item.get("sourceIp") or "",
          "online": {"state": "unknown", "label": "未上报", "ageSeconds": None},
          "latestState": {"state": "unknown", "label": "未知"},
          "monitorStatus": {},
          "currentStatus": "",
          "currentStage": "",
          "currentReason": "",
          "currentProgress": {"currentIndex": 0, "totalCount": 0, "successCount": 0, "failureCount": 0},
          "lastHeartbeatAt": device_item.get("lastHeartbeatAt") or "",
          "lastSeenAt": device_item.get("lastSeenAt") or "",
          "runCount": 0,
          "completedCount": 0,
          "failedCount": 0,
          "stoppedCount": 0,
          "durationMs": 0,
          "plannedCount": 0,
          "successCount": 0,
          "failureCount": 0,
          "lastUsageAt": "",
      })
      row["computerName"] = event.get("computerName") or row["computerName"]
      row["deviceGroup"] = clean_device_group(row.get("deviceGroup") or device_item.get("deviceGroup") or "") or "未分组"
      row["appVersion"] = event.get("appVersion") or row["appVersion"]
      row["sourceIp"] = event.get("sourceIp") or row["sourceIp"]
      row["runCount"] += 1
      status = event.get("status")
      if status == "completed":
          row["completedCount"] += 1
      elif status == "stopped":
          row["stoppedCount"] += 1
      else:
          row["failedCount"] += 1
      row["durationMs"] += int(event.get("durationMs") or 0)
      row["plannedCount"] += int(event.get("plannedCount") or 0)
      row["successCount"] += int(event.get("successCount") or 0)
      row["failureCount"] += int(event.get("failureCount") or 0)
      row["lastUsageAt"] = max(row["lastUsageAt"], event.get("finishedAt") or event.get("recordedAt") or "")
      row["lastSeenAt"] = max(row.get("lastSeenAt") or "", row["lastUsageAt"])
    for row in rows.values():
        row["deviceGroup"] = clean_device_group(row.get("deviceGroup") or "") or "未分组"
    groups = sorted({row.get("deviceGroup") or "未分组" for row in rows.values()})
    items = [row for row in rows.values() if not group or (row.get("deviceGroup") or "未分组") == group]
    items = sorted(items, key=lambda item: (item.get("deviceGroup", ""), item.get("lastSeenAt") or item.get("lastUsageAt") or "", item.get("computerName", "")), reverse=True)
    return {
        "period": period if period in {"today", "week", "last_week"} else "week",
        "label": label,
        "start": start.isoformat().replace("+00:00", "Z"),
        "end": end.isoformat().replace("+00:00", "Z"),
        "group": group,
        "groups": groups,
        "items": items,
    }


def usage_detail(server, period="week", device_id=""):
    start, end, label = report_period(period)
    device_id = str(device_id or "")[:128]
    store = load_json(server.usage_events_path, {"events": []})
    records = []
    for event in store.get("events", []):
      if not isinstance(event, dict) or event.get("event") != "finish":
          continue
      if device_id and event.get("deviceId") != device_id:
          continue
      finished = parse_iso(event.get("finishedAt")) or parse_iso(event.get("recordedAt"))
      if not finished or finished < start or finished >= end:
          continue
      records.append({
          "id": event.get("id", ""),
          "computerName": event.get("computerName", ""),
          "appVersion": event.get("appVersion", ""),
          "sourceIp": event.get("sourceIp", ""),
          "runId": event.get("runId", ""),
          "status": event.get("status", ""),
          "startedAt": event.get("startedAt", ""),
          "finishedAt": event.get("finishedAt") or event.get("recordedAt", ""),
          "durationMs": int(event.get("durationMs") or 0),
          "plannedCount": int(event.get("plannedCount") or 0),
          "successCount": int(event.get("successCount") or 0),
          "failureCount": int(event.get("failureCount") or 0),
          "stage": event.get("stage", ""),
          "reason": event.get("reason", ""),
          "action": event.get("action", ""),
          "taskIndex": int(event.get("taskIndex") or 0),
          "totalCount": int(event.get("totalCount") or 0),
          "taskRole": event.get("taskRole", ""),
          "taskType": event.get("taskType", ""),
          "taskDate": event.get("taskDate", ""),
          "taskTime": event.get("taskTime", ""),
      })
    records.sort(key=lambda item: item.get("finishedAt", ""), reverse=True)
    return {
        "period": period if period in {"today", "week", "last_week"} else "week",
        "label": label,
        "start": start.isoformat().replace("+00:00", "Z"),
        "end": end.isoformat().replace("+00:00", "Z"),
        "deviceId": device_id,
        "items": records[:100],
    }


def daily_report(server, day="", group=""):
    start, end, label = daily_report_period(day)
    group = clean_device_group(group)
    requests = load_json(server.requests_path, {"requests": {}}).get("requests", {})
    if not isinstance(requests, dict):
        requests = {}
    heartbeat_store = load_json(getattr(server, "heartbeat_events_path", None), {"events": []})
    usage_store = load_json(server.usage_events_path, {"events": []})
    heartbeat_events = [event for event in heartbeat_store.get("events", []) if isinstance(event, dict)]
    usage_events = [event for event in usage_store.get("events", []) if isinstance(event, dict)]
    rows = {}

    def ensure_row(device_id, seed=None):
        seed = seed if isinstance(seed, dict) else {}
        device_item = requests.get(device_id, {}) if isinstance(requests, dict) else {}
        if not isinstance(device_item, dict):
            device_item = {}
        row = rows.setdefault(device_id, {
            "deviceId": device_id,
            "deviceRef": device_item.get("deviceRef") or seed.get("deviceRef") or device_ref(device_id),
            "deviceGroup": clean_device_group(device_item.get("deviceGroup") or seed.get("deviceGroup") or ""),
            "computerName": device_item.get("computerName") or seed.get("computerName") or "",
            "appVersion": device_item.get("appVersion") or seed.get("appVersion") or "",
            "sourceIp": device_item.get("sourceIp") or seed.get("sourceIp") or "",
            "firstOpenedAt": "",
            "lastHeartbeatAt": "",
            "lastSeenAt": "",
            "onlineMs": 0,
            "heartbeatCount": 0,
            "heartbeatCoverage": "none",
            "runCount": 0,
            "completedCount": 0,
            "failedCount": 0,
            "stoppedCount": 0,
            "durationMs": 0,
            "plannedCount": 0,
            "successCount": 0,
            "failureCount": 0,
            "firstUsageAt": "",
            "lastUsageAt": "",
            "lastFailureReason": "",
            "_heartbeats": [],
        })
        row["deviceGroup"] = clean_device_group(device_item.get("deviceGroup") or row.get("deviceGroup") or seed.get("deviceGroup") or "")
        for key in ["computerName", "appVersion", "sourceIp", "deviceRef"]:
            if seed.get(key):
                row[key] = seed.get(key)
        return row

    for device_id, device_item in requests.items():
        if not isinstance(device_item, dict):
            continue
        ensure_row(device_id, device_item)

    for event in heartbeat_events:
        recorded = parse_iso(event.get("recordedAt"))
        if not recorded or recorded < start or recorded >= end:
            continue
        device_id = event.get("deviceId") or ""
        if not device_id:
            continue
        row = ensure_row(device_id, event)
        row["_heartbeats"].append(recorded)
        ts = recorded.isoformat().replace("+00:00", "Z")
        row["firstOpenedAt"] = min_nonempty_time(row["firstOpenedAt"], ts)
        row["lastHeartbeatAt"] = max(row["lastHeartbeatAt"], ts)
        row["lastSeenAt"] = max(row["lastSeenAt"], ts)
        row["heartbeatCount"] += 1

    for event in usage_events:
        if event.get("event") != "finish":
            continue
        finished = parse_iso(event.get("finishedAt")) or parse_iso(event.get("recordedAt"))
        if not finished or finished < start or finished >= end:
            continue
        device_id = event.get("deviceId") or ""
        if not device_id:
            continue
        row = ensure_row(device_id, event)
        started_at = event.get("startedAt") or ""
        finished_at = event.get("finishedAt") or event.get("recordedAt") or ""
        row["runCount"] += 1
        status = event.get("status")
        if status == "completed":
            row["completedCount"] += 1
        elif status == "stopped":
            row["stoppedCount"] += 1
        else:
            row["failedCount"] += 1
            row["lastFailureReason"] = event.get("reason") or event.get("action") or row["lastFailureReason"]
        row["durationMs"] += int(event.get("durationMs") or 0)
        row["plannedCount"] += int(event.get("plannedCount") or 0)
        row["successCount"] += int(event.get("successCount") or 0)
        row["failureCount"] += int(event.get("failureCount") or 0)
        row["firstUsageAt"] = min_nonempty_time(row["firstUsageAt"], started_at or finished_at)
        row["lastUsageAt"] = max(row["lastUsageAt"], finished_at)
        row["lastSeenAt"] = max(row["lastSeenAt"], finished_at)

    for row in rows.values():
        heartbeats = sorted(set(row.pop("_heartbeats", [])))
        row["onlineMs"] = estimate_online_ms(heartbeats)
        if heartbeats:
            row["heartbeatCoverage"] = "full"
        elif row.get("lastHeartbeatAt"):
            row["heartbeatCoverage"] = "last-only"
        if not row["firstOpenedAt"]:
            device_item = requests.get(row["deviceId"], {}) if isinstance(requests, dict) else {}
            last_heartbeat = parse_iso(device_item.get("lastHeartbeatAt")) if isinstance(device_item, dict) else None
            if last_heartbeat and start <= last_heartbeat < end:
                row["firstOpenedAt"] = device_item.get("lastHeartbeatAt") or ""
                row["lastHeartbeatAt"] = device_item.get("lastHeartbeatAt") or ""
                row["lastSeenAt"] = max(row["lastSeenAt"], row["lastHeartbeatAt"])
                row["heartbeatCount"] = max(row["heartbeatCount"], 1)
                row["heartbeatCoverage"] = "last-only"
        row["successRate"] = round((row["successCount"] / row["plannedCount"]) * 100, 1) if row["plannedCount"] else 0
        row["deviceGroup"] = row["deviceGroup"] or "未分组"

    items = [row for row in rows.values() if (not group or row.get("deviceGroup") == group)]
    items.sort(key=lambda item: (item.get("deviceGroup", ""), item.get("lastSeenAt") or item.get("lastUsageAt") or "", item.get("computerName", "")), reverse=True)
    groups = sorted({(row.get("deviceGroup") or "未分组") for row in rows.values()})
    totals = {
        "deviceCount": len(items),
        "runCount": sum(int(row.get("runCount") or 0) for row in items),
        "durationMs": sum(int(row.get("durationMs") or 0) for row in items),
        "plannedCount": sum(int(row.get("plannedCount") or 0) for row in items),
        "successCount": sum(int(row.get("successCount") or 0) for row in items),
        "failureCount": sum(int(row.get("failureCount") or 0) for row in items),
        "onlineMs": sum(int(row.get("onlineMs") or 0) for row in items),
    }
    return {
        "date": label,
        "start": start.isoformat().replace("+00:00", "Z"),
        "end": end.isoformat().replace("+00:00", "Z"),
        "groups": groups,
        "group": group,
        "totals": totals,
        "items": items,
    }


def daily_report_period(day=""):
    text = str(day or "").strip()
    try:
        local_date = dt.date.fromisoformat(text)
    except ValueError:
        local_date = dt.datetime.now(REPORT_TZ).date()
    start_local = dt.datetime.combine(local_date, dt.time.min, tzinfo=REPORT_TZ)
    end_local = start_local + dt.timedelta(days=1)
    return start_local.astimezone(dt.timezone.utc), end_local.astimezone(dt.timezone.utc), local_date.isoformat()


def min_nonempty_time(current, value):
    value = str(value or "")
    if not value:
        return current or ""
    return min(current, value) if current else value


def estimate_online_ms(heartbeats):
    if not heartbeats:
        return 0
    total = 0
    for left, right in zip(heartbeats, heartbeats[1:]):
        delta = max(0, int((right - left).total_seconds() * 1000))
        total += min(delta, 2 * 60 * 1000)
    return total


def report_period(period):
    now = dt.datetime.now(REPORT_TZ)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_start = today - dt.timedelta(days=today.weekday())
    if period == "today":
        start = today
        end = today + dt.timedelta(days=1)
        label = "今日"
    elif period == "last_week":
        start = week_start - dt.timedelta(days=7)
        end = week_start
        label = "上周"
    else:
        start = week_start
        end = week_start + dt.timedelta(days=7)
        label = "本周"
    return start.astimezone(dt.timezone.utc), end.astimezone(dt.timezone.utc), label


def configured_latest_client_version(server):
    try:
        policy = read_policy(server)
        value = str(policy.get("latestClientVersion") or "").strip()
        return value[:32] or DEFAULT_LATEST_CLIENT_VERSION
    except Exception:
        return DEFAULT_LATEST_CLIENT_VERSION


def newer_version(left, right):
    if not left:
        return right or ""
    if not right:
        return left or ""
    return left if compare_versions(left, right) >= 0 else right


def enrich_admin_item(item, now, latest_client_version="", policy=None):
    next_item = dict(item)
    device = (policy or {}).get("devices", {}).get(item.get("deviceId") or "")
    heartbeat = parse_iso(item.get("lastHeartbeatAt"))
    age = (now - heartbeat).total_seconds() if heartbeat else None
    if age is None:
        online = {"state": "unknown", "label": "未上报", "ageSeconds": None}
    elif age <= 60:
        online = {"state": "online", "label": "在线", "ageSeconds": int(age)}
    elif age <= 300:
        online = {"state": "stale", "label": "可能离线", "ageSeconds": int(age)}
    else:
        online = {"state": "offline", "label": "离线", "ageSeconds": int(age)}
    update = item.get("updateStatus") if isinstance(item.get("updateStatus"), dict) else {}
    current = update.get("currentVersion") or item.get("appVersion") or ""
    latest = newer_version(update.get("latestVersion") or "", latest_client_version or "")
    if update.get("pendingUpdateReady") is True:
        downloaded = update.get("latestVersion") or latest
        latest_label = f"下次启动更新到 {downloaded or '新版本'}"
        latest_state = "ready"
        update_action = {"state": "ready", "label": "已下载待重启"}
    elif update.get("status") == "failed":
        latest_label = "检查失败"
        latest_state = "failed"
        update_action = {"state": "failed", "label": "检查失败"}
    elif latest and compare_versions(latest, current) > 0:
        latest_label = f"待更新到 {latest}"
        latest_state = "outdated"
        update_action = {"state": "outdated", "label": f"待更新到 {latest}"}
    elif current:
        latest_label = "最新"
        latest_state = "latest"
        update_action = {"state": "latest", "label": "已是最新"}
    else:
        latest_label = "未知"
        latest_state = "unknown"
        update_action = {"state": "unknown", "label": "-"}
    next_item["online"] = online
    next_item["latestState"] = {"state": latest_state, "label": latest_label}
    next_item["updateAction"] = update_action
    next_item["sharedLibraryUpload"] = isinstance(device, dict) and can_upload_shared_library(policy or {}, item.get("deviceId") or "", device)
    return next_item


def approve_device(server, device_id, admin="web"):
    if not isinstance(device_id, str) or len(device_id) > 128:
        return False, "设备号格式错误。"
    policy = read_policy(server)
    devices = policy.setdefault("devices", {})
    previous_device = devices.get(device_id) if isinstance(devices, dict) else {}
    devices[device_id] = {
        "enabled": True,
        "actions": sorted(ACTIONS),
        "expiresAt": None,
        "sharedLibraryUpload": isinstance(previous_device, dict) and previous_device.get("sharedLibraryUpload") is True,
    }
    write_policy(server, policy)
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {"deviceId": device_id, "deviceRef": device_ref(device_id)})
    item["status"] = "approved"
    item["approvedAt"] = now_iso()
    item["updatedAt"] = item["approvedAt"]
    item["approvedBy"] = admin
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "approve", "deviceRef": device_ref(device_id), "admin": admin})
    return True, "已通过授权。"


def reject_device(server, device_id, admin="web"):
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {"deviceId": device_id, "deviceRef": device_ref(device_id)})
    item["status"] = "rejected"
    item["rejectedAt"] = now_iso()
    item["updatedAt"] = item["rejectedAt"]
    item["rejectedBy"] = admin
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "reject", "deviceRef": device_ref(device_id), "admin": admin})
    return True, "已拒绝申请。"


def update_shared_library_upload_permission(server, device_id, enabled, admin="web"):
    if not isinstance(device_id, str) or len(device_id) > 128:
        return False, "设备号格式错误。"
    policy = read_policy(server)
    device = policy.setdefault("devices", {}).setdefault(device_id, {
        "enabled": False,
        "actions": sorted(ACTIONS),
        "expiresAt": None,
    })
    if not isinstance(device, dict):
        return False, "设备号格式错误。"
    device["sharedLibraryUpload"] = enabled is True
    write_policy(server, policy)
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {"deviceId": device_id, "deviceRef": device_ref(device_id)})
    item["updatedAt"] = now_iso()
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "shared-library-upload-permission", "deviceRef": device_ref(device_id), "enabled": enabled is True, "admin": admin})
    return True, "已允许上传共享文案。" if enabled is True else "已禁止上传共享文案。"


def update_device_group(server, device_id, group_name, admin="web"):
    if not isinstance(device_id, str) or len(device_id) > 128:
        return False, "设备号格式错误。"
    group_name = clean_device_group(group_name)
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {
        "deviceId": device_id,
        "deviceRef": device_ref(device_id),
        "status": "approved",
    })
    item["deviceGroup"] = group_name
    item["updatedAt"] = now_iso()
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "device-group", "deviceRef": device_ref(device_id), "deviceGroup": group_name, "admin": admin})
    return True, "设备组别已保存。"


class Handler(BaseHTTPRequestHandler):
    server_version = "License"
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(1.0)

    def log_message(self, *_):
        pass

    def reply(self, status, body, content_type="application/json; charset=utf-8", headers=None):
        raw = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(raw)
        self.close_connection = True

    def read_json(self, max_body=MAX_BODY, timeout_seconds=0.8):
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            raise ValueError("content-type")
        length_header = self.headers.get_all("Content-Length", [])
        if len(length_header) != 1 or self.headers.get("Transfer-Encoding"):
            raise ValueError("length")
        length = int(length_header[0])
        if length <= 0 or length > max_body:
            raise OverflowError()
        deadline = time.monotonic() + timeout_seconds
        data = bytearray()
        while len(data) < length:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError()
            self.connection.settimeout(remaining)
            part = self.rfile.read1(length - len(data))
            if not part:
                raise ValueError("incomplete")
            data.extend(part)
        return json.loads(data)

    def source_ip(self):
        forwarded = self.headers.get("X-Forwarded-For", "").split(",", 1)[0].strip()
        return forwarded or self.client_address[0]

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/admin/api/requests":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "requests": pending_items(self.server)})
            return
        if parsed.path == "/admin/api/usage-report":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "report": usage_report(self.server, (query.get("range") or ["week"])[0], (query.get("group") or [""])[0])})
            return
        if parsed.path == "/admin/api/usage-detail":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "detail": usage_detail(self.server, (query.get("range") or ["week"])[0], (query.get("deviceId") or [""])[0])})
            return
        if parsed.path == "/admin/api/daily-report":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "report": daily_report(self.server, (query.get("date") or [""])[0], (query.get("group") or [""])[0])})
            return
        if parsed.path == "/admin/api/device-detail":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            detail = device_detail(self.server, (query.get("deviceId") or [""])[0])
            self.reply(200 if detail else 404, {"ok": bool(detail), "detail": detail or {}, "message": "" if detail else "没有找到这台设备。"})
            return
        if parsed.path == "/admin/api/me":
            admin = require_admin(self.server, self, parse_qs(parsed.query))
            if not admin:
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "admin": admin})
            return
        if parsed.path == "/admin/api/admin-users":
            admin = require_admin(self.server, self, parse_qs(parsed.query))
            if not admin or admin.get("role") != "owner":
                self.reply(403, result(False, "ADMIN_DENIED", "只有总管理员可以管理后台账号。"))
                return
            self.reply(200, {"ok": True, "users": list_admin_users(self.server)})
            return
        if parsed.path == "/admin/api/shared-library":
            admin = require_admin(self.server, self, parse_qs(parsed.query))
            if not admin:
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "items": shared_library_list(self.server), "groups": shared_library_groups(self.server)})
            return
        if parsed.path == "/admin/api/support-reports":
            admin = require_admin(self.server, self, parse_qs(parsed.query))
            if not admin:
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "reports": support_reports(self.server)})
            return
        if parsed.path == "/admin":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(200, LOGIN_PAGE.encode("utf-8"), "text/html; charset=utf-8")
                return
            token = html.escape((query.get("token") or [""])[0], quote=True)
            page = ADMIN_PAGE.replace("__TOKEN__", token).encode("utf-8")
            self.reply(200, page, "text/html; charset=utf-8")
            return
        self.reply(404, result(False, "NOT_FOUND", "授权接口不存在。"))

    do_HEAD = do_GET
    do_PUT = do_GET
    do_DELETE = do_GET
    do_OPTIONS = do_GET

    def do_POST(self):
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/admin/login":
                if not admin_source_allowed(self):
                    self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                    return
                payload = self.read_json()
                ok, message, admin = login_admin(self.server, payload.get("username", ""), payload.get("password", ""), self.source_ip(), self.headers.get("User-Agent", ""))
                headers = {"Set-Cookie": make_admin_session_cookie(self.server, admin["username"], admin_user_by_name(self.server, admin["username"]))} if ok else None
                self.reply(200 if ok else 403, {"ok": ok, "message": message, "admin": admin}, headers=headers)
                return
            if parsed.path == "/admin/logout":
                self.reply(200, {"ok": True, "message": "已退出。"}, headers={"Set-Cookie": expire_admin_session_cookie()})
                return
            if parsed.path.startswith("/admin/api/"):
                payload = self.read_json()
                query = {"token": [payload.get("token", "")]}
                admin = require_admin(self.server, self, query)
                if not admin:
                    self.reply(403, result(False, "ADMIN_DENIED", "无权操作授权总控。"))
                    return
                device_id = payload.get("deviceId", "")
                if parsed.path == "/admin/api/approve":
                    ok, message = approve_device(self.server, device_id, admin.get("username", "web"))
                elif parsed.path == "/admin/api/reject":
                    ok, message = reject_device(self.server, device_id, admin.get("username", "web"))
                elif parsed.path == "/admin/api/shared-upload":
                    ok, message = update_shared_library_upload_permission(self.server, device_id, payload.get("enabled") is True, admin.get("username", "web"))
                elif parsed.path == "/admin/api/device-group":
                    ok, message = update_device_group(self.server, device_id, payload.get("groupName", ""), admin.get("username", "web"))
                elif parsed.path == "/admin/api/shared-library/delete":
                    ok, message = admin_delete_shared_library(self.server, payload.get("cloudId", ""), admin.get("username", "web"))
                elif parsed.path == "/admin/api/shared-library/group":
                    ok, message = admin_update_shared_library_group(self.server, payload.get("cloudId", ""), payload.get("groupName", ""), admin.get("username", "web"))
                elif parsed.path == "/admin/api/support-reports/status":
                    ok, message = update_support_report_status(self.server, payload.get("reportId", ""), payload.get("status", ""), admin.get("username", "web"))
                elif parsed.path == "/admin/api/admin-users/save":
                    if admin.get("role") != "owner":
                        self.reply(403, result(False, "ADMIN_DENIED", "只有总管理员可以管理后台账号。"))
                        return
                    ok, message = set_admin_user(self.server, payload.get("username", ""), payload.get("password", ""), payload.get("displayName", ""), payload.get("role", "manager"), payload.get("enabled", True), admin.get("username", "web"))
                elif parsed.path == "/admin/api/admin-users/enabled":
                    if admin.get("role") != "owner":
                        self.reply(403, result(False, "ADMIN_DENIED", "只有总管理员可以管理后台账号。"))
                        return
                    ok, message = update_admin_user_enabled(self.server, payload.get("username", ""), payload.get("enabled") is True, admin.get("username", "web"))
                elif parsed.path == "/admin/api/admin-users/reset-password":
                    if admin.get("role") != "owner":
                        self.reply(403, result(False, "ADMIN_DENIED", "只有总管理员可以管理后台账号。"))
                        return
                    ok, message = reset_admin_password(self.server, payload.get("username", ""), payload.get("password", ""), admin.get("username", "web"))
                else:
                    self.reply(404, result(False, "NOT_FOUND", "授权接口不存在。"))
                    return
                self.reply(200 if ok else 400, {"ok": ok, "message": message})
                return
            if parsed.path != "/license/check":
                self.do_GET()
                return
            if ipaddress.ip_address(self.client_address[0]) not in self.server.gateway_ips:
                self.reply(403, result(False, "SOURCE_DENIED", "请通过公司授权网关访问。"))
                return
            payload = self.read_json(max_body=MAX_SHARED_BODY, timeout_seconds=60)
            if isinstance(payload, dict) and payload.get("action") == REQUEST_ACTION:
                status, body = record_request(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            if isinstance(payload, dict) and payload.get("action") == HEARTBEAT_ACTION:
                status, body = record_heartbeat(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            if isinstance(payload, dict) and payload.get("action") == USAGE_REPORT_ACTION:
                status, body = record_usage_report(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            if isinstance(payload, dict) and payload.get("action") == SUPPORT_REPORT_ACTION:
                status, body = record_support_report(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            if isinstance(payload, dict) and payload.get("action") in SHARED_LIBRARY_ACTIONS:
                status, body = handle_shared_library_action(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            policy = read_policy(self.server)
            status, body = check(payload, policy)
            self.reply(status, body)
            record = {
                "action": payload.get("action") if isinstance(payload, dict) and payload.get("action") in ACTIONS else "invalid",
                "version": payload.get("appVersion") if isinstance(payload, dict) and isinstance(payload.get("appVersion"), str) else "invalid",
                "allowed": body["allowed"],
                "code": body["code"],
            }
            if isinstance(payload, dict) and isinstance(payload.get("deviceId"), str):
                record["deviceRef"] = device_ref(payload["deviceId"])
            print(json.dumps(record, ensure_ascii=False), flush=True)
        except OverflowError:
            self.reply(413, result(False, "BODY_SIZE", "请求内容太大。若是在上传共享文案，请改用“导出共享包”手动发送。"))
        except (socket.timeout, TimeoutError):
            self.reply(408, result(False, "REQUEST_TIMEOUT", "授权请求超时。"))
        except (ValueError, UnicodeError, json.JSONDecodeError):
            self.reply(400, result(False, "INVALID_REQUEST", "授权请求格式错误。"))
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            self.reply(503, result(False, "SERVICE_UNAVAILABLE", "授权服务暂不可用。"))


LOGIN_PAGE = """<!doctype html><meta charset="utf-8"><title>自动发单--后台管理登录</title>
<style>
*{box-sizing:border-box}body{font-family:Arial,"Microsoft YaHei",sans-serif;margin:0;min-height:100vh;display:grid;place-items:center;background:#f3f6fb;color:#122033}.box{width:min(420px,calc(100vw - 32px));background:#fff;border:1px solid #d8e2f0;border-radius:10px;padding:26px;box-shadow:0 18px 45px rgba(15,23,42,.12)}h1{font-size:24px;margin:0 0 6px}p{margin:0 0 20px;color:#64748b}label{display:grid;gap:6px;margin:12px 0;font-weight:700}input{min-height:40px;border:1px solid #cbd5e1;border-radius:7px;padding:8px 10px;font-size:15px}button{width:100%;min-height:42px;margin-top:12px;border:1px solid #2563eb;background:#2563eb;color:#fff;border-radius:7px;font-weight:700}.msg{min-height:20px;color:#b91c1c;margin-top:12px}
</style>
<div class="box"><h1>自动发单--后台管理</h1><p>请输入管理员账号密码。</p><label>账号<input id="username" autocomplete="username"></label><label>密码<input id="password" type="password" autocomplete="current-password"></label><button onclick="login()">登录</button><div id="msg" class="msg"></div></div>
<script>
async function login(){const r=await fetch("/admin/login",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({username:username.value.trim(),password:password.value})});const data=await r.json().catch(()=>({message:"登录失败。"}));if(data.ok){location.href="/admin";return;}msg.textContent=data.message||"登录失败。";}
password.addEventListener("keydown",e=>{if(e.key==="Enter")login();});
</script>"""


ADMIN_PAGE = """<!doctype html><meta charset="utf-8"><title>自动发单--后台管理</title>
<style>
*{box-sizing:border-box}body{font-family:Arial,"Microsoft YaHei",sans-serif;margin:0;background:#f3f6fb;color:#122033}.layout{display:flex;min-height:100vh}.side{width:208px;background:#0f172a;color:#dbe7ff;padding:18px 14px;position:sticky;top:0;height:100vh}.brand{font-size:19px;font-weight:700;margin:0 0 6px}.hint{color:#94a3b8;font-size:12px;line-height:1.6;margin:0 0 18px}.nav{display:block;width:100%;border:0;background:transparent;color:#cbd5e1;text-align:left;padding:11px 12px;border-radius:8px;margin:5px 0;cursor:pointer}.nav:hover{background:#1e293b}.nav.active{background:#2563eb;color:#fff}.badge{float:right;background:#ef4444;color:#fff;border-radius:999px;min-width:22px;text-align:center;padding:1px 6px;font-size:12px}.main{flex:1;padding:22px 26px 40px;min-width:0}.top{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin-bottom:16px}.top h1{font-size:24px;margin:0 0 6px}.top p{margin:0;color:#64748b}.refresh{min-height:36px;padding:0 14px;border:1px solid #93c5fd;background:#fff;color:#1d4ed8;border-radius:7px}.cards{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:12px;margin:14px 0 18px}.card{background:#fff;border:1px solid #d8e2f0;border-radius:8px;padding:13px}.card strong{display:block;font-size:26px;margin-top:6px}.warn{border-color:#f59e0b;background:#fff7ed}.panel{background:#fff;border:1px solid #d8e2f0;border-radius:8px;padding:14px;margin:14px 0 18px}.panel h2{font-size:18px;margin:0 0 10px}.section[hidden]{display:none}table{border-collapse:collapse;width:100%;background:#fff;margin-bottom:18px}td,th{border:1px solid #d8e2f0;padding:8px;text-align:left;vertical-align:top}th{background:#eef4fb;white-space:nowrap}button,select,input{min-height:32px;margin-right:8px}input,select{border:1px solid #cbd5e1;border-radius:6px;padding:5px 8px}label{font-weight:700;color:#334155}.primary{background:#2563eb;color:#fff;border:1px solid #2563eb;border-radius:6px;padding:0 12px}.danger{background:#fff;color:#b91c1c;border:1px solid #fca5a5;border-radius:6px;padding:0 12px}.muted{color:#64748b}.pending{color:#b45309;font-weight:700}.approved{color:#166534;font-weight:700}.rejected{color:#b91c1c;font-weight:700}.online{color:#166534;font-weight:700}.stale{color:#b45309;font-weight:700}.offline,.failed{color:#b91c1c;font-weight:700}.latest{color:#166534;font-weight:700}.outdated{color:#1d4ed8;font-weight:700}.ready{color:#7c3aed;font-weight:700}.unknown{color:#64748b;font-weight:700}.sub{display:block;color:#64748b;font-size:12px;margin-top:3px}.num{text-align:right;font-variant-numeric:tabular-nums}.mini{min-height:26px;padding:2px 8px;margin-left:8px}.device{font-family:monospace;max-width:260px;word-break:break-all}.empty{padding:24px;color:#64748b;text-align:center}.modal{position:fixed;inset:0;background:rgba(15,23,42,.35);display:flex;align-items:flex-start;justify-content:center;padding:48px 24px;z-index:10}.modal[hidden]{display:none}.modal-box{background:#fff;border:1px solid #cbd5e1;max-width:1280px;width:100%;max-height:82vh;overflow:auto;padding:16px;box-shadow:0 18px 45px rgba(15,23,42,.22)}.modal-head{display:flex;align-items:center;justify-content:space-between;gap:12px}.scene{min-width:260px}.reason{max-width:360px;word-break:break-word}.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:12px}.toolbar input{min-width:260px}.group-input{width:150px}.status-msg{color:#64748b;font-size:12px}.diag-grid{display:grid;grid-template-columns:140px minmax(0,1fr);gap:8px 12px;margin:12px 0}.diag-grid b{color:#475569}.diag-card{border:1px solid #d8e2f0;border-radius:8px;padding:12px;margin:12px 0;background:#fbfdff}.diag-card h3{margin:0 0 8px;font-size:16px}.diag-card pre{white-space:pre-wrap;word-break:break-word;background:#0f172a;color:#e5e7eb;padding:10px;border-radius:6px;max-height:180px;overflow:auto}@media(max-width:980px){.layout{display:block}.side{position:static;width:auto;height:auto}.cards{grid-template-columns:repeat(2,minmax(140px,1fr))}.main{padding:16px;overflow:auto}}
</style>
<div class="layout"><aside class="side"><div class="brand">自动发单--后台管理</div><p class="hint">处理设备授权、共享文案、在线监控、任务报表和异常协助。页面每 30 秒自动刷新。</p><button class="nav active" data-tab="pending" onclick="setTab('pending')">待授权 <span id="pendingBadge" class="badge">0</span></button><button class="nav" data-tab="approved" onclick="setTab('approved')">已授权 <span id="approvedBadge" class="badge">0</span></button><button class="nav" data-tab="sharedLibrary" onclick="setTab('sharedLibrary')">共享文案</button><button class="nav" data-tab="usage" onclick="setTab('usage')">在线监控</button><button class="nav" data-tab="dailyReport" onclick="setTab('dailyReport')">每日报表</button><button class="nav" data-tab="support" onclick="setTab('support')">异常协助 <span id="supportBadge" class="badge">0</span></button><button id="adminUsersNav" class="nav" data-tab="adminUsers" onclick="setTab('adminUsers')" hidden>管理员账号</button></aside><main class="main"><div class="top"><div><h1 id="pageTitle">待授权</h1><p id="pageDesc">优先处理新设备授权申请。</p><span id="currentAdmin" class="sub"></span></div><button class="refresh" onclick="load()">刷新</button></div><div class="cards"><div class="card warn"><span>待授权</span><strong id="pendingCount">0</strong></div><div class="card"><span>已授权</span><strong id="approvedCount">0</strong></div><div class="card"><span>离线/未上报</span><strong id="offlineCount">0</strong></div><div class="card"><span>待更新</span><strong id="outdatedCount">0</strong></div></div>
<section id="pendingSection" class="section"><div class="panel"><h2>待授权设备</h2><span id="pendingTip" class="sub"></span></div><table><thead><tr><th>状态</th><th>电脑名</th><th>版本</th><th>是否最新</th><th>在线状态</th><th>来源</th><th>申请时间</th><th>设备号</th><th>操作</th></tr></thead><tbody id="pendingRows"></tbody></table></section>
<section id="approvedSection" class="section" hidden><div class="panel"><h2>已授权设备</h2><span class="sub">已通过的设备可单独开关“上传共享文案”资格；下载/使用云端文案仍只要求设备已授权。</span></div><table><thead><tr><th>电脑名</th><th>版本</th><th>是否最新</th><th>在线状态</th><th>更新状态</th><th>共享上传</th><th>来源</th><th>申请时间</th><th>设备号</th></tr></thead><tbody id="approvedRows"></tbody></table></section>
<section id="sharedLibrarySection" class="section" hidden><div class="panel"><h2>共享文案</h2><span class="sub">这里显示所有已上传到云端的共享文案。删除只删除云端共享副本，不影响别人已经下载到本机的文案。</span><div class="toolbar"><input id="sharedLibrarySearch" placeholder="搜索文案名称或上传设备" oninput="renderSharedLibraryAdmin()"><select id="sharedLibraryGroupFilter" onchange="renderSharedLibraryAdmin()"><option value="">全部分组</option></select><datalist id="sharedLibraryGroupOptions"></datalist><span id="sharedLibraryTip" class="status-msg"></span></div></div><table><thead><tr><th>文案名称</th><th>分组</th><th>条数</th><th>大小</th><th>云端版本</th><th>上传时间</th><th>上传设备</th><th>来源</th><th>操作</th></tr></thead><tbody id="sharedLibraryRows"></tbody></table></section>
<section id="usageSection" class="section" hidden><div class="panel"><h2>在线监控 / 任务报表</h2><span class="sub">打开程序后就会上报在线状态和当前阶段；创建任务完成后再累计使用次数、时长和任务数。</span><div class="toolbar"><label>任务统计范围 <select id="usageRange" onchange="loadUsage()"><option value="today">今日</option><option value="week" selected>本周</option><option value="last_week">上周</option></select></label><label>组别 <select id="usageGroup" onchange="loadUsage()"><option value="">全部组别</option></select></label><span id="usageTitle" class="sub"></span></div></div><table><thead><tr><th>组别</th><th>电脑名</th><th>在线状态</th><th>当前阶段</th><th>版本</th><th>使用次数</th><th>总时长</th><th>平均时长</th><th>任务数</th><th>成功</th><th>失败</th><th>完成/失败/中止</th><th>最后心跳</th><th>最后任务</th><th>来源</th></tr></thead><tbody id="usageRows"></tbody></table></section>
<section id="dailyReportSection" class="section" hidden><div class="panel"><h2>每日使用报表</h2><span class="sub">按北京时间统计当天每台电脑首次打开、最后在线、估算在线时长、实际创建任务、成功失败次数。关闭程序只能按最后心跳估算。</span><div class="toolbar"><label>日期 <input id="dailyReportDate" type="date" onchange="loadDailyReport()"></label><label>组别 <select id="dailyReportGroup" onchange="loadDailyReport()"><option value="">全部组别</option></select></label><button class="primary" onclick="exportDailyReportCsv()">导出 CSV</button><span id="dailyReportTitle" class="status-msg"></span></div></div><table><thead><tr><th>组别</th><th>电脑名</th><th>版本</th><th>首次打开</th><th>最后在线</th><th>在线时长</th><th>使用次数</th><th>创建任务</th><th>成功</th><th>失败</th><th>完成/失败/中止</th><th>成功率</th><th>最近失败原因</th><th>来源</th></tr></thead><tbody id="dailyReportRows"></tbody></table></section>
<section id="supportSection" class="section" hidden><div class="panel"><h2>异常协助</h2><span class="sub">这里只显示用户主动点击“上报给管理员”的问题。本地已先给处理建议，解决不了才会上报。</span><div class="toolbar"><select id="supportStatusFilter" onchange="renderSupportReports()"><option value="">全部状态</option><option value="pending">待处理</option><option value="handled">已处理</option><option value="ignored">忽略</option></select><input id="supportSearch" placeholder="搜索电脑名、阶段、错误" oninput="renderSupportReports()"><span id="supportTip" class="status-msg"></span></div></div><table><thead><tr><th>状态</th><th>电脑名</th><th>阶段/类型</th><th>错误</th><th>本地建议</th><th>上报时间</th><th>来源</th><th>操作</th></tr></thead><tbody id="supportRows"></tbody></table></section>
<section id="adminUsersSection" class="section" hidden><div class="panel"><h2>管理员账号</h2><span class="sub">每个管理者单独账号。停用后，这个账号即使知道密码也不能登录。</span><div style="display:grid;grid-template-columns:140px 180px 180px 120px 100px auto;gap:8px;margin-top:12px;align-items:end"><label>账号<input id="newAdminUsername" placeholder="manager01"></label><label>显示名称/电脑备注<input id="newAdminDisplay" placeholder="张三-电脑"></label><label>密码<input id="newAdminPassword" placeholder="至少 8 位"></label><label>角色<select id="newAdminRole"><option value="manager">管理者</option><option value="owner">总管理员</option></select></label><label>启用<select id="newAdminEnabled"><option value="true">启用</option><option value="false">停用</option></select></label><button class="primary" onclick="saveAdminUser()">保存账号</button></div><span id="adminUserTip" class="sub"></span></div><table><thead><tr><th>账号</th><th>显示名称/电脑备注</th><th>角色</th><th>状态</th><th>最后登录</th><th>登录来源</th><th>浏览器标识</th><th>操作</th></tr></thead><tbody id="adminUserRows"></tbody></table></section>
<div id="usageDetailModal" class="modal" hidden><div class="modal-box"><div class="modal-head"><div><h2 id="usageDetailTitle">使用详情</h2><span id="usageDetailRange" class="sub"></span></div><button onclick="closeUsageDetail()">关闭</button></div><table><thead><tr><th>时间</th><th>状态</th><th>任务进度</th><th>场景</th><th>原因/最后动作</th><th>版本</th><th>来源</th></tr></thead><tbody id="usageDetailRows"></tbody></table></div></div><div id="deviceDetailModal" class="modal" hidden><div class="modal-box"><div class="modal-head"><div><h2 id="deviceDetailTitle">设备详情 / 诊断</h2><span id="deviceDetailSub" class="sub"></span></div><button onclick="closeDeviceDetail()">关闭</button></div><div id="deviceDetailBody"></div></div></div></main></div>
<script>
const token="__TOKEN__";
const state={tab:"pending",requests:[],admin:null,adminUsers:[],sharedLibraryItems:[],sharedLibraryGroups:["开群组","老群组","合集组"],supportReports:[],dailyReport:null};
function el(id){return document.getElementById(id);}
async function api(path,body){const opt=body?{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({...body,token})}:{};const sep=path.includes("?")?"&":"?";const r=await fetch(path+(body?"":sep+"token="+encodeURIComponent(token)),opt);return r.json();}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>{if(c==="&")return"&amp;";if(c==="<")return"&lt;";if(c===">")return"&gt;";if(c==='"')return"&quot;";return"&#39;";});}
function ago(sec){if(sec==null)return"未收到心跳";if(sec<60)return Math.max(0,sec)+" 秒前";if(sec<3600)return Math.floor(sec/60)+" 分钟前";return Math.floor(sec/3600)+" 小时前";}
function fmtDuration(ms){const sec=Math.round(Number(ms||0)/1000);const h=Math.floor(sec/3600);const m=Math.floor((sec%3600)/60);const s=sec%60;return h?`${h}小时${m}分`:(m?`${m}分${s}秒`:`${s}秒`);}
function fmtBeijingTime(value){const raw=String(value||"").trim();if(!raw)return"-";const date=new Date(raw);if(!Number.isFinite(date.getTime()))return raw;const parts=Object.fromEntries(new Intl.DateTimeFormat("zh-CN",{timeZone:"Asia/Shanghai",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).formatToParts(date).map(p=>[p.type,p.value]));return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}:${parts.second} 北京时间`;}
function todayBeijingDate(){const parts=Object.fromEntries(new Intl.DateTimeFormat("zh-CN",{timeZone:"Asia/Shanghai",year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(new Date()).map(p=>[p.type,p.value]));return `${parts.year}-${parts.month}-${parts.day}`;}
function setTab(tab){state.tab=tab;document.querySelectorAll("[data-tab]").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));el("pendingSection").hidden=tab!=="pending";el("approvedSection").hidden=tab!=="approved";el("sharedLibrarySection").hidden=tab!=="sharedLibrary";el("usageSection").hidden=tab!=="usage";el("dailyReportSection").hidden=tab!=="dailyReport";el("supportSection").hidden=tab!=="support";el("adminUsersSection").hidden=tab!=="adminUsers";el("pageTitle").textContent=tab==="approved"?"已授权":tab==="sharedLibrary"?"共享文案":tab==="usage"?"在线监控":tab==="dailyReport"?"每日报表":tab==="support"?"异常协助":tab==="adminUsers"?"管理员账号":"待授权";el("pageDesc").textContent=tab==="approved"?"查看已通过设备的在线和更新状态。":tab==="sharedLibrary"?"查看和管理已上传到云端的共享文案。":tab==="usage"?"打开程序就能看到在线状态和当前阶段；创建任务后再累计任务报表。":tab==="dailyReport"?"按天查看每个组别、每台电脑的打开时间、在线时长和创建结果。":tab==="support"?"查看用户处理不了后主动上报的问题。":tab==="adminUsers"?"管理可登录总控的后台账号。":"优先处理新设备授权申请。";if(tab==="sharedLibrary")loadSharedLibraryAdmin();if(tab==="usage")loadUsage();if(tab==="dailyReport")loadDailyReport();if(tab==="support")loadSupportReports();if(tab==="adminUsers")loadAdminUsers();}
function statusLabel(v){if(v==="completed")return"完成";if(v==="failed")return"失败";if(v==="stopped")return"中止";if(v==="pending")return"待授权";if(v==="approved")return"已授权";if(v==="rejected")return"已拒绝";return v||"-";}
function renderDeviceId(id){const value=String(id||"");return value.length>28?`${esc(value.slice(0,12))}...${esc(value.slice(-10))}<span class="sub">${esc(value)}</span>`:esc(value);}
function renderStats(pending,approved,all){const offline=approved.filter(x=>["offline","unknown"].includes(x.online?.state||"unknown")).length;const outdated=approved.filter(x=>["outdated","ready"].includes(x.latestState?.state||"unknown")).length;el("pendingCount").textContent=pending.length;el("approvedCount").textContent=approved.length;el("offlineCount").textContent=offline;el("outdatedCount").textContent=outdated;el("pendingBadge").textContent=pending.length;el("approvedBadge").textContent=approved.length;el("pendingTip").textContent=pending.length?`当前有 ${pending.length} 台设备等待处理。`:"当前没有待授权设备。";}
function pendingRow(x){const online=x.online||{};const latest=x.latestState||{};const canUpload=x.sharedLibraryUpload===true;return `<tr><td class="${esc(x.status)}">${esc(statusLabel(x.status))}</td><td>${esc(x.computerName||"")}<button class="mini" onclick="openDeviceDetail('${esc(x.deviceId)}')">诊断</button></td><td>${esc(x.appVersion||"")}</td><td class="${esc(latest.state||"unknown")}">${esc(latest.label||"未知")}</td><td class="${esc(online.state||"unknown")}">${esc(online.label||"未上报")}<span class="sub">${esc(ago(online.ageSeconds))}</span></td><td>${esc(x.sourceIp||"")}</td><td>${esc(fmtBeijingTime(x.requestedAt))}</td><td class="device">${renderDeviceId(x.deviceId)}</td><td><button class="primary" onclick="approve('${esc(x.deviceId)}')">通过</button><button class="danger" onclick="rejectReq('${esc(x.deviceId)}')">拒绝</button><button class="${canUpload?"danger":"primary"}" onclick="setSharedUpload('${esc(x.deviceId)}',${canUpload?"false":"true"})">${canUpload?"禁止上传":"允许上传"}</button></td></tr>`;}
function approvedRow(x){const online=x.online||{};const latest=x.latestState||{};const action=x.updateAction||{};const canUpload=x.sharedLibraryUpload===true;return `<tr><td>${esc(x.computerName||"")}<button class="mini" onclick="openDeviceDetail('${esc(x.deviceId)}')">诊断</button></td><td>${esc(x.appVersion||"")}</td><td class="${esc(latest.state||"unknown")}">${esc(latest.label||"未知")}</td><td class="${esc(online.state||"unknown")}">${esc(online.label||"未上报")}<span class="sub">${esc(ago(online.ageSeconds))}</span></td><td class="${esc(action.state||"unknown")}">${esc(action.label||"-")}</td><td><span class="${canUpload?"approved":"muted"}">${canUpload?"允许":"禁止"}</span><button class="${canUpload?"danger":"primary"}" onclick="setSharedUpload('${esc(x.deviceId)}',${canUpload?"false":"true"})">${canUpload?"禁止上传":"允许上传"}</button></td><td>${esc(x.sourceIp||"")}</td><td>${esc(fmtBeijingTime(x.requestedAt))}</td><td class="device">${renderDeviceId(x.deviceId)}</td></tr>`;}
function renderDevices(){const pending=state.requests.filter(x=>(x.status||"pending")==="pending");const approved=state.requests.filter(x=>x.status==="approved");renderStats(pending,approved,state.requests);el("pendingRows").innerHTML=pending.map(pendingRow).join("")||"<tr><td class='empty' colspan='9'>当前没有待授权设备。</td></tr>";el("approvedRows").innerHTML=approved.map(approvedRow).join("")||"<tr><td class='empty' colspan='9'>当前没有已授权设备。</td></tr>";}
function fmtBytes(bytes){const n=Number(bytes||0);if(n>=1024*1024)return Math.ceil(n/1024/1024)+"MB";if(n>=1024)return Math.ceil(n/1024)+"KB";return n+"B";}
function cleanGroup(v){return String(v||"").replace(/\\s+/g," ").trim().slice(0,40);}
function normalizeSharedGroups(groups,items){const out=[];["开群组","老群组","合集组"].forEach(n=>{if(!out.includes(n))out.push(n);});(Array.isArray(groups)?groups:[]).forEach(n=>{const g=cleanGroup(n);if(g&&!out.includes(g))out.push(g);});(Array.isArray(items)?items:[]).forEach(x=>{const g=cleanGroup(x.groupName);if(g&&!out.includes(g))out.push(g);});return out;}
function renderSharedLibraryGroupOptions(){const filter=el("sharedLibraryGroupFilter");if(!filter)return;const selected=filter.value||"";filter.innerHTML="<option value=''>全部分组</option>"+state.sharedLibraryGroups.map(g=>`<option value="${esc(g)}">${esc(g)}</option>`).join("")+"<option value='__ungrouped'>未分组</option>";filter.value=selected==="__ungrouped"||state.sharedLibraryGroups.includes(selected)?selected:"";el("sharedLibraryGroupOptions").innerHTML=state.sharedLibraryGroups.map(g=>`<option value="${esc(g)}"></option>`).join("");}
function visibleSharedLibraryItems(){const q=String(el("sharedLibrarySearch")?.value||"").trim().toLowerCase();const group=String(el("sharedLibraryGroupFilter")?.value||"");return state.sharedLibraryItems.filter(x=>{const hay=[x.name,x.cloudId,x.uploadedByDeviceRef,x.sourceIp].map(v=>String(v||"").toLowerCase()).join(" ");const groupName=String(x.groupName||"");return(!q||hay.includes(q))&&(!group||(group==="__ungrouped"?!groupName:groupName===group));});}
function sharedLibraryRow(x,index){return `<tr><td>${esc(x.name||"未命名文案")}<span class="sub">${esc(x.cloudId||"")}</span></td><td><input id="sharedGroup${index}" class="group-input" list="sharedLibraryGroupOptions" value="${esc(x.groupName||"")}" placeholder="未分组"><button class="mini" onclick="saveSharedLibraryGroup('${esc(x.cloudId||"")}',${index})">保存</button></td><td class="num">${esc(x.taskCount||0)}</td><td>${esc(fmtBytes(x.packageBytes))}</td><td class="num">${esc(x.cloudVersion||0)}</td><td>${esc(fmtBeijingTime(x.uploadedAt))}</td><td class="device">${esc(x.uploadedByDeviceRef||"")}</td><td>${esc(x.sourceIp||"")}</td><td><button class="danger" onclick="deleteSharedLibrary('${esc(x.cloudId||"")}')">删除</button></td></tr>`;}
function renderSharedLibraryAdmin(){renderSharedLibraryGroupOptions();const items=visibleSharedLibraryItems();el("sharedLibraryTip").textContent=state.sharedLibraryItems.length?`显示 ${items.length} / ${state.sharedLibraryItems.length} 份`:"";el("sharedLibraryRows").innerHTML=items.map(sharedLibraryRow).join("")||`<tr><td class='empty' colspan='9'>${state.sharedLibraryItems.length?"没有匹配的云端共享文案。":"暂无云端共享文案。"}</td></tr>`;}
async function loadSharedLibraryAdmin(){const data=await api("/admin/api/shared-library");if(data.ok){state.sharedLibraryItems=data.items||[];state.sharedLibraryGroups=normalizeSharedGroups(data.groups,state.sharedLibraryItems);renderSharedLibraryAdmin();}else{el("sharedLibraryRows").innerHTML="<tr><td class='empty' colspan='9'>读取共享文案失败："+esc(data.message||"未知原因")+"</td></tr>";}}
async function saveSharedLibraryGroup(cloudId,index){if(!cloudId)return;const groupName=cleanGroup(el("sharedGroup"+index)?.value||"");const data=await api("/admin/api/shared-library/group",{cloudId,groupName});if(!data.ok){alert(data.message||"保存分组失败。");return;}el("sharedLibraryTip").textContent=data.message||"分组已保存。";await loadSharedLibraryAdmin();}
async function deleteSharedLibrary(cloudId){if(!cloudId)return;if(!confirm("确认删除这份云端共享文案？只删除云端副本，不影响已经下载到本机的文案。"))return;const data=await api("/admin/api/shared-library/delete",{cloudId});if(!data.ok)alert(data.message||"删除失败。");await loadSharedLibraryAdmin();}
function monitorStatusLabel(x){const status=String(x?.currentStatus||"");if(status==="running")return"运行中";if(status==="paused")return"暂停/等待";if(status==="waiting")return"等待确认";if(status==="failed")return"失败";if(status==="stopped")return"已停止";if(status==="ready")return"已打开";return status||"-";}
function monitorStageText(x){const p=x?.currentProgress||{};const progress=Number(p.totalCount||0)?` ${Number(p.currentIndex||0)}/${Number(p.totalCount||0)}`:"";const reason=x?.currentReason?`<span class="sub">${esc(x.currentReason)}</span>`:"";return `${esc(x.currentStage||"-")}${esc(progress)}${reason}`;}
async function loadUsage(){const range=el("usageRange").value;const group=el("usageGroup")?.value||"";const data=await api("/admin/api/usage-report?range="+encodeURIComponent(range)+"&group="+encodeURIComponent(group));const report=data.report||{};const groups=Array.isArray(report.groups)?report.groups:[];const selected=report.group||group||"";el("usageGroup").innerHTML="<option value=''>全部组别</option>"+groups.map(g=>`<option value="${esc(g)}">${esc(g)}</option>`).join("");el("usageGroup").value=groups.includes(selected)?selected:"";el("usageTitle").textContent=`任务统计范围：${report.label||""} ${report.start||""} - ${report.end||""}`;el("usageRows").innerHTML=(report.items||[]).map(x=>{const avg=x.runCount?Math.round(Number(x.durationMs||0)/x.runCount):0;const online=x.online||{};return `<tr><td><input id="usageDeviceGroup${esc(x.deviceId||"")}" class="group-input" value="${esc(x.deviceGroup||"未分组")}" placeholder="未分组"><button class="mini" onclick="saveUsageDeviceGroup('${esc(x.deviceId||"")}')">保存</button></td><td>${esc(x.computerName||"")}<button class="mini" onclick="openUsageDetail('${esc(x.deviceId||"")}')">详情</button><span class="sub">${esc(x.deviceRef||"")}</span></td><td class="${esc(online.state||"unknown")}">${esc(online.label||"未上报")}</td><td>${esc(monitorStatusLabel(x))}<span class="sub">${monitorStageText(x)}</span></td><td>${esc(x.appVersion||"")}</td><td class="num">${esc(x.runCount||0)}</td><td class="num">${esc(fmtDuration(x.durationMs))}</td><td class="num">${esc(fmtDuration(avg))}</td><td class="num">${esc(x.plannedCount||0)}</td><td class="num">${esc(x.successCount||0)}</td><td class="num">${esc(x.failureCount||0)}</td><td>${esc(x.completedCount||0)} / ${esc(x.failedCount||0)} / ${esc(x.stoppedCount||0)}</td><td>${esc(fmtBeijingTime(x.lastHeartbeatAt))}</td><td>${esc(fmtBeijingTime(x.lastUsageAt))}</td><td>${esc(x.sourceIp||"")}</td></tr>`}).join("")||"<tr><td class='empty' colspan='15'>还没有设备心跳或任务记录。打开程序后会先出现在这里；创建任务完成后才会累计任务次数和时长。</td></tr>";}
async function saveUsageDeviceGroup(deviceId){const input=el("usageDeviceGroup"+deviceId);const data=await api("/admin/api/device-group",{deviceId,groupName:input?.value||""});el("usageTitle").textContent=data.message||"";await loadUsage();}
async function loadDailyReport(){if(!el("dailyReportDate").value)el("dailyReportDate").value=todayBeijingDate();const date=el("dailyReportDate").value;const group=el("dailyReportGroup").value||"";const data=await api("/admin/api/daily-report?date="+encodeURIComponent(date)+"&group="+encodeURIComponent(group));if(!data.ok){el("dailyReportRows").innerHTML="<tr><td class='empty' colspan='14'>读取每日报表失败："+esc(data.message||"未知原因")+"</td></tr>";return;}state.dailyReport=data.report||{};renderDailyReport();}
function renderDailyReport(){const report=state.dailyReport||{};const groups=Array.isArray(report.groups)?report.groups:[];const selected=report.group||el("dailyReportGroup").value||"";el("dailyReportGroup").innerHTML="<option value=''>全部组别</option>"+groups.map(g=>`<option value="${esc(g)}">${esc(g)}</option>`).join("");el("dailyReportGroup").value=groups.includes(selected)?selected:"";const totals=report.totals||{};el("dailyReportTitle").textContent=`${report.date||""}：设备 ${totals.deviceCount||0} 台，使用 ${totals.runCount||0} 次，任务 ${totals.plannedCount||0} 条，成功 ${totals.successCount||0}，失败 ${totals.failureCount||0}，在线约 ${fmtDuration(totals.onlineMs||0)}`;el("dailyReportRows").innerHTML=(report.items||[]).map(dailyReportRow).join("")||"<tr><td class='empty' colspan='14'>这一天没有心跳或任务记录。</td></tr>";}
function dailyReportRow(x){const coverage=x.heartbeatCoverage==="full"?"":"<span class='sub'>心跳明细不足，仅供参考</span>";return `<tr><td><input id="deviceGroup${esc(x.deviceId)}" class="group-input" value="${esc(x.deviceGroup||"未分组")}" placeholder="未分组"><button class="mini" onclick="saveDeviceGroup('${esc(x.deviceId)}')">保存</button></td><td>${esc(x.computerName||"")}<span class="sub">${esc(x.deviceRef||"")}</span></td><td>${esc(x.appVersion||"")}</td><td>${esc(fmtBeijingTime(x.firstOpenedAt))}</td><td>${esc(fmtBeijingTime(x.lastHeartbeatAt||x.lastSeenAt))}</td><td>${esc(fmtDuration(x.onlineMs))}${coverage}</td><td class="num">${esc(x.runCount||0)}</td><td class="num">${esc(x.plannedCount||0)}</td><td class="num">${esc(x.successCount||0)}</td><td class="num">${esc(x.failureCount||0)}</td><td>${esc(x.completedCount||0)} / ${esc(x.failedCount||0)} / ${esc(x.stoppedCount||0)}</td><td class="num">${esc(x.successRate||0)}%</td><td class="reason">${esc(x.lastFailureReason||"-")}</td><td>${esc(x.sourceIp||"")}</td></tr>`;}
async function saveDeviceGroup(deviceId){const input=el("deviceGroup"+deviceId);const data=await api("/admin/api/device-group",{deviceId,groupName:input?.value||""});el("dailyReportTitle").textContent=data.message||"";await loadDailyReport();}
function exportDailyReportCsv(){const report=state.dailyReport||{};const rows=Array.isArray(report.items)?report.items:[];const header=["日期","组别","电脑名","设备号","版本","首次打开","最后在线","在线时长","使用次数","创建任务","成功","失败","完成","失败轮次","中止","成功率","最近失败原因","来源"];const lines=[header,...rows.map(x=>[report.date||"",x.deviceGroup||"未分组",x.computerName||"",x.deviceRef||"",x.appVersion||"",fmtBeijingTime(x.firstOpenedAt),fmtBeijingTime(x.lastHeartbeatAt||x.lastSeenAt),fmtDuration(x.onlineMs),x.runCount||0,x.plannedCount||0,x.successCount||0,x.failureCount||0,x.completedCount||0,x.failedCount||0,x.stoppedCount||0,(x.successRate||0)+"%",x.lastFailureReason||"",x.sourceIp||""])];const csv=lines.map(row=>row.map(csvCell).join(",")).join("\\r\\n");const blob=new Blob(["\\ufeff"+csv],{type:"text/csv;charset=utf-8"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`daily-report-${report.date||todayBeijingDate()}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
function csvCell(value){return `"${String(value??"").replace(/"/g,'""')}"`;}
function runStatusLabel(v){if(v==="running")return"运行中";if(v==="completed")return"完成";if(v==="failed")return"失败";if(v==="stopped")return"中止";return v||"-";}
function supportStatusLabel(v){if(v==="handled")return"已处理";if(v==="ignored")return"忽略";return"待处理";}
function visibleSupportReports(){const q=String(el("supportSearch")?.value||"").trim().toLowerCase();const status=String(el("supportStatusFilter")?.value||"");return state.supportReports.filter(x=>{const hay=[x.computerName,x.stage,x.category,x.message,x.sourceIp,x.deviceRef].map(v=>String(v||"").toLowerCase()).join(" ");return(!status||x.status===status)&&(!q||hay.includes(q));});}
function supportReportRow(x){const suggestions=Array.isArray(x.suggestions)?x.suggestions:[];const logs=Array.isArray(x.logs)?x.logs:[];const detail=[...suggestions.map((s,i)=>`${i+1}. ${s}`),...logs.slice(-5).map(s=>"日志："+s)].join("\\n");return `<tr><td class="${esc(x.status==="handled"?"approved":x.status==="ignored"?"muted":"pending")}">${esc(supportStatusLabel(x.status))}</td><td>${esc(x.computerName||"")}<span class="sub">${esc(x.appVersion||"")}</span></td><td>${esc(x.stage||"-")}<span class="sub">${esc(x.category||"-")}</span></td><td class="reason">${esc(x.message||"-")}<span class="sub">${esc(x.lastAction||"")}</span></td><td class="reason">${esc(suggestions.join("；")||"-")}</td><td>${esc(fmtBeijingTime(x.reportedAt))}</td><td>${esc(x.sourceIp||"")}<span class="sub">${esc(x.deviceRef||"")}</span></td><td><details><summary>详情</summary><pre>${esc(detail)}</pre></details><button class="primary" onclick="setSupportStatus('${esc(x.id)}','handled')">已处理</button><button onclick="setSupportStatus('${esc(x.id)}','ignored')">忽略</button></td></tr>`;}
function renderSupportReports(){const items=visibleSupportReports();const pending=state.supportReports.filter(x=>(x.status||"pending")==="pending").length;el("supportBadge").textContent=pending;el("supportTip").textContent=state.supportReports.length?`显示 ${items.length} / ${state.supportReports.length} 条，待处理 ${pending} 条`:"";el("supportRows").innerHTML=items.map(supportReportRow).join("")||"<tr><td class='empty' colspan='8'>当前没有异常协助记录。</td></tr>";}
async function loadSupportReports(){const data=await api("/admin/api/support-reports");if(data.ok){state.supportReports=data.reports||[];renderSupportReports();}else{el("supportRows").innerHTML="<tr><td class='empty' colspan='8'>读取异常协助失败："+esc(data.message||"未知原因")+"</td></tr>";}}
async function setSupportStatus(reportId,status){const data=await api("/admin/api/support-reports/status",{reportId,status});if(!data.ok)alert(data.message||"更新失败。");await loadSupportReports();}
function sceneText(x){const parts=[];if(x.stage)parts.push("阶段="+x.stage);if(x.taskRole)parts.push("角色="+x.taskRole);if(x.taskType)parts.push("类型="+x.taskType);if(x.taskDate)parts.push("日期="+x.taskDate);if(x.taskTime)parts.push("时间="+x.taskTime);return parts.join("；")||"-";}
async function openUsageDetail(deviceId){const range=el("usageRange").value;const data=await api("/admin/api/usage-detail?range="+encodeURIComponent(range)+"&deviceId="+encodeURIComponent(deviceId));const detail=data.detail||{};el("usageDetailTitle").textContent="使用详情："+((detail.items||[])[0]?.computerName||deviceId||"未知电脑");el("usageDetailRange").textContent=`${detail.label||""} ${detail.start||""} - ${detail.end||""}`;el("usageDetailRows").innerHTML=(detail.items||[]).map(x=>`<tr><td>${esc(fmtBeijingTime(x.startedAt))}<span class="sub">结束：${esc(fmtBeijingTime(x.finishedAt))}</span><span class="sub">用时：${esc(fmtDuration(x.durationMs))}</span></td><td class="${esc(x.status==="completed"?"latest":x.status==="stopped"?"stale":"failed")}">${esc(runStatusLabel(x.status))}</td><td>${esc(x.taskIndex||0)} / ${esc(x.totalCount||x.plannedCount||0)}<span class="sub">计划 ${esc(x.plannedCount||0)}，成功 ${esc(x.successCount||0)}，失败 ${esc(x.failureCount||0)}</span></td><td class="scene">${esc(sceneText(x))}</td><td class="reason">${esc(x.reason||x.action||"-")}</td><td>${esc(x.appVersion||"")}</td><td>${esc(x.sourceIp||"")}</td></tr>`).join("")||"<tr><td colspan='7'>这个范围内没有明细记录。</td></tr>";el("usageDetailModal").hidden=false;}
function closeUsageDetail(){el("usageDetailModal").hidden=true;}
function closeDeviceDetail(){el("deviceDetailModal").hidden=true;}
function listBlock(items,empty){return Array.isArray(items)&&items.length?items.map(x=>`<li>${esc(x)}</li>`).join(""):`<li>${esc(empty||"暂无")}</li>`;}
function diagnosticBlock(d){if(!d||!d.message)return "<div class='diag-card'><h3>最近诊断</h3><p class='muted'>暂无最近失败诊断。用户打开系统后会持续上报状态；上传失败后会自动带上脱敏诊断。</p></div>";return `<div class="diag-card"><h3>最近诊断</h3><div class="diag-grid"><b>时间</b><span>${esc(fmtBeijingTime(d.recordedAt||d.receivedAt))}</span><b>阶段</b><span>${esc(d.stage||"-")}</span><b>类型</b><span>${esc(d.category||"-")}</span><b>文案</b><span>${esc(d.previewName||"-")}</span><b>错误</b><span class="failed">${esc(d.message||"-")}</span><b>最后动作</b><span>${esc(d.lastAction||"-")}</span></div><b>处理建议</b><ul>${listBlock(d.suggestions,"暂无处理建议")}</ul><b>日志摘要</b><pre>${esc((d.logs||[]).join("\\n")||"暂无日志摘要")}</pre></div>`;}
function supportRows(items){return Array.isArray(items)&&items.length?`<table><thead><tr><th>时间</th><th>状态</th><th>阶段</th><th>错误</th></tr></thead><tbody>${items.map(x=>`<tr><td>${esc(fmtBeijingTime(x.reportedAt))}</td><td>${esc(supportStatusLabel(x.status))}</td><td>${esc(x.stage||"-")}</td><td class="reason">${esc(x.message||"-")}</td></tr>`).join("")}</tbody></table>`:"<p class='muted'>暂无用户主动上报记录。</p>";}
function usageRows(items){return Array.isArray(items)&&items.length?`<table><thead><tr><th>时间</th><th>状态</th><th>阶段</th><th>原因</th></tr></thead><tbody>${items.map(x=>`<tr><td>${esc(fmtBeijingTime(x.recordedAt||x.finishedAt))}</td><td>${esc(runStatusLabel(x.status))}</td><td>${esc(x.stage||"-")}</td><td class="reason">${esc(x.reason||x.action||"-")}</td></tr>`).join("")}</tbody></table>`:"<p class='muted'>暂无最近任务记录。</p>";}
async function openDeviceDetail(deviceId){if(!deviceId)return;const data=await api("/admin/api/device-detail?deviceId="+encodeURIComponent(deviceId));if(!data.ok){alert(data.message||"读取设备诊断失败。");return;}const detail=data.detail||{};const d=detail.device||{};const online=d.online||{};const latest=d.latestState||{};const monitor=d.monitorStatus||{};el("deviceDetailTitle").textContent="设备详情 / 诊断："+(d.computerName||deviceId);el("deviceDetailSub").textContent=(d.deviceRef||"")+" / "+(d.appVersion||"-")+" / "+(online.label||"未上报");el("deviceDetailBody").innerHTML=`<div class="diag-card"><h3>设备状态</h3><div class="diag-grid"><b>电脑名</b><span>${esc(d.computerName||"-")}</span><b>组别</b><span>${esc(d.deviceGroup||"未分组")}</span><b>设备号</b><span class="device">${esc(d.deviceId||deviceId)}</span><b>版本</b><span>${esc(d.appVersion||"-")}</span><b>是否最新</b><span class="${esc(latest.state||"unknown")}">${esc(latest.label||"-")}</span><b>在线</b><span class="${esc(online.state||"unknown")}">${esc(online.label||"未上报")} ${esc(ago(online.ageSeconds))}</span><b>当前阶段</b><span>${esc(monitor.step||"-")} ${esc(monitorStatusLabel({currentStatus:monitor.status}))}</span><b>等待/失败原因</b><span>${esc(monitor.waitingReason||"-")}</span><b>来源</b><span>${esc(d.sourceIp||"-")}</span><b>最后心跳</b><span>${esc(fmtBeijingTime(d.lastHeartbeatAt))}</span></div></div>${diagnosticBlock(detail.lastDiagnostic)}<div class="diag-card"><h3>用户主动上报</h3>${supportRows(detail.supportReports)}</div><div class="diag-card"><h3>最近任务记录</h3>${usageRows(detail.usageEvents)}</div>`;el("deviceDetailModal").hidden=false;}
function roleLabel(v){return v==="owner"?"总管理员":"管理者";}
function adminUserRow(x){const status=x.enabled?"启用":"停用";const toggle=x.enabled?"停用":"启用";return `<tr><td>${esc(x.username)}</td><td>${esc(x.displayName||"")}</td><td>${esc(roleLabel(x.role))}</td><td class="${x.enabled?"approved":"rejected"}">${status}</td><td>${esc(fmtBeijingTime(x.lastLoginAt))}</td><td>${esc(x.lastLoginIp||"-")}</td><td class="reason">${esc(x.lastLoginAgent||"-")}</td><td><button class="${x.enabled?"danger":"primary"}" onclick="toggleAdminUser('${esc(x.username)}',${x.enabled?"false":"true"})">${toggle}</button><button onclick="resetAdminPass('${esc(x.username)}')">重置密码</button></td></tr>`;}
function renderAdminUsers(){el("adminUserRows").innerHTML=state.adminUsers.map(adminUserRow).join("")||"<tr><td class='empty' colspan='8'>暂无管理员账号。</td></tr>";}
async function loadAdminUsers(){const data=await api("/admin/api/admin-users");if(data.ok){state.adminUsers=data.users||[];renderAdminUsers();}else{el("adminUserRows").innerHTML="<tr><td class='empty' colspan='8'>只有总管理员可以查看。</td></tr>";}}
async function saveAdminUser(){const payload={username:el("newAdminUsername").value.trim(),displayName:el("newAdminDisplay").value.trim(),password:el("newAdminPassword").value,role:el("newAdminRole").value,enabled:el("newAdminEnabled").value==="true"};const data=await api("/admin/api/admin-users/save",payload);el("adminUserTip").textContent=data.message||"";if(data.ok){el("newAdminPassword").value="";await loadAdminUsers();}}
async function toggleAdminUser(username,enabled){const data=await api("/admin/api/admin-users/enabled",{username,enabled});el("adminUserTip").textContent=data.message||"";await loadAdminUsers();}
async function resetAdminPass(username){const password=prompt("请输入新密码，至少 8 位");if(!password)return;const data=await api("/admin/api/admin-users/reset-password",{username,password});el("adminUserTip").textContent=data.message||"";}
async function loadMe(){const data=await api("/admin/api/me");if(!data.ok){location.href="/admin";return;}state.admin=data.admin;el("currentAdmin").textContent=`当前登录：${data.admin.displayName||data.admin.username}（${roleLabel(data.admin.role)}）`;el("adminUsersNav").hidden=data.admin.role!=="owner";if(data.admin.role!=="owner"&&state.tab==="adminUsers")setTab("pending");}
async function logout(){await fetch("/admin/logout",{method:"POST",headers:{"content-type":"application/json"},body:"{}"});location.href="/admin";}
async function load(){const data=await api("/admin/api/requests");state.requests=data.requests||[];renderDevices();if(state.tab==="sharedLibrary")await loadSharedLibraryAdmin();if(state.tab==="usage")await loadUsage();if(state.tab==="dailyReport")await loadDailyReport();if(state.tab==="support")await loadSupportReports();else loadSupportReports().catch(()=>{});}
async function approve(id){await api("/admin/api/approve",{deviceId:id});load();}
async function rejectReq(id){await api("/admin/api/reject",{deviceId:id});load();}
async function setSharedUpload(id,enabled){await api("/admin/api/shared-upload",{deviceId:id,enabled});load();}
async function init(){await loadMe();await load();}
init();
setInterval(load,30000);
</script>"""


def ensure_admin_token(path):
    path = Path(path)
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    token = secrets.token_urlsafe(24)
    path.write_text(token + "\n", encoding="utf-8")
    os.chmod(path, 0o640)
    return token


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bind", required=True)
    parser.add_argument("--port", type=int, default=8093)
    parser.add_argument("--policy", required=True)
    parser.add_argument("--gateway", action="append", required=True)
    args = parser.parse_args()
    policy_path = Path(args.policy)
    server = ThreadingHTTPServer((args.bind, args.port), Handler)
    server.daemon_threads = True
    server.policy_path = policy_path
    server.requests_path = policy_path.with_name("requests.json")
    server.usage_events_path = policy_path.with_name("usage-events.json")
    server.heartbeat_events_path = policy_path.with_name("heartbeat-events.json")
    server.support_reports_path = policy_path.with_name("support-reports.json")
    server.audit_path = policy_path.with_name("audit.log")
    server.admin_token_path = policy_path.with_name("admin-token")
    server.admin_users_path = policy_path.with_name("admin-users.json")
    server.admin_token = ensure_admin_token(server.admin_token_path)
    server.gateway_ips = {ipaddress.ip_address(v) for v in args.gateway}
    server.serve_forever()


if __name__ == "__main__":
    main()

import fs from "node:fs/promises";
import path from "node:path";
import { chromium } from "playwright";
import { fillTextWithReadbackGuard } from "./text-input-guard.js";
import { ensureMediaReadyBeforeSubmit } from "./media-ready-guard.js";
import { resolveLocalMediaForTask } from "./media-local-check.js";
import { handleRobotNotInGroup, nextRobotCandidate, parseSubmitConfirmRobotCount, readSubmitConfirmDialog, showManualRobotSwitchNotice } from "./confirm-dialog-policy.js";
import { resolveCmsScheduleDateOption, verifyCmsScheduleDateSelectedText } from "./schedule-date.js";

const T = {
  useRole: "使用角色",
  selectRole: "请选择角色",
  text: "文本",
  image: "图片",
  video: "视频",
  finder: "视频号",
  sticker: "动态表情",
  taskRemark: "任务备注",
  scheduleSend: "定时发送",
  today: "今天",
  tomorrow: "明天",
  dayAfterTomorrow: "后天",
  anyTime: "任意时间",
  textPlaceholder: "请输入文字",
  upload: "点击上传",
  execute: "执行发送",
  confirmCreate: "确认创建",
  customSticker: "自定义表情包",
  confirmUpload: "确认上传",
  ready: "极速就绪",
  success: "创建成功"
};

const SCRIPT_TEXT_PLACEHOLDER_PREFIX = "请输入文字";

export async function openRealCmsPage(options = {}) {
  if (options.cdpUrl) {
    const browser = await chromium.connectOverCDP(options.cdpUrl);
    const context = browser.contexts()[0] || await browser.newContext();
    installSafeDialogHandlersForContext(context, options);
    try {
      const page = await reuseOrOpenCmsPage(context, options);
      await ensureCmsPageAlive(page);
      return { context, browser, page, shouldClose: false };
    } catch (error) {
      await browser.close().catch(() => {});
      throw error;
    }
  }

  const profileDir = options.profileDir || path.join(options.projectRoot || process.cwd(), "browser-profile");
  const context = await chromium.launchPersistentContext(profileDir, {
    headless: Boolean(options.headless),
    viewport: options.viewport || { width: 1440, height: 1000 }
  });
  installSafeDialogHandlersForContext(context, options);
  try {
    const page = await reuseOrOpenCmsPage(context, options);
    await ensureCmsPageAlive(page);
    return { context, browser: context, page, shouldClose: true };
  } catch (error) {
    await context.close().catch(() => {});
    throw error;
  }
}

export async function openRealCmsCreatePages(options = {}) {
  if (options.cdpUrl) {
    const browser = await chromium.connectOverCDP(options.cdpUrl);
    const context = browser.contexts()[0] || await browser.newContext();
    installSafeDialogHandlersForContext(context, options);
    try {
      const pages = await ensureCmsCreatePages(context, options);
      if (!pages.length) {
        throw new Error("没有找到可控制的云中客创建任务页。请先用 2.0 打开的浏览器登录云中客，并分别打开托页面和豆妈页面。");
      }
      return { context, browser, pages, shouldClose: false };
    } catch (error) {
      await browser.close().catch(() => {});
      throw error;
    }
  }

  const profileDir = options.profileDir || path.join(options.projectRoot || process.cwd(), "browser-profile");
  const context = await chromium.launchPersistentContext(profileDir, {
    headless: Boolean(options.headless),
    viewport: options.viewport || { width: 1440, height: 1000 }
  });
  installSafeDialogHandlersForContext(context, options);
  try {
    const pages = await ensureCmsCreatePages(context, options);
    if (!pages.length) {
      throw new Error("没有找到可控制的云中客创建任务页。请先用 2.0 打开的浏览器登录云中客，并分别打开托页面和豆妈页面。");
    }
    return { context, browser: context, pages, shouldClose: true };
  } catch (error) {
    await context.close().catch(() => {});
    throw error;
  }
}

function installSafeDialogHandlersForContext(context, options = {}) {
  if (!context || context.__v2SafeDialogHandlersInstalled) return;
  context.__v2SafeDialogHandlersInstalled = true;
  for (const page of context.pages?.() || []) installSafeDialogHandler(page, options);
  context.on?.("page", (page) => installSafeDialogHandler(page, options));
}

function installSafeDialogHandler(page, options = {}) {
  if (!page || page.__v2SafeDialogHandlerInstalled) return;
  page.__v2SafeDialogHandlerInstalled = true;
  page.on?.("dialog", async (dialog) => {
    const text = safeDialogText(dialog);
    try {
      if (dialog.type?.() === "beforeunload") await dialog.accept();
      else await dialog.dismiss();
    } catch (error) {
      if (!isNoDialogShowingError(error)) {
        options.actions?.push?.({
          name: "safeDialogHandler",
          ok: false,
          text,
          error: error?.message || String(error)
        });
      }
      return;
    }
    options.actions?.push?.({
      name: "safeDialogHandler",
      ok: true,
      text
    });
  });
}

function safeDialogText(dialog) {
  try {
    return String(dialog?.message?.() || "").slice(0, 500);
  } catch {
    return "";
  }
}

function isNoDialogShowingError(error) {
  const message = error?.message || String(error || "");
  return /Page\.handleJavaScriptDialog|No dialog is showing/i.test(message);
}

export async function reuseOrOpenCmsPage(context, options = {}) {
  const targetUrl = String(options.cmsUrl || "").trim();
  const createPage = await findExistingCmsCreatePage(context, targetUrl);
  if (createPage) {
    if (options.bringToFront !== false) await createPage.bringToFront().catch(() => {});
    return createPage;
  }

  const existingCmsPage = context.pages().find((page) => isCmsPageUrl(page.url?.() || "", targetUrl));
  if (existingCmsPage) {
    if (options.bringToFront !== false) await existingCmsPage.bringToFront().catch(() => {});
    await existingCmsPage.waitForLoadState("domcontentloaded", { timeout: options.timeoutMs || 15000 }).catch(() => {});
    if (await pageLooksLikeCreateForm(existingCmsPage)) return existingCmsPage;
  }
  if (!targetUrl) {
    throw new Error("没有找到云中客页面地址，请在 config.json 里配置 cmsUrl。");
  }
  if (options.requireExistingCreatePage) {
    throw new Error("没有找到可控制的云中客创建任务页。请先用 2.0 打开的浏览器登录云中客并停在创建任务页；普通 Chrome 如果没有远程调试端口，脚本不能直接接管。");
  }
  const page = context.pages().find((item) => item.url() === "about:blank") || await context.newPage();
  await page.goto(targetUrl, { waitUntil: "domcontentloaded", timeout: options.timeoutMs || 30000 });
  await page.waitForTimeout(1200).catch(() => {});
  return page;
}

export async function ensureCmsPageAlive(page) {
  if (!page || page.isClosed?.()) {
    throw new Error("云中客页面已经关闭，请重新打开后再测试。");
  }
  const url = page.url?.() || "";
  if (!/iyunzk\.com|cms/i.test(url)) {
    throw new Error("当前页面不是云中客/CMS 页面，请先打开云中客创建任务页面。");
  }
}

export function createRealCmsSubmitBeforeAdapter(page, options = {}) {
  const actions = [];
  const visualObserver = createCmsVirtualMouseObserver(page, {
    enabled: options.virtualMouse !== false,
    actions
  });
  installObservedMouse(page, visualObserver);
  const facade = options.facade || createPlaywrightCmsPageFacade(page, {
    ...options,
    visualObserver,
    policyLog: async (entry) => {
      actions.push({ name: "confirmDialogPolicy", ...entry });
      if (typeof options.control?.checkpoint === "function") {
        await options.control.checkpoint(formatConfirmDialogPolicyLog(entry));
      }
    }
  });
  const mediaManifest = options.mediaManifest || {};
  const state = {
    lastTuoIdentity: null,
    tuoSpeakerIdentities: new Map(),
    tuoInteractionIdentities: new Map()
  };
  return {
    actions,
    async locateTaskPageForBackground(task) {
      const visible = options.focusDuringRun !== false;
      await focusCmsPageForVisualTask(page, visualObserver, task, { ...options, focusDuringRun: visible });
      actions.push(action("locateTaskPageForBackground", task));
      return { ok: true, visible };
    },
    async focusTaskPageForRetry(task) {
      const visible = options.focusDuringRun !== false && options.focusOnRetry !== false;
      await focusCmsPageForVisualTask(page, visualObserver, task, {
        ...options,
        focusDuringRun: visible
      });
      actions.push(action("focusTaskPageForRetry", task));
      return { ok: true, visible };
    },
    async beforeTask(task) {
      await focusCmsPageForVisualTask(page, visualObserver, task, options);
      if (options.resetBeforeEachTask !== true) return;
      actions.push(action("resetEditor", task));
      await resetCmsEditorForOneTask(page, {
        skipPageReset: options.skipPageReset === true,
        timeoutMs: options.timeoutMs || 30000,
        waitMs: options.pageResetWaitMs || 1200
      });
    },
    async selectRole(task) {
      await focusCmsPageForVisualTask(page, visualObserver, task, options);
      actions.push(action("selectRole", task));
      if (task.role === "douma") {
        await facade.assertCreatePageConfigured?.(task);
        return;
      }
      const switchDecision = tuoRobotSwitchDecision(task, state);
      let selectedTuoIdentity = switchDecision.currentIdentity;
      const preciseTuo = task.role === "tuo" && switchDecision.currentIdentity?.precise;
      if (preciseTuo) {
        if (switchDecision.shouldSwitch) {
          const switchAction = action("switchTuoRobot", task);
          actions.push(switchAction);
          if (typeof facade.switchTuoRobot !== "function") {
            throw new Error(`第 ${task.index} 条需要按精准托昵称选择机器人，但当前 CMS adapter 不支持“更换机器人”，已停止。`);
          }
          const switchResult = await facade.switchTuoRobot(task, switchDecision);
          Object.assign(switchAction, summarizeRobotSwitchResult(switchResult));
          selectedTuoIdentity = resolveSelectedTuoIdentity(switchDecision.currentIdentity, switchResult);
        }
      } else {
        const target = roleTargetForTask(task, options.config || {}, options);
        await facade.selectCurrentTaskRole(target, task);
      }
      if (task.role === "tuo" && !preciseTuo && shouldPreSwitchTuoRobot(options) && switchDecision.shouldSwitch) {
        const switchAction = action("switchTuoRobot", task);
        actions.push(switchAction);
        if (typeof facade.switchTuoRobot !== "function") {
          throw new Error(`第 ${task.index} 条需要切换托机器人，但当前 CMS adapter 不支持“更换机器人”，已停止。`);
        }
        const switchResult = await facade.switchTuoRobot(task, switchDecision);
        Object.assign(switchAction, summarizeRobotSwitchResult(switchResult));
        selectedTuoIdentity = resolveSelectedTuoIdentity(switchDecision.currentIdentity, switchResult);
      }
      await facade.assertCreatePageConfigured?.(task);
      if (task.role === "tuo") rememberTuoIdentity(state, selectedTuoIdentity);
    },
    async setScheduleTime(task) {
      if (!String(task.time || "").trim()) {
        throw new Error(`第 ${task.index} 条缺少最终发送时间，已停止，不会填内容/上传素材/执行发送。`);
      }
      if (typeof facade.setScheduleTime !== "function") return;
      actions.push(action("setScheduleTime", task));
      return await facade.setScheduleTime(task);
    },
    async fillText(task) {
      actions.push(action("fillText", task));
      await fillTextWithReadbackGuard(facade, task.text);
      await facade.assertCurrentEditorContentPresent(task);
    },
    async fillFinderFeed(task) {
      actions.push(action("fillFinderFeed", task));
      await fillTextWithReadbackGuard({
        fillTextInput: (text) => facade.fillFinderFeedInput(text),
        clearTextInput: () => facade.clearFinderFeedInput(),
        readTextInput: () => facade.readFinderFeedInput(),
        writeClipboardText: (text) => facade.writeClipboardText(text),
        pasteText: () => facade.pasteFinderFeedText()
      }, task.text);
      await facade.assertCurrentEditorContentPresent(task);
    },
    async uploadMedia(task) {
      actions.push(action("uploadMedia", task));
      const localPath = resolveLocalMediaForTask(task, mediaManifest);
      await facade.uploadMediaFile(localPath, task);
    },
    async waitMediaReady(task) {
      actions.push(action("waitMediaReady", task));
      const localPath = resolveLocalMediaForTask(task, mediaManifest);
      try {
        await ensureMediaReadyBeforeSubmit(facade, localPath, {
          ...(options.media || {}),
          taskType: task.type
        });
      } catch (error) {
        if (task.type !== "sticker") throw error;
        const areaText = await facade.readStickerAreaText?.();
        const suffix = areaText ? ` 动态表情区域：${areaText}` : " 动态表情区域：未读取到可见文字";
        throw new Error(`${error?.message || error}${suffix}`);
      }
      await facade.assertCurrentEditorContentPresent(task);
    },
    async submit(task) {
      actions.push(action("submit", task));
      if (options.allowRealSubmit !== true) {
        throw new Error(`第 ${task.index} 条已到提交前停止：真实提交未开放。`);
      }
      return await facade.submitCurrentTask(task);
    }
  };
}

function createCmsVirtualMouseObserver(page, options = {}) {
  const enabled = options.enabled !== false && page;
  const actions = options.actions || [];
  const warned = new Set();
  const warn = (message) => {
    const text = message?.message || String(message || "");
    if (!text || warned.has(text)) return;
    warned.add(text);
    actions.push({
      name: "virtualMouseWarning",
      message: text
    });
  };
  return {
    async install() {
      if (!enabled || typeof page.evaluate !== "function") return false;
      try {
        await page.evaluate(() => {
          const id = "fd-auto-tool-virtual-mouse";
          let dot = document.getElementById(id);
          if (!dot) {
            dot = document.createElement("div");
            dot.id = id;
            dot.setAttribute("aria-hidden", "true");
            Object.assign(dot.style, {
              position: "fixed",
              left: "0",
              top: "0",
              width: "9px",
              height: "9px",
              marginLeft: "-4.5px",
              marginTop: "-4.5px",
              borderRadius: "999px",
              background: "rgba(37, 99, 235, 0.42)",
              border: "1px solid rgba(255, 255, 255, 0.78)",
              boxShadow: "0 0 0 3px rgba(37, 99, 235, 0.12)",
              zIndex: "2147483647",
              pointerEvents: "none",
              transform: "translate3d(12px, 12px, 0)",
              transition: "transform 80ms linear",
              willChange: "transform"
            });
            document.documentElement.appendChild(dot);
          }
          window.__fdAutoToolMoveVirtualMouse = (x, y) => {
            const current = document.getElementById(id);
            if (!current) return;
            current.style.pointerEvents = "none";
            current.style.transform = `translate3d(${Math.round(Number(x) || 0)}px, ${Math.round(Number(y) || 0)}px, 0)`;
          };
        });
        return true;
      } catch (error) {
        warn(`虚拟鼠标注入失败：${error?.message || error}`);
        return false;
      }
    },
    async move(x, y) {
      if (!enabled || typeof page.evaluate !== "function") return false;
      try {
        await this.install();
        await page.evaluate(({ x, y }) => {
          if (typeof window.__fdAutoToolMoveVirtualMouse === "function") {
            window.__fdAutoToolMoveVirtualMouse(x, y);
          }
        }, { x, y });
        return true;
      } catch (error) {
        warn(`虚拟鼠标移动失败：${error?.message || error}`);
        return false;
      }
    },
    warn
  };
}

function installObservedMouse(page, observer) {
  if (!page?.mouse || page.__fdAutoToolObservedMouse) return;
  page.__fdAutoToolVirtualMouseObserver = observer;
  page.__fdAutoToolObservedMouse = true;
  const originalClick = page.mouse.click.bind(page.mouse);
  const originalMove = page.mouse.move?.bind(page.mouse);
  page.mouse.click = async (x, y, ...args) => {
    await observer.move(x, y);
    return originalClick(x, y, ...args);
  };
  if (originalMove) {
    page.mouse.move = async (x, y, ...args) => {
      await observer.move(x, y);
      return originalMove(x, y, ...args);
    };
  }
}

async function focusCmsPageForVisualTask(page, observer, task, options = {}) {
  if (!page) return;
  if (options.focusDuringRun !== false) {
    try {
      await page.bringToFront?.();
    } catch (error) {
      observer.warn(`第 ${task?.index || "?"} 条切换到当前 CMS 页面失败：${error?.message || error}`);
    }
  }
  await observer.install();
}

async function clickLocatorForVisual(page, locator, options = {}) {
  await moveVirtualMouseToLocator(page, locator);
  return locator.click(options);
}

async function moveVirtualMouseToLocator(page, locator) {
  const observer = page?.__fdAutoToolVirtualMouseObserver;
  if (!observer) return false;
  const box = await locator.boundingBox({ timeout: 800 }).catch(() => null);
  if (!box) return false;
  return observer.move(box.x + box.width / 2, box.y + box.height / 2);
}

export function createPlaywrightCmsPageFacade(page, options = {}) {
  return {
    async selectCurrentTaskRole(target, task) {
      await ensureCmsPageAlive(page);
      if (!target) {
        if (await pageLooksLikeCreateForm(page)) return { ok: true, skipped: true, reason: "manual-prepared-random" };
        throw new Error("云中客页面异常：没有看到创建任务页核心元素。请先切到已登录、已选好群和机器人的云中客创建任务页。");
      }
      await closePopups(page);
      const opened = await openRoleDropdown(page, { optional: true });
      if (!opened) {
        if (await pageLooksLikeCreateForm(page)) {
          return { ok: true, target, skipped: true, reason: "manual-prepared" };
        }
        throw new Error("云中客页面异常：没有找到“使用角色”选择框，也没有看到文本/图片/视频创建入口。请先手动打开云中客创建任务页面。");
      }
      const option = await findRoleOptionPoint(page, target);
      if (!option) {
        throw new Error(`第 ${task.index} 条没有找到当前任务对应的角色/机器人：${target}`);
      }
      await page.mouse.click(option.x, option.y);
      await page.waitForTimeout(500);
      return { ok: true, target, selected: option.text || target };
    },
    async switchTuoRobot(task, decision = {}) {
      await ensureCmsPageAlive(page);
      const candidate = decision.currentIdentity?.candidate || firstPreciseTuoCandidate(task);
      if (candidate?.nickname) {
        return selectTuoRobotCandidate(page, candidate, task, {
          reason: "precise-primary",
          timeoutMs: options.robotSwitchTimeoutMs || 8000
        });
      }
      const beforeSelection = await readCurrentCmsSelection(page);
      const beforeState = await readCmsCreateConfigState(page);
      const point = await findChangeRobotPoint(page);
      if (!point) {
        throw new Error(`第 ${task.index} 条切换到新的托身份（${decision.currentIdentity?.label || task.speaker || ""}）时，没有找到“更换机器人”按钮，已停止。`);
      }
      await page.mouse.click(point.x, point.y);
      await waitForRobotSwitchSettled(page, {
        beforeSelection,
        beforeState,
        timeoutMs: options.robotSwitchTimeoutMs || 8000
      });
      const afterState = await readCmsCreateConfigState(page);
      if (!afterState.ok) {
        const details = afterState.reason ? ` 原因：${afterState.reason}` : "";
        throw new Error(`第 ${task.index} 条更换托机器人后，对应页面未选好群/机器人，已停止。${details}`);
      }
      const afterSelection = await readCurrentCmsSelection(page);
      return {
        ok: true,
        before: beforeSelection.robot,
        after: afterSelection.robot,
        changed: normalizeRobotSelection(beforeSelection.robot) !== normalizeRobotSelection(afterSelection.robot)
      };
    },
    async switchRobot(task, context = {}) {
      await ensureCmsPageAlive(page);
      const reasonText = context.reason === "submit-robot-status-failure"
        ? "提交后检测到机器人掉线/状态异常"
        : "检测到机器人不在群";
      if (context.candidate?.nickname) {
        return selectTuoRobotCandidate(page, context.candidate, task, {
          reason: context.reason || "robot-not-in-group",
          attempt: context.attempt,
          timeoutMs: options.robotSwitchTimeoutMs || 8000
        });
      }
      const beforeSelection = await readCurrentCmsSelection(page);
      const beforeState = await readCmsCreateConfigState(page);
      const point = await findChangeRobotPoint(page);
      if (!point) {
        throw new Error(`第 ${task.index} 条${reasonText}，但当前页面没有找到“更换机器人”按钮，已停止。`);
      }
      await page.mouse.click(point.x, point.y);
      await waitForRobotSwitchSettled(page, {
        beforeSelection,
        beforeState,
        timeoutMs: options.robotSwitchTimeoutMs || 8000
      });
      const afterState = await readCmsCreateConfigState(page);
      if (!afterState.ok) {
        const details = afterState.reason ? ` 原因：${afterState.reason}` : "";
        throw new Error(`第 ${task.index} 条${reasonText}，第 ${context.attempt || "?"} 次更换机器人后，对应页面未选好群/机器人，已停止。${details}`);
      }
      const afterSelection = await readCurrentCmsSelection(page);
      return {
        ok: true,
        before: beforeSelection.robot,
        after: afterSelection.robot,
        changed: normalizeRobotSelection(beforeSelection.robot) !== normalizeRobotSelection(afterSelection.robot)
      };
    },
    async setScheduleTime(task) {
      await ensureCmsPageAlive(page);
      await setCmsScheduleTime(page, task);
    },
    async readScheduleTime() {
      const input = await findScheduleTimeInput(page);
      return normalizeScheduleTime(await input.inputValue({ timeout: 500 }).catch(() => ""));
    },
    async fillTextInput(text) {
      await ensureCmsPageAlive(page);
      await clickMessageTab(page, T.text);
      const locator = await findTextInput(page, options);
      await clickLocatorForVisual(page, locator, { timeout: 5000 });
      await clearFocusedInput(page);
      await page.keyboard.insertText(text);
      await page.waitForTimeout(100);
    },
    async clearTextInput() {
      const locator = await findTextInput(page, options);
      await clickLocatorForVisual(page, locator, { timeout: 5000 });
      await clearFocusedInput(page);
    },
    async readTextInput() {
      const locator = await findTextInput(page, options);
      return readLocatorText(locator);
    },
    async writeClipboardText(text) {
      await page.evaluate(async (value) => {
        await navigator.clipboard.writeText(value);
      }, text);
    },
    async pasteText() {
      const locator = await findTextInput(page, options);
      await clickLocatorForVisual(page, locator, { timeout: 5000 });
      await page.keyboard.press(process.platform === "darwin" ? "Meta+V" : "Control+V");
      await page.waitForTimeout(150);
    },
    async fillFinderFeedInput(text) {
      await ensureCmsPageAlive(page);
      await clickMessageTab(page, T.finder);
      const locator = await findFinderFeedInput(page, options);
      await clickLocatorForVisual(page, locator, { timeout: 5000 });
      await clearFocusedInput(page);
      await page.keyboard.insertText(text);
      await page.waitForTimeout(100);
    },
    async clearFinderFeedInput() {
      await clickMessageTab(page, T.finder);
      const locator = await findFinderFeedInput(page, options);
      await clickLocatorForVisual(page, locator, { timeout: 5000 });
      await clearFocusedInput(page);
    },
    async readFinderFeedInput() {
      await clickMessageTab(page, T.finder);
      const locator = await findFinderFeedInput(page, options);
      return readLocatorText(locator);
    },
    async pasteFinderFeedText() {
      await clickMessageTab(page, T.finder);
      const locator = await findFinderFeedInput(page, options);
      await clickLocatorForVisual(page, locator, { timeout: 5000 });
      await page.keyboard.press(process.platform === "darwin" ? "Meta+V" : "Control+V");
      await page.waitForTimeout(150);
    },
    async uploadMediaFile(localPath, task) {
      await ensureCmsPageAlive(page);
      await fs.access(localPath).catch(() => {
        throw new Error(`第 ${task.index} 条本地素材不存在：${localPath}`);
      });
      await closePopups(page);
      if (task.type === "sticker") {
        await uploadStickerFile(page, localPath, task);
        await page.waitForTimeout(800);
        return;
      }
      await clickMessageTab(page, mediaTabLabel(task.type));
      await page.waitForTimeout(500);
      await uploadFile(page, localPath, task);
      await page.waitForTimeout(800);
    },
    async waitForMediaReady({ expectedStatus = T.ready, timeoutMs = 60000, taskType = "" }) {
      const start = Date.now();
      const limitMs = Math.min(timeoutMs || 60000, 60000);
      while (Date.now() - start < limitMs) {
        const compression = await findStickerCompressionConfirmPoint(page);
        if (compression.present && compression.point) {
          await page.mouse.click(compression.point.x, compression.point.y);
          await page.waitForTimeout(700);
          continue;
        }
        if (compression.present && !compression.point) {
          const text = compression.text || "未读取到可见文字";
          throw new Error(`媒体校验失败：压缩后上传弹窗没有找到“确认上传”按钮。弹窗内容：${text}`);
        }
        const mediaState = await readMediaReadyState(page, { expectedStatus, taskType });
        if (mediaState.ready) return true;
        await page.waitForTimeout(700);
      }
      return false;
    },
    async submitCurrentTask(task) {
      await ensureCmsPageAlive(page);
      let robotStatusRetryCount = 0;
      const submitOnce = async () => {
        await waitForSubmitUiSettled(page, {
          timeoutMs: options.submitUiSettleTimeoutMs || 5000,
          taskIndex: task.index
        });
        await assertCurrentEditorContentPresent(page, task, {
          mediaReadyTimeoutMs: options.submitMediaReadyTimeoutMs || options.mediaReadyTimeoutMs || 60000
        });
        const responseErrors = collectSubmitResponseErrors(page);
        const expiredSchedule = { confirmed: false, originalTime: "", dialogText: "" };
        try {
          const confirmExpiredScheduleDialog = async (expired) => {
            if (!expired.confirmPoint) {
              throw new Error(`第 ${task.index} 条出现过期定时弹窗，但没有找到“是”按钮，已停止。弹窗内容：${expired.text || "未读取到弹窗文字"}`);
            }
            await page.mouse.click(expired.confirmPoint.x, expired.confirmPoint.y);
            await page.waitForTimeout(700);
            expiredSchedule.confirmed = true;
            expiredSchedule.originalTime = expired.time || task.time || "";
            expiredSchedule.dialogText = expired.text || "";
            return true;
          };
          const openConfirmDialog = async () => {
            await ensureSelectedRobotAvailableBeforeExecute(page, task, {
              policy: options.robotNotInGroupPolicy || "ignore",
              maxRetries: options.robotNotInGroupMaxRetries || 5,
              switchRobot: async ({ attempt, candidate, statusText }) => {
                if (typeof this.switchRobot !== "function") {
                  throw new Error(`第 ${task.index} 条执行发送前检测到机器人不在群，但当前页面不支持“更换机器人”，已停止。页面状态：${statusText || ""}`);
                }
                return this.switchRobot(task, { attempt, reason: "visible-robot-not-in-group", candidate, statusText });
              },
              log: options.policyLog
            });
            const execute = await findActionTextPoint(page, [T.execute]);
            if (!execute) throw new Error(`第 ${task.index} 条没有找到“执行发送”按钮。`);
            await page.mouse.click(execute.x, execute.y);
            const blockedByMedia = await waitForSubmitMediaNotReadyNotice(page, { timeoutMs: 900 });
            if (blockedByMedia.present && ["image", "sticker", "video"].includes(task.type)) {
              const mediaState = await waitForCurrentEditorMediaReady(page, task, {
                timeoutMs: options.submitMediaReadyRetryTimeoutMs || options.submitMediaReadyTimeoutMs || options.mediaReadyTimeoutMs || 60000
              });
              if (!mediaState.ready) {
                const visibleText = mediaState.text ? ` 可见文字：${mediaState.text}` : "";
                throw new Error(`第 ${task.index} 条点击执行发送后提示素材未就绪，等待后仍没有变成绿色“${T.ready}”。原因：${mediaState.reason || "没有检测到绿色可用状态"}${visibleText}`);
              }
              const retryExecute = await findActionTextPoint(page, [T.execute]);
              if (!retryExecute) throw new Error(`第 ${task.index} 条素材变为极速就绪后，没有重新找到“执行发送”按钮。页面提示：${blockedByMedia.text || ""}`);
              await page.mouse.click(retryExecute.x, retryExecute.y);
            }
            const confirmTimeoutMs = options.submitConfirmTimeoutMs || 5000;
            const first = await waitForSubmitGateDialog(page, { timeoutMs: confirmTimeoutMs });
            if (first.expiredSchedule) {
              await confirmExpiredScheduleDialog(first);
              const afterExpired = await waitForAnySubmitConfirmDialog(page, { timeoutMs: 1800 });
              return afterExpired.present ? afterExpired : { present: false, expiredScheduleConfirmed: true, text: first.text };
            }
            return first.present ? first : await waitForLatestSubmitConfirmDialog(page, { timeoutMs: Math.min(confirmTimeoutMs, 3000) });
          };
          let confirm = await openConfirmDialog();
          if (!confirm.present && !expiredSchedule.confirmed) {
            const missingRobot = await readMissingWechatRobotPrompt(page);
            if (missingRobot.present) {
              const error = new Error(`第 ${task.index} 条提交前提示“请选择微信机器人”，准备重新搜索并勾选机器人。${missingRobot.text ? `页面提示：${missingRobot.text}` : ""}`);
              error.code = "MISSING_WECHAT_ROBOT_SELECTION";
              error.promptText = missingRobot.text || "";
              throw error;
            }
            throw new Error(`第 ${task.index} 条没有找到新的“确认创建”弹窗，已停在提交确认前。`);
          }
          if (confirm.present) {
            const robotNotInGroupPolicy = options.robotNotInGroupPolicy || "ignore";
            const applyRobotNotInGroupPolicy = async (dialog) => {
              const policyResult = await handleRobotNotInGroup({
                page,
                role: task.role,
                task,
                policy: robotNotInGroupPolicy,
                maxRetries: options.robotNotInGroupMaxRetries || 5,
                switchRobot: async ({ attempt, candidate }) => {
                  if (typeof this.switchRobot !== "function") {
                    throw new Error(`第 ${task.index} 条检测到机器人不在群，但当前页面不支持“更换机器人”，已停止。`);
                  }
                  return this.switchRobot(task, { attempt, reason: "robot-not-in-group", candidate });
                },
                openConfirmDialog,
                getCurrentSelection: () => readCurrentCmsSelection(page),
                log: options.policyLog,
                initialDialog: dialog
              });
              if (policyResult.needStop) throw new Error(policyResult.message);
              if (policyResult.canSubmit === false) {
                throw new Error(policyResult.message || `第 ${task.index} 条检测到机器人不在群，已停止确认创建。`);
              }
              return policyResult.dialog || dialog;
            };
            confirm = await applyRobotNotInGroupPolicy(confirm);
            const latestConfirm = await readSubmitConfirmDialog(page);
            if (latestConfirm.present) {
              if (String(robotNotInGroupPolicy) === "switch_robot" && latestConfirm.robotNotInGroup) {
                confirm = await applyRobotNotInGroupPolicy(latestConfirm);
              } else {
                confirm = latestConfirm;
              }
            }
            assertSingleRobotSubmitConfirm(task, confirm);
            const confirmPoint = confirm.confirmPoint || confirm.point;
            if (!confirmPoint) {
              const text = confirm.text || "未读取到弹窗可见文字";
              throw new Error(`第 ${task.index} 条确认弹窗内没有找到蓝色“确认创建”按钮，已停止。弹窗内容：${text}`);
            }
            responseErrors.markSubmitClick?.();
            await page.mouse.click(confirmPoint.x, confirmPoint.y);
          }

          let success = await waitForSubmitCompletion(page, {
            timeoutMs: options.submitFastResultTimeoutMs || 900,
            pollMs: 180,
            responseErrors: responseErrors.errors
          });
          if (success.expiredSchedule) {
            await confirmExpiredScheduleDialog(success.dialog);
            success = await waitForSubmitCompletion(page, {
              timeoutMs: options.submitSuccessTimeoutMs || 12000,
              responseErrors: responseErrors.errors
            });
          }
          if (!success.ok && !success.failed) {
            const stillOpen = await findLatestSubmitConfirmDialog(page);
            if (stillOpen.present && stillOpen.point) {
              assertSingleRobotSubmitConfirm(task, stillOpen);
              const progress = await readSubmitInProgressEvidence(page, responseErrors);
              if (progress.active) {
                success = await waitForSubmitCompletion(page, {
                  timeoutMs: options.submitSuccessTimeoutMs || 12000,
                  responseErrors: responseErrors.errors
                });
                if (success.expiredSchedule) {
                  await confirmExpiredScheduleDialog(success.dialog);
                  success = await waitForSubmitCompletion(page, {
                    timeoutMs: options.submitSuccessTimeoutMs || 12000,
                    responseErrors: responseErrors.errors
                  });
                }
              } else {
                responseErrors.markSubmitClick?.();
                await page.mouse.click(stillOpen.point.x, stillOpen.point.y);
                success = await waitForSubmitCompletion(page, {
                  timeoutMs: options.submitSuccessTimeoutMs || 12000,
                  responseErrors: responseErrors.errors
                });
                if (success.expiredSchedule) {
                  await confirmExpiredScheduleDialog(success.dialog);
                  success = await waitForSubmitCompletion(page, {
                    timeoutMs: options.submitSuccessTimeoutMs || 12000,
                    responseErrors: responseErrors.errors
                  });
                }
              }
            } else if (stillOpen.present && !stillOpen.point) {
              const text = stillOpen.text || "未读取到弹窗可见文字";
              throw new Error(`第 ${task.index} 条确认弹窗仍未关闭，且没有可点击的蓝色“确认创建”按钮。弹窗内容：${text}`);
            } else {
              success = await waitForSubmitCompletion(page, {
                timeoutMs: options.submitSuccessTimeoutMs || 12000,
                responseErrors: responseErrors.errors
              });
            }
          }
          if (success.failed) throw new Error(`第 ${task.index} 条提交失败：${success.message}`);
          if (!success.ok) throw new Error(`第 ${task.index} 条提交后未检测到创建成功：${success.message}`);
          const editable = await waitForPageEditableAfterSubmit(page, {
            timeoutMs: options.submitEditableTimeoutMs || 8000
          });
          return {
            ok: true,
            successDetected: success.ok,
            pageEditableAfterSubmit: editable.ok,
            editableWarning: editable.ok ? "" : `已检测到创建成功，但页面暂未回到可编辑状态：${editable.message}`,
            expiredScheduleConfirmed: expiredSchedule.confirmed,
            expiredSchedule: expiredSchedule.confirmed ? {
              originalTime: expiredSchedule.originalTime,
              dialogText: expiredSchedule.dialogText
            } : null
          };
        } finally {
          responseErrors.dispose();
        }
      };

      let robotSelectionRecoveryCount = 0;
      while (true) {
        try {
          const result = await submitOnce();
          return {
            ...result,
            ...(robotSelectionRecoveryCount ? { robotSelectionRecoveryCount } : {}),
            ...(robotStatusRetryCount ? { robotStatusRetryCount } : {})
          };
        } catch (error) {
          const message = error?.message || String(error);
          if (robotSelectionRecoveryCount < 1 && isMissingWechatRobotSelectionError(error)) {
            robotSelectionRecoveryCount += 1;
            await recoverMissingWechatRobotSelection(page, task, {
              timeoutMs: options.robotSwitchTimeoutMs || 8000,
              promptText: error.promptText || message
            });
            await page.waitForTimeout(500);
            continue;
          }
          if (robotSelectionRecoveryCount && isMissingWechatRobotSelectionError(error)) {
            throw new Error(`第 ${task.index} 条提示“请选择微信机器人”，已重新清空关键词、重新搜索并勾选一次后仍失败，请人工检查当前机器人是否真正勾选。原始失败：${message}`);
          }
          if (robotStatusRetryCount < 1 && isRobotStatusSubmitFailure(message)) {
            robotStatusRetryCount += 1;
            if (typeof this.switchRobot !== "function") {
              throw new Error(`第 ${task.index} 条提交后检测到机器人掉线/状态异常，但当前页面不支持“更换机器人”，已停止。原始失败：${message}`);
            }
            await this.switchRobot(task, {
              attempt: robotStatusRetryCount,
              reason: "submit-robot-status-failure",
              submitFailureMessage: message
            });
            await page.waitForTimeout(500);
            continue;
          }
          if (robotStatusRetryCount) {
            throw new Error(`第 ${task.index} 条提交后检测到机器人掉线/状态异常，已更换机器人重试一次仍失败：${message}`);
          }
          throw error;
        }
      }
    },
    async assertCurrentEditorContentPresent(task) {
      await assertCurrentEditorContentPresent(page, task);
    },
    async assertCreatePageConfigured(task) {
      await assertCreatePageConfigured(page, task);
    },
    async readStickerAreaText() {
      const state = await readStickerAreaState(page);
      return state.text || "";
    },
    async assertNoRealSubmit() {
      return true;
    }
  };
}

async function ensureSelectedRobotAvailableBeforeExecute(page, task, options = {}) {
  const normalizedPolicy = String(options.policy || "ignore");
  const first = await readSelectedRobotAvailability(page);
  if (!first.notInGroup) return first;
  if (normalizedPolicy !== "switch_robot") {
    throw new Error(`第 ${task.index} 条执行发送前检测到机器人不在群，已停止，不会点击执行发送。请改为“自动更换机器人后再创建”或手动换机器人。页面状态：${first.text || first.reason || ""}`);
  }
  const limit = Math.max(1, Number(options.maxRetries || 5));
  let lastState = first;
  for (let attempt = 1; attempt <= limit; attempt += 1) {
    const candidate = nextRobotCandidate(task, attempt);
    await options.log?.({
      event: "visible_robot_not_in_group_retry",
      taskIndex: task?.index,
      role: task?.role,
      speaker: task?.speaker || task?.cleanSpeaker || "",
      attempt,
      candidate,
      statusText: lastState.text || lastState.reason || ""
    });
    await options.switchRobot?.({ attempt, candidate, statusText: lastState.text || lastState.reason || "" });
    if (typeof page.waitForTimeout === "function") await page.waitForTimeout(500);
    lastState = await readSelectedRobotAvailability(page);
    if (!lastState.notInGroup) {
      await options.log?.({
        event: "visible_robot_not_in_group_switched",
        taskIndex: task?.index,
        role: task?.role,
        speaker: task?.speaker || task?.cleanSpeaker || "",
        attempt,
        candidate,
        statusText: lastState.text || ""
      });
      return lastState;
    }
  }
  await showManualRobotSwitchNotice(page, limit);
  throw new Error(`第 ${task.index} 条执行发送前连续 ${limit} 次更换机器人后仍显示不在群，已停止，不会点击执行发送。页面状态：${lastState.text || lastState.reason || ""}`);
}

async function readSelectedRobotAvailability(page) {
  if (!page || typeof page.evaluate !== "function") return { notInGroup: false, text: "", reason: "无法读取页面" };
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const badRobotState = (text) => /机器人.{0,40}(不在群|不在本群|不可用|离线|异常)|不在群|不在本群/.test(compact(text));
    const selectedMarkers = Array.from(document.querySelectorAll("input[type='checkbox']:checked,.el-checkbox.is-checked,.el-checkbox__input.is-checked,[aria-checked='true']"))
      .filter((el) => visible(el) || visible(el.closest?.("tr,.el-table__row,li,div")));
    const rowTexts = [];
    for (const marker of selectedMarkers) {
      const containers = [
        marker.closest?.("tr"),
        marker.closest?.(".el-table__row"),
        marker.closest?.("li"),
        marker.closest?.("[class*='row']"),
        marker.parentElement?.closest?.("tr,.el-table__row,li,[class*='row']")
      ].filter(Boolean);
      for (const container of containers) {
        const text = compact(container.innerText || container.textContent);
        if (!text || text.length > 800) continue;
        rowTexts.push(text);
        break;
      }
    }
    const badRow = rowTexts.find((text) => badRobotState(text));
    if (badRow) return { notInGroup: true, text: badRow.slice(0, 500), source: "selected-row" };

    const body = compact(document.body?.innerText || document.body?.textContent || "");
    const robotSection = body.match(/机器人\s*[（(]\s*已选[\s\S]{0,600}?(?:执行发送设置|群\s*[（(]\s*已选|$)/)?.[0] || "";
    if (badRobotState(robotSection)) return { notInGroup: true, text: robotSection.slice(0, 500), source: "robot-section" };
    return { notInGroup: false, text: rowTexts.slice(0, 3).join(" / ") || robotSection.slice(0, 300), source: rowTexts.length ? "selected-row" : "robot-section" };
  }).catch((error) => ({ notInGroup: false, text: "", reason: error?.message || String(error) }));
}

function assertSingleRobotSubmitConfirm(task, dialog = {}) {
  const count = Number.isFinite(Number(dialog.robotCount))
    ? Number(dialog.robotCount)
    : parseSubmitConfirmRobotCount(dialog.text);
  if (Number.isFinite(count) && count > 1) {
    const text = dialog.text || "未读取到弹窗文字";
    throw new Error(`第 ${task?.index ?? "?"} 条确认弹窗显示已选择 ${count} 个机器人，已暂停当前批次，不会点击“确认创建”。请先只保留 1 个机器人。弹窗内容：${text}`);
  }
}

async function readMissingWechatRobotPrompt(page) {
  if (!page || typeof page.evaluate !== "function") return { present: false, text: "" };
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const promptPattern = /请选择微信机器人|请选择.*机器人/;
    const selectors = [
      ".el-message",
      ".el-notification",
      ".toast",
      ".ivu-message",
      ".ant-message",
      ".el-form-item__error",
      "[class*='error']",
      "[class*='message']"
    ].join(",");
    const texts = Array.from(document.querySelectorAll(selectors))
      .filter(visible)
      .map((el) => compact(el.innerText || el.textContent))
      .filter(Boolean);
    const matched = texts.find((text) => promptPattern.test(text));
    if (matched) return { present: true, text: matched.slice(0, 300) };
    const bodyText = compact(document.body?.innerText || document.body?.textContent || "");
    const bodyMatch = bodyText.match(/[^。！？\n\r]{0,30}请选择微信机器人[^。！？\n\r]{0,30}/);
    return bodyMatch ? { present: true, text: bodyMatch[0].slice(0, 300) } : { present: false, text: "" };
  }).catch((error) => ({ present: false, text: error?.message || "" }));
}

export async function resetCmsEditorForOneTask(page, options = {}) {
  await ensureCmsPageAlive(page);
  await closePopups(page);
  if (!await pageLooksLikeCreateForm(page)) {
    throw new Error("没有看到云中客创建任务核心元素，已停止。请确认当前页仍是已登录、已选好群和机器人的创建任务页。");
  }
  if (options.skipPageReset === true) return { reloaded: false, skipped: true };
  const cleared = await clearScriptEditorInputs(page);
  await page.waitForTimeout(options.waitMs || 300).catch(() => {});
  return {
    reloaded: false,
    cleared,
    scriptList: await readScriptContentListState(page)
  };
}

async function clearScriptEditorInputs(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = typeof getComputedStyle === "function" ? getComputedStyle(el) : { visibility: "visible", display: "block" };
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const roots = Array.from(document.querySelectorAll(".drama-content,.drama-item,[class*='drama-content'],[class*='drama-item']"))
      .filter(visible);
    let textInputs = 0;
    let fileInputs = 0;
    const dispatch = (el) => {
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    };
    for (const root of roots) {
      for (const el of Array.from(root.querySelectorAll("textarea,input:not([type='file']),[contenteditable='true']"))) {
        if (!visible(el)) continue;
        if (el.isContentEditable) {
          el.textContent = "";
        } else {
          el.value = "";
        }
        dispatch(el);
        textInputs += 1;
      }
      for (const input of Array.from(root.querySelectorAll("input[type='file']"))) {
        input.value = "";
        dispatch(input);
        fileInputs += 1;
      }
    }
    return { textInputs, fileInputs };
  }).catch((error) => ({ textInputs: 0, fileInputs: 0, error: error?.message || String(error) }));
}

export async function readCurrentCmsSelection(page) {
  await ensureCmsPageAlive(page);
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const body = document.body?.innerText || "";
    const lines = body.split(/\n+/).map(compact).filter(Boolean);
    const fallback = (type) => `未识别，请以当前云中客页面已选${type}为准`;
    const readRemark = () => {
      const inputs = Array.from(document.querySelectorAll("textarea,input"))
        .filter((el) => visible(el));
      for (const el of inputs) {
        const around = compact([
          el.getAttribute("placeholder") || "",
          el.closest?.("label,.el-form-item,div")?.innerText || "",
          el.parentElement?.innerText || ""
        ].join(" "));
        if (!around.includes("任务备注")) continue;
        return compact(el.value || el.innerText || el.textContent);
      }
      return "";
    };
    const readSwitchState = (label) => {
      const labels = Array.from(document.querySelectorAll("label,span,div"))
        .filter((el) => visible(el) && compact(el.innerText || el.textContent) === label);
      const switches = Array.from(document.querySelectorAll(".el-switch,[role='switch'],input[type='checkbox']"))
        .filter((item) => visible(item) || visible(item.closest?.(".el-switch,label,div")));
      const switchState = (item) => {
        if (item.matches?.("input[type='checkbox']")) return Boolean(item.checked);
        if (item.getAttribute?.("aria-checked") === "true") return true;
        if (item.getAttribute?.("aria-checked") === "false") return false;
        const classText = String(item.className || item.closest?.(".el-switch")?.className || "");
        return /\bis-checked\b/.test(classText);
      };
      for (const labelEl of labels) {
        const labelRect = labelEl.getBoundingClientRect?.();
        const nearby = switches
          .map((item) => {
            const rect = item.getBoundingClientRect?.() || item.closest?.(".el-switch,label,div")?.getBoundingClientRect?.();
            if (!labelRect || !rect) return null;
            const vertical = Math.abs((rect.top + rect.bottom) / 2 - (labelRect.top + labelRect.bottom) / 2);
            const horizontal = rect.left - labelRect.right;
            if (vertical > 28 || horizontal < -12) return null;
            return { item, score: vertical * 10 + Math.abs(horizontal) };
          })
          .filter(Boolean)
          .sort((a, b) => a.score - b.score);
        if (nearby[0]) return switchState(nearby[0].item);
        const root = labelEl.parentElement?.parentElement || labelEl.parentElement;
        const scoped = root
          ? switches.find((item) => root.contains?.(item) && compact(root.innerText || root.textContent).includes(label))
          : null;
        if (scoped) return switchState(scoped);
      }
      return null;
    };
    const rowTextsFromChecked = (type) => {
      const markers = Array.from(document.querySelectorAll("input[type='checkbox']:checked,.el-checkbox.is-checked,.el-checkbox__input.is-checked,[aria-checked='true']"))
        .filter((el) => visible(el) || visible(el.closest?.("tr,.el-table__row,li,div")));
      const rows = [];
      for (const marker of markers) {
        const containers = [
          marker.closest?.("tr"),
          marker.closest?.(".el-table__row"),
          marker.closest?.("li"),
          marker.closest?.("[class*='row']"),
          marker.parentElement?.closest?.("tr,.el-table__row,li,[class*='row']")
        ].filter(Boolean);
        for (const container of containers) {
          const text = compact(container.innerText || container.textContent);
          if (!text || text.length > 500) continue;
          if (isBlockedSelectedRow(text)) continue;
          const cleaned = type === "group" ? cleanupGroup(text) : cleanupRobot(text);
          if (!cleaned) continue;
          if (type === "group" && looksLikeGroup(cleaned)) rows.push(cleaned);
          if (type === "robot" && looksLikeRobot(cleaned)) rows.push(cleaned);
          break;
        }
      }
      return uniqueTexts(rows).join("、");
    };
    const lineSection = (startPattern, endPattern) => {
      const start = lines.findIndex((line) => startPattern.test(line));
      if (start < 0) return "";
      const endOffset = lines.slice(start + 1).findIndex((line) => endPattern.test(line));
      const end = endOffset >= 0 ? start + 1 + endOffset : lines.length;
      return lines.slice(start + 1, end).join("\n");
    };
    const usefulLine = (sectionText, type) => {
      const sectionLines = sectionText.split(/\n+/).map(compact).filter(Boolean);
      const blocked = [
        "群(已选", "群 (已选", "机器人(已选", "机器人 (已选", "导出群聊", "屏蔽群", "显示选中项", "刷新",
        "排序", "默认排序", "关键词", "请选择分组", "配置", "包含分组", "群聊",
        "执行发送设置", "购买云中客", "创建任务", "首页", "更多"
      ];
      const candidates = sectionLines.filter((line) => {
        if (blocked.some((word) => line.includes(word))) return false;
        if (type === "group") return looksLikeGroup(line);
        return looksLikeRobot(line);
      });
      for (const candidate of candidates) {
        const cleaned = type === "group" ? cleanupGroup(candidate) : cleanupRobot(candidate);
        if (cleaned && cleaned !== "机器人") return cleaned;
      }
      return "";
    };
    const uniqueTexts = (items) => Array.from(new Set(items.map(compact).filter(Boolean)));
    const isBlockedSelectedRow = (text) => /^(ID|快捷分组|备注|排序|机器人|更多设置)$/.test(text) ||
      /ID\s+快捷分组\s+备注\s*排序\s*机器人|更多设置|显示选中项|发送后换|同分组去重|关键词搜索|请选择分组|默认排序/.test(text);
    const looksLikeGroup = (text) => /群成员|群聊|群:|群：|群#|老群|A\d+|采集/.test(text) && !/机器人\s*[（(]\s*已选|执行发送|发送模式/.test(text);
    const looksLikeRobot = (text) => /群\d+|宝妈|豆妈|托|小姐姐|机器人|女性|男性|母亲|动漫|SVIP|唯你/.test(text) && !/群\s*[（(]已选|执行发送|发送模式/.test(text);
    const cleanupGroup = (text) => {
      let value = compact(text)
        .replace(/^群聊\s*/, "")
        .replace(/^\d+[,，.\s]*(?:\.\.\.)?\s*/, "")
        .replace(/^ID\s*/, "");
      value = value.split(/\s+(?:机器人|更多设置)\b/)[0] || value;
      value = value.split(/\s+[（(]\d+\/\d+\s*在线/)[0] || value;
      value = value.replace(/\s*配置$/, "").trim();
      return isBlockedSelectedRow(value) ? "" : value;
    };
    const cleanupRobot = (text) => {
      const source = compact(text).replace(/^机器人\s*[（(]?\d*[）)]?\s*/, "").replace(/\s*配置$/, "");
      const onlineMatch = source.match(/[（(]\d+\/\d+\s*在线[:：]?\s*\d*[）)]?\s*(.+)$/);
      const value = compact(onlineMatch?.[1] || source)
        .replace(/\s+\d+$/, "")
        .replace(/^机器人\s*/, "")
        .replace(/\s*配置$/, "");
      return isBlockedSelectedRow(value) ? "" : value;
    };
    const groupSection = lineSection(/^群\s*[（(]\s*已选/i, /^机器人\s*[（(]\s*已选/i);
    const robotSection = lineSection(/^机器人\s*[（(]\s*已选/i, /^(执行发送设置|当前分组|群顺序)/i);
    const group = rowTextsFromChecked("group") || usefulLine(groupSection, "group");
    const robot = rowTextsFromChecked("robot") || usefulLine(robotSection, "robot");
    const selectedCounts = lines.filter((line) => /已选\s*\d+/.test(line));
    return {
      group: group || fallback("群"),
      robot: robot || fallback("机器人"),
      taskRemark: readRemark(),
      multiQuickMode: readSwitchState("多快捷模式"),
      selectedCounts
    };
  }).catch(() => ({
    group: "未识别，请以当前云中客页面已选群为准",
    robot: "未识别，请以当前云中客页面已选机器人为准",
    taskRemark: "",
    multiQuickMode: null,
    selectedCounts: []
  }));
}

export async function assertCreatePageConfigured(page, task = {}) {
  const state = await readCmsCreateConfigState(page);
  if (state.ok) return state;
  const details = state.reason ? ` 原因：${state.reason}` : "";
  throw new Error(`第 ${task.index} 条：对应页面未选好群/机器人，已停止，不会上传素材/执行发送。${details}`);
}

export async function readCmsCreateConfigState(page) {
  await ensureCmsPageAlive(page);
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = typeof getComputedStyle === "function" ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && (!s || (s.visibility !== "hidden" && s.display !== "none"));
    };
    const targetAreaText = () => {
      const body = document.body?.innerText || "";
      const end = body.search(/执行发送设置|编辑剧本内容|编辑脚本内容|任务备注/);
      return compact(end >= 0 ? body.slice(0, end) : body);
    };
    const selectedMarkers = Array.from(document.querySelectorAll("input[type='checkbox']:checked,.el-checkbox.is-checked,.el-checkbox__input.is-checked,[aria-checked='true']"))
      .filter((el) => visible(el) || visible(el.closest?.("tr,.el-table__row,li,div")));
    const rows = [];
    for (const marker of selectedMarkers) {
      const containers = [
        marker.closest?.("tr"),
        marker.closest?.(".el-table__row"),
        marker.closest?.("li"),
        marker.closest?.("[class*='row']"),
        marker.parentElement?.closest?.("tr,.el-table__row,li,[class*='row']")
      ].filter(Boolean);
      for (const container of containers) {
        const text = compact(container.innerText || container.textContent);
        if (!text || text.length > 800) continue;
        if (/执行发送|任务备注|编辑脚本|添加单条|添加多条|添加附加消息|发送后清空/.test(text)) continue;
        rows.push(text);
        break;
      }
    }
    const uniqueRows = Array.from(new Set(rows));
    const hasTargetRow = uniqueRows.some((text) => /群|L\d+|W\d+|M\d+|C\d+|成员/.test(text));
    const hasRobotInRow = uniqueRows.some((text) => /机器人|在线|个微|企微|宝妈|豆妈|托|小姐姐|男性|女性|号/.test(text));
    const area = targetAreaText();
    const statisticOnly = /已选\s*\d+\s*\/\s*\d+/.test(area) && uniqueRows.length === 0;
    if (hasTargetRow && hasRobotInRow) {
      return {
        ok: true,
        selectedRows: uniqueRows,
        groupReady: true,
        robotReady: true
      };
    }
    if (statisticOnly) {
      return {
        ok: false,
        selectedRows: uniqueRows,
        groupReady: false,
        robotReady: false,
        reason: "只看到已选数量统计，没有检测到实际勾选的群/机器人行"
      };
    }
    return {
      ok: false,
      selectedRows: uniqueRows,
      groupReady: hasTargetRow,
      robotReady: hasRobotInRow,
      reason: uniqueRows.length
        ? `实际勾选行未同时包含可用群和机器人：${uniqueRows.slice(0, 3).join(" / ")}`
        : "没有检测到实际勾选的群/机器人行"
    };
  }).catch((error) => ({
    ok: false,
    selectedRows: [],
    groupReady: false,
    robotReady: false,
    reason: error?.message || "无法读取页面群/机器人配置"
  }));
}

export function isCmsPageUrl(url, targetUrl = "") {
  const value = String(url || "");
  if (!/iyunzk\.com|cms/i.test(value)) return false;
  if (!targetUrl) return true;
  try {
    return new URL(value).origin === new URL(targetUrl).origin;
  } catch {
    return true;
  }
}

function roleTargetForTask(task, config, options) {
  const explicit = options.roleTargets?.[task.role];
  if (explicit !== undefined) return explicit;
  if (config.tuoMode && config.tuoMode !== "fixed") return "";
  if (task.role === "douma") return config.roles?.douma?.fixedRolePrefix || config.roles?.douma?.tabLabel || "豆妈";
  if (task.role === "tuo") return config.roles?.tuo?.fixedRolePrefix || "";
  return "";
}

function shouldPreSwitchTuoRobot(options = {}) {
  const policy = options.robotNotInGroupPolicy || options.config?.robotNotInGroupPolicy || "ignore";
  return String(policy) === "switch_robot";
}

function tuoRobotSwitchDecision(task, stateOrPreviousIdentity) {
  const state = stateOrPreviousIdentity?.tuoSpeakerIdentities ? stateOrPreviousIdentity : null;
  const previousIdentity = state ? state.lastTuoIdentity : stateOrPreviousIdentity;
  const currentIdentity = tuoIdentityForTask(task, state);
  if (task.role !== "tuo") {
    return { shouldSwitch: false, currentIdentity, previousIdentity, reason: "not-tuo" };
  }
  if (!previousIdentity?.key) {
    return {
      shouldSwitch: Boolean(currentIdentity.precise),
      currentIdentity,
      previousIdentity,
      reason: currentIdentity.precise ? "first-precise-tuo" : "first-tuo"
    };
  }
  const shouldSwitch = Boolean(currentIdentity.key && !sameTuoIdentity(currentIdentity, previousIdentity));
  return {
    shouldSwitch,
    currentIdentity,
    previousIdentity,
    reason: shouldSwitch ? "tuo-identity-changed" : "same-tuo-identity"
  };
}

function tuoIdentityForTask(task = {}, state = null) {
  const interactionGroup = String(task.interactionGroup || "").trim();
  const cleanSpeaker = cleanTuoSpeaker(task.cleanSpeaker || task.speaker || "");
  const speakerKey = normalizeTuoIdentity(cleanSpeaker || task.speaker || "");
  const preciseCandidate = firstPreciseTuoCandidate(task);
  const speakerIdentity = speakerKey ? state?.tuoSpeakerIdentities?.get(speakerKey) : null;
  const interactionIdentity = interactionGroup ? state?.tuoInteractionIdentities?.get(interactionGroup) : null;
  if (interactionIdentity) {
    return {
      ...interactionIdentity,
      speakerKey: interactionIdentity.speakerKey || speakerKey,
      interactionGroup,
      label: `${cleanSpeaker || task.speaker || interactionIdentity.label || "托"} / ${interactionGroup}`
    };
  }
  if (interactionGroup && speakerIdentity) {
    return {
      ...speakerIdentity,
      speakerKey,
      interactionGroup,
      precise: Boolean(speakerIdentity.precise || preciseCandidate?.nickname),
      candidate: speakerIdentity.candidate || preciseCandidate || null,
      label: `${cleanSpeaker || task.speaker || speakerIdentity.label || "托"} / ${interactionGroup}`
    };
  }
  if (interactionGroup) {
    return {
      key: `interaction:${interactionGroup}`,
      speakerKey,
      interactionGroup,
      label: `${cleanSpeaker || task.speaker || "托"} / ${interactionGroup}`,
      precise: Boolean(preciseCandidate?.nickname),
      candidate: preciseCandidate
    };
  }
  return {
    key: `speaker:${speakerKey}`,
    speakerKey,
    interactionGroup,
    label: cleanSpeaker || task.speaker || "托",
    precise: Boolean(preciseCandidate?.nickname),
    candidate: preciseCandidate
  };
}

function rememberTuoIdentity(state, identity = {}) {
  if (!state || !identity.key) return;
  state.lastTuoIdentity = identity;
  if (identity.speakerKey && !state.tuoSpeakerIdentities.has(identity.speakerKey)) {
    state.tuoSpeakerIdentities.set(identity.speakerKey, identity);
  }
  if (identity.interactionGroup && !state.tuoInteractionIdentities.has(identity.interactionGroup)) {
    state.tuoInteractionIdentities.set(identity.interactionGroup, identity);
  }
}

function resolveSelectedTuoIdentity(identity = {}, switchResult = {}) {
  const candidate = switchResult?.candidate?.nickname ? switchResult.candidate : identity.candidate;
  if (!candidate?.nickname) return identity;
  const label = identity.interactionGroup
    ? `${candidate.nickname} / ${identity.interactionGroup}`
    : candidate.nickname;
  return {
    ...identity,
    candidate,
    label,
    precise: true
  };
}

function sameTuoIdentity(currentIdentity = {}, previousIdentity = {}) {
  if (currentIdentity.key && currentIdentity.key === previousIdentity.key) return true;
  if (
    currentIdentity.interactionGroup &&
    previousIdentity.interactionGroup &&
    currentIdentity.interactionGroup === previousIdentity.interactionGroup
  ) {
    return true;
  }
  if (currentIdentity.speakerKey && previousIdentity.speakerKey && currentIdentity.speakerKey === previousIdentity.speakerKey) {
    return true;
  }
  return false;
}

function cleanTuoSpeaker(value) {
  return String(value || "")
    .replace(/[（(【\[][^）)】\]]*下面还说话[^）)】\]]*[）)】\]]/g, "")
    .replace(/下面还说话/g, "")
    .replace(/[，,。；;：:]+$/g, "")
    .trim();
}

function normalizeTuoIdentity(value) {
  return String(value || "").replace(/\s+/g, "").toLowerCase();
}

function extractRobotNicknameFromRowText(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (!text) return "";
  const parts = text.split(/[|｜]/).map((part) => part.trim()).filter(Boolean);
  const raw = parts.length >= 2 ? parts[1] : text;
  return raw
    .replace(/[（(].*$/, "")
    .replace(/\s*(在线|离线|不在群|不在本群|不可用|异常).*$/, "")
    .replace(/\b\d+\s*$/, "")
    .trim();
}

function robotNicknameMatches(rowText, nickname) {
  const targetKey = normalizeTuoIdentity(nickname);
  if (!targetKey) return false;
  const nicknameKey = normalizeTuoIdentity(extractRobotNicknameFromRowText(rowText));
  return nicknameKey === targetKey;
}

function cssEscape(value) {
  return String(value || "").replace(/["\\]/g, "\\$&");
}

async function findChangeRobotPoint(page) {
  return findActionTextPoint(page, ["更换机器人", "随机更换机器人"]);
}

async function waitForRobotSwitchSettled(page, options = {}) {
  const timeoutMs = options.timeoutMs || 8000;
  const start = Date.now();
  const beforeRobot = normalizeRobotSelection(options.beforeSelection?.robot);
  const beforeRows = normalizeSelectedRows(options.beforeState?.selectedRows);
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    lastState = await readCmsCreateConfigState(page);
    const currentSelection = await readCurrentCmsSelection(page);
    const currentRobot = normalizeRobotSelection(currentSelection.robot);
    const currentRows = normalizeSelectedRows(lastState.selectedRows);
    const robotChanged = Boolean(beforeRobot && currentRobot && beforeRobot !== currentRobot);
    const rowsChanged = Boolean(beforeRows && currentRows && beforeRows !== currentRows);
    const becameReadable = Boolean(!beforeRobot && currentRobot);
    if (lastState.ok && (robotChanged || rowsChanged || becameReadable)) return true;
    await page.waitForTimeout(200);
  }
  const details = lastState?.reason ? ` 原因：${lastState.reason}` : "";
  throw new Error(`更换托机器人后没有检测到可用机器人，已停止。${details}`);
}

function normalizeRobotSelection(value) {
  const text = String(value || "").replace(/\s+/g, "").toLowerCase();
  if (!text || text.includes("未识别")) return "";
  return text;
}

function normalizeSelectedRows(rows = []) {
  return (rows || []).map((row) => String(row || "").replace(/\s+/g, " ").trim()).filter(Boolean).join("|");
}

function firstPreciseTuoCandidate(task = {}) {
  return preciseTuoCandidateSequence(task)[0] || null;
}

function isMissingWechatRobotSelectionError(error) {
  const message = error?.message || String(error || "");
  return error?.code === "MISSING_WECHAT_ROBOT_SELECTION" || /请选择微信机器人|请选择.*机器人/.test(message);
}

async function recoverMissingWechatRobotSelection(page, task = {}, context = {}) {
  if (task.role && task.role !== "tuo") {
    throw new Error(`第 ${task.index} 条提示“请选择微信机器人”，但当前不是托任务，无法按托名自动重选机器人。请人工检查当前页面机器人是否勾选。`);
  }
  const candidate = firstPreciseTuoCandidate(task) || {
    nickname: String(task.cleanSpeaker || task.speaker || "").trim()
  };
  const nickname = String(candidate.nickname || "").trim();
  if (!nickname) {
    throw new Error(`第 ${task.index} 条提示“请选择微信机器人”，但没有可用于重新搜索的托名，请人工检查当前页面机器人是否勾选。`);
  }
  await selectTuoRobotCandidate(page, candidate, task, {
    reason: "missing-wechat-robot-selection",
    timeoutMs: context.timeoutMs || 8000,
    fallbackAttempted: false
  });
  return { ok: true, nickname };
}

function preciseTuoCandidateSequence(task = {}) {
  if (task?.tuoAssignment?.mode !== "precise_roster" && !task?.tuoAssignment) return [];
  const candidates = Array.isArray(task?.tuoAssignment?.candidates) ? task.tuoAssignment.candidates : [];
  const primary = task?.tuoAssignment?.primary?.nickname ? task.tuoAssignment.primary : null;
  const selectedNames = [
    task.speaker,
    task.cleanSpeaker,
    primary?.nickname
  ].map((value) => String(value || "").trim()).filter(Boolean);
  const all = [primary, ...candidates].filter((item) => item?.nickname);
  const ordered = [];
  for (const name of selectedNames) {
    const matched = all.find((item) => normalizeTuoIdentity(item.nickname) === normalizeTuoIdentity(name));
    ordered.push(matched || { nickname: name });
  }
  ordered.push(...all);
  const seen = new Set();
  return ordered.filter((item) => {
    const key = normalizeTuoIdentity(item?.nickname || "");
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function selectTuoRobotCandidate(page, candidate = {}, task = {}, context = {}) {
  const candidates = preciseTuoCandidateFallbackSequence(task, candidate);
  const errors = [];
  for (const [index, nextCandidate] of candidates.entries()) {
    try {
      const result = await selectTuoRobotCandidateSingle(page, nextCandidate, task, context);
      const firstNickname = String(candidates[0]?.nickname || "").trim();
      const usedNickname = String(result?.candidate?.nickname || nextCandidate.nickname || "").trim();
      return {
        ...result,
        fallbackUsed: index > 0,
        fallbackFrom: index > 0 ? firstNickname : "",
        candidate: result?.candidate || nextCandidate,
        message: index > 0 && firstNickname
          ? `主托“${firstNickname}”不可用，已改用备用托“${usedNickname}”。`
          : result?.message || ""
      };
    } catch (error) {
      errors.push({ candidate: nextCandidate, error });
      if (!isRecoverablePreciseCandidateSelectionError(error) || index >= candidates.length - 1) {
        if (errors.length <= 1) throw error;
        throw buildPreciseCandidateSequenceError(task, errors);
      }
      await clearRobotKeywordSearch(page).catch(() => false);
    }
  }
  throw buildPreciseCandidateSequenceError(task, errors);
}

function preciseTuoCandidateFallbackSequence(task = {}, firstCandidate = {}) {
  const ordered = [];
  if (firstCandidate?.nickname) ordered.push(firstCandidate);
  ordered.push(...preciseTuoCandidateSequence(task));
  const seen = new Set();
  return ordered.filter((item) => {
    const key = normalizeTuoIdentity(item?.nickname || "");
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function isRecoverablePreciseCandidateSelectionError(error) {
  if (error?.code === "ROBOT_CANDIDATE_NOT_FOUND") return true;
  const message = error?.message || String(error || "");
  return /没有搜索到可勾选项|没有搜索到同身份托|没有找到机器人行|没有检测到“机器人（已选1\/总数）且目标机器人已勾选/.test(message);
}

function buildPreciseCandidateSequenceError(task = {}, errors = []) {
  const details = errors
    .map(({ candidate, error }) => `“${String(candidate?.nickname || "").trim() || "未命名"}”：${error?.message || error}`)
    .join("；");
  return new Error(`第 ${task.index} 条主托和备用托都不可用，已停止。${details}`);
}

async function selectTuoRobotCandidateSingle(page, candidate = {}, task = {}, context = {}) {
  const timing = createPreciseRobotTiming();
  const nickname = String(candidate.nickname || "").trim();
  if (!nickname) throw new Error(`第 ${task.index} 条需要按名单更换托，但候补托名称为空。`);
  const beforeStatus = await readRobotSelectionStatus(page, nickname);
  timing.mark("read-robot-selection-status", {
    selectedCount: beforeStatus.selectedCount,
    targetSelected: beforeStatus.targetSelected
  });
  const beforeRobot = robotSelectionStatusLabel(beforeStatus);
  if (robotSelectionAlreadyMatchesPreciseTuo(beforeStatus, nickname)) {
    task.speaker = nickname;
    task.cleanSpeaker = nickname;
    return {
      ok: true,
      candidate,
      before: beforeRobot,
      after: beforeRobot,
      changed: false,
      skipped: true,
      reason: "precise-target-already-selected",
      timings: timing.done("already-selected")
    };
  }
  if (beforeStatus.selectedCount > 1) {
    await recoverRobotSelectionForPreciseTuo(page, nickname, task, context, timing);
  } else if (beforeStatus.selectedCount === 1) {
    const selectedPoint = await findSelectedRobotCheckboxPoint(page);
    if (selectedPoint) {
      await page.mouse.click(selectedPoint.x, selectedPoint.y);
      timing.mark("clear-selected-click");
      try {
        await waitForRobotSelectionCleared(page, { timeoutMs: Math.min(context.timeoutMs || 8000, 450) });
        timing.mark("clear-selected-done");
      } catch (error) {
        const stillSelected = await findSelectedRobotCheckboxPoint(page);
        if (stillSelected) {
          await recoverRobotSelectionForPreciseTuo(page, nickname, task, { ...context, fallbackAttempted: true }, timing);
        }
      }
    } else {
      await recoverRobotSelectionForPreciseTuo(page, nickname, task, context, timing);
    }
  }
  await fillRobotKeywordSearch(page, nickname);
  timing.mark("search-filled");
  const candidatePoint = await waitForRobotCandidatePoint(page, nickname, {
    timeoutMs: Math.min(context.timeoutMs || 8000, 2000)
  });
  if (!candidatePoint) {
    const error = new Error(`第 ${task.index} 条需要更换同身份托“${nickname}”，但机器人列表没有搜索到可勾选项。`);
    error.code = "ROBOT_CANDIDATE_NOT_FOUND";
    throw error;
  }
  if (!candidatePoint.selected) {
    await page.mouse.click(candidatePoint.x, candidatePoint.y);
    timing.mark("candidate-clicked");
  } else {
    timing.mark("candidate-already-selected");
  }
  const candidateSelectedTimeoutMs = Math.min(context.timeoutMs || 8000, 1800);
  try {
    await waitForRobotCandidateSelected(page, nickname, {
      timeoutMs: candidateSelectedTimeoutMs
    });
    timing.mark("candidate-selected");
  } catch (error) {
    if (context.fallbackAttempted) throw error;
    if (error?.code === "ROBOT_MULTI_SELECTED") {
      await recoverRobotSelectionForPreciseTuo(page, nickname, task, { ...context, fallbackAttempted: true }, timing);
    } else {
      await retryRobotCandidateSelection(page, nickname, task, { ...context, fallbackAttempted: true });
      timing.mark("candidate-retry-clicked");
    }
    await waitForRobotCandidateSelected(page, nickname, {
      timeoutMs: candidateSelectedTimeoutMs
    });
    timing.mark("candidate-selected-after-retry");
  }
  task.speaker = nickname;
  task.cleanSpeaker = nickname;
  return {
    ok: true,
    candidate,
    before: beforeRobot,
    after: nickname,
    changed: true,
    timings: timing.done("selected")
  };
}

function createPreciseRobotTiming() {
  const startedAt = Date.now();
  const steps = [];
  return {
    mark(stage, extra = {}) {
      steps.push({
        stage,
        elapsedMs: Date.now() - startedAt,
        ...extra
      });
    },
    done(stage) {
      if (stage) this.mark(stage);
      return steps;
    }
  };
}

function summarizeRobotSwitchResult(result = {}) {
  const timings = Array.isArray(result.timings) ? result.timings : [];
  return {
    robotCandidate: result?.candidate?.nickname || "",
    robotSwitchChanged: Boolean(result.changed),
    robotSwitchSkipped: Boolean(result.skipped),
    robotSwitchFallbackUsed: Boolean(result.fallbackUsed),
    robotSwitchFallbackFrom: result.fallbackFrom || "",
    robotSwitchMessage: result.message || "",
    robotSwitchTimings: timings.slice(-12)
  };
}

function robotSelectionStatusLabel(status = {}) {
  const selectedRows = Array.isArray(status.selectedRows) ? status.selectedRows : [];
  return status.targetText || selectedRows[0] || "";
}

function robotSelectionAlreadyMatchesPreciseTuo(status = {}, nickname = "") {
  if (status.selectedCount !== 1) return false;
  const selectedRows = Array.isArray(status.selectedRows) ? status.selectedRows : [];
  if (selectedRows.length !== 1) return false;
  return robotNicknameMatches(selectedRows[0], nickname);
}

async function fillRobotKeywordSearch(page, nickname) {
  const marker = await markRobotKeywordSearchInput(page);
  if (!marker) throw new Error(`没有找到机器人关键词搜索框，无法搜索候补托“${nickname}”。`);
  await clickRobotKeywordSearchClear(page, marker).catch(() => false);
  const input = page.locator(`[data-v2-robot-keyword-search="${cssEscape(marker)}"]`).first();
  await input.fill("").catch(() => {});
  await input.fill(nickname);
}

async function clearRobotKeywordSearch(page) {
  const marker = await markRobotKeywordSearchInput(page);
  if (!marker) return false;
  await clickRobotKeywordSearchClear(page, marker).catch(() => false);
  const input = page.locator(`[data-v2-robot-keyword-search="${cssEscape(marker)}"]`).first();
  await input.fill("").catch(() => {});
  return true;
}

async function markRobotKeywordSearchInput(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const compact = (value) => String(value || "").replace(/\s+/g, "");
    const insideRobotColumn = (el) => {
      const rect = el.getBoundingClientRect();
      const headers = Array.from(document.querySelectorAll("section,aside,main,div,span"))
        .filter(visible)
        .map((node) => {
          const text = compact(node.innerText || node.textContent || "");
          if (!/^机器人/.test(text) || !/已选/.test(text)) return null;
          const headerRect = node.getBoundingClientRect();
          const area = headerRect.width * headerRect.height;
          let score = 0;
          if (/^机器人[（(]?已选/.test(text)) score += 100;
          if (headerRect.height <= 80) score += 30;
          score -= Math.min(100, area / 50000);
          return { rect: headerRect, score };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score);
      return headers.some(({ rect: headerRect }) => (
        rect.left >= headerRect.left - 16
        && rect.left <= headerRect.left + 560
        && rect.right <= headerRect.left + 620
        && rect.top >= headerRect.top - 12
      ));
    };
    const findRobotListPanelForElement = (el) => {
      if (!insideRobotColumn(el)) return null;
      const containers = Array.from(document.querySelectorAll("section,aside,main,div"))
        .filter((node) => node.contains(el) && visible(node));
      const scored = containers.map((node) => {
        const text = compact(node.innerText || node.textContent || "");
        if (!/机器人/.test(text)) return null;
        const rect = node.getBoundingClientRect();
        const area = rect.width * rect.height;
        let score = 0;
        if (/机器人[（(]?已选/.test(text) || /机器人（已选/.test(text)) score += 90;
        if (/机器人\(\d+\)|机器人（\d+）/.test(text)) score += 40;
        if (/关键词搜索/.test(text)) score += 20;
        if (/提纯SVIP|宝妈|可宝妈|成熟女性|学生|工作/.test(text)) score += 20;
        if (/群[（(]?已选|群聊|群列表|群帅/.test(text)) score -= 120;
        if (rect.width >= 180 && rect.width <= 520) score += 20;
        if (rect.left > innerWidth * 0.25) score += 8;
        score -= Math.min(100, area / 120000);
        return { node, score, area };
      }).filter(Boolean).sort((a, b) => b.score - a.score || a.area - b.area);
      return scored[0]?.score > 20 ? scored[0].node : null;
    };
    const keywordSearchInputScore = (input, robotPanel) => {
      const placeholder = String(input.placeholder || "");
      const rect = input.getBoundingClientRect();
      const anchors = Array.from(robotPanel.querySelectorAll("button,span,div,label,input"))
        .filter((node) => node !== input && visible(node))
        .map((node) => {
          const text = compact(
            `${node.innerText || node.textContent || ""} ${node.value || ""} ${node.placeholder || ""} ${node.getAttribute("aria-label") || ""} ${node.getAttribute("title") || ""}`
          );
          if (!/^关键词$/.test(text) && !/关键词$/.test(text)) return null;
          const anchorRect = node.getBoundingClientRect();
          const sameLine = anchorRect.bottom >= rect.top - 6 && anchorRect.top <= rect.bottom + 6;
          const onLeft = anchorRect.left <= rect.left + 4 && rect.left - anchorRect.right <= 160;
          if (!sameLine || !onLeft) return null;
          return { distance: Math.max(0, rect.left - anchorRect.right) };
        })
        .filter(Boolean)
        .sort((a, b) => a.distance - b.distance);
      let score = 0;
      if (/关键词搜索|搜索/.test(placeholder)) score += 60;
      if (anchors[0]) score += 80 - Math.min(40, anchors[0].distance / 4);
      return score > 0 ? score : null;
    };
    const inputs = Array.from(document.querySelectorAll("input"));
    const scored = inputs.map((input, index) => {
      if (!visible(input)) return null;
      if (input.disabled || input.readOnly || input.getAttribute("readonly") !== null) return null;
      const placeholder = String(input.placeholder || "");
      if (/请选择角色/.test(placeholder)) return null;
      const robotPanel = findRobotListPanelForElement(input);
      if (!robotPanel) return null;
      const keywordScore = keywordSearchInputScore(input, robotPanel);
      if (keywordScore === null) return null;
      const text = String(robotPanel.innerText || robotPanel.textContent || "");
      let score = 100;
      score += keywordScore;
      if (/关键词搜索/.test(text)) score += 10;
      if (/请选择角色|角色管理|使用角色/.test(text)) score -= 80;
      const rect = input.getBoundingClientRect();
      const panelRect = robotPanel.getBoundingClientRect();
      score += Math.max(0, rect.left - panelRect.left) / 1000;
      score += rect.left / 1000;
      return { input, index, score };
    }).filter(Boolean).sort((a, b) => b.score - a.score);
    const target = scored[0]?.input || null;
    if (!target) return "";
    const marker = `robot-keyword-${Date.now()}`;
    target.setAttribute("data-v2-robot-keyword-search", marker);
    return marker;
  }).catch(() => "");
}

async function clickRobotKeywordSearchClear(page, marker) {
  if (!marker) return false;
  const point = await page.evaluate((marker) => {
    const input = document.querySelector(`[data-v2-robot-keyword-search="${marker}"]`);
    if (!input) return null;
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const inputRect = input.getBoundingClientRect();
    const root = input.closest(".el-input, [class*='input'], div") || input.parentElement;
    const candidates = Array.from(root?.querySelectorAll?.("button,i,svg,span,[class*='clear'],[class*='close'],[class*='suffix']") || [])
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = String(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title") || "");
        const className = String(el.className || "");
        const nearRight = rect.left >= inputRect.left + inputRect.width * 0.65 && rect.left <= inputRect.right + 20;
        const aligned = rect.bottom >= inputRect.top - 4 && rect.top <= inputRect.bottom + 4;
        if (!nearRight || !aligned) return null;
        let score = 0;
        if (/清除|clear|close|circle-close|el-input__clear/i.test(`${text} ${className}`)) score += 30;
        score += rect.left / 1000;
        return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2, score };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }, marker).catch(() => null);
  if (!point) return false;
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(120);
  return true;
}

async function findSelectedRobotCheckboxPoint(page) {
  return findRobotCheckboxPoint(page, { selected: true });
}

async function findRobotHeaderCheckboxPoint(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const compact = (value) => String(value || "").replace(/\s+/g, "");
    const insideRobotColumn = (el) => {
      const rect = el.getBoundingClientRect();
      const headers = Array.from(document.querySelectorAll("section,aside,main,div,span"))
        .filter(visible)
        .map((node) => {
          const text = compact(node.innerText || node.textContent || "");
          if (!/^机器人/.test(text) || !/已选/.test(text)) return null;
          const headerRect = node.getBoundingClientRect();
          const area = headerRect.width * headerRect.height;
          let score = 0;
          if (/^机器人[（(]?已选/.test(text)) score += 100;
          if (headerRect.height <= 80) score += 30;
          score -= Math.min(100, area / 50000);
          return { rect: headerRect, score };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score);
      return headers.some(({ rect: headerRect }) => (
        rect.left >= headerRect.left - 16
        && rect.left <= headerRect.left + 560
        && rect.right <= headerRect.left + 620
        && rect.top >= headerRect.top - 12
      ));
    };
    const candidates = Array.from(document.querySelectorAll("input[type='checkbox'],.el-checkbox__input,[role='checkbox']"))
      .filter((el) => visible(el) && insideRobotColumn(el))
      .map((el) => {
        const row = el.closest?.("tr,.el-table__row,li,[class*='row'],[class*='header'],div") || el.parentElement;
        const text = String(row?.innerText || row?.textContent || "");
        const rect = el.getBoundingClientRect();
        let score = 0;
        if (/机器人\s*[（(]?\s*\d+/.test(text)) score += 100;
        if (/默认分组|关键词|配置|提纯SVIP|宝妈|托|在线/.test(text)) score -= 30;
        score -= rect.top / 1000;
        return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2, text, score };
      })
      .sort((a, b) => b.score - a.score || a.y - b.y);
    return candidates[0] || null;
  }).catch(() => null);
}

async function findRobotCandidateCheckboxPoint(page, nickname) {
  return findRobotCheckboxPoint(page, { nickname });
}

async function waitForRobotCandidatePoint(page, nickname, options = {}) {
  const timeoutMs = options.timeoutMs || 3000;
  const start = Date.now();
  let point = null;
  while (Date.now() - start < timeoutMs) {
    point = await findRobotCandidateCheckboxPoint(page, nickname);
    if (point) return point;
    await page.waitForTimeout(100);
  }
  return point;
}

async function findRobotCheckboxPoint(page, options = {}) {
  return page.evaluate((options) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(options.nickname || "");
    const extractRobotNickname = (value) => {
      const text = String(value || "").replace(/\s+/g, " ").trim();
      if (!text) return "";
      const parts = text.split(/[|｜]/).map((part) => part.trim()).filter(Boolean);
      const raw = parts.length >= 2 ? parts[1] : text;
      return raw
        .replace(/[（(].*$/, "")
        .replace(/\s*(在线|离线|不在群|不在本群|不可用|异常).*$/, "")
        .replace(/\b\d+\s*$/, "")
        .trim();
    };
    const robotNicknameMatches = (text) => normalize(extractRobotNickname(text)) === target;
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const compact = (value) => String(value || "").replace(/\s+/g, "");
    const robotHeaders = Array.from(document.querySelectorAll("section,aside,main,div,span"))
      .filter(visible)
      .map((node) => {
        const text = compact(node.innerText || node.textContent || "");
        if (!/^机器人/.test(text) || !/已选/.test(text)) return null;
        const headerRect = node.getBoundingClientRect();
        const area = headerRect.width * headerRect.height;
        let score = 0;
        if (/^机器人[（(]?已选/.test(text)) score += 100;
        if (headerRect.height <= 80) score += 30;
        score -= Math.min(100, area / 50000);
        return { rect: headerRect, score };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);
    const insideRobotColumn = (el) => {
      const rect = el.getBoundingClientRect();
      return robotHeaders.some(({ rect: headerRect }) => (
        rect.left >= headerRect.left - 16
        && rect.left <= headerRect.left + 560
        && rect.right <= headerRect.left + 620
        && rect.top >= headerRect.top - 12
      ));
    };
    const findRobotListPanelForElement = (el) => {
      if (!insideRobotColumn(el)) return null;
      const containers = Array.from(document.querySelectorAll("section,aside,main,div"))
        .filter((node) => node.contains(el) && visible(node));
      const scored = containers.map((node) => {
        const text = compact(node.innerText || node.textContent || "");
        if (!/机器人/.test(text)) return null;
        const rect = node.getBoundingClientRect();
        const area = rect.width * rect.height;
        let score = 0;
        if (/机器人[（(]?已选/.test(text) || /机器人（已选/.test(text)) score += 90;
        if (/机器人\(\d+\)|机器人（\d+）/.test(text)) score += 40;
        if (/提纯SVIP|宝妈|可宝妈|成熟女性|学生|工作/.test(text)) score += 20;
        if (/群[（(]?已选|群聊|群列表|群帅/.test(text)) score -= 120;
        if (rect.width >= 180 && rect.width <= 520) score += 20;
        if (rect.left > innerWidth * 0.25) score += 8;
        score -= Math.min(100, area / 120000);
        return { node, score, area };
      }).filter(Boolean).sort((a, b) => b.score - a.score || a.area - b.area);
      return scored[0]?.score > 20 ? scored[0].node : null;
    };
    const selectedState = (node) => Boolean(
      node?.querySelector?.("input[type='checkbox']:checked") ||
      node?.querySelector?.(".is-checked") ||
      node?.closest?.(".is-checked") ||
      node?.getAttribute?.("aria-checked") === "true" ||
      node?.querySelector?.("[aria-checked='true']")
    );
    const checkboxClickable = (checkbox) => {
      const clickable = checkbox.closest?.(".el-checkbox") || checkbox.closest?.("label") || checkbox;
      const rect = (visible(clickable) ? clickable : checkbox).getBoundingClientRect();
      return {
        el: clickable,
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
        rect,
        selected: selectedState(clickable) || selectedState(checkbox)
      };
    };
    const targetCandidateNodes = Array.from(document.querySelectorAll("tr,li,.el-table__row,[class*='row'],[class*='item'],div,span,label"))
      .filter(visible)
      .map((node) => {
        const robotPanel = findRobotListPanelForElement(node);
        if (!robotPanel) return null;
        const text = String(node.innerText || node.textContent || "");
        const compactText = normalize(text);
        if (!target || !compactText.includes(target)) return null;
        if (/机器人\s*[（(]?\s*已选|默认分组|关键词|配置|排序|在线排序/.test(text)) return null;
        const rect = node.getBoundingClientRect();
        const area = rect.width * rect.height;
        let score = 0;
        if (/机器人|宝妈|女性|工作|托|SVIP|群#|\(群\d+\)|（群\d+）/.test(text)) score += 80;
        if (area < 70000) score += 40;
        if (rect.height <= 48) score += 35;
        score -= Math.min(120, area / 1200);
        return { node, robotPanel, text, compact: compactText, rect, area, score };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score || a.area - b.area || a.rect.top - b.rect.top);
    const uniqueCandidateRows = (items) => {
      const seen = new Set();
      return items.filter((item) => {
        const row = item.node.closest?.("tr,li,.el-table__row,[class*='row'],[class*='item']") || item.node;
        const key = row || `${Math.round(item.rect.top)}:${Math.round(item.rect.left)}:${item.compact}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    };
    const exactCandidateNodes = targetCandidateNodes.filter((item) => target && robotNicknameMatches(item.text));
    const singleCandidateNodes = uniqueCandidateRows(targetCandidateNodes).length === 1 ? targetCandidateNodes : [];
    const selectableTargetNodes = exactCandidateNodes.length ? exactCandidateNodes : singleCandidateNodes;
    const robotPanels = Array.from(new Set(selectableTargetNodes.map((item) => item.robotPanel)));
    const checkboxCandidates = robotPanels.flatMap((robotPanel) => (
      Array.from(robotPanel.querySelectorAll("input[type='checkbox'],.el-checkbox,.el-checkbox__input,[role='checkbox']"))
        .filter(visible)
        .map((checkbox) => {
          const clickable = checkboxClickable(checkbox);
          const text = String((checkbox.closest?.("tr,li,.el-table__row,[class*='row'],[class*='item']") || checkbox.parentElement)?.innerText || "");
          return { ...clickable, checkbox, text };
        })
    ));
    const visualRows = selectableTargetNodes.flatMap((targetRow) => checkboxCandidates
      .map((candidate) => {
        const targetMid = targetRow.rect.top + targetRow.rect.height / 2;
        const checkMid = candidate.rect.top + candidate.rect.height / 2;
        const yDistance = Math.abs(targetMid - checkMid);
        const verticalOverlap = Math.min(targetRow.rect.bottom, candidate.rect.bottom) - Math.max(targetRow.rect.top, candidate.rect.top);
        const leftOfText = candidate.rect.left <= targetRow.rect.left + 12;
        if (yDistance > Math.max(22, targetRow.rect.height * 0.75) && verticalOverlap <= 0) return null;
        let score = 100;
        if (leftOfText) score += 40;
        if (verticalOverlap > 0) score += Math.min(40, verticalOverlap);
        score -= yDistance * 2;
        score -= Math.max(0, candidate.rect.left - targetRow.rect.left);
        return {
          ...candidate,
          text: targetRow.text.slice(0, 200),
          score,
          yDistance
        };
      })
      .filter(Boolean));
    const rows = Array.from(document.querySelectorAll("tr,li,.el-table__row,[class*='row'],[class*='item']"))
      .filter(visible)
      .map((row) => {
        const robotPanel = findRobotListPanelForElement(row);
        if (!robotPanel) return null;
        const text = String(row.innerText || row.textContent || "");
        const compact = normalize(text);
        const checkbox = Array.from(row.querySelectorAll("input[type='checkbox'],.el-checkbox,.el-checkbox__input,[role='checkbox']"))
          .find(visible);
        if (!checkbox) return null;
        const clickable = checkboxClickable(checkbox);
        return { row, text, compact, checkbox, selected: clickable.selected, ...clickable };
      })
      .filter(Boolean)
      .filter((item) => /机器人|宝妈|女性|工作|托|SVIP|群#|\(群\d+\)|（群\d+）/.test(item.text));
    const exactRows = rows.filter((item) => target && robotNicknameMatches(item.text));
    const matched = options.selected
      ? rows.find((item) => item.selected && !/机器人\s*[（(]?\s*已选|默认分组|关键词|配置/.test(item.text))
      : visualRows.sort((a, b) => b.score - a.score || a.yDistance - b.yDistance)[0]
        || exactRows[0]
        || null;
    if (!matched) return null;
    return {
      x: matched.x,
      y: matched.y,
      text: matched.text.slice(0, 200),
      selected: matched.selected
    };
  }, options).catch(() => null);
}

async function waitForRobotCandidateSelected(page, nickname, options = {}) {
  const timeoutMs = options.timeoutMs || 8000;
  const start = Date.now();
  let lastStatus = null;
  while (Date.now() - start < timeoutMs) {
    lastStatus = await readRobotSelectionStatus(page, nickname);
    if (lastStatus.selectedCount === 1 && lastStatus.targetSelected) return true;
    if (lastStatus.selectedCount === 1 && robotSelectionHasSingleTargetRow(lastStatus, nickname)) return true;
    if (lastStatus.selectedCount > 1 || robotSelectionHasMultipleSelectedRows(lastStatus)) {
      const selectedCount = lastStatus.selectedCount ?? lastStatus.selectedRows?.length;
      const error = new Error(`更换同身份托“${nickname}”后检测到机器人已选 ${selectedCount} 个，已停止。请只保留 1 个机器人。`);
      error.code = "ROBOT_MULTI_SELECTED";
      error.selectedCount = selectedCount;
      throw error;
    }
    const directPoint = await findRobotCandidateCheckboxPoint(page, nickname);
    if (directPoint?.selected && robotSelectionRowsAllowTarget(lastStatus, nickname)) {
      return true;
    }
    await page.waitForTimeout(100);
  }
  const countText = lastStatus?.selectedCount === null || lastStatus?.selectedCount === undefined
    ? "未识别"
    : `${lastStatus.selectedCount}/${lastStatus.totalCount || "?"}`;
  const details = lastStatus?.targetText ? ` 目标行：${lastStatus.targetText}` : "";
  throw new Error(`更换同身份托“${nickname}”后没有检测到“机器人（已选1/总数）且目标机器人已勾选，当前已选 ${countText}，已停止。${details}`);
}

function robotSelectionHasMultipleSelectedRows(status = {}) {
  return Array.isArray(status.selectedRows) && status.selectedRows.length > 1;
}

function robotSelectionHasSingleTargetRow(status = {}, nickname = "") {
  const selectedRows = Array.isArray(status.selectedRows) ? status.selectedRows : [];
  if (selectedRows.length !== 1) return false;
  return robotSelectionRowsAllowTarget(status, nickname);
}

function robotSelectionRowsAllowTarget(status = {}, nickname = "") {
  const selectedRows = Array.isArray(status.selectedRows) ? status.selectedRows : [];
  if (!selectedRows.length) return true;
  if (selectedRows.length > 1) return false;
  const targetKey = normalizeTuoIdentity(nickname);
  if (!targetKey) return false;
  return robotNicknameMatches(selectedRows[0], nickname);
}

async function waitForRobotSelectedCount(page, expectedCount, options = {}) {
  const timeoutMs = options.timeoutMs || 8000;
  const waitMs = options.waitMs || (expectedCount === 0 ? 80 : 150);
  const start = Date.now();
  let lastStatus = null;
  while (Date.now() - start < timeoutMs) {
    lastStatus = await readRobotSelectionStatus(page, "");
    if (robotSelectionCountMatches(lastStatus, expectedCount)) return lastStatus;
    await page.waitForTimeout(waitMs);
  }
  const countText = lastStatus?.selectedCount === null || lastStatus?.selectedCount === undefined
    ? "未识别"
    : `${lastStatus.selectedCount}/${lastStatus.totalCount || "?"}`;
  throw new Error(`等待机器人已选数量变成 ${expectedCount} 失败，当前已选 ${countText}。`);
}

function robotSelectionCountMatches(status = {}, expectedCount) {
  if (status.selectedCount === expectedCount) return true;
  if (expectedCount !== 0) return false;
  const selectedRows = Array.isArray(status.selectedRows) ? status.selectedRows : [];
  const countUnknown = status.selectedCount === null || status.selectedCount === undefined;
  return countUnknown && selectedRows.length === 0 && !status.targetSelected;
}

async function waitForRobotSelectionCleared(page, options = {}) {
  const timeoutMs = options.timeoutMs || 500;
  const waitMs = options.waitMs || 80;
  const start = Date.now();
  let lastStatus = options.initialStatus || null;
  while (Date.now() - start < timeoutMs) {
    lastStatus = lastStatus || await readRobotSelectionStatus(page, "");
    if (robotSelectionCountMatches(lastStatus, 0)) return lastStatus;
    if (lastStatus.selectedCount > 1 || robotSelectionHasMultipleSelectedRows(lastStatus)) {
      const selectedCount = lastStatus.selectedCount ?? lastStatus.selectedRows?.length;
      const error = new Error(`清空机器人选择时检测到仍已选 ${selectedCount} 个机器人。`);
      error.code = "ROBOT_MULTI_SELECTED";
      error.selectedCount = selectedCount;
      throw error;
    }
    const selectedPoint = await findSelectedRobotCheckboxPoint(page);
    if (!selectedPoint && !lastStatus.targetSelected) return lastStatus;
    lastStatus = null;
    await page.waitForTimeout(waitMs);
  }
  const countText = lastStatus?.selectedCount === null || lastStatus?.selectedCount === undefined
    ? "未识别"
    : `${lastStatus.selectedCount}/${lastStatus.totalCount || "?"}`;
  throw new Error(`等待机器人清空选择失败，当前已选 ${countText}。`);
}

async function waitForAllRobotsSelected(page, options = {}) {
  const timeoutMs = options.timeoutMs || 8000;
  const start = Date.now();
  let lastStatus = options.initialStatus || null;
  if (lastStatus?.totalCount && lastStatus.selectedCount === lastStatus.totalCount) return lastStatus;
  while (Date.now() - start < timeoutMs) {
    lastStatus = await readRobotSelectionStatus(page, "");
    if (lastStatus.totalCount && lastStatus.selectedCount === lastStatus.totalCount) return lastStatus;
    await page.waitForTimeout(150);
  }
  const countText = lastStatus?.selectedCount === null || lastStatus?.selectedCount === undefined
    ? "未识别"
    : `${lastStatus.selectedCount}/${lastStatus.totalCount || "?"}`;
  throw new Error(`等待机器人全选失败，当前已选 ${countText}。`);
}

async function waitForRobotSelectionReadable(page, options = {}) {
  const timeoutMs = options.timeoutMs || 1200;
  const start = Date.now();
  let lastStatus = null;
  while (Date.now() - start < timeoutMs) {
    lastStatus = await readRobotSelectionStatus(page, "");
    if (Number.isFinite(lastStatus.selectedCount)) return lastStatus;
    await page.waitForTimeout(80);
  }
  return lastStatus || { selectedCount: null, totalCount: null, selectedRows: [] };
}

async function recoverRobotSelectionForPreciseTuo(page, nickname, task = {}, context = {}, timing = null) {
  await clearRobotKeywordSearch(page);
  await page.waitForTimeout(50);
  const headerPoint = await findRobotHeaderCheckboxPoint(page);
  if (!headerPoint) {
    throw new Error(`第 ${task.index} 条更换同身份托“${nickname}”时检测到机器人多选，但没有找到机器人表头全选框，已停止。`);
  }
  await page.mouse.click(headerPoint.x, headerPoint.y);
  timing?.mark?.("recover-header-click");
  let afterHeaderClick = await waitForRobotSelectionReadable(page, { timeoutMs: Math.min(context.timeoutMs || 8000, 450) });
  if (!robotSelectionCountMatches(afterHeaderClick, 0)) {
    if (afterHeaderClick?.selectedCount === 1 && !robotSelectionHasMultipleSelectedRows(afterHeaderClick)) {
      const selectedPoint = await findSelectedRobotCheckboxPoint(page);
      if (selectedPoint) {
        await page.mouse.click(selectedPoint.x, selectedPoint.y);
        timing?.mark?.("recover-single-selected-click");
        afterHeaderClick = await waitForRobotSelectionCleared(page, {
          timeoutMs: Math.min(context.timeoutMs || 8000, 500)
        });
      }
    } else if (afterHeaderClick?.selectedCount > 0 || robotSelectionHasMultipleSelectedRows(afterHeaderClick)) {
      await page.mouse.click(headerPoint.x, headerPoint.y);
      timing?.mark?.("recover-header-click-again", {
        selectedCount: afterHeaderClick.selectedCount
      });
      afterHeaderClick = await waitForRobotSelectionCleared(page, {
        timeoutMs: Math.min(context.timeoutMs || 8000, 700)
      });
    } else {
      afterHeaderClick = await waitForRobotSelectionCleared(page, {
        timeoutMs: Math.min(context.timeoutMs || 8000, 500),
        initialStatus: afterHeaderClick
      });
    }
  }
  if (!robotSelectionCountMatches(afterHeaderClick, 0)) {
    await page.mouse.click(headerPoint.x, headerPoint.y);
    afterHeaderClick = await waitForRobotSelectionCleared(page, {
      timeoutMs: Math.min(context.timeoutMs || 8000, 700)
    });
  }
  timing?.mark?.("recover-selection-cleared", {
    selectedCount: afterHeaderClick?.selectedCount
  });
  await fillRobotKeywordSearch(page, nickname);
  timing?.mark?.("recover-search-filled");
  const candidatePoint = await waitForRobotCandidatePoint(page, nickname, {
    timeoutMs: Math.min(context.timeoutMs || 8000, 2000)
  });
  if (!candidatePoint) {
    const error = new Error(`第 ${task.index} 条兜底清空后仍没有搜索到同身份托“${nickname}”。`);
    error.code = "ROBOT_CANDIDATE_NOT_FOUND";
    throw error;
  }
  if (!candidatePoint.selected) {
    await page.mouse.click(candidatePoint.x, candidatePoint.y);
    timing?.mark?.("recover-candidate-clicked");
  }
}

async function retryRobotCandidateSelection(page, nickname, task = {}, context = {}) {
  await clearRobotKeywordSearch(page);
  await page.waitForTimeout(50);
  await fillRobotKeywordSearch(page, nickname);
  const candidatePoint = await waitForRobotCandidatePoint(page, nickname, {
    timeoutMs: Math.min(context.timeoutMs || 8000, 2000)
  });
  if (!candidatePoint) {
    const error = new Error(`第 ${task.index} 条重新输入托名“${nickname}”后仍没有找到机器人行。`);
    error.code = "ROBOT_CANDIDATE_NOT_FOUND";
    throw error;
  }
  if (!candidatePoint.selected) {
    await page.mouse.click(candidatePoint.x, candidatePoint.y);
    await page.waitForTimeout(80);
  }
}

export async function readRobotSelectionStatus(page, nickname) {
  return page.evaluate((nickname) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(nickname || "");
    const extractRobotNickname = (value) => {
      const text = String(value || "").replace(/\s+/g, " ").trim();
      if (!text) return "";
      const parts = text.split(/[|｜]/).map((part) => part.trim()).filter(Boolean);
      const raw = parts.length >= 2 ? parts[1] : text;
      return raw
        .replace(/[（(].*$/, "")
        .replace(/\s*(在线|离线|不在群|不在本群|不可用|异常).*$/, "")
        .replace(/\b\d+\s*$/, "")
        .trim();
    };
    const robotNicknameMatches = (text) => normalize(extractRobotNickname(text)) === target;
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const compact = (value) => String(value || "").replace(/\s+/g, "");
    const parseRobotCount = () => {
      const text = compact(document.body?.innerText || "");
      const match = text.match(/机器人[（(]?已选(\d+)(?:\/(\d+))?/);
      if (!match) return { selectedCount: null, totalCount: null };
      return {
        selectedCount: Number(match[1]),
        totalCount: match[2] ? Number(match[2]) : null
      };
    };
    const robotHeaders = Array.from(document.querySelectorAll("section,aside,main,div,span"))
      .filter(visible)
      .map((node) => {
        const text = compact(node.innerText || node.textContent || "");
        if (!/^机器人/.test(text) || !/已选/.test(text)) return null;
        const headerRect = node.getBoundingClientRect();
        const area = headerRect.width * headerRect.height;
        let score = 0;
        if (/^机器人[（(]?已选/.test(text)) score += 100;
        if (headerRect.height <= 80) score += 30;
        score -= Math.min(100, area / 50000);
        return { rect: headerRect, score };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);
    const insideRobotColumn = (el) => {
      const rect = el.getBoundingClientRect();
      return robotHeaders.some(({ rect: headerRect }) => (
        rect.left >= headerRect.left - 16
        && rect.left <= headerRect.left + 560
        && rect.right <= headerRect.left + 620
        && rect.top >= headerRect.top - 12
      ));
    };
    const rows = Array.from(document.querySelectorAll("tr,li,.el-table__row,[class*='row'],[class*='item']"))
      .filter(visible)
      .filter(insideRobotColumn)
      .map((row) => {
        const text = String(row.innerText || row.textContent || "");
        const checkbox = Array.from(row.querySelectorAll("input[type='checkbox'],.el-checkbox__input,[role='checkbox']"))
          .find(visible);
        const rowClass = String(row.className || "");
        const selected = Boolean(
          row.querySelector("input[type='checkbox']:checked") ||
          row.querySelector(".is-checked") ||
          row.getAttribute("aria-checked") === "true" ||
          checkbox?.getAttribute?.("aria-checked") === "true" ||
          /\bis-(checked|selected|current)\b/.test(rowClass)
        );
        return { text, compact: normalize(text), selected };
      })
      .filter((item) => item.text && !/机器人\s*[（(]?\s*已选|默认分组|关键词|配置/.test(item.text));
    const exactRows = rows.filter((item) => target && robotNicknameMatches(item.text));
    const targetRow = exactRows[0] || null;
    const count = parseRobotCount();
    return {
      ...count,
      targetSelected: Boolean(targetRow?.selected),
      targetText: targetRow?.text?.slice(0, 200) || "",
      selectedRows: rows.filter((item) => item.selected).map((item) => item.text.slice(0, 200))
    };
  }, nickname).catch(() => ({
    selectedCount: null,
    totalCount: null,
    targetSelected: false,
    targetText: "",
    selectedRows: []
  }));
}

async function setCmsScheduleTime(page, task) {
  const targetTime = normalizeScheduleTime(task.time);
  if (!targetTime) throw new Error(`第 ${task.index} 条发送时间无效：${task.time || "空"}`);
  const targetDate = resolveCmsScheduleDateOption(task.date, { time: targetTime });
  await closePopups(page);
  const selectedDate = await selectCmsScheduleDate(page, task, targetDate);
  const input = await findScheduleTimeInput(page);
  await input.scrollIntoViewIfNeeded({ timeout: 5000 }).catch(() => {});
  await clickLocatorForVisual(page, input, { timeout: 3000, force: true }).catch(() => {});
  await clearFocusedInput(page);
  await page.keyboard.insertText(targetTime).catch(async () => {
    await setNativeInputValue(input, targetTime);
  });
  await page.keyboard.press("Enter").catch(() => {});
  await clickTimePickerOk(page);
  await page.waitForTimeout(350);

  let current = normalizeScheduleTime(await input.inputValue({ timeout: 800 }).catch(() => ""));
  if (current !== targetTime) {
    await setNativeInputValue(input, targetTime);
    await page.keyboard.press("Enter").catch(() => {});
    await clickTimePickerOk(page);
    await page.waitForTimeout(250);
    current = normalizeScheduleTime(await input.inputValue({ timeout: 800 }).catch(() => ""));
  }
  if (current !== targetTime) {
    throw new Error(`第 ${task.index} 条定时发送时间没有写入成功：应该是 ${targetTime}，当前是 ${current || "空"}`);
  }
  return {
    ok: true,
    date: targetDate.taskDate,
    time: targetTime,
    todayDate: targetDate.todayDate,
    dateOffsetDays: targetDate.offset,
    optionText: targetDate.optionText,
    selectedDateText: selectedDate || targetDate.optionText
  };
}

async function selectCmsScheduleDate(page, task, targetDate) {
  const opened = await openScheduleDateDropdown(page, targetDate);
  if (!opened) {
    throw new Error(`第 ${task.index} 条无法打开 CMS 定时日期下拉：preview 日期=${targetDate.taskDate}，时间=${task.time || ""}`);
  }
  await page.waitForTimeout(250);
  const beforeSelected = await readSelectedScheduleDateText(page, targetDate);
  if (verifyScheduleDateText(beforeSelected, targetDate)) {
    await closePopups(page);
    return beforeSelected;
  }
  const clicked = await clickScheduleDateOption(page, targetDate);
  if (!clicked) {
    const detected = await readVisibleScheduleDateOptions(page);
    if (targetDate.offset === 0) {
      await closePopups(page);
      return beforeSelected || targetDate.optionText;
    }
    const detail = detected.length ? `，页面检测到的日期选项=${detected.join("、")}` : "";
    throw new Error(`第 ${task.index} 条 CMS 定时日期选项不支持该日期：preview 日期=${targetDate.taskDate}，应该选择=${targetDate.optionText}，时间=${task.time || ""}${detail}`);
  }
  await page.waitForTimeout(250);
  const selected = await readSelectedScheduleDateText(page, targetDate);
  if (!verifyScheduleDateText(selected, targetDate)) {
    throw new Error(`第 ${task.index} 条 CMS 定时日期没有选择成功：preview 日期=${targetDate.taskDate}，应该选择=${targetDate.optionText}，当前=${selected || "未识别"}`);
  }
  return selected;
}

async function openScheduleDateDropdown(page, targetDate) {
  const point = await page.evaluate(({ T, targetDate }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const overlapY = (a, b) => Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const textOf = (el) => normalize(el.innerText || el.textContent || el.value || el.placeholder || "");
    const timeInput = Array.from(document.querySelectorAll("input"))
      .filter(visible)
      .find((el) => normalize(el.placeholder).includes(normalize(T.anyTime)) || /^\d{1,2}:\d{2}(?::\d{2})?$/.test(String(el.value || "").trim()));
    const [month = "", day = ""] = String(targetDate?.taskDate || "").split("/");
    const targetDay = Number(targetDate?.day || day || 0);
    const dateWords = [
      T.today,
      T.tomorrow,
      T.dayAfterTomorrow,
      "+3天",
      "+4天",
      "+5天",
      "+6天",
      "+7天",
      targetDay ? `${targetDay}号` : "",
      month && day ? `${Number(month)}/${Number(day)}` : "",
      month && day ? `${Number(month)}月${Number(day)}日` : ""
    ].map(normalize).filter(Boolean);
    const labels = Array.from(document.querySelectorAll("span,div,label,p"))
      .filter(visible)
      .filter((el) => {
        const text = textOf(el);
        return text.includes(normalize(T.scheduleSend)) && text.length <= 20;
      })
      .map((el) => {
        const r = el.getBoundingClientRect();
        const sectionText = normalize(el.closest(".el-form,.el-form-item,form,section,div")?.innerText || "");
        return { r, sectionText };
      })
      .sort((a, b) => {
        const aInSection = a.sectionText.includes("执行发送设置") ? 0 : 1;
        const bInSection = b.sectionText.includes("执行发送设置") ? 0 : 1;
        return aInSection - bInSection || a.r.top - b.r.top;
      });
    for (const label of labels) {
      const rowTop = label.r.top - 24;
      const rowBottom = label.r.bottom + 32;
      const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,div,span"))
        .filter(visible)
        .map((el) => {
          const r = el.getBoundingClientRect();
          return { el, r, text: textOf(el) };
        })
        .filter((item) => item.r.left > label.r.right - 4)
        .filter((item) => item.r.left < label.r.left + 260)
        .filter((item) => overlapY(item.r, { top: rowTop, bottom: rowBottom }) >= Math.min(item.r.height, rowBottom - rowTop) * 0.35)
        .filter((item) => dateWords.some((word) => item.text.includes(word)))
        .sort((a, b) => {
          const aSelect = a.el.closest(".el-select") ? 0 : 1;
          const bSelect = b.el.closest(".el-select") ? 0 : 1;
          return aSelect - bSelect || a.r.left - b.r.left;
        });
      const target = candidates[0];
      if (target) {
        const clickable = target.el.closest(".el-select,.el-input") || target.el;
        const r = clickable.getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      }
    }
    if (!timeInput) return null;
    const timeRect = timeInput.getBoundingClientRect();
    const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,div,span"))
      .filter(visible)
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = textOf(el);
        return { r, text };
      })
      .filter((item) => {
        if (item.r.right > timeRect.left + 8) return false;
        if (item.r.left < timeRect.left - 280) return false;
        if (overlapY(item.r, timeRect) < Math.min(item.r.height, timeRect.height) * 0.45) return false;
        return dateWords.some((word) => item.text.includes(word));
      })
      .sort((a, b) => b.r.right - a.r.right);
    const target = candidates[0];
    if (!target) return null;
    return { x: target.r.left + target.r.width / 2, y: target.r.top + target.r.height / 2 };
  }, { T, targetDate }).catch(() => null);
  if (!point) return false;
  await page.mouse.click(point.x, point.y);
  return true;
}

async function clickScheduleDateOption(page, targetDate) {
  const point = await page.evaluate(({ targetDate }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const expectedDay = `${Number(targetDate.day)}号`;
    const expectedWrappedDay = `(${expectedDay})`;
    const expectedPrefix = normalize(targetDate.optionText).replace(/\(.*/, "");
    const [month = "", day = ""] = String(targetDate.taskDate || "").split("/");
    const expectedSlashDate = month && day ? `${Number(month)}/${Number(day)}` : "";
    const expectedChineseDate = month && day ? `${Number(month)}月${Number(day)}日` : "";
    const matchesTarget = (text) => {
      if (text === expectedDay) return true;
      if (expectedSlashDate && text.includes(expectedSlashDate)) return true;
      if (expectedChineseDate && text.includes(expectedChineseDate)) return true;
      if (targetDate.offset <= 2) {
        if (!text.includes(expectedPrefix)) return false;
        if (/\d{1,2}号/.test(text)) return text.includes(expectedWrappedDay) || text.includes(expectedDay);
        return text === expectedPrefix;
      }
      if (!text.includes(`+${targetDate.offset}天`)) return false;
      if (/\d{1,2}号/.test(text)) return text.includes(expectedWrappedDay) || text.includes(expectedDay);
      return true;
    };
    const roots = Array.from(document.querySelectorAll(".el-select-dropdown, .el-popper, [x-placement], [role='listbox']"))
      .filter(visible)
      .filter((root) => {
        const text = normalize(root.innerText || root.textContent || "");
        return text.includes("今天") || text.includes("明天") || text.includes("后天") || text.includes(expectedDay);
      });
    let candidates = roots.flatMap((root) =>
      Array.from(root.querySelectorAll(".el-select-dropdown__item, li, [role='option'], span, div"))
        .filter(visible)
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = normalize(el.innerText || el.textContent || "");
          return { el, r, text };
        })
    )
      .filter((item) => item.r.width > 20 && item.r.height > 10 && item.text.length <= 30)
      .filter((item) => matchesTarget(item.text))
      .sort((a, b) => dateOptionRank(a.text, targetDate) - dateOptionRank(b.text, targetDate) || a.r.top - b.r.top || a.r.left - b.r.left);
    if (!candidates.length) {
      candidates = Array.from(document.querySelectorAll(".el-select-dropdown__item, li, [role='option'], button,span,div"))
        .filter(visible)
        .filter((el) => !el.matches("body,html"))
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = normalize(el.innerText || el.textContent || "");
          return { el, r, text };
        })
        .filter((item) => item.r.width > 20 && item.r.height > 10 && item.text.length <= 30)
        .filter((item) => matchesTarget(item.text))
        .sort((a, b) => dateOptionRank(a.text, targetDate) - dateOptionRank(b.text, targetDate) || a.r.top - b.r.top || a.r.left - b.r.left);
    }
    const target = candidates[0];
    if (!target) return null;
    const clickable = target.el.closest(".el-select-dropdown__item, li, [role='option']") || target.el;
    const r = clickable.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2, text: target.text };

    function dateOptionRank(text, targetDate) {
      if (text === normalize(targetDate.optionText)) return 0;
      if (text === expectedDay) return 1;
      if (expectedSlashDate && text.includes(expectedSlashDate)) return 1;
      if (expectedChineseDate && text.includes(expectedChineseDate)) return 1;
      if (text.includes(expectedWrappedDay) || text.includes(expectedDay)) return 1;
      return 2;
    }
  }, { targetDate }).catch(() => null);
  if (!point) return clickScheduleDateOptionByText(page, targetDate);
  await page.mouse.click(point.x, point.y);
  return true;
}

async function clickScheduleDateOptionByText(page, targetDate) {
  const texts = scheduleDateOptionTextCandidates(targetDate);
  const selectors = [
    ".el-select-dropdown__item",
    ".el-popper li",
    "[role='option']",
    ".el-select-dropdown span",
    ".el-select-dropdown div"
  ].join(",");
  for (const text of texts) {
    const exact = page.locator(selectors).filter({ hasText: new RegExp(`^\\s*${escapeRegExp(text)}\\s*$`) }).first();
    if (await exact.count().catch(() => 0)) {
      await clickLocatorForVisual(page, exact, { timeout: 1500, force: true }).catch(async () => {
        await exact.click({ timeout: 1500, force: true });
      });
      return true;
    }
  }
  for (const text of texts) {
    const partial = page.locator(selectors).filter({ hasText: text }).first();
    if (await partial.count().catch(() => 0)) {
      await clickLocatorForVisual(page, partial, { timeout: 1500, force: true }).catch(async () => {
        await partial.click({ timeout: 1500, force: true });
      });
      return true;
    }
  }
  return false;
}

function scheduleDateOptionTextCandidates(targetDate = {}) {
  const [month = "", day = ""] = String(targetDate.taskDate || "").split("/");
  const normalizedMonth = Number(month);
  const normalizedDay = Number(targetDate.day || day || 0);
  const compactOption = String(targetDate.optionText || "").replace(/\s+/g, "");
  const prefix = compactOption.replace(/\(.*/, "");
  return Array.from(new Set([
    compactOption,
    normalizedDay ? `${prefix}(${normalizedDay}号)` : "",
    prefix,
    normalizedDay ? `${normalizedDay}号` : "",
    normalizedMonth && normalizedDay ? `${normalizedMonth}/${normalizedDay}` : "",
    normalizedMonth && normalizedDay ? `${normalizedMonth}月${normalizedDay}日` : ""
  ].filter(Boolean)));
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function readSelectedScheduleDateText(page, targetDate) {
  return page.evaluate(({ T, targetDate }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const overlapY = (a, b) => Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const textOf = (el) => normalize(el.innerText || el.textContent || el.value || el.placeholder || "");
    const [month = "", day = ""] = String(targetDate?.taskDate || "").split("/");
    const targetDay = Number(targetDate?.day || day || 0);
    const dateWords = [
      T.today,
      T.tomorrow,
      T.dayAfterTomorrow,
      "+3天",
      "+4天",
      "+5天",
      "+6天",
      "+7天",
      targetDay ? `${targetDay}号` : "",
      month && day ? `${Number(month)}/${Number(day)}` : "",
      month && day ? `${Number(month)}月${Number(day)}日` : ""
    ].map(normalize).filter(Boolean);
    const labels = Array.from(document.querySelectorAll("span,div,label,p"))
      .filter(visible)
      .filter((el) => {
        const text = textOf(el);
        return text.includes(normalize(T.scheduleSend)) && text.length <= 20;
      })
      .map((el) => {
        const r = el.getBoundingClientRect();
        const sectionText = normalize(el.closest(".el-form,.el-form-item,form,section,div")?.innerText || "");
        return { r, sectionText };
      })
      .sort((a, b) => {
        const aInSection = a.sectionText.includes("执行发送设置") ? 0 : 1;
        const bInSection = b.sectionText.includes("执行发送设置") ? 0 : 1;
        return aInSection - bInSection || a.r.top - b.r.top;
      });
    for (const label of labels) {
      const rowTop = label.r.top - 24;
      const rowBottom = label.r.bottom + 32;
      const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,span,div"))
        .filter(visible)
        .filter((el) => !el.closest(".el-select-dropdown,.el-popper,[x-placement],[role='listbox']"))
        .map((el) => {
          const r = el.getBoundingClientRect();
          return { r, text: textOf(el) };
        })
        .filter((item) => item.r.left > label.r.right - 4)
        .filter((item) => overlapY(item.r, { top: rowTop, bottom: rowBottom }) >= Math.min(item.r.height, rowBottom - rowTop) * 0.35)
        .filter((item) => dateWords.some((word) => item.text.includes(word)))
        .sort((a, b) => a.r.left - b.r.left);
      if (candidates[0]?.text) return candidates[0].text;
    }
    const timeInput = Array.from(document.querySelectorAll("input"))
      .filter(visible)
      .find((el) => normalize(el.placeholder).includes(normalize(T.anyTime)) || /^\d{1,2}:\d{2}(?::\d{2})?$/.test(String(el.value || "").trim()));
    if (!timeInput) return "";
    const timeRect = timeInput.getBoundingClientRect();
    const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,span,div"))
      .filter(visible)
      .filter((el) => !el.closest(".el-select-dropdown,.el-popper,[x-placement],[role='listbox']"))
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = normalize(el.innerText || el.textContent || el.value || "");
        return { r, text };
      })
      .filter((item) => {
        if (item.r.right > timeRect.left + 8) return false;
        if (item.r.left < timeRect.left - 280) return false;
        if (overlapY(item.r, timeRect) < Math.min(item.r.height, timeRect.height) * 0.45) return false;
        return dateWords.some((word) => item.text.includes(word));
      })
      .sort((a, b) => b.r.right - a.r.right);
    return candidates[0]?.text || "";
  }, { T, targetDate }).catch(() => "");
}

async function readVisibleScheduleDateOptions(page) {
  return page.evaluate(() => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const isDateOption = (text) => /^(今天|明天|后天|\+\d+天)(?:\(\d{1,2}号\))?$/.test(text)
      || /^\d{1,2}号$/.test(text)
      || /^\d{1,2}\/\d{1,2}$/.test(text)
      || /^\d{1,2}月\d{1,2}日$/.test(text);
    const values = Array.from(document.querySelectorAll(".el-select-dropdown__item, li, [role='option'], button,span,div"))
      .filter(visible)
      .map((el) => normalize(el.innerText || el.textContent || ""))
      .filter((text) => text && text.length <= 30 && isDateOption(text));
    return Array.from(new Set(values)).slice(0, 12);
  }).catch(() => []);
}

function verifyScheduleDateText(text, targetDate) {
  return verifyCmsScheduleDateSelectedText(text, targetDate);
}

async function findScheduleTimeInput(page) {
  const byPlaceholder = page.locator(`input[placeholder*="${T.anyTime}"]:visible`).first();
  if (await byPlaceholder.count().catch(() => 0)) return byPlaceholder;
  const byIndex = await page.evaluate((T) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const normalize = (value) => compact(value).replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const inputs = Array.from(document.querySelectorAll("input"));
    const direct = inputs.findIndex((el) => visible(el) && (
      normalize(el.placeholder).includes(normalize(T.anyTime)) ||
      /^\d{1,2}:\d{2}(?::\d{2})?$/.test(String(el.value || "").trim())
    ));
    if (direct >= 0) return direct;
    const labels = Array.from(document.querySelectorAll("span,div,label,p"))
      .filter((el) => visible(el) && normalize(el.innerText || el.textContent).includes(normalize(T.scheduleSend)))
      .map((el) => el.getBoundingClientRect())
      .sort((a, b) => a.top - b.top);
    if (!labels.length) return -1;
    for (const labelRect of labels) {
      const rowTop = labelRect.top - 24;
      const rowBottom = labelRect.bottom + 28;
      const rowInputs = inputs
        .map((el, index) => ({ el, index, r: el.getBoundingClientRect() }))
        .filter((item) => visible(item.el))
        .filter((item) => item.r.top >= rowTop && item.r.bottom <= rowBottom && item.r.left > labelRect.right)
        .sort((a, b) => b.r.left - a.r.left);
      const timeInput = rowInputs.find((item) => item.r.width >= 80 && item.r.width <= 260);
      if (timeInput) return timeInput.index;
    }
    return -1;
  }, T).catch(() => -1);
  if (byIndex >= 0) return page.locator("input").nth(byIndex);
  throw new Error("找不到定时发送时间输入框");
}

async function setNativeInputValue(locator, value) {
  await locator.evaluate((el, nextValue) => {
    el.removeAttribute("readonly");
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    el.focus();
    if (setter) setter.call(el, nextValue);
    else el.value = nextValue;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur?.();
  }, value);
}

async function clickTimePickerOk(page) {
  const point = await page.evaluate(() => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const panels = Array.from(document.querySelectorAll(".el-time-panel,.el-picker-panel,.el-date-picker,.ant-picker-dropdown"))
      .filter(visible);
    for (const panel of panels) {
      const buttons = Array.from(panel.querySelectorAll("button,span,a"))
        .filter((el) => visible(el) && /^(确定|OK)$/i.test(normalize(el.innerText || el.textContent)));
      const button = buttons[buttons.length - 1];
      if (button) {
        const r = button.getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      }
    }
    return null;
  }).catch(() => null);
  if (!point) return false;
  await page.mouse.click(point.x, point.y);
  return true;
}

function normalizeScheduleTime(value) {
  const match = String(value || "").trim().match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
  if (!match) return "";
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  const second = Number(match[3] || 0);
  if (hour > 23 || minute > 59 || second > 59) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${pad(hour)}:${pad(minute)}:${pad(second)}`;
}

async function openRoleDropdown(page, options = {}) {
  const point = await findRoleDropdownPoint(page);
  if (point) {
    await page.mouse.click(point.x, point.y);
    await page.waitForTimeout(250);
    return true;
  }
  const input = page.locator(`input[placeholder*="${T.selectRole}"]`).first();
  if (await input.count().catch(() => 0)) {
    await clickLocatorForVisual(page, input, { timeout: 5000, force: true });
    await page.waitForTimeout(500);
    return true;
  }
  if (options.optional) return false;
  throw new Error("云中客页面异常：没有找到“使用角色”选择框。");
}

export async function pageLooksLikeCreateForm(page) {
  const result = await page.evaluate((T) => {
    const body = document.body.innerText || "";
    const typeHits = [T.text, T.image, T.video, T.finder, T.sticker].filter((label) => body.includes(label));
    const coreHits = [T.execute, T.taskRemark, T.scheduleSend, T.textPlaceholder, T.upload].filter((label) => body.includes(label));
    return {
      ok: body.includes(T.execute) && typeHits.length >= 2 || coreHits.length >= 2 && typeHits.length >= 1,
      typeHits,
      coreHits
    };
  }, T).catch(() => ({ ok: false, typeHits: [], coreHits: [] }));
  return Boolean(result?.ok);
}

async function findExistingCmsCreatePage(context, targetUrl = "") {
  const pages = await findExistingCmsCreatePages(context, targetUrl);
  return pages[0] || null;
}

async function findExistingCmsCreatePages(context, targetUrl = "") {
  const pages = [];
  for (const page of context.pages()) {
    if (!isCmsPageUrl(page.url?.() || "", targetUrl)) continue;
    await page.waitForLoadState("domcontentloaded", { timeout: 3000 }).catch(() => {});
    if (await pageLooksLikeCreateForm(page)) pages.push(page);
  }
  return pages;
}

export async function ensureCmsCreatePages(context, options = {}) {
  const targetUrl = String(options.cmsUrl || "").trim();
  const requiredRoles = normalizeRequiredCmsRoles(options);
  await clearCmsPageRoleMarkers(context, targetUrl);
  if (options.forceFreshCreatePages === true) {
    await closeExistingCmsTaskPages(context, targetUrl);
    if (!targetUrl) throw new Error("没有找到云中客页面地址，请在 config.json 里配置 cmsUrl。");
    const rolePages = {};
    for (const role of requiredRoles) {
      rolePages[role] = await openMarkedCmsPage(context, targetUrl, role, options);
    }
    return requiredRoles.map((role) => rolePages[role]).filter(Boolean);
  }
  const pool = await scanCmsPagePool(context, targetUrl);
  const existingCreatePages = [...pool.createPages];
  const rolePages = {};

  for (const [index, role] of requiredRoles.entries()) {
    const page = existingCreatePages[index];
    if (!page || page.isClosed?.()) continue;
    rolePages[role] = page;
    await markCmsPageRole(page, role);
  }

  if (!options.requireExistingCreatePage && targetUrl) {
    for (const role of requiredRoles) {
      if (rolePages[role] && !rolePages[role].isClosed?.()) continue;
      rolePages[role] = await openMarkedCmsPage(context, targetUrl, role, options);
    }
  }

  const keep = new Set(Object.values(rolePages).filter(Boolean));
  await closeExtraCmsCreatePages(existingCreatePages.slice(requiredRoles.length), keep);
  if (pool.joblistPage) {
    await pool.joblistPage.close?.().catch(() => {});
  }
  return requiredRoles.map((role) => rolePages[role]).filter(Boolean);
}

async function closeExistingCmsTaskPages(context, targetUrl = "") {
  for (const page of context.pages()) {
    if (page.isClosed?.()) continue;
    const url = page.url?.() || "";
    if (!isCmsPageUrl(url, targetUrl) && !isCmsJoblistPageUrl(url, targetUrl)) continue;
    await page.close?.().catch(() => {});
  }
}

async function scanCmsPagePool(context, targetUrl = "") {
  const rolePages = {};
  let joblistPage = null;
  const createPages = [];
  const extraCreatePages = [];
  for (const page of context.pages()) {
    if (page.isClosed?.()) continue;
    const url = page.url?.() || "";
    if (!isCmsPageUrl(url, targetUrl) && !isCmsJoblistPageUrl(url, targetUrl)) continue;
    await page.waitForLoadState?.("domcontentloaded", { timeout: 3000 }).catch(() => {});
    const marker = await readCmsPageRoleMarker(page);
    if (isCmsJoblistPageUrl(url, targetUrl) || marker === "joblist") {
      if (!joblistPage) {
        joblistPage = page;
        await markCmsPageRole(page, "joblist");
      }
      continue;
    }
    const looksLikeCreate = marker === "tuo" || marker === "douma" || await pageLooksLikeCreateForm(page);
    if (!looksLikeCreate) continue;
    createPages.push(page);
  }
  return { rolePages, createPages, extraCreatePages, joblistPage };
}

async function clearCmsPageRoleMarkers(context, targetUrl = "") {
  for (const page of context.pages()) {
    if (page.isClosed?.()) continue;
    const url = page.url?.() || "";
    if (!isCmsPageUrl(url, targetUrl) && !isCmsJoblistPageUrl(url, targetUrl)) continue;
    page.__v2CmsRole = "";
    await page.evaluate?.(() => {
      try {
        window.__v2CmsRole = "";
        sessionStorage.removeItem("__v2CmsRole");
      } catch {
        window.__v2CmsRole = "";
      }
    }).catch(() => {});
  }
}

function normalizeRequiredCmsRoles(options = {}) {
  const roles = Array.isArray(options.requiredRoles) && options.requiredRoles.length
    ? options.requiredRoles
    : ["tuo", "douma"].slice(0, Math.max(1, Number(options.minCreatePages || 1)));
  return Array.from(new Set(roles.filter((role) => role === "tuo" || role === "douma")));
}

async function openMarkedCmsPage(context, url, role, options = {}) {
  const page = context.pages().find((item) => item.url?.() === "about:blank" && !item.__v2CmsRole) || await context.newPage();
  await markCmsPageRole(page, role);
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: options.timeoutMs || 30000 });
  await page.waitForTimeout(1200).catch(() => {});
  await markCmsPageRole(page, role);
  return page;
}

async function closeExtraCmsCreatePages(pages = [], keep = new Set()) {
  for (const page of pages) {
    if (!page || keep.has(page) || page.isClosed?.()) continue;
    await page.close?.().catch(() => {});
  }
}

async function markCmsPageRole(page, role) {
  page.__v2CmsRole = role;
  await page.evaluate?.((value) => {
    window.__v2CmsRole = value;
    try {
      sessionStorage.setItem("__v2CmsRole", value);
    } catch {}
  }, role).catch(() => {});
}

async function readCmsPageRoleMarker(page) {
  if (page.__v2CmsRole) return page.__v2CmsRole;
  const marker = await page.evaluate?.(() => {
    try {
      return window.__v2CmsRole || sessionStorage.getItem("__v2CmsRole") || "";
    } catch {
      return window.__v2CmsRole || "";
    }
  }).catch(() => "");
  if (marker === "tuo" || marker === "douma" || marker === "joblist") {
    page.__v2CmsRole = marker;
    return marker;
  }
  return "";
}

function isCmsJoblistPageUrl(value, targetUrl = "") {
  try {
    const url = new URL(value);
    if (!/iyunzk\.com$/i.test(url.hostname) && !/cms\.iyunzk\.com$/i.test(url.hostname)) return false;
    return /\/wx\/FenWei_rw\/joblist\/?$/i.test(url.pathname);
  } catch {
    return /cms\.iyunzk\.com\/wx\/FenWei_rw\/joblist/i.test(String(value || ""));
  }
}

async function findRoleDropdownPoint(page) {
  return page.evaluate((T) => {
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const input = Array.from(document.querySelectorAll("input"))
      .find((el) => visible(el) && String(el.placeholder || "").includes(T.selectRole));
    if (input) {
      const r = input.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    }
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (!String(node.nodeValue || "").includes(T.useRole) || !visible(node.parentElement)) continue;
      const row = node.parentElement.closest("div,section,form") || node.parentElement;
      const candidate = Array.from(row.querySelectorAll("input,.el-select,.el-input,[class*='select']")).filter(visible).pop();
      if (candidate) {
        const r = candidate.getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      }
    }
    return null;
  }, T).catch(() => null);
}

async function findRoleOptionPoint(page, targetText) {
  return page.evaluate((targetText) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(targetText);
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const selectors = ".el-select-dropdown__item, .el-select-dropdown li, [class*='select-dropdown'] li, [role='option']";
    const options = Array.from(document.querySelectorAll(selectors))
      .filter((el) => visible(el) && !String(el.className || "").includes("disabled"))
      .map((el) => {
        const text = String(el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
        const r = el.getBoundingClientRect();
        return { text, x: r.left + r.width / 2, y: r.top + r.height / 2, top: r.top };
      })
      .filter((item) => normalize(item.text).startsWith(target) || normalize(item.text).includes(target));
    options.sort((a, b) => a.top - b.top);
    return options[0] || null;
  }, targetText).catch(() => null);
}

async function clickMessageTab(page, label) {
  const point = await findSmallTextPoint(page, [label]);
  if (!point) throw new Error(`云中客页面异常：没有找到“${label}”类型入口。`);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(250);
}

async function findTextInput(page, options = {}) {
  if (options.preferNewEditor) {
    const editor = page.locator(editorScopedSelector(".ql-editor:visible")).first();
    if (await editor.count().catch(() => 0)) return editor;
  }
  const textarea = page.locator(editorScopedSelector(`textarea[placeholder*="${SCRIPT_TEXT_PLACEHOLDER_PREFIX}"]:visible`)).first();
  if (await textarea.count().catch(() => 0)) return textarea;
  const editable = page.locator(editorScopedSelector(`[contenteditable='true'][data-placeholder*="${SCRIPT_TEXT_PLACEHOLDER_PREFIX}"]:visible`)).first();
  if (await editable.count().catch(() => 0)) return editable;
  throw new Error("找不到编辑脚本内容文本框");
}

async function findFinderFeedInput(page, options = {}) {
  const specific = page.locator(editorScopedSelector("textarea[placeholder*='视频号']:visible,textarea[placeholder*='参数']:visible,[contenteditable='true'][data-placeholder*='视频号']:visible,[contenteditable='true'][data-placeholder*='参数']:visible")).first();
  if (await specific.count().catch(() => 0)) return specific;
  const textarea = page.locator(editorScopedSelector("textarea:visible")).first();
  if (await textarea.count().catch(() => 0)) return textarea;
  const editable = page.locator(editorScopedSelector("[contenteditable='true']:visible")).first();
  if (await editable.count().catch(() => 0)) return editable;
  return findTextInput(page, options);
}

function editorScopedSelector(targetSelector) {
  const roots = [
    ".drama-content",
    ".drama-item",
    "[class*='drama-content']",
    "[class*='drama-item']"
  ];
  return roots.map((root) => `${root} ${targetSelector}`).join(",");
}

async function uploadStickerFile(page, localPath, task) {
  await clickMessageTab(page, T.sticker);
  await page.waitForTimeout(500);

  if (await setStickerFileInput(page, localPath, { preferName: "msg_img" })) {
    await confirmStickerUploadIfNeeded(page, task);
    return;
  }

  if (await setStickerFileInput(page, localPath, { preferName: "file" })) {
    await confirmStickerUploadIfNeeded(page, task);
    return;
  }

  const uploadPoint = await findStickerAreaTextPoint(page, [T.upload, "点击上传", "拖动动态表情"]);
  if (uploadPoint) {
    const chooserPromise = page.waitForEvent("filechooser", { timeout: 6000 }).catch(() => null);
    await page.mouse.click(uploadPoint.x, uploadPoint.y);
    const chooser = await chooserPromise;
    if (chooser) {
      await chooser.setFiles(localPath);
      await confirmStickerUploadIfNeeded(page, task);
      return;
    }
  }

  const areaText = await readStickerAreaText(page);
  const suffix = areaText ? ` 动态表情区域：${areaText}` : "";
  throw new Error(`第 ${task.index} 条没有找到动态表情 file input 或上传入口。${suffix}`);
}

async function setStickerFileInput(page, localPath, options = {}) {
  const index = await findStickerFileInputIndex(page, options);
  if (index < 0) return false;
  try {
    await page.locator('input[type="file"]').nth(index).setInputFiles(localPath, { timeout: 3000 });
    return true;
  } catch {
    return false;
  }
}

async function findStickerFileInputIndex(page, options = {}) {
  return page.evaluate(({ preferName, allowUnscoped }) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = typeof getComputedStyle === "function" ? getComputedStyle(el) : { visibility: "visible", display: "block" };
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
    const roots = findStickerEditorRoots(document, visible, compact);
    const candidates = inputs.map((input, index) => {
      const parentText = compact(input.parentElement?.innerText || input.parentElement?.textContent);
      const name = input.getAttribute("name") || "";
      const inStickerRoot = roots.some((root) => root === input || root.contains(input));
      const looksSticker = /动态表情|表情包|点击上传|拖动/.test(parentText) || name === "msg_img";
      if (!inStickerRoot && !(allowUnscoped && looksSticker)) return null;
      let score = 0;
      if (name === preferName) score -= 100;
      if (name === "msg_img") score -= 50;
      if (/动态表情/.test(parentText)) score -= 20;
      if (/点击上传|拖动/.test(parentText)) score -= 10;
      if (input.disabled) score += 1000;
      return { index, score };
    }).filter(Boolean);
    candidates.sort((a, b) => a.score - b.score || a.index - b.index);
    return candidates[0]?.index ?? -1;

    function findStickerEditorRoots(document, visible, compact) {
      const roots = Array.from(document.querySelectorAll(".drama-item,.drama-content,[class*='drama-item'],[class*='drama-content']"))
        .filter((root) => {
          const text = compact(root.innerText || root.textContent);
          const hasSticker = text.includes("动态表情") && /表情包|拖动动态表情|点击上传/.test(text);
          const activeSticker = Array.from(root.querySelectorAll(".el-radio-button.is-active,.is-active"))
            .some((el) => visible(el) && compact(el.innerText || el.textContent).includes("动态表情"));
          return visible(root) && hasSticker && activeSticker;
        });
      return roots;
    }
  }, options).catch(() => -1);
}

async function findStickerAreaTextPoint(page, labels) {
  return page.evaluate((labels) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const roots = Array.from(document.querySelectorAll(".drama-item,.drama-content,[class*='drama-item'],[class*='drama-content']"))
      .filter((root) => visible(root) && /动态表情|表情包|拖动动态表情/.test(compact(root.innerText || root.textContent)));
    const candidates = [];
    for (const root of roots) {
      for (const el of Array.from(root.querySelectorAll("button,a,span,div,label"))) {
        const text = compact(el.innerText || el.textContent);
        if (!visible(el) || !labels.some((label) => text.includes(label))) continue;
        const r = el.getBoundingClientRect();
        candidates.push({ x: r.left + r.width / 2, y: r.top + r.height / 2, top: r.top, area: r.width * r.height, text });
      }
    }
    candidates.sort((a, b) => a.area - b.area || a.top - b.top);
    return candidates[0] || null;
  }, labels).catch(() => null);
}

async function readMediaReadyState(page, options = {}) {
  return page.evaluate(({ expectedStatus, taskType }) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const normalize = (value) => compact(value).replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const typeLabel = taskType === "image" ? "图片" : taskType === "video" ? "视频" : taskType === "sticker" ? "动态表情" : "";
    const roots = Array.from(document.querySelectorAll(".drama-item,.drama-content,[class*='drama-item'],[class*='drama-content']"))
      .filter((root) => visible(root));
    const activeRoot = roots.find((root) => {
      if (!typeLabel) return false;
      return Array.from(root.querySelectorAll(".el-radio-button.is-active,.is-active,.active,[aria-selected='true']"))
        .some((el) => visible(el) && normalize(el.innerText || el.textContent).includes(normalize(typeLabel)));
    });
    const fallbackRoot = roots.find((root) => {
      const text = normalize(root.innerText || root.textContent);
      if (typeLabel && !text.includes(normalize(typeLabel))) return false;
      return text.includes(normalize(expectedStatus)) || /点击上传|拖动|上传成功|上传完成|已上传|100%/i.test(text);
    });
    const root = activeRoot || fallbackRoot || roots[0];
    if (!root) {
      return { ready: false, active: false, text: "", reason: "没有找到媒体上传区域" };
    }

    const text = compact(root.innerText || root.textContent);
    const mediaPreview = Array.from(root.querySelectorAll("img,video"))
      .filter(visible)
      .some((el) => {
        const src = String(el.currentSrc || el.src || "");
        const r = el.getBoundingClientRect();
        return src && !/icon_close|close/i.test(src) && r.width >= 20 && r.height >= 20;
      });
    const uploadListItem = Array.from(root.querySelectorAll(".el-upload-list__item,[class*='upload-list'] li,[class*='file-list'] li,[class*='is-success']"))
      .some(visible);
    const uploadEvidence = uploadListItem || /上传中|上传成功|上传完成|已上传|100%|\.gif|\.webp|\.png|\.jpe?g|\.mp4|\.mov/i.test(text);
    const uploadPlaceholderGone = !/拖动|点击上传|或点击上传/.test(text) && uploadEvidence;
    const contentPresent = mediaPreview || uploadListItem || uploadPlaceholderGone;
    const statusNodes = Array.from(root.querySelectorAll("button,a,span,div,label,p,i"))
      .filter((el) => visible(el) && normalize(el.innerText || el.textContent).includes(normalize(expectedStatus)));
    const greenStatus = statusNodes.some((el) => hasGreenStatus(el, visible));
    const statusTextFound = statusNodes.length > 0 || normalize(text).includes(normalize(expectedStatus));
    const ready = Boolean(contentPresent && statusTextFound && greenStatus);
    let reason = "";
    if (!contentPresent) reason = "上传区为空或没有预览";
    else if (!statusTextFound) reason = `没有看到“${expectedStatus}”`;
    else if (!greenStatus) reason = `“${expectedStatus}”不是绿色状态`;
    return {
      ready,
      text: text.slice(0, 500),
      contentPresent,
      statusTextFound,
      greenStatus,
      mediaPreview,
      uploadListItem,
      uploadPlaceholderGone,
      reason
    };

    function hasGreenStatus(statusEl, visible) {
      let current = statusEl;
      for (let depth = 0; current && depth < 6; depth += 1) {
        if (visible(current) && elementLooksGreen(current)) return true;
        const nearby = [
          current.previousElementSibling,
          current.nextElementSibling,
          ...Array.from(current.children || [])
        ].filter(Boolean);
        if (nearby.some((el) => visible(el) && elementLooksGreen(el))) return true;
        const rect = current.getBoundingClientRect?.();
        if (depth > 1 && rect && rect.width * rect.height > 80000) break;
        current = current.parentElement;
      }
      return false;
    }

    function elementLooksGreen(el) {
      const className = String(el.className || "");
      if (/(warning|danger|error|orange|yellow|gray|grey|disabled|loading|process)/i.test(className)) return false;
      const s = getComputedStyle(el);
      const colors = [s.color, s.backgroundColor, s.borderColor, s.borderTopColor, s.fill]
        .map(parseColor)
        .filter(Boolean);
      if (colors.some(isGreenColor)) return true;
      return /(success|green|ready|ok|complete|finished|is-success)/i.test(className);
    }

    function parseColor(value) {
      const text = String(value || "").trim();
      if (!text || text === "transparent" || text === "rgba(0, 0, 0, 0)") return null;
      const rgb = text.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (rgb) return { r: Number(rgb[1]), g: Number(rgb[2]), b: Number(rgb[3]) };
      const hex = text.match(/^#([0-9a-f]{6})$/i);
      if (hex) {
        const n = Number.parseInt(hex[1], 16);
        return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
      }
      return null;
    }

    function isGreenColor(color) {
      return color.g >= 100 && color.g > color.r * 1.2 && color.g > color.b * 1.1;
    }
  }, {
    expectedStatus: options.expectedStatus || T.ready,
    taskType: options.taskType || ""
  }).catch((error) => ({ ready: false, text: error?.message || "", reason: error?.message || "" }));
}

async function readStickerAreaState(page) {
  return readMediaReadyState(page, { expectedStatus: T.ready, taskType: "sticker" });
}

async function readStickerAreaText(page) {
  const state = await readStickerAreaState(page);
  return state.text || "";
}

async function confirmStickerUploadIfNeeded(page, task) {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    const state = await findStickerCompressionConfirmPoint(page);
    if (state.present && state.point) {
      await page.mouse.click(state.point.x, state.point.y);
      await page.waitForTimeout(700);
      return true;
    }
    if (state.present && !state.point) {
      const text = state.text || "未读取到可见文字";
      throw new Error(`第 ${task.index} 条压缩后上传弹窗没有找到“确认上传”按钮。弹窗内容：${text}`);
    }
    const stickerState = await readMediaReadyState(page, { expectedStatus: T.ready, taskType: "sticker" });
    if (stickerState.ready) return false;
    await page.waitForTimeout(500);
  }
  return false;
}

async function findStickerCompressionConfirmPoint(page) {
  return page.evaluate((T) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const normalize = (value) => compact(value).replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const textOf = (el) => compact(el?.innerText || el?.textContent);
    const dialogSelectors = [
      ".el-dialog",
      ".el-message-box",
      "[role='dialog']",
      ".ant-modal",
      ".modal",
      "[class*='dialog']",
      "[class*='modal']"
    ].join(",");
    const dialogRoots = Array.from(document.querySelectorAll(dialogSelectors))
      .filter((el) => visible(el) && normalize(textOf(el)).includes(normalize("压缩后上传")));
    if (!dialogRoots.length && !normalize(document.body?.innerText || "").includes(normalize("压缩后上传"))) {
      return { present: false, text: "" };
    }
    const roots = dialogRoots.length ? dialogRoots : [document.body];
    const candidates = [];
    for (const root of roots) {
      const rootText = textOf(root).slice(0, 800);
      const elements = Array.from(root.querySelectorAll("button,[role='button'],.el-button,a,span"));
      for (const el of elements) {
        const text = textOf(el);
        const normalized = normalize(text);
        if (!visible(el) || !normalized.includes(normalize(T.confirmUpload))) continue;
        const clickable = el.closest?.("button,[role='button'],.el-button,a") || el;
        if (!visible(clickable)) continue;
        const r = clickable.getBoundingClientRect();
        const className = String(clickable.className || "");
        candidates.push({
          x: r.left + r.width / 2,
          y: r.top + r.height / 2,
          top: r.top,
          area: r.width * r.height,
          exact: normalized === normalize(T.confirmUpload) ? 0 : 1,
          primary: /primary|success|blue/i.test(className) ? 0 : 1,
          rootText
        });
      }
    }
    candidates.sort((a, b) => a.exact - b.exact || a.primary - b.primary || a.area - b.area || b.top - a.top);
    return {
      present: true,
      point: candidates[0] ? { x: candidates[0].x, y: candidates[0].y } : null,
      text: (candidates[0]?.rootText || textOf(roots[0])).slice(0, 800)
    };
  }, T).catch((error) => ({ present: false, text: error?.message || "" }));
}

async function uploadFile(page, localPath, task) {
  if (await setFileInput(page, localPath)) return;
  const chooserPromise = page.waitForEvent("filechooser", { timeout: 6000 }).catch(() => null);
  const point = await findSmallTextPoint(page, uploadLabels(task.type));
  if (point) await page.mouse.click(point.x, point.y);
  const chooser = await chooserPromise;
  if (chooser) {
    await chooser.setFiles(localPath);
    await confirmUploadIfNeeded(page);
    return;
  }
  if (await setFileInput(page, localPath)) {
    await confirmUploadIfNeeded(page);
    return;
  }
  throw new Error(`第 ${task.index} 条没有找到素材上传入口。`);
}

async function setFileInput(page, localPath) {
  for (const frame of page.frames()) {
    const inputs = frame.locator('input[type="file"]');
    const count = await inputs.count().catch(() => 0);
    for (let index = count - 1; index >= 0; index -= 1) {
      try {
        await inputs.nth(index).setInputFiles(localPath, { timeout: 2000 });
        return true;
      } catch {}
    }
  }
  return false;
}

async function confirmUploadIfNeeded(page) {
  const point = await findSmallTextPoint(page, [T.confirmUpload, "压缩后上传"]);
  if (!point) return false;
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(700);
  return true;
}

async function findSmallTextPoint(page, labels) {
  return page.evaluate((labels) => {
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const candidates = Array.from(document.querySelectorAll("button,a,span,div,label,p"))
      .filter((el) => visible(el) && labels.some((label) => String(el.innerText || el.textContent || "").includes(label)))
      .map((el) => {
        const r = el.getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2, top: r.top, area: r.width * r.height };
      })
      .filter((item) => item.area > 10);
    candidates.sort((a, b) => a.area - b.area || a.top - b.top);
    return candidates[0] || null;
  }, labels).catch(() => null);
}

async function findActionTextPoint(page, labels) {
  return page.evaluate((labels) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const targets = labels.map(normalize);
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const textOf = (el) => String(el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
    const selectors = "button,[role='button'],.el-button,a,span";
    const candidates = Array.from(document.querySelectorAll(selectors))
      .filter((el) => visible(el) && targets.some((target) => normalize(textOf(el)).includes(target)))
      .map((el) => {
        const r = el.getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2, top: r.top, area: r.width * r.height, text: textOf(el) };
      })
      .filter((item) => item.area > 10);
    candidates.sort((a, b) => {
      const aExact = targets.includes(normalize(a.text)) ? 0 : 1;
      const bExact = targets.includes(normalize(b.text)) ? 0 : 1;
      return aExact - bExact || a.area - b.area || a.top - b.top;
    });
    return candidates[0] || null;
  }, labels).catch(() => null);
}

async function waitForSubmitUiSettled(page, options = {}) {
  const timeoutMs = options.timeoutMs || 5000;
  const start = Date.now();
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    lastState = await readSubmitUiBusyState(page);
    if (!lastState.busy) return true;
    await page.waitForTimeout(150);
  }
  const reason = lastState?.reason || "确认弹窗/遮罩/加载状态未结束";
  throw new Error(`第 ${options.taskIndex || ""} 条提交前页面还没有恢复：${reason}`);
}

async function waitForLatestSubmitConfirmDialog(page, options = {}) {
  const timeoutMs = options.timeoutMs || 8000;
  const start = Date.now();
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    lastState = await findLatestSubmitConfirmDialog(page);
    if (submitConfirmDialogReady(lastState)) return lastState;
    await page.waitForTimeout(80);
  }
  return lastState || { present: false, point: null, text: "" };
}

async function waitForSubmitGateDialog(page, options = {}) {
  const timeoutMs = options.timeoutMs || 8000;
  const start = Date.now();
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    const expired = await readExpiredScheduleDialog(page);
    if (expired.present) return expired;
    const confirm = await readSubmitConfirmDialog(page);
    if (submitConfirmDialogReady(confirm)) return confirm;
    lastState = await findLatestSubmitConfirmDialog(page);
    if (submitConfirmDialogReady(lastState)) return lastState;
    await page.waitForTimeout(80);
  }
  return lastState || { present: false, point: null, text: "" };
}

async function waitForAnySubmitConfirmDialog(page, options = {}) {
  const timeoutMs = options.timeoutMs || 2500;
  const start = Date.now();
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    const confirm = await readSubmitConfirmDialog(page);
    if (submitConfirmDialogReady(confirm)) return confirm;
    lastState = await findLatestSubmitConfirmDialog(page);
    if (submitConfirmDialogReady(lastState)) return lastState;
    await page.waitForTimeout(100);
  }
  return lastState || { present: false, point: null, text: "" };
}

function submitConfirmDialogReady(dialog = {}) {
  if (!dialog.present) return false;
  return Boolean(dialog.confirmPoint || dialog.point || dialog.robotNotInGroup);
}

async function waitForExpiredScheduleDialog(page, options = {}) {
  const timeoutMs = options.timeoutMs || 1200;
  const start = Date.now();
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    lastState = await readExpiredScheduleDialog(page);
    if (lastState.present) return lastState;
    await page.waitForTimeout?.(200).catch(() => {});
  }
  return lastState || { present: false, expiredSchedule: false, text: "", time: "", confirmPoint: null, cancelPoint: null };
}

export async function readExpiredScheduleDialog(page) {
  if (!page || typeof page.evaluate !== "function") {
    return { present: false, expiredSchedule: false, text: "", time: "", confirmPoint: null, cancelPoint: null };
  }
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const normalize = (value) => compact(value).replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const textOf = (el) => compact(el?.innerText || el?.textContent);
    const dialogSelectors = [
      ".el-message-box",
      ".el-dialog",
      "[role='dialog']",
      ".ant-modal",
      ".modal",
      "[class*='message-box']",
      "[class*='dialog']",
      "[class*='modal']"
    ].join(",");
    const dialogs = Array.from(document.querySelectorAll(dialogSelectors))
      .filter(visible)
      .map((el, order) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return {
          el,
          order,
          zIndex: Number.parseInt(style.zIndex || "0", 10) || 0,
          area: rect.width * rect.height,
          text: textOf(el)
        };
      })
      .filter((item) => {
        const text = normalize(item.text);
        return text.includes("定时时间") && text.includes("已经过了") && text.includes("立即执行");
      });
    dialogs.sort((a, b) => b.zIndex - a.zIndex || b.order - a.order || b.area - a.area);
    if (!dialogs.length) return { present: false, expiredSchedule: false, text: "", time: "", confirmPoint: null, cancelPoint: null };

    const dialog = dialogs[0];
    const buttons = Array.from(dialog.el.querySelectorAll("button,[role='button'],.el-button,a"))
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = textOf(el);
        const normalized = normalize(text);
        return {
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2,
          text,
          normalized,
          blue: elementLooksBlue(el),
          area: rect.width * rect.height,
          top: rect.top
        };
      });
    const yes = buttons
      .filter((item) => item.normalized === "是" || item.normalized.includes("确定") || item.normalized.includes("立即执行"))
      .sort((a, b) => Number(b.blue) - Number(a.blue) || a.area - b.area || b.top - a.top)[0];
    const no = buttons
      .filter((item) => item.normalized === "否" || item.normalized.includes("取消"))
      .sort((a, b) => Number(a.blue) - Number(b.blue) || a.area - b.area || b.top - a.top)[0];
    const time = dialog.text.match(/今天\s*(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1] || "";
    return {
      present: true,
      expiredSchedule: true,
      text: dialog.text.slice(0, 1000),
      time,
      confirmPoint: yes ? { x: yes.x, y: yes.y } : null,
      cancelPoint: no ? { x: no.x, y: no.y } : null
    };

    function elementLooksBlue(el) {
      const className = String(el.className || "");
      if (/primary|blue/i.test(className)) return true;
      const style = getComputedStyle(el);
      const colors = [style.backgroundColor, style.borderColor, style.borderTopColor, style.color]
        .map(parseColor)
        .filter(Boolean);
      return colors.some((color) => color.b >= 120 && color.b > color.r * 1.15 && color.b >= color.g * 0.85);
    }

    function parseColor(value) {
      const text = String(value || "").trim();
      const rgb = text.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (rgb) return { r: Number(rgb[1]), g: Number(rgb[2]), b: Number(rgb[3]) };
      const hex = text.match(/^#([0-9a-f]{6})$/i);
      if (!hex) return null;
      const n = Number.parseInt(hex[1], 16);
      return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    }
  }).catch((error) => ({
    present: false,
    expiredSchedule: false,
    text: error?.message || "",
    time: "",
    confirmPoint: null,
    cancelPoint: null
  }));
}

async function waitForPolicySubmitConfirmDialog(page, options = {}) {
  const timeoutMs = options.timeoutMs || 8000;
  const start = Date.now();
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    lastState = await readSubmitConfirmDialog(page);
    if (lastState.present) return lastState;
    await page.waitForTimeout(300);
  }
  return lastState || { present: false, confirmPoint: null, cancelPoint: null, text: "" };
}

async function waitForSubmitCompletion(page, options = {}) {
  const timeoutMs = options.timeoutMs || 12000;
  const pollMs = options.pollMs || 500;
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const result = await readSubmitResultSnapshot(page);
    if (result.failed || result.ok) return result;
    if (options.responseErrors?.length) {
      return { failed: true, message: options.responseErrors[0] };
    }
    const expired = await readExpiredScheduleDialog(page);
    if (expired.present) {
      return { expiredSchedule: true, dialog: expired, message: expired.text || "过期定时弹窗" };
    }
    await page.waitForTimeout(pollMs);
  }
  if (options.responseErrors?.length) return { failed: true, message: options.responseErrors[0] };
  return { ok: false, message: "未检测到成功提示" };
}

async function waitForSubmitMediaNotReadyNotice(page, options = {}) {
  const timeoutMs = options.timeoutMs || 900;
  const start = Date.now();
  let last = null;
  while (Date.now() - start < timeoutMs) {
    last = await readSubmitMediaNotReadyNotice(page);
    if (last.present) return last;
    if (typeof page.waitForTimeout !== "function") break;
    await page.waitForTimeout(120);
  }
  return last || { present: false, text: "" };
}

async function readSubmitMediaNotReadyNotice(page) {
  if (!page || typeof page.evaluate !== "function") return { present: false, text: "" };
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const isMediaNotReady = (text) => {
      const value = compact(text);
      return /素材/.test(value) && /(未就绪|极速模式未就绪|重新检查素材就绪状态|请重新检查)/.test(value);
    };
    const selectors = ".el-message,.el-notification,.toast,.ivu-message,.ant-message,.el-alert,[role='alert']";
    const messages = Array.from(document.querySelectorAll(selectors))
      .filter(visible)
      .map((el) => compact(el.innerText || el.textContent))
      .filter(Boolean);
    const matched = messages.find(isMediaNotReady);
    if (matched) return { present: true, text: matched.slice(0, 500) };
    return { present: false, text: "" };
  }).catch((error) => ({ present: false, text: error?.message || "" }));
}

async function readSubmitInProgressEvidence(page, tracker = {}) {
  const clickedAt = tracker.submitClickAt || 0;
  const activity = tracker.activity || {};
  if (clickedAt && activity.lastAt && activity.lastAt >= clickedAt) {
    return { active: true, reason: "submit-network-activity", lastUrl: activity.lastUrl || "" };
  }
  const state = await page.evaluate((T) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const normalize = (value) => compact(value).replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const loadingSelectors = [
      ".el-loading-mask",
      ".ant-spin-spinning",
      ".ivu-spin-fix",
      "[class*='loading']",
      "[class*='Loading']"
    ].join(",");
    const loadingText = Array.from(document.querySelectorAll(loadingSelectors))
      .filter(visible)
      .map((el) => compact(`${el.innerText || el.textContent || ""} ${el.className || ""}`))
      .find((text) => /加载|提交|创建|处理中|loading|spin/i.test(text));
    if (loadingText) return { active: true, reason: `loading:${loadingText.slice(0, 80)}` };

    const messageSelectors = ".el-message,.el-notification,.toast,.ivu-message,.ant-message";
    const transientText = Array.from(document.querySelectorAll(messageSelectors))
      .filter(visible)
      .map((el) => compact(el.innerText || el.textContent))
      .find((text) => /提交中|创建中|加载中|处理中/.test(text));
    if (transientText) return { active: true, reason: `message:${transientText.slice(0, 80)}` };

    const labels = [T.confirmCreate, "确定创建"].map(normalize);
    const dialogSelectors = [
      ".el-message-box",
      ".el-dialog",
      "[role='dialog']",
      ".ant-modal",
      ".modal",
      "[class*='message-box']",
      "[class*='dialog']",
      "[class*='modal']"
    ].join(",");
    const dialogs = Array.from(document.querySelectorAll(dialogSelectors)).filter(visible);
    const buttons = dialogs.flatMap((dialog) => Array.from(dialog.querySelectorAll("button,[role='button'],.el-button,a")))
      .filter(visible)
      .filter((el) => labels.some((label) => normalize(el.innerText || el.textContent).includes(label)));
    const button = buttons[0];
    if (!button) return { active: false, reason: "confirm-button-not-found" };
    const className = String(button.className || "");
    const text = compact(button.innerText || button.textContent);
    const disabled = Boolean(button.disabled) || button.getAttribute?.("disabled") != null || button.getAttribute?.("aria-disabled") === "true";
    const loading = /is-loading|loading|加载|提交中|创建中|处理中/i.test(`${className} ${text}`);
    return {
      active: disabled || loading,
      reason: disabled ? "confirm-button-disabled" : loading ? `confirm-button-loading:${text}` : "confirm-button-idle"
    };
  }, T).catch(() => ({ active: false, reason: "progress-check-failed" }));
  return state;
}

async function waitForPageEditableAfterSubmit(page, options = {}) {
  const timeoutMs = options.timeoutMs || 8000;
  const start = Date.now();
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    lastState = await readSubmitUiBusyState(page);
    if (!lastState.busy && await pageLooksLikeCreateForm(page)) {
      return { ok: true };
    }
    await page.waitForTimeout(400);
  }
  return { ok: false, message: lastState?.reason || "页面仍在确认/加载状态" };
}

async function readSubmitUiBusyState(page) {
  const dialog = await findLatestSubmitConfirmDialog(page);
  const state = await page.evaluate((T) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const loadingSelectors = [
      ".el-loading-mask",
      ".ant-spin-spinning",
      ".ivu-spin-fix",
      "[class*='loading']",
      "[class*='Loading']"
    ].join(",");
    const loading = Array.from(document.querySelectorAll(loadingSelectors))
      .filter(visible)
      .some((el) => {
        const text = compact(el.innerText || el.textContent);
        const className = String(el.className || "");
        return /加载|提交|创建|处理中|loading|spin/i.test(`${text} ${className}`);
      });
    const messageSelectors = ".el-message,.el-notification,.toast,.ivu-message,.ant-message";
    const transientText = Array.from(document.querySelectorAll(messageSelectors))
      .filter(visible)
      .map((el) => compact(el.innerText || el.textContent))
      .filter((text) => /提交中|创建中|加载中|处理中/.test(text))
      .join(" ");
    return {
      loading,
      transientText,
      reason: loading ? "页面仍有加载遮罩" : transientText ? `页面仍有处理中提示：${transientText}` : ""
    };
  }, T).catch(() => ({ loading: false, transientText: "", reason: "" }));
  const busy = Boolean(dialog.present || state.loading || state.transientText);
  return {
    busy,
    reason: dialog.present ? `仍有确认弹窗：${dialog.text || ""}` : state.reason
  };
}

async function findLatestSubmitConfirmDialog(page) {
  const result = await page.evaluate((T) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const normalize = (value) => compact(value).replace(/\s+/g, "");
    const labels = [T.confirmCreate, "确定创建"].map(normalize);
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const textOf = (el) => compact(el?.innerText || el?.textContent);
    const dialogSelectors = [
      ".el-message-box",
      ".el-dialog",
      "[role='dialog']",
      ".ant-modal",
      ".modal",
      "[class*='message-box']",
      "[class*='dialog']",
      "[class*='modal']"
    ].join(",");
    const dialogs = Array.from(document.querySelectorAll(dialogSelectors))
      .filter((el) => visible(el))
      .map((el, order) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return {
          el,
          order,
          zIndex: Number.parseInt(style.zIndex || "0", 10) || 0,
          area: rect.width * rect.height,
          text: textOf(el),
          top: rect.top
        };
      })
      .filter((item) => {
        const text = normalize(item.text);
        return labels.some((label) => text.includes(label)) || /确定要执行发送|当前已选择/.test(item.text);
      });
    dialogs.sort((a, b) => b.zIndex - a.zIndex || b.order - a.order || b.area - a.area);
    if (!dialogs.length) return { present: false, point: null, text: "", robotCount: null };
    const dialog = dialogs[0];
    const buttonSelectors = "button,[role='button'],.el-button,a";
    const cancelLabels = ["取消", "关闭"].map(normalize);
    const candidates = Array.from(dialog.el.querySelectorAll(buttonSelectors))
      .filter((el) => visible(el))
      .map((el) => {
        const text = textOf(el);
        const normalized = normalize(text);
        const rect = el.getBoundingClientRect();
        const className = String(el.className || "");
        const disabledAttr = el.getAttribute?.("disabled");
        const ariaDisabled = el.getAttribute?.("aria-disabled");
        const primary = elementLooksBlue(el) ? 0 : 1;
        const exact = labels.includes(normalized) ? 0 : 1;
        return {
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2,
          text,
          normalized,
          exact,
          primary,
          disabled: Boolean(el.disabled) || (disabledAttr !== null && disabledAttr !== undefined && disabledAttr !== "") || ariaDisabled === "true",
          loading: /is-loading|loading|加载|提交中|创建中|处理中/i.test(`${className} ${text}`),
          area: rect.width * rect.height,
          top: rect.top
        };
      })
      .filter((item) => labels.some((label) => item.normalized.includes(label)))
      .filter((item) => !item.disabled && !item.loading);
    const cancelCandidates = Array.from(dialog.el.querySelectorAll(buttonSelectors))
      .filter((el) => visible(el))
      .map((el) => {
        const text = textOf(el);
        const normalized = normalize(text);
        const rect = el.getBoundingClientRect();
        const primary = elementLooksBlue(el) ? 0 : 1;
        return {
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2,
          text,
          normalized,
          primary,
          area: rect.width * rect.height,
          top: rect.top
        };
      })
      .filter((item) => cancelLabels.includes(item.normalized));
    candidates.sort((a, b) => a.primary - b.primary || a.exact - b.exact || a.area - b.area || b.top - a.top);
    cancelCandidates.sort((a, b) => b.primary - a.primary || a.area - b.area || b.top - a.top);
    const blueCandidate = candidates.find((item) => item.primary === 0);
    return {
      present: true,
      point: blueCandidate ? { x: blueCandidate.x, y: blueCandidate.y } : null,
      confirmPoint: blueCandidate ? { x: blueCandidate.x, y: blueCandidate.y } : null,
      cancelPoint: cancelCandidates[0] ? { x: cancelCandidates[0].x, y: cancelCandidates[0].y } : null,
      robotNotInGroup: /机器人\s*不在群/.test(compact(dialog.text)),
      robotCount: null,
      text: dialog.text.slice(0, 800)
    };

    function elementLooksBlue(el) {
      const className = String(el.className || "");
      if (/primary|blue/i.test(className)) return true;
      const style = getComputedStyle(el);
      const colors = [style.backgroundColor, style.borderColor, style.borderTopColor, style.color]
        .map(parseColor)
        .filter(Boolean);
      return colors.some((color) => color.b >= 120 && color.b > color.r * 1.15 && color.b >= color.g * 0.85);
    }

    function parseColor(value) {
      const text = String(value || "").trim();
      const rgb = text.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (rgb) return { r: Number(rgb[1]), g: Number(rgb[2]), b: Number(rgb[3]) };
      const hex = text.match(/^#([0-9a-f]{6})$/i);
      if (!hex) return null;
      const n = Number.parseInt(hex[1], 16);
      return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    }
  }, T).catch((error) => ({ present: false, point: null, text: error?.message || "", robotCount: null }));
  return {
    ...result,
    robotCount: parseSubmitConfirmRobotCount(result?.text)
  };
}

async function readSubmitResultSnapshot(page) {
  const successWords = [T.success, "创建成功", "提交成功", "成功"];
  const failureWords = ["创建失败", "提交失败", "失败", "错误", "异常"];
  return page.evaluate(({ successWords, failureWords }) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const submitCountSummary = (value) => {
      const text = compact(value);
      const success = text.match(/成功\s*[:：]\s*(\d+)/);
      const failure = text.match(/失败\s*[:：]\s*(\d+)/);
      if (!success && !failure) return null;
      const successCount = success ? Number(success[1]) : 0;
      const failureCount = failure ? Number(failure[1]) : 0;
      if (failureCount > 0) return { failed: true, message: text };
      if (successCount > 0 && failureCount === 0) return { ok: true, message: text };
      return { pending: true, message: text };
    };
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const selectors = ".el-message,.el-notification,.el-message-box,.el-dialog,[role='alert'],.el-alert,.toast,.ivu-message,.ant-message";
    const messages = Array.from(document.querySelectorAll(selectors))
      .filter(visible)
      .map((el) => compact(el.innerText || el.textContent))
      .filter(Boolean);
    for (const message of messages) {
      const summary = submitCountSummary(message);
      if (summary?.failed || summary?.ok) return summary;
    }
    const bodySummary = submitCountSummary(document.body?.innerText || "");
    if (bodySummary?.failed || bodySummary?.ok) return bodySummary;
    const failureMessage = messages.find((text) => !submitCountSummary(text)?.pending && failureWords.some((word) => text.includes(word)));
    if (failureMessage) return { failed: true, message: failureMessage };
    const successMessage = messages.find((text) => successWords.some((word) => text.includes(word)));
    if (successMessage) return { ok: true, message: successMessage };
    return { ok: false, messages };
  }, { successWords, failureWords }).catch(() => ({ ok: false }));
}

async function assertCurrentEditorContentPresent(page, task, options = {}) {
  if (["image", "sticker", "video"].includes(task.type)) {
    const mediaState = await waitForCurrentEditorMediaReady(page, task, {
      timeoutMs: options.mediaReadyTimeoutMs || 60000
    });
    if (mediaState.ready) return mediaState;
    const visibleText = mediaState.text ? ` 可见文字：${mediaState.text}` : "";
    throw new Error(`第 ${task.index} 条素材未就绪，已停止，不会执行发送。原因：${mediaState.reason || "没有检测到绿色可用状态"}${visibleText}`);
  }
  const state = await readCurrentEditorContentState(page, task);
  if (!state.ok) {
    const reason = state.reason ? `原因：${state.reason}` : "";
    throw new Error(`第 ${task.index} 条右侧编辑器内容为空，已停止，不会执行发送。${reason}`);
  }
  return state;
}

async function waitForCurrentEditorMediaReady(page, task, options = {}) {
  const timeoutMs = Math.max(1000, Number(options.timeoutMs || 60000));
  const start = Date.now();
  let lastState = null;
  while (Date.now() - start < timeoutMs) {
    lastState = await readMediaReadyState(page, { expectedStatus: T.ready, taskType: task.type });
    if (lastState.ready) return lastState;
    if (typeof page.waitForTimeout !== "function") break;
    await page.waitForTimeout(700);
  }
  return lastState || { ready: false, text: "", reason: "没有检测到绿色可用状态" };
}

async function readCurrentEditorContentState(page, task = {}) {
  return page.evaluate(({ taskText, taskType, readyText }) => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const normalize = (value) => compact(value).replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = typeof getComputedStyle === "function" ? getComputedStyle(el) : { visibility: "visible", display: "block" };
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const editorRoots = Array.from(document.querySelectorAll(".drama-content,.drama-item,[class*='drama-content'],[class*='drama-item']"))
      .filter(visible);
    const rootSet = new Set(editorRoots);
    const inEditor = (el) => Array.from(rootSet).some((root) => root === el || root.contains(el));
    const scriptPlaceholder = (el) => {
      const placeholder = String(el.getAttribute("placeholder") || el.getAttribute("data-placeholder") || "");
      if (placeholder.includes("请输入文字")) return true;
      if (taskType === "finder" && /视频号|参数/.test(placeholder)) return true;
      return false;
    };
    const editorTextareas = Array.from(document.querySelectorAll("textarea,[contenteditable='true']"))
      .filter((el) => visible(el) && inEditor(el))
      .filter((el) => scriptPlaceholder(el) || taskType === "finder");
    const textValues = editorTextareas
      .map((el) => compact(el.value || el.innerText || el.textContent))
      .filter(Boolean);
    const expected = normalize(taskText);
    const textMatched = textValues.some((value) => {
      const normalized = normalize(value);
      if (!expected) return normalized.length > 0;
      return normalized.includes(expected) || expected.includes(normalized);
    });
    if (taskType === "text" || taskType === "finder") {
      return {
        ok: textMatched,
        mode: taskType,
        textValues: textValues.slice(0, 3),
        reason: editorTextareas.length ? (textValues.length ? "编辑脚本内容文本框与本条预览内容不一致" : "编辑脚本内容文本框为空") : "找不到编辑脚本内容文本框"
      };
    }
    return {
      ok: textMatched,
      mode: taskType || "unknown",
      textValues: textValues.slice(0, 3),
      reason: "右侧编辑器没有检测到可发送内容"
    };
  }, {
    taskText: task.text || "",
    taskType: task.type || "",
    readyText: T.ready
  }).catch((error) => ({
    ok: false,
    reason: error?.message || "无法读取右侧编辑器内容"
  }));
}

async function readScriptContentListState(page) {
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const body = document.body?.innerText || "";
    const match = body.match(/当前分组([\s\S]*?)执行发送设置/);
    const section = match?.[1] || "";
    const empty = /暂无剧本/.test(section);
    const blocked = [
      /^1、默认分组$/,
      /^添加快捷内容$/,
      /^当前分组$/,
      /^暂无剧本/,
      /^点击右侧/,
      /^进行添加$/
    ];
    const lines = section.split(/\n+/)
      .map(compact)
      .filter(Boolean)
      .filter((line) => !blocked.some((pattern) => pattern.test(line)));
    return {
      count: empty ? 0 : lines.length,
      empty,
      items: lines.slice(0, 10)
    };
  }).catch(() => ({ count: 0, empty: true, items: [] }));
}

async function waitForSubmitResult(page, options = {}) {
  const timeoutMs = options.timeoutMs || 12000;
  const start = Date.now();
  const successWords = [T.success, "创建成功", "提交成功", "成功"];
  const failureWords = ["创建失败", "提交失败", "失败", "错误", "异常"];
  while (Date.now() - start < timeoutMs) {
    const result = await page.evaluate(({ successWords, failureWords }) => {
      const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
      const submitCountSummary = (value) => {
        const text = compact(value);
        const success = text.match(/成功\s*[:：]\s*(\d+)/);
        const failure = text.match(/失败\s*[:：]\s*(\d+)/);
        if (!success && !failure) return null;
        const successCount = success ? Number(success[1]) : 0;
        const failureCount = failure ? Number(failure[1]) : 0;
        if (failureCount > 0) return { failed: true, message: text };
        if (successCount > 0 && failureCount === 0) return { ok: true, message: text };
        return { pending: true, message: text };
      };
      const visible = (el) => {
        const r = el?.getBoundingClientRect?.();
        const s = el ? getComputedStyle(el) : null;
        return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
          && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
      };
      const selectors = ".el-message,.el-notification,.el-message-box,.el-dialog,[role='alert'],.el-alert,.toast,.ivu-message,.ant-message";
      const messages = Array.from(document.querySelectorAll(selectors))
        .filter(visible)
        .map((el) => compact(el.innerText || el.textContent))
        .filter(Boolean);
      for (const message of messages) {
        const summary = submitCountSummary(message);
        if (summary?.failed || summary?.ok) return summary;
      }
      const bodySummary = submitCountSummary(document.body?.innerText || "");
      if (bodySummary?.failed || bodySummary?.ok) return bodySummary;
      const failureMessage = messages.find((text) => !submitCountSummary(text)?.pending && failureWords.some((word) => text.includes(word)));
      if (failureMessage) return { failed: true, message: failureMessage };
      const successMessage = messages.find((text) => successWords.some((word) => text.includes(word)));
      if (successMessage) return { ok: true, message: successMessage };
      return { ok: false, messages };
    }, { successWords, failureWords }).catch(() => ({ ok: false }));
    if (result.failed || result.ok) return result;
    if (options.responseErrors?.length) {
      return { failed: true, message: options.responseErrors[0] };
    }
    await page.waitForTimeout(500);
  }
  if (options.responseErrors?.length) return { failed: true, message: options.responseErrors[0] };
  return { ok: false, message: "未检测到成功提示" };
}

async function readVisiblePageMessages(page) {
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const selectors = ".el-message,.el-notification,.el-message-box,.el-dialog,[role='alert'],.el-alert,.toast,.ivu-message,.ant-message";
    return Array.from(document.querySelectorAll(selectors))
      .filter(visible)
      .map((el) => compact(el.innerText || el.textContent))
      .filter(Boolean)
      .slice(0, 5);
  }).catch(() => []);
}

function collectSubmitResponseErrors(page) {
  const errors = [];
  const activity = { count: 0, lastAt: 0, lastUrl: "" };
  let submitClickAt = 0;
  if (typeof page.on !== "function" || typeof page.off !== "function") {
    return {
      errors,
      activity,
      get submitClickAt() {
        return submitClickAt;
      },
      markSubmitClick() {
        submitClickAt = Date.now();
      },
      dispose() {}
    };
  }
  const matchesSubmitUrl = (url) => /iyunzk|cms|api|task|send|mood|FenWei/i.test(url);
  const markActivity = (url) => {
    activity.count += 1;
    activity.lastAt = Date.now();
    activity.lastUrl = url || "";
  };
  const requestHandler = (request) => {
    try {
      const url = request.url?.() || "";
      if (matchesSubmitUrl(url)) markActivity(url);
    } catch {}
  };
  const handler = async (response) => {
    try {
      const url = response.url?.() || "";
      if (!matchesSubmitUrl(url)) return;
      markActivity(url);
      const status = response.status?.() || 0;
      const headers = response.headers?.() || {};
      const contentType = headers["content-type"] || headers["Content-Type"] || "";
      if (status >= 400) {
        const text = await response.text().catch(() => "");
        errors.push(`接口 ${status}：${compactError(text || url)}`);
        return;
      }
      if (!/json|text/i.test(contentType)) return;
      const text = await response.text().catch(() => "");
      const message = extractResponseError(text);
      if (message) errors.push(message);
    } catch {}
  };
  page.on("request", requestHandler);
  page.on("response", handler);
  return {
    errors,
    activity,
    get submitClickAt() {
      return submitClickAt;
    },
    markSubmitClick() {
      submitClickAt = Date.now();
    },
    dispose() {
      page.off("request", requestHandler);
      page.off("response", handler);
    }
  };
}

function extractResponseError(text) {
  const value = String(text || "").trim();
  if (!value) return "";
  const summary = parseSubmitCountSummary(value);
  if (summary?.ok) return "";
  if (summary?.pending) return "";
  if (summary?.failed) return `接口返回：${compactError(summary.message || value)}`;
  try {
    const parsed = JSON.parse(value);
    const success = parsed.success ?? parsed.ok;
    const code = parsed.code ?? parsed.errcode ?? parsed.errorCode;
    const message = parsed.message || parsed.msg || parsed.error || parsed.errmsg || "";
    const messageSummary = parseSubmitCountSummary(message);
    if (messageSummary?.ok) return "";
    if (messageSummary?.pending) return "";
    if (messageSummary?.failed) return `接口返回：${compactError(messageSummary.message || message)}`;
    if (success === false || (code !== undefined && ![0, "0", 200, "200"].includes(code)) || /失败|错误|异常/.test(message)) {
      return `接口返回：${compactError(message || value)}`;
    }
    return "";
  } catch {}
  if (/失败|错误|异常|不能为空|请选择/.test(value)) return `接口返回：${compactError(value)}`;
  return "";
}

function parseSubmitCountSummary(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  const success = text.match(/成功\s*[:：]\s*(\d+)/);
  const failure = text.match(/失败\s*[:：]\s*(\d+)/);
  if (!success && !failure) return null;
  const successCount = success ? Number(success[1]) : 0;
  const failureCount = failure ? Number(failure[1]) : 0;
  if (failureCount > 0) return { failed: true, message: text, successCount, failureCount };
  if (successCount > 0 && failureCount === 0) return { ok: true, message: text, successCount, failureCount };
  return { pending: true, message: text, successCount, failureCount };
}

function isRobotStatusSubmitFailure(value) {
  const text = String(value || "").replace(/\s+/g, "");
  if (!/提交失败|创建失败|接口返回|失败|异常|错误/.test(text)) return false;
  return /检查机器人状态|机器人状态|机器人掉线|机器人离线|机器人下线|机器人异常|机器人不可用|机器人失效|机器人未在线|机器人.*掉线|机器人.*离线|机器人.*下线|机器人.*异常/.test(text);
}

function compactError(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > 220 ? `${text.slice(0, 219)}...` : text;
}

async function clearFocusedInput(page) {
  await page.keyboard.press(process.platform === "darwin" ? "Meta+A" : "Control+A");
  await page.keyboard.press("Backspace");
}

async function readLocatorText(locator) {
  try {
    return await locator.inputValue({ timeout: 500 });
  } catch {}
  return locator.innerText({ timeout: 500 }).catch(() => "");
}

async function closePopups(page) {
  await page.keyboard.press("Escape").catch(() => {});
  await page.keyboard.press("Escape").catch(() => {});
}

function mediaTabLabel(type) {
  if (type === "image") return T.image;
  if (type === "sticker") return T.sticker;
  if (type === "video") return T.video;
  return T.image;
}

function uploadLabels(type) {
  if (type === "sticker") return [T.upload, "自定义表情包"];
  if (type === "video") return [T.upload, "视频上传", "将视频拖到此处"];
  return [T.upload, "粘贴图片", "将图片拖到此处"];
}

function action(name, task) {
  return {
    name,
    index: task.index,
    role: task.role,
    speaker: task.speaker,
    date: task.date,
    time: task.time,
    type: task.type,
    sourceId: task.sourceId
  };
}

function formatConfirmDialogPolicyLog(entry = {}) {
  const role = entry.role === "douma" ? "豆妈" : "托";
  const prefix = `第 ${entry.taskIndex || "?"} 条：确认弹窗检测到机器人不在群 / role=${role} / speaker=${entry.speaker || "未识别"}`;
  if (entry.event === "robot_not_in_group_ignored") {
    return `${prefix} / 处理=不用管直接创建 / 弹窗=${entry.dialogText || ""}`;
  }
  if (entry.event === "robot_not_in_group_retry") {
    const point = entry.cancelPoint ? ` / 取消坐标=${Math.round(entry.cancelPoint.x)},${Math.round(entry.cancelPoint.y)}` : "";
    return `${prefix} / 第 ${entry.attempt || "?"} 次取消并更换机器人${point} / 弹窗=${entry.dialogText || ""}`;
  }
  if (entry.event === "robot_not_in_group_cancel_failed") {
    const point = entry.cancelPoint ? ` / 取消坐标=${Math.round(entry.cancelPoint.x)},${Math.round(entry.cancelPoint.y)}` : "";
    return `${prefix} / 第 ${entry.attempt || "?"} 次取消失败${point} / 原因=${entry.reason || "取消按钮点击后确认弹窗未关闭"} / 弹窗=${entry.dialogText || ""}`;
  }
  if (entry.event === "robot_not_in_group_switched") {
    return `${prefix} / 第 ${entry.attempt || "?"} 次更换后提示消失，继续确认创建 / 弹窗=${entry.dialogText || ""}`;
  }
  if (entry.event === "robot_not_in_group_stop") {
    return `${prefix} / 已尝试 ${entry.attempt || 0} 次仍不在群，停止当前批次 / 弹窗=${entry.dialogText || ""}`;
  }
  return `${prefix} / 弹窗=${entry.dialogText || ""}`;
}

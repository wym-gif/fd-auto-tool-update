import http from "node:http";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import path from "node:path";
import { applyPreviewDefaultDate, finalPreviewCheck, finalPreviewPath, loadPreviewForOpen, saveFinalPreview } from "./preview-store.js";

export async function createPreviewTestServer(runDir, options = {}) {
  const server = http.createServer((req, res) => {
    handleRequest(req, res, runDir, options).catch((error) => sendJson(res, 500, {
      ok: false,
      error: error?.message || String(error)
    }));
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port || 0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });
  const address = server.address();
  const url = `http://127.0.0.1:${address.port}/`;
  return {
    server,
    url,
    close: () => new Promise((resolve) => server.close(resolve))
  };
}

async function handleRequest(req, res, runDir, options = {}) {
  const url = new URL(req.url || "/", "http://127.0.0.1");
  if (req.method === "GET" && url.pathname === "/") {
    const meta = await loadPreviewPageMeta(runDir);
    const defaultDate = options.defaultDate || meta.defaultDate || "";
    const state = await loadPreviewForOpen(runDir, {
      regenerate: url.searchParams.get("regenerate") === "1",
      defaultDate
    });
    sendHtml(res, renderPreviewPage(state, runDir, {
      ...meta,
      consoleUrl: options.consoleUrl || "",
      defaultDate,
      repairProblem: previewRepairProblemFromUrl(url)
    }));
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/preview") {
    sendJson(res, 200, { ok: true, ...(await loadPreviewForOpen(runDir)) });
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/media-preview") {
    await sendMediaPreview(req, res, url.searchParams.get("path") || "");
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/media-status") {
    sendJson(res, 200, await mediaStatus(url.searchParams.get("path") || ""));
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/library/list") {
    const items = typeof options.onListLibrary === "function"
      ? await options.onListLibrary()
      : (Array.isArray(options.libraryItems) ? options.libraryItems : []);
    sendJson(res, 200, { ok: true, items });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/upload-media") {
    const uploaded = await saveUploadedMedia(req, runDir);
    sendJson(res, 200, { ok: true, ...uploaded });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/preview") {
    const body = await readJsonBody(req);
    const saved = await saveFinalPreview(runDir, body.tasks, { requireComplete: true });
    const saveAdvice = await options.onPreviewSaved?.({
      runDir,
      path: saved.path,
      tasks: saved.tasks,
      autoSave: body.autoSave === true,
      librarySaveMode: body.librarySaveMode,
      libraryName: body.libraryName,
      libraryTargetId: body.libraryTargetId
    });
    sendJson(res, 200, {
      ok: true,
      source: "preview.json",
      path: saved.path,
      tasks: saved.tasks,
      savedAt: new Date().toISOString(),
      consoleUrl: options.consoleUrl || "",
      saveAdvice: saveAdvice || null
    });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/library/save") {
    const body = await readJsonBody(req);
    const saved = await saveFinalPreview(runDir, body.tasks, { requireComplete: true });
    if (!options.onSaveToLibrary) {
      sendJson(res, 400, { ok: false, error: "当前入口没有启用文案库保存。" });
      return;
    }
    const item = await options.onSaveToLibrary({
      runDir,
      path: saved.path,
      tasks: saved.tasks,
      name: body.name,
      forceNew: body.forceNew === true,
      targetId: body.targetId || body.libraryTargetId || ""
    });
    sendJson(res, 200, {
      ok: true,
      source: "preview-library",
      item,
      tasks: saved.tasks,
      savedAt: new Date().toISOString()
    });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/regenerate") {
    if (options.onRegeneratePreview) {
      const result = await options.onRegeneratePreview({ runDir });
      sendJson(res, 202, { ok: true, ...result });
      return;
    }
    const meta = await loadPreviewPageMeta(runDir);
    const state = await loadPreviewForOpen(runDir, {
      regenerate: true,
      defaultDate: options.defaultDate || meta.defaultDate || ""
    });
    sendJson(res, 200, { ok: true, ...state });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/final-check") {
    const body = await readJsonBody(req);
    sendJson(res, 200, await finalPreviewCheck(runDir, body.tasks));
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/prepare-cms") {
    const body = await readJsonBody(req);
    const check = await finalPreviewCheck(runDir, body.tasks);
    if (!check.ok) {
      sendJson(res, 400, check);
      return;
    }
    if (options.onPrepareCms) {
      const result = await options.onPrepareCms({ runDir, tasks: body.tasks, check });
      sendJson(res, 202, { ok: true, preparedCms: true, ...result });
      return;
    }
    sendJson(res, 200, check);
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/return-settings") {
    const result = await options.onReturnSettings?.({ runDir });
    sendJson(res, 200, { ok: true, consoleUrl: options.consoleUrl || "", ...(result || {}) });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/abandon") {
    const body = await readJsonBody(req);
    await savePreviewDraft(runDir, body.tasks || []);
    const result = await options.onAbandon?.({ runDir, tasks: body.tasks || [] });
    sendJson(res, 200, { ok: true, consoleUrl: options.consoleUrl || "", draftPath: path.join(runDir, "preview-draft.json"), ...(result || {}) });
    return;
  }
  sendJson(res, 404, { ok: false, error: "Not found" });
}

function previewRepairProblemFromUrl(url) {
  if (url.searchParams.get("repairMode") !== "shared-upload") return null;
  const index = Number(url.searchParams.get("problemIndex"));
  if (!Number.isInteger(index) || index < 0) return null;
  return {
    index,
    message: url.searchParams.get("problemReason") || `第 ${index + 1} 条素材需要重新上传`
  };
}

function renderPreviewPage(state, runDir, meta = {}) {
  const pageTasks = normalizePreviewTasksForRobotStrategy(
    applyPreviewDefaultDate(state.tasks, meta.defaultDate),
    meta.robotStrategy
  );
  const tasksJson = JSON.stringify(pageTasks).replace(/</g, "\\u003c");
  const source = escapeHtml(state.source);
  const previewPathText = escapeHtml(finalPreviewPath(runDir));
  const runDirText = escapeHtml(runDir);
  const runId = path.basename(path.resolve(runDir));
  const rangeLabel = escapeHtml(meta.rangeLabel || "未记录");
  const rawEventCount = escapeHtml(meta.rawEventCount ?? "-");
  const previewTaskCount = escapeHtml(meta.previewTaskCount ?? state.tasks.length);
  const consoleUrl = JSON.stringify(meta.consoleUrl || "").replace(/</g, "\\u003c");
  const defaultDate = JSON.stringify(meta.defaultDate || "").replace(/</g, "\\u003c");
  const runDirJson = JSON.stringify(runDir).replace(/</g, "\\u003c");
  const runIdJson = JSON.stringify(runId).replace(/</g, "\\u003c");
  const libraryItemJson = JSON.stringify(meta.libraryItem || null).replace(/</g, "\\u003c");
  const robotStrategyJson = JSON.stringify(meta.robotStrategy || "").replace(/</g, "\\u003c");
  const preciseTuoRosterJson = JSON.stringify(meta.preciseTuoRosterOptions || []).replace(/</g, "\\u003c");
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>妙券自动发单 - 预览确认</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, "Microsoft YaHei", sans-serif; background: #f3f6fa; color: #111827; }
    header { position: sticky; top: 0; z-index: 5; background: rgba(255,255,255,0.98); border-bottom: 1px solid #d8dde6; box-shadow: 0 1px 4px rgba(15, 23, 42, 0.04); }
    main { padding: 16px 18px 40px; }
    .topbar { min-height: 70px; padding: 14px 18px 12px; display: flex; align-items: flex-start; justify-content: space-between; gap: 18px; flex-wrap: wrap; }
    .title { font-size: 20px; line-height: 1.2; font-weight: 700; }
    .library-date-notice { display: none; max-width: 760px; margin-top: 8px; color: #92400e; background: #fffbeb; border: 1px solid #fbbf24; border-radius: 6px; padding: 7px 9px; font-size: 13px; line-height: 1.35; font-weight: 700; box-shadow: 0 1px 0 rgba(146,64,14,0.08); }
    .library-date-notice.show { display: block; }
    .subtitle { margin-top: 4px; color: #475569; font-size: 13px; }
    .debug-paths { margin-top: 6px; color: #64748b; font-size: 12px; max-width: 760px; }
    .debug-paths summary { cursor: pointer; user-select: none; }
    .pathline { margin-top: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .run-summary { margin-top: 8px; display: flex; gap: 10px; flex-wrap: wrap; color: #475569; font-size: 12px; }
    .summary-pill { border: 1px solid #d7e0ee; background: #f8fafc; border-radius: 999px; padding: 3px 9px; }
    .actions { display: grid; justify-items: end; gap: 8px; min-width: min(100%, 420px); flex: 1 1 420px; }
    .action-buttons { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; max-width: 100%; }
    .cms-advice { max-width: 520px; text-align: right; font-size: 13px; line-height: 1.4; color: #475569; }
    .cms-advice.reusable { color: #c2410c; background: #fff7ed; border: 1px solid #fed7aa; border-radius: 6px; padding: 6px 8px; font-weight: 700; }
    .cms-advice.blocked { color: #b91c1c; font-weight: 600; }
    .cms-advice.library { color: #0f766e; background: #f0fdfa; border: 1px solid #99f6e4; border-radius: 6px; padding: 6px 8px; font-weight: 700; }
    .cms-advice.cancelled { color: #c2410c; background: #fff7ed; border: 1px solid #fed7aa; border-radius: 6px; padding: 6px 8px; font-weight: 700; }
    .library-btn { border-color: #0f766e; color: #0f766e; }
    .batchbar { margin: 0 18px 12px; padding: 12px; border: 1px solid #d7e0ee; border-radius: 8px; background: #fff; display: grid; gap: 10px; }
    .tool-row { min-height: 36px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .status-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .view-note { font-size: 12px; color: #64748b; line-height: 1.45; }
    button { height: 36px; border: 1px solid #94a3b8; background: #fff; border-radius: 6px; padding: 0 14px; cursor: pointer; font: inherit; }
    button.primary { background: #2563eb; border-color: #2563eb; color: white; }
    button.danger { border-color: #dc2626; color: #b91c1c; }
    button.ghost { border-color: #2563eb; color: #1d4ed8; }
    button.active { background: #111827; border-color: #111827; color: white; }
    button.small-btn { height: 32px; padding: 0 10px; font-size: 13px; }
    table { width: 100%; border-collapse: collapse; table-layout: fixed; background: #fff; border: 1px solid #d8dde6; }
    th, td { border-bottom: 1px solid #e2e8f0; padding: 10px; vertical-align: top; font-size: 14px; }
    th { background: #eef3f9; text-align: left; font-weight: 700; position: sticky; top: var(--preview-table-head-top, 0px); z-index: 4; box-shadow: 0 1px 0 #d8dde6; }
    body.row-select-dragging { user-select: none; cursor: crosshair; }
    body.row-select-dragging input[data-select-row] { cursor: crosshair; }
    input, select, textarea { width: 100%; border: 1px solid #cbd5e1; border-radius: 5px; padding: 7px 8px; font: inherit; background: #fff; }
    textarea { min-height: 72px; resize: vertical; line-height: 1.45; }
    .select-col { width: 58px; text-align: center; }
    .exec { width: 76px; }
    .role { width: 92px; }
    .speaker { width: 260px; }
    table.precise-tuo-table .speaker { width: 430px; }
    .date { width: 136px; }
    .time { width: 136px; }
    .type { width: 94px; }
    .skip { width: 72px; text-align: center; }
    .content { width: 360px; min-width: 360px; }
    .muted { color: #64748b; font-size: 12px; }
    .status { min-height: 18px; font-size: 13px; color: #166534; }
    .error { color: #b91c1c; }
    .index-cell strong { display: block; font-size: 16px; margin-bottom: 2px; }
    .subnote { margin-top: 5px; color: #64748b; font-size: 12px; line-height: 1.35; }
    .content-grid { display: grid; grid-template-columns: 1fr; gap: 8px; }
    .media-box { display: grid; grid-template-columns: 96px 1fr; gap: 10px; align-items: start; }
    .media-box.media-drop-zone { border: 1px dashed #cbd5e1; border-radius: 7px; padding: 7px; background: #fff; }
    .media-box.media-drop-zone.drag-over { border-color: #2563eb; background: #eff6ff; }
    .media-tools { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin-top: 7px; }
    .media-hint { color: #64748b; font-size: 12px; line-height: 1.35; margin-top: 5px; }
    .thumb { width: 96px; height: 76px; border: 1px solid #d1d5db; background: #f8fafc; display: flex; align-items: center; justify-content: center; overflow: hidden; color: #64748b; font-size: 12px; }
    .thumb img, .thumb video { max-width: 100%; max-height: 100%; display: block; }
    .media-thumb { cursor: zoom-in; }
    .media-popover { position: fixed; z-index: 30; display: none; width: min(286px, calc(100vw - 24px)); padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; background: #fff; box-shadow: 0 14px 36px rgba(15, 23, 42, 0.22); pointer-events: none; }
    .media-popover.open { display: block; }
    .media-popover img, .media-popover video { display: block; max-width: 268px; max-height: min(360px, calc(100vh - 44px)); margin: 0 auto; object-fit: contain; background: #f8fafc; }
    .hidden-file { display: none; }
    tr.skipped { background: #f3f4f6; color: #6b7280; }
    tr.invalid { outline: 2px solid #fecaca; outline-offset: -2px; }
    tr.repair-focus { background: #fff1f2; }
    .row-note { margin-top: 4px; color: #b91c1c; font-size: 12px; line-height: 1.35; }
    .row-note.error { color: #b91c1c; background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 6px 8px; font-weight: 700; }
    .row-note.warning { color: #92400e; background: #fffbeb; border: 1px solid #fde68a; border-radius: 6px; padding: 6px 8px; }
    .toolbar-label { color: #374151; font-size: 13px; }
    .toolbar-input { width: 132px; }
    .toolbar-date-custom { width: 132px; }
    .toolbar-number { width: 80px; }
    .preview-path { margin-top: 5px; color: #64748b; font-size: 12px; overflow-wrap: anywhere; line-height: 1.35; }
    .tag { display: inline-block; border-radius: 999px; background: #dbeafe; color: #1d4ed8; padding: 2px 8px; font-size: 12px; margin-right: 8px; }
    .media-status { margin-top: 5px; color: #64748b; font-size: 12px; }
    .media-status.bad { color: #b91c1c; font-weight: 600; }
    .manual-badge { display: inline-block; margin-top: 4px; color: #92400e; background: #fef3c7; border: 1px solid #fde68a; border-radius: 999px; padding: 1px 7px; font-size: 12px; }
    .speaker-picker { display: grid; gap: 8px; align-items: start; }
    .speaker-main-row { display: grid; grid-template-columns: 58px 82px minmax(220px, 1fr); gap: 7px; align-items: start; }
    .speaker-picker label { display: grid; gap: 3px; color: #475569; font-size: 12px; font-weight: 700; }
    .speaker-picker select, .speaker-picker input { min-height: 32px; padding: 5px 8px; font-size: 13px; }
    .persona-note { display: grid; gap: 4px; color: #475569; font-size: 12px; line-height: 1.35; }
    .current-candidate { display: flex; align-items: center; justify-content: center; min-height: 32px; padding: 5px 8px; border: 1px solid #fb923c; border-radius: 6px; background: #fff7ed; }
    .current-label { color: #c2410c; font-weight: 800; white-space: nowrap; }
    .candidate-prefix { color: #64748b; font-weight: 700; }
    .candidate-text { font-weight: 700; color: #17345c; }
    .candidate-meta { color: #64748b; font-weight: 600; }
    .backup-tag { display: inline-flex; align-items: center; min-height: 19px; padding: 0 6px; border-radius: 999px; border: 1px solid #fed7aa; background: #fff7ed; color: #c2410c; font-size: 12px; font-weight: 700; white-space: nowrap; }
    .candidate-list { display: grid; grid-template-columns: 58px 82px minmax(220px, 1fr); gap: 6px 7px; padding-top: 6px; border-top: 1px solid #e2e8f0; color: #475569; font-size: 12px; font-weight: 700; }
    .candidate-section-label { display: flex; align-items: center; min-height: 32px; padding-left: 8px; color: #475569; font-weight: 700; }
    .candidate-picks { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px; }
    .candidate-list select { min-height: 32px; padding: 5px 8px; font-size: 13px; }
    .candidate-pick { display: flex; align-items: center; flex-wrap: nowrap; gap: 5px; height: 32px; min-height: 32px; padding: 5px 8px; text-align: left; border-color: #cbd5e1; color: #17345c; background: #f8fafc; font-size: 12px; font-weight: 600; line-height: 1.35; overflow: hidden; }
    .candidate-pick.backup { border-color: #fdba74; background: #fffaf5; }
    .candidate-pick .candidate-text, .candidate-pick .candidate-meta { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .modal-backdrop { position: fixed; inset: 0; z-index: 20; display: none; align-items: center; justify-content: center; padding: 22px; background: rgba(15, 23, 42, 0.42); }
    .modal-backdrop.open { display: flex; }
    .modal { width: min(720px, 100%); max-height: calc(100vh - 44px); overflow: auto; background: #fff; border-radius: 8px; box-shadow: 0 24px 60px rgba(15, 23, 42, 0.24); border: 1px solid #d8dde6; }
    .modal-header { padding: 16px 18px 12px; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .modal-title { font-size: 18px; font-weight: 700; }
    .modal-close-danger { min-width: 34px; height: 34px; padding: 0; border-color: #fecaca; color: #dc2626; background: #fff1f2; font-size: 20px; line-height: 1; font-weight: 800; }
    .modal-close-danger:hover { border-color: #f87171; background: #fee2e2; color: #b91c1c; }
    .modal-body { padding: 16px 18px; display: grid; gap: 14px; }
    .modal-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
    .modal-field { display: grid; gap: 6px; }
    .modal-field label { font-size: 13px; color: #374151; }
    .modal-field.full { grid-column: 1 / -1; }
    .modal-actions { padding: 12px 18px 16px; display: flex; justify-content: flex-end; gap: 8px; border-top: 1px solid #e2e8f0; }
    .modal-error { color: #b91c1c; font-size: 13px; min-height: 18px; line-height: 1.4; }
    .modal-hint { color: #475569; font-size: 13px; line-height: 1.5; }
    .content-actions { display: flex; justify-content: flex-end; gap: 8px; }
    .detail-textarea { min-height: min(58vh, 520px); font-family: Consolas, "Microsoft YaHei", monospace; white-space: pre-wrap; }
    .manual-media-preview { display: grid; grid-template-columns: 112px 1fr; align-items: start; gap: 10px; }
    .manual-media-preview.media-drop-zone { border: 1px dashed #cbd5e1; border-radius: 7px; padding: 8px; }
    .manual-media-preview.media-drop-zone.drag-over { border-color: #2563eb; background: #eff6ff; }
    .wide-modal { width: min(1120px, 100%); }
    #manualBatchModal .modal-header { cursor: move; user-select: none; }
    #manualBatchModal .modal-header button { cursor: pointer; }
    #manualBatchModal .wide-modal { height: min(760px, calc(100vh - 44px)); display: flex; flex-direction: column; overflow: hidden; }
    #manualBatchModal .wide-modal.is-dragging { transition: none; }
    #manualBatchModal .modal-body { min-height: 0; overflow: hidden; grid-template-rows: auto minmax(0, 1fr) auto; }
    #manualBatchModal .modal-actions { flex-shrink: 0; background: #fff; }
    .manual-batch-tools { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .manual-batch-step { display: grid; grid-template-columns: minmax(90px, 1fr) 92px; gap: 8px; }
    .manual-batch-table-wrap { min-height: 0; overflow: auto; border: 1px solid #d8dde6; border-radius: 8px; }
    .manual-batch-table { width: 100%; border-collapse: collapse; table-layout: fixed; font-size: 13px; }
    .manual-batch-table th, .manual-batch-table td { border-bottom: 1px solid #e5e7eb; padding: 8px; vertical-align: top; }
    .manual-batch-table th { position: sticky; top: 0; z-index: 1; background: #f8fafc; color: #334155; text-align: left; font-weight: 700; }
    .manual-batch-table tbody tr:last-child td { border-bottom: 0; }
    .manual-batch-table select, .manual-batch-table input, .manual-batch-table textarea { width: 100%; min-width: 0; font-size: 13px; }
    .manual-batch-table textarea { min-height: 58px; resize: vertical; }
    .manual-batch-table textarea.drag-over { border-color: #2563eb; background: #eff6ff; }
    .manual-batch-media-box { display: grid; grid-template-columns: 74px minmax(0, 1fr); gap: 8px; align-items: start; margin-top: 7px; padding: 7px; border: 1px dashed #cbd5e1; border-radius: 7px; background: #fff; }
    .manual-batch-media-box.drag-over { border-color: #2563eb; background: #eff6ff; }
    .manual-batch-media-box .thumb { width: 72px; height: 58px; }
    .manual-batch-media-tools { display: grid; gap: 5px; }
    .manual-batch-media-actions { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
    .manual-batch-table .batch-role { width: 82px; }
    .manual-batch-table .batch-speaker { width: 150px; }
    .manual-batch-table .batch-date { width: 96px; }
    .manual-batch-table .batch-time { width: 108px; }
    .manual-batch-table .batch-type { width: 92px; }
    .manual-batch-table .batch-skip { width: 58px; text-align: center; }
    .manual-batch-table .batch-action { width: 70px; text-align: center; }
    .manual-batch-table .batch-content { min-width: 260px; }
    @media (max-width: 720px) {
      .modal-grid, .manual-media-preview { grid-template-columns: 1fr; }
    }
    details.debug { margin-top: 8px; color: #64748b; font-size: 12px; }
    details.debug summary { cursor: pointer; user-select: none; }
    .debug-grid { margin-top: 8px; display: grid; grid-template-columns: repeat(5, minmax(130px, 1fr)); gap: 8px; }
    .debug-grid label { display: block; color: #475569; }
    .debug-grid input, .debug-grid textarea { margin-top: 4px; font-size: 12px; }
  </style>
</head>
<body>
  <header>
    <div class="topbar">
      <div>
        <div class="title">妙券自动发单 - 预览确认</div>
        <div class="subtitle">本次共 <strong id="totalCount">0</strong> 条，已选中 <strong id="selectedCount">0</strong> 条，已标记不发 <strong id="skipCount">0</strong> 条</div>
        <div class="run-summary">
          <span class="summary-pill">本次读取范围：${rangeLabel}</span>
          <span class="summary-pill">原始采集：${rawEventCount} 条</span>
          <span class="summary-pill">预览条目：${previewTaskCount} 条</span>
        </div>
        <div id="libraryDateNotice" class="library-date-notice"></div>
        <details class="debug-paths">
          <summary>高级/调试信息</summary>
          <div class="pathline">预览内容文件：${previewPathText}</div>
          <div class="pathline">当前目录：${runDirText}</div>
        </details>
      </div>
      <div class="actions">
        <div class="action-buttons">
          <button class="ghost" id="addRowBtn">手动补录</button>
          <button class="library-btn" id="saveLibraryBtn" title="保存当前改完的预览内容和素材，以后可从控制台文案库直接打开。">存入文案库</button>
          <button class="ghost" id="regenerateBtn" title="飞书文案改过后，沿用控制台当前范围和时间模式重新采集、解析并生成预览。">文案有变，重新生成预览</button>
          <button class="primary" id="confirmBtn">确认无误，进入云中客设置</button>
        </div>
        <div id="cmsAdvice" class="cms-advice">首次确认请进入云中客设置；如果云中客页面已设置且仍可复用，保存后会自动提示返回控制台创建。</div>
      </div>
    </div>
    <div class="batchbar">
      <div class="tool-row">
        <span class="toolbar-label">批量修改：已选 <strong id="batchSelectedCount">0</strong> 条</span>
        <button id="selectAllBtn" class="small-btn">全选</button>
        <button id="selectNoneBtn" class="small-btn">全不选</button>
        <span class="toolbar-label">批量日期：</span>
        <select id="batchDateQuick" class="toolbar-input"></select>
        <input id="batchDateCustom" class="toolbar-date-custom" placeholder="自定义日期" hidden>
        <button id="applyDateBtn" class="small-btn">应用日期</button>
        <span class="toolbar-label">时间：</span>
        <button id="delayBtn" class="small-btn">整体延后</button>
        <button id="advanceBtn" class="small-btn">整体提前</button>
        <input id="batchMinutes" class="toolbar-number" type="number" value="5">
        <select id="batchTimeUnit" class="toolbar-input">
          <option value="second">秒</option>
          <option value="minute" selected>分钟</option>
          <option value="hour">小时</option>
          <option value="day">天</option>
        </select>
        <button id="applyTimeBtn" class="small-btn">应用时间</button>
        <button id="restoreTimeBtn" class="small-btn">恢复选中行时间</button>
        <button id="undoBtn" class="small-btn" disabled>撤回上一步</button>
        <button id="restoreOpenStateBtn" class="small-btn" disabled>恢复打开时状态</button>
      </div>
      <div class="tool-row">
        <span class="toolbar-label">角色：</span>
        <select id="batchRole" class="toolbar-input"><option value="">角色</option><option value="tuo">托</option><option value="douma">豆妈</option></select>
        <button id="applyRoleBtn" class="small-btn">批量改角色</button>
        <button id="skipSelectedBtn" class="small-btn">设为不发</button>
        <button id="unskipSelectedBtn" class="small-btn">取消不发</button>
        <span class="toolbar-label">查看方式：</span>
        <button class="active" id="executionViewBtn">按执行顺序</button>
        <button id="timeViewBtn">按时间顺序</button>
        <button id="toggleSkippedRowsBtn">隐藏不发</button>
      </div>
      <div class="status-row">
        <div id="viewNote" class="view-note">
          <div>按执行顺序：同编号托会放在一起，时间不变。</div>
          <div>按时间顺序：仅用于检查，不改变正式执行顺序。</div>
        </div>
        <div id="status" class="status"></div>
      </div>
    </div>
    <span id="source" hidden>${source}</span>
  </header>
  <main>
    <table id="previewTable">
      <thead>
        <tr>
          <th class="select-col">批量</th>
          <th class="exec">序号</th>
          <th class="role">角色</th>
          <th class="speaker" id="speakerHeader">说话人</th>
          <th class="date">日期</th>
          <th class="time">时间</th>
          <th class="type">类型</th>
          <th class="content">内容/素材</th>
          <th class="skip">不发</th>
        </tr>
      </thead>
      <tbody id="rows"></tbody>
    </table>
  </main>
  <div class="media-popover" id="mediaPopover" aria-hidden="true"></div>
  <div class="modal-backdrop" id="manualModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="manualModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="manualModalTitle">手动补一条</div>
        <button class="small-btn" id="manualCancelTopBtn" type="button">取消</button>
      </div>
      <div class="modal-body">
        <div class="modal-grid">
          <div class="modal-field">
            <label for="manualRole">角色</label>
            <select id="manualRole"><option value="tuo">托</option><option value="douma">豆妈</option></select>
          </div>
          <div class="modal-field">
            <label for="manualSpeaker">说话人</label>
            <input id="manualSpeaker">
          </div>
          <div class="modal-field">
            <label for="manualDate">日期</label>
            <input id="manualDate">
          </div>
          <div class="modal-field">
            <label for="manualTime">时间</label>
            <input id="manualTime" placeholder="例如 19:16:10">
          </div>
          <div class="modal-field">
            <label for="manualType">类型</label>
            <select id="manualType"><option value="text">文字</option><option value="finder">视频号</option><option value="image">图片</option><option value="sticker">表情包</option><option value="video">视频</option></select>
          </div>
          <div class="modal-field">
            <label for="manualInsertPosition">插入位置</label>
            <select id="manualInsertPosition"><option value="after-selection">当前选中行后</option><option value="before-selection">当前选中行前</option><option value="end">末尾</option></select>
          </div>
          <div class="modal-field">
            <label><input id="manualSkip" type="checkbox"> 是否不发</label>
          </div>
          <div class="modal-field full" id="manualTextWrap">
            <label for="manualText">正文</label>
            <textarea id="manualText"></textarea>
          </div>
          <div class="modal-field full" id="manualMediaWrap" hidden>
            <label for="manualMediaPath">素材选择/上传</label>
            <div class="manual-media-preview media-drop-zone" id="manualMediaDropZone">
              <div class="thumb" id="manualMediaThumb">无素材</div>
              <div>
                <input id="manualMediaPath" placeholder="可填写本地素材路径">
                <div class="preview-path" id="manualMediaShortPath">未选择素材</div>
                <div class="media-status" id="manualMediaStatus">未选择素材</div>
                <input class="hidden-file" id="manualMediaFile" type="file">
                <button class="small-btn ghost" id="manualChooseMediaBtn" type="button">选择素材</button>
                <div class="media-hint">也可以拖拽文件到这里，或复制图片后按 Ctrl+V 粘贴。</div>
              </div>
            </div>
          </div>
        </div>
        <div id="manualModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="manualCancelBtn" type="button">取消</button>
        <button class="primary" id="manualAddBtn" type="button">添加</button>
      </div>
    </div>
  </div>
  <div class="modal-backdrop" id="manualBatchModal" aria-hidden="true">
    <div class="modal wide-modal" role="dialog" aria-modal="true" aria-labelledby="manualBatchModalTitle">
      <div class="modal-header" title="按住标题栏可拖动窗口">
        <div class="modal-title" id="manualBatchModalTitle">手动补录</div>
        <button class="small-btn modal-close-danger" id="manualBatchCancelTopBtn" type="button" aria-label="关闭" title="关闭">×</button>
      </div>
      <div class="modal-body">
        <div class="modal-grid">
          <div class="modal-field">
            <label for="manualBatchInsertPosition">插入位置</label>
            <select id="manualBatchInsertPosition"><option value="after-selection">当前选中行后</option><option value="before-selection">当前选中行前</option><option value="end">末尾</option></select>
          </div>
          <div class="modal-field">
            <label for="manualBatchStepMinutes">每行时间递增</label>
            <div class="manual-batch-step">
              <input id="manualBatchStepMinutes" type="number" min="0" value="1">
              <select id="manualBatchStepUnit"><option value="minute">分钟</option><option value="second">秒</option></select>
            </div>
          </div>
          <div class="modal-field full">
            <div class="manual-batch-tools">
              <button class="small-btn ghost" id="manualBatchAddLineBtn" type="button">再加一行</button>
              <span class="modal-hint">只会添加已填写正文/素材的行，空白行自动跳过。图片/视频/表情包可点选择文件，也可拖拽或粘贴图片。</span>
            </div>
            <div class="modal-hint" id="manualBatchStepHint">例：起始 19:34:37，递增 1 分钟，后续行自动变为 19:35:37、19:36:37。</div>
          </div>
        </div>
        <div class="manual-batch-table-wrap">
          <table class="manual-batch-table">
            <thead>
              <tr>
                <th class="batch-role">角色</th>
                <th class="batch-speaker">说话人</th>
                <th class="batch-date">日期</th>
                <th class="batch-time">时间</th>
                <th class="batch-type">类型</th>
                <th class="batch-content">正文/素材</th>
                <th class="batch-skip">不发</th>
                <th class="batch-action">操作</th>
              </tr>
            </thead>
            <tbody id="manualBatchRows"></tbody>
          </table>
        </div>
        <div id="manualBatchModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="manualBatchCancelBtn" type="button">取消</button>
        <button class="primary" id="manualBatchAddBtn" type="button">添加已填写行</button>
      </div>
    </div>
  </div>
  <div class="modal-backdrop" id="librarySaveModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="librarySaveModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="librarySaveModalTitle">存入文案库</div>
        <button class="small-btn" id="librarySaveCancelTopBtn" type="button">取消，不保存</button>
      </div>
      <div class="modal-body">
        <div class="modal-hint" id="librarySaveHint">确认后会保存当前预览页已修改的内容和素材，以后可从控制台文案库直接打开。</div>
        <div class="modal-grid">
          <div class="modal-field full" id="librarySaveModeWrap" hidden>
            <label for="librarySaveMode">保存方式</label>
            <select id="librarySaveMode">
              <option value="overwrite">覆盖原文案</option>
              <option value="copy">另存为新文案</option>
            </select>
          </div>
          <div class="modal-field full" id="librarySaveNameWrap">
            <label for="librarySaveName">文案名称</label>
            <input id="librarySaveName" placeholder="给这份文案起个名字">
          </div>
          <div class="modal-field full" id="librarySaveTargetWrap" hidden>
            <label for="librarySaveTarget">选择要覆盖的文案</label>
            <select id="librarySaveTarget"></select>
          </div>
        </div>
        <div id="librarySaveModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="librarySaveCancelBtn" type="button">取消，不保存</button>
        <button class="primary" id="librarySaveConfirmBtn" type="button">确认存入文案库</button>
      </div>
    </div>
  </div>
  <div class="modal-backdrop" id="contentDetailModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="contentDetailModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="contentDetailModalTitle">内容详情</div>
        <button class="small-btn" id="contentDetailCloseTopBtn" type="button">关闭</button>
      </div>
      <div class="modal-body">
        <div class="modal-hint" id="contentDetailMeta"></div>
        <textarea class="detail-textarea" id="contentDetailText" readonly></textarea>
      </div>
      <div class="modal-actions">
        <button class="primary" id="contentDetailCloseBtn" type="button">关闭</button>
      </div>
    </div>
  </div>
  <div class="modal-backdrop" id="regenerateModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="regenerateModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="regenerateModalTitle">重新生成预览</div>
        <button class="small-btn" id="regenerateCancelTopBtn" type="button">取消</button>
      </div>
      <div class="modal-body">
        <div class="modal-hint" id="regenerateModalHint"></div>
        <div id="regenerateModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="regenerateCancelBtn" type="button">取消</button>
        <button class="primary" id="regenerateConfirmBtn" type="button">确认重新生成</button>
      </div>
    </div>
  </div>
  <script>
    const defaultDate = ${defaultDate};
    const runDirForPage = ${runDirJson};
    const runIdForPage = ${runIdJson};
    const robotStrategy = ${robotStrategyJson};
    const preciseTuoEnabled = robotStrategy === "precise";
    clearLegacyPreviewStorage();
    let tasks = normalizeTasksForCurrentRun(${tasksJson});
    let viewMode = "execution";
    let hideSkippedRows = false;
    let pendingTimeDirection = 1;
    let selectedRows = new Set();
    let rowSelectDrag = null;
    let suppressRowSelectClickUntil = 0;
    let dirty = false;
    let autoSaveTimer = null;
    let saveFailed = false;
    let savedAt = "";
    let lastSaveAdvice = null;
    let libraryUnsavedChanges = false;
    let librarySaveModalResolver = null;
    let previewLibraryItems = [];
    let previewLibraryItemsLoaded = false;
    let mediaPopoverTarget = null;
    const consoleUrl = ${consoleUrl};
    const libraryItem = ${libraryItemJson};
    const libraryDateNotice = ${JSON.stringify(meta.libraryDateNotice || "").replace(/</g, "\\u003c")};
    let previewRepairProblem = ${JSON.stringify(meta.repairProblem || null).replace(/</g, "\\u003c")};
    let previewRepairFocused = false;
    let previewInitialInvalidFocused = false;
    const preciseTuoRosterOptions = ${preciseTuoRosterJson};
    window.__v2PreviewPage = true;
    window.__v2PreviewRunDir = runDirForPage;
    window.__v2PreviewRunId = runIdForPage;
    window.__v2PreviewDefaultDate = defaultDate;
    window.__v2PreviewDirty = false;
    const originalTimes = tasks.map((task) => ({ date: task.documentDate || task.date || "", time: task.documentTime || task.time || "" }));
    const initialTasksSnapshot = cloneTasks(tasks);
    const initialOriginalTimesSnapshot = cloneTasks(originalTimes);
    let undoStack = [];
    const fields = ["role", "speaker", "date", "time", "type", "text", "mediaPath", "skip", "order", "interactionGroup", "continueMarker", "cleanSpeaker", "sourceId", "sourceText", "documentDate", "documentTime", "daySegment", "tuoAssignment"];
    initBatchDateControls();
    initLibraryDateNotice();
    updateStickyTableHeadTop();
    render();
    focusInitialRepairProblem();
    focusInitialInvalidProblem();

    document.getElementById("executionViewBtn").addEventListener("click", () => {
      collect();
      viewMode = "execution";
      render();
      setStatus("当前按执行顺序显示；同编号托会放在一起，时间不变。");
    });
    document.getElementById("timeViewBtn").addEventListener("click", () => {
      collect();
      viewMode = "time";
      render();
      setStatus("当前仅按时间顺序查看，不改变实际执行顺序。");
    });
    document.getElementById("toggleSkippedRowsBtn").addEventListener("click", () => {
      collect();
      hideSkippedRows = !hideSkippedRows;
      if (hideSkippedRows) {
        selectedRows = new Set(Array.from(selectedRows).filter((index) => !tasks[index]?.skip));
      }
      render();
      setStatus(hideSkippedRows ? "已隐藏标记为不发的行；点击“显示全部”可恢复。" : "已显示全部预览内容。");
    });
    document.getElementById("addRowBtn").addEventListener("click", () => {
      collect();
      openManualBatchModal();
    });
    document.getElementById("manualCancelTopBtn").addEventListener("click", () => closeManualModal());
    document.getElementById("manualCancelBtn").addEventListener("click", () => closeManualModal());
    document.getElementById("manualType").addEventListener("change", () => updateManualTypeFields());
    document.getElementById("manualMediaPath").addEventListener("input", () => updateManualMediaPreview());
    document.getElementById("manualMediaFile").addEventListener("change", () => updateManualMediaPreview());
    document.getElementById("manualChooseMediaBtn").addEventListener("click", () => document.getElementById("manualMediaFile").click());
    document.getElementById("manualAddBtn").addEventListener("click", () => addManualTaskFromModal());
    document.getElementById("manualBatchCancelTopBtn").addEventListener("click", () => closeManualBatchModal());
    document.getElementById("manualBatchCancelBtn").addEventListener("click", () => closeManualBatchModal());
    document.getElementById("manualBatchAddLineBtn").addEventListener("click", () => addManualBatchRow());
    document.getElementById("manualBatchAddBtn").addEventListener("click", () => addManualBatchTasksFromModal());
    document.getElementById("manualBatchInsertPosition").addEventListener("change", () => refreshManualBatchTiming());
    document.getElementById("manualBatchStepMinutes").addEventListener("input", () => refreshManualBatchTiming());
    document.getElementById("manualBatchStepUnit").addEventListener("change", () => refreshManualBatchTiming());
    initDraggableModal("manualBatchModal");
    document.getElementById("librarySaveMode").addEventListener("change", () => updateLibrarySaveModeFields());
    document.getElementById("librarySaveTarget").addEventListener("change", () => updateLibrarySaveModeFields());
    document.getElementById("librarySaveCancelTopBtn").addEventListener("click", () => cancelLibrarySaveModal());
    document.getElementById("librarySaveCancelBtn").addEventListener("click", () => cancelLibrarySaveModal());
    document.getElementById("librarySaveConfirmBtn").addEventListener("click", () => confirmLibrarySaveModal());
    document.getElementById("contentDetailCloseTopBtn").addEventListener("click", () => closeContentDetailModal());
    document.getElementById("contentDetailCloseBtn").addEventListener("click", () => closeContentDetailModal());
    document.getElementById("regenerateCancelTopBtn").addEventListener("click", () => closeRegenerateModal());
    document.getElementById("regenerateCancelBtn").addEventListener("click", () => closeRegenerateModal());
    document.getElementById("regenerateConfirmBtn").addEventListener("click", () => confirmRegeneratePreview());
    document.getElementById("selectAllBtn").addEventListener("click", () => {
      collect();
      selectedRows = new Set(sortedRowsForView().map((row) => row.originalIndex));
      render();
    });
    document.getElementById("selectNoneBtn").addEventListener("click", () => {
      collect();
      selectedRows = new Set();
      render();
    });
    document.getElementById("applyDateBtn").addEventListener("click", () => applyBatchDate());
    document.getElementById("batchDateQuick").addEventListener("change", () => updateBatchDateCustomVisibility());
    document.getElementById("delayBtn").addEventListener("click", () => {
      pendingTimeDirection = 1;
      updateTimeDirectionButtons();
      setStatus("已选择整体延后：先勾选要修改的行，填写数值和单位后应用");
    });
    document.getElementById("advanceBtn").addEventListener("click", () => {
      pendingTimeDirection = -1;
      updateTimeDirectionButtons();
      setStatus("已选择整体提前：先勾选要修改的行，填写数值和单位后应用");
    });
    document.getElementById("applyTimeBtn").addEventListener("click", () => shiftSelectedTimes(pendingTimeDirection));
    document.getElementById("applyRoleBtn").addEventListener("click", () => applyBatchRole());
    document.getElementById("skipSelectedBtn").addEventListener("click", () => setSelectedSkip(true));
    document.getElementById("unskipSelectedBtn").addEventListener("click", () => setSelectedSkip(false));
    document.getElementById("restoreTimeBtn").addEventListener("click", () => restoreSelectedTimes());
    document.getElementById("undoBtn").addEventListener("click", () => undoLastChange());
    document.getElementById("restoreOpenStateBtn").addEventListener("click", () => restoreOpenState());
    document.getElementById("saveLibraryBtn").addEventListener("click", saveToLibrary);
    document.getElementById("confirmBtn").addEventListener("click", async () => {
      const saved = await savePreview();
      if (!saved.ok) return;
      if (saved.saveAdvice?.action === "reuse_cms") {
        applySaveAdvice(saved.saveAdvice);
        setStatus(saved.saveAdvice.message || "已保存；云中客页面仍可复用。请回控制台直接开始创建。");
        openConsole(saved);
        return;
      }
      const result = await postJson("/api/prepare-cms", { tasks });
      if (result.ok) {
        setStatus(result.preparedCms
          ? "已进入 CMS 准备阶段：请在云中客页面手动确认分组、机器人和发送策略，然后回到控制台继续。"
          : "已保存并核对通过：请准备云中客页面后再开始创建。");
        if (!result.preparedCms && (result.consoleUrl || consoleUrl)) setTimeout(() => openConsole(result), 400);
      } else {
        setStatus(result.error || "进入 CMS 准备阶段失败", true);
      }
    });
    document.getElementById("regenerateBtn").addEventListener("click", async () => {
      if (libraryItem) {
        setStatus("这份预览来自文案库，不能直接重新采集飞书。请回控制台重新选择文档并生成预览。", true);
        return;
      }
      openRegenerateModal();
    });

    function openRegenerateModal() {
      const modal = document.getElementById("regenerateModal");
      const hint = document.getElementById("regenerateModalHint");
      const error = document.getElementById("regenerateModalError");
      hint.textContent = dirty
        ? "当前预览有未保存修改。确认后会沿用控制台当前范围和时间模式重新采集飞书文案，并覆盖当前未保存修改。"
        : "确认后会沿用控制台当前范围和时间模式重新采集飞书文案。";
      error.textContent = "";
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setStatus("请确认是否重新生成预览。");
    }

    function closeRegenerateModal() {
      const modal = document.getElementById("regenerateModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    }

    async function confirmRegeneratePreview() {
      const button = document.getElementById("regenerateBtn");
      button.disabled = true;
      const confirmBtn = document.getElementById("regenerateConfirmBtn");
      const cancelBtn = document.getElementById("regenerateCancelBtn");
      const cancelTopBtn = document.getElementById("regenerateCancelTopBtn");
      const modalError = document.getElementById("regenerateModalError");
      confirmBtn.disabled = true;
      cancelBtn.disabled = true;
      cancelTopBtn.disabled = true;
      modalError.textContent = "";
      closeRegenerateModal();
      setStatus("已收到重新生成请求，正在调出飞书文档并重新读取，请稍等...");
      try {
        const result = await postJson("/api/regenerate", {});
        if (result.ok) {
          if (Array.isArray(result.tasks)) {
            clearLegacyPreviewStorage();
            tasks = normalizeTasksForCurrentRun(result.tasks);
            selectedRows = new Set();
            document.getElementById("source").textContent = result.source || "";
            dirty = false;
            window.__v2PreviewDirty = false;
            viewMode = "execution";
            render();
            setStatus("已重新生成预览内容");
            return;
          }
          clearLegacyPreviewStorage();
          dirty = false;
          window.__v2PreviewDirty = false;
          setStatus(result.refocusFeishu
            ? "已开始调出飞书文档重新读取，完成后会打开新的预览页。"
            : "已提交重新生成预览请求，请到控制台查看进度。");
          if (!result.refocusFeishu) openConsole(result);
          return;
        }
        setStatus(result.error || "重新生成预览失败", true);
      } catch (error) {
        setStatus("重新生成预览失败：" + (error?.message || error), true);
      } finally {
        button.disabled = false;
        confirmBtn.disabled = false;
        cancelBtn.disabled = false;
        cancelTopBtn.disabled = false;
      }
    }

    function render() {
      updateStickyTableHeadTop();
      updateSpeakerLayout();
      const rows = document.getElementById("rows");
      rows.innerHTML = "";
      const displayRows = sortedRowsForView();
      for (const { task, originalIndex } of displayRows) {
        const tr = document.createElement("tr");
        tr.dataset.index = String(originalIndex);
        tr.className = task.skip ? "skipped" : "";
        tr.innerHTML = [
          cell(rowCheckbox(originalIndex)),
          execCell(originalIndex, task),
          cell(select("role", task.role, [["tuo", "托"], ["douma", "豆妈"]])),
          speakerCell(task, originalIndex),
          dateCell(originalIndex, task),
          timeCell(originalIndex, task),
          cell(select("type", task.type, [["text", "文字"], ["finder", "视频号"], ["image", "图片"], ["sticker", "表情包"], ["video", "视频"]])),
          contentCell(task),
          skipCell(task)
        ].join("");
        rows.appendChild(tr);
      }
      updateViewControls();
      refreshMediaStatuses();
      markInvalidRows(validateClient(tasks));
      markRepairProblemRow();
    }

    function markRepairProblemRow() {
      if (!previewRepairProblem) return;
      const index = Number(previewRepairProblem.index);
      const row = document.querySelector("tr[data-index='" + index + "']");
      if (!row) return;
      row.classList.add("invalid", "repair-focus");
      if (!row.querySelector("[data-repair-note='1']")) {
        const note = document.createElement("div");
        note.className = "row-note error";
        note.dataset.repairNote = "1";
        note.textContent = previewRepairProblem.message || ("第 " + (index + 1) + " 条素材需要重新上传");
        row.querySelector("td:last-child")?.appendChild(note);
      }
    }

    function focusInitialRepairProblem() {
      if (!previewRepairProblem || previewRepairFocused) return;
      previewRepairFocused = true;
      setTimeout(() => {
        const row = document.querySelector("tr[data-index='" + Number(previewRepairProblem.index) + "']");
        if (!row) return;
        row.scrollIntoView({ block: "center", behavior: "smooth" });
        const button = row.querySelector("button[data-action='choose-media']");
        if (button) button.focus();
        setStatus((previewRepairProblem.message || "素材无法上传共享") + "。请在标红行点击更换素材，或直接拖拽/粘贴素材到这一行。", true);
      }, 250);
    }

    function focusInitialInvalidProblem() {
      if (previewRepairProblem || previewInitialInvalidFocused) return;
      const errors = validateClient(tasks);
      if (!errors.length) return;
      previewInitialInvalidFocused = true;
      setTimeout(() => {
        const first = errors[0];
        const row = document.querySelector("tr[data-index='" + Number(first.index) + "']");
        if (!row) return;
        row.scrollIntoView({ block: "center", behavior: "smooth" });
        const text = row.querySelector("[data-field='text']");
        if (text) text.focus();
        setStatus(first.message + "。请在标红行手动补完整后再保存/创建。", true);
      }, 250);
    }

    function updateSpeakerLayout() {
      const precise = tasks.some((task) => isPreciseTuoTask(task));
      document.getElementById("speakerHeader").textContent = precise ? "人设 / 托号昵称 / 备选托" : "说话人";
      document.getElementById("previewTable").classList.toggle("precise-tuo-table", precise);
    }

    function updateStickyTableHeadTop() {
      const header = document.querySelector("header");
      const height = header ? Math.ceil(header.getBoundingClientRect().height) : 0;
      document.documentElement.style.setProperty("--preview-table-head-top", height + "px");
    }

    function normalizeTasksForCurrentRun(items) {
      const fallback = normalizePreviewDate(defaultDate || "");
      return (Array.isArray(items) ? items : []).map((task) => {
        const next = { ...task };
        next.date = normalizePreviewDate(String(next.date || "").trim() || fallback);
        return normalizeTaskForCurrentRobotStrategy(next);
      });
    }

    function normalizeTasksForCurrentRobotStrategy(items) {
      return (Array.isArray(items) ? items : []).map((task) => normalizeTaskForCurrentRobotStrategy(task));
    }

    function normalizeTaskForCurrentRobotStrategy(task) {
      if (preciseTuoEnabled || !task || typeof task !== "object") return task;
      if (task.role !== "tuo" || !task.tuoAssignment) return task;
      const next = { ...task };
      delete next.tuoAssignment;
      return next;
    }

    function clearLegacyPreviewStorage() {
      try {
        const keys = [];
        for (let index = 0; index < localStorage.length; index += 1) {
          const key = localStorage.key(index) || "";
          if (/^(v2-preview|preview-page|preview-state)/i.test(key)) keys.push(key);
        }
        for (const key of keys) localStorage.removeItem(key);
      } catch {}
    }

    document.addEventListener("input", (event) => {
      const row = event.target.closest && event.target.closest("tr[data-index]");
      if (!row || !event.target.dataset.field) return;
      updateTaskFromRow(row);
      if (event.target.dataset.field === "speaker" && row.querySelector("[data-persona-filter='1']")) {
        refreshPreciseTuoDatalist(row);
      }
      updateTextDetailForRow(row);
      clearRowError(row);
      markDirty();
    });
    document.addEventListener("change", async (event) => {
      const row = event.target.closest && event.target.closest("tr[data-index]");
      if (!row) return;
      if (event.target.dataset.selectRow === "1") {
        const index = Number(row.dataset.index);
        if (event.target.checked) selectedRows.add(index);
        else selectedRows.delete(index);
        updateViewControls();
        return;
      }
      if (event.target.dataset.uploadFor === "mediaPath") {
        await uploadReplacement(row, event.target.files && event.target.files[0]);
        return;
      }
      if (event.target.dataset.personaFilter === "1") {
        refreshPreciseTuoDatalist(row);
        updateTaskFromRow(row);
        markDirty("已修改精准托人设筛选，正在自动保存预览内容");
        return;
      }
      if (event.target.dataset.candidateSelect === "1") {
        const value = event.target.value || "";
        if (value) {
          event.target.value = "";
          applyPreciseCandidateChoice(row, value, "已切换备选托");
        }
        return;
      }
      if (event.target.dataset.field) {
        updateTaskFromRow(row);
        markDirty();
        if (event.target.dataset.field === "role" || event.target.dataset.field === "type" || event.target.dataset.field === "skip") render();
      }
    });
    document.addEventListener("pointerdown", (event) => {
      const checkbox = event.target.closest && event.target.closest("input[data-select-row='1']");
      if (!checkbox || event.button !== 0) return;
      const row = checkbox.closest("tr[data-index]");
      if (!row) return;
      event.preventDefault();
      rowSelectDrag = { checked: !checkbox.checked, seen: new Set() };
      document.body.classList.add("row-select-dragging");
      applyRowSelectionDrag(row);
      suppressRowSelectClickUntil = Date.now() + 600;
    }, true);
    document.addEventListener("pointermove", (event) => {
      if (!rowSelectDrag) return;
      const node = document.elementFromPoint(event.clientX, event.clientY);
      const row = node?.closest?.("tr[data-index]");
      if (row) applyRowSelectionDrag(row);
    }, true);
    document.addEventListener("pointerup", () => finishRowSelectionDrag(), true);
    document.addEventListener("pointercancel", () => finishRowSelectionDrag(), true);
    document.addEventListener("click", (event) => {
      const checkbox = event.target.closest && event.target.closest("input[data-select-row='1']");
      if (!checkbox || Date.now() > suppressRowSelectClickUntil) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
    document.addEventListener("click", (event) => {
      const thumb = event.target.closest && event.target.closest("[data-media-popover-src]");
      if (thumb) {
        event.preventDefault();
        toggleMediaPopover(thumb);
        return;
      }
      if (mediaPopoverTarget && !event.target.closest?.("#mediaPopover")) {
        hideMediaPopover();
      }
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        hideMediaPopover();
        closeContentDetailModal();
      }
    });
    window.addEventListener("scroll", () => hideMediaPopover(), true);
    window.addEventListener("resize", () => updateStickyTableHeadTop());

    document.addEventListener("click", (event) => {
      const button = event.target.closest && event.target.closest("button[data-action],button[data-candidate-pick]");
      if (!button) return;
      const row = button.closest("tr[data-index]");
      if (!row) return;
      if (button.dataset.candidatePick) {
        applyPreciseCandidateChoice(row, button.dataset.candidatePick, "已切换推荐备选托");
        return;
      }
      if (button.dataset.action === "choose-media") {
        const fileInput = row.querySelector("input[type='file'][data-upload-for='mediaPath']");
        if (fileInput) fileInput.click();
      }
      if (button.dataset.action === "view-text-detail") {
        updateTaskFromRow(row);
        showContentDetailModal(tasks[Number(row.dataset.index)] || readTaskFromRow(row, {}), row.dataset.index);
      }
      if (button.dataset.action === "mark-skip") {
        updateTaskFromRow(row);
        pushUndoSnapshot("单行设为不发");
        tasks[Number(row.dataset.index)].skip = true;
        render();
        markDirty("已设为不发，正在自动保存预览内容");
      }
    });
    document.addEventListener("dragover", (event) => {
      const target = mediaDropTargetFromEvent(event);
      if (!target) return;
      event.preventDefault();
      target.classList.add("drag-over");
    });
    document.addEventListener("dragleave", (event) => {
      const target = event.target.closest && event.target.closest(".media-drop-zone,.manualBatchContent,[data-manual-batch-drop-zone]");
      if (target) target.classList.remove("drag-over");
    });
    document.addEventListener("drop", async (event) => {
      const target = mediaDropTargetFromEvent(event);
      if (!target) return;
      event.preventDefault();
      target.classList.remove("drag-over");
      const file = firstUsableFile(event.dataTransfer?.files);
      if (!file) return setStatus("没有识别到可上传的素材文件", true);
      await handleDroppedOrPastedMedia(target, file);
    });
    document.addEventListener("paste", async (event) => {
      const file = firstUsableFile(Array.from(event.clipboardData?.files || []));
      if (!file) return;
      const target = mediaPasteTargetFromEvent(event);
      if (!target) return;
      event.preventDefault();
      await handleDroppedOrPastedMedia(target, file);
    });

    function mediaDropTargetFromEvent(event) {
      const target = event.target.closest && event.target.closest("[data-media-drop-zone],#manualMediaDropZone,.manualBatchContent,[data-manual-batch-drop-zone]");
      if (!target) return null;
      if (target.hasAttribute?.("data-manual-batch-drop-zone")) return target;
      if (target.classList?.contains("manualBatchContent")) return target;
      return target.closest?.(".media-drop-zone") || target;
    }

    function mediaPasteTargetFromEvent(event) {
      const row = event.target.closest && event.target.closest("tr[data-index]");
      if (row && !isTextLikeType(tasks[Number(row.dataset.index)]?.type)) return row.querySelector("[data-media-drop-zone]");
      const manualModal = document.getElementById("manualModal");
      if (manualModal?.classList.contains("open") && !document.getElementById("manualMediaWrap")?.hidden) return document.getElementById("manualMediaDropZone");
      const batchRow = event.target.closest && event.target.closest("#manualBatchRows tr");
      if (batchRow && !isTextLikeType(batchRow.querySelector(".manualBatchType")?.value)) {
        return batchRow.querySelector("[data-manual-batch-drop-zone]") || batchRow.querySelector(".manualBatchContent");
      }
      return null;
    }

    function firstUsableFile(files) {
      return Array.from(files || []).find((file) => file && file.size > 0) || null;
    }

    async function handleDroppedOrPastedMedia(target, file) {
      if (target.id === "manualMediaDropZone" || target.closest?.("#manualMediaDropZone")) {
        await setManualModalMediaFile(file);
        return;
      }
      if (target.classList?.contains("manualBatchContent") || target.hasAttribute?.("data-manual-batch-drop-zone")) {
        await setManualBatchMediaFile(target.closest("tr"), file);
        return;
      }
      const row = target.closest?.("tr[data-index]");
      if (row) {
        await uploadReplacement(row, file);
      }
    }

    function collect() {
      const nextTasks = tasks.map((task) => ({ ...task }));
      for (const row of Array.from(document.querySelectorAll("tbody tr"))) {
        const originalIndex = Number(row.dataset.index);
        if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= nextTasks.length) continue;
        nextTasks[originalIndex] = readTaskFromRow(row, nextTasks[originalIndex]);
      }
      tasks = normalizeTasksForCurrentRobotStrategy(nextTasks);
    }

    function readTaskFromRow(row, baseTask) {
      const task = { ...baseTask };
      const previousType = String(baseTask?.type || "");
      const previousMediaPath = String(baseTask?.mediaPath || "");
      for (const field of fields) {
        const el = row.querySelector("[data-field='" + field + "']");
        if (!el) continue;
      if (field === "skip") task[field] = el.checked;
      else if (field === "continueMarker") task[field] = el.checked;
      else if (field === "order") task[field] = Number(el.value);
      else task[field] = el.value;
      }
      if (String(task.type || "") !== previousType || String(task.mediaPath || "") !== previousMediaPath || task.skip) {
        delete task.previewError;
      }
      const persona = row.querySelector("[data-persona-filter='1']");
      if (task.role !== "tuo" && task.tuoAssignment) {
        delete task.tuoAssignment;
      }
      if (persona && task.role === "tuo" && task.tuoAssignment && typeof task.tuoAssignment === "object") {
        task.cleanSpeaker = String(task.speaker || "").replace(/\s+/g, "");
        task.tuoAssignment = {
          ...task.tuoAssignment,
          selectedPersona: persona.value || "all"
        };
      }
      return task;
    }

    function updateTaskFromRow(row) {
      const originalIndex = Number(row.dataset.index);
      if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= tasks.length) return;
      tasks[originalIndex] = readTaskFromRow(row, tasks[originalIndex]);
    }

    function updateTextDetailForRow(row) {
      const originalIndex = Number(row.dataset.index);
      if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= tasks.length) return;
      const task = tasks[originalIndex];
      const button = row.querySelector("button[data-action='view-text-detail']");
      if (button) button.textContent = textDetailButtonLabel(task);
      const modal = document.getElementById("contentDetailModal");
      if (!modal?.classList.contains("open") || modal.dataset.taskIndex !== String(originalIndex)) return;
      const text = document.getElementById("contentDetailText");
      const meta = document.getElementById("contentDetailMeta");
      if (text) text.value = task.text || "";
      if (meta) meta.textContent = contentDetailLabel(task);
    }

    function applyPreciseCandidateChoice(row, nickname, message) {
      const originalIndex = Number(row.dataset.index);
      if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= tasks.length) return;
      const input = row.querySelector("[data-field='speaker']");
      if (input) input.value = nickname;
      updateTaskFromRow(row);
      pushUndoSnapshot("切换推荐备选托");
      const persona = row.querySelector("[data-persona-filter='1']")?.value || selectedPersonaForTask(tasks[originalIndex]);
      const groupKey = precisePreviewGroupKey(tasks[originalIndex]);
      let synced = 0;
      tasks[originalIndex] = withPreciseSpeaker(tasks[originalIndex], nickname, persona);
      if (groupKey) {
        for (let index = 0; index < tasks.length; index += 1) {
          if (index === originalIndex) continue;
          if (!isPreciseTuoTask(tasks[index])) continue;
          if (precisePreviewGroupKey(tasks[index]) !== groupKey) continue;
          tasks[index] = withPreciseSpeaker(tasks[index], nickname, persona);
          synced += 1;
        }
      }
      const adjusted = rebalancePreciseTuoCooldownAfter(originalIndex);
      render();
      const suffix = (synced ? "，并同步 " + (synced + 1) + " 条同组托词" : "")
        + (adjusted ? "，后续 " + adjusted + " 条托词已避开禁用期" : "");
      markDirty(message + suffix + "，正在自动保存预览内容");
    }

    function withPreciseSpeaker(task, nickname, persona) {
      const next = {
        ...task,
        speaker: nickname,
        cleanSpeaker: String(nickname || "").replace(/\s+/g, "")
      };
      if (next.tuoAssignment && typeof next.tuoAssignment === "object") {
        next.tuoAssignment = {
          ...next.tuoAssignment,
          selectedPersona: persona || next.tuoAssignment.selectedPersona || "all"
        };
      }
      return next;
    }

    function precisePreviewGroupKey(task = {}) {
      const saved = String(task?.tuoAssignment?.groupKey || "").trim();
      if (saved) return saved;
      const interactionGroup = String(task.interactionGroup || "").trim();
      return interactionGroup ? "interaction:" + normalizeTuoKey(interactionGroup) : "";
    }

    function rebalancePreciseTuoCooldownAfter(changedIndex) {
      const mainLast = new Map();
      const backupLast = new Map();
      const mainGroup = new Map();
      const backupGroup = new Map();
      let preciseSequence = 0;
      let adjusted = 0;
      for (let index = 0; index < tasks.length; index += 1) {
        const task = tasks[index];
        if (!isPreciseTuoTask(task)) continue;
        preciseSequence += 1;
        const groupKey = precisePreviewGroupKey(task);
        if (index > changedIndex && preciseCandidateDisabled(task.speaker, groupKey, preciseSequence, task, mainLast, backupLast, mainGroup, backupGroup)) {
          const replacement = firstAllowedPreciseReplacement(task, groupKey, preciseSequence, mainLast, backupLast, mainGroup, backupGroup);
          if (replacement && normalizeTuoKey(replacement.nickname) !== normalizeTuoKey(task.speaker)) {
            tasks[index] = withPreciseSpeaker(task, replacement.nickname, firstPersonaLabel(replacement) || selectedPersonaForTask(task));
            adjusted += 1;
          }
        }
        rememberPreciseCooldownForTask(tasks[index], groupKey, preciseSequence, mainLast, backupLast, mainGroup, backupGroup);
      }
      return adjusted;
    }

    function firstAllowedPreciseReplacement(task, groupKey, preciseSequence, mainLast, backupLast, mainGroup, backupGroup) {
      const selected = selectedPersonaForTask(task);
      const candidates = [
        ...recommendedPreciseCandidates(task, selected),
        ...alternatePreciseCandidates(task, selected)
      ];
      const seen = new Set();
      for (const item of candidates) {
        const key = normalizeTuoKey(item?.nickname || "");
        if (!key || seen.has(key)) continue;
        seen.add(key);
        if (!preciseCandidateDisabled(key, groupKey, preciseSequence, task, mainLast, backupLast, mainGroup, backupGroup)) {
          return item;
        }
      }
      return null;
    }

    function rememberPreciseCooldownForTask(task, groupKey, preciseSequence, mainLast, backupLast, mainGroup, backupGroup) {
      const speakerKey = normalizeTuoKey(task?.speaker || "");
      if (speakerKey) {
        mainLast.set(speakerKey, preciseSequence);
        backupLast.set(speakerKey, preciseSequence);
        mainGroup.set(speakerKey, groupKey || "");
        backupGroup.set(speakerKey, groupKey || "");
      }
      const visibleCount = positivePreciseCooldownNumber(task?.tuoAssignment?.visibleBackupCount, 2);
      for (const item of recommendedPreciseCandidates(task, selectedPersonaForTask(task)).slice(0, visibleCount)) {
        const key = normalizeTuoKey(item?.nickname || "");
        if (!key) continue;
        backupLast.set(key, preciseSequence);
        backupGroup.set(key, groupKey || "");
      }
    }

    function preciseCandidateDisabled(nickname, groupKey, preciseSequence, task, mainLast, backupLast, mainGroup, backupGroup) {
      const key = normalizeTuoKey(nickname || "");
      if (!key) return false;
      const mainAt = mainLast.get(key);
      const backupAt = backupLast.get(key);
      const mainCooldown = positivePreciseCooldownNumber(task?.tuoAssignment?.mainCooldown, 15);
      const backupCooldown = positivePreciseCooldownNumber(task?.tuoAssignment?.backupCooldown, 10);
      if (Number.isFinite(Number(mainAt)) && mainGroup.get(key) !== groupKey && preciseSequence - Number(mainAt) <= mainCooldown) return true;
      if (Number.isFinite(Number(backupAt)) && backupGroup.get(key) !== groupKey && preciseSequence - Number(backupAt) <= backupCooldown) return true;
      return false;
    }

    function positivePreciseCooldownNumber(value, fallback) {
      const number = Number(value);
      return Number.isFinite(number) && number > 0 ? Math.floor(number) : fallback;
    }

    function sortedRowsForView() {
      const rows = tasks.map((task, originalIndex) => ({ task, originalIndex }));
      const sorted = viewMode !== "time" ? rows : [...rows].sort((a, b) => {
        const left = timeSortKey(a.task);
        const right = timeSortKey(b.task);
        if (left !== right) return left - right;
        return a.originalIndex - b.originalIndex;
      });
      return hideSkippedRows ? sorted.filter((row) => !row.task.skip) : sorted;
    }

    function selectedIndexes() {
      return Array.from(selectedRows).filter((index) => index >= 0 && index < tasks.length);
    }

    function cloneTasks(items) {
      return JSON.parse(JSON.stringify(items || []));
    }

    function replaceOriginalTimes(snapshot) {
      originalTimes.splice(0, originalTimes.length, ...cloneTasks(snapshot));
    }

    function pushUndoSnapshot(label) {
      undoStack.push({
        label,
        tasks: cloneTasks(tasks),
        originalTimes: cloneTasks(originalTimes),
        selectedRows: Array.from(selectedRows)
      });
      if (undoStack.length > 20) undoStack.shift();
      updateUndoButtons();
    }

    function undoLastChange() {
      const snapshot = undoStack.pop();
      if (!snapshot) return setStatus("没有可撤回的修改", true);
      tasks = cloneTasks(snapshot.tasks);
      replaceOriginalTimes(snapshot.originalTimes);
      selectedRows = new Set(snapshot.selectedRows || []);
      render();
      markDirty("已撤回上一步：" + snapshot.label + "，正在自动保存预览内容");
      updateUndoButtons();
    }

    function restoreOpenState() {
      collect();
      pushUndoSnapshot("恢复打开时状态前");
      tasks = cloneTasks(initialTasksSnapshot);
      replaceOriginalTimes(initialOriginalTimesSnapshot);
      selectedRows = new Set();
      viewMode = "execution";
      render();
      markDirty("已恢复打开时状态，正在自动保存预览内容");
    }

    function updateUndoButtons() {
      const undo = document.getElementById("undoBtn");
      const restore = document.getElementById("restoreOpenStateBtn");
      if (undo) {
        undo.disabled = !undoStack.length;
        undo.textContent = undoStack.length ? "撤回上一步" : "撤回上一步";
      }
      if (restore) restore.disabled = !initialTasksSnapshot.length;
    }

    function applyBatchDate() {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改日期的行，或点全选", true);
      const value = selectedBatchDate();
      if (!value) return setStatus("请先选择或填写批量日期", true);
      if (!validDate(value)) return setStatus("批量日期格式不合法", true);
      pushUndoSnapshot("批量修改日期");
      for (const index of indexes) tasks[index].date = value;
      render();
      markDirty("已批量修改日期，正在自动保存预览内容");
    }

    function shiftSelectedTimes(direction) {
      collect();
      const amount = Math.abs(Number(document.getElementById("batchMinutes").value || 0));
      if (!amount) return setStatus("请填写时间偏移数值", true);
      const unit = document.getElementById("batchTimeUnit").value || "minute";
      const seconds = amount * batchTimeUnitSeconds(unit);
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改时间的行，或点全选，再应用", true);
      pushUndoSnapshot(direction > 0 ? "批量延后时间" : "批量提前时间");
      for (const index of indexes) {
        const shifted = shiftPreviewDateTime(tasks[index].date, tasks[index].time, direction * seconds);
        tasks[index].date = shifted.date;
        tasks[index].time = shifted.time;
      }
      render();
      markDirty((direction > 0 ? "已批量延后" : "已批量提前") + amount + batchTimeUnitLabel(unit) + "，跨天日期已同步，正在自动保存预览内容");
    }

    function applyBatchRole() {
      collect();
      const role = document.getElementById("batchRole").value;
      if (!role) return setStatus("请先选择批量角色", true);
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改角色的行，或点全选", true);
      pushUndoSnapshot("批量修改角色");
      for (const index of indexes) {
        tasks[index].role = role;
        if (role !== "tuo") delete tasks[index].tuoAssignment;
      }
      render();
      markDirty("已批量修改角色，正在自动保存预览内容");
    }

    function setSelectedSkip(skip) {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要设为不发的行，或点全选", true);
      pushUndoSnapshot(skip ? "设为不发" : "取消不发");
      for (const index of indexes) tasks[index].skip = skip;
      render();
      markDirty(skip ? "已将选中行设为不发，正在自动保存预览内容" : "已取消选中行不发，正在自动保存预览内容");
    }

    function restoreSelectedTimes() {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要恢复时间的行，或点全选", true);
      pushUndoSnapshot("恢复选中行时间");
      for (const index of indexes) {
        if (!originalTimes[index]) continue;
        tasks[index].date = originalTimes[index].date;
        tasks[index].time = originalTimes[index].time;
      }
      render();
      markDirty("已恢复选中行原时间，正在自动保存预览内容");
    }

    async function savePreview(options = {}) {
      if (!options.auto && autoSaveTimer) {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = null;
      }
      setStatus("正在保存...");
      collect();
      const errors = validateClient(tasks);
      if (errors.length) {
        if (!options.auto) markInvalidRows(errors);
        const prefix = options.auto ? "未自动保存：" : "";
        setStatus(prefix + errors.slice(0, 4).map((item) => item.message).join("；"), true);
        saveFailed = true;
        return { ok: false };
      }
      let result;
      let libraryChoice = {};
      try {
        libraryChoice = await chooseLibrarySaveChoice(options);
        if (libraryChoice?.canceled) return { ok: false, canceled: true };
        result = await postJson("/api/preview", { tasks, autoSave: options.auto === true, ...libraryChoice });
      } catch (error) {
        result = { ok: false, error: error?.message || String(error) };
      }
      if (result.ok) tasks = result.tasks;
      if (result.ok) {
        dirty = false;
        window.__v2PreviewDirty = false;
        saveFailed = false;
        savedAt = result.savedAt || new Date().toISOString();
        lastSaveAdvice = result.saveAdvice || null;
        if (libraryItem && !options.auto) libraryUnsavedChanges = false;
        if (libraryItem && (libraryChoice.librarySaveMode === "overwrite" || libraryChoice.librarySaveMode === "copy")) libraryUnsavedChanges = false;
        applySaveAdvice(lastSaveAdvice);
      }
      setStatus(result.ok
        ? (options.auto ? "已自动保存预览内容：" : "已保存预览内容：") + formatTime(savedAt)
        : "保存失败，请重试：" + (result.error || "未知原因"),
        !result.ok);
      if (!result.ok) saveFailed = true;
      if (!options.auto || options.render) render();
      return result;
    }

    async function saveToLibrary() {
      const button = document.getElementById("saveLibraryBtn");
      const oldButtonText = button?.textContent || "存入文案库";
      showTopNotice("准备存入文案库，请按提示确认名称。", "library");
      const choice = await chooseLibrarySaveChoice({ forceAskForLibrary: true });
      if (choice?.canceled) {
        const message = "已取消存入文案库，未保存。";
        setStatus(message);
        showTopNotice(message, "cancelled");
        return;
      }
      const defaultName = choice.libraryName || defaultLibraryName();
      let name = choice.libraryName || "";
      const forceNew = choice.librarySaveMode !== "overwrite";
      const targetId = choice.librarySaveMode === "overwrite" ? choice.libraryTargetId : "";
      name = String(name || defaultName).trim() || defaultName;
      setStatus("正在保存到文案库...");
      showTopNotice("正在存入文案库：" + name + "。", "library");
      if (button) {
        button.disabled = true;
        button.textContent = "存入中...";
      }
      try {
        collect();
        const errors = validateClient(tasks);
        if (errors.length) {
          const message = "不能存入文案库：" + errors.slice(0, 4).map((item) => item.message).join("；");
          markInvalidRows(errors);
          setStatus(message, true);
          showTopNotice(message, "blocked");
          return;
        }
        let result;
        try {
          result = await postJson("/api/library/save", {
            name,
            tasks,
            forceNew,
            targetId,
            librarySaveMode: choice.librarySaveMode
          });
        } catch (error) {
          result = { ok: false, error: error?.message || String(error) };
        }
        if (!result.ok) {
          const message = result.error || "保存到文案库失败";
          setStatus(message, true);
          showTopNotice(message, "blocked");
          return;
        }
        tasks = result.tasks || tasks;
        dirty = false;
        libraryUnsavedChanges = false;
        window.__v2PreviewDirty = false;
        savedAt = result.savedAt || new Date().toISOString();
        render();
        const savedName = result.item?.name || name || defaultName;
        setStatus("已存入文案库：" + savedName);
        showTopNotice("已存入文案库：" + savedName + "。以后可在控制台文案库直接打开。", "library");
      } finally {
        if (button) {
          button.disabled = false;
          button.textContent = oldButtonText;
        }
      }
    }

    async function chooseLibrarySaveChoice(options = {}) {
      if (options.auto) {
        return { librarySaveMode: "none" };
      }
      if (!libraryItem && !options.forceAskForLibrary) return {};
      if (!dirty && !libraryUnsavedChanges && !options.forceAskForLibrary) return { librarySaveMode: "none" };
      return await openLibrarySaveModal(options);
    }

    async function openLibrarySaveModal(options = {}) {
      await loadPreviewLibraryItems();
      return new Promise((resolve) => {
        if (librarySaveModalResolver) {
          librarySaveModalResolver({ canceled: true });
          librarySaveModalResolver = null;
        }
        librarySaveModalResolver = resolve;
        const modal = document.getElementById("librarySaveModal");
        const title = document.getElementById("librarySaveModalTitle");
        const hint = document.getElementById("librarySaveHint");
        const modeWrap = document.getElementById("librarySaveModeWrap");
        const mode = document.getElementById("librarySaveMode");
        const name = document.getElementById("librarySaveName");
        const target = document.getElementById("librarySaveTarget");
        const error = document.getElementById("librarySaveModalError");
        const confirm = document.getElementById("librarySaveConfirmBtn");
        const cancelTop = document.getElementById("librarySaveCancelTopBtn");
        const cancelBottom = document.getElementById("librarySaveCancelBtn");
        error.textContent = "";
        mode.innerHTML = "";
        renderLibrarySaveTargetOptions();
        modal.dataset.cancelMode = options.forceAskForLibrary ? "cancel" : "use-current";
        if (libraryItem) {
          title.textContent = options.forceAskForLibrary ? "保存文案库修改" : "是否保存文案库修改";
          hint.textContent = options.forceAskForLibrary
            ? "这份预览来自文案库“" + (libraryItem.name || "未命名文案") + "”。请选择覆盖原文案，或另存为新文案。"
            : "这份预览来自文案库“" + (libraryItem.name || "未命名文案") + "”。不保存到文案库时，本次创建仍会使用当前预览页已修改的内容。";
          modeWrap.hidden = false;
          mode.appendChild(new Option("另存为新文案", "copy"));
          if (previewLibraryItems.length) mode.appendChild(new Option("覆盖已有文案", "overwrite"));
          if (!options.forceAskForLibrary) mode.appendChild(new Option("本次创建不保存到文案库", "none"));
          mode.value = options.forceAskForLibrary ? "copy" : (previewLibraryItems.length ? "overwrite" : "copy");
          name.value = libraryItem.name || defaultLibraryName();
          if (target && libraryItem?.id) target.value = libraryItem.id;
          confirm.textContent = "确认保存";
          cancelTop.textContent = options.forceAskForLibrary ? "取消，不保存" : "不保存到文案库，继续本次创建";
          cancelBottom.textContent = options.forceAskForLibrary ? "取消，不保存" : "不保存到文案库，继续本次创建";
        } else {
          title.textContent = "存入文案库";
          hint.textContent = previewLibraryItems.length
            ? "请选择另存为新文案，或覆盖已经保存的一份文案。覆盖只有点击确认后才会生效。"
            : "确认后会保存当前预览页已修改的内容和素材，以后可从控制台文案库直接打开。";
          modeWrap.hidden = false;
          mode.appendChild(new Option("另存为新文案", "copy"));
          if (previewLibraryItems.length) mode.appendChild(new Option("覆盖已有文案", "overwrite"));
          mode.value = "copy";
          name.value = options.defaultName || defaultLibraryName();
          confirm.textContent = "确认存入文案库";
          cancelTop.textContent = "取消，不保存";
          cancelBottom.textContent = "取消，不保存";
        }
        updateLibrarySaveModeFields();
        modal.classList.add("open");
        modal.setAttribute("aria-hidden", "false");
        setTimeout(() => {
          const focusTarget = document.getElementById("librarySaveName").disabled ? document.getElementById("librarySaveConfirmBtn") : document.getElementById("librarySaveName");
          focusTarget.focus();
          if (!document.getElementById("librarySaveName").disabled) document.getElementById("librarySaveName").select();
        }, 0);
      });
    }

    function updateLibrarySaveModeFields() {
      const mode = document.getElementById("librarySaveMode").value;
      const name = document.getElementById("librarySaveName");
      const nameWrap = document.getElementById("librarySaveNameWrap");
      const target = document.getElementById("librarySaveTarget");
      const targetWrap = document.getElementById("librarySaveTargetWrap");
      const confirm = document.getElementById("librarySaveConfirmBtn");
      const error = document.getElementById("librarySaveModalError");
      error.textContent = "";
      if (mode === "overwrite") {
        nameWrap.hidden = true;
        name.disabled = true;
        targetWrap.hidden = false;
        target.disabled = false;
        const selected = selectedLibrarySaveTarget();
        name.value = selected?.name || libraryItem?.name || defaultLibraryName();
        confirm.textContent = "确认覆盖已有文案";
        return;
      }
      if (libraryItem && mode === "none") {
        nameWrap.hidden = true;
        name.disabled = true;
        targetWrap.hidden = true;
        target.disabled = true;
        confirm.textContent = "不保存，继续本次创建";
        return;
      }
      targetWrap.hidden = true;
      target.disabled = true;
      nameWrap.hidden = false;
      name.disabled = false;
      if (libraryItem && mode === "copy" && (!String(name.value || "").trim() || name.value === (libraryItem.name || ""))) {
        name.value = (libraryItem.name || defaultLibraryName()) + " 副本";
      }
      confirm.textContent = "确认另存为新文案";
    }

    function confirmLibrarySaveModal() {
      const mode = document.getElementById("librarySaveMode").value || "copy";
      const name = document.getElementById("librarySaveName").value.trim();
      const target = document.getElementById("librarySaveTarget");
      const error = document.getElementById("librarySaveModalError");
      if (mode === "none") {
        closeLibrarySaveModal({ librarySaveMode: "none" });
        return;
      }
      if (mode === "overwrite" && !target.value) {
        error.textContent = "请选择要覆盖的文案。";
        target.focus();
        return;
      }
      if (mode === "copy" && !name) {
        error.textContent = "请填写文案名称。";
        document.getElementById("librarySaveName").focus();
        return;
      }
      const selected = selectedLibrarySaveTarget();
      closeLibrarySaveModal({
        librarySaveMode: mode,
        libraryName: mode === "overwrite" ? (selected?.name || libraryItem?.name || defaultLibraryName()) : name,
        libraryTargetId: mode === "overwrite" ? target.value : ""
      });
    }

    async function loadPreviewLibraryItems() {
      if (previewLibraryItemsLoaded) return previewLibraryItems;
      try {
        const result = await getJson("/api/library/list");
        previewLibraryItems = Array.isArray(result.items) ? result.items : [];
      } catch {
        previewLibraryItems = [];
      }
      previewLibraryItemsLoaded = true;
      return previewLibraryItems;
    }

    function renderLibrarySaveTargetOptions() {
      const target = document.getElementById("librarySaveTarget");
      if (!target) return;
      target.innerHTML = "";
      for (const item of previewLibraryItems) {
        target.appendChild(new Option((item.name || "未命名文案") + "（" + (item.taskCount || 0) + "条）", item.id || ""));
      }
      if (libraryItem?.id && previewLibraryItems.some((item) => item.id === libraryItem.id)) {
        target.value = libraryItem.id;
      }
    }

    function selectedLibrarySaveTarget() {
      const targetId = document.getElementById("librarySaveTarget")?.value || "";
      return previewLibraryItems.find((item) => item.id === targetId) || null;
    }

    function cancelLibrarySaveModal() {
      const modal = document.getElementById("librarySaveModal");
      if (modal.dataset.cancelMode === "use-current") {
        closeLibrarySaveModal({ librarySaveMode: "none" });
        return;
      }
      closeLibrarySaveModal({ canceled: true });
    }

    function closeLibrarySaveModal(result) {
      const modal = document.getElementById("librarySaveModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      if (librarySaveModalResolver) {
        const resolve = librarySaveModalResolver;
        librarySaveModalResolver = null;
        resolve(result || { canceled: true });
      }
    }

    function defaultLibraryName() {
      const first = tasks.find((task) => !task.skip) || tasks[0] || {};
      const parts = [
        first.speaker || "",
        first.date || "",
        first.time || "",
        String(first.text || "").replace(/\\s+/g, " ").trim().slice(0, 18)
      ].filter(Boolean);
      return parts.join(" ") || ("预览文案 " + runIdForPage);
    }

    function applySaveAdvice(advice) {
      const node = document.getElementById("cmsAdvice");
      const button = document.getElementById("confirmBtn");
      if (!node || !button) return;
      node.className = "cms-advice";
      if (advice?.action === "reuse_cms") {
        node.textContent = advice.message || "云中客页面仍可复用，修改预览后无需重新设置。点击后会保存预览内容并返回控制台。";
        node.classList.add("reusable");
        button.textContent = "确认无误，回到控制台创建";
        button.title = "结构未变，云中客页面仍可复用；保存后返回控制台直接开始创建。";
        return;
      }
      if (advice?.action === "prepare_cms") {
        node.textContent = advice.message || "预览结构已变化，需要重新进入云中客设置。";
        node.classList.add("blocked");
        button.textContent = "确认无误，进入云中客设置";
        button.title = "";
        return;
      }
      node.textContent = "首次确认请进入云中客设置；如果云中客页面已设置且仍可复用，保存后会自动提示返回控制台创建。";
      button.textContent = "确认无误，进入云中客设置";
      button.title = "";
    }

    function initLibraryDateNotice() {
      if (!libraryItem || !libraryDateNotice) return;
      const node = document.getElementById("libraryDateNotice");
      if (!node) return;
      node.className = "library-date-notice show";
      node.textContent = libraryDateNotice;
    }

    function showTopNotice(message, kind = "") {
      const node = document.getElementById("cmsAdvice");
      if (!node) return;
      node.className = "cms-advice";
      if (kind) node.classList.add(kind);
      node.textContent = message || "";
    }

    function openManualModal() {
      const selected = selectedIndexes();
      const anchorIndex = selected.length ? Math.max(...selected) : tasks.length - 1;
      const anchor = tasks[anchorIndex] || {};
      document.getElementById("manualRole").value = anchor.role || "tuo";
      document.getElementById("manualSpeaker").value = anchor.speaker || "";
      document.getElementById("manualDate").value = defaultDate || todayMonthDay();
      document.getElementById("manualTime").value = validTime(anchor.time) ? shiftClock(anchor.time, 1) : currentClock();
      document.getElementById("manualType").value = "text";
      document.getElementById("manualText").value = "";
      document.getElementById("manualMediaPath").value = "";
      document.getElementById("manualMediaFile").value = "";
      document.getElementById("manualSkip").checked = false;
      document.getElementById("manualInsertPosition").value = selected.length ? "after-selection" : "end";
      document.getElementById("manualModalError").textContent = "";
      updateManualTypeFields();
      updateManualMediaPreview();
      const modal = document.getElementById("manualModal");
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setTimeout(() => document.getElementById("manualSpeaker").focus(), 0);
    }

    function closeManualModal() {
      const modal = document.getElementById("manualModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      const file = document.getElementById("manualMediaFile");
      if (file) file.value = "";
    }

    function manualAnchorTask() {
      const selected = selectedIndexes();
      const anchorIndex = selected.length ? Math.max(...selected) : tasks.length - 1;
      return {
        selected,
        anchor: tasks[anchorIndex] || {}
      };
    }

    function manualBatchAnchorTask() {
      const selected = selectedIndexes();
      const mode = document.getElementById("manualBatchInsertPosition")?.value || (selected.length ? "after-selection" : "end");
      let anchorIndex = tasks.length - 1;
      if (selected.length && mode === "before-selection") anchorIndex = Math.min(...selected);
      else if (selected.length && mode === "after-selection") anchorIndex = Math.max(...selected);
      return {
        selected,
        mode,
        anchor: tasks[anchorIndex] || {}
      };
    }

    function openManualBatchModal() {
      const state = manualAnchorTask();
      document.getElementById("manualBatchInsertPosition").value = state.selected.length ? "after-selection" : "end";
      document.getElementById("manualBatchStepMinutes").value = "1";
      document.getElementById("manualBatchStepUnit").value = "minute";
      updateManualBatchStepHint();
      document.getElementById("manualBatchModalError").textContent = "";
      document.getElementById("manualBatchRows").innerHTML = "";
      addManualBatchRow();
      const modal = document.getElementById("manualBatchModal");
      resetDraggableModal(modal);
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setTimeout(() => document.querySelector("#manualBatchRows textarea")?.focus(), 0);
    }

    function closeManualBatchModal() {
      const modal = document.getElementById("manualBatchModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      document.getElementById("manualBatchModalError").textContent = "";
    }

    function initDraggableModal(modalId) {
      const backdrop = document.getElementById(modalId);
      const dialog = backdrop?.querySelector(".modal");
      const handle = backdrop?.querySelector(".modal-header");
      if (!backdrop || !dialog || !handle) return;
      let drag = null;
      handle.addEventListener("pointerdown", (event) => {
        if (event.button !== 0) return;
        if (event.target.closest("button,input,select,textarea,a")) return;
        const currentX = Number(dialog.dataset.dragX || 0);
        const currentY = Number(dialog.dataset.dragY || 0);
        drag = {
          startX: event.clientX,
          startY: event.clientY,
          currentX,
          currentY
        };
        dialog.classList.add("is-dragging");
        handle.setPointerCapture?.(event.pointerId);
        event.preventDefault();
      });
      handle.addEventListener("pointermove", (event) => {
        if (!drag) return;
        const x = drag.currentX + event.clientX - drag.startX;
        const y = drag.currentY + event.clientY - drag.startY;
        setDraggableModalOffset(dialog, x, y);
      });
      const stop = (event) => {
        if (!drag) return;
        drag = null;
        dialog.classList.remove("is-dragging");
        try {
          handle.releasePointerCapture?.(event.pointerId);
        } catch {}
      };
      handle.addEventListener("pointerup", stop);
      handle.addEventListener("pointercancel", stop);
    }

    function setDraggableModalOffset(dialog, x, y) {
      const bounds = dialog.getBoundingClientRect();
      const maxX = Math.max(0, (window.innerWidth - Math.min(180, bounds.width)) / 2);
      const maxY = Math.max(0, (window.innerHeight - Math.min(120, bounds.height)) / 2);
      const nextX = Math.max(-maxX, Math.min(maxX, x));
      const nextY = Math.max(-maxY, Math.min(maxY, y));
      dialog.dataset.dragX = String(nextX);
      dialog.dataset.dragY = String(nextY);
      dialog.style.transform = "translate(" + nextX + "px, " + nextY + "px)";
    }

    function resetDraggableModal(backdrop) {
      const dialog = backdrop?.querySelector(".modal");
      if (!dialog) return;
      dialog.dataset.dragX = "0";
      dialog.dataset.dragY = "0";
      dialog.style.transform = "";
      dialog.classList.remove("is-dragging");
    }

    function addManualBatchRow() {
      const tbody = document.getElementById("manualBatchRows");
      const state = manualBatchAnchorTask();
      const anchor = state.anchor || {};
      const row = document.createElement("tr");
      const date = normalizePreviewDate(anchor.date || defaultDate || todayMonthDay());
      row.className = "manual-batch-row";
      row.innerHTML =
        "<td><select class='manualBatchRole'><option value='tuo'>托</option><option value='douma'>豆妈</option></select></td>" +
        "<td><input class='manualBatchSpeaker'></td>" +
        "<td><input class='manualBatchDate'></td>" +
        "<td><input class='manualBatchTime'></td>" +
        "<td><select class='manualBatchType'><option value='text'>文字</option><option value='finder'>视频号</option><option value='image'>图片</option><option value='sticker'>表情包</option><option value='video'>视频</option></select></td>" +
        "<td><div class='manual-batch-content-cell'>" +
          "<textarea class='manualBatchContent' placeholder='填写正文；图片/视频/表情包填写本地素材路径'></textarea>" +
          "<div class='manual-batch-media-box' data-manual-batch-drop-zone='1' hidden>" +
            "<div class='thumb manualBatchThumb'>无素材</div>" +
            "<div class='manual-batch-media-tools'>" +
              "<div class='manual-batch-media-actions'>" +
                "<input class='hidden-file manualBatchFile' type='file'>" +
                "<button class='small-btn ghost manualBatchChooseBtn' type='button'>选择文件</button>" +
              "</div>" +
              "<div class='media-status manualBatchMediaStatus'>未选择素材</div>" +
              "<div class='media-hint'>可拖拽素材到这里，或复制图片后在本行 Ctrl+V 粘贴。</div>" +
            "</div>" +
          "</div>" +
        "</div></td>" +
        "<td><input class='manualBatchSkip' type='checkbox'></td>" +
        "<td><button class='small-btn manualBatchRemoveBtn' type='button'>删除</button></td>";
      row.querySelector(".manualBatchRole").value = anchor.role || "tuo";
      row.querySelector(".manualBatchSpeaker").value = anchor.speaker || "";
      row.querySelector(".manualBatchDate").value = date;
      row.querySelector(".manualBatchType").addEventListener("change", (event) => updateManualBatchContentPlaceholder(row, event.target.value));
      row.querySelector(".manualBatchContent").addEventListener("input", () => updateManualBatchMediaPreview(row));
      row.querySelector(".manualBatchFile").addEventListener("change", async (event) => {
        await setManualBatchMediaFile(row, event.target.files && event.target.files[0]);
      });
      row.querySelector(".manualBatchChooseBtn").addEventListener("click", () => row.querySelector(".manualBatchFile")?.click());
      row.querySelector(".manualBatchRemoveBtn").addEventListener("click", () => row.remove());
      tbody.appendChild(row);
      updateManualBatchContentPlaceholder(row, "text");
      refreshManualBatchTiming();
    }

    function manualBatchStepSeconds() {
      const value = Math.max(0, Number(document.getElementById("manualBatchStepMinutes")?.value || 0));
      const unit = document.getElementById("manualBatchStepUnit")?.value || "minute";
      return unit === "second" ? value : value * 60;
    }

    function updateManualBatchStepHint() {
      const input = document.getElementById("manualBatchStepMinutes");
      const unit = document.getElementById("manualBatchStepUnit")?.value || "minute";
      const raw = Math.max(0, Number(input?.value || 0));
      const label = unit === "second" ? "秒" : "分钟";
      const state = manualBatchAnchorTask();
      const base = validTime(state.anchor?.time) ? state.anchor.time : "19:34:37";
      const direction = state.mode === "before-selection" ? -1 : 1;
      const first = shiftClockSeconds(base, direction * raw * (unit === "second" ? 1 : 60));
      const second = shiftClockSeconds(base, direction * raw * (unit === "second" ? 2 : 120));
      const position = state.mode === "before-selection" ? "往前" : "往后";
      const node = document.getElementById("manualBatchStepHint");
      if (node) node.textContent = "例：参考时间 " + base + "，每行" + position + "递增 " + raw + " " + label + "，补录行自动变为 " + first + "、" + second + "。";
    }

    function refreshManualBatchTiming() {
      updateManualBatchStepHint();
      const rows = Array.from(document.querySelectorAll("#manualBatchRows tr"));
      const state = manualBatchAnchorTask();
      const anchor = state.anchor || {};
      const baseTime = validTime(anchor.time) ? anchor.time : currentClock();
      const stepSeconds = manualBatchStepSeconds();
      for (const [index, row] of rows.entries()) {
        const input = row.querySelector(".manualBatchTime");
        if (!input) continue;
        const previousAuto = input.dataset.autoValue || "";
        if (input.value && input.value !== previousAuto) continue;
        const offset = manualBatchTimeOffsetSeconds(index, rows.length, state.mode, stepSeconds);
        const nextValue = validTime(baseTime) ? shiftClockSeconds(baseTime, offset) : currentClock();
        input.value = nextValue;
        input.dataset.autoValue = nextValue;
      }
    }

    function manualBatchTimeOffsetSeconds(index, total, mode, stepSeconds) {
      if (mode === "before-selection") return -1 * Math.max(1, total - index) * stepSeconds;
      return (index + 1) * stepSeconds;
    }

    function updateManualBatchContentPlaceholder(row, type) {
      const input = row.querySelector(".manualBatchContent");
      if (!input) return;
      const mediaBox = row.querySelector("[data-manual-batch-drop-zone='1']");
      const file = row.querySelector(".manualBatchFile");
      const isText = isTextLikeType(type);
      input.placeholder = isText ? "填写正文" : "可填写本地素材路径；也可点选择文件、拖拽文件或粘贴图片";
      if (mediaBox) mediaBox.hidden = isText;
      if (file) {
        file.setAttribute("accept", acceptForType(type));
        file.value = "";
      }
      updateManualBatchMediaPreview(row);
    }

    function updateManualBatchMediaPreview(row) {
      const type = row.querySelector(".manualBatchType")?.value || "";
      const mediaBox = row.querySelector("[data-manual-batch-drop-zone='1']");
      const thumb = row.querySelector(".manualBatchThumb");
      const status = row.querySelector(".manualBatchMediaStatus");
      const pathValue = row.querySelector(".manualBatchContent")?.value.trim() || "";
      if (!mediaBox || !thumb || !status || isTextLikeType(type)) return;
      const preview = mediaPreviewSrc(pathValue);
      if (preview) {
        thumb.innerHTML = type === "video"
          ? "<video src='" + escapeAttr(preview) + "' muted></video>"
          : "<img src='" + escapeAttr(preview) + "' alt='素材预览'>";
        setThumbPopover(thumb, preview, type);
      } else {
        thumb.textContent = "无素材";
        setThumbPopover(thumb, "", type);
      }
      status.textContent = pathValue ? ("已选择：" + (shortPath(pathValue) || pathValue)) : "未选择素材";
      status.className = pathValue ? "media-status manualBatchMediaStatus" : "media-status manualBatchMediaStatus bad";
    }

    async function addManualBatchTasksFromModal() {
      const errorEl = document.getElementById("manualBatchModalError");
      errorEl.textContent = "";
      const rows = Array.from(document.querySelectorAll("#manualBatchRows tr"));
      const nextTasks = [];
      const errors = [];
      const stamp = Date.now();
      for (const [rowIndex, row] of rows.entries()) {
        const role = row.querySelector(".manualBatchRole").value;
        const speaker = row.querySelector(".manualBatchSpeaker").value.trim();
        const date = normalizePreviewDate(row.querySelector(".manualBatchDate").value);
        const time = row.querySelector(".manualBatchTime").value.trim();
        const type = row.querySelector(".manualBatchType").value;
        const skip = row.querySelector(".manualBatchSkip").checked;
        const content = row.querySelector(".manualBatchContent").value.trim();
        if (!content) continue;
        const label = "第 " + (rowIndex + 1) + " 行";
        if (!role) errors.push(label + " 请选择角色");
        if (!speaker) errors.push(label + " 请填写说话人");
        if (!date) errors.push(label + " 请填写日期");
        else if (!validDate(date)) errors.push(label + " 日期格式不合法");
        if (!time) errors.push(label + " 请填写时间");
        else if (!validTime(time)) errors.push(label + " 时间格式不合法");
        if (!type) errors.push(label + " 请选择类型");
        if (!isTextLikeType(type) && !mediaPathMatchesType(content, type)) errors.push(label + " 素材类型不匹配");
        nextTasks.push({
          sourceId: "manual-batch-" + stamp + "-" + rowIndex,
          sourceText: "手动批量新增",
          role,
          speaker,
          date,
          time,
          type,
          text: isTextLikeType(type) ? content : "",
          mediaPath: isTextLikeType(type) ? "" : content,
          skip,
          order: 0,
          interactionGroup: "",
          continueMarker: false,
          cleanSpeaker: speaker.replace(/\\s+/g, "")
        });
      }
      if (!nextTasks.length) errors.push("请至少填写一条正文或素材路径");
      if (errors.length) {
        errorEl.textContent = errors.join("；");
        return;
      }
      const sourceText = nextTasks.length === 1 ? "手动新增" : "手动批量新增";
      for (const task of nextTasks) task.sourceText = sourceText;
      for (const task of nextTasks) {
        if (isTextLikeType(task.type)) continue;
        const status = await fetch("/api/media-status?path=" + encodeURIComponent(task.mediaPath)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
        if (!status.ok) {
          errorEl.textContent = "素材不可用：" + (status.message || task.mediaPath);
          return;
        }
      }
      collect();
      const insertAt = manualBatchInsertIndex();
      pushUndoSnapshot("手动批量补录");
      tasks.splice(insertAt, 0, ...nextTasks);
      originalTimes.splice(insertAt, 0, ...nextTasks.map(() => ({ date: "", time: "" })));
      reindexTaskOrders();
      selectedRows = new Set(nextTasks.map((_, offset) => insertAt + offset));
      viewMode = "execution";
      closeManualBatchModal();
      render();
      markDirty("已手动补录 " + nextTasks.length + " 条，正在自动保存预览内容");
    }

    function manualBatchInsertIndex() {
      const mode = document.getElementById("manualBatchInsertPosition").value;
      const selected = selectedIndexes();
      if (mode === "before-selection" && selected.length) return Math.min(...selected);
      if (mode === "after-selection" && selected.length) return Math.max(...selected) + 1;
      return tasks.length;
    }

    function updateManualTypeFields() {
      const type = document.getElementById("manualType").value;
      document.getElementById("manualTextWrap").hidden = !isTextLikeType(type);
      document.getElementById("manualMediaWrap").hidden = isTextLikeType(type);
      document.getElementById("manualMediaFile").setAttribute("accept", acceptForType(type));
      document.getElementById("manualModalError").textContent = "";
      updateManualMediaPreview();
    }

    async function updateManualMediaPreview() {
      const type = document.getElementById("manualType").value;
      const thumb = document.getElementById("manualMediaThumb");
      const status = document.getElementById("manualMediaStatus");
      const short = document.getElementById("manualMediaShortPath");
      if (isTextLikeType(type)) return;
      const file = document.getElementById("manualMediaFile").files?.[0];
      const pathValue = document.getElementById("manualMediaPath").value.trim();
      if (file) {
        const objectUrl = URL.createObjectURL(file);
        thumb.innerHTML = type === "video"
          ? "<video src='" + escapeAttr(objectUrl) + "' muted></video>"
          : "<img src='" + escapeAttr(objectUrl) + "' alt='素材预览'>";
        setThumbPopover(thumb, objectUrl, type);
        short.textContent = file.name;
        status.textContent = "已选择本地文件，点击添加后保存到本轮素材缓存";
        status.className = "media-status";
        return;
      }
      short.textContent = shortPath(pathValue) || "未选择素材";
      const preview = mediaPreviewSrc(pathValue);
      if (preview) {
        thumb.innerHTML = type === "video"
          ? "<video src='" + escapeAttr(preview) + "' muted></video>"
          : "<img src='" + escapeAttr(preview) + "' alt='素材预览'>";
        setThumbPopover(thumb, preview, type);
      } else {
        thumb.textContent = "无素材";
        setThumbPopover(thumb, "", type);
      }
      if (!pathValue) {
        status.textContent = "未选择素材";
        status.className = "media-status bad";
        return;
      }
      const result = await fetch("/api/media-status?path=" + encodeURIComponent(pathValue)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
      status.textContent = result.message || (result.ok ? "素材可用" : "素材不可用");
      status.className = result.ok ? "media-status" : "media-status bad";
    }

    async function addManualTaskFromModal() {
      const errorEl = document.getElementById("manualModalError");
      errorEl.textContent = "";
      const role = document.getElementById("manualRole").value;
      const speaker = document.getElementById("manualSpeaker").value.trim();
      const date = normalizePreviewDate(document.getElementById("manualDate").value);
      const time = document.getElementById("manualTime").value.trim();
      const type = document.getElementById("manualType").value;
      const skip = document.getElementById("manualSkip").checked;
      const text = document.getElementById("manualText").value;
      let mediaPath = document.getElementById("manualMediaPath").value.trim();
      const file = document.getElementById("manualMediaFile").files?.[0] || null;
      const errors = [];
      if (!role) errors.push("请选择角色");
      if (!speaker) errors.push("请填写说话人");
      if (!date) errors.push("请填写日期");
      else if (!validDate(date)) errors.push("日期格式不合法");
      if (!time) errors.push("请填写时间");
      else if (!validTime(time)) errors.push("时间格式不合法");
      if (!type) errors.push("请选择类型");
      if (isTextLikeType(type)) {
        if (!String(text || "").trim()) errors.push("请填写正文");
      } else if (!file && !mediaPath) {
        errors.push("请选择或填写本地素材路径");
      } else if (mediaPath && !mediaPathMatchesType(mediaPath, type)) {
        errors.push("素材类型不匹配");
      }
      if (errors.length) {
        errorEl.textContent = errors.join("；");
        return;
      }
      if (!isTextLikeType(type) && file) {
        const form = new FormData();
        form.append("file", file);
        form.append("type", type);
        form.append("sourceId", "manual-" + Date.now());
        const uploaded = await postForm("/api/upload-media", form);
        if (!uploaded.ok) {
          errorEl.textContent = uploaded.error || "素材上传失败";
          return;
        }
        mediaPath = uploaded.path;
      }
      if (!isTextLikeType(type) && mediaPath) {
        const status = await fetch("/api/media-status?path=" + encodeURIComponent(mediaPath)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
        if (!status.ok) {
          errorEl.textContent = status.message || "素材不可用";
          return;
        }
      }
      collect();
      const insertAt = manualInsertIndex();
      pushUndoSnapshot("手动新增");
      const task = {
        sourceId: "manual-" + Date.now(),
        sourceText: "手动新增",
        role,
        speaker,
        date,
        time,
        type,
        text: isTextLikeType(type) ? text : "",
        mediaPath: isTextLikeType(type) ? "" : mediaPath,
        skip,
        order: 0,
        interactionGroup: "",
        continueMarker: false,
        cleanSpeaker: speaker.replace(/\\s+/g, "")
      };
      tasks.splice(insertAt, 0, task);
      originalTimes.splice(insertAt, 0, { date: "", time: "" });
      reindexTaskOrders();
      selectedRows = new Set([insertAt]);
      viewMode = "execution";
      closeManualModal();
      render();
      markDirty("已手动新增一条，正在自动保存预览内容");
    }

    function manualInsertIndex() {
      const mode = document.getElementById("manualInsertPosition").value;
      const selected = selectedIndexes();
      if (mode === "before-selection" && selected.length) return Math.min(...selected);
      if (mode === "after-selection" && selected.length) return Math.max(...selected) + 1;
      return tasks.length;
    }

    function reindexTaskOrders() {
      tasks = tasks.map((task, index) => ({ ...task, order: index + 1 }));
    }

    function shiftClock(value, minutes) {
      return shiftClockSeconds(value, Number(minutes || 0) * 60);
    }

    function shiftClockSeconds(value, seconds) {
      const base = parseClockSeconds(value);
      if (!Number.isFinite(base)) return value;
      let total = base + Number(seconds || 0);
      total = ((total % 86400) + 86400) % 86400;
      return formatClockSeconds(total);
    }

    function shiftPreviewDateTime(date, time, seconds) {
      const base = parseClockSeconds(time);
      if (!Number.isFinite(base)) return { date, time };
      const total = base + Number(seconds || 0);
      const dayDelta = Math.floor(total / 86400);
      const secondsOfDay = ((total % 86400) + 86400) % 86400;
      return {
        date: dayDelta ? shiftPreviewDate(date, dayDelta) : date,
        time: formatClockSeconds(secondsOfDay)
      };
    }

    function parseClockSeconds(value) {
      const match = String(value || "").trim().match(/^(\\d{1,2})[:：](\\d{1,2})(?:[:：](\\d{1,2}))?$/);
      if (!match) return NaN;
      return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0);
    }

    function formatClockSeconds(total) {
      const hour = Math.floor(total / 3600);
      const minute = Math.floor((total % 3600) / 60);
      const second = total % 60;
      return pad2(hour) + ":" + pad2(minute) + ":" + pad2(second);
    }

    function shiftPreviewDate(value, dayDelta) {
      const parts = parsePreviewDateParts(value);
      if (!parts) return value;
      const date = new Date(parts.year, parts.month - 1, parts.day);
      if (Number.isNaN(date.getTime())) return value;
      date.setDate(date.getDate() + Number(dayDelta || 0));
      return (date.getMonth() + 1) + "/" + date.getDate();
    }

    function parsePreviewDateParts(value) {
      const text = String(value || "").trim();
      const ymd = text.match(/^(\\d{4})-(\\d{1,2})-(\\d{1,2})$/);
      if (ymd) return { year: Number(ymd[1]), month: Number(ymd[2]), day: Number(ymd[3]) };
      const md = text.match(/^(\\d{1,2})\\s*[\\/月-]\\s*(\\d{1,2})\\s*日?$/);
      if (md) return { year: new Date().getFullYear(), month: Number(md[1]), day: Number(md[2]) };
      return null;
    }

    function batchTimeUnitSeconds(unit) {
      if (unit === "second") return 1;
      if (unit === "hour") return 3600;
      if (unit === "day") return 86400;
      return 60;
    }

    function batchTimeUnitLabel(unit) {
      if (unit === "second") return "秒";
      if (unit === "hour") return "小时";
      if (unit === "day") return "天";
      return "分钟";
    }

    async function uploadReplacement(row, file) {
      if (!file) return;
      updateTaskFromRow(row);
      const index = Number(row.dataset.index);
      const task = tasks[index];
      const result = await uploadMediaFile(file, task.type || "", task.sourceId || "");
      if (!result.ok) {
        setStatus(result.error || "素材上传失败", true);
        return;
      }
      pushUndoSnapshot("更换素材");
      task.mediaPath = result.path;
      delete task.previewError;
      row.querySelector("[data-field='mediaPath']").value = result.path;
      if (previewRepairProblem && Number(previewRepairProblem.index) === index) previewRepairProblem = null;
      render();
      markDirty("素材已替换，正在自动保存预览内容");
    }

    async function setManualModalMediaFile(file) {
      const type = document.getElementById("manualType").value;
      if (isTextLikeType(type)) return setStatus("当前补录类型是文字，不需要上传素材", true);
      const result = await uploadMediaFile(file, type, "manual-" + Date.now());
      const errorEl = document.getElementById("manualModalError");
      if (!result.ok) {
        if (errorEl) errorEl.textContent = result.error || "素材上传失败";
        setStatus(result.error || "素材上传失败", true);
        return;
      }
      document.getElementById("manualMediaPath").value = result.path;
      document.getElementById("manualMediaFile").value = "";
      await updateManualMediaPreview();
      setStatus("素材已上传，可继续补录。");
    }

    async function setManualBatchMediaFile(row, file) {
      if (!row) return;
      const type = row.querySelector(".manualBatchType")?.value || "";
      const errorEl = document.getElementById("manualBatchModalError");
      if (isTextLikeType(type)) {
        if (errorEl) errorEl.textContent = "当前行是文字类型，不需要上传素材。";
        return;
      }
      const result = await uploadMediaFile(file, type, "manual-batch-" + Date.now());
      if (!result.ok) {
        if (errorEl) errorEl.textContent = result.error || "素材上传失败";
        setStatus(result.error || "素材上传失败", true);
        return;
      }
      row.querySelector(".manualBatchContent").value = result.path;
      const fileInput = row.querySelector(".manualBatchFile");
      if (fileInput) fileInput.value = "";
      updateManualBatchMediaPreview(row);
      if (errorEl) errorEl.textContent = "";
      setStatus("批量补录素材已上传。");
    }

    async function uploadMediaFile(file, type, sourceId = "") {
      const form = new FormData();
      form.append("file", file);
      form.append("type", type || "");
      form.append("sourceId", sourceId || "");
      return postForm("/api/upload-media", form);
    }

    function validateClient(items) {
      const errors = [];
      for (const [index, task] of items.entries()) {
        if (task.skip) continue;
        const label = "第 " + (index + 1) + " 条";
        if (String(task.previewError || "").trim()) errors.push({ index, message: String(task.previewError || "").trim() });
        if (!task.role) errors.push({ index, message: label + " 缺少角色" });
        if (!String(task.date || "").trim()) errors.push({ index, message: label + " 缺少日期" });
        else if (!validDate(task.date)) errors.push({ index, message: label + " 日期格式不合法" });
        if (!String(task.time || "").trim()) errors.push({ index, message: label + " 缺少时间" });
        else if (!validTime(task.time)) errors.push({ index, message: label + " 时间格式不合法" });
        if (isTextLikeType(task.type)) {
          if (!String(task.text || "").trim()) errors.push({ index, message: label + " 正文为空" });
          else if (task.type === "finder" && !isCompleteFinderXml(task.text)) errors.push({ index, message: label + " 视频号代码块未完整采集，请手动补录完整参数" });
        } else if (!String(task.mediaPath || "").trim()) {
          errors.push({ index, message: label + " 素材路径为空" });
        } else if (/^(blob:|image-blob:)/i.test(String(task.mediaPath || "").trim())) {
          errors.push({ index, message: label + " 是临时素材地址，请重新生成预览或点更换素材换成本地文件" });
        } else if (!mediaPathMatchesType(task.mediaPath, task.type)) {
          errors.push({ index, message: label + " 素材类型不匹配" });
        }
      }
      return errors;
    }

    function markInvalidRows(errors) {
      document.querySelectorAll("tbody tr").forEach((row) => clearRowError(row));
      const byIndex = new Map();
      for (const error of errors) {
        if (!byIndex.has(error.index)) byIndex.set(error.index, []);
        byIndex.get(error.index).push(error.message);
      }
      for (const [index, messages] of byIndex.entries()) {
        const row = document.querySelector("tr[data-index='" + index + "']");
        if (!row) continue;
        row.classList.add("invalid");
        const note = document.createElement("div");
        note.className = "row-note error";
        note.dataset.validationNote = "1";
        note.textContent = messages.join("；");
        (row.querySelector(".content-grid") || row.querySelector("td:last-child")).appendChild(note);
      }
    }

    function clearRowError(row) {
      row.classList.remove("invalid");
      row.querySelectorAll("[data-validation-note='1']").forEach((node) => node.remove());
    }

    function timeSortKey(task) {
      return dateSortKey(task.date) * 1000000 + clockSortKey(task.time);
    }

    function dateSortKey(date) {
      const match = String(date || "").match(/(\\d{1,2})\\s*[\\\/月]\\s*(\\d{1,2})/);
      if (!match) return 0;
      return Number(match[1]) * 100 + Number(match[2]);
    }

    function clockSortKey(time) {
      const match = String(time || "").match(/^(\\d{1,2}):(\\d{1,2})(?::(\\d{1,2}))?/);
      if (!match) return 999999;
      return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0);
    }

    function updateViewControls() {
      document.getElementById("executionViewBtn").classList.toggle("active", viewMode === "execution");
      document.getElementById("timeViewBtn").classList.toggle("active", viewMode === "time");
      const toggleSkippedRowsBtn = document.getElementById("toggleSkippedRowsBtn");
      toggleSkippedRowsBtn.classList.toggle("active", hideSkippedRows);
      toggleSkippedRowsBtn.textContent = hideSkippedRows ? "显示全部" : "隐藏不发";
      const selectedCount = selectedIndexes().length;
      const skipCount = tasks.filter((task) => task.skip).length;
      document.getElementById("totalCount").textContent = String(tasks.length);
      document.getElementById("selectedCount").textContent = String(selectedCount);
      document.getElementById("batchSelectedCount").textContent = String(selectedCount);
      document.getElementById("skipCount").textContent = String(skipCount);
      updateTimeDirectionButtons();
      updateUndoButtons();
    }

    function updateTimeDirectionButtons() {
      document.getElementById("delayBtn").classList.toggle("active", pendingTimeDirection === 1);
      document.getElementById("advanceBtn").classList.toggle("active", pendingTimeDirection === -1);
    }

    function initBatchDateControls() {
      const select = document.getElementById("batchDateQuick");
      if (!select) return;
      select.innerHTML = batchDateOptions().map((option) =>
        "<option value='" + escapeAttr(option.value) + "'>" + escapeHtmlJs(option.label) + "</option>"
      ).join("");
      select.value = todayMonthDay();
      updateBatchDateCustomVisibility();
    }

    function batchDateOptions() {
      return [
        { label: "今天 " + dateOffsetMonthDay(0), value: dateOffsetMonthDay(0) },
        { label: "明天 " + dateOffsetMonthDay(1), value: dateOffsetMonthDay(1) },
        { label: "后天 " + dateOffsetMonthDay(2), value: dateOffsetMonthDay(2) },
        { label: "大后天 " + dateOffsetMonthDay(3), value: dateOffsetMonthDay(3) },
        { label: "自定义日期", value: "custom" }
      ];
    }

    function updateBatchDateCustomVisibility() {
      const custom = document.getElementById("batchDateCustom");
      const select = document.getElementById("batchDateQuick");
      if (!custom || !select) return;
      custom.hidden = select.value !== "custom";
      if (!custom.hidden) custom.focus();
    }

    function selectedBatchDate() {
      const select = document.getElementById("batchDateQuick");
      if (!select) return "";
      if (select.value !== "custom") return normalizePreviewDate(select.value);
      return normalizePreviewDate(document.getElementById("batchDateCustom")?.value || "");
    }

    function input(field, value, type = "text", readonly = false) {
      return "<input data-field='" + field + "' type='" + type + "' value='" + escapeAttr(value ?? "") + "'" + (readonly ? " readonly" : "") + ">";
    }
    function textarea(field, value, readonly = false) {
      return "<textarea data-field='" + field + "'" + (readonly ? " readonly" : "") + ">" + escapeHtmlJs(value ?? "") + "</textarea>";
    }
    function checkbox(field, value) {
      return "<input data-field='" + field + "' type='checkbox'" + (value ? " checked" : "") + ">";
    }
    function select(field, value, options) {
      return "<select data-field='" + field + "'>" + options.map(([key, label]) => "<option value='" + key + "'" + (key === value ? " selected" : "") + ">" + label + "</option>").join("") + "</select>";
    }
    function fileInput(task) {
      return "<input class='hidden-file' data-upload-for='mediaPath' type='file' accept='" + acceptForType(task.type) + "'>";
    }
    function speakerCell(task, originalIndex) {
      if (!isPreciseTuoTask(task)) return cell(input("speaker", task.speaker));
      return cell(preciseTuoSpeakerPicker(task, originalIndex));
    }
    function preciseTuoSpeakerPicker(task, originalIndex) {
      const selectedPersona = selectedPersonaForTask(task);
      const listId = "tuo-speaker-options-" + originalIndex;
      const options = preciseTuoOptionsForTask(task, selectedPersona);
      return "<div class='speaker-picker' data-precise-speaker-row='1'>" +
        "<div class='speaker-main-row'>" +
          "<div class='persona-note' data-persona-note='1'>" + preciseTuoNote(task, selectedPersona) + "</div>" +
          personaSelect(task, selectedPersona) +
          "<input data-field='speaker' list='" + escapeAttr(listId) + "' value='" + escapeAttr(task.speaker || "") + "' placeholder='托号昵称'>" +
        "</div>" +
        preciseTuoDatalist(listId, options) +
        candidateSelect(task, selectedPersona) +
      "</div>";
    }
    function personaSelect(task, selectedPersona) {
      return "<select data-persona-filter='1'>" + precisePersonaOptions(task).map((option) =>
        "<option value='" + escapeAttr(option.value) + "'" + (option.value === selectedPersona ? " selected" : "") + ">" + escapeHtmlJs(option.label) + "</option>"
      ).join("") + "</select>";
    }
    function preciseTuoDatalist(id, options) {
      return "<datalist id='" + escapeAttr(id) + "'>" + options.map((item) =>
        "<option value='" + escapeAttr(item.nickname || "") + "' label='" + escapeAttr(candidateOptionLabel(item)) + "'></option>"
      ).join("") + "</datalist>";
    }
    function refreshPreciseTuoDatalist(row) {
      const index = Number(row.dataset.index);
      const task = tasks[index];
      if (!task) return;
      const persona = row.querySelector("[data-persona-filter='1']")?.value || "all";
      const datalist = row.querySelector("datalist");
      if (datalist) {
        datalist.innerHTML = preciseTuoOptionsForTask(task, persona).map((item) =>
          "<option value='" + escapeAttr(item.nickname || "") + "' label='" + escapeAttr(candidateOptionLabel(item)) + "'></option>"
        ).join("");
      }
      const note = row.querySelector("[data-persona-note='1']");
      if (note) note.innerHTML = preciseTuoNote(task, persona);
      const list = row.querySelector("[data-candidate-list='1']");
      if (list) list.outerHTML = candidateSelect(task, persona);
    }
    function isPreciseTuoTask(task) {
      return preciseTuoEnabled && task?.role === "tuo" && task?.tuoAssignment?.mode === "precise_roster";
    }
    function selectedPersonaForTask(task) {
      const saved = String(task?.tuoAssignment?.selectedPersona || "").trim();
      if (saved) return saved;
      return firstPersonaLabel(currentPreciseCandidate(task) || task?.tuoAssignment?.primary) || "all";
    }
    function precisePersonaOptions(task) {
      const personas = new Set();
      for (const item of allPreciseTuoOptions(task)) {
        for (const label of candidatePersonaLabels(item)) {
          if (label) personas.add(label);
        }
      }
      const ordered = Array.from(personas);
      return [
        { value: "all", label: "全部人设" },
        ...ordered.map((label) => ({ value: label, label }))
      ];
    }
    function preciseTuoOptionsForTask(task, persona) {
      const selected = String(persona || "all");
      const options = allPreciseTuoOptions(task);
      if (selected === "all") return options;
      return options.filter((item) => candidatePersonaLabels(item).includes(selected));
    }
    function allPreciseTuoOptions(task) {
      const sources = [
        ...(Array.isArray(task?.tuoAssignment?.candidates) ? task.tuoAssignment.candidates : []),
        ...(task?.tuoAssignment?.primary?.nickname ? [task.tuoAssignment.primary] : []),
        ...(Array.isArray(preciseTuoRosterOptions) ? preciseTuoRosterOptions : [])
      ];
      const seen = new Set();
      const result = [];
      for (const item of sources) {
        const nickname = String(item?.nickname || "").trim();
        const key = normalizeTuoKey(nickname);
        if (!key || seen.has(key)) continue;
        seen.add(key);
        result.push(item);
      }
      return result;
    }
    function currentPreciseCandidate(task) {
      const key = normalizeTuoKey(task?.speaker || "");
      return allPreciseTuoOptions(task).find((item) => normalizeTuoKey(item.nickname) === key) || null;
    }
    function preciseTuoNote(task, persona) {
      return "<div class='current-candidate'>" +
        "<span class='current-label'>在用</span>" +
      "</div>";
    }
    function candidateOptionLabel(item) {
      return candidateSummary(item, item?.nickname || "");
    }
    function candidateSelect(task, persona) {
      const candidates = alternatePreciseCandidates(task, persona);
      const recommended = recommendedPreciseCandidates(task, persona).slice(0, 2);
      const options = ["<option value=''>选择备选托</option>", ...candidates.map((item) =>
        "<option value='" + escapeAttr(item.nickname || "") + "'>" + escapeHtmlJs(candidateSummary(item, item.nickname || "")) + "</option>"
      )].join("");
      return "<div class='candidate-list' data-candidate-list='1'>" +
        "<div></div><div class='candidate-section-label'>备选</div>" +
        "<div class='candidate-picks'>" +
          recommended.map((item, index) =>
            "<button class='candidate-pick" + (item.backup ? " backup" : "") + "' type='button' data-candidate-pick='" + escapeAttr(item.nickname || "") + "'>" +
              candidateDisplay(item, index === 0 ? "①" : "②") +
            "</button>"
          ).join("") +
        "</div>" +
        "<div></div><div class='candidate-section-label'>更多</div><select data-candidate-select='1'>" + options + "</select>" +
      "</div>";
    }
    function recommendedPreciseCandidates(task, persona) {
      const selected = String(persona || "all");
      const currentKey = normalizeTuoKey(task?.speaker || "");
      const source = Array.isArray(task?.tuoAssignment?.candidates) ? task.tuoAssignment.candidates : [];
      const seen = new Set();
      const result = [];
      for (const item of source) {
        const key = normalizeTuoKey(item?.nickname || "");
        if (!key || key === currentKey || seen.has(key)) continue;
        if (selected !== "all" && !candidatePersonaLabels(item).includes(selected)) continue;
        seen.add(key);
        result.push(item);
      }
      return result;
    }
    function alternatePreciseCandidates(task, persona) {
      const currentKey = normalizeTuoKey(task?.speaker || "");
      const primary = preciseTuoOptionsForTask(task, persona).filter((item) => normalizeTuoKey(item.nickname) !== currentKey);
      const seen = new Set(primary.map((item) => normalizeTuoKey(item.nickname)));
      const extra = allPreciseTuoOptions(task).filter((item) => {
        const key = normalizeTuoKey(item.nickname);
        if (!key || key === currentKey || seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      return [...primary, ...extra];
    }
    function candidateSummary(item, fallbackName = "") {
      const name = String(item?.nickname || fallbackName || "").trim();
      const personas = candidatePersonaLabels(item);
      const aux = Array.isArray(item?.auxTags) ? item.auxTags : [];
      const parts = [name || "未匹配名单"];
      if (personas.length) parts.push(personas.join("/"));
      if (aux.length) parts.push(aux.join("/"));
      if (item?.backup) parts.push("备用");
      return parts.filter(Boolean).join("｜");
    }
    function candidateDisplay(item, prefix = "") {
      const name = String(item?.nickname || "").trim() || "未匹配名单";
      return (prefix ? "<span class='candidate-prefix'>" + escapeHtmlJs(prefix) + "</span>" : "") +
        "<span class='candidate-text'>" + escapeHtmlJs(name) + "</span>" +
        candidateMetaHtml(item) +
        (item?.backup ? "<span class='backup-tag'>备用</span>" : "");
    }
    function candidateMetaHtml(item = {}) {
      const labels = [
        ...candidatePersonaLabels(item),
        ...(Array.isArray(item?.auxTags) ? item.auxTags : [])
      ].filter(Boolean);
      if (!labels.length) return "";
      return "<span class='candidate-meta'>" + escapeHtmlJs(labels.join(" / ")) + "</span>";
    }
    function candidatePersonaLabels(item = {}) {
      if (Array.isArray(item.personas) && item.personas.length) return item.personas.filter(Boolean);
      return (item.tags || []).map(personaLabel).filter(Boolean);
    }
    function firstPersonaLabel(item = {}) {
      return candidatePersonaLabels(item)[0] || "";
    }
    function personaLabel(tag) {
      if (tag === "mom") return "宝妈";
      if (tag === "work") return "工作";
      if (tag === "young") return "年轻女性";
      if (tag === "mature") return "成熟女性";
      if (tag === "female") return "女性";
      if (tag === "male") return "男性";
      return "";
    }
    function normalizeTuoKey(value) {
      return String(value || "").replace(/\s+/g, "").toLowerCase();
    }
    function dateCell(originalIndex, task) {
      return cell(input("date", task.date) + "<div class='subnote'>原日期：" + escapeHtmlJs(originalTimes[originalIndex]?.date || "-") + "</div>");
    }
    function timeCell(originalIndex, task) {
      return cell(input("time", task.time) + "<div class='subnote'>原时间：" + escapeHtmlJs(originalTimes[originalIndex]?.time || "-") + "</div>");
    }
    function contentCell(task) {
      const details = debugDetails(task);
      const warning = previewWarningNote(task);
      if (isTextLikeType(task.type)) {
        return cell("<div class='content-grid'>" + warning + textarea("text", task.text) + textDetailButton(task) + hiddenMediaField(task) + details + "</div>");
      }
      return cell("<div class='content-grid'>" + warning + hiddenTextField(task) + mediaCell(task) + details + "</div>");
    }
    function previewWarningNote(task) {
      const warning = String(task?.previewWarning || "").trim();
      return warning ? "<div class='row-note warning'>" + escapeHtmlJs(warning) + "</div>" : "";
    }
    function textDetailButton(task) {
      return "<div class='content-actions'><button class='small-btn ghost' type='button' data-action='view-text-detail'>" + escapeHtmlJs(textDetailButtonLabel(task)) + "</button></div>";
    }
    function textDetailButtonLabel(task) {
      const length = String(task?.text || "").length;
      return "查看详情" + (length ? "（" + length + "字）" : "");
    }
    function mediaCell(task) {
      const path = task.mediaPath || "";
      const disabled = isTextLikeType(task.type) ? " disabled" : "";
      return "<div class='media-box media-drop-zone' data-media-drop-zone='1'>" +
        mediaThumb(task) +
        "<div>" +
          "<span class='tag'>" + typeLabel(task.type) + "</span>" +
          input("mediaPath", path) +
          "<div class='preview-path'>" + escapeHtmlJs(shortPath(path) || "未选择素材") + "</div>" +
          "<div class='media-status' data-media-status data-path='" + escapeAttr(path) + "'>正在检查素材状态...</div>" +
          fileInput(task) +
          "<div class='media-tools'><button class='small-btn ghost' data-action='choose-media'" + disabled + ">更换素材</button></div>" +
          "<div class='media-hint'>可拖拽素材到这里，或复制图片后在本行 Ctrl+V 粘贴。</div>" +
        "</div>" +
      "</div>";
    }
    function mediaThumb(task) {
      const src = mediaPreviewSrc(task.mediaPath);
      if (!src || isTextLikeType(task.type)) return "<div class='thumb'>无素材</div>";
      const attrs = " class='thumb media-thumb' data-media-popover-src='" + escapeAttr(src) + "' data-media-popover-type='" + escapeAttr(task.type) + "' title='点击放大检查素材'";
      if (task.type === "video") return "<div" + attrs + "><video src='" + escapeAttr(src) + "' muted></video></div>";
      return "<div" + attrs + "><img src='" + escapeAttr(src) + "' alt='素材预览'></div>";
    }
    function mediaPreviewSrc(value) {
      const text = String(value || "").trim();
      if (!text) return "";
      if (/^https?:\\/\\//i.test(text)) return "";
      if (/^data:/i.test(text)) return text;
      return "/api/media-preview?path=" + encodeURIComponent(text);
    }
    function showContentDetailModal(task = {}, taskIndex = "") {
      const modal = document.getElementById("contentDetailModal");
      const text = document.getElementById("contentDetailText");
      const meta = document.getElementById("contentDetailMeta");
      modal.dataset.taskIndex = String(taskIndex ?? "");
      meta.textContent = contentDetailLabel(task);
      text.value = task.text || "";
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setTimeout(() => text.focus(), 0);
    }
    function contentDetailLabel(task = {}) {
      return [typeLabel(task.type), task.speaker || "", task.date || "", task.time || ""].filter(Boolean).join(" / ") || "当前内容";
    }
    function closeContentDetailModal() {
      const modal = document.getElementById("contentDetailModal");
      if (!modal) return;
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    }
    async function refreshMediaStatuses() {
      const nodes = Array.from(document.querySelectorAll("[data-media-status]"));
      await Promise.all(nodes.map(async (node) => {
        const value = node.dataset.path || "";
        if (!value) {
          node.textContent = "未选择素材";
          node.className = "media-status bad";
          return;
        }
        const result = await fetch("/api/media-status?path=" + encodeURIComponent(value)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
        node.textContent = result.message || (result.ok ? "素材可用" : "素材不可用");
        node.className = result.ok ? "media-status" : "media-status bad";
      }));
    }
    function cell(html) { return "<td>" + html + "</td>"; }
    function execCell(originalIndex, task) {
      const manual = isManualTask(task) ? "<span class='manual-badge'>手动新增</span>" : "";
      return "<td class='index-cell'><strong>" + (originalIndex + 1) + "</strong><div class='subnote'>执行顺序</div>" + manual + hiddenInput("order", task.order, "number") + "</td>";
    }
    function rowCheckbox(originalIndex) {
      return "<input type='checkbox' data-select-row='1'" + (selectedRows.has(originalIndex) ? " checked" : "") + ">";
    }
    function applyRowSelectionDrag(row) {
      if (!rowSelectDrag) return;
      const index = Number(row.dataset.index);
      if (!Number.isFinite(index) || rowSelectDrag.seen.has(index)) return;
      rowSelectDrag.seen.add(index);
      if (rowSelectDrag.checked) selectedRows.add(index);
      else selectedRows.delete(index);
      const checkbox = row.querySelector("input[data-select-row='1']");
      if (checkbox) checkbox.checked = rowSelectDrag.checked;
      updateViewControls();
    }
    function finishRowSelectionDrag() {
      if (!rowSelectDrag) return;
      rowSelectDrag = null;
      document.body.classList.remove("row-select-dragging");
      suppressRowSelectClickUntil = Date.now() + 250;
    }
    function skipCell(task) {
      return cell(checkbox("skip", task.skip) + "<div class='subnote'>" + (task.skip ? "不发，创建时跳过" : "要发") + "</div>");
    }
    function debugDetails(task) {
      return "<details class='debug'><summary>高级/调试信息</summary><div class='debug-grid'>" +
        debugField("interactionGroup", input("interactionGroup", task.interactionGroup)) +
        debugField("continueMarker", checkbox("continueMarker", task.continueMarker)) +
        debugField("cleanSpeaker", input("cleanSpeaker", task.cleanSpeaker)) +
        debugField("sourceId", input("sourceId", task.sourceId, "text", true)) +
        debugField("sourceText", textarea("sourceText", task.sourceText, true)) +
      "</div></details>";
    }
    function debugField(label, control) {
      return "<label>" + label + control + "</label>";
    }
    function hiddenInput(field, value, type = "text") {
      return "<input data-field='" + field + "' type='" + type + "' value='" + escapeAttr(value ?? "") + "' hidden>";
    }
    function hiddenMediaField(task) {
      return "<input data-field='mediaPath' value='" + escapeAttr(task.mediaPath || "") + "' hidden>";
    }
    function hiddenTextField(task) {
      return "<textarea data-field='text' hidden>" + escapeHtmlJs(task.text || "") + "</textarea>";
    }
    function typeLabel(type) {
      if (type === "image") return "图片";
      if (type === "sticker") return "表情包";
      if (type === "video") return "视频";
      if (type === "finder") return "视频号";
      return "文字";
    }
    function isTextLikeType(type) {
      return type === "text" || type === "finder";
    }
    function isCompleteFinderXml(text) {
      const value = String(text || "").trim();
      return /<msg\\b/i.test(value) &&
        /<appmsg\\b/i.test(value) &&
        (/<finderFeed\\b/i.test(value) || /<type>\\s*51\\s*<\\/type>/i.test(value)) &&
        /<\\/msg>\\s*$/i.test(value);
    }
    function isManualTask(task) {
      return /^manual-/i.test(String(task.sourceId || "")) || String(task.sourceText || "") === "手动新增";
    }
    function shortPath(value) {
      const text = String(value || "").trim();
      if (!text) return "";
      if (/^https?:\\/\\//i.test(text) || /^blob:/i.test(text)) return text;
      return text.split(/[\\\\\\/]/).slice(-3).join("\\\\");
    }
    function acceptForType(type) {
      if (type === "video") return ".mp4,.mov,.webm,video/*";
      if (type === "sticker") return ".gif,.webp,.png,.jpg,.jpeg,image/gif,image/webp,image/png,image/jpeg";
      return ".jpg,.jpeg,.png,.webp,.gif,image/*";
    }
    function toggleMediaPopover(target) {
      if (mediaPopoverTarget === target) {
        hideMediaPopover();
        return;
      }
      showMediaPopover(target);
    }
    function showMediaPopover(target) {
      const popover = document.getElementById("mediaPopover");
      const src = target.dataset.mediaPopoverSrc || "";
      const type = target.dataset.mediaPopoverType || "image";
      if (!popover || !src) return;
      popover.innerHTML = type === "video"
        ? "<video src='" + escapeAttr(src) + "' muted autoplay loop playsinline></video>"
        : "<img src='" + escapeAttr(src) + "' alt='素材放大预览'>";
      popover.classList.add("open");
      popover.setAttribute("aria-hidden", "false");
      mediaPopoverTarget = target;
      positionMediaPopover(target, popover);
      const video = popover.querySelector("video");
      if (video) video.play().catch(() => {});
    }
    function hideMediaPopover() {
      const popover = document.getElementById("mediaPopover");
      if (!popover) return;
      popover.classList.remove("open");
      popover.setAttribute("aria-hidden", "true");
      popover.innerHTML = "";
      mediaPopoverTarget = null;
    }
    function positionMediaPopover(target, popover) {
      const rect = target.getBoundingClientRect();
      const gap = 10;
      const margin = 12;
      const width = popover.offsetWidth || 286;
      const height = popover.offsetHeight || 260;
      let left = rect.right + gap;
      let top = rect.top;
      if (left + width > window.innerWidth - margin) left = rect.left - width - gap;
      if (left < margin) left = Math.max(margin, window.innerWidth - width - margin);
      if (top + height > window.innerHeight - margin) top = window.innerHeight - height - margin;
      if (top < margin) top = margin;
      popover.style.left = left + "px";
      popover.style.top = top + "px";
    }
    function setThumbPopover(thumb, src, type) {
      if (!thumb) return;
      if (src && !isTextLikeType(type)) {
        thumb.classList.add("media-thumb");
        thumb.dataset.mediaPopoverSrc = src;
        thumb.dataset.mediaPopoverType = type || "image";
        thumb.title = "点击放大检查素材";
        return;
      }
      thumb.classList.remove("media-thumb");
      delete thumb.dataset.mediaPopoverSrc;
      delete thumb.dataset.mediaPopoverType;
      thumb.removeAttribute("title");
    }
    function validDate(value) {
      const text = String(value || "").trim();
      return /^\\d{1,2}\\s*[\\/月-]\\s*\\d{1,2}\\s*日?$/.test(text) || /^\\d{4}-\\d{1,2}-\\d{1,2}$/.test(text);
    }
    function normalizePreviewDate(value) {
      const text = String(value || "").trim();
      const ymd = text.match(/^\\d{4}-(\\d{1,2})-(\\d{1,2})$/);
      if (ymd) return Number(ymd[1]) + "/" + Number(ymd[2]);
      const md = text.match(/^(\\d{1,2})\\s*[\\/月-]\\s*(\\d{1,2})\\s*日?$/);
      if (md) return Number(md[1]) + "/" + Number(md[2]);
      return text;
    }
    function validTime(value) {
      const match = String(value || "").trim().match(/^(\\d{1,2})[:：](\\d{1,2})(?:[:：](\\d{1,2}))?$/);
      if (!match) return false;
      const h = Number(match[1]), m = Number(match[2]), s = Number(match[3] || 0);
      return h >= 0 && h <= 23 && m >= 0 && m <= 59 && s >= 0 && s <= 59;
    }
    function mediaPathMatchesType(value, type) {
      const text = String(value || "").toLowerCase();
      if (/^https?:\\/\\//.test(text) || /^sample:\\/\\//.test(text)) return true;
      if (type === "video") return /\\.(mp4|mov|webm)$/.test(text);
      if (type === "sticker") return /\\.(gif|webp|png|jpg|jpeg)$/.test(text);
      if (type === "image") return /\\.(jpg|jpeg|png|webp)$/.test(text);
      return true;
    }
    function pad2(value) {
      return String(value).padStart(2, "0");
    }
    function escapeAttr(value) { return String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;"); }
    function escapeHtmlJs(value) { return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;"); }
    async function postJson(url, data) {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      return response.json();
    }
    async function getJson(url) {
      const response = await fetch(url);
      return response.json();
    }
    async function postForm(url, data) {
      const response = await fetch(url, { method: "POST", body: data });
      return response.json();
    }
    function setStatus(message, error = false) {
      const el = document.getElementById("status");
      el.textContent = message || "";
      el.className = error ? "status error" : "status";
    }
    function markDirty(message = "有修改，正在自动保存预览内容") {
      dirty = true;
      window.__v2PreviewDirty = true;
      saveFailed = false;
      if (libraryItem) {
        libraryUnsavedChanges = true;
        setStatus("文案库预览有修改，正在自动保存本次预览；不会覆盖原文案。确认创建时可选择覆盖、另存或仅本次使用。");
        scheduleAutoSave();
        return;
      }
      setStatus(message);
      scheduleAutoSave();
    }
    function scheduleAutoSave() {
      if (autoSaveTimer) clearTimeout(autoSaveTimer);
      autoSaveTimer = setTimeout(async () => {
        autoSaveTimer = null;
        if (!dirty) return;
        await savePreview({ auto: true });
      }, 900);
    }
    function openConsole(resultOrUrl) {
      const target = typeof resultOrUrl === "string" ? resultOrUrl : (resultOrUrl?.consoleUrl || consoleUrl);
      if (!target) return setStatus("没有控制台地址，无法自动返回。请从 2.0 控制台重新打开预览页。", true);
      if (typeof resultOrUrl === "object" && resultOrUrl?.focusedConsole) {
        setStatus("已切回控制台；当前预览页已保留。");
        return;
      }
      setStatus("当前预览页已保留；请手动切回原控制台标签页。");
    }
    function todayMonthDay() {
      return dateOffsetMonthDay(0);
    }
    function currentClock() {
      const now = new Date();
      return pad2(now.getHours()) + ":" + pad2(now.getMinutes()) + ":" + pad2(now.getSeconds());
    }
    function dateOffsetMonthDay(offsetDays) {
      const now = new Date();
      now.setDate(now.getDate() + Number(offsetDays || 0));
      return (now.getMonth() + 1) + "/" + now.getDate();
    }
    function formatTime(value) {
      if (!value) return "";
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return value;
      return pad2(date.getHours()) + ":" + pad2(date.getMinutes()) + ":" + pad2(date.getSeconds());
    }
  </script>
</body>
</html>`;
}

async function readJsonBody(req) {
  const raw = await readRawBody(req);
  const text = raw.toString("utf8");
  return text ? JSON.parse(text) : {};
}

async function loadPreviewPageMeta(runDir, state) {
  const report = await readJsonIfExists(path.join(runDir, "console-generate-report.json"));
  const preciseTuoReport = await readJsonIfExists(path.join(runDir, "precise-tuo-report.json"));
  const diagnostics = await readJsonIfExists(path.join(runDir, "collect-diagnostics.json"));
  const librarySource = await readJsonIfExists(path.join(runDir, "library-source.json"));
  const libraryMeta = await readJsonIfExists(path.join(runDir, "library-meta.json"));
  const robotStrategy = normalizeRobotStrategy(
    librarySource.robotStrategy
    || report.robotStrategy
    || libraryMeta.settingsSnapshot?.robotStrategy
  ) || (hasPreciseTuoReport(preciseTuoReport, report) ? "precise" : "");
  const libraryRecord = librarySource.id ? librarySource : libraryMeta;
  const libraryItem = libraryRecord.id ? {
    id: libraryRecord.id,
    name: libraryRecord.name || "",
    taskCount: libraryRecord.taskCount || 0
  } : null;
  const libraryDefaultDate = String(librarySource.defaultDate || "").trim();
  return {
    runId: path.basename(path.resolve(runDir)),
    libraryItem,
    libraryDateNotice: libraryItem && libraryDefaultDate
      ? `已按今天 ${libraryDefaultDate} 更新文案库预览日期；原文案库不会被覆盖。请确认日期无误后再创建。`
      : "",
    robotStrategy,
    defaultDate: report.readRange?.baseSendDate || "",
    rangeLabel: report.readRange?.label || (report.readRange?.mode === "full" ? "全文读取" : ""),
    rawEventCount: report.rawEventCount ?? diagnostics.collectedEventCount,
    previewTaskCount: report.previewTaskCount ?? state?.tasks?.length,
    preciseTuoRosterOptions: Array.isArray(preciseTuoReport.rosterOptions)
      ? preciseTuoReport.rosterOptions
      : (Array.isArray(report.preciseTuo?.rosterOptions) ? report.preciseTuo.rosterOptions : [])
  };
}

function normalizePreviewTasksForRobotStrategy(tasks, robotStrategy = "") {
  const strategy = normalizeRobotStrategy(robotStrategy);
  if (strategy === "precise") return tasks;
  if (!strategy) return tasks;
  return (Array.isArray(tasks) ? tasks : []).map((task) => {
    if (task?.role !== "tuo" || !task?.tuoAssignment) return task;
    const next = { ...task };
    delete next.tuoAssignment;
    return next;
  });
}

function normalizeRobotStrategy(value) {
  const strategy = String(value || "").trim();
  return ["random", "fixed", "precise"].includes(strategy) ? strategy : "";
}

function hasPreciseTuoReport(preciseTuoReport = {}, report = {}) {
  return Boolean(
    preciseTuoReport.assignedCount
    || preciseTuoReport.tuoTaskCount
    || (Array.isArray(preciseTuoReport.rosterOptions) && preciseTuoReport.rosterOptions.length)
    || report.preciseTuo?.assignedCount
    || report.preciseTuo?.tuoTaskCount
  );
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function readRawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function savePreviewDraft(runDir, tasks) {
  const draftPath = path.join(runDir, "preview-draft.json");
  await fs.writeFile(draftPath, JSON.stringify(Array.isArray(tasks) ? tasks : [], null, 2), "utf8");
  return draftPath;
}

async function saveUploadedMedia(req, runDir) {
  const parsed = parseMultipartFormData(await readRawBody(req), req.headers["content-type"] || "");
  const file = parsed.files[0];
  if (!file?.body?.length) {
    throw new Error("没有收到素材文件。");
  }
  const type = String(parsed.fields.type || "").trim();
  const extension = normalizedMediaExtension(file.filename, type);
  if (!extension) {
    throw new Error(`素材类型不匹配：${type || "未知"} / ${file.filename || ""}`);
  }
  const cacheDir = path.join(runDir, "manual-media-cache");
  await fs.mkdir(cacheDir, { recursive: true });
  const base = sanitizeFilename(path.basename(file.filename || `media${extension}`, path.extname(file.filename || ""))) || "media";
  const hash = crypto.createHash("sha1").update(file.body).digest("hex").slice(0, 10);
  const localPath = path.join(cacheDir, `${Date.now()}-${hash}-${base}${extension}`);
  await fs.writeFile(localPath, file.body);
  return {
    path: localPath,
    previewUrl: `/api/media-preview?path=${encodeURIComponent(localPath)}`,
    size: file.body.length
  };
}

function parseMultipartFormData(buffer, contentType) {
  const boundaryMatch = String(contentType || "").match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!boundaryMatch) throw new Error("上传请求缺少 boundary。");
  const boundary = Buffer.from(`--${boundaryMatch[1] || boundaryMatch[2]}`);
  const fields = {};
  const files = [];
  let offset = buffer.indexOf(boundary);
  while (offset >= 0) {
    const next = buffer.indexOf(boundary, offset + boundary.length);
    if (next < 0) break;
    let part = buffer.subarray(offset + boundary.length, next);
    if (part.subarray(0, 2).toString() === "--") break;
    if (part.subarray(0, 2).toString() === "\r\n") part = part.subarray(2);
    if (part.subarray(-2).toString() === "\r\n") part = part.subarray(0, -2);
    const headerEnd = part.indexOf(Buffer.from("\r\n\r\n"));
    if (headerEnd > 0) {
      const headerText = part.subarray(0, headerEnd).toString("utf8");
      const body = part.subarray(headerEnd + 4);
      const disposition = headerText.match(/content-disposition:[^\n]+/i)?.[0] || "";
      const name = disposition.match(/name="([^"]+)"/i)?.[1] || "";
      const filename = disposition.match(/filename="([^"]*)"/i)?.[1] || "";
      if (filename) files.push({ name, filename, body });
      else if (name) fields[name] = body.toString("utf8");
    }
    offset = next;
  }
  return { fields, files };
}

async function sendMediaPreview(req, res, mediaPath) {
  const filePath = String(mediaPath || "").trim();
  if (!filePath || /^[a-z]+:\/\//i.test(filePath)) {
    sendJson(res, 400, { ok: false, error: "只能预览本地素材路径。" });
    return;
  }
  let stat;
  try {
    stat = await fs.stat(filePath);
  } catch {
    sendJson(res, 404, { ok: false, error: "素材不存在。" });
    return;
  }
  if (!stat.isFile()) {
    sendJson(res, 400, { ok: false, error: "素材路径不是文件。" });
    return;
  }
  res.writeHead(200, {
    "Content-Type": mediaContentType(filePath),
    "Content-Length": stat.size,
    "Cache-Control": "no-store"
  });
  createReadStream(filePath).pipe(res);
}

async function mediaStatus(mediaPath) {
  const filePath = String(mediaPath || "").trim();
  if (!filePath) return { ok: false, message: "未选择素材" };
  if (/^(blob:|image-blob:)/i.test(filePath)) return { ok: false, message: "浏览器临时素材地址，需重新生成预览或更换成本地文件" };
  if (/^data:/i.test(filePath)) return { ok: true, message: "内嵌素材可用" };
  if (/^https?:\/\//i.test(filePath)) {
    return { ok: false, message: "远程地址未落地，保存时会尝试下载到本地 media-cache" };
  }
  if (/^sample:\/\//i.test(filePath)) {
    return { ok: true, message: "测试素材可用" };
  }
  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile() || stat.size <= 0) return { ok: false, message: "素材文件无效" };
    return { ok: true, message: `本地素材可用（${Math.ceil(stat.size / 1024)}KB）` };
  } catch {
    return { ok: false, message: "素材不存在" };
  }
}

function normalizedMediaExtension(filename, type) {
  const ext = path.extname(String(filename || "")).toLowerCase();
  if (type === "video") return [".mp4", ".mov", ".webm"].includes(ext) ? ext : "";
  if (type === "sticker") return [".gif", ".webp", ".png", ".jpg", ".jpeg"].includes(ext) ? ext : "";
  if (type === "image") return [".jpg", ".jpeg", ".png", ".webp", ".gif"].includes(ext) ? ext : "";
  return [".jpg", ".jpeg", ".png", ".webp", ".gif", ".mp4", ".mov", ".webm"].includes(ext) ? ext : "";
}

function mediaContentType(filename) {
  const ext = path.extname(String(filename || "")).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  if (ext === ".gif") return "image/gif";
  if (ext === ".mp4") return "video/mp4";
  if (ext === ".mov") return "video/quicktime";
  if (ext === ".webm") return "video/webm";
  return "application/octet-stream";
}

function sanitizeFilename(value) {
  return String(value || "").replace(/[^\w.-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}

function sendHtml(res, html) {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(html);
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload, null, 2));
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

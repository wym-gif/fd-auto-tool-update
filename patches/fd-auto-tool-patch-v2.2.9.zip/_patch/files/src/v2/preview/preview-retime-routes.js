import { retimePreviewTasks } from "../time/preview-retime.js";

export function buildPreviewRetimeResponse(body = {}) {
  const intervalError = validatePreviewRetimeIntervals(body.intervals || {}, body.endTime);
  if (intervalError) throw new Error(intervalError);
  const result = retimePreviewTasks(Array.isArray(body.tasks) ? body.tasks : [], {
    startMode: body.startMode,
    startTime: body.startTime,
    endTime: body.endTime,
    startDate: body.startDate,
    intervals: body.intervals || {}
  });
  return {
    ok: true,
    tasks: result.tasks,
    diagnostics: result.diagnostics || [],
    gaps: result.gaps || [],
    startMode: result.startMode || "normal",
    startEstimate: result.startEstimate || null
  };
}

export function validatePreviewRetimeIntervals(intervals = {}, endTime = "") {
  const allowOpenMax = String(endTime || "").trim() !== "";
  for (const interval of Object.values(intervals || {})) {
    if (!interval || typeof interval !== "object") continue;
    const min = String(interval.min ?? "").trim();
    const max = String(interval.max ?? "").trim();
    if (!min && !max) continue;
    if (!min && max) return "请先填写间隔下限。";
    if (!/^\d+$/.test(min) || Number(min) <= 0 || (max && (!/^\d+$/.test(max) || Number(max) <= 0))) {
      return "自定义间隔只能填写正整数秒数。";
    }
    if (!max && !allowOpenMax) return "请填写间隔上限，或填写结束时间。";
    if (max && Number(min) > Number(max)) return "自定义间隔的最短不能大于最长。";
  }
  return "";
}

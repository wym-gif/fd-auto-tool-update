export const PREVIEW_TASK_REQUIRED_FIELDS = [
  "sourceId",
  "sourceText",
  "role",
  "speaker",
  "date",
  "time",
  "type",
  "text",
  "mediaPath",
  "skip",
  "order",
  "interactionGroup",
  "continueMarker",
  "cleanSpeaker"
];

export const PREVIEW_TASK_TYPES = new Set(["text", "image", "sticker", "video"]);
export const PREVIEW_TASK_ROLES = new Set(["douma", "tuo"]);

export function createPreviewTask(fields = {}) {
  const task = {
    sourceId: "",
    sourceText: "",
    role: "",
    speaker: "",
    date: "",
    time: "",
    type: "text",
    text: "",
    mediaPath: "",
    skip: false,
    order: 0,
    interactionGroup: "",
    continueMarker: false,
    cleanSpeaker: "",
    ...fields
  };
  validatePreviewTaskShape(task);
  return task;
}

export function validatePreviewTaskShape(task) {
  for (const field of PREVIEW_TASK_REQUIRED_FIELDS) {
    if (!(field in Object(task))) {
      throw new Error(`PreviewTask 缺少字段：${field}`);
    }
  }
  if (!PREVIEW_TASK_ROLES.has(task.role)) {
    throw new Error(`PreviewTask 角色无效：${task.role}`);
  }
  if (!PREVIEW_TASK_TYPES.has(task.type)) {
    throw new Error(`PreviewTask 类型无效：${task.type}`);
  }
  if (task.type === "text" && typeof task.text !== "string") {
    throw new Error("PreviewTask 文本内容必须是字符串");
  }
  if (task.type !== "text" && typeof task.mediaPath !== "string") {
    throw new Error("PreviewTask 媒体路径必须是字符串");
  }
  return true;
}

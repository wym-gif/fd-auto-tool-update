import fs from "node:fs/promises";
import path from "node:path";
import { assertCmsAdapterShape, createFakeCmsAdapter } from "./cms-adapter.js";
import { findLatestV2DryRunSource, runCreateDryRun } from "./create-plan.js";

export async function runCreateRunner(runDir, options = {}) {
  const dryRun = options.dryRunResult || await runCreateDryRun(runDir, options);
  const defaultAdapter = options.adapter || createFakeCmsAdapter();
  const adapterForTask = typeof options.adapterForTask === "function"
    ? options.adapterForTask
    : () => defaultAdapter;
  const actionCursors = new Map();
  const adapterActions = [];
  const allowRealSubmit = options.allowRealSubmit === true;
  const plan = (dryRun.plan || []).map((item) => ({ ...item }));
  const runtimeScheduleEvents = [];
  let expiredScheduleCount = 0;
  const logs = [
    "2.0 CMS 创建执行骨架",
    "",
    "创建执行骨架来源：preview.json -> create-preflight -> create-plan",
    `预览总数：${dryRun.total}`,
    `跳过不发：${dryRun.skipped}`,
    `待创建：${dryRun.createCount}`,
    `真实提交：${allowRealSubmit ? "允许" : "关闭"}`,
    ""
  ];
  const completed = [];

  for (let planIndex = 0; planIndex < plan.length; planIndex += 1) {
    const item = plan[planIndex];
    let itemDone = false;
    while (!itemDone) {
      try {
        await checkpoint(options.control, `准备创建：${planIndex + 1}/${plan.length} / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.time || ""} / ${item.type || ""}`);
        const adapter = adapterForTask(item);
        assertCmsAdapterShape(adapter);
        collectNewAdapterActions(adapter, actionCursors, adapterActions);
        if (typeof options.validateTaskBinding === "function") {
          const binding = await options.validateTaskBinding(item, adapter);
          if (binding) {
            logs.push(`第 ${item.index} 条：${roleLabel(item.role)} 使用第 ${binding.pageIndex || "?"} 个云中客创建页；runId=${binding.runId || ""}`);
            await checkpoint(options.control, `第 ${item.index} 条页面校验通过：${roleLabel(item.role)} -> ${binding.roleLabel || roleLabel(item.role)}页面（第 ${binding.pageIndex || "?"} 页）`);
          }
        }
        await checkpoint(options.control, `第 ${item.index} 条开始前`);
        if (typeof adapter.beforeTask === "function") {
          logs.push(`第 ${item.index} 条：清理上一条残留`);
          await runTimedTaskStep(item, options, {
            checkBeforeAction: false,
            waiting: "正在等待 CMS 页面可编辑",
            logLabel: "等待 CMS 页面可编辑",
            suggestion: "请确认云中客创建页没有弹窗遮挡，页面仍停留在创建任务页，并且网络正常。",
            action: () => adapter.beforeTask(item, { completedCount: completed.length })
          });
        }
        logs.push(`第 ${item.index} 条：选择角色/机器人`);
        await runTimedTaskStep(item, options, {
          checkBeforeAction: false,
          waiting: "正在选择角色/机器人",
          logLabel: "选择角色/机器人",
          suggestion: "请确认托/豆妈页面绑定正确，当前页面已选好分组和机器人。",
          action: () => adapter.selectRole(item)
        });
        if (typeof adapter.setScheduleTime === "function") {
          logs.push(`第 ${item.index} 条：设置发送时间 ${item.date || "空"} ${item.time || "空"}`);
          const scheduleResult = await runTimedTaskStep(item, options, {
            checkBeforeAction: false,
            waiting: "正在设置时间",
            logLabel: "设置发送时间",
            suggestion: "请确认云中客创建页的定时发送控件可见、未被弹窗遮挡，并检查任务时间是否有效。",
            action: () => adapter.setScheduleTime(item)
          });
          if (scheduleResult) {
            logs.push(formatCmsScheduleSetLog(item, scheduleResult));
          }
        }

        if (item.type === "text") {
          logs.push(`第 ${item.index} 条：文本校验`);
          await checkpoint(options.control, `第 ${item.index} 条文本填入前`);
          await runTimedTaskStep(item, options, {
            waiting: "正在填写内容",
            logLabel: "填写正文",
            suggestion: "请确认云中客文本编辑框可见且没有弹窗遮挡。",
            action: () => adapter.fillText(item)
          });
        } else {
          logs.push(`第 ${item.index} 条：媒体上传`);
          await checkpoint(options.control, `第 ${item.index} 条上传前`);
          await runTimedTaskStep(item, options, {
            waiting: "正在上传/填写内容",
            logLabel: "上传素材",
            suggestion: "请确认素材文件存在、云中客上传控件可见，且页面没有弹窗遮挡。",
            action: () => adapter.uploadMedia(item)
          });
          logs.push(`第 ${item.index} 条：等待极速就绪`);
          await runTimedTaskStep(item, options, {
            waiting: "正在等待素材极速就绪",
            logLabel: "等待素材极速就绪",
            timeoutMs: options.mediaReadyTimeoutMs || options.taskStepTimeoutMs || 90000,
            suggestion: "请确认素材上传成功，云中客页面出现预览且极速状态变绿；如果素材过大或网络慢，请重新上传或稍后再试。",
            action: () => adapter.waitMediaReady(item)
          });
        }

        if (allowRealSubmit) {
          logs.push(`第 ${item.index} 条：提交`);
          await checkpoint(options.control, `第 ${item.index} 条点击提交前`);
          await checkpoint(options.control, `第 ${item.index} 条点击执行发送`);
          const submitResult = await runTimedTaskStep(item, options, {
            waiting: "正在等待确认弹窗/确认创建",
            logLabel: "确认创建",
            timeoutMs: options.submitStepTimeoutMs || options.submitSuccessTimeoutMs || options.taskStepTimeoutMs || 60000,
            suggestion: "请查看云中客是否弹出确认框、过期定时提示或机器人不在群提示；如果页面卡住，请手动关闭异常弹窗后重试。",
            action: () => adapter.submit(item)
          });
          completed.push({ ...item, submitted: true });
          await checkpoint(options.control, `第 ${item.index} 条创建成功：${planIndex + 1}/${plan.length} / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.time || ""} / ${item.type || ""}`);
          if (submitResult?.expiredScheduleConfirmed) {
            expiredScheduleCount += 1;
            const limit = Math.max(1, Number(options.maxExpiredScheduleAdjustments || 3));
            const now = resolveRuntimeNow(options);
            const adjusted = adjustRemainingScheduleAfterExpired(plan, planIndex, now, options);
            runtimeScheduleEvents.push({
              event: "expired_schedule_confirmed",
              taskIndex: item.index,
              role: item.role,
              speaker: item.speaker,
              originalDate: item.date || "",
              originalTime: submitResult.originalTime || submitResult.expiredSchedule?.originalTime || item.time || "",
              immediateAt: dateTimeForLog(now),
              adjustedRange: adjusted.range,
              startTime: adjusted.startTime,
              intervalRules: adjusted.intervalRules,
              adjustedTasks: adjusted.adjustedTasks,
              dialogText: submitResult.dialogText || submitResult.expiredSchedule?.dialogText || ""
            });
            logs.push(`第 ${item.index} 条：CMS 提示定时时间已过期，原时间=${item.date || ""} ${submitResult.originalTime || item.time || ""}，已点击“是”改成立即执行。`);
            if (adjusted.adjustedTasks.length) {
              logs.push(`后续第 ${adjusted.range.first} 条到第 ${adjusted.range.last} 条已从当前时间 ${adjusted.startTime} 重新顺延；使用间隔规则：${formatIntervalRules(adjusted.intervalRules)}。`);
              for (const detail of adjusted.adjustedTasks) {
                logs.push(formatRuntimeScheduleAdjustment(detail));
              }
            } else {
              logs.push("后续没有未创建任务，不需要重新顺延。");
            }
            await saveRuntimeScheduleOutputs(runDir, {
              runDir,
              previewPath: dryRun.previewPath,
              adjustedAt: now.toISOString(),
              events: runtimeScheduleEvents,
              plan
            });
            if (expiredScheduleCount >= limit) {
              throw new Error(`连续 ${expiredScheduleCount} 次遇到过期定时弹窗，已停止，避免一直改成立即执行。请检查控制台时间设置。`);
            }
          } else {
            expiredScheduleCount = 0;
          }
        } else {
          await checkpoint(options.control, `第 ${item.index} 条点击执行发送前`);
          logs.push(`第 ${item.index} 条：提交前停止`);
          completed.push({ ...item, submitted: false });
        }
        collectNewAdapterActions(adapter, actionCursors, adapterActions);
        itemDone = true;
      } catch (error) {
        const resumeDecision = handleResumeFromIndexDecision(error, item, plan, planIndex, options, logs);
        if (resumeDecision === "retry") continue;
        if (resumeDecision && Number.isInteger(resumeDecision.nextPlanIndex)) {
          planIndex = resumeDecision.nextPlanIndex;
          itemDone = true;
          continue;
        }
        const decision = await handleTaskErrorDecision(error, item, planIndex, plan.length, options, logs);
        if (decision === "retry") {
          logs.push(`第 ${item.index} 条：人工选择重试当前条。`);
          continue;
        }
        if (decision === "skip") {
          logs.push(`第 ${item.index} 条：人工选择跳过当前条。原因：${error?.message || String(error)}`);
          completed.push({ ...item, submitted: false, skippedAfterError: true, error: error?.message || String(error) });
          itemDone = true;
          continue;
        }
        throw error;
      }
    }
  }

  logs.push("");
  logs.push(allowRealSubmit
    ? "执行骨架完成：已按 adapter 提交。"
    : "执行骨架完成：默认 dry-run，没有真实提交。");

  const result = {
    ok: true,
    source: dryRun.source,
    previewPath: dryRun.previewPath,
    runDir,
    total: dryRun.total,
    skipped: dryRun.skipped,
    createCount: dryRun.createCount,
    allowRealSubmit,
    completed,
    runtimeScheduleEvents,
    adjustedPlan: plan,
    adapterActions,
    log: logs.join("\n")
  };
  await saveRunnerOutputs(runDir, result);
  return result;
}

export async function findLatestV2RunnerSource(runsRoot) {
  return findLatestV2DryRunSource(runsRoot);
}

export function buildCreateRunnerReport(result) {
  return [
    result.log,
    "",
    `create-runner.log：${path.join(result.runDir, "create-runner.log")}`,
    `create-runner-actions.json：${path.join(result.runDir, "create-runner-actions.json")}`
  ].join("\n");
}

async function saveRunnerOutputs(runDir, result) {
  await fs.writeFile(path.join(runDir, "create-runner.log"), result.log, "utf8");
  await fs.writeFile(path.join(runDir, "create-runner-actions.json"), JSON.stringify(result.adapterActions, null, 2), "utf8");
  if (result.runtimeScheduleEvents?.length) {
    await saveRuntimeScheduleOutputs(runDir, {
      runDir,
      previewPath: result.previewPath,
      events: result.runtimeScheduleEvents,
      plan: result.adjustedPlan || result.completed
    });
  }
}

function collectNewAdapterActions(adapter, actionCursors, adapterActions) {
  const actions = adapter.actions || [];
  const cursor = actionCursors.get(adapter) || 0;
  if (actions.length > cursor) {
    adapterActions.push(...actions.slice(cursor));
    actionCursors.set(adapter, actions.length);
  }
}

async function checkpoint(control, label) {
  if (!control?.checkpoint) return;
  await control.checkpoint(label);
}

async function runTimedTaskStep(task, options, step) {
  const waiting = step.waiting || step.logLabel || "执行 CMS 动作";
  if (step.checkBeforeAction !== false) {
    await checkpoint(options.control, `第 ${task.index} 条${waiting}`);
  }
  return withTaskStepTimeout(task, options, step.action(), {
    waiting,
    timeoutMs: step.timeoutMs || options.taskStepTimeoutMs || 120000,
    suggestion: step.suggestion || "请确认当前 CMS 页面可操作后重试。"
  });
}

async function handleTaskErrorDecision(error, task, planIndex, totalCount, options, logs) {
  if (shouldBypassManualErrorHandling(error)) throw error;
  if (typeof options.control?.handleTaskError !== "function") throw error;
  const decision = await options.control.handleTaskError({
    task,
    planIndex,
    totalCount,
    error,
    message: error?.message || String(error)
  });
  if (decision === "retry" || decision === "skip") return decision;
  if (decision === "stop") {
    throw new Error(`用户选择停止本轮，停在第 ${task.index} 条。原始错误：${error?.message || String(error)}`);
  }
  logs.push(`第 ${task.index} 条：人工处理返回未知选择 ${decision || "空"}，按停止处理。`);
  throw error;
}

function handleResumeFromIndexDecision(error, task, plan, planIndex, options, logs) {
  if (error?.code !== "resume_from_index") return null;
  const targetIndex = Number(error.targetIndex || 0);
  if (!targetIndex) return null;
  if (typeof options.control?.clearResumeFromIndex === "function") {
    options.control.clearResumeFromIndex(targetIndex);
  }
  const targetPlanIndex = plan.findIndex((entry) => Number(entry.index) >= targetIndex);
  if (targetPlanIndex < 0) {
    logs.push(`人工选择从第 ${targetIndex} 条继续，但后面没有待创建任务，本轮结束。`);
    return { nextPlanIndex: plan.length - 1 };
  }
  if (targetPlanIndex <= planIndex) {
    logs.push(`人工选择从第 ${targetIndex} 条继续，重新开始第 ${task.index} 条。`);
    return "retry";
  }
  logs.push(`人工选择从第 ${targetIndex} 条继续，跳到第 ${plan[targetPlanIndex].index} 条。`);
  return { nextPlanIndex: targetPlanIndex - 1 };
}

function shouldBypassManualErrorHandling(error) {
  const message = error?.message || String(error || "");
  return error?.code === "resume_from_index"
    || /用户已停止|已停止，后台停在检查点|控制台后台服务已断开/.test(message);
}

async function withTaskStepTimeout(task, options, promise, details = {}) {
  const timeoutMs = Math.max(1000, Number(details.timeoutMs || 120000));
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          reject(new Error(formatTaskStepTimeout(task, options, details, timeoutMs)));
        }, timeoutMs);
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function formatTaskStepTimeout(task, options, details, timeoutMs) {
  const role = roleLabel(task.role);
  return [
    `第 ${task.index} 条 ${role} 任务超时。`,
    `当前 role=${task.role || ""}（${role}）。`,
    `当前页面=${role}页面。`,
    `当前等待=${details.waiting || "CMS 页面响应"}。`,
    `已等待=${Math.round(timeoutMs / 1000)} 秒。`,
    `建议处理：${details.suggestion || "请确认当前 CMS 页面可操作后重试。"}`
  ].join(" ");
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "未知角色";
}

function adjustRemainingScheduleAfterExpired(plan, currentPlanIndex, now, options = {}) {
  const current = plan[currentPlanIndex];
  const remaining = plan.slice(currentPlanIndex + 1);
  const intervalRules = describeIntervalRules(options);
  const nowSeconds = secondsSinceLocalMidnight(now);
  if (!remaining.length) {
    return { range: { first: null, last: null }, startTime: dateTimeForLog(now), intervalRules, adjustedTasks: [] };
  }
  let cursorSeconds = nowSeconds;
  const base = new Date(now);
  let previous = current;
  const adjustedTasks = [];
  for (const task of remaining) {
    const gap = gapBetweenRuntimeTasks(previous, task, options);
    const candidateSeconds = cursorSeconds + gap;
    const originalSeconds = absoluteSecondsFromTaskDateTime(task, base);
    const shouldKeepOriginal = originalSeconds !== null && originalSeconds > nowSeconds && originalSeconds >= candidateSeconds;
    const nextAvailable = dateTimeFromAbsoluteSeconds(base, candidateSeconds);
    cursorSeconds = shouldKeepOriginal ? originalSeconds : candidateSeconds;
    const adjustedDateTime = dateTimeFromAbsoluteSeconds(base, cursorSeconds);
    const oldDate = task.date || "";
    const oldTime = task.time || "";
    const adjusted = oldDate !== adjustedDateTime.date || oldTime !== adjustedDateTime.time;
    task.date = adjustedDateTime.date;
    task.time = adjustedDateTime.time;
    adjustedTasks.push({
      index: task.index,
      role: task.role,
      speaker: task.speaker,
      type: task.type,
      oldDate,
      oldTime,
      newDate: task.date,
      newTime: task.time,
      gapSeconds: gap,
      nextAvailableDate: nextAvailable.date,
      nextAvailableTime: nextAvailable.time,
      previewExpired: originalSeconds !== null && originalSeconds <= nowSeconds,
      adjusted,
      keptPreviewTime: shouldKeepOriginal,
      reason: runtimeScheduleAdjustmentReason({
        originalSeconds,
        nowSeconds,
        candidateSeconds,
        shouldKeepOriginal
      })
    });
    previous = task;
  }
  return {
    range: { first: remaining[0].index, last: remaining[remaining.length - 1].index },
    startTime: dateTimeForLog(now),
    intervalRules,
    adjustedTasks
  };
}

function gapBetweenRuntimeTasks(prev, next, options = {}) {
  if (!prev || !next) return 0;
  if (sameInteractionGroup(prev, next)) return pickInterval("sameTuo", 20, 45, options);
  if (prev.role !== next.role) return Math.max(120, pickInterval("roleSwitch", 120, 120, options));
  if (isMedia(prev) || isMedia(next)) return pickInterval("media", 30, 50, options);
  if (next.role === "douma") return pickInterval("doumaSame", 45, 45, options);
  if (prev.speaker === next.speaker) return pickInterval("sameTuo", 20, 45, options);
  return pickInterval("differentTuo", 15, 15, options);
}

function runtimeScheduleAdjustmentReason(details = {}) {
  if (details.shouldKeepOriginal) return "preview 时间未过期，且不早于 nextAvailableTime，保留 preview 时间";
  if (details.originalSeconds === null) return "preview 时间无效或缺失，按 nextAvailableTime 顺延";
  if (details.originalSeconds <= details.nowSeconds) return "preview 时间已过期，按 nextAvailableTime 顺延";
  if (details.originalSeconds < details.candidateSeconds) return "preview 时间距离上一条太近，按 nextAvailableTime 顺延";
  return "按 nextAvailableTime 顺延";
}

function formatRuntimeScheduleAdjustment(detail = {}) {
  const previewTime = `${detail.oldDate || ""} ${detail.oldTime || ""}`.trim() || "空";
  const adjustedTime = `${detail.newDate || ""} ${detail.newTime || ""}`.trim() || "空";
  const nextAvailable = `${detail.nextAvailableDate || ""} ${detail.nextAvailableTime || ""}`.trim() || "空";
  return [
    `运行时重排：第 ${detail.index} 条`,
    `原 preview 时间=${previewTime}`,
    `nextAvailableTime=${nextAvailable}`,
    `是否过期=${detail.previewExpired ? "是" : "否"}`,
    `是否调整=${detail.adjusted ? "是" : "否"}`,
    `调整后时间=${adjustedTime}`,
    `原因=${detail.reason || ""}`
  ].join("；");
}

function formatCmsScheduleSetLog(item, result = {}) {
  return [
    `第 ${item.index} 条：CMS 定时已设置`,
    `preview 日期=${item.date || ""}`,
    `preview 时间=${item.time || ""}`,
    result.todayDate ? `今天日期=${result.todayDate}` : "",
    Number.isFinite(Number(result.dateOffsetDays)) ? `日期差=${Number(result.dateOffsetDays)}天` : "",
    `CMS 选择=${result.selectedDateText || result.optionText || result.date || ""}`,
    `CMS 填写时间=${result.time || item.time || ""}`
  ].filter(Boolean).join("；");
}

function pickInterval(key, min, max, options = {}) {
  const custom = options.intervals?.[key];
  const low = Number.isFinite(Number(custom?.min)) ? Number(custom.min) : min;
  const high = Number.isFinite(Number(custom?.max)) ? Number(custom.max) : max;
  if (options.randomizeRuntimeSchedule === true || options.randomize === true) {
    const rnd = typeof options.random === "function" ? options.random() : Math.random();
    return Math.round(low + Math.max(0, Math.min(1, rnd)) * (high - low));
  }
  return Math.round((low + high) / 2);
}

function describeIntervalRules(options = {}) {
  return {
    mode: options.scheduleMode || "doc",
    sameTuo: describeInterval("sameTuo", 20, 45, options),
    differentTuo: describeInterval("differentTuo", 15, 15, options),
    media: describeInterval("media", 30, 50, options),
    doumaSame: describeInterval("doumaSame", 45, 45, options),
    roleSwitch: describeInterval("roleSwitch", 120, 120, options)
  };
}

function describeInterval(key, min, max, options = {}) {
  const custom = options.intervals?.[key];
  const low = Number.isFinite(Number(custom?.min)) ? Number(custom.min) : min;
  const high = Number.isFinite(Number(custom?.max)) ? Number(custom.max) : max;
  return { min: low, max: high, custom: Boolean(custom) };
}

function formatIntervalRules(rules = {}) {
  const text = (key, label) => {
    const item = rules[key] || {};
    const range = item.min === item.max ? `${item.min}秒` : `${item.min}-${item.max}秒`;
    return `${label}${range}${item.custom ? "(自定义)" : ""}`;
  };
  return [
    `模式=${rules.mode || "doc"}`,
    text("sameTuo", "同托连续"),
    text("differentTuo", "不同托"),
    text("media", "素材附近"),
    text("doumaSame", "豆妈连续"),
    text("roleSwitch", "豆妈/托切换")
  ].join("，");
}

function resolveRuntimeNow(options = {}) {
  if (typeof options.now === "function") return new Date(options.now());
  if (options.now) return new Date(options.now);
  return new Date();
}

function secondsSinceLocalMidnight(date) {
  return date.getHours() * 3600 + date.getMinutes() * 60 + date.getSeconds();
}

function absoluteSecondsFromTaskDateTime(task, baseDate) {
  const timeSeconds = timeToSeconds(task?.time);
  if (timeSeconds === null) return null;
  const taskDate = parseTaskMonthDay(task?.date, baseDate);
  if (!taskDate) return timeSeconds;
  const baseMidnight = new Date(baseDate);
  baseMidnight.setHours(0, 0, 0, 0);
  const taskMidnight = new Date(baseDate.getFullYear(), taskDate.month - 1, taskDate.day);
  taskMidnight.setHours(0, 0, 0, 0);
  return Math.round((taskMidnight.getTime() - baseMidnight.getTime()) / 1000) + timeSeconds;
}

function parseTaskMonthDay(value, baseDate) {
  const match = String(value || "").trim().match(/^(\d{1,2})\s*[\/月-]\s*(\d{1,2})(?:日)?$/);
  if (!match) return null;
  const month = Number(match[1]);
  const day = Number(match[2]);
  if (!month || !day) return null;
  return { year: baseDate.getFullYear(), month, day };
}

function timeToSeconds(time) {
  const match = String(time || "").trim().match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  const second = Number(match[3] || 0);
  if (hour > 23 || minute > 59 || second > 59) return null;
  return hour * 3600 + minute * 60 + second;
}

function dateTimeFromAbsoluteSeconds(baseDate, absoluteSeconds) {
  const date = new Date(baseDate);
  date.setHours(0, 0, 0, 0);
  date.setSeconds(Math.round(Number(absoluteSeconds) || 0));
  return {
    date: `${date.getMonth() + 1}/${date.getDate()}`,
    time: secondsToClock(secondsSinceLocalMidnight(date))
  };
}

function secondsToClock(totalSeconds) {
  const seconds = ((Math.round(Number(totalSeconds) || 0) % 86400) + 86400) % 86400;
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(Math.floor(seconds / 3600))}:${pad(Math.floor((seconds % 3600) / 60))}:${pad(seconds % 60)}`;
}

function monthDayWithOffset(baseDate, offsetDays) {
  const date = new Date(baseDate);
  date.setDate(date.getDate() + offsetDays);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function dateTimeForLog(date) {
  return `${monthDayWithOffset(date, 0)} ${secondsToClock(secondsSinceLocalMidnight(date))}`;
}

function isMedia(task) {
  return task.type === "image" || task.type === "sticker" || task.type === "video";
}

function sameInteractionGroup(prev, next) {
  return Boolean(prev?.interactionGroup && next?.interactionGroup && prev.interactionGroup === next.interactionGroup);
}

async function saveRuntimeScheduleOutputs(runDir, payload) {
  await fs.writeFile(path.join(runDir, "runtime-schedule.json"), JSON.stringify(payload, null, 2), "utf8");
  await fs.writeFile(path.join(runDir, "adjusted-preview.json"), JSON.stringify(payload.plan || [], null, 2), "utf8");
}

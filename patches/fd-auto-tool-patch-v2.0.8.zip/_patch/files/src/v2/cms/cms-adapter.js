export function createFakeCmsAdapter(options = {}) {
  const actions = [];
  return {
    actions,
    async selectRole(task) {
      actions.push(action("selectRole", task));
    },
    async fillText(task) {
      actions.push(action("fillText", task));
      if (options.failText) throw new Error(`第 ${task.index} 条文本填写失败`);
    },
    async uploadMedia(task) {
      actions.push(action("uploadMedia", task));
      if (options.failMedia) throw new Error(`第 ${task.index} 条媒体上传失败`);
    },
    async waitMediaReady(task) {
      actions.push(action("waitMediaReady", task));
      if (options.mediaReady === false) throw new Error(`第 ${task.index} 条媒体没有就绪`);
    },
    async submit(task) {
      actions.push(action("submit", task));
      if (options.failSubmit) throw new Error(`第 ${task.index} 条提交失败`);
    }
  };
}

export function assertCmsAdapterShape(adapter) {
  for (const name of ["selectRole", "fillText", "uploadMedia", "waitMediaReady", "submit"]) {
    if (typeof adapter?.[name] !== "function") {
      throw new Error(`CMS adapter 缺少动作实现：${name}`);
    }
  }
  return true;
}

function action(name, task) {
  return {
    name,
    index: task.index,
    role: task.role,
    speaker: task.speaker,
    date: task.date,
    time: task.time,
    type: task.type,
    sourceId: task.sourceId
  };
}

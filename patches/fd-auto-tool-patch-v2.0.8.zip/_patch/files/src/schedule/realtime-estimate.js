export const CUSTOM_INTERVAL_KEYS = ["differentTuo", "sameTuo", "doumaSame", "roleSwitch"];

export function isEstimateTask(task) {
  if (!task || task.__skip) return false;
  return ["text", "image", "sticker", "video"].includes(task.type);
}

export function estimateRealtimeGaps(tasks, config = {}) {
  const gaps = [];
  for (let index = 1; index < tasks.length; index += 1) {
    gaps.push(estimateGapBetweenTasks(tasks[index - 1], tasks[index], config));
  }
  return gaps;
}

export function estimateGapBetweenTasks(prev, next, config = {}) {
  if (!prev || !next) return 0;
  if (prev.role !== next.role) return Math.max(120, estimateIntervalSeconds(config, "roleSwitch", 120));
  if (next.role === "douma") return estimateIntervalSeconds(config, "doumaSame", 45);
  if (prev.speaker === next.speaker) return estimateIntervalSeconds(config, "sameTuo", 32);
  return estimateIntervalSeconds(config, "differentTuo", 35);
}

export function estimateIntervalSeconds(config, key, fallback) {
  const item = config?.customIntervals?.[key] || {};
  const min = intervalValueOrNull(item.min);
  const max = intervalValueOrNull(item.max);
  if (min !== null && max !== null) return Math.round((min + max) / 2);
  if (min !== null) return min;
  if (max !== null) return max;
  return fallback;
}

export function intervalValueOrNull(value) {
  if (value === "" || value === undefined || value === null) return null;
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? Math.round(number) : null;
}

export function validateServerCustomIntervals(intervals = {}) {
  for (const key of CUSTOM_INTERVAL_KEYS) {
    const item = intervals[key] || {};
    const min = intervalValueOrNull(item.min);
    const max = intervalValueOrNull(item.max);
    if ((item.min !== "" && item.min !== undefined && item.min !== null && min === null) ||
        (item.max !== "" && item.max !== undefined && item.max !== null && max === null)) {
      return "自定义间隔只能填写 0 以上的秒数。";
    }
    if (min !== null && max !== null && max < min) return "自定义间隔的最长时间不能小于最短时间。";
  }
  return "";
}

export function countEstimateRoles(tasks) {
  return tasks.reduce((stats, task) => {
    if (task.role === "douma") stats.douma += 1;
    else if (task.role === "tuo") stats.tuo += 1;
    else stats.other += 1;
    return stats;
  }, { douma: 0, tuo: 0, other: 0 });
}

export function defaultStartTimeAfterLead(config = {}) {
  const leadSeconds = Number(config.realtimeMinLeadSeconds ?? 60);
  const date = new Date(Date.now() + Math.max(1, leadSeconds) * 1000);
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

# 发单工具版本记录

## 未发布

- 发布：2026-10-08 将更新源 `latest.json` 发布为 `2.2.0`，补丁包 `patches/fd-auto-tool-patch-v2.2.0.zip` 可访问；发布前完成补丁构建、临时目录模拟更新和基础代码检查。本次客户端补丁不包含本机运行数据、测试文件或授权总控服务器部署脚本。
- 控制台文案库列表简化右侧操作区：首页每条文案只直接显示“上传共享/更新上传/已共享”“使用”和“更多”，上移/下移收进“更多”菜单，减少按钮横向占用；管理文案库弹窗仍保留完整操作按钮。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "compact preview library|preview library marks shared" tests\v2-console.test.js`；文案库首页“更多”菜单、排序、共享按钮状态和相关 UI 测试通过。
- 授权总控侧边栏移除“退出登录”入口，避免页面出现无实际帮助的按钮；后台退出接口保留，不影响已有登录校验。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `$env:PYTHONPYCACHEPREFIX = Join-Path $env:TEMP 'fd-auto-tool-pycache-check'; python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`、`python -m unittest discover -s tools\server-license -p test_service.py`；授权后台页面静态断言和授权总控 10 项测试通过。
- 文案库共享反馈和授权总控权限补强：控制台点击“上传共享/更新上传”后会在按钮和当前文案行显示上传中、成功或具体失败原因；打开“云端文案”失败时显示授权服务返回的真实原因，不再只显示 `500`。已共享文案未修改时显示“已共享”，本机文案有更新后显示“更新上传”。授权总控设备列表拆成独立操作：待授权设备显示“通过 / 拒绝 / 允许上传”，已授权设备显示“允许上传 / 禁止上传”；“允许上传”只控制上传共享文案资格，下载/使用云端文案仍只要求设备已授权。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\console\server.js src\v2\console\workflow.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "upload and download shared copywriting|shared preview library|marks shared" tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`、`$env:PYTHONPYCACHEPREFIX = Join-Path $env:TEMP 'fd-auto-tool-pycache-check'; python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`、`python -m unittest discover -s tools\server-license -p test_service.py`；控制台共享上传/下载/失败反馈、已共享/更新上传显示、授权总控共享上传独立按钮和授权总控 10 项测试通过。
- 预览页手动补录继续修正插入位置和弹窗操作：选择“当前选中行前”时，补录行时间会按选中行时间往前排；选择“当前选中行后/末尾”时继续往后排。补录弹窗标题栏现在可拖动，右上角改为红色 `X` 关闭按钮，避免和底部“取消”重复。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\preview\preview-page.js tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 --test-name-pattern "manual add|manual batch" tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`；手动补录前插/后插时间、弹窗拖动、红色关闭按钮和预览页全量 44 项测试通过。
- 预览页“手动补一条/批量补录”入口合并为“手动补录”：打开后默认只给 1 行，填写 1 行就是补 1 条，点“再加一行”可补多条；空白行会跳过，提交按钮改为“添加已填写行”。补录弹窗新增分钟/秒递增单位和示例说明，并固定底部按钮、让表格区域独立滚动。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\preview\preview-page.js tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 --test-name-pattern "manual add|manual batch" tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`；手动补录单条/多条、秒级递增、本地素材路径、选中行前插入和预览页全量 44 项测试通过。
- 精准托意图识别补强长期跟买/售后背书话术：出现“这么多年、一直跟着豆妈、老粉/老群友、没踩过雷、售后/小助理处理”等经验型表达时优先打成熟语境，不再因单独出现“姐妹”等词误偏年轻女性；普通年轻口吻仍保持年轻女性匹配。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\tuo\tuo-intent.js tests\v2-precise-tuo.test.js`、`node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`；精准托 19 项测试通过。
- 飞书预览解析修复媒体错挂上一条消息的问题：图片/视频/表情包如果自身带有明确 `collectSpeaker` 和 `collectTime`，且与当前解析段落不一致，会按媒体自己的采集上下文生成任务，不再盲目继承上一条消息的说话人和时间；没有采集上下文的媒体继续沿用原逻辑。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`；固定格式解析 41 项通过。
- 预览页精准托“备选托”推荐顺序修复：每行优先展示该任务分配时保存的 `tuoAssignment.candidates`，再补当前主托和全局名单，避免同一人设下所有行都固定显示全局名单前两个备用托；下拉“更多”仍保留全局名单可手动选择。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\preview\preview-page.js tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 --test-name-pattern "precise tuo speaker|backup picks|candidate" tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`；精准托备选展示、预览页全量 43 项测试通过。
- 飞书预览解析过滤正文里混入的孤立 XML 字段：如 `<priority>-1</priority>`、`<type>51</type>` 这类飞书隐藏结构字段如果夹在普通正文里，会在正文清洗阶段丢弃；完整视频号 XML 仍按视频号任务保留。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`；固定格式解析 40 项通过。
- 预览页新增“批量补录”：可在选中行前/后或末尾一次补多条预览任务，默认带出选中行的角色、说话人、日期和时间，并按每行递增分钟自动排时间；空白行会跳过，补录后仍只保存为预览内容。本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\preview\preview-page.js tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 --test-name-pattern "manual add|manual batch" tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`；单条补录、批量补录、媒体上传、选中行前插入和预览页全量 42 项测试通过。
- 飞书采集和范围定位补强重复/错位处理：同一消息里视觉位置重叠的重复正文块会在采集阶段去重；指定开始/结束位置时，纯文本关键词如果命中同一视觉位置、同一上下文的 DOM 重复块，会自动当成一个边界继续，不再误报“无法唯一定位”。解析层继续保留“文本-媒体-续文”合并兜底；本次不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\feishu\collector.js src\v2\range\locate-range.js src\v2\parser\parse-fixed-format.js tests\v2-feishu-collect.test.js tests\v2-range.test.js tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-range.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`；范围定位 20 项、固定格式解析 39 项、飞书采集 65 项通过。
- 飞书预览解析修复同一消息文本被媒体插队的问题：同一说话人、同一原日期/时间的飞书采集块如果出现“文本-图片/视频/表情-续文”，会把续文并回前一条文本，保留正文里的单独 `-` 行，并把媒体排在完整文本后面；不涉及 CMS 正式创建链路。
- 验证：2026-10-07 在本机运行 `node --check src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`；固定格式解析 39 项通过。
- 精准托备用托兜底改为分散轮换：主托仍优先；需要使用备用托时，先按人设池挑本轮未用过的备用托，再从通用备用池挑本轮未用过的备用托，所有备用托用过一轮后才进入下一轮。这样文案库“重新分配托名单”和正常生成预览时，备用托不会集中卡在少数几个号上；同一互动组仍保持同一个托。
- 验证：2026-10-07 在本机运行 `node --check src\v2\tuo\precise-tuo-assigner.js tests\v2-precise-tuo.test.js`、`node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`、`node --test --test-concurrency=1 tests\v2-preview-library.test.js`、`node --test --test-concurrency=1 --test-name-pattern "preview library|visual page settings" tests\v2-console.test.js`；备用托分散轮换、文案库重分配和控制台相关测试通过。
- 文案库打开预览时支持按当前精准托名单重新分配：当前页面已选择精准托名单时，点击文案库“使用”会提示“重新分配/沿用原托”。选择重新分配只修改本次打开的预览工作副本，不覆盖文案库原件；正文、日期、时间和素材不重新采集，CMS 正式创建仍只读取最终预览结果。
- 验证：2026-10-07 在本机运行 `node --check src\v2\preview\preview-library.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-preview-library.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-preview-library.test.js`、`node --test --test-concurrency=1 --test-name-pattern "preview library|visual page settings" tests\v2-console.test.js`；文案库工作副本精准托重分配和控制台提示测试通过。
- 文案库新增手动共享第一阶段：本机文案库单条文案可点“上传共享/更新上传”，云端文案弹窗可查看同公司共享文案并“下载使用/更新到本机”；共享包会包含预览任务和素材文件，下载后自动恢复成本机可用素材路径。共享接口复用现有授权总控服务器，查看/下载要求设备已授权，上传要求设备额外具备共享上传权限。
- 验证：2026-10-07 在本机运行 `node --check src\v2\license\license-manager.js src\v2\preview\shared-preview-library.js src\v2\preview\preview-library.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-preview-library.test.js tests\v2-console.test.js`、`python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`、`node --test --test-concurrency=1 tests\v2-preview-library.test.js`、`python -m unittest discover -s tools\server-license -p test_service.py`、`node --test --test-concurrency=1 --test-name-pattern "preview library|visual page settings" tests\v2-console.test.js`；文案库打包/导入、授权总控共享接口和控制台共享入口测试通过。
- 预览页“文案有变，重新生成预览”改为页面内确认流程：点击后先显示确认弹窗和状态提示，不再依赖浏览器原生确认框；确认后会立即显示“已收到重新生成请求”，再调出飞书重新读取。文案库来源的预览不再弹浏览器 alert，改为在页面状态区明确提示不能直接重新采集；预览页顶部按钮区允许换行，降低按钮条挤压遮挡内容的概率。
- 验证：2026-09-30 在本机运行 `node --check src\v2\preview\preview-page.js src\v2\tools\test-preview-cli.js tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 --test-name-pattern "regenerate|top action buttons|library preview blocks" tests\v2-preview-store.test.js`；重新生成预览、顶部按钮、文案库拦截和预览自测通过。
- 云中客配置自动套用修复群数据未加载完整时的误判：托/豆妈页面遇到 `群（已选 0/58）`、空列表、暂无数据等状态时，真实云中客页面会先执行浏览器页面刷新再重试；若刷新后仍被旧关键词/旧筛选过滤成空列表，会先清空对应群/机器人关键词或分组筛选，再按当前配置重新设置和勾选。测试页或无法浏览器刷新的页面才退回页面内 `刷新全部机器人&群数据` 兜底；清空后仍找不到可选项才提示“群数据未加载完整”，不再继续走到任务备注导致误报。
- 验证：2026-09-30 在本机运行 `node --check src\v2\cms\cms-config-form-apply.js tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 --test-name-pattern "stale group keyword|browser reloads stale cms group page|stale group data|refreshes incomplete tuo" tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`；云中客配置自动套用浏览器刷新、旧关键词清理、页面内刷新兜底、刷新失败阻断和提示状态测试通过。
- 预览页“文案有变，重新生成预览”改为明确调出飞书文档重新读取：点击后不再先切回控制台，而是后台启动完整 `generatePreview` 流程，由飞书采集页复用/打开目标文档并前置读取；旧预览页提示“正在调出飞书文档并重新读取”，生成完成后会打开新的预览页。
- 验证：2026-09-30 在本机运行 `node --check src\v2\preview\preview-page.js src\v2\console\workflow.js tests\v2-preview-store.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "regenerate|top action buttons|library preview blocks regenerate|v2 console server exposes visual page settings and status" tests\v2-preview-store.test.js tests\v2-console.test.js`；预览页重新生成、顶部按钮、文案库拦截和控制台静态测试通过。
- 控制台“云中客配置 / 配置库”头部增强视觉层级：保留蓝白系统色调，增加浅蓝到浅橙的低饱和渐变、左侧细色条和弱斜纹背景，让配置库区域更显眼但不突兀；列表里的当前使用项取消重复左侧竖线，改为柔和浅蓝选中态。
- 验证：2026-09-30 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 精准托机器人勾选定位修复：输入托名后不再只依赖“托名文本和 checkbox 在同一个 DOM 行里”，改为按目标托名这一行的屏幕高度定位左侧小方框并点击；点击后必须确认 `机器人（已选1/总数）` 且目标行已勾选，失败会清空关键词、重新输入托名并重勾一次。点“执行发送”后如果云中客提示“请选择微信机器人”，也会先按当前托名自动重选一次，第二次仍失败才要求人工处理。
- 验证：2026-09-30 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 --test-name-pattern "real CMS precise robot|formal submit|robot-not-in-group|page config check|missing wechat" tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；真实 CMS submit-before 62 项通过。
- 发布：2026-09-30 将更新源 `latest.json` 发布为 `2.1.10`，补丁包 `patches/fd-auto-tool-patch-v2.1.10.zip` 可访问；发布前完成补丁构建、临时目录模拟更新和基础代码检查。
- 预览页“文案有变，重新生成预览”点击后会立刻显示“正在重新读取飞书并生成预览”，并临时禁用按钮避免重复点击；请求失败会在预览页红字提示。控制台“第一天发单日期”的日期选择框改为短宽度，不再横向撑满。
- 验证：2026-09-30 在本机运行 `node --check src\v2\preview\preview-page.js src\v2\console\server.js tests\v2-preview-store.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "regenerate keeps preview page|library preview blocks regenerate|top action buttons" tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；预览页重新生成按钮反馈、文案库拦截和控制台日期框样式测试通过。
- 控制台“第一天发单日期”改为可点击的日期选择器：页面显示用系统日期控件，提交给后端时继续转成 `10/1` 这类已有格式，旧配置里的 `10/1` 也会自动回显到日期控件；按节奏/天数“范围”读取会保留中间天标题作为换天标记，预览日期按第一天日期自动顺延，不再所有任务都停在同一天。
- 验证：2026-09-30 在本机运行 `node --check src\v2\date\date-rules.js src\v2\range\heading-range.js src\v2\console\server.js tests\v2-heading-range.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-heading-range.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-range.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "heading range|range mode switch|visual page settings" tests\v2-console.test.js`；日期控件、范围换天标记、固定格式解析、范围定位和控制台页面静态测试通过。
- 控制台“按节奏/天数选择”新增“单天 / 范围”切换：单天模式保持原来的“第几天 + 节奏/阶段”选择，可继续选单独节点；范围模式改为选择“开始第几天 / 结束第几天”，自动读取中间整天内容并继续跳过朋友圈，隐藏字段不会串到另一种模式。
- 验证：2026-09-30 在本机运行 `node --check src\v2\range\heading-range.js src\v2\console\settings.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-heading-range.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-heading-range.test.js`、`node --test --test-concurrency=1 --test-name-pattern "heading range|range mode switch|visual page settings" tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "heading day range options" tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-range.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`；标题范围选择、控制台切换、范围定位、固定格式解析和控制台全量测试通过。
- 飞书按节奏/天数读取标题结构前会先等待浏览器标签从 `Docs`、`· Docs`、`飞书云文档` 这类加载态变成真实文档名，或等正文里的文档标题先加载出来；左侧目录只显示 0/1 条但正文已有多个标题时，会继续等待目录补全，超时才提示“左侧目录还没加载完整”，不再把加载未完成误判成“未识别到天数”。
- 验证：2026-09-30 在本机运行 `node --check src\v2\range\heading-range.js tests\v2-heading-range.test.js`、`node --test --test-concurrency=1 tests\v2-heading-range.test.js`、`node --test --test-concurrency=1 tests\v2-range.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`；标题加载等待、正文标题放行、目录残缺等待、范围定位和固定格式解析测试通过。
- 云中客配置自动套用继续增强：托页面也会检查群数量是否明显未加载完整，遇到 `0/58` 这类异常会先刷新再设置；默认全选改为点表头后等待校验、未选中的行逐行补勾并最终复查。控制台时间模式的日期输入改为“第一天发单日期”，解析器支持 `第一天/第二天/第三天/第1天/D1/day1` 这类标题按第一天日期自动顺延，实时跟发只重排时间、不覆盖顺延后的日期。
- 验证：2026-09-30 在本机运行 `node --check src\v2\date\date-rules.js src\v2\range\heading-range.js src\v2\parser\parse-fixed-format.js src\v2\cms\cms-config-form-apply.js src\v2\console\server.js tests\v2-parser-fixed-format.test.js tests\v2-range.test.js tests\v2-cms-config-library.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js tests\v2-range.test.js tests\v2-time.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；云中客自动套用、日期顺延、范围识别、时间排期和控制台静态测试通过。
- 云中客配置自动套用增强真实页面定位：托页面“管理分组”改为按按钮/标签附近的下拉框定位，任务备注改为按“任务备注”文字右侧最近输入框定位；豆妈页面如果检测到群/机器人数量明显未加载完整，会先点击云中客刷新按钮重试，再继续清空分组、填写关键词/分组并勾选。
- 验证：2026-09-30 在本机运行 `node --check src\v2\cms\cms-config-form-apply.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-cms-config-library.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；云中客配置自动套用和控制台页面静态测试通过。
- 控制台云中客配置列表里的“当前使用”标签改为绿色，和蓝色操作按钮区分开。
- 验证：2026-09-30 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台把“云中客配置”从“发单版本”中拆成独立模块：页面上现在是 `2. 发单版本`、`3. 云中客配置`，后续“机器人不在群 / 读取范围 / 时间模式 / 结果和日志”编号顺延，避免云中客配置看起来像发单版本的附属设置。
- 验证：2026-09-30 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 云中客配置自动套用补齐关键词、全选、任务备注和提示状态：关键词模式会先清空对应群/机器人区域的分组筛选再填写关键词；`默认全选` 优先点击表头全选框，失败再逐行兜底并校验勾选结果；任务备注只定位右侧“执行发送设置”里的任务备注输入框；页面半透明提示在设置中保持显示，成功后提示检查确认并回控制台继续，失败时变红显示具体原因并提示人工设置后继续。
- 验证：2026-09-30 在本机运行 `node --check src\v2\cms\cms-config-form-apply.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-cms-config-library.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；云中客配置自动套用和控制台提示测试通过。
- 控制台“云中客配置”区域降低视觉干扰：外层面板、当前配置行、当前使用标签、已使用按钮和自动套用说明改为低饱和白底/浅灰蓝样式，只在真实错误弹窗里保留强提醒色。
- 验证：2026-09-30 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台“云中客配置”改为配置库优先：默认显示已保存配置列表，有配置时可直接在列表点“使用”，右上角“新增配置”才展开托页面/豆妈页面两步表单；保存成功后自动选中新配置并收起表单，避免像白填一遍还要重新设置。
- 验证：2026-09-30 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 云中客配置恢复从“只提示人工设置”改为“先自动套用配置”：进入 CMS 准备后会打开托/豆妈页面并按表单尝试设置分组/关键词、勾选群和机器人、任务备注、多快捷模式和机器人更换方式；云中客页面中间显示半透明进度提示，失败时页面显示红色错误提示，控制台同时弹出明显失败弹窗。自动设置失败不退出流程，仍停在“我已设置好，开始创建任务”等待人工补齐。
- 验证：2026-09-30 在本机运行 `node --check src\v2\cms\cms-config-form-apply.js src\v2\cms\cms-config-restore.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-cms-config-library.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；云中客配置恢复与控制台提示测试通过。
- 修复飞书图片块控件文字被采进预览的问题：独立的“添加图标 / 添加封面”以及合并成两行的“添加图标\n添加封面”会在采集归一化阶段过滤，不再生成额外文字任务，图片本身继续保留。
- 验证：2026-09-30 在本机运行 `node --check src\v2\feishu\collector.js tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 --test-name-pattern "image block chrome|document section title" tests\v2-feishu-collect.test.js`；飞书采集控件文字过滤测试通过。
- 控制台云中客配置卡片列表新增独立滚动区域，配置摘要内容较多时可在列表内滚动查看，不再被面板底部截断。
- 验证：2026-09-30 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台云中客配置表单的豆妈页面改为问题式配置：群和机器人分别询问“是否使用分组”，选择“是”时填写分组名字，选择“否”时填写关键词；群关键词模式默认选择第一个，群分组模式默认全选，机器人仍默认选择 1 个。
- 验证：2026-09-30 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台云中客配置表单的可填写输入框新增本机历史候选：管理分组、精准托分组/机器人、豆妈群/机器人输入内容和任务备注会在失焦或保存配置时记录，下次聚焦输入框可从历史候选中选择。
- 验证：2026-09-29 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台云中客配置表单的豆妈页面把“群聊选择个数：默认全选”和“机器人选择个数：默认 1”改为顶部只读说明，不再显示成可输入框；需要填写的群/机器人查找方式、输入内容和任务备注保留在下方。
- 验证：2026-09-29 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台云中客配置表单的粗略托页面把“多快捷模式：默认开”和“群聊选择个数：默认全选”改为顶部只读说明，不再显示成可输入框；需要填写的管理分组、机器人更换方式和任务备注保留在下方。
- 验证：2026-09-29 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台云中客配置表单不再二次选择托版本，改为只读显示并跟随上方“发单版本”：上方选粗略版时显示粗略托字段，上方选精准版/精准托名单时显示精准托字段，避免上下两处配置不一致。
- 验证：2026-09-29 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台云中客配置表单移除“配置名称”字段，托页面设置只保留业务配置；点击“保存配置”时再弹出名称输入框，用于保存到配置库。
- 验证：2026-09-29 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台云中客配置表单优化为明确的两步流程：去掉顶部两个像 Tab 的步骤框，第一页标题直接显示“托页面设置”，点击“下一页：设置豆妈页面”后第二页“豆妈页面设置”从右侧滑入；“粗略托 / 精准托”单选改为横向不换行显示。
- 验证：2026-09-29 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台“云中客配置”表单从弹窗改为区域内常驻展示：打开控制台即可直接填写托页面/豆妈页面设置，右上角“保存配置”和表单底部“保存配置”都会保存当前表单；空状态提示同步改为“填写上方表单后保存”，避免误以为必须先进入云中客页面。
- 验证：2026-09-29 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态测试通过。
- 控制台“云中客配置”新增两步表单向导：第 1 页填写托页面设置，粗略托包含多快捷默认开、管理分组、机器人更换方式、群聊选择个数和任务备注；精准托包含群包含分组、群聊选择个数、机器人分组和任务备注。第 2 页填写豆妈页面设置，支持群/机器人分别选择“分组”或“关键词”查找方式、选择个数和任务备注。保存后的配置卡片按“托页面 / 豆妈页面”分块展示表单内容，配置库仍支持使用、改名和删除。
- 表单型云中客配置不再强依赖页面自动读取摘要；恢复时会打开/切换到云中客页面等待人工确认。如果按表单打开托/豆妈页面失败，只记录原因并提示人工设置，不退出本轮；人工设置完成后仍可点击“我已设置好，开始创建任务”继续发单。
- 验证：2026-09-29 在本机运行 `node --check src\v2\cms\cms-config-form.js src\v2\cms\cms-config-library.js src\v2\cms\cms-config-restore.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-cms-config-library.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；云中客配置表单保存/恢复测试和控制台静态页面测试通过。
- 云中客配置库保存当前页面摘要时，改为优先读取真实勾选的快捷分组/机器人行，并按“多快捷模式”文字旁边的开关判断状态；不再把表头、筛选项、发送区设置误混进托/豆妈页面摘要，任务备注仍只读取任务备注输入框。
- 验证：2026-09-29 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 --test-name-pattern "real CMS current selection reads checked quick rows" tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；云中客配置摘要新增用例通过，真实 CMS submit-before 60 项通过。
- 云中客配置库补充保存页面选择配置：保存前会刷新当前托/豆妈云中客页的群、机器人、任务备注、多快捷模式和已选数量摘要；恢复时只带回这些页面选择记录，发送模式、发送间隔、定时发送、快捷时间、主消息发送顺序、消息模式继续交给云中客自己的默认记忆。
- 验证：2026-09-29 在本机运行 `node --check src\v2\cms\cms-page-selection-snapshot.js src\v2\cms\cms-page-selection-restore.js src\v2\cms\cms-config-snapshot.js src\v2\cms\cms-config-restore.js src\v2\cms\real-cms-adapter.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`；云中客配置库选择快照保存/恢复测试通过。
- 控制台“云中客配置”区域改为更明显的状态条和配置卡片展示：未选择时显示空状态，已选择时显示当前配置和托/豆妈页面摘要，并明确提示恢复后仍需人工确认且不会自动开始创建。
- 验证：2026-09-29 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态展示测试通过。
- 控制台新增“云中客配置”库：可保存当前 run 的托/豆妈云中客页面绑定和设置摘要，后续选择后会记住配置；进入云中客设置时先恢复配置记录并停在等待确认状态，要求人工检查群、机器人和发送设置后再开始创建。
- 验证：2026-09-29 在本机运行 `node --check src\v2\cms\cms-config-library.js src\v2\cms\cms-config-snapshot.js src\v2\cms\cms-config-restore.js`、`node --check src\v2\console\settings.js src\v2\console\workflow.js src\v2\console\server.js`、`node --test --test-concurrency=1 tests\v2-cms-config-library.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`；新增云中客配置库单测和控制台 46 项通过。
- 控制台文案库“使用”按钮改为直接打开预览页，不再二次确认；点击后立即显示“正在打开文案库预览页”，成功后提示如果没有自动切换可切到“妙券自动发单 - 预览确认”标签页，避免误以为按钮无反应且不增加操作步骤。
- 控制台“发单版本”提示补充精准版限制：在粗略版多快捷模式提示同一区域新增“精准版：目前只支持单组托形式”，避免误按多组托配置精准版。
- 飞书全文/范围采集增加第二遍复扫兜底：第一遍滚动采集结束后，会回到全文顶部或范围开始位置再滚动检测一遍，第二遍只补充第一遍漏掉的正文/图片/表情包/视频，不重复已有事件，降低飞书素材延迟加载或滚动短暂卡住导致预览少素材的概率。视频号代码块复制逻辑保持原有缓存和去外壳规则，第二遍不会重复破坏已复制的 XML。
- 验证：2026-09-28 在本机运行 `node --check src\v2\feishu\collector.js tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 --test-name-pattern "finder code block|copied finder|continues to next speaker|rescans once" tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`；固定格式解析 37 项、飞书采集 59 项通过。重点覆盖：视频号完整 XML 复制、多个视频号不重复、视频号后继续采下一位说话人、第二遍复扫能补进第一遍后才出现的内容。
- 修复第二遍复扫导致范围开始位置“不唯一”的问题：复扫产生的同一虚拟滚动 DOM 头部或“下面还说话”重复头会在采集合并/范围定位阶段视为同一锚点，不再把同一个开始位置算成两个候选；真实文档里稳定来源的两条同名同时间消息仍然按不唯一报错，避免误选。
- 验证：2026-09-28 在本机运行 `node --check src\v2\range\locate-range.js src\v2\feishu\collector.js tests\v2-range.test.js tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 --test-name-pattern "duplicate DOM|repeated timed anchors|rescan duplicate|virtual-scroll|rescans once|finder code block|copied finder|continues to next speaker" tests\v2-range.test.js tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-range.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`；范围定位 18 项、飞书采集 60 项通过。重点覆盖：复扫重复起点不报“不唯一”、真实重复时间仍报错、视频号复制采集不受影响。
- 修复范围采集第二遍复扫没有完整执行的问题：第二遍改为独立临时采集池，开始/结束命中只看本轮扫描结果，不再复用第一遍已采到的结束关键词而首屏提前停止；第二遍完成后再合并回总结果。跨遍合并时优先保留采集插入顺序，避免飞书虚拟滚动的屏幕 `y` 坐标变化把范围开始前的旧说话人段落插入到开始位置后面。
- 验证：2026-09-28 在本机运行 `node --check src\v2\feishu\collector.js tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 --test-name-pattern "independent pass|rescan duplicate previous|drops rescan duplicate|rescans once|finder code block|copied finder|continues to next speaker" tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-range.test.js`；飞书采集 62 项、范围定位 18 项通过。重点覆盖：范围第二遍至少继续扫描到结束边界、复扫旧段落不会混入开始范围、视频号复制采集不受影响。
- 控制台“选择文档/文案来源”说明下新增橙色“注意”提示：视频太大时需提前准备视频号代码块；文案需标明每句话的说话人，互动托需在说话人旁标注“（下面还说话）”。
- 验证：2026-09-28 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面提示测试通过。
- 修复飞书文档小标题被当成正文的问题：独立一行的“日常合集文案（新）”这类文档章节标题会在采集归一化阶段过滤，不再继承上一位说话人并拼进可发送文本。
- 验证：2026-09-28 在本机运行 `node --check src\v2\feishu\collector.js tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 --test-name-pattern "document section title|independent pass|rescan duplicate previous|finder code block|copied finder|continues to next speaker" tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`；飞书采集 63 项通过。重点覆盖：文档章节标题不进正文、第二遍复扫和视频号复制采集不受影响。
- 发布：2026-09-28 将更新源 `latest.json` 发布为 `2.1.9`，补丁包 `patches/fd-auto-tool-patch-v2.1.9.zip` 可访问；在临时目录模拟从 `2.1.8` 套补丁成功，内置代码检查通过。
- 修复飞书视频号代码块工具栏残留被当成预览文字的问题：当飞书把代码块外壳合并成 `代码块 / XML / 复制` 这类文本时，采集层和解析层都会识别为代码块控件文字并丢弃，不再在视频号之间多出一条“代码块 XML 复制”的文字预览。
- 验证：2026-09-28 在本机运行 `node --check src\v2\feishu\collector.js src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 --test-name-pattern "dom code fragments|finder xml" tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`；固定格式解析 37 项、飞书采集 58 项通过。
- 预览页“存入文案库”弹窗改为统一支持“另存为新文案”和“覆盖已有文案”：不管预览是从飞书全文读取、指定范围读取，还是从文案库打开后修改，都可以在同一个弹窗里选择保存方式；选择覆盖时，会从已保存文案库列表里选择要覆盖的文案，确认后才真正覆盖。控制台生成预览前不再增加额外覆盖目标选择，避免流程变复杂。
- 飞书表情包素材落地修复为优先下载动态源：当采集到的是飞书 `/v2/cover/` 静态封面或页面内联静态图时，表情包会先按同一 token 尝试下载 `/preview/.../?preview_type=16` 动态预览源；动态源失败才回退静态图，避免别人电脑上预览/上传成静态 PNG。
- 验证：2026-09-28 在本机运行 `node --check src\v2\preview\preview-page.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 --test-name-pattern "library save modal" tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 --test-name-pattern "preview library|library preview" tests\v2-console.test.js`、`node --check src\v2\media\media-cache.js tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 --test-name-pattern "animated sticker preview" tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`；预览页 41 项、控制台文案库 4 项、飞书采集 58 项通过。
- 精准托正式创建继续提速：切换托前会先读取当前机器人选择状态，如果页面已经只选中 1 个机器人，且当前机器人/已选行能匹配本条预览目标托昵称，则直接复用当前选择，不再执行“取消旧勾选 -> 清空关键词 -> 搜索 -> 勾选”的完整切换流程。匹配不明确、已选 0 个或大于 1 个时仍走原安全流程。
- 验证：2026-09-28 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 --test-name-pattern "precise robot candidate|robot-not-in-group retry|waits for green media ready" tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；真实 CMS submit-before 测试通过。
- 控制台“发单版本”的“粗略版：随机托”卡片下新增醒目橙色提示：粗略版随机托需先在云中客页面打开【多快捷模式】后再开始创建，避免手动设置时漏开多快捷。
- 验证：2026-09-28 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台页面静态提示测试通过。
- 精准托正式创建做第一版低风险提速：机器人关键词搜索后不再固定等待 600ms，改为最多 3 秒短轮询，目标机器人行一出现就继续；机器人已选数量、目标行勾选、全选/全取消兜底和提交前页面稳定检测的轮询间隔由 300-500ms 缩短到 150-250ms。保留所有安全校验，不跳过 `已选0/已选1`、目标机器人勾选、确认弹窗机器人数量和素材绿色就绪检查。
- 验证：2026-09-28 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 --test-name-pattern "precise robot candidate|robot-not-in-group retry|waits for green media ready" tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；真实 CMS submit-before 59 项通过。新增覆盖：精准托搜索候选后使用目标行短轮询，不再固定死等 600ms。
- 修复媒体任务提交前“就绪中”被误判为失败的问题：图片、视频、动态表情在正式创建点击“执行发送”前，如果当前只看到非绿色的“极速就绪/就绪中”状态，会继续等待素材状态变成绿色就绪；确认绿色后才查找并点击一次“执行发送”。超时仍未绿色时才按“素材未就绪”停止，避免过早点发送或重复点击。
- 验证：2026-09-28 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 --test-name-pattern "waits for green media ready|sticker submit stops" tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；真实 CMS submit-before 59 项通过。新增覆盖：提交前前两次读取为“就绪中/非绿色”，第三次变成绿色“极速就绪”后，只点击一次“执行发送”。
- 精准托生成预览前新增“上一轮成功托冷却”居中确认弹窗：如果检测到上一轮已经成功创建的托，会询问是否把这些托加入本轮冷却池；选择“是”后，本轮精准托预览分配会优先避开这些托，候选不足时才兜底使用；选择“否”则不使用上一轮成功托冷却。该逻辑只影响精准托预览分配，不影响豆妈、粗略托和正式创建选机器人流程。
- 精准托预览分配增加基于本轮 run 名称的同分候选轮换，避免每次新创建预览时第一个托总是名单里的同一个托；上一轮成功托冷却候选会在点击“开始下一轮”清空当前状态后继续保留一次，用于下一次生成预览前确认。
- 验证：2026-09-28 在本机运行 `node --check src\v2\tuo\precise-tuo-assigner.js src\v2\console\workflow.js src\v2\console\server.js tests\v2-precise-tuo.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`；精准托分配 15 项、控制台 46 项通过。新增覆盖：开启上一轮成功托冷却时首条会避开上一轮已成功托；不同 run seed 会轮换同分候选；开始下一轮后仍能读取上一轮成功托作为冷却弹窗候选。
- 调整精准托正式创建的托机器人切换主流程和兜底：换到下一位托前，如果当前机器人只已选 1 个，会先点击当前已选行取消并等待 `已选0/总数`，再搜索当前任务目标托昵称并只勾选目标行；如果一开始或选择后检测到已选数量大于 1，才执行兜底流程：清空搜索、点击机器人表头全选到 `已选总数/总数`、再点一次全取消到 `已选0/总数`，随后重新搜索当前任务目标托并校验 `已选1/总数`。兜底只用于精准托的托页面，不用于豆妈和粗略托。
- 验证：2026-09-28 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；真实 CMS submit-before 58 项通过。新增覆盖：精准托机器人切换会先取消当前唯一已选，再搜索目标托；多选时才走全选/全取消兜底。
- 修复精准托模式下豆妈页面误走角色/换托准备流程的问题：正式创建时只有 `托` 任务会进入精准托按名单搜索/勾选机器人或粗略托换机器人逻辑；`豆妈` 任务与粗略托模式一致，不点击“请选择角色”、不搜索机器人、不换托，只检查当前豆妈云中客页面群和机器人配置可用后继续填内容/素材。
- 验证：2026-09-28 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；真实 CMS submit-before 58 项通过。新增覆盖：精准托配置下豆妈任务不会调用使用角色下拉，也不会切换托机器人。
- 修复精准托正式创建选机器人顺序错误的问题：按预览托号昵称搜索目标机器人后，只在目标行未勾选时点击一次；目标行已勾选时不再二次点击，避免把机器人取消选中。点击后会读取右侧标题 `机器人（已选X/Y）`，必须检测到 `已选1/Y` 且目标机器人已勾选才继续上传素材/创建；若为 `0/Y`、大于 1 个或识别不到目标勾选，会立即停止并报错。
- 验证：2026-09-28 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；真实 CMS submit-before 57 项通过。新增覆盖：精准托机器人先搜索再按目标行状态选择，并要求机器人已选数量为 1。
- 控制台“保存托人设名称”和“修改托人设名称”不再使用浏览器原生 `prompt()`，改为复用页面内居中弹窗输入名称；弹窗支持回车确认、Esc/取消关闭，并保留空名称校验。
- 验证：2026-09-28 在本机运行 `node --check src\v2\console\server.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`；控制台 45 项通过。新增覆盖：托人设保存/改名不再使用原生 `prompt()`，改用页面内居中输入弹窗。
- 修复精准托正式创建仍尝试点击“请选择角色”下拉、以及机器人搜索误点左侧群列表关键词框的问题：精准托托任务创建前不再依赖使用角色下拉换托，会先按“机器人（已选…）”标题的屏幕坐标锁定右侧机器人列，再按预览页当前托号昵称/`tuoAssignment.primary` 到该列下“排序”右侧的 `关键词` 控件右边输入框搜索并勾选对应机器人；左侧“群”面板关键词框和群复选框会被排除，不再只靠父容器是否含“机器人”判断。同一精准托身份连续任务不重复切换，换托和机器人不在群重试仍走“清空关键词 -> 输入候补昵称 -> 勾选”的流程。粗略托和豆妈角色选择逻辑不变。
- 正式创建确认弹窗增加机器人数量保护：读取“当前已选择”弹窗中的机器人数量，如果显示已选择机器人数量大于 1，会立即停止当前批次并报错，不点击“确认创建”，避免精准托一条消息被多个机器人发送。
- 验证：2026-09-28 在本机运行 `node --check src\v2\cms\confirm-dialog-policy.js src\v2\cms\real-cms-adapter.js tests\v2-cms-confirm-dialog-policy.test.js tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-cms-confirm-dialog-policy.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`；确认弹窗策略 10 项、真实 CMS submit-before 56 项通过。新增覆盖：精准托创建前不调用使用角色下拉而是按预览候选切换机器人；机器人关键词搜索和机器人复选框只在右侧机器人列表面板内定位；确认弹窗显示 `机器人 2 个` 时停止且不会点击确认创建。
- 修复正式创建时首条定时时间过期后“后续任务重新顺延”不尊重自定义豆妈/托切换间隔的问题：用户填写了豆妈/托切换 `10-20` 秒时，运行时二次排程会按自定义间隔计算；未填写自定义时仍保留默认至少 `120` 秒，避免改变旧默认行为。
- 修复精准托图片开头导致同一原始说话人过早锁定“年纪大/宝妈”人设的问题：如果首条图片/无文字没有托词可判断，会先参考同一原始托后面的明确文字托词；后续同一说话人出现“给老妈、看哈、惯不、先买几袋”等年轻买家口吻时，这一组会一起分配到年轻/学生类托，不再图片一条用年纪大托、文字一条用年轻托。“可年纪大”会识别为成熟人设，年轻口吻下会降低这类候选优先级。互动托分组仍保持固定复用，普通家庭囤货文案不触发换托。
- 验证：2026-09-28 在本机运行 `node --check src\v2\tuo\tuo-intent.js src\v2\tuo\tuo-roster.js src\v2\tuo\precise-tuo-assigner.js tests\v2-precise-tuo.test.js src\v2\cms\create-runner.js tests\v2-cms-runner.test.js`、`node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`、`node --test --test-concurrency=1 tests\v2-cms-runner.test.js`；精准托 13 项、创建 runner 23 项通过。新增覆盖：同一原始托下图片在前、下一条“我先买3袋给老妈看哈用的惯不”在后时，图片和文字会一起选到 `可学生` 托；正式创建过期顺延时自定义豆妈/托切换 `10-20` 秒不会被强制改成 120 秒。
- 修复手动范围结束位置是“说话人 + 时间”标题时预览少内容的问题：飞书采集命中结束关键词后，如果该关键词对应角色标题，不再立刻停止，会继续向下补采该标题下面的正文/素材，或直到看到下一位说话人/达到补采上限；结束关键词命中正文时仍保持原停止逻辑。范围裁剪仍按结束位置这一条记录截取，不把后面的下一条带进预览。
- 验证：2026-09-28 在本机检查 `runs\v2_real_flow_20260928_140539`，确认 `raw-events/range-events` 只有 `托3 9/23 19:13:57` 标题、缺少 `[天啊]一颗磷虾油居然约等于8粒鱼油` 正文，根因是采集在 `keywords-found` 提前停止；随后运行 `node --check src\v2\feishu\collector.js tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-collect-range-parse.test.js tests\feishu-read-range.test.js`，飞书采集 57 项、范围解析相关 15 项通过。
- 发布：2026-09-28 将更新源 `latest.json` 发布为 `2.1.8`，补丁包 `patches/fd-auto-tool-patch-v2.1.8.zip` 可访问；在临时目录模拟从 `2.1.7` 套补丁成功，内置代码检查通过。
- 修复控制台页面“点什么都没反应”的脚本错误：托名单显示名称里的换行在 HTML 模板中改为双转义，避免生成非法 JavaScript 导致整页事件不绑定；页面加载后按钮、运行状态和版本状态可正常刷新。
- 版本更新检查增加超时保护：后台读取更新源超时后仍返回本机当前版本，并把超时原因显示为“检查更新未完成，不影响当前使用”；前端版本状态请求也加超时，不再长期停在“正在检查更新...”或当前版本 `-`。
- 验证：2026-09-28 在本机运行 `node --check src\update\online-update.js src\v2\version\version-manager.js src\v2\console\server.js tests\online-update.test.js tests\v2-version-manager.test.js tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\online-update.test.js tests\v2-version-manager.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`；控制台脚本解析、更新源超时、本机版本兜底和控制台基础状态测试通过。
- 飞书采集视频号代码块时改为按当前代码块复制结果定稿：识别到含 `<msg><appmsg>` 且带 `finderFeed` 或 `<type>51</type>` 的代码块后，悬停代码块并点击右上角“复制”最多 5 次；复制结果按归一化相似度分组，优先取出现次数最多且完整的 `<msg>...</msg>`，如果多数结果明显缺尾或缺核心字段，则取更完整的结果。同一个代码块后续滚动再次露出时不再重复点击复制，但会复用第一次复制出的 XML 清理当前视口里的“示例代码/代码块/行号/半截 XML”；处理完当前视频号后继续滚动到下一个说话人，再按下一条实际类型采集。该改动只在飞书采集视频号代码块路径生效。
- 优化飞书全页采集滚动稳定性：每一步只滚动一个主文档容器，不再同时触发鼠标滚轮、PageDown、窗口滚动和多个容器滚动；复制视频号代码块时不再强制 `scrollIntoView` 把页面拉回旧位置，复制前后会恢复主文档滚动位置。同一条“说话人时间 + 视频号核心字段”的代码块会缓存第一次复制出的 XML，后续滚动再次看到时直接复用，避免第一条或第二条代码块被重复复制。
- 验证：2026-09-28 在本机运行 `node --check src\v2\feishu\collector.js tests\v2-feishu-collect.test.js src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js src\v2\preview\preview-page.js tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js tests\v2-parser-fixed-format.test.js`；飞书采集 56 项、预览页和固定格式解析合计 76 项通过，其中视频号全页滚动用例断言两个代码块只产生两组复制尝试，不再重复回到已处理代码块。
- 修复视频号 XML 被云中客识别失败的问题：飞书复制/解析视频号代码块时，URL 参数中的裸 `&` 会输出为 XML 安全的 `&amp;`，避免 `<url>...&hy=...&idx=...</url>` 破坏 XML；完整 `feishu-copied-finder-*` 后面的飞书懒加载残留 `加载中...` 也不再追加到视频号参数末尾。
- 验证：2026-09-28 在本机运行 `node --check src\v2\feishu\collector.js tests\v2-feishu-collect.test.js src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js src\v2\preview\preview-page.js tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js tests\v2-preview-store.test.js`；固定格式解析 37 项、飞书采集和预览页合计 96 项通过。使用 `runs\v2_real_flow_20260928_125118\raw-events.json` 复跑解析，3 条视频号均为 `bareAmp=0`、包含 `&amp;`，且不再包含 `加载中...`。
- 修复精准托正式创建时有 `interactionGroup` 会丢失预览选定托的问题：精准托创建前会按预览页最终的 `speaker/cleanSpeaker`、`tuoAssignment.primary` 和候选列表确定当前托昵称，即使属于互动组也会先在机器人列表关键词框搜索并只勾选该托；同一互动组后续消息复用已选托。机器人不在群需要换托时，会从当前已选托后的同身份候补托开始，逐个执行“取消旧勾选、清空关键词、输入新昵称、勾选”的选择流程，不走粗略托随机更换。
- 修复精准托机器人搜索框误点只读“请选择角色”的问题：候补托搜索只定位机器人列表里的可编辑关键词输入框，排除只读/禁用输入框和“请选择角色”输入框；清空搜索时优先点击输入框右侧清除按钮，再回退为直接清空输入值。
- 验证：2026-09-28 在本机运行 `node --check src\v2\cms\real-cms-adapter.js src\v2\cms\confirm-dialog-policy.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-confirm-dialog-policy.test.js`、`node --test --test-concurrency=1 tests\v2-cms-confirm-dialog-policy.test.js`、`node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js`、`node --test --test-concurrency=1 tests\v2-cms-runner.test.js`；确认弹窗策略 9 项、真实 CMS submit-before 54 项、创建 runner 22 项通过。新增覆盖：精准托互动组创建前按预览选定托搜索勾选、当前选定托来自 primary/speaker 时候补重试不跳过第一个候补。
- 修复视频号预览二次拼接代码块碎片的问题：当解析层已经收到 `feishu-copied-finder-*` 的完整 `<msg>...</msg>` 后，后续同一消息段再次出现的 `dom-block-*`、空白行、`示例代码/代码块` 和 XML 片段不再追加进同一个视频号任务，避免预览内容比原飞书复制结果更长。
- 预览页文字和视频号内容旁新增“查看详情”按钮，打开后用弹窗显示当前行最新完整内容，便于核对长文字或长 XML；正文/XML 输入框变更时，按钮上的字数会实时更新，已打开的详情弹窗也会同步当前内容，不影响图片、视频、表情包预览。
- 验证：2026-09-28 在本机运行 `node --check src\v2\feishu\collector.js tests\v2-feishu-collect.test.js src\v2\preview\preview-page.js tests\v2-preview-store.test.js src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-feishu-collect.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`；飞书采集 56 项、预览页 40 项和固定格式解析 36 项通过。使用 `runs\v2_real_flow_20260928_121050\raw-events.json` 复跑解析，三条视频号预览长度恢复为原复制结果 `4434 / 4526 / 4526`，`sourceId` 只保留 `feishu-copied-finder-*`，不再包含 `dom-block-*`。
- 飞书采集支持视频号格式代码块：遇到包含 `<msg><appmsg>` 且带 `finderFeed` 或 `<type>51</type>` 的代码块，会去掉“示例代码/复制/自动换行/语言名/行号”等飞书代码块外壳，只保留 XML 参数生成“视频号”预览项；正式创建沿用现有视频号入口填写参数，不改粗略托/精准托分配逻辑。
- 验证：2026-09-28 在本机运行 `node --check src\v2\feishu\collector.js src\v2\parser\parse-fixed-format.js tests\v2-feishu-collect.test.js tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`node --test --test-concurrency=1 --test-name-pattern "finder|video account|page collector" tests\v2-feishu-collect.test.js tests\v2-cms-runner.test.js tests\v2-cms-dry-run.test.js tests\v2-cms-page-actions.test.js`；视频号代码块采集、解析和 CMS 视频号创建路径测试通过。
- 授权总控新增管理员账号登录：不再需要给其他管理者分发 URL token，可为每个管理者创建固定账号、显示名称/电脑备注和密码；总管理员可启用、停用、重置密码。服务器只保存密码哈希，不保存明文密码；账号登录仍限制内网来源，并记录最后登录时间、来源 IP 和浏览器标识，方便跟进是谁在查看。
- 验证：2026-09-27 在本机运行 `python -c "import ast, pathlib; [ast.parse(pathlib.Path(p).read_text(encoding='utf-8'), filename=p) for p in ['tools/server-license/service.py','tools/server-license/test_service.py']]"`、`python -m unittest discover -s tools\server-license -p test_service.py`；后台账号哈希、登录记录、停用后禁止登录和总控页面结构测试通过。
- 部署：2026-09-27 已同步 `tools/server-license/service.py` 到总控服务器 `/opt/miaoquan-license/service.py` 并重启 `miaoquan-license.service`，服务状态为 `active`；已创建 `owner` 总管理员和 `manager01` 普通管理者账号。已验证未登录显示登录页，`owner` 登录后可看到“管理员账号”，`manager01` 可登录但访问管理员账号接口会被拒绝。密码未写入项目文件。
- 精准托预览分配时，当前行展示过的在用托和备选托会先加入本轮临时冷却池，后续托词优先避开这些候选；正式创建仍只按真实发送出去的托记录，不把预览候选永久占用。同一个原始说话人默认继续复用同一个名单托，只有后续文本明确出现工作场景且当前托不是工作人设时才重新分配，避免工作场景继续沿用前面的宝妈托，也避免普通家用/囤货文案误换托。
- 预览页精准托“在用”标记改为更醒目的橙色底和橙色边框，便于区分当前实际使用托。
- 控制台精准托名单上传区优先显示已保存的托人设名称，下一行显示原名单文件名，避免只看到 `tuo_roster_...xlsx` 不知道当前选了哪套名单。
- 验证：2026-09-27 在本机运行 `node --check src\v2\tuo\precise-tuo-assigner.js tests\v2-precise-tuo.test.js src\v2\preview\preview-page.js src\v2\console\server.js tests\v2-console.test.js`，以及 `node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`、`node --test --test-concurrency=1 --test-name-pattern "v2 console server exposes visual page settings and status" tests\v2-console.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`；精准托分配、同原始托工作场景重分配、同原始托普通囤货不换托、控制台托人设名称显示、预览页保存和精准托候选 UI 相关测试通过。使用 `runs\v2_real_flow_20260927_203012` 的真实预览数据复跑，`白天在公司...` 场景已分配到工作人设托。
- 调整授权总控页面为左侧导航后台布局，按“待授权 / 已授权 / 使用报表”拆分内容；默认进入待授权页，已授权设备不再显示“通过”按钮，避免把已授权设备误当成待处理。
- 验证：2026-09-27 在本机运行 `python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`、`python -m unittest discover -s tools\server-license -p test_service.py`；总控页面结构和授权服务测试通过。
- 部署：2026-09-27 已同步 `tools/server-license/service.py` 到总控服务器 `/opt/miaoquan-license/service.py` 并重启 `miaoquan-license.service`，服务状态为 `active/running`；服务器脚本已包含左侧导航页面标记。当前本机已配置 `techadmin@10.6.1.123` SSH 密钥登录，未在项目文件中保存服务器密码。

## 2.1.7

- 恢复云中客确认创建弹窗的原有点击流程：第一次点击“确认创建”后短等 1.8 秒；若未检测到成功/失败且确认弹窗仍在、仍能找到蓝色“确认创建”按钮，则按原逻辑再点一次并等待正式结果，避免第一次点击未触发时卡在确认弹窗。绿色“任务创建成功”提示作为正式成功依据，即使页面暂时没恢复可编辑也不再判失败。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\real-cms-adapter.js`、`node --check tests\v2-real-cms-submit-before.test.js`，以及 `node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js tests\v2-cms-runner.test.js tests\v2-console.test.js`；确认创建原有重试流程、成功判定、运行中页面切换、创建 runner 和控制台相关测试共 115 项通过。
- 调整正式创建运行中的云中客页面切换：每条任务开始前和失败后重试当前条时，默认会用浏览器标签切换接口切到对应托/豆妈云中客页，不再只做后台定位；不使用系统鼠标点标签，仍保留显式 `focusDuringRun: false` 的后台模式给调试使用。控制台正式创建已改为启用可见切换。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\real-cms-adapter.js src\v2\cms\create-runner.js src\v2\console\workflow.js src\v2\tools\run-real-cms-cli.js tests\v2-real-cms-submit-before.test.js`，以及 `node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js tests\v2-cms-runner.test.js tests\v2-console.test.js`；运行中页面切换、重试切页、创建 runner 和控制台相关测试共 113 项通过。
- 修复飞书里同一个说话人在同一秒连续发两条文字时，预览页把两条合并到同一条正文里的问题；现在重复出现新的“说话人 + 日期 + 时间”头部会按独立消息拆成多条，只有同一个头部来源被重复采集时才会忽略重复头。
- 验证：2026-09-27 在本机运行 `node --check src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js`，以及 `node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js tests\v2-real-collect-range-parse.test.js tests\v2-feishu-collect.test.js`；同人同秒两条文字拆分、解析、飞书采集和真实范围解析相关测试共 117 项通过。
- 修复实时发创建时，预览日期已经是今天但 CMS 日期下拉只显示 `27号`、`9/27`、`9月27日` 等纯日期文本时，程序找不到“今天(27号)”而误报“CMS 定时日期选项不支持该日期”的问题；现在日期控件定位、选项点击和选中校验都会兼容这些显示方式。若目标日期就是今天且 CMS 当前已是今天，会跳过强制点日期，只填写时间；坐标扫描失败时会再用可见文字定位日期选项。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\schedule-date.js src\v2\cms\real-cms-adapter.js tests\v2-cms-schedule-date.test.js`，以及 `node --test --test-concurrency=1 tests\v2-cms-schedule-date.test.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-runner.test.js`；实时发日期匹配、CMS submit-before 和创建 runner 相关测试通过。
- 修复正式创建某条失败后点击“重试这一条”时，系统没有明确定位到该条对应的托/豆妈云中客页，导致重试流程容易和当前可见页面混淆的问题；现在重试当前失败条时会在后台定位到绑定的对应角色页继续执行，不把云中客窗口强行带到前台，正常连续创建仍保持不频繁抢前台。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\create-runner.js src\v2\cms\real-cms-adapter.js tests\v2-cms-runner.test.js`，以及 `node --test --test-concurrency=1 tests\v2-cms-runner.test.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-schedule-date.test.js`；重试当前条切回角色页、真实 CMS adapter 和日期匹配测试通过。
- 正常连续创建时，每条任务开始前也会在后台定位到该条对应的托/豆妈云中客页执行，不把窗口或标签页强行带到前台；在上传、等待素材极速就绪、等待确认弹窗等长步骤中，控制台选择“从下一条继续/从指定条继续”或“跳过当前条”也会及时生效，不再只能等长步骤超时或结束。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\create-runner.js src\v2\cms\real-cms-adapter.js src\v2\console\state.js tests\v2-cms-runner.test.js`，以及 `node --test --test-concurrency=1 tests\v2-cms-runner.test.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-schedule-date.test.js tests\v2-console.test.js`；连续创建后台定位、长步骤中继续/跳过、控制台状态流和 CMS 相关测试共 116 项通过。
- 发布：2026-09-27 将更新源 `latest.json` 发布为 `2.1.7`，补丁包 `patches/fd-auto-tool-patch-v2.1.7.zip` 可访问；在临时目录模拟从 `2.1.6` 套补丁成功，内置代码检查通过。

## 2.1.6

- 从文案库打开预览时，工作副本里的可发送条目日期会默认改为今天；原文案库保存内容不覆盖，时间、正文、素材和不发条目保持不变。
- 验证：2026-09-27 在本机运行 `node --check src\v2\preview\preview-library.js src\v2\console\workflow.js tests\v2-console.test.js`，以及 `node --test --test-concurrency=1 tests\v2-console.test.js`；文案库工作副本默认今日日期和控制台相关测试通过。
- 授权总控使用报表新增“详情”查看：汇总表保持原样，点击电脑名旁的详情可查看每轮开始/结束时间、状态、任务进度、脱敏场景和失败/中止原因；场景只包含阶段、角色、类型、日期、时间，不上传正文、素材路径或群名。
- 验证：2026-09-27 在本机运行 `node --check src\v2\license\license-manager.js src\v2\console\workflow.js src\v2\console\state.js`、`python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`，以及 `node --test --test-concurrency=1 tests\v2-license-manager.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`、`python -m unittest discover -s tools\server-license -p test_service.py`；使用详情上报、总控明细接口和控制台相关测试通过。
- 预览页说话人列会按托模式切换：粗略托/普通预览显示“说话人”并使用普通列宽，只有精准托名单任务才显示“人设 / 托号昵称 / 备选托”和精准托宽列。
- 验证：2026-09-27 在本机运行 `node --check src\v2\preview\preview-page.js tests\v2-preview-store.test.js`，以及 `node --test --test-concurrency=1 tests\v2-preview-store.test.js`；粗略托和精准托预览页展示测试通过。
- 从文案库打开预览并默认改为今天日期时，预览页顶部摘要区会显示醒目的浅黄色提示，说明已按今天更新日期且原文案库不会被覆盖；本机预览路径和当前目录改为默认收起的“高级/调试信息”。
- 验证：2026-09-27 在本机运行 `node --check src\v2\preview\preview-library.js src\v2\preview\preview-page.js tests\v2-preview-store.test.js`，以及 `node --test --test-concurrency=1 tests\v2-preview-store.test.js`；文案库日期提示、路径默认收起和预览页相关测试通过。
- 发布：2026-09-27 将更新源 `latest.json` 发布为 `2.1.6`，补丁包 `patches/fd-auto-tool-patch-v2.1.6.zip` 可访问；在临时目录模拟从 `2.1.5` 套补丁成功，内置代码检查通过。授权总控服务器 `miaoquan-license.service` 已同步服务脚本并重启，服务状态为 `active`，无 token 访问新报表接口返回 `403 ADMIN_DENIED`，确认新路由已加载且权限生效。

## 2.1.5

- 授权总控新增使用报表：客户端在正式创建开始和结束时上报脱敏使用记录，总控按今日/本周/上周汇总每台电脑的使用次数、总时长、平均时长、计划任务数、成功数、失败数、完成/失败/中止次数和最后使用时间。
- 使用报表只记录设备、版本、时间、任务数量和运行状态，不上传正文、素材、群名或业务内容；统计按北京时间切日和切周。
- 授权总控的“是否最新/更新状态”改为以总控侧最新客户端版本兜底判断，避免客户端未上报 latestVersion 时把旧版误标成“最新”；旧版本会显示“待更新到当前版本”。
- 修复 CMS 日期下拉偶发点错或识别不到“今天(27号)”的问题：日期控件定位会避开右侧时间输入，日期选项匹配优先精确日期，同时兼容 CMS 只显示“今天/明天/后天”的简写。
- 验证：2026-09-26 在本机运行 `node --check src\v2\license\license-manager.js src\v2\console\workflow.js`、`python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`，以及 `node --test --test-concurrency=1 tests\v2-license-manager.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`、`python -m unittest discover -s tools\server-license -p test_service.py`；客户端上报、总控报表汇总和控制台流程测试通过。
- 验证：2026-09-26 在本机运行 `python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`、`python -m unittest discover -s tools\server-license -p test_service.py`；总控旧版设备更新状态兜底显示测试通过。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-cms-schedule-date.test.js`，以及 `node --test --test-concurrency=1 tests\v2-cms-schedule-date.test.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-runner.test.js`；CMS 日期下拉匹配、正式创建前适配和创建执行骨架测试通过。

## 2.1.4

- 预览确认页的图片、表情包和视频缩略图支持点击小窗放大检查；不是大弹窗，点空白处、再点原缩略图或按 Esc 可关闭。
- 正式创建和预览保存后的自动流程不再主动把 2.0 浏览器/控制台切到前台，减少运行时抢光标；需要人工设置云中客时仍会按用户点击打开页面。
- 修复飞书同一条消息的媒体被重复识别成多条预览项的问题；同人同时间的相邻媒体在素材特征相同或画面位置明显相同时只保留一条，避免同一张图/表情包重复发送。
- “机器人不在群”的自动更换机器人默认重试上限从 3 次提高到 5 次，输入框仍可按本轮需要手动修改。
- 授权总控支持准实时设备监控：客户端控制台后台每 60 秒上报心跳、当前版本和更新状态；总控页面每 30 秒自动刷新，显示是否最新、在线状态、更新状态和最后心跳。
- 修复精准托按每条托词重新分配导致同一个原始托被拆成多个托的问题；同一互动托分组或同一明确原始说话人会固定复用同一个名单昵称。
- 精准托自动分配改为按同一人设内的托号数量做轮换冷却；例如宝妈人设有 10 个托时，会尽量等这一人设的其他托轮过后再复用，同一互动组继续说话只占一次使用位。
- 精准托预览页支持按本次托名单备注里的业务人设筛选托昵称；“无头像”“动物头”等头像类信息只作为附加标记显示，不作为人设分类。
- 精准托备选托会在当前行先推荐 2 个备选，并保留“更多备选”下拉显示当前人设下所有可选托；在用托改为浅蓝行内高亮，备选托改为浅灰行内样式，只有备用托额外显示浅橙“备用”标记，选择备选即可切换当前托昵称；同一互动组手动切换备选托时会同步后续同组托词；预览表头随页面滚动冻结显示，精准托列改为“人设 / 托号昵称 / 备选托”三列布局。
- 精准托预览页主行改为“在用 / 人设 / 托号昵称”，整体与日期、时间、类型、正文顶部水平对齐；人设列固定为短宽度，备选托区域下移并用分隔线留出间距，显示为“备选 / ① 托号 / ② 托号”和“更多 / 下拉框”，从人设列缩进对齐且尽量单行展示；“更多”和下拉框固定同一行，备选/更多标签按文字位置对齐。
- 验证：2026-09-24 在本机运行相关 `node --check`，以及 `node --test --test-concurrency=1 tests\v2-controlled-cms-browser.test.js tests\v2-console.test.js tests\v2-real-cms-submit-before.test.js tests\v2-preview-store.test.js`；受控浏览器、控制台、CMS submit-before 和预览页相关测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\parser\parse-fixed-format.js`，以及 `node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`tests\v2-feishu-collect.test.js`、`tests\v2-real-collect-range-parse.test.js`；解析、采集和真实范围解析链路测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\tuo\precise-tuo-assigner.js tests\v2-precise-tuo.test.js`，以及 `node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`；精准托名单读取、分配和同托复用测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\tuo\tuo-roster.js src\v2\tuo\precise-tuo-assigner.js src\v2\preview\preview-page.js tests\v2-precise-tuo.test.js tests\v2-preview-store.test.js`，以及 `node --test --test-concurrency=1 tests\v2-preview-store.test.js tests\v2-precise-tuo.test.js`；动态人设解析、头像类附加标记、备选托点击保存、表头冻结和精准托预览测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\tuo\precise-tuo-assigner.js src\v2\preview\preview-page.js tests\v2-precise-tuo.test.js tests\v2-preview-store.test.js`，以及 `node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`；同人设轮换冷却、同组备选同步和预览页交互测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\license\license-manager.js src\v2\console\server.js tests\v2-license-manager.test.js`、`python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`，以及 `node --test --test-concurrency=1 tests\v2-license-manager.test.js tests\v2-license-entrypoints.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`、`python -m unittest discover -s tools\server-license -p test_service.py`；授权心跳、总控在线/版本状态和控制台入口测试通过。

## 2.1.3

- 修复正式创建中底部“放弃本轮，重新设置”和“退出”被运行状态锁住的问题；这两个中止动作在 2.0 专用可控浏览器里保持可点击。
- “放弃本轮”和“退出”确认改为控制台页面内弹窗，提示内容改成分段分点展示，避免浏览器原生确认框被自动化弹窗状态影响。
- “退出”会优先请求 Chrome 关闭整个 2.0 专用受控浏览器，避免只关控制台而预览页残留。
- 将控制台、预览页、正式创建确认和常见错误提示里的 `preview.json` 改成“已保存的预览内容/预览内容文件”等普通用户能看懂的说法。
- 修复 `10点30催单`、`11点30点催单` 这类独立催单节奏标题被识别成正文发送的问题；正文句子里提到催单时间仍会保留。
- 启动控制台后会后台检查在线更新；发现新版本时先静默下载到待安装目录，不退出、不重启、不影响当前操作，下载好后提示“下次启动会自动更新”。
- 下次双击启动且后台服务未运行时，会先应用已下载好的补丁，再打开控制台；手动“立即更新”仍保留，作为需要马上切换版本时的备用入口。
- 验证：2026-09-24 在本机运行相关 `node --check`，以及 `node --test --test-concurrency=1 tests\v2-controlled-cms-browser.test.js tests\v2-console.test.js tests\v2-preview-store.test.js tests\v2-cms-preflight.test.js tests\v2-cms-dry-run.test.js tests\v2-cms-runner.test.js tests\v2-cms-page-actions.test.js tests\v2-real-cms-submit-before.test.js tests\v2-time.test.js tests\v2-parser-fixed-format.test.js tests\v2-heading-range.test.js tests\v2-collect-range-parse.test.js tests\v2-parser-cli.test.js tests\online-update.test.js tests\v2-version-manager.test.js`，相关测试通过。

## 2.1.2

- 修复文案库管理里“改名”“删除”使用浏览器原生弹窗导致点了没反应的问题，改为控制台页面内确认弹窗。
- 文案库改名或删除后会同步刷新右侧文案库列表和“管理文案库”弹窗列表，删除当前使用文案时会清掉当前使用标记。
- 在读取范围和时间模式处补充提示：直接使用文案库保存的预览时，不需要改读取范围，也不会按时间模式重新排时间；如需改时间请在预览页调整或重新读取飞书生成预览。

## 2.1.1

- 修复从文案库打开的预览只修改时间后，保存时被“未覆盖文案库原文案”提示误导，不能直接复用已设置好的云中客页面创建的问题。

## 2.1.0

- 修复正式创建暂停后，点击“继续”里的“从下一条开始”可能不生效的问题。

## 2.0.9

- 新增文案库选择和管理：可搜索文案名称，选择后在列表中标记为“当前使用”。
- 新增精准托按名单分配：支持上传 XLSX/CSV/JSON 托名单，只读取“昵称”和“备注”，生成预览前自动分配托说话人。
- 新增视频号参数任务：托/豆妈发言下方的 XML 参数整段进入“视频号”预览项，创建时填入云中客视频号入口。
- 调整“文案有变，重新生成预览”和“放弃本轮，重新设置”的行为，避免误复用文案库或旧预览状态。
- 修复改过预览日期后正式创建仍按当天创建的问题。

## 1.0.14

- 创建云中客任务前增加预览内容校验，避免预览有内容但创建时漏填。
- 文字任务填入后会读回核对，不完整会自动重填。
- 普通输入仍不完整时，会使用剪贴板粘贴兜底；兜底失败才停止，避免漏发。
- 图片、表情包、视频创建前会检查本地素材文件是否存在。

## 1.0.13

- 精推/合集读取中，`T1/T3/T10 + 下面有出现/下面还说话/同一个人两句话/有回复` 等互动标注不会再发成正文。
- 第一次识别到某个编号托是互动托后，后面同编号再次出现会继承同一个互动托。
- 预览和实际创建顺序都会把同一个互动托收在一起；原定时间不改。

## 1.0.12

- 修复精推项目里 `T3（下面还说话）` 这类括号标注没有触发互动托归组的问题。
- 精推同一节奏内，同一个编号互动托会先归到一起，再重新计算预览时间。
- 网页控制台同步显示扫描飞书、素材下载进度，不用只看黑色窗口。

## 1.0.11

- 控制台运行状态新增等待进度显示。
- 监控飞书等待下一次检查时，会显示百分比和小进度条。
- 生成预览后，控制台状态会更新为“预览已生成，等待确认”。

## 1.0.10

- 修复控制台“立即更新”点击后看起来没反应的问题。
- 点击“立即更新”后会立刻显示更新状态，不再先弹浏览器确认框。
- 更新失败时页面会显示具体失败原因，方便判断是网络、下载还是安装问题。

## 1.0.9

- 用户操作页面名称改为“妙券自动发单🚀”。
- 预览确认页、黑窗口启动提示和页面确认提示同步使用新名称。

## 1.0.8

- 优化“立即更新”按钮反馈，点击后会显示正在更新。
- 在线更新过程会在黑窗口输出检查、下载、解压、安装和结果提示。
- 已是最新版时会明确提示当前版本，不再像按钮没反应。

## 1.0.7

- 用户操作页面名称改为“妙券自动发单”。
- 预览确认页名称改为“妙券自动发单 - 预览确认”。
- 黑窗口启动和确认提示同步使用“妙券自动发单”名称。

## 1.0.6

- 修正 1.0.5 完整包打包路径问题，确保控制台实际加载的新代码里能看到“检查更新”按钮。
- 保持 GitHub 在线更新地址内置在新包配置中。

## 1.0.5

- 控制台新增在线检查更新和一键更新入口。
- 后续只要配置固定更新地址，用户可以在控制台直接检查并安装补丁。
- 在线补丁仍会走版本检查、更新前备份、补丁校验，不覆盖配置、历史记录、素材缓存和运行记录。

## 1.0.3

- 支持新版完整包的小补丁更新。
- 新增 `一键更新补丁.bat`，自动检查版本、备份旧文件、覆盖补丁文件并做代码检查。
- 新增 `恢复更新前版本.bat`，可恢复最近一次补丁更新前的程序文件。
- 补丁更新不会覆盖 `config.json`、`last-settings.json`、`cms-page-settings.json`、`runs/`、缓存和日志。
- 保留本轮已完成的可视化控制、精推目录读取、精推范围定位等改动。

## 1.0.2

- 当前工作版本。
- 在 `run.bat` 中支持先准备发单页面，再读取 `监控预览` 生成的最新结果执行。
- `监控预览.bat` 会把最新预览同步到 `latest-preview.json`，供 `run.bat` 使用。

## 1.0.1

- 稳定备份版本。
- 备份位置：`C:\Users\Administrator\Documents\ChatGPT\脚本程序\版本备份\fd-auto-tool-v1.0.1-稳定备份`
- 用途：后续如果 1.0.2 改坏了，可以从这里恢复。

import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { postLicenseServicePayload } from "../license/license-manager.js";
import { finalPreviewPath, previewTasksPath, readPreviewTasks, saveFinalPreview } from "./preview-store.js";
import { listPreviewLibrary, previewLibraryRoot, resolvePreviewLibraryItem } from "./preview-library.js";

const META_FILE = "library-meta.json";
const MAX_PACKAGE_BYTES = 250 * 1024 * 1024;

export async function uploadSharedPreviewLibraryItem(projectRoot, id, options = {}) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const pack = await buildSharedPackage(item);
  const body = await postLicenseServicePayload(projectRoot, {
    action: "shared-library-upload",
    library: pack
  }, { ...options, timeoutMs: options.timeoutMs ?? 60000 });
  if (!body?.ok) throw new Error(body?.message || "共享文案上传失败。");
  await updateLocalSharedMeta(item, body.item || {}, pack.packageHash);
  return {
    ok: true,
    item: await resolvePreviewLibraryItem(projectRoot, id),
    shared: body.item,
    items: await listPreviewLibrary(projectRoot)
  };
}

export async function listSharedPreviewLibrary(projectRoot, options = {}) {
  const localItems = await listPreviewLibrary(projectRoot);
  const body = await postLicenseServicePayload(projectRoot, {
    action: "shared-library-list"
  }, { ...options, timeoutMs: options.timeoutMs ?? 30000 });
  if (!body?.ok) throw new Error(body?.message || "读取云端文案失败。");
  const localByCloudId = new Map(localItems
    .filter((item) => item.shared?.cloudId)
    .map((item) => [item.shared.cloudId, item]));
  const items = (Array.isArray(body.items) ? body.items : []).map((cloud) => {
    const local = localByCloudId.get(cloud.cloudId);
    const localVersion = Number(local?.shared?.cloudVersion || 0);
    const cloudVersion = Number(cloud.cloudVersion || 0);
    return {
      ...cloud,
      localId: local?.id || "",
      localVersion,
      localStatus: local
        ? (cloudVersion > localVersion ? "update_available" : "current")
        : "not_downloaded"
    };
  });
  return { ok: true, items };
}

export async function downloadSharedPreviewLibraryItem(projectRoot, cloudId, options = {}) {
  const body = await postLicenseServicePayload(projectRoot, {
    action: "shared-library-download",
    cloudId
  }, { ...options, timeoutMs: options.timeoutMs ?? 60000, maxResponseBytes: MAX_PACKAGE_BYTES + 1024 * 1024 });
  if (!body?.ok) throw new Error(body?.message || "下载云端文案失败。");
  const item = await importSharedPackage(projectRoot, body.item, body.package);
  return { ok: true, item, items: await listPreviewLibrary(projectRoot) };
}

async function buildSharedPackage(item) {
  const tasks = await readPreviewTasks(finalPreviewPath(item.runDir));
  const { rewrittenTasks, mediaFiles } = await collectMediaFiles(item.runDir, tasks);
  const rawEvents = await readJsonIfExists(path.join(item.runDir, "raw-events.json"));
  const meta = await readJsonIfExists(path.join(item.runDir, META_FILE));
  const pack = {
    schemaVersion: 1,
    sourceLocalId: item.id,
    cloudId: meta.shared?.cloudId || "",
    baseCloudVersion: Number(meta.shared?.cloudVersion || 0),
    name: item.name || "未命名文案",
    taskCount: rewrittenTasks.length,
    updatedAt: item.updatedAt || meta.updatedAt || "",
    tasks: rewrittenTasks,
    rawEvents: Array.isArray(rawEvents) ? rawEvents : [],
    mediaFiles
  };
  const packageHash = sha256(JSON.stringify(pack));
  const packageBytes = Buffer.byteLength(JSON.stringify(pack), "utf8");
  if (packageBytes > MAX_PACKAGE_BYTES) throw new Error("共享文案包超过 250MB，暂不能上传。");
  return { ...pack, packageHash, packageBytes };
}

async function collectMediaFiles(runDir, tasks) {
  const mediaFiles = [];
  const rewrittenTasks = [];
  const seen = new Set();
  for (const task of Array.isArray(tasks) ? tasks : []) {
    const next = { ...task };
    const mediaPath = String(next.mediaPath || "").trim();
    const rel = mediaPath ? mediaRelativePath(runDir, mediaPath) : "";
    if (rel) {
      const packageRel = rel.replace(/\\/g, "/");
      next.mediaPath = packageRel;
      if (!seen.has(packageRel)) {
        seen.add(packageRel);
        const filePath = path.join(runDir, rel);
        const buffer = await fs.readFile(filePath);
        mediaFiles.push({
          path: packageRel,
          size: buffer.length,
          sha256: sha256(buffer),
          contentBase64: buffer.toString("base64")
        });
      }
    }
    rewrittenTasks.push(next);
  }
  return { rewrittenTasks, mediaFiles };
}

function mediaRelativePath(runDir, mediaPath) {
  if (/^(sample|data|https?|blob|image-blob):/i.test(mediaPath)) return "";
  const resolved = path.resolve(mediaPath);
  const mediaRoot = path.resolve(runDir, "media-cache");
  if (!resolved.startsWith(mediaRoot + path.sep)) return "";
  return path.join("media-cache", path.relative(mediaRoot, resolved));
}

async function importSharedPackage(projectRoot, cloudItem = {}, pack = {}) {
  if (!pack || pack.schemaVersion !== 1) throw new Error("云端文案包格式不支持。");
  const root = previewLibraryRoot(projectRoot);
  await fs.mkdir(root, { recursive: true });
  const existing = await localItemByCloudId(projectRoot, cloudItem.cloudId);
  const id = existing?.id || safeLocalId(pack.sourceLocalId) || `shared_${safeLocalId(cloudItem.cloudId) || Date.now()}`;
  const itemDir = path.join(root, id);
  await fs.mkdir(path.join(itemDir, "media-cache"), { recursive: true });
  for (const file of Array.isArray(pack.mediaFiles) ? pack.mediaFiles : []) {
    const rel = safePackagePath(file.path);
    if (!rel.startsWith("media-cache/")) throw new Error("云端素材路径不安全。");
    const buffer = Buffer.from(String(file.contentBase64 || ""), "base64");
    if (file.sha256 && sha256(buffer) !== file.sha256) throw new Error("云端素材校验失败。");
    const dest = path.join(itemDir, ...rel.split("/"));
    await fs.mkdir(path.dirname(dest), { recursive: true });
    await fs.writeFile(dest, buffer);
  }
  const tasks = (Array.isArray(pack.tasks) ? pack.tasks : []).map((task) => {
    const next = { ...task };
    const rel = safePackagePath(next.mediaPath || "");
    if (rel.startsWith("media-cache/")) next.mediaPath = path.join(itemDir, ...rel.split("/"));
    return next;
  });
  await saveFinalPreview(itemDir, tasks, { requireComplete: true });
  await fs.writeFile(previewTasksPath(itemDir), JSON.stringify(tasks, null, 2), "utf8");
  await fs.writeFile(path.join(itemDir, "raw-events.json"), JSON.stringify(Array.isArray(pack.rawEvents) ? pack.rawEvents : [], null, 2), "utf8");
  const now = new Date().toISOString();
  const meta = {
    id,
    name: cleanName(cloudItem.name || pack.name) || "云端文案",
    createdAt: existing?.createdAt || now,
    updatedAt: cloudItem.updatedAt || pack.updatedAt || now,
    sourceRunDir: "",
    runDir: itemDir,
    previewPath: finalPreviewPath(itemDir),
    taskCount: tasks.length,
    shared: {
      cloudId: cloudItem.cloudId || pack.cloudId || "",
      cloudVersion: Number(cloudItem.cloudVersion || 0),
      uploadedAt: cloudItem.uploadedAt || "",
      packageHash: cloudItem.packageHash || pack.packageHash || "",
      downloadedAt: now
    }
  };
  await fs.writeFile(path.join(itemDir, META_FILE), JSON.stringify(meta, null, 2), "utf8");
  await listPreviewLibrary(projectRoot);
  return resolvePreviewLibraryItem(projectRoot, id);
}

async function updateLocalSharedMeta(item, cloudItem, packageHash) {
  const metaPath = path.join(item.runDir, META_FILE);
  const meta = await readJsonIfExists(metaPath);
  const next = {
    ...meta,
    shared: {
      ...(meta.shared || {}),
      cloudId: cloudItem.cloudId || meta.shared?.cloudId || "",
      cloudVersion: Number(cloudItem.cloudVersion || 0),
      uploadedAt: cloudItem.uploadedAt || new Date().toISOString(),
      packageHash: cloudItem.packageHash || packageHash,
      downloadedAt: meta.shared?.downloadedAt || ""
    }
  };
  await fs.writeFile(metaPath, JSON.stringify(next, null, 2), "utf8");
}

async function localItemByCloudId(projectRoot, cloudId) {
  const wanted = String(cloudId || "");
  if (!wanted) return null;
  const items = await listPreviewLibrary(projectRoot);
  return items.find((item) => item.shared?.cloudId === wanted) || null;
}

function safePackagePath(value) {
  const normalized = String(value || "").replace(/\\/g, "/");
  if (!normalized || normalized.startsWith("/") || /^[a-zA-Z]:/.test(normalized) || normalized.includes("..")) return "";
  return normalized;
}

function safeLocalId(value) {
  const id = String(value || "").trim();
  return /^[a-zA-Z0-9_.-]+$/.test(id) ? id : "";
}

function cleanName(value) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 80);
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

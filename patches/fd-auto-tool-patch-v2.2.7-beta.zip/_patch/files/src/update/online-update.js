import childProcess from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const DEFAULT_UPDATE_CHECK_TIMEOUT_MS = 8000;
const DEFAULT_UPDATE_DOWNLOAD_TIMEOUT_MS = 60000;
const OFFICIAL_RAW_PREFIX = "https://raw.githubusercontent.com/wym-gif/fd-auto-tool-update/refs/heads/main/";
const OFFICIAL_RAW_LEGACY_PREFIX = "https://raw.githubusercontent.com/wym-gif/fd-auto-tool-update/main/";
const OFFICIAL_CDN_PREFIX = "https://cdn.jsdelivr.net/gh/wym-gif/fd-auto-tool-update@main/";
const BETA_MANIFEST_NAME = "latest-beta.json";

export async function checkOnlineUpdate(config = {}) {
  const currentVersion = await readCurrentVersion();
  const releaseChannel = normalizeReleaseChannel(config.releaseChannel, currentVersion);
  const updateSourceUrls = getUpdateSourceUrls({ ...config, releaseChannel, currentVersion });
  console.log("正在检查在线更新...");
  if (!updateSourceUrls.length) {
    return {
      ok: false,
      releaseChannel,
      currentVersion,
      error: `${releaseChannelLabel(releaseChannel)}还没有配置独立更新地址。`
    };
  }
  let latest;
  let manifestChannel = "";
  let updateSourceUrl = "";
  const updateSourceErrors = [];
  for (const sourceUrl of updateSourceUrls) {
    try {
      const candidate = await fetchUpdateManifest(sourceUrl, {
        timeoutMs: updateCheckTimeoutMs(config)
      });
      const candidateVersion = String(candidate.latestVersion || candidate.version || "").trim();
      if (!candidateVersion) throw new Error("更新源格式不完整，缺少版本号。");
      const candidateChannel = manifestReleaseChannel(candidate, candidateVersion, sourceUrl);
      assertMatchingReleaseChannel(releaseChannel, candidateChannel, "更新清单");
      latest = candidate;
      manifestChannel = candidateChannel;
      updateSourceUrl = sourceUrl;
      break;
    } catch (error) {
      updateSourceErrors.push({
        updateSourceUrl: sourceUrl,
        error: error?.message || String(error)
      });
    }
  }
  if (!latest) {
    return {
      ok: false,
      error: formatSourceFailure(updateSourceErrors),
      currentVersion,
      releaseChannel,
      updateSourceErrors,
      attemptedUpdateSourceUrls: updateSourceUrls
    };
  }
  const latestVersion = String(latest.latestVersion || latest.version || "").trim();
  const patchUrls = getPatchUrls(latest, updateSourceUrl);
  if (!latestVersion || !patchUrls.length) return { ok: false, error: "更新源格式不完整，缺少版本号或补丁地址。" };
  const minVersion = String(latest.minVersion || "").trim();
  if (minVersion && compareVersions(currentVersion, minVersion) < 0) {
    return { ok: false, error: "当前版本太旧，不能直接在线更新，请先使用新版完整运行包。" };
  }
  return {
    ok: true,
    currentVersion,
    latestVersion,
    releaseChannel,
    manifestChannel,
    hasUpdate: compareVersions(latestVersion, currentVersion) > 0,
    notes: Array.isArray(latest.notes) ? latest.notes.map((item) => String(item)).filter(Boolean) : [],
    patchUrl: patchUrls[0],
    patchUrls,
    updateSourceUrl,
    attemptedUpdateSourceUrls: updateSourceUrls,
    updateSourceErrors,
    fallbackUsed: updateSourceErrors.length > 0
  };
}

export async function installOnlineUpdate(config = {}) {
  console.log("开始在线更新...");
  const status = await checkOnlineUpdate(config);
  if (!status.ok) return status;
  if (!status.hasUpdate) {
    console.log("当前已经是最新版本：" + (status.currentVersion || "-"));
    return { ok: true, alreadyLatest: true, currentVersion: status.currentVersion, latestVersion: status.latestVersion };
  }

  const rootDir = process.cwd();
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "fd-auto-update-"));
  const zipPath = path.join(tempRoot, "patch.zip");
  const extractDir = path.join(tempRoot, "extract");
  try {
    console.log("正在下载补丁：" + status.patchUrl);
    const downloaded = await downloadUpdatePatch(status, zipPath, {
      timeoutMs: updateDownloadTimeoutMs(config)
    });
    if (downloaded.url !== status.patchUrl) console.log("已切换备用补丁地址：" + downloaded.url);
    console.log("补丁下载完成，正在解压...");
    await fs.mkdir(extractDir, { recursive: true });
    await extractZip(zipPath, extractDir);
    const patchRoot = await findExtractedPatchRoot(extractDir);
    if (!patchRoot) throw new Error("补丁包里没有找到 _patch\\patch-manifest.json。");
    const manifest = await readJsonIfExists(path.join(patchRoot, "patch-manifest.json"));
    validatePatchManifest(manifest, status.releaseChannel, status.latestVersion);
    const targetPatchRoot = path.join(rootDir, "_patch");
    console.log("正在安装补丁...");
    await fs.rm(targetPatchRoot, { recursive: true, force: true });
    await fs.cp(patchRoot, targetPatchRoot, { recursive: true });
    const result = childProcess.spawnSync(process.execPath, [path.join(rootDir, "tools", "apply-patch.cjs")], {
      cwd: rootDir,
      encoding: "utf8"
    });
    if (result.status !== 0) {
      const detail = (result.stderr || result.stdout || "").trim();
      throw new Error(detail || "补丁安装失败。");
    }
    console.log("在线更新成功：" + status.currentVersion + " -> " + status.latestVersion);
    return {
      ok: true,
      currentVersion: status.currentVersion,
      latestVersion: status.latestVersion,
      message: result.stdout || ""
    };
  } catch (error) {
    console.log("在线更新失败：" + (error?.message || String(error)));
    return { ok: false, error: error?.message || String(error) };
  } finally {
    await fs.rm(tempRoot, { recursive: true, force: true }).catch(() => {});
  }
}

export async function prepareOnlineUpdate(config = {}, options = {}) {
  console.log("正在后台准备在线更新...");
  const status = await checkOnlineUpdate(config);
  if (!status.ok) return status;
  if (!status.hasUpdate) {
    await removePreparedOnlineUpdate(options.projectRoot || process.cwd());
    return { ok: true, alreadyLatest: true, currentVersion: status.currentVersion, latestVersion: status.latestVersion };
  }

  const rootDir = path.resolve(options.projectRoot || process.cwd());
  const pendingRoot = preparedUpdateRoot(rootDir);
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "fd-auto-update-prepare-"));
  const zipPath = path.join(tempRoot, "patch.zip");
  const extractDir = path.join(tempRoot, "extract");
  try {
    console.log("正在后台下载补丁：" + status.patchUrl);
    const downloaded = await downloadUpdatePatch(status, zipPath, {
      timeoutMs: updateDownloadTimeoutMs(config)
    });
    if (downloaded.url !== status.patchUrl) console.log("已切换备用补丁地址：" + downloaded.url);
    await fs.mkdir(extractDir, { recursive: true });
    await extractZip(zipPath, extractDir);
    const patchRoot = await findExtractedPatchRoot(extractDir);
    if (!patchRoot) throw new Error("补丁包里没有找到 _patch\\patch-manifest.json。");
    const manifest = await readJsonIfExists(path.join(patchRoot, "patch-manifest.json"));
    const patchChannel = validatePatchManifest(manifest, status.releaseChannel, status.latestVersion);
    const targetPatchRoot = safeResolveInside(pendingRoot, "_patch");
    await fs.rm(pendingRoot, { recursive: true, force: true });
    await fs.mkdir(pendingRoot, { recursive: true });
    await fs.cp(patchRoot, targetPatchRoot, { recursive: true });
    const prepared = {
      ready: true,
      currentVersion: status.currentVersion,
      latestVersion: status.latestVersion,
      targetVersion: String(manifest.targetVersion || status.latestVersion || "").trim(),
      releaseChannel: status.releaseChannel,
      manifestChannel: patchChannel,
      updateSourceUrl: status.updateSourceUrl,
      patchUrl: downloaded.url || status.patchUrl,
      notes: status.notes || [],
      preparedAt: new Date().toISOString()
    };
    await fs.writeFile(path.join(pendingRoot, "pending-update.json"), JSON.stringify(prepared, null, 2), "utf8");
    console.log("新版本已下载好，下次启动会自动更新：" + status.latestVersion);
    return { ok: true, prepared: true, ...prepared };
  } catch (error) {
    console.log("后台准备更新失败：" + (error?.message || String(error)));
    return { ok: false, error: error?.message || String(error) };
  } finally {
    await fs.rm(tempRoot, { recursive: true, force: true }).catch(() => {});
  }
}

export async function getPreparedOnlineUpdate(projectRoot = process.cwd()) {
  const rootDir = path.resolve(projectRoot);
  const pendingRoot = preparedUpdateRoot(rootDir);
  const metadata = await readJsonIfExists(path.join(pendingRoot, "pending-update.json"));
  const manifestPath = path.join(pendingRoot, "_patch", "patch-manifest.json");
  if (!metadata.ready || !await pathExists(manifestPath)) {
    return { ready: false };
  }
  const currentPackage = await readCurrentPackage(rootDir);
  const currentVersion = currentPackage.version;
  const releaseChannel = normalizeReleaseChannel(currentPackage.releaseChannel, currentVersion);
  const manifest = await readJsonIfExists(manifestPath);
  try {
    const metadataChannel = manifestReleaseChannel(
      { channel: metadata.releaseChannel || metadata.manifestChannel },
      metadata.targetVersion || metadata.latestVersion,
      metadata.updateSourceUrl || metadata.patchUrl
    );
    assertMatchingReleaseChannel(releaseChannel, metadataChannel, "待安装更新");
    validatePatchManifest(manifest, releaseChannel, metadata.targetVersion || metadata.latestVersion);
  } catch (error) {
    await removePreparedOnlineUpdate(rootDir);
    return {
      ready: false,
      discarded: true,
      currentVersion,
      releaseChannel,
      discardReason: error?.message || String(error)
    };
  }
  if (metadata.latestVersion && compareVersions(currentVersion, metadata.latestVersion) >= 0) {
    await removePreparedOnlineUpdate(rootDir);
    return { ready: false, alreadyApplied: true, currentVersion };
  }
  return {
    ready: true,
    currentVersion,
    releaseChannel,
    latestVersion: String(metadata.latestVersion || metadata.targetVersion || "").trim(),
    targetVersion: String(metadata.targetVersion || metadata.latestVersion || "").trim(),
    preparedAt: String(metadata.preparedAt || "").trim(),
    notes: Array.isArray(metadata.notes) ? metadata.notes : [],
    path: pendingRoot
  };
}

export async function installPreparedOnlineUpdate(projectRoot = process.cwd(), options = {}) {
  const rootDir = path.resolve(projectRoot);
  const prepared = await getPreparedOnlineUpdate(rootDir);
  if (!prepared.ready) return { ok: true, applied: false, ...prepared };

  const sourcePatchRoot = safeResolveInside(preparedUpdateRoot(rootDir), "_patch");
  const targetPatchRoot = safeResolveInside(rootDir, "_patch");
  try {
    await fs.rm(targetPatchRoot, { recursive: true, force: true });
    await fs.cp(sourcePatchRoot, targetPatchRoot, { recursive: true });
    const result = childProcess.spawnSync(process.execPath, [path.join(rootDir, "tools", "apply-patch.cjs")], {
      cwd: rootDir,
      encoding: "utf8",
      windowsHide: true
    });
    if (result.status !== 0) {
      const detail = (result.stderr || result.stdout || "").trim();
      throw new Error(detail || "补丁安装失败。");
    }
    await removePreparedOnlineUpdate(rootDir);
    return {
      ok: true,
      applied: true,
      currentVersion: prepared.currentVersion,
      latestVersion: prepared.latestVersion,
      message: result.stdout || ""
    };
  } catch (error) {
    if (!options.keepBrokenPatch) await fs.rm(targetPatchRoot, { recursive: true, force: true }).catch(() => {});
    return { ok: false, applied: false, error: error?.message || String(error), prepared };
  }
}

export async function removePreparedOnlineUpdate(projectRoot = process.cwd()) {
  await fs.rm(preparedUpdateRoot(path.resolve(projectRoot)), { recursive: true, force: true }).catch(() => {});
}

export function getUpdateSourceUrls(config = {}) {
  const releaseChannel = normalizeReleaseChannel(config.releaseChannel, config.currentVersion);
  const configured = [];
  const channelConfig = config.updateChannels?.[releaseChannel];
  addChannelSourceValues(channelConfig, configured);
  addSourceValues(config[`${releaseChannel}UpdateSourceUrls`], configured);
  addSourceValues(config[`${releaseChannel}UpdateSourceUrl`], configured);
  addSourceValues(process.env[`FD_AUTO_TOOL_${releaseChannel.toUpperCase()}_UPDATE_URLS`], configured);
  addSourceValues(process.env[`FD_AUTO_TOOL_${releaseChannel.toUpperCase()}_UPDATE_URL`], configured);

  if (!configured.length) {
    const legacy = [];
    addSourceValues(config.updateSourceUrls, legacy);
    addSourceValues(config.updateSourceUrl, legacy);
    addSourceValues(process.env.FD_AUTO_TOOL_UPDATE_URLS, legacy);
    addSourceValues(process.env.FD_AUTO_TOOL_UPDATE_URL, legacy);
    for (const sourceUrl of legacy) {
      const compatible = compatibleLegacySourceUrl(sourceUrl, releaseChannel);
      if (compatible) addUnique(configured, compatible);
    }
  }

  const urls = [];
  for (const sourceUrl of configured) {
    addUnique(urls, sourceUrl);
    for (const fallbackUrl of officialFallbackUrls(sourceUrl)) addUnique(urls, fallbackUrl);
  }
  return urls;
}

function addChannelSourceValues(value, target) {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    addSourceValues(value.updateSourceUrls || value.urls, target);
    addSourceValues(value.updateSourceUrl || value.url, target);
    return;
  }
  addSourceValues(value, target);
}

function getUpdateSourceUrl(config = {}) {
  return getUpdateSourceUrls(config)[0] || "";
}

function addSourceValues(value, target) {
  if (Array.isArray(value)) {
    for (const item of value) addSourceValues(item, target);
    return;
  }
  for (const item of String(value || "").split(/[\r\n,;]+/)) {
    const text = item.trim();
    if (text) target.push(text);
  }
}

function addUnique(target, value) {
  const text = String(value || "").trim();
  if (text && !target.includes(text)) target.push(text);
}

export function normalizeReleaseChannel(value, version = "") {
  const normalized = String(value || "").trim().toLowerCase();
  if (normalized === "beta") return "beta";
  if (normalized === "stable") return "stable";
  return /-(?:alpha|beta|rc|dev|preview)(?:[.-]|$)/i.test(String(version || "")) ? "beta" : "stable";
}

export function releaseChannelLabel(channel) {
  return normalizeReleaseChannel(channel) === "beta" ? "内测版" : "正式版";
}

export function manifestReleaseChannel(manifest = {}, version = "", sourceUrl = "") {
  const declaredText = String(manifest.channel || manifest.releaseChannel || "").trim().toLowerCase();
  if (declaredText && declaredText !== "stable" && declaredText !== "beta") {
    throw new Error(`更新清单通道不受支持：${declaredText}`);
  }
  const versionChannel = normalizeReleaseChannel("", version);
  const sourceChannel = /latest-beta\.json(?:[?#]|$)/i.test(String(sourceUrl || "")) ? "beta" : "";
  const channel = declaredText || sourceChannel || versionChannel;
  if (version && declaredText && declaredText !== versionChannel) {
    throw new Error(`更新清单通道与版本号不一致：${declaredText} / ${version}`);
  }
  if (version && sourceChannel && sourceChannel !== versionChannel) {
    throw new Error(`更新清单地址与版本号不一致：${sourceUrl} / ${version}`);
  }
  if (sourceChannel && channel !== sourceChannel) {
    throw new Error(`更新清单通道与地址不一致：${channel} / ${sourceUrl}`);
  }
  return channel;
}

export function assertMatchingReleaseChannel(expected, actual, subject = "更新内容") {
  const expectedChannel = normalizeReleaseChannel(expected);
  const actualChannel = normalizeReleaseChannel(actual);
  if (expectedChannel !== actualChannel) {
    throw new Error(`${subject}通道不匹配：当前是${releaseChannelLabel(expectedChannel)}，收到的是${releaseChannelLabel(actualChannel)}。已阻止更新。`);
  }
}

export function validatePatchManifest(manifest = {}, releaseChannel = "stable", expectedVersion = "") {
  const targetVersion = String(manifest.targetVersion || expectedVersion || "").trim();
  if (!targetVersion) throw new Error("补丁清单缺少目标版本。");
  if (expectedVersion && targetVersion !== String(expectedVersion).trim()) {
    throw new Error(`补丁目标版本不匹配：更新清单是 ${expectedVersion}，补丁是 ${targetVersion}。`);
  }
  const patchChannel = manifestReleaseChannel(manifest, targetVersion);
  assertMatchingReleaseChannel(releaseChannel, patchChannel, "补丁");
  return patchChannel;
}

function compatibleLegacySourceUrl(sourceUrl, releaseChannel) {
  const text = String(sourceUrl || "").trim();
  if (!text) return "";
  const isBetaSource = /latest-beta\.json(?:[?#]|$)/i.test(text);
  if (releaseChannel === "stable") return isBetaSource ? "" : text;
  if (isBetaSource) return text;
  if (!isOfficialUpdateUrl(text)) return "";
  return text.replace(/latest\.json(?=([?#]|$))/i, BETA_MANIFEST_NAME);
}

function isOfficialUpdateUrl(url) {
  const text = normalizeOfficialRawUrl(url);
  return text.startsWith(OFFICIAL_RAW_PREFIX) || text.startsWith(OFFICIAL_CDN_PREFIX);
}

function updateCheckTimeoutMs(config = {}) {
  return positiveNumber(config.updateCheckTimeoutMs, positiveNumber(config.updateTimeoutMs, DEFAULT_UPDATE_CHECK_TIMEOUT_MS));
}

function updateDownloadTimeoutMs(config = {}) {
  return positiveNumber(config.updateDownloadTimeoutMs, positiveNumber(config.updateTimeoutMs, DEFAULT_UPDATE_DOWNLOAD_TIMEOUT_MS));
}

function positiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function readCurrentVersion(rootDir = process.cwd()) {
  return (await readCurrentPackage(rootDir)).version;
}

async function readCurrentPackage(rootDir = process.cwd()) {
  try {
    const packageJson = JSON.parse(await fs.readFile(path.resolve(rootDir, "package.json"), "utf8"));
    return {
      version: String(packageJson.version || "").trim() || "0.0.0",
      releaseChannel: String(packageJson.releaseChannel || "").trim()
    };
  } catch {
    return { version: "0.0.0", releaseChannel: "" };
  }
}

async function fetchUpdateManifest(updateSourceUrl, options = {}) {
  const normalizedUrl = normalizeOfficialRawUrl(updateSourceUrl);
  const url = new URL(normalizedUrl);
  url.searchParams.set("_t", String(Date.now()));
  const response = await fetchWithTimeout(url, { cache: "no-store" }, {
    timeoutMs: options.timeoutMs,
    label: "更新源读取"
  });
  if (!response.ok) throw new Error("更新源读取失败：" + response.status);
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("更新源返回的不是 JSON，可能访问到了错误页或登录页。");
  }
}

async function downloadUpdatePatch(status, targetPath, options = {}) {
  const patchUrls = [];
  addSourceValues(status.patchUrls || status.patchUrl, patchUrls);
  const uniqueUrls = [];
  for (const patchUrl of patchUrls) addUnique(uniqueUrls, patchUrl);
  const errors = [];
  for (const patchUrl of uniqueUrls) {
    try {
      await downloadFile(patchUrl, targetPath, options);
      return { url: patchUrl };
    } catch (error) {
      errors.push({ patchUrl, error: error?.message || String(error) });
    }
  }
  throw new Error(formatPatchFailure(errors));
}

async function downloadFile(url, targetPath, options = {}) {
  const response = await fetchWithTimeout(url, { cache: "no-store" }, {
    timeoutMs: options.timeoutMs,
    label: "补丁下载"
  });
  if (!response.ok) throw new Error("补丁下载失败：" + response.status);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (!buffer.length) throw new Error("下载到的补丁文件为空。");
  await fs.writeFile(targetPath, buffer);
}

function getPatchUrls(manifest, sourceUrl) {
  const configured = [];
  addSourceValues(manifest.patchUrls, configured);
  addSourceValues(manifest.patchUrl || manifest.url, configured);
  const urls = [];
  for (const patchUrl of configured) {
    const resolvedUrl = resolveUrl(patchUrl, sourceUrl);
    const preferredUrl = preferredPatchUrlForSource(resolvedUrl, sourceUrl);
    addUnique(urls, preferredUrl);
    addUnique(urls, resolvedUrl);
    for (const fallbackUrl of officialFallbackUrls(resolvedUrl)) addUnique(urls, fallbackUrl);
  }
  return urls;
}

function resolveUrl(value, baseUrl) {
  const text = String(value || "").trim();
  if (!text) return "";
  try {
    return new URL(text, baseUrl).toString();
  } catch {
    return text;
  }
}

function preferredPatchUrlForSource(patchUrl, sourceUrl) {
  if (String(sourceUrl || "").startsWith(OFFICIAL_CDN_PREFIX)) {
    return toOfficialCdnUrl(patchUrl) || patchUrl;
  }
  if (isOfficialRawUrl(sourceUrl)) {
    return normalizeOfficialRawUrl(patchUrl);
  }
  return patchUrl;
}

function officialFallbackUrls(url) {
  const cdnUrl = toOfficialCdnUrl(url);
  if (cdnUrl) return [cdnUrl];
  const rawUrl = toOfficialRawUrl(url);
  if (rawUrl) return [rawUrl];
  return [];
}

function normalizeOfficialRawUrl(url) {
  return String(url || "").replace(OFFICIAL_RAW_LEGACY_PREFIX, OFFICIAL_RAW_PREFIX);
}

function isOfficialRawUrl(url) {
  const normalized = normalizeOfficialRawUrl(url);
  return normalized.startsWith(OFFICIAL_RAW_PREFIX);
}

function toOfficialCdnUrl(url) {
  const normalized = normalizeOfficialRawUrl(url);
  if (!normalized.startsWith(OFFICIAL_RAW_PREFIX)) return "";
  return OFFICIAL_CDN_PREFIX + normalized.slice(OFFICIAL_RAW_PREFIX.length);
}

function toOfficialRawUrl(url) {
  const text = String(url || "").trim();
  if (!text.startsWith(OFFICIAL_CDN_PREFIX)) return "";
  return OFFICIAL_RAW_PREFIX + text.slice(OFFICIAL_CDN_PREFIX.length);
}

function formatSourceFailure(errors) {
  const count = errors.length;
  const last = errors[count - 1]?.error || "未知原因";
  if (count <= 1) return "更新源检查未完成：" + last;
  return `更新源检查未完成：已尝试 ${count} 个更新地址都失败。最后原因：${last}`;
}

function formatPatchFailure(errors) {
  const count = errors.length;
  const last = errors[count - 1]?.error || "未知原因";
  if (count <= 1) return "补丁下载失败：" + last;
  return `补丁下载失败：已尝试 ${count} 个补丁地址都失败。最后原因：${last}`;
}

async function fetchWithTimeout(url, init = {}, options = {}) {
  const timeoutMs = positiveNumber(options.timeoutMs, DEFAULT_UPDATE_CHECK_TIMEOUT_MS);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal
    });
  } catch (error) {
    if (error?.name === "AbortError") {
      throw new Error(`${options.label || "网络请求"}超时（${Math.round(timeoutMs / 1000)} 秒），不影响当前使用。`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function extractZip(zipPath, destination) {
  const result = childProcess.spawnSync("tar", ["-xf", zipPath, "-C", destination], {
    cwd: process.cwd(),
    encoding: "utf8"
  });
  if (result.status !== 0) {
    const detail = (result.stderr || result.stdout || "").trim();
    throw new Error("补丁解压失败。" + (detail ? "\n" + detail : ""));
  }
}

async function findExtractedPatchRoot(baseDir) {
  const direct = path.join(baseDir, "_patch");
  if (await pathExists(path.join(direct, "patch-manifest.json"))) return direct;
  const entries = await fs.readdir(baseDir, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const candidate = path.join(baseDir, entry.name, "_patch");
    if (await pathExists(path.join(candidate, "patch-manifest.json"))) return candidate;
  }
  return "";
}

async function pathExists(file) {
  try {
    await fs.access(file);
    return true;
  } catch {
    return false;
  }
}

async function readJsonIfExists(file) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch {
    return {};
  }
}

function preparedUpdateRoot(rootDir) {
  return safeResolveInside(rootDir, "_pending-update");
}

function safeResolveInside(base, rel) {
  const resolved = path.resolve(base, rel);
  const root = path.resolve(base);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) {
    throw new Error("更新路径不安全：" + rel);
  }
  return resolved;
}

export function compareVersions(left, right) {
  const a = parseVersion(left);
  const b = parseVersion(right);
  const length = Math.max(a.core.length, b.core.length);
  for (let index = 0; index < length; index += 1) {
    const diff = (a.core[index] || 0) - (b.core[index] || 0);
    if (diff !== 0) return diff > 0 ? 1 : -1;
  }
  if (!a.prerelease.length && !b.prerelease.length) return 0;
  if (!a.prerelease.length) return 1;
  if (!b.prerelease.length) return -1;
  for (let index = 0; index < Math.max(a.prerelease.length, b.prerelease.length); index += 1) {
    const leftPart = a.prerelease[index];
    const rightPart = b.prerelease[index];
    if (leftPart === undefined) return -1;
    if (rightPart === undefined) return 1;
    if (leftPart === rightPart) continue;
    const leftNumber = /^\d+$/.test(leftPart) ? Number(leftPart) : null;
    const rightNumber = /^\d+$/.test(rightPart) ? Number(rightPart) : null;
    if (leftNumber !== null && rightNumber !== null) return leftNumber > rightNumber ? 1 : -1;
    if (leftNumber !== null) return -1;
    if (rightNumber !== null) return 1;
    return leftPart.localeCompare(rightPart) > 0 ? 1 : -1;
  }
  return 0;
}

function parseVersion(value) {
  const normalized = String(value || "0").trim().replace(/^v/i, "").split("+")[0];
  const [coreText, ...prereleaseParts] = normalized.split("-");
  return {
    core: coreText.split(".").map((item) => Number.parseInt(item, 10) || 0),
    prerelease: prereleaseParts.join("-").split(".").map((item) => item.trim().toLowerCase()).filter(Boolean)
  };
}

import childProcess from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

export async function checkOnlineUpdate(config = {}) {
  const updateSourceUrl = getUpdateSourceUrl(config);
  console.log("正在检查在线更新...");
  if (!updateSourceUrl) {
    return { ok: false, error: "还没有配置更新地址。等更新源接好后，这里就可以一键检查更新。" };
  }
  const currentVersion = await readCurrentVersion();
  const latest = await fetchUpdateManifest(updateSourceUrl);
  const latestVersion = String(latest.latestVersion || latest.version || "").trim();
  const patchUrl = String(latest.patchUrl || latest.url || "").trim();
  if (!latestVersion || !patchUrl) return { ok: false, error: "更新源格式不完整，缺少版本号或补丁地址。" };
  const minVersion = String(latest.minVersion || "").trim();
  if (minVersion && compareVersions(currentVersion, minVersion) < 0) {
    return { ok: false, error: "当前版本太旧，不能直接在线更新，请先使用新版完整运行包。" };
  }
  return {
    ok: true,
    currentVersion,
    latestVersion,
    hasUpdate: compareVersions(latestVersion, currentVersion) > 0,
    notes: Array.isArray(latest.notes) ? latest.notes.map((item) => String(item)).filter(Boolean) : [],
    patchUrl
  };
}

export async function installOnlineUpdate(config = {}) {
  console.log("开始在线更新...");
  const status = await checkOnlineUpdate(config);
  if (!status.ok) return status;
  if (!status.hasUpdate) {
    console.log("当前已经是最新版本：" + (status.currentVersion || "-"));
    return { ok: true, alreadyLatest: true, currentVersion: status.currentVersion, latestVersion: status.latestVersion };
  }

  const rootDir = process.cwd();
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "fd-auto-update-"));
  const zipPath = path.join(tempRoot, "patch.zip");
  const extractDir = path.join(tempRoot, "extract");
  try {
    console.log("正在下载补丁：" + status.patchUrl);
    await downloadFile(status.patchUrl, zipPath);
    console.log("补丁下载完成，正在解压...");
    await fs.mkdir(extractDir, { recursive: true });
    await extractZip(zipPath, extractDir);
    const patchRoot = await findExtractedPatchRoot(extractDir);
    if (!patchRoot) throw new Error("补丁包里没有找到 _patch\\patch-manifest.json。");
    const targetPatchRoot = path.join(rootDir, "_patch");
    console.log("正在安装补丁...");
    await fs.rm(targetPatchRoot, { recursive: true, force: true });
    await fs.cp(patchRoot, targetPatchRoot, { recursive: true });
    const result = childProcess.spawnSync(process.execPath, [path.join(rootDir, "tools", "apply-patch.cjs")], {
      cwd: rootDir,
      encoding: "utf8"
    });
    if (result.status !== 0) {
      const detail = (result.stderr || result.stdout || "").trim();
      throw new Error(detail || "补丁安装失败。");
    }
    console.log("在线更新成功：" + status.currentVersion + " -> " + status.latestVersion);
    return {
      ok: true,
      currentVersion: status.currentVersion,
      latestVersion: status.latestVersion,
      message: result.stdout || ""
    };
  } catch (error) {
    console.log("在线更新失败：" + (error?.message || String(error)));
    return { ok: false, error: error?.message || String(error) };
  } finally {
    await fs.rm(tempRoot, { recursive: true, force: true }).catch(() => {});
  }
}

export async function prepareOnlineUpdate(config = {}, options = {}) {
  console.log("正在后台准备在线更新...");
  const status = await checkOnlineUpdate(config);
  if (!status.ok) return status;
  if (!status.hasUpdate) {
    await removePreparedOnlineUpdate(options.projectRoot || process.cwd());
    return { ok: true, alreadyLatest: true, currentVersion: status.currentVersion, latestVersion: status.latestVersion };
  }

  const rootDir = path.resolve(options.projectRoot || process.cwd());
  const pendingRoot = preparedUpdateRoot(rootDir);
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "fd-auto-update-prepare-"));
  const zipPath = path.join(tempRoot, "patch.zip");
  const extractDir = path.join(tempRoot, "extract");
  try {
    console.log("正在后台下载补丁：" + status.patchUrl);
    await downloadFile(status.patchUrl, zipPath);
    await fs.mkdir(extractDir, { recursive: true });
    await extractZip(zipPath, extractDir);
    const patchRoot = await findExtractedPatchRoot(extractDir);
    if (!patchRoot) throw new Error("补丁包里没有找到 _patch\\patch-manifest.json。");
    const targetPatchRoot = safeResolveInside(pendingRoot, "_patch");
    await fs.rm(pendingRoot, { recursive: true, force: true });
    await fs.mkdir(pendingRoot, { recursive: true });
    await fs.cp(patchRoot, targetPatchRoot, { recursive: true });
    const manifest = await readJsonIfExists(path.join(targetPatchRoot, "patch-manifest.json"));
    const prepared = {
      ready: true,
      currentVersion: status.currentVersion,
      latestVersion: status.latestVersion,
      targetVersion: String(manifest.targetVersion || status.latestVersion || "").trim(),
      patchUrl: status.patchUrl,
      notes: status.notes || [],
      preparedAt: new Date().toISOString()
    };
    await fs.writeFile(path.join(pendingRoot, "pending-update.json"), JSON.stringify(prepared, null, 2), "utf8");
    console.log("新版本已下载好，下次启动会自动更新：" + status.latestVersion);
    return { ok: true, prepared: true, ...prepared };
  } catch (error) {
    console.log("后台准备更新失败：" + (error?.message || String(error)));
    return { ok: false, error: error?.message || String(error) };
  } finally {
    await fs.rm(tempRoot, { recursive: true, force: true }).catch(() => {});
  }
}

export async function getPreparedOnlineUpdate(projectRoot = process.cwd()) {
  const rootDir = path.resolve(projectRoot);
  const pendingRoot = preparedUpdateRoot(rootDir);
  const metadata = await readJsonIfExists(path.join(pendingRoot, "pending-update.json"));
  const manifestPath = path.join(pendingRoot, "_patch", "patch-manifest.json");
  if (!metadata.ready || !await pathExists(manifestPath)) {
    return { ready: false };
  }
  const currentVersion = await readCurrentVersion(rootDir);
  if (metadata.latestVersion && compareVersions(currentVersion, metadata.latestVersion) >= 0) {
    await removePreparedOnlineUpdate(rootDir);
    return { ready: false, alreadyApplied: true, currentVersion };
  }
  return {
    ready: true,
    currentVersion,
    latestVersion: String(metadata.latestVersion || metadata.targetVersion || "").trim(),
    targetVersion: String(metadata.targetVersion || metadata.latestVersion || "").trim(),
    preparedAt: String(metadata.preparedAt || "").trim(),
    notes: Array.isArray(metadata.notes) ? metadata.notes : [],
    path: pendingRoot
  };
}

export async function installPreparedOnlineUpdate(projectRoot = process.cwd(), options = {}) {
  const rootDir = path.resolve(projectRoot);
  const prepared = await getPreparedOnlineUpdate(rootDir);
  if (!prepared.ready) return { ok: true, applied: false, ...prepared };

  const sourcePatchRoot = safeResolveInside(preparedUpdateRoot(rootDir), "_patch");
  const targetPatchRoot = safeResolveInside(rootDir, "_patch");
  try {
    await fs.rm(targetPatchRoot, { recursive: true, force: true });
    await fs.cp(sourcePatchRoot, targetPatchRoot, { recursive: true });
    const result = childProcess.spawnSync(process.execPath, [path.join(rootDir, "tools", "apply-patch.cjs")], {
      cwd: rootDir,
      encoding: "utf8",
      windowsHide: true
    });
    if (result.status !== 0) {
      const detail = (result.stderr || result.stdout || "").trim();
      throw new Error(detail || "补丁安装失败。");
    }
    await removePreparedOnlineUpdate(rootDir);
    return {
      ok: true,
      applied: true,
      currentVersion: prepared.currentVersion,
      latestVersion: prepared.latestVersion,
      message: result.stdout || ""
    };
  } catch (error) {
    if (!options.keepBrokenPatch) await fs.rm(targetPatchRoot, { recursive: true, force: true }).catch(() => {});
    return { ok: false, applied: false, error: error?.message || String(error), prepared };
  }
}

export async function removePreparedOnlineUpdate(projectRoot = process.cwd()) {
  await fs.rm(preparedUpdateRoot(path.resolve(projectRoot)), { recursive: true, force: true }).catch(() => {});
}

function getUpdateSourceUrl(config = {}) {
  return String(config.updateSourceUrl || process.env.FD_AUTO_TOOL_UPDATE_URL || "").trim();
}

async function readCurrentVersion(rootDir = process.cwd()) {
  try {
    const packageJson = JSON.parse(await fs.readFile(path.resolve(rootDir, "package.json"), "utf8"));
    return String(packageJson.version || "").trim() || "0.0.0";
  } catch {
    return "0.0.0";
  }
}

async function fetchUpdateManifest(updateSourceUrl) {
  const normalizedUrl = updateSourceUrl.replace(
    "https://raw.githubusercontent.com/wym-gif/fd-auto-tool-update/main/",
    "https://raw.githubusercontent.com/wym-gif/fd-auto-tool-update/refs/heads/main/"
  );
  const url = new URL(normalizedUrl);
  url.searchParams.set("_t", String(Date.now()));
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) throw new Error("更新源读取失败：" + response.status);
  return await response.json();
}

async function downloadFile(url, targetPath) {
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) throw new Error("补丁下载失败：" + response.status);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (!buffer.length) throw new Error("下载到的补丁文件为空。");
  await fs.writeFile(targetPath, buffer);
}

async function extractZip(zipPath, destination) {
  const result = childProcess.spawnSync("tar", ["-xf", zipPath, "-C", destination], {
    cwd: process.cwd(),
    encoding: "utf8"
  });
  if (result.status !== 0) {
    const detail = (result.stderr || result.stdout || "").trim();
    throw new Error("补丁解压失败。" + (detail ? "\n" + detail : ""));
  }
}

async function findExtractedPatchRoot(baseDir) {
  const direct = path.join(baseDir, "_patch");
  if (await pathExists(path.join(direct, "patch-manifest.json"))) return direct;
  const entries = await fs.readdir(baseDir, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const candidate = path.join(baseDir, entry.name, "_patch");
    if (await pathExists(path.join(candidate, "patch-manifest.json"))) return candidate;
  }
  return "";
}

async function pathExists(file) {
  try {
    await fs.access(file);
    return true;
  } catch {
    return false;
  }
}

async function readJsonIfExists(file) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch {
    return {};
  }
}

function preparedUpdateRoot(rootDir) {
  return safeResolveInside(rootDir, "_pending-update");
}

function safeResolveInside(base, rel) {
  const resolved = path.resolve(base, rel);
  const root = path.resolve(base);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) {
    throw new Error("更新路径不安全：" + rel);
  }
  return resolved;
}

export function compareVersions(left, right) {
  const a = String(left || "0").split(".").map((item) => Number.parseInt(item, 10) || 0);
  const b = String(right || "0").split(".").map((item) => Number.parseInt(item, 10) || 0);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index += 1) {
    const diff = (a[index] || 0) - (b[index] || 0);
    if (diff !== 0) return diff > 0 ? 1 : -1;
  }
  return 0;
}

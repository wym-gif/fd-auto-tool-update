import { execFile, spawn } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import {
  checkOnlineUpdate,
  getPreparedOnlineUpdate,
  installOnlineUpdate,
  installPreparedOnlineUpdate,
  prepareOnlineUpdate
} from "../../update/online-update.js";

const execFileAsync = promisify(execFile);

export const DEFAULT_BACKUP_ROOT_NAME = "版本备份";
export const STABLE_BACKUP_PREFIX = "fd-auto-tool-2.0-stable";
export const BACKUP_NOTE_FILE = "BACKUP-NOTE.md";

const EXCLUDED_DIRS = new Set([
  ".git",
  "node_modules",
  "runs",
  "preview-library",
  "browser-profile",
  "browser-profile-cms",
  "browser-profile-cms-manual",
  "media-cache",
  "logs",
  "backups",
  ".tmp-preview-ui-test",
  "_patch"
]);

const EXCLUDED_FILES = new Set([
  "config.json",
  "license.json",
  ".env",
  "last-settings.json",
  "last-console-settings.json",
  "cms-page-settings.json",
  "latest-preview.json",
  "watch-preview-last.log",
  "preview-last.log",
  "run-last.log"
]);

const SENSITIVE_NAME_RE = /(cookie|cookies|session|token|secret|password)/i;

export async function getVersionStatus(projectRoot, options = {}) {
  const packageJson = await readJsonIfExists(path.join(projectRoot, "package.json"));
  const updateConfig = await readUpdateConfig(projectRoot);
  const onlineStatus = updateConfig.updateSourceUrl ? await safeOnlineUpdateStatus(projectRoot, updateConfig) : null;
  const preparedUpdate = updateConfig.updateSourceUrl ? await getPreparedOnlineUpdate(projectRoot) : { ready: false };
  const remoteUrl = await gitText(projectRoot, ["remote", "get-url", "origin"]);
  const currentCommit = await gitText(projectRoot, ["rev-parse", "--short", "HEAD"]);
  const currentCommitFull = await gitText(projectRoot, ["rev-parse", "HEAD"]);
  const currentBranch = await gitText(projectRoot, ["branch", "--show-current"]);
  const localStatus = await gitText(projectRoot, ["status", "--porcelain"]);
  const latestStableTag = firstLine(await gitText(projectRoot, ["tag", "--list", "v*", "--sort=-version:refname"]));
  const latestRemoteVersion = preparedUpdate.ready
    ? preparedUpdate.latestVersion
    : onlineStatus?.latestVersion || (remoteUrl ? await latestRemoteStableTag(projectRoot) : "");
  const currentDisplayVersion = displayVersion(packageJson.version || "");
  const latestRemoteDisplayVersion = displayVersion(latestRemoteVersion);
  const gitUpdateAvailable = Boolean(
    latestRemoteVersion &&
    packageJson.version &&
    compareVersionTags(latestRemoteVersion, normalizeVersionTag(packageJson.version)) > 0
  );
  const updateAvailable = Boolean(preparedUpdate.ready || onlineStatus?.hasUpdate || gitUpdateAvailable);
  const backupRoot = backupRootFor(projectRoot, options);
  const backups = await listBackups(projectRoot, options);

  return {
    currentVersion: packageJson.version || "",
    currentDisplayVersion,
    currentCommit: currentCommit || "未提交",
    currentCommitFull: currentCommitFull || "",
    currentBranch: currentBranch || "",
    projectDir: projectRoot,
    hasGitRemote: Boolean(remoteUrl),
    hasUpdateSource: Boolean(updateConfig.updateSourceUrl),
    remoteUrl: updateConfig.updateSourceUrl || remoteUrl,
    updateSourceUrl: updateConfig.updateSourceUrl || "",
    updateMode: updateConfig.updateSourceUrl ? "patch" : "git",
    latestRemoteVersion,
    latestRemoteDisplayVersion,
    updateAvailable,
    pendingUpdateReady: Boolean(preparedUpdate.ready),
    preparedUpdate,
    hasLocalChanges: Boolean(localStatus.trim()),
    latestBackup: backups[0] || null,
    latestStableTag: latestStableTag || "",
    backupRoot
  };
}

export async function createStableBackup(projectRoot, options = {}) {
  const backupRoot = backupRootFor(projectRoot, options);
  const backupName = options.name || `${STABLE_BACKUP_PREFIX}-${dateStamp(options.now)}`;
  const targetDir = path.join(backupRoot, backupName);
  await fs.mkdir(backupRoot, { recursive: true });
  if (await exists(targetDir)) {
    throw new Error(`备份目录已存在：${targetDir}`);
  }
  await fs.mkdir(targetDir, { recursive: true });
  await fs.cp(projectRoot, targetDir, {
    recursive: true,
    force: false,
    errorOnExist: false,
    filter: (source) => shouldCopyPath(projectRoot, source)
  });
  await fs.writeFile(path.join(targetDir, BACKUP_NOTE_FILE), buildBackupNote({
    projectRoot,
    backupName,
    backupTime: new Date(options.now || Date.now()),
    status: options.status || "可正常使用",
    confirmedFeatures: options.confirmedFeatures || defaultConfirmedFeatures(),
    knownLimits: options.knownLimits || defaultKnownLimits()
  }), "utf8");
  return {
    ok: true,
    backupName,
    backupPath: targetDir,
    notePath: path.join(targetDir, BACKUP_NOTE_FILE)
  };
}

export async function listBackups(projectRoot, options = {}) {
  const backupRoot = backupRootFor(projectRoot, options);
  const entries = await fs.readdir(backupRoot, { withFileTypes: true }).catch(() => []);
  const backups = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || !entry.name.startsWith(STABLE_BACKUP_PREFIX)) continue;
    const fullPath = path.join(backupRoot, entry.name);
    const stat = await fs.stat(fullPath).catch(() => null);
    backups.push({
      name: entry.name,
      path: fullPath,
      mtime: stat?.mtime?.toISOString?.() || ""
    });
  }
  backups.sort((a, b) => b.name.localeCompare(a.name) || b.mtime.localeCompare(a.mtime));
  return backups;
}

export async function updateToLatestVersion(projectRoot, options = {}) {
  const updateConfig = await readUpdateConfig(projectRoot);
  if (updateConfig.updateSourceUrl) {
    const prepared = await installPreparedOnlineUpdate(projectRoot);
    if (!prepared.ok) throw new Error(prepared.error || "已下载更新安装失败。");
    const result = prepared.applied
      ? prepared
      : await runInProjectRoot(projectRoot, () => installOnlineUpdate(updateConfig));
    if (!result.ok) throw new Error(result.error || "在线补丁更新失败。");
    return {
      ok: true,
      action: "update",
      updateMode: "patch",
      onlineUpdate: result,
      status: await getVersionStatus(projectRoot, options)
    };
  }

  const backup = await createStableBackup(projectRoot, {
    ...options,
    name: options.backupName || `${STABLE_BACKUP_PREFIX}-before-update-${dateTimeStamp()}`
  });
  await runGit(projectRoot, ["fetch", "--tags", "origin"]);
  await runGit(projectRoot, ["checkout", "main"]);
  await runGit(projectRoot, ["pull", "--ff-only", "origin", "main"]);
  await runCommand(projectRoot, options.installCommand || "npm", options.installArgs || ["install"]);
  await runCommand(projectRoot, options.checkCommand || "npm", options.checkArgs || ["test"]);
  return {
    ok: true,
    action: "update",
    backup,
    status: await getVersionStatus(projectRoot, options)
  };
}

export async function prepareLatestVersionUpdate(projectRoot, options = {}) {
  const updateConfig = await readUpdateConfig(projectRoot);
  if (!updateConfig.updateSourceUrl) {
    return { ok: false, error: "还没有配置更新地址，不能后台下载更新。" };
  }
  const result = await runInProjectRoot(projectRoot, () => prepareOnlineUpdate(updateConfig, { projectRoot }));
  return {
    ...result,
    status: await getVersionStatus(projectRoot, options)
  };
}

export async function rollbackToPreviousStableVersion(projectRoot, options = {}) {
  const backup = await createStableBackup(projectRoot, {
    ...options,
    name: options.backupName || `${STABLE_BACKUP_PREFIX}-before-rollback-${dateTimeStamp()}`
  });
  await runGit(projectRoot, ["fetch", "--tags", "origin"]).catch(() => {});
  const currentTag = await currentExactTag(projectRoot);
  const tags = (await gitText(projectRoot, ["tag", "--list", "v*", "--sort=-version:refname"]))
    .split(/\r?\n/)
    .map((tag) => tag.trim())
    .filter(Boolean);
  const currentIndex = currentTag ? tags.indexOf(currentTag) : -1;
  const targetTag = currentIndex >= 0 ? tags[currentIndex + 1] : tags[1] || tags[0] || "";
  if (!targetTag) throw new Error("没有找到可回退的稳定 tag。");
  await runGit(projectRoot, ["checkout", targetTag]);
  await runCommand(projectRoot, options.installCommand || "npm", options.installArgs || ["install"]);
  await runCommand(projectRoot, options.checkCommand || "npm", options.checkArgs || ["test"]);
  return {
    ok: true,
    action: "rollback",
    backup,
    rolledBackTo: targetTag,
    status: await getVersionStatus(projectRoot, options)
  };
}

export async function openBackupDir(projectRoot, options = {}) {
  const backupRoot = backupRootFor(projectRoot, options);
  await fs.mkdir(backupRoot, { recursive: true });
  if (process.platform === "win32") {
    const child = spawn("explorer.exe", [backupRoot], {
      detached: true,
      stdio: "ignore",
      windowsHide: false
    });
    child.unref();
  }
  return { ok: true, backupRoot };
}

export function backupRootFor(projectRoot, options = {}) {
  return path.resolve(projectRoot, options.backupRoot || path.join(path.dirname(projectRoot), DEFAULT_BACKUP_ROOT_NAME));
}

export function shouldCopyPath(projectRoot, sourcePath) {
  const relative = path.relative(projectRoot, sourcePath);
  if (!relative) return true;
  const parts = relative.split(path.sep).filter(Boolean);
  if (parts.some((part) => EXCLUDED_DIRS.has(part))) return false;
  const base = path.basename(sourcePath);
  if (EXCLUDED_FILES.has(base)) return false;
  if (base.endsWith(".zip")) return false;
  if (SENSITIVE_NAME_RE.test(base)) return false;
  if (parts.includes("客户数据") || parts.includes("用户本地素材")) return false;
  return true;
}

function buildBackupNote({ projectRoot, backupName, backupTime, status, confirmedFeatures, knownLimits }) {
  return [
    "# BACKUP NOTE",
    "",
    `- 备份名称：${backupName}`,
    `- 备份时间：${formatDateTime(backupTime)}`,
    `- 来源目录：${projectRoot}`,
    `- 当前版本状态：${status}`,
    "",
    "## 已确认功能",
    "",
    ...confirmedFeatures.map((item) => `- ${item}`),
    "",
    "## 仍需后续优化的问题",
    "",
    ...knownLimits.map((item) => `- ${item}`),
    "",
    "## 恢复方式",
    "",
    "1. 停止当前 2.0 控制台服务。",
    "2. 将本备份目录中的代码复制回项目目录。",
    "3. 保留现有 config.json、runs、browser-profile 等本地运行数据，除非明确要恢复干净环境。",
    "4. 在项目目录执行 npm install。",
    "5. 运行 npm test 做基础检查。",
    "",
    "## 启动方式",
    "",
    "- 正式入口：双击 2.0可视化控制台.bat。",
    "- 调试入口：双击 2.0可视化控制台-调试版.bat。",
    "- 控制台会启动或复用 2.0 专用可控 Chrome。",
    ""
  ].join("\n");
}

function defaultConfirmedFeatures() {
  return [
    "2.0 可视化控制台可启动并连接专用可控 Chrome。",
    "飞书文档采集、范围解析、预览生成链路可用。",
    "预览页支持人工编辑、批量操作和自动保存预览内容。",
    "正式创建只读取已确认的预览内容。",
    "云中客只复用托页面和豆妈页面两个创建任务页。",
    "图片、视频、表情包创建前会校验本地素材文件。",
    "采集去重只用于重复采集块，不删除正文内部空行和重复文案。",
    "过期定时弹窗可点击“是”并对后续未创建任务做运行时顺延。"
  ];
}

function defaultKnownLimits() {
  return [
    "任务列表 joblist 不参与 2.0 自动创建流程。",
    "日期规则后续应抽成 src/v2/date/date-rules.js。",
    "公司授权能力当前为预留结构，后续需要接入真实 license key、公司账号或设备绑定。",
    "正式大批量使用中仍需观察飞书 DOM 变化、CMS 弹窗变化和素材下载稳定性。"
  ];
}

async function latestRemoteStableTag(projectRoot) {
  const output = await gitText(projectRoot, ["ls-remote", "--tags", "--refs", "origin", "v*"]);
  const tags = output
    .split(/\r?\n/)
    .map((line) => line.trim().split(/\s+/)[1] || "")
    .map((ref) => ref.replace(/^refs\/tags\//, ""))
    .filter(Boolean)
    .sort(compareVersionTags)
    .reverse();
  return tags[0] || "";
}

async function readUpdateConfig(projectRoot) {
  const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
  const example = await readJsonIfExists(path.join(projectRoot, "config.example.json"));
  return {
    ...example,
    ...config,
    updateSourceUrl: String(config.updateSourceUrl || example.updateSourceUrl || "").trim()
  };
}

async function safeOnlineUpdateStatus(projectRoot, config) {
  try {
    return await runInProjectRoot(projectRoot, () => checkOnlineUpdate(config));
  } catch {
    return null;
  }
}

async function runInProjectRoot(projectRoot, callback) {
  const cwd = process.cwd();
  try {
    process.chdir(projectRoot);
    return await callback();
  } finally {
    process.chdir(cwd);
  }
}

async function currentExactTag(projectRoot) {
  return firstLine(await gitText(projectRoot, ["describe", "--tags", "--exact-match"]));
}

function compareVersionTags(a, b) {
  const aa = versionParts(a);
  const bb = versionParts(b);
  for (let index = 0; index < Math.max(aa.length, bb.length); index += 1) {
    const diff = (aa[index] || 0) - (bb[index] || 0);
    if (diff) return diff;
  }
  return a.localeCompare(b);
}

function versionParts(tag) {
  return String(tag || "").replace(/^v/i, "").split(".").map((part) => Number(part) || 0);
}

function normalizeVersionTag(version) {
  const text = String(version || "").trim();
  if (!text) return "";
  return text.startsWith("v") || text.startsWith("V") ? text : `v${text}`;
}

function displayVersion(version) {
  return String(version || "").trim().replace(/^v/i, "");
}

async function runGit(projectRoot, args) {
  return runCommand(projectRoot, "git", args);
}

async function gitText(projectRoot, args) {
  try {
    const result = await runGit(projectRoot, args);
    return String(result.stdout || "").trim();
  } catch {
    return "";
  }
}

async function runCommand(projectRoot, command, args = []) {
  try {
    return await execFileAsync(command, args, {
      cwd: projectRoot,
      windowsHide: true,
      maxBuffer: 20 * 1024 * 1024
    });
  } catch (error) {
    const output = [error.stdout, error.stderr].filter(Boolean).join("\n").trim();
    throw new Error(`${command} ${args.join(" ")} 失败${output ? `：${output}` : ""}`);
  }
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function firstLine(text) {
  return String(text || "").split(/\r?\n/).map((line) => line.trim()).find(Boolean) || "";
}

function dateStamp(now = Date.now()) {
  const date = new Date(now);
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0")
  ].join("");
}

function dateTimeStamp(now = Date.now()) {
  const date = new Date(now);
  return `${dateStamp(date)}_${String(date.getHours()).padStart(2, "0")}${String(date.getMinutes()).padStart(2, "0")}${String(date.getSeconds()).padStart(2, "0")}`;
}

function formatDateTime(date) {
  const pad = (value) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

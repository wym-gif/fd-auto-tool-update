import fs from "node:fs/promises";
import path from "node:path";
import { PREVIEW_TASK_REQUIRED_FIELDS, createPreviewTask, validatePreviewTaskShape } from "../contracts/preview-task.js";
import { isRemoteMediaPath, isTemporaryBrowserMediaPath, localizePreviewTaskMediaWithFetch } from "../media/media-cache.js";

export function previewTasksPath(runDir) {
  return path.join(runDir, "preview-tasks.json");
}

export function finalPreviewPath(runDir) {
  return path.join(runDir, "preview.json");
}

export async function findLatestV2FlowRun(runsRoot) {
  return findLatestPreviewTaskRun(runsRoot, { prefix: "v2_flow_" });
}

export async function findLatestV2RealFlowRun(runsRoot) {
  return findLatestPreviewTaskRun(runsRoot, { prefix: "v2_real_flow_" });
}

async function findLatestPreviewTaskRun(runsRoot, options = {}) {
  const entries = await fs.readdir(runsRoot, { withFileTypes: true }).catch(() => []);
  const candidates = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || !entry.name.startsWith(options.prefix || "v2_flow_")) continue;
    const runDir = path.join(runsRoot, entry.name);
    try {
      const stat = await fs.stat(previewTasksPath(runDir));
      candidates.push({ runDir, mtimeMs: stat.mtimeMs });
    } catch {
      continue;
    }
  }
  candidates.sort((a, b) => b.mtimeMs - a.mtimeMs || b.runDir.localeCompare(a.runDir));
  return candidates[0]?.runDir || null;
}

export async function loadPreviewForOpen(runDir, options = {}) {
  const previewPath = finalPreviewPath(runDir);
  if (!options.regenerate && await exists(previewPath)) {
    return {
      source: "preview.json",
      path: previewPath,
      tasks: applyPreviewDefaultDate(await readPreviewTasks(previewPath), options.defaultDate)
    };
  }

  const sourcePath = previewTasksPath(runDir);
  const tasks = applyPreviewDefaultDate(await readPreviewTasks(sourcePath), options.defaultDate);
  await saveFinalPreview(runDir, tasks);
  return {
    source: options.regenerate ? "preview-tasks.json regenerated preview.json" : "preview-tasks.json initialized preview.json",
    path: sourcePath,
    tasks
  };
}

export function applyPreviewDefaultDate(tasks, defaultDate = "") {
  const fallback = String(defaultDate || "").trim();
  const normalized = validatePreviewTasks(tasks);
  if (!fallback) return normalized;
  return normalized.map((task) => String(task.date || "").trim()
    ? task
    : { ...task, date: fallback });
}

export async function saveFinalPreview(runDir, tasks, options = {}) {
  let normalized = validatePreviewTasks(tasks);
  if (options.requireComplete === true) {
    normalized = await localizePreviewTaskMediaWithFetch(normalized, {
      runDir,
      mediaCacheDir: options.mediaCacheDir || path.join(runDir, "media-cache"),
      fetchImpl: options.fetchImpl
    });
    await validatePreviewTasksReadyForSave(normalized, { runDir });
  }
  const previewPath = finalPreviewPath(runDir);
  await fs.writeFile(previewPath, JSON.stringify(normalized, null, 2), "utf8");
  return {
    path: previewPath,
    tasks: normalized
  };
}

export async function loadFinalPreviewForCreate(runDir) {
  const previewPath = finalPreviewPath(runDir);
  if (!await exists(previewPath)) {
    throw new Error("创建前最终核对失败：没有找到已保存的预览内容，请先确认预览。");
  }
  return {
    source: "preview.json",
    path: previewPath,
    tasks: await readPreviewTasks(previewPath)
  };
}

export function comparePreviewTasks(leftTasks, rightTasks) {
  const left = validatePreviewTasks(leftTasks);
  const right = validatePreviewTasks(rightTasks);
  const errors = [];
  if (left.length !== right.length) {
    errors.push(`条数不一致：页面 ${left.length} 条，已保存的预览内容 ${right.length} 条`);
  }
  const count = Math.min(left.length, right.length);
  for (let index = 0; index < count; index += 1) {
    for (const field of PREVIEW_TASK_REQUIRED_FIELDS) {
      if (JSON.stringify(left[index][field]) !== JSON.stringify(right[index][field])) {
        errors.push(`第 ${index + 1} 条 ${field} 不一致`);
      }
    }
  }
  return {
    ok: errors.length === 0,
    errors
  };
}

export async function finalPreviewCheck(runDir, pageTasks) {
  await validatePreviewTasksReadyForSave(pageTasks, { runDir });
  const finalPreview = await loadFinalPreviewForCreate(runDir);
  await validatePreviewTasksReadyForSave(finalPreview.tasks, { runDir });
  const compare = comparePreviewTasks(pageTasks, finalPreview.tasks);
  if (!compare.ok) {
    throw new Error(`创建前最终核对失败：${compare.errors.join("；")}`);
  }
  return {
    ok: true,
    source: finalPreview.source,
    path: finalPreview.path,
    count: finalPreview.tasks.length
  };
}

export async function readPreviewTasks(filePath) {
  const tasks = JSON.parse(await fs.readFile(filePath, "utf8"));
  return validatePreviewTasks(tasks);
}

export function validatePreviewTasks(tasks) {
  if (!Array.isArray(tasks)) {
    throw new Error("PreviewTask 文件必须是数组。");
  }
  return tasks.map((task) => {
    const normalized = createPreviewTask({ ...task });
    if (isTemporaryBrowserMediaPath(normalized.sourceUrl)) {
      delete normalized.sourceUrl;
    }
    validatePreviewTaskShape(normalized);
    return normalized;
  });
}

export async function validatePreviewTasksReadyForSave(tasks, options = {}) {
  const normalized = validatePreviewTasks(tasks);
  const errors = [];
  for (const [index, task] of normalized.entries()) {
    if (task.skip) continue;
    const label = `第 ${index + 1} 条`;
    if (!String(task.role || "").trim()) errors.push(`${label} 缺少角色`);
    if (!String(task.date || "").trim()) errors.push(`${label} 缺少日期`);
    if (!validPreviewDate(task.date)) errors.push(`${label} 日期格式不合法：${task.date}`);
    if (!String(task.time || "").trim()) errors.push(`${label} 缺少时间`);
    if (!validPreviewTime(task.time)) errors.push(`${label} 时间格式不合法：${task.time}`);
    if (task.type === "text" || task.type === "finder") {
      if (!String(task.text || "").trim()) errors.push(`${label} ${task.type === "finder" ? "视频号参数" : "文字正文"}为空`);
      continue;
    }
    const mediaPath = String(task.mediaPath || "").trim();
    if (!mediaPath) {
      errors.push(`${label} 素材路径为空`);
      continue;
    }
    if (isTemporaryBrowserMediaPath(mediaPath)) {
      errors.push(`${label} 是浏览器临时素材地址，不能正式发单，请重新生成预览或点“更换素材”换成本地文件：${mediaPath}`);
      continue;
    }
    if (isRemoteMediaPath(mediaPath)) {
      const detail = task.mediaDownloadError ? `，下载失败：${task.mediaDownloadError}` : "";
      errors.push(`${label} 是远程素材地址未落地，不能正式发单${detail}：${mediaPath}`);
      continue;
    }
    if (!mediaExtensionLooksValid(mediaPath, task.type)) {
      errors.push(`${label} 素材类型不匹配：${task.type} / ${mediaPath}`);
    }
    if (isLocalMediaPath(mediaPath)) {
      try {
        const stat = await fs.stat(path.resolve(options.runDir || process.cwd(), mediaPath));
        if (!stat.isFile() || stat.size <= 0) errors.push(`${label} 素材文件无效：${mediaPath}`);
      } catch {
        errors.push(`${label} 素材不存在：${mediaPath}`);
      }
    }
  }
  if (errors.length) {
    throw new Error(`保存预览内容失败：${errors.join("；")}`);
  }
  return { ok: true, count: normalized.length };
}

function validPreviewDate(value) {
  const text = String(value || "").trim();
  return /^\d{1,2}\s*[\/月-]\s*\d{1,2}\s*日?$/.test(text) || /^\d{4}-\d{1,2}-\d{1,2}$/.test(text);
}

function validPreviewTime(value) {
  const match = String(value || "").trim().match(/^(\d{1,2})[:：](\d{1,2})(?:[:：](\d{1,2}))?$/);
  if (!match) return false;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  const second = Number(match[3] || 0);
  return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59 && second >= 0 && second <= 59;
}

function isLocalMediaPath(mediaPath) {
  if (isTemporaryBrowserMediaPath(mediaPath)) return false;
  if (/^[a-z]+:\/\//i.test(mediaPath)) return false;
  if (/^data:/i.test(mediaPath)) return false;
  if (/^sample:\/\//i.test(mediaPath)) return false;
  return Boolean(mediaPath);
}

function mediaExtensionLooksValid(mediaPath, type) {
  if (/^sample:\/\//i.test(mediaPath)) return true;
  const ext = path.extname(mediaPath).toLowerCase();
  if (type === "image") return [".jpg", ".jpeg", ".png", ".webp", ".gif"].includes(ext);
  if (type === "sticker") return [".gif", ".png", ".webp", ".jpg", ".jpeg"].includes(ext);
  if (type === "video") return [".mp4", ".mov", ".webm"].includes(ext);
  return false;
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

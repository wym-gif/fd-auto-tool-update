import fs from "node:fs/promises";
import path from "node:path";
import { findLatestV2PreviewRun, runCreatePreflight } from "./create-preflight.js";

export async function runCreateDryRun(runDir, options = {}) {
  const preflight = await runCreatePreflight(runDir, options);
  const plan = buildCreatePlan(preflight);
  const runId = path.basename(path.resolve(runDir));
  const planPath = path.join(runDir, "create-plan.json");
  const planMetaPath = path.join(runDir, "create-plan-meta.json");
  const logPath = path.join(runDir, "create-dry-run.log");
  const log = buildCreateDryRunLog(preflight, plan);
  await fs.writeFile(planPath, JSON.stringify(plan, null, 2), "utf8");
  await fs.writeFile(planMetaPath, JSON.stringify({
    runId,
    runDir,
    previewPath: preflight.path,
    createdAt: new Date().toISOString(),
    total: preflight.total,
    skipped: preflight.skipped,
    createCount: preflight.createCount
  }, null, 2), "utf8");
  await fs.writeFile(logPath, log, "utf8");
  return {
    ok: true,
    runId,
    source: preflight.source,
    previewPath: preflight.path,
    runDir,
    planPath,
    planMetaPath,
    logPath,
    total: preflight.total,
    skipped: preflight.skipped,
    createCount: preflight.createCount,
    plan,
    log
  };
}

export async function findLatestV2DryRunSource(runsRoot) {
  return findLatestV2PreviewRun(runsRoot);
}

export function buildCreatePlan(preflight) {
  return preflight.createTasks.map((task, index) => ({
    index: index + 1,
    sourceOrder: task.order,
    sourceId: task.sourceId,
    sourceText: task.sourceText,
    role: task.role,
    speaker: task.speaker,
    date: task.date,
    time: task.time,
    type: task.type,
    text: task.text,
    mediaPath: task.mediaPath,
    interactionGroup: task.interactionGroup,
    continueMarker: task.continueMarker,
    cleanSpeaker: task.cleanSpeaker,
    tuoAssignment: task.tuoAssignment || null,
    action: actionForTask(task),
    summary: summaryForTask(task)
  }));
}

export function buildCreateDryRunLog(preflight, plan) {
  return [
    "2.0 CMS 创建演练",
    "",
    `创建演练来源：${displayPreviewSource(preflight.source)}`,
    `预览内容文件：${preflight.path}`,
    `预览总数：${preflight.total}`,
    `跳过不发：${preflight.skipped}`,
    `待创建：${preflight.createCount}`,
    "",
    "创建动作日志：",
    ...plan.map(formatPlanLine),
    "",
    "演练完成：没有打开云中客，没有创建任务。"
  ].join("\n");
}

function displayPreviewSource(source) {
  return source === "preview.json" ? "已保存的预览内容" : source;
}

export function buildCreateDryRunReport(result) {
  return [
    result.log,
    "",
    `create-plan.json：${result.planPath}`,
    `create-dry-run.log：${result.logPath}`
  ].join("\n");
}

function formatPlanLine(item) {
  return `第 ${item.index} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.date || ""} ${item.time || ""} / ${item.type} / ${item.summary} / sourceId=${item.sourceId || ""}`;
}

function actionForTask(task) {
  if (task.type === "text") return "createTextTask";
  if (task.type === "finder") return "createFinderTask";
  if (task.type === "image") return "createImageTask";
  if (task.type === "sticker") return "createStickerTask";
  if (task.type === "video") return "createVideoTask";
  return "unknown";
}

function summaryForTask(task) {
  const value = task.type === "text" || task.type === "finder" ? task.text : task.mediaPath;
  return compact(value);
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "";
}

function compact(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > 60 ? `${text.slice(0, 59)}...` : text;
}

import { ensureMediaReadyBeforeSubmit } from "./media-ready-guard.js";
import { fillTextWithReadbackGuard } from "./text-input-guard.js";
import { findLatestV2DryRunSource, runCreateDryRun } from "./create-plan.js";

export async function runPageActionCheck(runDir, page, control = {}, options = {}) {
  const dryRun = options.dryRunResult || await runCreateDryRun(runDir, options);
  const logs = [
    "2.0 页面动作校验",
    "",
    "页面动作校验来源：已保存的预览内容 -> 创建前校对 -> 创建计划",
    `预览总数：${dryRun.total}`,
    `跳过不发：${dryRun.skipped}`,
    `待创建：${dryRun.createCount}`,
    ""
  ];
  const results = [];

  for (const item of dryRun.plan) {
    await checkpoint(control, `第 ${item.index} 条开始前`);
    logs.push(formatStartLine(item));
    if (item.type === "text") {
      const textResult = await fillTextWithReadbackGuard(page, item.text);
      await checkpoint(control, `第 ${item.index} 条点击创建前`);
      await assertSubmitBlocked(page, item);
      const line = `第 ${item.index} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.type} / 输入校验通过(${textResult.method})`;
      logs.push(line);
      results.push({ ...item, ok: true, guard: "text", method: textResult.method });
      continue;
    }
    if (item.type === "finder") {
      const finderResult = await fillTextWithReadbackGuard({
        fillTextInput: (text) => page.fillFinderFeedInput ? page.fillFinderFeedInput(text) : page.fillTextInput(text),
        clearTextInput: () => page.clearFinderFeedInput ? page.clearFinderFeedInput() : page.clearTextInput(),
        readTextInput: () => page.readFinderFeedInput ? page.readFinderFeedInput() : page.readTextInput(),
        writeClipboardText: (text) => page.writeClipboardText(text),
        pasteText: () => page.pasteFinderFeedText ? page.pasteFinderFeedText() : page.pasteText()
      }, item.text);
      await checkpoint(control, `第 ${item.index} 条点击创建前`);
      await assertSubmitBlocked(page, item);
      const line = `第 ${item.index} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.type} / 视频号参数校验通过(${finderResult.method})`;
      logs.push(line);
      results.push({ ...item, ok: true, guard: "finder", method: finderResult.method });
      continue;
    }

    await checkpoint(control, `第 ${item.index} 条上传前`);
    const mediaResult = await ensureMediaReadyBeforeSubmit(page, item.mediaPath, {
      ...(options.media || {}),
      taskType: item.type
    });
    await checkpoint(control, `第 ${item.index} 条点击创建前`);
    await assertSubmitBlocked(page, item);
    const line = `第 ${item.index} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.type} / 媒体就绪通过 / ${mediaResult.mediaPath}`;
    logs.push(line);
    results.push({ ...item, ok: true, guard: "media", status: mediaResult.status });
  }

  logs.push("");
  logs.push("页面动作校验完成：没有打开真实云中客，没有创建任务。");
  return {
    ok: true,
    source: dryRun.source,
    runDir: dryRun.runDir,
    total: dryRun.total,
    skipped: dryRun.skipped,
    createCount: dryRun.createCount,
    results,
    log: logs.join("\n")
  };
}

export async function findLatestV2PageActionSource(runsRoot) {
  return findLatestV2DryRunSource(runsRoot);
}

async function assertSubmitBlocked(page, item) {
  if (page.assertNoRealSubmit) {
    await page.assertNoRealSubmit(item);
  }
}

async function checkpoint(control, label) {
  if (!control?.checkpoint) return;
  await control.checkpoint(label);
}

function formatStartLine(item) {
  const summary = item.type === "text" || item.type === "finder" ? item.summary : item.mediaPath;
  return `准备第 ${item.index} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.date || ""} ${item.time || ""} / ${item.type} / ${summary}`;
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "";
}

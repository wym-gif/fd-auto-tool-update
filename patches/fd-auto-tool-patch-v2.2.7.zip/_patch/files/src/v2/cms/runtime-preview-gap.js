export function createRuntimeScheduleBaseline(plan = []) {
  return plan.map((task) => ({
    submitIdentity: String(task?.submitIdentity || ""),
    index: Number(task?.index || 0),
    date: String(task?.date || ""),
    time: String(task?.time || "")
  }));
}

export function applyPersistedRuntimePlan(plan = [], persistedPlan = []) {
  const byIdentity = new Map((persistedPlan || [])
    .filter((task) => task?.submitIdentity)
    .map((task) => [String(task.submitIdentity), task]));
  for (const task of plan) {
    const persisted = byIdentity.get(String(task?.submitIdentity || ""));
    if (!persisted) continue;
    task.date = String(persisted.date || "");
    task.time = String(persisted.time || "");
  }
  return plan;
}

export function assertRuntimeScheduleCompatible(currentPlan = [], state = {}) {
  if (!state || state.version !== 2) throw runtimeStateError("运行时排程状态版本无效");
  if (!Array.isArray(state.baseline)) throw runtimeStateError("运行时排程缺少 baseline");
  if (!Array.isArray(state.plan)) throw runtimeStateError("运行时排程缺少 plan");
  if (!Array.isArray(state.events)) throw runtimeStateError("运行时排程缺少 events");
  if (!Object.hasOwn(state, "offsetSeconds")) throw runtimeStateError("运行时排程缺少 offsetSeconds");

  const baseline = indexScheduleEntries(state.baseline, "baseline");
  const persisted = indexScheduleEntries(state.plan, "plan");
  const current = indexScheduleEntries(currentPlan, "当前最终预览计划");
  assertSameIdentities(baseline, persisted, "保存的 baseline 与 plan 任务集合不一致");
  assertSameIdentities(baseline, current, "当前最终预览任务集合已变化");

  for (const [identity, original] of baseline) {
    const task = current.get(identity);
    if (task.date !== original.date || task.time !== original.time) {
      throw runtimeStateError(`当前最终预览中任务 ${identity} 的日期或时间已变化（原 ${formatSchedule(original)}，现 ${formatSchedule(task)}）`);
    }
  }
  return true;
}

export function shiftRemainingScheduleByPreviewOffset({
  plan = [],
  baseline = [],
  currentPlanIndex = 0,
  anchorDate,
  fallbackGapSeconds
} = {}) {
  const anchor = new Date(anchorDate);
  if (Number.isNaN(anchor.getTime())) throw new Error("运行时顺延缺少有效的立即执行锚点时间。");
  const anchorSeconds = Math.floor(anchor.getTime() / 1000);
  const baselineByIdentity = new Map((baseline || []).map((item) => [String(item?.submitIdentity || ""), item]));
  const current = plan[currentPlanIndex];
  const remaining = plan.slice(currentPlanIndex + 1);
  const currentBaseline = baselineByIdentity.get(String(current?.submitIdentity || "")) || current;
  const currentPreviewSeconds = previewTaskTimestampSeconds(currentBaseline, anchor);
  const validRemaining = remaining.map((task) => {
    const original = baselineByIdentity.get(String(task?.submitIdentity || "")) || task;
    return { task, original, previewSeconds: previewTaskTimestampSeconds(original, anchor) };
  });

  let offsetSeconds = currentPreviewSeconds === null ? null : anchorSeconds - currentPreviewSeconds;
  if (offsetSeconds === null) {
    const firstValid = validRemaining.find((item) => item.previewSeconds !== null);
    if (firstValid) {
      const fallback = positiveGap(fallbackGapSeconds?.(current, firstValid.task));
      offsetSeconds = anchorSeconds + fallback - firstValid.previewSeconds;
    }
  }

  if (offsetSeconds !== null) {
    const impossible = validRemaining.find((item) => item.previewSeconds !== null && item.previewSeconds + offsetSeconds <= anchorSeconds);
    if (impossible) {
      const error = new Error(`第 ${impossible.task?.index || "?"} 条原始发送时间不晚于已立即执行的第 ${current?.index || "?"} 条，无法在保持最终预览发送时间关系的同时安排到当前可执行时间之后。已停止，请人工调整预览后单独新建一轮。`);
      error.code = "CMS_RUNTIME_SCHEDULE_CONFLICT";
      error.taskIndex = impossible.task?.index;
      throw error;
    }
  }

  const adjustedTasks = [];
  let cursorSeconds = anchorSeconds;
  let previous = current;
  for (const item of validRemaining) {
    const oldDate = item.task.date || "";
    const oldTime = item.task.time || "";
    let targetSeconds;
    let fallbackSeconds = null;
    let basis;
    if (item.previewSeconds !== null && offsetSeconds !== null) {
      targetSeconds = item.previewSeconds + offsetSeconds;
      basis = "preview_fixed_offset";
    } else {
      fallbackSeconds = positiveGap(fallbackGapSeconds?.(previous, item.task));
      targetSeconds = Math.max(anchorSeconds, cursorSeconds) + fallbackSeconds;
      basis = "default_interval_fallback";
    }
    const next = dateTimeFromTimestampSeconds(targetSeconds);
    item.task.date = next.date;
    item.task.time = next.time;
    adjustedTasks.push({
      index: item.task.index,
      submitIdentity: item.task.submitIdentity,
      role: item.task.role,
      speaker: item.task.speaker,
      type: item.task.type,
      oldDate,
      oldTime,
      previewDate: item.original?.date || "",
      previewTime: item.original?.time || "",
      newDate: next.date,
      newTime: next.time,
      offsetSeconds,
      relativeToAnchorSeconds: item.previewSeconds !== null && currentPreviewSeconds !== null
        ? item.previewSeconds - currentPreviewSeconds
        : null,
      fallbackGapSeconds: fallbackSeconds,
      basis,
      adjusted: oldDate !== next.date || oldTime !== next.time,
      reason: basis === "preview_fixed_offset"
        ? "按最终保存预览基线应用同一固定偏移"
        : "原始日期或时间缺失/无效，使用默认间隔兜底"
    });
    cursorSeconds = targetSeconds;
    previous = item.task;
  }

  return {
    range: {
      first: remaining[0]?.index ?? null,
      last: remaining.at(-1)?.index ?? null
    },
    offsetSeconds,
    adjustedTasks
  };
}

export function previewTaskTimestampSeconds(task, referenceDate = new Date()) {
  const time = parseClock(task?.time);
  const date = parsePreviewDate(task?.date, referenceDate);
  if (!time || !date) return null;
  const value = new Date(date.year, date.month - 1, date.day, time.hour, time.minute, time.second, 0);
  if (value.getFullYear() !== date.year || value.getMonth() !== date.month - 1 || value.getDate() !== date.day) return null;
  return Math.floor(value.getTime() / 1000);
}

function parsePreviewDate(value, referenceDate) {
  const text = String(value || "").trim();
  const full = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (full) return { year: Number(full[1]), month: Number(full[2]), day: Number(full[3]) };
  const short = text.match(/^(\d{1,2})\s*[\/月-]\s*(\d{1,2})(?:日)?$/);
  if (!short) return null;
  const month = Number(short[1]);
  const day = Number(short[2]);
  const reference = new Date(referenceDate);
  const years = [reference.getFullYear() - 1, reference.getFullYear(), reference.getFullYear() + 1];
  const candidates = years
    .map((year) => new Date(year, month - 1, day))
    .filter((date) => date.getMonth() === month - 1 && date.getDate() === day)
    .sort((left, right) => Math.abs(left.getTime() - reference.getTime()) - Math.abs(right.getTime() - reference.getTime()));
  const selected = candidates[0];
  return selected ? { year: selected.getFullYear(), month, day } : null;
}

function parseClock(value) {
  const match = String(value || "").trim().match(/^(\d{1,2})[:：](\d{1,2})(?:[:：](\d{1,2}))?$/);
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  const second = Number(match[3] || 0);
  if (hour > 23 || minute > 59 || second > 59) return null;
  return { hour, minute, second };
}

function dateTimeFromTimestampSeconds(seconds) {
  const date = new Date(Math.round(seconds) * 1000);
  const pad = (value) => String(value).padStart(2, "0");
  return {
    date: `${date.getMonth() + 1}/${date.getDate()}`,
    time: `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
  };
}

function positiveGap(value) {
  const number = Math.round(Number(value));
  return Number.isFinite(number) && number > 0 ? number : 1;
}

function indexScheduleEntries(entries, label) {
  const indexed = new Map();
  for (const entry of entries) {
    if (!entry || typeof entry !== "object") throw runtimeStateError(`${label} 含有无效任务项`);
    const identity = typeof entry.submitIdentity === "string" ? entry.submitIdentity.trim() : "";
    if (!identity) throw runtimeStateError(`${label} 存在缺少 submitIdentity 的任务`);
    if (!Object.hasOwn(entry, "date") || typeof entry.date !== "string") throw runtimeStateError(`${label} 中任务 ${identity} 缺少有效 date 字段`);
    if (!Object.hasOwn(entry, "time") || typeof entry.time !== "string") throw runtimeStateError(`${label} 中任务 ${identity} 缺少有效 time 字段`);
    if (indexed.has(identity)) throw runtimeStateError(`${label} 中任务身份 ${identity} 重复`);
    indexed.set(identity, { identity, date: entry.date, time: entry.time });
  }
  return indexed;
}

function assertSameIdentities(expected, actual, message) {
  if (expected.size !== actual.size || [...expected.keys()].some((identity) => !actual.has(identity))) {
    throw runtimeStateError(message);
  }
}

function formatSchedule(task = {}) {
  return `${task.date || "空日期"} ${task.time || "空时间"}`;
}

function runtimeStateError(reason) {
  const error = new Error(`已保存的运行时排程不能用于当前最终预览：${reason}。为避免混用新旧时间，本次已在执行任何 CMS 页面动作前停止；请核对预览并单独新建一轮。`);
  error.code = "CMS_RUNTIME_SCHEDULE_BASELINE_MISMATCH";
  return error;
}

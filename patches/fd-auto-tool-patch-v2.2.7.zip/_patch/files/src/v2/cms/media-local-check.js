import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { readImageSize } from "../media/image-size.js";
import { loadFinalPreviewForCreate } from "../preview/preview-store.js";

const MEDIA_TYPES = new Set(["image", "sticker", "video"]);
const IMAGE_RISK_TYPES = new Set(["image", "sticker"]);
const DEFAULT_IMAGE_WARNING_BYTES = 10 * 1024 * 1024;
const DEFAULT_IMAGE_WARNING_EDGE = 4096;
const DEFAULT_IMAGE_WARNING_PIXELS = 12_000_000;
const DEFAULT_VIDEO_WARNING_BYTES = 10 * 1024 * 1024;

export async function runMediaLocalCheck(runDir, options = {}) {
  const finalPreview = await loadFinalPreviewForCreate(runDir);
  const mediaCacheDir = options.mediaCacheDir || path.join(runDir, "media-cache");
  const logPath = path.join(runDir, "media-local-check.log");
  const manifestPath = path.join(runDir, "media-local-check.json");
  const lines = [];

  const includeSourceIds = options.includeSourceIds ? new Set(options.includeSourceIds.map((value) => String(value || ""))) : null;
  const mediaTasks = finalPreview.tasks.filter((task) => {
    if (!MEDIA_TYPES.has(task.type)) return false;
    if (!includeSourceIds) return true;
    return includeSourceIds.has(String(task.sourceId || ""));
  });
  const activeMediaTasks = mediaTasks.filter((task) => !task.skip);
  const skippedMediaTasks = mediaTasks.filter((task) => task.skip);
  const items = [];
  const mediaErrors = [];

  lines.push("2.0 媒体下载/本地文件校验");
  lines.push(`来源：${finalPreview.path}`);
  lines.push(`预览总数：${finalPreview.tasks.length}`);
  lines.push(`媒体总数：${mediaTasks.length}`);
  lines.push(`跳过不发媒体：${skippedMediaTasks.length}`);
  lines.push(`待校验媒体：${activeMediaTasks.length}`);

  await fs.mkdir(mediaCacheDir, { recursive: true });

  for (const [index, task] of activeMediaTasks.entries()) {
    const previewIndex = finalPreview.tasks.indexOf(task);
    try {
      const item = await resolveMediaTask(task, previewIndex, mediaCacheDir, options, runDir);
      items.push(item);
      lines.push(formatMediaLogLine(item, index));
      for (const warning of item.riskWarnings || []) lines.push(`  风险提示：${warning}`);
    } catch (error) {
      const mediaError = buildMediaError(task, previewIndex, error);
      mediaErrors.push(mediaError);
      lines.push(`  素材错误：预览第 ${mediaError.previewIndex} 条：${mediaError.message}`);
      if (options.continueOnError !== true) {
        lines.push(`失败：${error?.message || error}`);
        await fs.writeFile(logPath, `${lines.join("\n")}\n`, "utf8");
        throw error;
      }
    }
  }

  const riskWarnings = items.flatMap((item) => (item.riskWarnings || []).map((message) => ({
    previewIndex: item.previewIndex,
    sourceId: item.sourceId,
    role: item.role,
    speaker: item.speaker,
    type: item.type,
    localPath: item.localPath,
    size: item.size,
    imageSize: item.imageSize || null,
    message
  })));
  const manifest = {
    source: "preview.json",
    previewPath: finalPreview.path,
    runDir,
    mediaCacheDir,
    total: finalPreview.tasks.length,
    mediaTotal: mediaTasks.length,
    skippedMedia: skippedMediaTasks.length,
    checkedCount: items.length,
    items,
    riskWarnings,
    mediaErrors
  };

  await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2), "utf8");
  if (riskWarnings.length) {
    lines.push(`预警：发现 ${riskWarnings.length} 个可能触发云中客上传失败或压缩弹窗的媒体素材。`);
    for (const warning of riskWarnings) lines.push(`  - 预览第 ${warning.previewIndex} 条：${warning.message}`);
  }
  if (mediaErrors.length) {
    lines.push(`错误：发现 ${mediaErrors.length} 个不能正式创建的媒体素材。`);
    for (const error of mediaErrors) lines.push(`  - 预览第 ${error.previewIndex} 条：${error.message}`);
  }
  lines.push(mediaErrors.length ? "校验完成：存在媒体错误，请先在预览页标红行处理。" : "校验通过：所有待发媒体都有本地文件。");
  await fs.writeFile(logPath, `${lines.join("\n")}\n`, "utf8");

  return {
    ok: true,
    ...manifest,
    manifestPath,
    logPath,
    skippedTasks: finalPreview.tasks.filter((task) => task.skip).length
  };
}

export async function loadMediaLocalManifest(runDir) {
  const manifestPath = path.join(runDir, "media-local-check.json");
  const manifest = JSON.parse(await fs.readFile(manifestPath, "utf8"));
  return { ...manifest, manifestPath };
}

export function resolveLocalMediaForTask(task, manifest) {
  const sourceId = String(task.sourceId || "");
  const sourceOrder = Number(task.sourceOrder || task.order || 0);
  const item = (manifest?.items || []).find((entry) => {
    if (sourceId && String(entry.sourceId || "") === sourceId) return true;
    return Number(entry.previewIndex || 0) === sourceOrder;
  });
  if (!item?.localPath) {
    throw new Error(`第 ${task.index || sourceOrder || "?"} 条素材没有本地校验记录，请先运行 2.0 媒体下载/本地文件校验。`);
  }
  return item.localPath;
}

export function buildMediaLocalCheckReport(result) {
  return [
    "2.0 媒体下载/本地文件校验",
    "",
    `媒体校验来源：${result.source}`,
    `预览内容文件：${result.previewPath}`,
    `预览总数：${result.total}`,
    `跳过不发：${result.skippedTasks}`,
    `媒体总数：${result.mediaTotal}`,
    `跳过不发媒体：${result.skippedMedia}`,
    `待校验媒体：${result.checkedCount}`,
    `素材错误：${(result.mediaErrors || []).length}`,
    `压缩风险：${(result.riskWarnings || []).length}`,
    "",
    "媒体校验列表：",
    ...result.items.map(formatMediaReportLine),
    ...((result.mediaErrors || []).length ? [
      "",
      "素材错误：",
      ...result.mediaErrors.map((item, index) =>
        `${index + 1}. 预览第 ${item.previewIndex} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.type} / ${item.message}`
      )
    ] : []),
    ...((result.riskWarnings || []).length ? [
      "",
      "压缩上传风险：",
      ...result.riskWarnings.map((item, index) =>
        `${index + 1}. 预览第 ${item.previewIndex} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.type} / ${item.message}`
      )
    ] : []),
    "",
    "校验通过：后续创建阶段可使用 media-local-check.json 里的本地素材映射。",
    "",
    `media-local-check.json：${result.manifestPath}`,
    `media-local-check.log：${result.logPath}`
  ].join("\n");
}

async function resolveMediaTask(task, previewIndex, mediaCacheDir, options, runDir) {
  const label = `第 ${previewIndex + 1} 条`;
  const mediaPath = String(task.mediaPath || "").trim();
  if (!mediaPath) {
    throw new Error(`${label} 素材路径为空`);
  }
  if (isBlobMediaPath(mediaPath)) {
    throw new Error(`${label} 是浏览器临时素材地址，不能正式创建，请先在预览页点“更换素材”换成本地文件：${mediaPath}`);
  }

  if (isRemoteMediaPath(mediaPath)) {
    const localPath = path.join(mediaCacheDir, buildMediaFilename(task, previewIndex, mediaPath));
    const downloaded = await downloadRemoteMedia(mediaPath, localPath, task, previewIndex, options, runDir);
    await assertLocalMediaFile(downloaded.localPath, task, previewIndex);
    return enrichMediaItemWithRisk(buildMediaItem(task, previewIndex, mediaPath, downloaded.localPath, downloaded.size, "downloaded"), options);
  }

  if (mediaPath.startsWith("sample://")) {
    const localPath = path.join(mediaCacheDir, buildMediaFilename(task, previewIndex, mediaPath));
    await fs.writeFile(localPath, sampleBytesForType(task.type));
    await assertLocalMediaFile(localPath, task, previewIndex);
    const stat = await fs.stat(localPath);
    return enrichMediaItemWithRisk(buildMediaItem(task, previewIndex, mediaPath, localPath, stat.size, "sample"), options);
  }

  await assertLocalMediaFile(mediaPath, task, previewIndex);
  const stat = await fs.stat(mediaPath);
  return enrichMediaItemWithRisk(buildMediaItem(task, previewIndex, mediaPath, mediaPath, stat.size, "local"), options);
}

async function downloadRemoteMedia(url, localPath, task, previewIndex, options, runDir) {
  const label = `第 ${previewIndex + 1} 条`;
  const timeoutMs = options.timeoutMs || 30000;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let directError = null;
  try {
    const fetchImpl = options.fetchImpl || globalThis.fetch;
    if (!fetchImpl) {
      throw new Error("当前 Node 环境不支持 fetch，无法下载远程素材");
    }
    const response = await fetchImpl(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "user-agent": "fd-auto-tool-v2-media-check",
        referer: "https://miaoquan.feishu.cn/"
      }
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const bytes = Buffer.from(await response.arrayBuffer());
    if (!bytes.length) {
      throw new Error("下载内容为空");
    }
    await fs.writeFile(localPath, bytes);
    return { localPath, size: bytes.length };
  } catch (error) {
    directError = error?.name === "AbortError" ? new Error(`下载超过 ${timeoutMs / 1000} 秒`) : error;
  } finally {
    clearTimeout(timer);
  }

  if (options.useBrowserDownload !== false) {
    try {
      return await downloadRemoteMediaWithBrowserProfile(url, localPath, options, runDir);
    } catch (browserError) {
      const reason = [
        `普通下载失败：${directError?.message || directError}`,
        `登录态下载失败：${browserError?.message || browserError}`
      ].join("；");
      throw new Error(`${label} 素材下载失败：${task.type} / ${compact(url)} / ${reason}`);
    }
  }

  throw new Error(`${label} 素材下载失败：${task.type} / ${compact(url)} / ${directError?.message || directError}`);
}

async function downloadRemoteMediaWithBrowserProfile(url, localPath, options, runDir) {
  const { chromium } = await import("playwright");
  const profileDir = options.profileDir || path.join(inferProjectRoot(runDir), "browser-profile");
  const context = await chromium.launchPersistentContext(profileDir, {
    headless: options.headless !== false,
    viewport: { width: 1200, height: 800 }
  });
  try {
    const response = await context.request.get(url, {
      timeout: options.timeoutMs || 30000,
      headers: {
        referer: "https://miaoquan.feishu.cn/"
      }
    });
    if (!response.ok()) {
      throw new Error(`HTTP ${response.status()}`);
    }
    const bytes = await response.body();
    if (!bytes.length) {
      throw new Error("下载内容为空");
    }
    await fs.writeFile(localPath, bytes);
    return { localPath, size: bytes.length };
  } finally {
    await context.close().catch(() => {});
  }
}

function inferProjectRoot(runDir) {
  const runsRoot = path.dirname(runDir);
  return path.basename(runsRoot).toLowerCase() === "runs" ? path.dirname(runsRoot) : process.cwd();
}

async function assertLocalMediaFile(localPath, task, previewIndex) {
  const label = `第 ${previewIndex + 1} 条`;
  let stat;
  try {
    stat = await fs.stat(localPath);
  } catch {
    throw new Error(`${label} 素材不存在：${localPath}`);
  }
  if (!stat.isFile() || stat.size <= 0) {
    throw new Error(`${label} 素材文件无效：${localPath}`);
  }
  if (!extensionLooksValid(localPath, task.type)) {
    throw new Error(`${label} 素材类型不一致：${task.type} / ${localPath}`);
  }
}

function buildMediaItem(task, previewIndex, sourcePath, localPath, size, status) {
  return {
    previewIndex: previewIndex + 1,
    sourceId: task.sourceId,
    role: task.role,
    speaker: task.speaker,
    date: task.date,
    time: task.time,
    type: task.type,
    sourcePath,
    localPath,
    size,
    status,
    imageSize: null,
    riskWarnings: []
  };
}

function buildMediaError(task, previewIndex, error) {
  return {
    previewIndex: previewIndex + 1,
    sourceId: task.sourceId,
    role: task.role,
    speaker: task.speaker,
    date: task.date,
    time: task.time,
    type: task.type,
    mediaPath: task.mediaPath,
    message: error?.message || String(error)
  };
}

async function enrichMediaItemWithRisk(item, options = {}) {
  if (item.type === "video") {
    return {
      ...item,
      riskWarnings: videoUploadRiskWarnings(item, options)
    };
  }
  if (!IMAGE_RISK_TYPES.has(item.type)) return item;
  const imageSize = await readImageSize(item.localPath);
  return {
    ...item,
    imageSize,
    riskWarnings: imageCompressionRiskWarnings(item, imageSize, options)
  };
}

function imageCompressionRiskWarnings(item, imageSize, options = {}) {
  const warnings = [];
  const maxBytes = Number(options.imageWarningBytes || DEFAULT_IMAGE_WARNING_BYTES);
  const maxEdge = Number(options.imageWarningEdge || DEFAULT_IMAGE_WARNING_EDGE);
  const maxPixels = Number(options.imageWarningPixels || DEFAULT_IMAGE_WARNING_PIXELS);
  if (maxBytes > 0 && Number(item.size || 0) > maxBytes) {
    warnings.push(`图片体积 ${formatBytes(item.size)} 超过 ${formatBytes(maxBytes)}，云中客上传时可能弹出“压缩后上传”。`);
  }
  if (imageSize?.width && imageSize?.height) {
    const edge = Math.max(Number(imageSize.width), Number(imageSize.height));
    const pixels = Number(imageSize.width) * Number(imageSize.height);
    if (maxEdge > 0 && edge > maxEdge) {
      warnings.push(`图片尺寸 ${imageSize.width}x${imageSize.height}，长边超过 ${maxEdge}px，云中客上传时可能弹出压缩提示。`);
    } else if (maxPixels > 0 && pixels > maxPixels) {
      warnings.push(`图片尺寸 ${imageSize.width}x${imageSize.height}，总像素超过 ${Math.round(maxPixels / 10000)} 万，云中客上传时可能弹出压缩提示。`);
    }
  }
  return warnings;
}

function videoUploadRiskWarnings(item, options = {}) {
  const warnings = [];
  const maxBytes = Number(options.videoWarningBytes || DEFAULT_VIDEO_WARNING_BYTES);
  if (maxBytes > 0 && Number(item.size || 0) > maxBytes) {
    warnings.push(`视频体积 ${formatBytes(item.size)} 超过 ${formatBytes(maxBytes)}，云中客上传视频大小限制为 10MB，正式创建时会上传失败。`);
  }
  return warnings;
}

function buildMediaFilename(task, previewIndex, mediaPath) {
  const hash = crypto.createHash("sha1").update(`${previewIndex}:${task.sourceId}:${mediaPath}`).digest("hex").slice(0, 10);
  return `${String(previewIndex + 1).padStart(3, "0")}-${task.type}-${hash}${extensionForTask(task, mediaPath)}`;
}

function extensionForTask(task, mediaPath) {
  const lower = mediaPath.toLowerCase();
  const matched = lower.match(/\.(jpg|jpeg|png|webp|gif|mp4|mov|webm)(?:[?#]|$)/);
  if (matched) return `.${matched[1]}`;
  if (task.type === "video") return ".mp4";
  if (task.type === "sticker") return ".gif";
  return ".jpg";
}

function extensionLooksValid(localPath, type) {
  const ext = path.extname(localPath).toLowerCase();
  if (type === "image") return [".jpg", ".jpeg", ".png", ".webp"].includes(ext);
  if (type === "sticker") return [".gif", ".png", ".webp", ".jpg", ".jpeg"].includes(ext);
  if (type === "video") return [".mp4", ".mov", ".webm"].includes(ext);
  return false;
}

function sampleBytesForType(type) {
  if (type === "video") return Buffer.from("sample-video");
  if (type === "sticker") return Buffer.from("GIF89a");
  return Buffer.from([0xff, 0xd8, 0xff, 0xd9]);
}

function formatMediaLogLine(item, index) {
  const sizeText = item.imageSize?.width && item.imageSize?.height ? ` / ${item.imageSize.width}x${item.imageSize.height}` : "";
  return `第 ${index + 1} 个媒体：预览第 ${item.previewIndex} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.type} / ${item.status} / ${item.localPath} / ${item.size} bytes${sizeText}`;
}

function formatMediaReportLine(item, index) {
  const sizeText = item.imageSize?.width && item.imageSize?.height ? ` / ${item.imageSize.width}x${item.imageSize.height}` : "";
  const warningText = (item.riskWarnings || []).length ? ` / 风险：${item.riskWarnings.join("；")}` : "";
  return `${index + 1}. 预览第 ${item.previewIndex} 条 / ${roleLabel(item.role)} / ${item.speaker || ""} / ${item.date || ""} ${item.time || ""} / ${item.type} / ${item.localPath} / ${item.size} bytes${sizeText}${warningText}`;
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "";
}

function isRemoteMediaPath(mediaPath) {
  return /^https?:\/\//i.test(mediaPath);
}

function isBlobMediaPath(mediaPath) {
  return /^blob:/i.test(String(mediaPath || "").trim());
}

function compact(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > 80 ? `${text.slice(0, 79)}...` : text;
}

function formatBytes(value) {
  const bytes = Number(value || 0);
  if (bytes >= 1024 * 1024) return `${Math.round(bytes / 1024 / 1024)}MB`;
  if (bytes >= 1024) return `${Math.round(bytes / 1024)}KB`;
  return `${bytes}B`;
}

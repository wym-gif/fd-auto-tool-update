import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

export const CMS_SUBMIT_STATE_FILE = "cms-submit-state.json";
const UNCERTAIN_STATUSES = new Set(["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown"]);
const PLAN_PROTECTED_STATUSES = new Set([...UNCERTAIN_STATUSES, "succeeded"]);
const VALID_SUBMIT_STATUSES = new Set([
  "ready",
  "submit_pending",
  "submit_confirmation_pending",
  "intermediate_confirmation_observed",
  "request_sent",
  "unknown",
  "cancelled_before_submit",
  "succeeded",
  "failed",
  "skipped"
]);

export async function createCmsSubmitStateStore(runDir, options = {}) {
  const filePath = path.join(runDir, CMS_SUBMIT_STATE_FILE);
  let existing = null;
  let stateFileExists = true;
  try {
    existing = JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch (cause) {
    if (cause?.code === "ENOENT") {
      stateFileExists = false;
    } else {
      const error = new Error(`${CMS_SUBMIT_STATE_FILE} 无法读取或 JSON 已损坏。为避免把已创建任务当成新任务，已阻止继续创建，请先核对原运行记录。`);
      error.code = "CMS_SUBMIT_STATE_CORRUPT";
      error.cause = cause;
      throw error;
    }
  }
  if (stateFileExists && !validSubmitStateDocument(existing)) {
    const error = new Error(`${CMS_SUBMIT_STATE_FILE} 格式损坏或版本无法识别。为避免把已创建任务当成新任务，已阻止继续创建，请先核对原运行记录。`);
    error.code = "CMS_SUBMIT_STATE_CORRUPT";
    throw error;
  }
  const state = stateFileExists
    ? existing
    : { version: 1, runId: path.basename(path.resolve(runDir)), updatedAt: "", tasks: {} };
  let writeQueue = Promise.resolve();

  const save = async () => {
    state.updatedAt = new Date().toISOString();
    writeQueue = writeQueue.then(() => saveSubmitStateWithLock(filePath, state, options));
    await writeQueue;
  };

  return {
    filePath,
    get(task) {
      return findTaskRecord(state.tasks, task);
    },
    assertRetryAllowed(task, retryOptions = {}) {
      const record = findTaskRecord(state.tasks, task);
      if (record && UNCERTAIN_STATUSES.has(record.status) && retryOptions.allowUncertain !== true) throw createUnknownSubmitError(task, record);
      if (!record && hasAmbiguousProtectiveLegacyRecords(state.tasks, task)) {
        throw createUnknownSubmitError(task, { index: task?.index });
      }
      return record;
    },
    assertPlanCompatible(plan = [], compatibilityOptions = {}) {
      const currentKeys = new Set(plan.map((task) => taskKey(task)));
      const skippedSubmitIdentities = new Set(
        (Array.isArray(compatibilityOptions.skippedSubmitIdentities)
          ? compatibilityOptions.skippedSubmitIdentities
          : [])
          .map((value) => String(value || ""))
          .filter(Boolean)
      );
      const protectedEntries = Object.entries(state.tasks)
        .filter(([, record]) => PLAN_PROTECTED_STATUSES.has(record?.status));
      const unreliable = protectedEntries.filter(([key]) => !key.startsWith("v2:") && !key.startsWith("task:"));
      if (unreliable.length) {
        const error = createPlanMismatchError(unreliable.map(([, record]) => record));
        error.code = "CMS_SUBMIT_IDENTITY_MISSING";
        error.message = `${CMS_SUBMIT_STATE_FILE} 中存在已成功或结果未知的旧记录，但缺少可靠任务身份。为避免恢复后重复创建，已阻止继续，请先人工核对 CMS 队列和原预览。`;
        throw error;
      }
      const missing = protectedEntries.filter(([key, record]) => {
        if (currentKeys.has(key)) return false;
        if (record?.status === "succeeded" && skippedSubmitIdentities.has(key)) return false;
        return true;
      });
      if (missing.length) throw createPlanMismatchError(missing.map(([, record]) => record));
      const unresolved = compatibilityOptions.allowUncertain === true
        ? null
        : protectedEntries.find(([, record]) => UNCERTAIN_STATUSES.has(record?.status));
      if (unresolved) {
        const [key, record] = unresolved;
        const task = plan.find((item) => taskKey(item) === key)
          || plan.find((item) => legacyRecordMatchesTask(record, item));
        throw createUnknownSubmitError(task, record);
      }
      return true;
    },
    async recordRecoveryDecision(decision = {}) {
      const decisionId = String(decision.decisionId || "");
      if (!decisionId) throw new Error("续发决定缺少 decisionId。");
      state.recoveryHistory = Array.isArray(state.recoveryHistory) ? state.recoveryHistory : [];
      if (state.recoveryHistory.some((item) => item?.decision?.decisionId === decisionId)) return;
      state.recoveryHistory.push({
        recordedAt: new Date().toISOString(),
        decision: JSON.parse(JSON.stringify(decision)),
        previousTasks: JSON.parse(JSON.stringify(state.tasks))
      });
      await save();
    },
    async update(task, status, details = {}) {
      const key = taskKey(task);
      const previous = state.tasks[key] || {};
      const record = {
        taskKey: key,
        index: Number(task?.index || 0),
        sourceId: String(task?.sourceId || ""),
        role: String(task?.role || ""),
        type: String(task?.type || ""),
        attempt: Number(details.attempt || previous.attempt || 1),
        status,
        action: String(details.action || "").slice(0, 80),
        reason: String(details.reason || "").slice(0, 300),
        updatedAt: new Date().toISOString(),
        scopeId: String(details.scopeId || previous.scopeId || ""),
        accountId: String(details.accountId || previous.accountId || ""),
        externalAccountId: String(details.externalAccountId || previous.externalAccountId || ""),
        cmsAccountIdentity: String(details.cmsAccountIdentity || previous.cmsAccountIdentity || ""),
        actualRobotNickname: String(details.actualRobotNickname || previous.actualRobotNickname || task?.speaker || ""),
        speaker: String(previous.speaker || task?.speaker || ""),
        tuoGroupKey: String(details.tuoGroupKey || previous.tuoGroupKey || task?.tuoAssignment?.groupKey || ""),
        runIdentity: String(details.runIdentity || previous.runIdentity || state.runId || ""),
        successAt: status === "succeeded"
          ? String(details.resetSuccessAt === true ? (details.successAt || new Date().toISOString()) : (previous.successAt || details.successAt || new Date().toISOString()))
          : String(details.resetSuccessAt === true ? "" : (previous.successAt || "")),
        successResetAttempt: Number(details.resetSuccessAt === true ? (details.attempt || previous.attempt || 1) : (previous.successResetAttempt || 0)),
        usageRecordedAt: String(details.usageRecordedAt || previous.usageRecordedAt || ""),
        usageEventId: String(details.usageEventId || previous.usageEventId || ""),
        reconciliationStatus: String(details.reconciliationStatus || previous.reconciliationStatus || ""),
        reconciliationReason: String(details.reconciliationReason || previous.reconciliationReason || ""),
        recoveryDecisionId: String(details.recoveryDecisionId || previous.recoveryDecisionId || ""),
        recoveryMode: String(details.recoveryMode || previous.recoveryMode || ""),
        skipPersisted: details.skipPersisted === true || previous.skipPersisted === true
      };
      state.tasks[key] = record;
      await save();
      return record;
    },
    snapshot() {
      return JSON.parse(JSON.stringify(state));
    }
  };
}

function validSubmitStateDocument(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  if (value.version !== 1 || !value.tasks || typeof value.tasks !== "object" || Array.isArray(value.tasks)) return false;
  return Object.entries(value.tasks).every(([key, record]) => validSubmitTaskRecord(key, record));
}

function validSubmitTaskRecord(key, record) {
  if (!key || !record || typeof record !== "object" || Array.isArray(record)) return false;
  if (!VALID_SUBMIT_STATUSES.has(String(record.status || ""))) return false;
  if (String(record.taskKey || "") !== key) return false;
  if (!Number.isInteger(Number(record.index)) || Number(record.index) < 1) return false;
  if (!String(record.sourceId || "").trim()) return false;
  if (!String(record.role || "").trim() || !String(record.type || "").trim()) return false;
  return true;
}

export function createCmsActionLifecycle({ task, submitState, attempt = 1 } = {}) {
  let cancelled = false;
  let cancelReason = "";
  let submitClickStarted = false;
  let terminalSubmitStatus = "";

  const assertActive = (action = "CMS 页面动作") => {
    if (!cancelled) return;
    const error = new Error(`第 ${task?.index || "?"} 条动作已废弃，不再执行${action}。原因：${cancelReason || "运行已停止"}`);
    error.code = "CMS_ACTION_CANCELLED";
    throw error;
  };

  const markUnknown = async (reason, action = "提交结果未确认") => {
    terminalSubmitStatus = "unknown";
    return submitState.update(task, "unknown", { attempt, action, reason });
  };

  const persistRequestSent = async (action) => {
    try {
      assertActive(`${action}后的提交状态`);
    } catch (error) {
      await markUnknown(cancelReason || error?.message || "提交点击后动作已取消", action);
      throw createUnknownSubmitError(task, submitState.get(task));
    }
    await submitState.update(task, "request_sent", { attempt, action });
    try {
      assertActive(`${action}后的提交状态`);
    } catch (error) {
      await markUnknown(cancelReason || error?.message || "提交状态落盘期间动作已取消", action);
      throw createUnknownSubmitError(task, submitState.get(task));
    }
  };

  const runSubmitClick = async (action, callback) => {
    assertActive(action);
    if (submitClickStarted && terminalSubmitStatus !== "failed") {
      await markUnknown("同一次提交动作试图再次点击最终确认，已阻止。", action);
      throw createUnknownSubmitError(task, submitState.get(task));
    }
    if (terminalSubmitStatus === "failed") {
      submitClickStarted = false;
      terminalSubmitStatus = "";
    }
    await submitState.update(task, "submit_pending", { attempt, action });
    try {
      assertActive(action);
    } catch (error) {
      await submitState.update(task, "cancelled_before_submit", { attempt, action, reason: error.message });
      throw error;
    }
    submitClickStarted = true;
    try {
      const result = await callback();
      await persistRequestSent(action);
      return result;
    } catch (error) {
      terminalSubmitStatus = "unknown";
      await submitState.update(task, "unknown", { attempt, action, reason: error?.message || String(error) });
      throw createUnknownSubmitError(task, submitState.get(task));
    }
  };

  return {
    get signal() {
      return { aborted: cancelled, reason: cancelReason };
    },
    get submitMayBeUnknown() {
      return submitClickStarted && !["succeeded", "failed"].includes(terminalSubmitStatus);
    },
    get submitStatus() {
      return terminalSubmitStatus;
    },
    cancel(reason) {
      cancelled = true;
      cancelReason = String(reason || "动作已取消");
    },
    assertActive,
    async runGuarded(action, callback) {
      assertActive(action);
      const result = await callback();
      assertActive(`${action}后的后续动作`);
      return result;
    },
    runSubmitClick,
    async runIrreversibleConfirm(action, callback) {
      assertActive(action);
      if (!submitClickStarted || terminalSubmitStatus === "failed") {
        return runSubmitClick(action, callback);
      }
      await submitState.update(task, "submit_confirmation_pending", { attempt, action });
      try {
        assertActive(action);
      } catch (error) {
        await markUnknown(cancelReason || error?.message || "不可逆确认点击前动作已取消", action);
        throw createUnknownSubmitError(task, submitState.get(task));
      }
      try {
        const result = await callback();
        await persistRequestSent(action);
        return result;
      } catch (error) {
        terminalSubmitStatus = "unknown";
        await submitState.update(task, "unknown", { attempt, action, reason: error?.message || String(error) });
        throw createUnknownSubmitError(task, submitState.get(task));
      }
    },
    async markIntermediateConfirmObserved(action = "检测到下一阶段确认弹窗") {
      assertActive(action);
      if (!submitClickStarted || terminalSubmitStatus) {
        throw new Error(`第 ${task?.index || "?"} 条没有可转换的提交确认阶段。`);
      }
      await submitState.update(task, "intermediate_confirmation_observed", { attempt, action });
      try {
        assertActive(action);
      } catch (error) {
        await markUnknown(cancelReason || error?.message || "确认阶段转换时动作已取消", action);
        throw createUnknownSubmitError(task, submitState.get(task));
      }
      await submitState.update(task, "ready", { attempt, action });
      try {
        assertActive(action);
      } catch (error) {
        await markUnknown(cancelReason || error?.message || "确认阶段转换完成前动作已取消", action);
        throw createUnknownSubmitError(task, submitState.get(task));
      }
      submitClickStarted = false;
    },
    async markSucceeded(action = "检测到创建成功", details = {}) {
      if (terminalSubmitStatus === "unknown" || (cancelled && submitClickStarted)) {
        return markUnknown(cancelReason || "动作超时或已停止", action);
      }
      terminalSubmitStatus = "succeeded";
      return submitState.update(task, "succeeded", { attempt, action, ...details });
    },
    async markFailed(reason, action = "CMS 明确返回失败") {
      if (terminalSubmitStatus === "unknown" || (cancelled && submitClickStarted)) {
        return markUnknown(cancelReason || reason || "动作超时或已停止", action);
      }
      terminalSubmitStatus = "failed";
      return submitState.update(task, "failed", { attempt, action, reason });
    },
    async markUnknown(reason, action = "提交结果未确认") {
      return markUnknown(reason, action);
    }
  };
}

async function saveSubmitStateWithLock(filePath, localState, options = {}) {
  const lockPath = `${filePath}.lock`;
  const lock = await acquireSubmitStateLock(lockPath, Number(options.lockTimeoutMs || 10000));
  try {
    let disk = null;
    try {
      disk = JSON.parse(await fs.readFile(filePath, "utf8"));
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
    const merged = {
      ...(disk || {}),
      ...localState,
      tasks: mergeSubmitTasks(disk?.tasks || {}, localState.tasks || {}),
      updatedAt: new Date().toISOString()
    };
    const tempPath = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
    await fs.writeFile(tempPath, JSON.stringify(merged, null, 2), "utf8");
    await fs.rename(tempPath, filePath);
    Object.assign(localState, merged);
  } finally {
    await releaseOwnedFileLock(lockPath, lock);
  }
}

function mergeSubmitTasks(diskTasks, localTasks) {
  const merged = { ...diskTasks };
  for (const [key, local] of Object.entries(localTasks)) {
    const disk = diskTasks[key] || {};
    merged[key] = {
      ...disk,
      ...local,
      successAt: Number(local.successResetAttempt || 0) > 0 ? (local.successAt || "") : (disk.successAt || local.successAt || ""),
      successResetAttempt: Math.max(Number(disk.successResetAttempt || 0), Number(local.successResetAttempt || 0)),
      usageRecordedAt: disk.usageRecordedAt || local.usageRecordedAt || "",
      usageEventId: disk.usageEventId || local.usageEventId || "",
      reconciliationStatus: disk.reconciliationStatus === "recorded" ? "recorded" : (local.reconciliationStatus || disk.reconciliationStatus || "")
    };
  }
  return merged;
}

async function acquireSubmitStateLock(lockPath, timeoutMs = 10000) {
  const started = Date.now();
  while (true) {
    try {
      const handle = await fs.open(lockPath, "wx");
      const ownerToken = crypto.randomUUID();
      await handle.writeFile(JSON.stringify({ pid: process.pid, ownerToken, createdAt: new Date().toISOString() }));
      return { handle, ownerToken };
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      if (await recoverDeadSubmitStateLock(lockPath)) continue;
      if (Date.now() - started >= timeoutMs) throw new Error(`等待提交状态文件锁超时：${lockPath}`);
      await new Promise((resolve) => setTimeout(resolve, 30));
    }
  }
}

async function recoverDeadSubmitStateLock(lockPath) {
  const recoveryPath = `${lockPath}.recovery`;
  let recoveryLock;
  try {
    const handle = await fs.open(recoveryPath, "wx");
    const ownerToken = crypto.randomUUID();
    await handle.writeFile(JSON.stringify({ pid: process.pid, ownerToken, createdAt: new Date().toISOString() }));
    recoveryLock = { handle, ownerToken };
  } catch (error) {
    if (error?.code === "EEXIST") return false;
    if (["EPERM", "EACCES"].includes(error?.code)) return false;
    throw error;
  }
  try {
    let owner;
    try {
      owner = JSON.parse(await fs.readFile(lockPath, "utf8"));
    } catch {
      return false;
    }
    const pid = Number(owner?.pid || 0);
    if (!Number.isInteger(pid) || pid <= 0 || isProcessAlive(pid)) return false;
    const stalePath = `${lockPath}.stale-${process.pid}-${crypto.randomUUID()}`;
    try {
      await fs.rename(lockPath, stalePath);
    } catch (error) {
      if (["ENOENT", "EEXIST", "EPERM", "EACCES"].includes(error?.code)) return false;
      throw error;
    }
    let movedOwner;
    try {
      movedOwner = JSON.parse(await fs.readFile(stalePath, "utf8"));
    } catch {
      movedOwner = null;
    }
    if (Number(movedOwner?.pid || 0) !== pid || String(movedOwner?.ownerToken || "") !== String(owner?.ownerToken || "")) {
      try { await fs.rename(stalePath, lockPath); } catch {}
      return false;
    }
    await fs.unlink(stalePath).catch(() => {});
    return true;
  } finally {
    await releaseOwnedFileLock(recoveryPath, recoveryLock);
  }
}

async function releaseOwnedFileLock(lockPath, lock) {
  if (!lock) return;
  await lock.handle?.close?.().catch(() => {});
  let owner;
  try {
    owner = JSON.parse(await fs.readFile(lockPath, "utf8"));
  } catch {
    return;
  }
  if (String(owner?.ownerToken || "") !== String(lock.ownerToken || "")) return;
  try {
    await fs.unlink(lockPath);
  } catch (error) {
    if (!["ENOENT", "EPERM", "EACCES"].includes(error?.code)) throw error;
  }
}

export function isProcessAlive(pid, kill = process.kill.bind(process)) {
  try {
    kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

export function createUnknownSubmitError(task, record = {}) {
  const error = new Error([
    `第 ${task?.index || record.index || "?"} 条已经发出或可能发出创建请求，但没有取得可靠结果。`,
    "为避免重复创建，系统不会自动重试、跳过或继续下一条。",
    "请先人工核对 CMS 任务队列；确认结果后再决定后续处理。",
    `状态记录：${CMS_SUBMIT_STATE_FILE}`
  ].join(" "));
  error.code = "CMS_SUBMIT_UNKNOWN";
  error.submitOutcome = "unknown";
  return error;
}

export function createPlanMismatchError(records = []) {
  const indexes = records.map((record) => Number(record?.index || 0)).filter(Boolean);
  const suffix = indexes.length ? ` 涉及原计划第 ${indexes.join("、")} 条。` : "";
  const error = new Error(`当前预览无法完整对应本轮已成功或结果未知的提交记录。${suffix}为避免通过修改、删除、重排或改成不发而重复创建，系统不会执行任何 CMS 页面动作。请先人工核对 CMS 队列；如需按新内容发送，请单独新建一轮。`);
  error.code = "CMS_SUBMIT_PLAN_MISMATCH";
  return error;
}

function taskKey(task = {}) {
  return String(task.submitIdentity || `${Number(task.index || 0)}:${String(task.sourceId || "")}`);
}

function findTaskRecord(tasks, task) {
  const current = tasks[taskKey(task)];
  if (current) return current;
  if (!task?.submitIdentity) return null;
  const legacy = legacyTaskRecords(tasks, task);
  return legacy.length === 1 ? legacy[0] : null;
}

function hasAmbiguousProtectiveLegacyRecords(tasks, task) {
  const legacy = legacyTaskRecords(tasks, task);
  return legacy.length > 1 && legacy.some((record) => UNCERTAIN_STATUSES.has(record.status) || record.status === "succeeded");
}

function legacyTaskRecords(tasks, task) {
  return Object.entries(tasks || {})
    .filter(([key]) => !key.startsWith("v2:") && !key.startsWith("task:"))
    .map(([, record]) => record)
    .filter((record) => legacyRecordMatchesTask(record, task));
}

function legacyRecordMatchesTask(record, task) {
  return String(record?.sourceId || "") === String(task?.sourceId || "")
    && String(record?.role || "") === String(task?.role || "")
    && String(record?.type || "") === String(task?.type || "");
}


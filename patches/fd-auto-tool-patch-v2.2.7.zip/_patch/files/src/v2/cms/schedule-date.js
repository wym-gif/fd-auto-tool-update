import { parseMonthDay } from "../date/date-rules.js";

export function resolveCmsScheduleDateOption(taskDate, options = {}) {
  const now = resolveNow(options.now);
  const today = startOfLocalDay(now);
  const parsed = parseMonthDay(taskDate);
  if (!parsed) {
    throw new Error(`preview 日期无效：${taskDate || "空"}`);
  }
  const explicitYear = /^\d{4}-\d{1,2}-\d{1,2}$/.test(String(taskDate || "").trim());
  const target = dateFromMonthDayNearToday({ ...parsed, year: explicitYear ? parsed.year : null }, today);
  const offset = Math.round((target.getTime() - today.getTime()) / 86400000);
  if (offset < 0) {
    throw new Error(`任务日期已经过去，不能默认选今天硬发：${formatMonthDay(target)} ${options.time || ""}`.trim());
  }
  if (offset > 7) {
    throw new Error(`CMS 定时日期最多支持 +7 天：${formatMonthDay(target)} ${options.time || ""}`.trim());
  }
  return {
    offset,
    year: target.getFullYear(),
    day: target.getDate(),
    taskDate: formatMonthDay(target),
    todayDate: formatMonthDay(today),
    optionText: scheduleDateOptionText(offset, target.getDate())
  };
}

export function scheduleDateOptionText(offset, day) {
  if (offset === 0) return `今天(${day}号)`;
  if (offset === 1) return `明天(${day}号)`;
  if (offset === 2) return `后天(${day}号)`;
  return `+${offset}天(${day}号)`;
}

export function verifyCmsScheduleDateSelectedText(text, targetDate) {
  const parsed = parseCmsScheduleDateSelectedText(text);
  if (!parsed) return false;
  const expected = expectedScheduleDateParts(targetDate);
  if (!expected) return false;
  if (parsed.relativeOffset !== null && parsed.relativeOffset !== expected.offset) return false;
  if (parsed.year !== null && parsed.year !== expected.year) return false;
  if (parsed.month !== null && parsed.month !== expected.month) return false;
  if (parsed.day !== null && parsed.day !== expected.day) return false;
  return parsed.relativeOffset !== null || parsed.day !== null;
}

export function parseCmsScheduleDateSelectedText(text) {
  const normalized = String(text || "")
    .trim()
    .replace(/[（]/g, "(")
    .replace(/[）]/g, ")")
    .replace(/\s+/g, "");
  if (!normalized) return null;

  let relativeOffset = null;
  const relativeMatches = [];
  if (normalized.includes("今天")) relativeMatches.push(0);
  if (normalized.includes("明天")) relativeMatches.push(1);
  if (normalized.includes("后天")) relativeMatches.push(2);
  for (const match of normalized.matchAll(/\+(\d{1,2})天/g)) relativeMatches.push(Number(match[1]));
  if (new Set(relativeMatches).size > 1) return null;
  if (relativeMatches.length) relativeOffset = relativeMatches[0];

  const fullDates = [];
  const fullDatePattern = /(?:^|[^\d])(\d{4})[-/.年](\d{1,2})[-/.月](\d{1,2})日?(?:$|[^\d])/g;
  for (const match of normalized.matchAll(fullDatePattern)) {
    fullDates.push({ year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) });
  }
  const withoutFullDates = normalized.replace(fullDatePattern, " ");
  for (const match of withoutFullDates.matchAll(/(?:^|[^\d])(\d{1,2})[/.月](\d{1,2})(?:日)?(?:$|[^\d])/g)) {
    fullDates.push({ year: null, month: Number(match[1]), day: Number(match[2]) });
  }
  const uniqueFullDates = uniqueDateParts(fullDates);
  if (uniqueFullDates.length > 1) return null;

  const dayMatches = Array.from(normalized.matchAll(/(?:^|[^\d])(\d{1,2})号(?:$|[^\d])/g), (match) => Number(match[1]));
  const uniqueDays = Array.from(new Set(dayMatches));
  if (uniqueDays.length > 1) return null;
  const fullDate = uniqueFullDates[0] || null;
  if (fullDate && uniqueDays.length && fullDate.day !== uniqueDays[0]) return null;

  const day = fullDate?.day ?? uniqueDays[0] ?? null;
  const month = fullDate?.month ?? null;
  if (month !== null && (month < 1 || month > 12)) return null;
  if (day !== null && (day < 1 || day > 31)) return null;
  if (relativeOffset === null && day === null) return null;
  return { relativeOffset, year: fullDate?.year ?? null, month, day };
}

function scheduleDateOptionPrefix(offset) {
  if (offset === 0) return "今天";
  if (offset === 1) return "明天";
  if (offset === 2) return "后天";
  return `+${offset}天`;
}

function expectedScheduleDateParts(targetDate = {}) {
  const [month, day] = String(targetDate.taskDate || "").split("/").map(Number);
  const expectedDay = Number(targetDate.day || day);
  const offset = Number(targetDate.offset);
  if (!Number.isInteger(offset) || !Number.isInteger(month) || !Number.isInteger(expectedDay)) return null;
  const year = Number(targetDate.year);
  if (!Number.isInteger(year)) return null;
  return { offset, year, month, day: expectedDay };
}

function uniqueDateParts(values) {
  const result = [];
  const seen = new Set();
  for (const value of values) {
    const key = `${value.year || ""}/${value.month}/${value.day}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(value);
  }
  return result;
}

function resolveNow(value) {
  if (typeof value === "function") return new Date(value());
  if (value) return new Date(value);
  return new Date();
}

function startOfLocalDay(value) {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
}

function dateFromMonthDayNearToday(parsed, today) {
  const year = parsed.year || today.getFullYear();
  const date = new Date(year, parsed.month - 1, parsed.day);
  date.setHours(0, 0, 0, 0);
  if (parsed.year) return date;
  const diff = Math.round((date.getTime() - today.getTime()) / 86400000);
  if (diff < -180) date.setFullYear(year + 1);
  if (diff > 180) date.setFullYear(year - 1);
  return date;
}

function formatMonthDay(date) {
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

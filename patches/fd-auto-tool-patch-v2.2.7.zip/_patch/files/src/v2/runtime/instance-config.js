import fs from "node:fs";
import fsPromises from "node:fs/promises";
import path from "node:path";

export const DEFAULT_CONSOLE_PORT = 62230;
export const DEFAULT_CONTROLLED_BROWSER_PORT = 9333;
export const INSTANCE_NAMES_FILE = "instance-names.json";

export function createInstanceConfig(projectRoot, options = {}) {
  const id = canonicalInstanceId(options.instance || options.instanceId || "");
  const enabled = Boolean(id);
  const offset = enabled ? instanceOffset(id) : 0;
  const port = numberOrDefault(options.port, DEFAULT_CONSOLE_PORT + offset);
  const cmsDebugPort = numberOrDefault(options.cmsDebugPort, DEFAULT_CONTROLLED_BROWSER_PORT + offset);
  const suffix = enabled ? `-${id}` : "";
  const instanceNames = options.instanceNames || readInstanceNames(projectRoot);
  const label = enabled ? instanceLabel(id, instanceNames, options.instanceName) : "默认";
  return {
    id,
    label,
    enabled,
    offset,
    port,
    cmsDebugPort,
    runsDir: path.join(projectRoot, enabled ? `runs${suffix}` : "runs"),
    logsDir: enabled ? path.join(projectRoot, "logs", `instance${suffix}`) : path.join(projectRoot, "logs"),
    profileDir: enabled ? `./browser-profile${suffix}` : "",
    consoleUrlParams: enabled ? { instance: id } : {}
  };
}

export function canonicalInstanceId(value = "") {
  const normalized = normalizeInstanceId(value);
  if (/^a$/i.test(normalized)) return "1";
  if (/^b$/i.test(normalized)) return "2";
  return normalized;
}

export function readInstanceNames(projectRoot = process.cwd()) {
  try {
    const filePath = path.join(projectRoot, INSTANCE_NAMES_FILE);
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const source = parsed.instances && typeof parsed.instances === "object" ? parsed.instances : parsed;
    return Object.fromEntries(Object.entries(source)
      .map(([key, value]) => [normalizeInstanceId(key), normalizeInstanceLabel(value)])
      .filter(([key, value]) => key && value));
  } catch {
    return {};
  }
}

export function normalizeInstanceId(value = "") {
  const text = String(value || "").trim();
  if (!text) return "";
  return text
    .replace(/[^\p{L}\p{N}_-]+/gu, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 32);
}

export function normalizeInstanceLabel(value = "") {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 40);
}

export async function saveInstanceName(projectRoot, instanceId, value) {
  const id = normalizeInstanceId(instanceId);
  if (!id) throw invalidInstanceNameError("当前不是编号实例，不能修改实例名称。");
  const collapsed = String(value || "").replace(/\s+/g, " ").trim();
  if (!collapsed) throw invalidInstanceNameError("实例名称不能为空。");
  if (collapsed.length > 40) throw invalidInstanceNameError("实例名称不能超过 40 个字符。");
  const label = normalizeInstanceLabel(collapsed);
  const filePath = path.join(projectRoot, INSTANCE_NAMES_FILE);
  const release = await acquireInstanceNamesLock(filePath);
  try {
    const stored = await readInstanceNamesDocument(filePath);
    if (stored.instances && typeof stored.instances === "object" && !Array.isArray(stored.instances)) {
      stored.instances = { ...stored.instances, [id]: label };
    } else {
      stored[id] = label;
    }
    await fsPromises.writeFile(filePath, JSON.stringify(stored, null, 2), "utf8");
    return { id, label };
  } finally {
    await release();
  }
}

function invalidInstanceNameError(message) {
  const error = new Error(message);
  error.statusCode = 400;
  return error;
}

export function appendInstanceParams(url, instanceConfig = {}) {
  const parsed = new URL(url);
  if (instanceConfig?.enabled && instanceConfig.id) {
    parsed.searchParams.set("instance", instanceConfig.id);
  }
  return parsed.toString();
}

function instanceLabel(id, instanceNames = {}, explicit = "") {
  const configured = normalizeInstanceLabel(explicit) || normalizeInstanceLabel(instanceNames[id]);
  if (configured) return configured;
  if (/^[1-5]$/.test(id)) return `实例${id}`;
  return id;
}

function instanceOffset(id) {
  const text = String(id || "");
  if (/^[a-z]$/i.test(text)) return text.toUpperCase().charCodeAt(0) - 64;
  if (/^\d+$/.test(text)) return Math.max(1, Math.min(500, Number(text)));
  let hash = 0;
  for (const char of text) hash = ((hash * 31) + char.charCodeAt(0)) % 500;
  return Math.max(1, hash);
}

function numberOrDefault(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function readInstanceNamesDocument(filePath) {
  try {
    const parsed = JSON.parse(await fsPromises.readFile(filePath, "utf8"));
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("实例名称配置必须是 JSON 对象。");
    }
    return parsed;
  } catch (error) {
    if (error?.code === "ENOENT") return {};
    if (error instanceof SyntaxError) throw new Error("instance-names.json 格式错误，未保存实例名称。");
    throw error;
  }
}

async function acquireInstanceNamesLock(filePath) {
  const lockPath = `${filePath}.lock`;
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      await fsPromises.mkdir(lockPath);
      return async () => fsPromises.rm(lockPath, { recursive: true, force: true });
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      const stat = await fsPromises.stat(lockPath).catch(() => null);
      if (stat && Date.now() - stat.mtimeMs > 10000) {
        await fsPromises.rm(lockPath, { recursive: true, force: true }).catch(() => {});
        continue;
      }
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }
  throw new Error("实例名称正在由另一个窗口保存，请稍后重试。");
}

const BASE = "https://open.feishu.cn/open-apis";

export class FeishuApiError extends Error {}

function apiFailure(label, status, data) {
  const code = Number.isSafeInteger(data?.code) ? `，飞书错误码 ${data.code}` : "，未收到可识别的飞书错误码";
  const violations = Array.isArray(data?.error?.permission_violations) ? data.error.permission_violations : [];
  const scopes = [...new Set(violations.map((item) => item?.subject).filter((value) =>
    typeof value === "string" && /^(docx|docs|wiki|drive):[a-z0-9_.:]{1,100}$/.test(value)))];
  const detail = scopes.length ? `接口返回的权限项：${scopes.join("、")}。` : "";
  const hint = status === 429 ? "请求频繁，请稍后重试。" : "需根据错误码核对接口权限或文档访问限制。";
  return new FeishuApiError(`${label}：HTTP ${status}${code}。${detail}${hint}`);
}

export function detectMediaType(buffer, fallback) {
  if (buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "image/png";
  if (buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255) return "image/jpeg";
  if (["GIF87a", "GIF89a"].includes(buffer.subarray(0, 6).toString("ascii"))) return "image/gif";
  if (buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  if (buffer.subarray(4, 8).toString("ascii") === "ftyp") return "video/mp4";
  return fallback || "application/octet-stream";
}

export function parseFeishuDocumentUrl(value) {
  let url;
  try { url = new URL(value); } catch { throw new FeishuApiError("请输入完整的飞书文档链接。"); }
  const match = url.pathname.match(/^\/(wiki|docx)\/([A-Za-z0-9]+)\/?$/);
  if (url.protocol !== "https:" || !url.hostname.endsWith(".feishu.cn") ||
      url.username || url.password || url.port || !match) {
    throw new FeishuApiError("飞书 API 读取仅支持 https://企业.feishu.cn/wiki/… 或 /docx/… 链接。");
  }
  return { type: match[1], token: match[2] };
}

export async function limitedBuffer(response, limit) {
  const reader = response.body?.getReader();
  if (!reader) throw new FeishuApiError("接口返回了空响应。");
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > limit) throw new FeishuApiError("响应超过本次读取的大小上限，未判定为完整读取。");
      chunks.push(value);
    }
  } finally {
    await reader.cancel().catch(() => {});
  }
  return Buffer.concat(chunks, size);
}

export function createFeishuApiClient({ fetchImpl = fetch, signal } = {}) {
  async function request(apiPath, { bearer, body, label, binary = false } = {}) {
    let response;
    try {
      response = await fetchImpl(BASE + apiPath, {
        method: body ? "POST" : "GET",
        redirect: "error",
        headers: {
          ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}),
          ...(body ? { "Content-Type": "application/json" } : {})
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(30000)]) : AbortSignal.timeout(30000)
      });
    } catch {
      throw new FeishuApiError(`${label}：连接失败或超时，请检查网络后重试。`);
    }
    if (!response.ok) {
      let errorData;
      try { errorData = JSON.parse((await limitedBuffer(response, 65536)).toString("utf8")); } catch {}
      throw apiFailure(label, response.status, errorData);
    }
    const mime = (response.headers.get("content-type") || "").split(";")[0].toLowerCase();
    const buffer = await limitedBuffer(response, binary ? 15 * 1024 * 1024 : 10 * 1024 * 1024);
    if (binary && mime !== "application/json") return { buffer, mime: detectMediaType(buffer, mime) };
    let data;
    try { data = JSON.parse(buffer.toString("utf8")); } catch { throw new FeishuApiError(`${label}：响应不是预期的 JSON 数据。`); }
    if (data.code !== 0) throw apiFailure(label, response.status, data);
    if (binary) throw new FeishuApiError(`${label}：未收到素材文件。`);
    return data;
  }
  return {
    async authenticate(appId, appSecret) {
      const result = await request("/auth/v3/tenant_access_token/internal", {
        body: { app_id: appId, app_secret: appSecret },
        label: "获取应用凭证"
      });
      if (!result.tenant_access_token) throw new FeishuApiError("飞书没有返回访问凭证。");
      return result.tenant_access_token;
    },
    async json(apiPath, bearer, label) {
      return (await request(apiPath, { bearer, label })).data;
    },
    async media(token, bearer) {
      return request(`/drive/v1/medias/${encodeURIComponent(token)}/download`, {
        bearer,
        label: "读取素材",
        binary: true
      });
    }
  };
}

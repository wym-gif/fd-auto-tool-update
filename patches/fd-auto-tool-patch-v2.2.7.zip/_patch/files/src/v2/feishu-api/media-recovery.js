import fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { downloadSelectedFeishuMedia } from "./selective-media.js";

const RESUME_FILE = "feishu-media-resume.json";
const MANIFEST_FILE = "feishu-media-manifest.json";
const WAIT_MESSAGE = "已保留取得的素材；本次自动获取已暂停，可点击“继续获取剩余素材”，也可手动补充。";

// Only opaque references are persisted. The server resolves these against the
// original, owner-bound allowlist; restoring never reads a newer document.
export async function prepareFeishuMediaRecovery(runDir, result, options = {}) {
  const selected = new Set((options.sourceIds || []).map(String));
  const entries = (result.mediaManifest || []).filter((entry) => selected.has(String(entry.sourceId)));
  const safeEntries = entries.map((entry) => ({
    sourceId: entry.sourceId,
    sourceOccurrenceId: entry.sourceOccurrenceId,
    blockOrder: entry.blockOrder,
    declaredKind: entry.declaredKind,
    declaredError: entry.declaredError,
    tokenRef: entry.token ? createHash("sha256").update(entry.token).digest("hex") : entry.tokenRef || ""
  }));
  await atomicJson(path.join(runDir, RESUME_FILE), {
    schemaVersion: 1, documentUrl: options.documentUrl, revision: result.report?.revision, entries: safeEntries
  });
  return createFeishuMediaRecoveryHandler(runDir, { ...options, liveEntries: entries });
}

export async function createFeishuMediaRecoveryHandler(runDir, options = {}) {
  const unavailable = async () => { throw new Error("本轮素材续取记录无法读取，当前预览内容已保留；请手动补充素材或联系管理员恢复记录。"); };
  let descriptor;
  try { descriptor = await readJson(path.join(runDir, RESUME_FILE), null); }
  catch { return unavailable; }
  if (!descriptor) return null;
  if (descriptor.schemaVersion !== 1 || !Array.isArray(descriptor.entries) ||
      !Number.isInteger(Number(descriptor.revision)) || Number(descriptor.revision) < 0 ||
      !descriptor.entries.every((entry) => Number.isSafeInteger(entry.blockOrder) && entry.blockOrder > 0 &&
        entry.sourceId === `feishu-api-${entry.blockOrder}` &&
        (!entry.tokenRef || /^[a-f0-9]{64}$/.test(entry.tokenRef)))) return unavailable;
  const entries = options.liveEntries || descriptor.entries;
  const entryIds = new Set(entries.map((entry) => String(entry.sourceId)));
  const mediaCacheDir = path.join(runDir, "media-cache");
  const now = options.now || Date.now;
  const cooldown = { until: 0 };
  let running = false;
  return async function recover({ sourceIds = [], signal, onProgress } = {}) {
    if (running) throw new Error("素材续取正在进行，请等待当前进度。");
    running = true;
    const windowMs = Math.max(1, Number(options.autoWindowMs ?? 600_000));
    const deadline = now() + windowMs;
    const windowController = new AbortController();
    const timer = setTimeout(() => windowController.abort(), windowMs);
    const requestSignal = signal ? AbortSignal.any([signal, windowController.signal]) : windowController.signal;
    const requested = new Set(sourceIds.map(String).filter((id) => entryIds.has(id)));
    const manifest = new Map();
    const updates = new Map();
    const pending = new Set(requested);
    const publish = (extra = {}) => onProgress?.({
      completed: [...updates.values()].filter((item) => item.status !== "waiting").length,
      total: requested.size, updates: [...updates.values()], ...extra
    });
    const save = () => atomicJson(path.join(runDir, MANIFEST_FILE), [...manifest.values()]);
    try {
      for (const item of await readJson(path.join(runDir, MANIFEST_FILE), [])) {
        if (entryIds.has(String(item.sourceId))) manifest.set(String(item.sourceId), item);
      }
      for (const id of requested) {
        const item = manifest.get(id);
        if (item?.status === "downloaded" && await reusableAsset(item, mediaCacheDir)) {
          updates.set(id, updateFor(item, mediaCacheDir));
          pending.delete(id);
        }
        cooldown.until = Math.max(cooldown.until, Number(item?.cooldownUntil || 0));
      }
      if (cooldown.until > now()) {
        cooldown.error = Object.assign(new Error("素材服务正在恢复"), {
          statusCode: 503, diagnostics: { retryAfterMs: cooldown.until - now() }
        });
      }
      publish();
      while (pending.size && now() < deadline && !requestSignal.aborted) {
        const groups = new Map();
        for (const entry of entries) {
          if (!pending.has(String(entry.sourceId))) continue;
          const key = entry.token || entry.tokenRef || entry.sourceId;
          if (!groups.has(key)) groups.set(key, []);
          groups.get(key).push(entry);
        }
        for (const group of groups.values()) {
          signal?.throwIfAborted();
          if (now() >= deadline || cooldown.until >= deadline || requestSignal.aborted) break;
          let result;
          try {
            result = await downloadSelectedFeishuMedia({ mediaManifest: group, report: { revision: descriptor.revision, rows: [] } }, {
              sourceIds: group.map((entry) => entry.sourceId), documentUrl: descriptor.documentUrl,
              mediaCacheDir, signal: requestSignal, cooldown, now, sleep: options.sleep,
              maxAttempts: 1, recoveryTimeoutMs: Math.max(1, deadline - now()),
              deferRetryableFailures: true,
              downloader: options.downloader,
              retryProgress: (progress) => publish(progress),
              onProgress: (progress) => publish({ bytes: Number(progress.receivedBytes || 0) })
            });
          } catch (error) {
            signal?.throwIfAborted();
            if (windowController.signal.aborted) break;
            throw error;
          }
          for (const item of result.selectedMediaManifest) {
            manifest.set(item.sourceId, { ...item, cooldownUntil: cooldown.until });
            if (item.status === "recovering") continue;
            updates.set(item.sourceId, updateFor(item, mediaCacheDir));
            pending.delete(item.sourceId);
          }
          // Commit each completed file before reporting it to the page.
          await save();
          publish();
        }
        if (!pending.size || requestSignal.aborted) break;
        const delay = Math.max(Number(options.roundDelayMs ?? 2_000), cooldown.until - now(), 1);
        if (now() + delay >= deadline) break;
        publish({ phase: "retry-wait", retryAfterMs: delay, reason: "正在等待素材服务恢复，已取得素材保留" });
        try { await abortableDelay(delay, requestSignal, options.sleep); }
        catch (error) { signal?.throwIfAborted(); if (!windowController.signal.aborted) throw error; }
      }
      signal?.throwIfAborted();
      for (const id of pending) {
        const item = manifest.get(id) || entries.find((entry) => entry.sourceId === id);
        const { token, ...safe } = item;
        const waiting = { ...safe, status: "waiting", message: WAIT_MESSAGE, cooldownUntil: cooldown.until };
        manifest.set(id, waiting);
        updates.set(id, updateFor(waiting, mediaCacheDir));
      }
      await save();
      const failed = [...updates.values()].filter((item) => item.status === "failed").length;
      return { updates: [...updates.values()], completed: requested.size - pending.size, total: requested.size,
        pendingCount: pending.size, message: pending.size ? WAIT_MESSAGE : failed
          ? `仍有 ${failed} 项素材无法自动取得，请查看对应行原因；其他素材已保存。` : "素材已自动补齐。" };
    } finally {
      clearTimeout(timer);
      running = false;
    }
  };
}

function updateFor(item, directory) {
  return { sourceId: item.sourceId, status: item.status,
    errorCode: String(item.errorCode || ""),
    mediaPath: item.status === "downloaded" ? path.join(directory, item.fileName) : "",
    type: item.kind || item.declaredKind || "image", message: item.error || item.message || "已自动补齐" };
}

async function reusableAsset(item, directory) {
  if (!item.fileName || path.basename(item.fileName) !== item.fileName || !/^[a-f0-9]{64}$/.test(item.sha256 || "")) return false;
  const file = path.join(directory, item.fileName);
  try {
    const stat = await fs.lstat(file);
    if (!stat.isFile() || stat.size !== item.bytes) return false;
    const hash = createHash("sha256");
    for await (const chunk of createReadStream(file)) hash.update(chunk);
    return hash.digest("hex") === item.sha256;
  } catch { return false; }
}

async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch (error) { if (error.code === "ENOENT") return fallback; throw error; }
}

async function atomicJson(file, value) {
  const temporary = `${file}.${randomUUID()}.tmp`;
  try {
    await fs.writeFile(temporary, JSON.stringify(value, null, 2), { mode: 0o600, flag: "wx" });
    await fs.rename(temporary, file);
  } finally { await fs.rm(temporary, { force: true }).catch(() => {}); }
}

async function abortableDelay(ms, signal, sleep) {
  signal.throwIfAborted();
  if (sleep) return sleep(ms);
  await new Promise((resolve, reject) => {
    const done = () => { signal.removeEventListener("abort", aborted); resolve(); };
    const timer = setTimeout(done, ms);
    const aborted = () => { clearTimeout(timer); signal.removeEventListener("abort", aborted); reject(signal.reason); };
    signal.addEventListener("abort", aborted, { once: true });
    if (signal.aborted) aborted();
  });
}

import { createFeishuApiClient, FeishuApiError, parseFeishuDocumentUrl } from "./client.js";
import { orderedFeishuHeadingRows, orderedFeishuRows } from "./blocks.js";
import { attachFeishuSourceIdentities } from "./source-identity.js";

export async function readFeishuApiDocument(input, options = {}) {
  const maxAttempts = Math.min(3, Math.max(1, Number(options.structureAttempts || 3)));
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    options.progress?.(`正在固定文档结构，请勿修改文档（第 ${attempt}/${maxAttempts} 次）`);
    try {
      const result = await readFeishuApiDocumentOnce(input, options);
      result.report.readAttempts = attempt;
      return result;
    } catch (error) {
      if (error?.code !== "FEISHU_DOCUMENT_CHANGED" || attempt >= maxAttempts) throw error;
      options.progress?.(`检测到文档在读取期间被修改，正在重新完整读取（第 ${attempt + 1}/${maxAttempts} 次）`);
    }
  }
}

async function readFeishuApiDocumentOnce(input, options = {}) {
  const client = options.client || createFeishuApiClient({ signal: AbortSignal.timeout(300000) });
  const progress = options.progress || (() => {});
  const downloadMedia = options.downloadMedia !== false;
  const headingOnly = options.headingOnly === true;
  const target = parseFeishuDocumentUrl(input.documentUrl);
  if (!/^cli_[A-Za-z0-9]+$/.test(input.appId || "") || typeof input.appSecret !== "string" || !input.appSecret.trim()) {
    throw new FeishuApiError("请填写有效的 App ID 和 App Secret。");
  }
  progress("正在验证应用凭证");
  const bearer = await client.authenticate(input.appId, input.appSecret.trim());
  let documentId = target.token;
  if (target.type === "wiki") {
    progress("正在解析知识库链接");
    const data = await client.json(`/wiki/v2/spaces/get_node?token=${encodeURIComponent(target.token)}`, bearer, "解析知识库链接");
    if (data?.node?.obj_type !== "docx" || !data.node.obj_token) {
      throw new FeishuApiError("此知识库节点不是新版文档（docx），当前不支持读取。");
    }
    documentId = data.node.obj_token;
  }
  const base = `/docx/v1/documents/${encodeURIComponent(documentId)}`;
  const meta = await client.json(base, bearer, "读取文档信息");
  const revision = meta?.document?.revision_id;
  if (!Number.isInteger(revision)) throw new FeishuApiError("无法取得文档版本，不能确认分页内容一致。");
  const blocks = [];
  const cursors = new Set();
  let cursor = "";
  let pages = 0;
  do {
    progress(`正在读取文档第 ${++pages} 页`);
    const query = new URLSearchParams({ page_size: "500", document_revision_id: "-1" });
    if (cursor) query.set("page_token", cursor);
    const data = await client.json(`${base}/blocks?${query}`, bearer, "读取文档内容块");
    if (!Array.isArray(data?.items)) throw new FeishuApiError("文档块响应不完整。");
    blocks.push(...data.items);
    if (blocks.length > 20000 || pages > 100) throw new FeishuApiError("文档超过本次读取上限，未判定为完整读取。");
    cursor = data.has_more ? data.page_token : "";
    if (data.has_more && (!cursor || cursors.has(cursor))) throw new FeishuApiError("接口分页游标异常，未判定为完整读取。");
    if (cursor) cursors.add(cursor);
  } while (cursor);
  progress("正在核对分页期间的文档版本");
  const collected = await client.json(base, bearer, "核对分页文档版本");
  if (collected?.document?.revision_id !== revision) {
    const error = new FeishuApiError("文档在分页读取期间发生变化，结果可能混合不同版本。");
    error.code = "FEISHU_DOCUMENT_CHANGED";
    throw error;
  }
  const converted = headingOnly
    ? orderedFeishuHeadingRows(blocks, documentId)
    : orderedFeishuRows(blocks, documentId);
  const rows = attachFeishuSourceIdentities(converted.rows, revision);
  const warnings = converted.warnings;
  const assets = new Map();
  const mediaManifest = buildFeishuMediaManifest(rows);
  const seen = new Map();
  let totalBytes = 0;
  let mediaCount = 0;
  let downloadedCount = 0;
  for (const row of rows) {
    const mediaToken = row.mediaToken;
    delete row.mediaToken;
    if (!["image", "file"].includes(row.type)) continue;
    mediaCount += 1;
    if (!downloadMedia) continue;
    progress(`正在读取第 ${mediaCount} 个素材`);
    if (!mediaToken) {
      row.mediaError ||= "缺少素材标识";
      continue;
    }
    try {
      let assetId = seen.get(mediaToken);
      if (!assetId) {
        if (totalBytes >= 80 * 1024 * 1024) throw new FeishuApiError("本次素材已达 80MB 上限。");
        const asset = await client.media(mediaToken, bearer);
        if (!asset.buffer.length) throw new FeishuApiError("素材为空。");
        if (totalBytes + asset.buffer.length > 80 * 1024 * 1024) throw new FeishuApiError("本次素材超过 80MB 上限。");
        assetId = String(row.order);
        assets.set(assetId, asset);
        totalBytes += asset.buffer.length;
        seen.set(mediaToken, assetId);
      }
      const asset = assets.get(assetId);
      row.assetId = assetId;
      row.mime = asset.mime;
      row.bytes = asset.buffer.length;
      if (row.type === "image" && !/^image\/(png|jpeg|gif|webp|avif)$/.test(asset.mime)) {
        warnings.push(`第 ${row.order} 块的图片格式暂不能显示，请下载附件核对。`);
      }
      downloadedCount += 1;
    } catch (error) {
      row.mediaError = error instanceof FeishuApiError ? error.message : "素材请求失败或超时。";
      warnings.push(`第 ${row.order} 块：${row.mediaError}`);
    }
  }
  return {
    assets,
    mediaManifest,
    report: {
      title: meta.document.title || "未命名文档",
      revision,
      pages,
      blockCount: blocks.length,
      mediaCount,
      downloadedCount,
      textCount: rows.filter((row) => row.type === "text").length,
      headingCount: rows.filter((row) => row.type === "heading").length,
      warnings,
      rows,
      checkedAt: new Date().toISOString()
    }
  };
}

export function hydrateFeishuGatewayDocument(document, options = {}) {
  if (!document || typeof document !== "object" || !Array.isArray(document.blocks) || !Array.isArray(document.assets)) {
    throw new FeishuApiError("飞书后台返回的文档内容不完整。");
  }
  const downloadMedia = options.downloadMedia !== false;
  const converted = options.headingOnly === true
    ? orderedFeishuHeadingRows(document.blocks, document.id)
    : orderedFeishuRows(document.blocks, document.id);
  const rows = attachFeishuSourceIdentities(converted.rows, document.revision);
  const warnings = converted.warnings;
  const assetsByToken = new Map();
  const mediaManifest = buildFeishuMediaManifest(rows);
  let totalAssetBytes = 0;
  for (const item of document.assets) {
    if (!item?.token || typeof item.data !== "string" || typeof item.mime !== "string") {
      throw new FeishuApiError("飞书后台返回了无效的素材数据。");
    }
    const buffer = Buffer.from(item.data, "base64");
    if (!buffer.length || buffer.length > 15 * 1024 * 1024) throw new FeishuApiError("飞书后台素材为空或超过大小上限。");
    if (assetsByToken.has(item.token)) throw new FeishuApiError("飞书后台返回了重复素材标识。");
    totalAssetBytes += buffer.length;
    if (totalAssetBytes > 80 * 1024 * 1024) throw new FeishuApiError("飞书后台素材总量超过 80MB 上限。");
    assetsByToken.set(item.token, { buffer, mime: item.mime });
  }
  const failures = new Map((document.assetErrors || []).map((item) => [item?.token, item?.message || "素材读取失败"]));
  const assets = new Map();
  const assetIds = new Map();
  let mediaCount = 0;
  let downloadedCount = 0;
  for (const row of rows) {
    const token = row.mediaToken;
    delete row.mediaToken;
    if (!["image", "file"].includes(row.type)) continue;
    mediaCount += 1;
    if (!downloadMedia) continue;
    if (!token) {
      row.mediaError ||= "缺少素材标识";
      continue;
    }
    const asset = assetsByToken.get(token);
    if (!asset) {
      row.mediaError = failures.get(token) || "飞书后台未返回此素材";
      warnings.push(`第 ${row.order} 块：${row.mediaError}`);
      continue;
    }
    let assetId = assetIds.get(token);
    if (!assetId) {
      assetId = String(row.order);
      assetIds.set(token, assetId);
      assets.set(assetId, asset);
    }
    row.assetId = assetId;
    row.mime = asset.mime;
    row.bytes = asset.buffer.length;
    downloadedCount += 1;
  }
  return {
    assets,
    mediaManifest,
    report: {
      title: document.title || "未命名文档",
      documentId: document.id,
      canonicalUrl: document.canonicalUrl,
      authMode: document.authMode,
      revision: document.revision,
      readAttempts: Number(document.readAttempts || 1),
      pages: document.pages,
      blockCount: document.blocks.length,
      mediaCount,
      downloadedCount,
      textCount: rows.filter((row) => row.type === "text").length,
      headingCount: rows.filter((row) => row.type === "heading").length,
      warnings,
      rows,
      checkedAt: new Date().toISOString()
    }
  };
}

export function buildFeishuMediaManifest(rows = []) {
  return rows
    .filter((row) => ["image", "file"].includes(row.type))
    .map((row) => ({
      sourceId: `feishu-api-${row.order}`,
      sourceOccurrenceId: String(row.sourceOccurrenceId || ""),
      blockId: String(row.blockId || ""),
      blockOrder: Number(row.order),
      token: String(row.mediaToken || ""),
      declaredBlockType: row.type,
      declaredName: String(row.text || ""),
      declaredKind: declaredMediaKind(row),
      declaredError: String(row.mediaError || ""),
      status: row.mediaToken ? "pending" : "missing-token"
    }));
}

export function selectedFeishuMediaManifest(result, sourceIds = []) {
  const selected = new Set(sourceIds.map(String));
  return (result?.mediaManifest || []).filter((item) => selected.has(String(item.sourceId)));
}

function declaredMediaKind(row) {
  if (["image", "sticker", "video"].includes(row.mediaKindHint)) return row.mediaKindHint;
  const name = String(row.text || "").trim();
  if (row.type === "image") return /\.gif$/i.test(name) ? "sticker" : "image";
  if (/\.(?:mp4|mov|webm)$/i.test(name)) return "video";
  if (/\.gif$/i.test(name)) return "sticker";
  if (/\.(?:png|jpe?g|webp|avif)$/i.test(name)) return "image";
  return "unknown";
}

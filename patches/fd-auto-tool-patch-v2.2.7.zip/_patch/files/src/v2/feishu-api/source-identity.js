export function attachFeishuSourceIdentities(rows = [], revision = "") {
  return (Array.isArray(rows) ? rows : []).map((row) => {
    const sourceOccurrenceId = buildFeishuSourceOccurrenceId(row, revision);
    const sourceSegmentIds = (Array.isArray(row?.segments) ? row.segments : [])
      .map((segment, index) => String(segment?.sourceSegmentId || `${sourceOccurrenceId}#segment-${index + 1}`));
    return {
      ...row,
      sourceRevision: Number.isFinite(Number(revision)) ? Number(revision) : String(revision || ""),
      sourceOccurrenceId,
      sourceSegmentIds
    };
  });
}

export function buildFeishuSourceOccurrenceId(row = {}, revision = "") {
  const revisionPart = String(revision ?? "").trim() || "unknown";
  const blockPart = encodeURIComponent(String(row?.blockId || "").trim() || `order-${Number(row?.order || 0)}`);
  const orderPart = Number.isFinite(Number(row?.order)) ? Number(row.order) : 0;
  const typePart = encodeURIComponent(String(row?.type || "unknown").trim() || "unknown");
  return `feishu:${revisionPart}:${blockPart}:${orderPart}:${typePart}`;
}

export function sourceOccurrenceIdsFrom(value = {}) {
  const values = [
    ...(Array.isArray(value?.sourceOccurrenceIds) ? value.sourceOccurrenceIds : []),
    ...(Array.isArray(value?.sourceSegmentIds) ? value.sourceSegmentIds : []),
    value?.sourceOccurrenceId
  ];
  return [...new Set(values.map((item) => String(item || "").trim()).filter(Boolean))];
}

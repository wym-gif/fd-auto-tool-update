import { FeishuApiError } from "./client.js";

const TEXT_KEYS = new Map([
  [1, "page"], [2, "text"], ...Array.from({ length: 9 }, (_, index) => [index + 3, `heading${index + 1}`]),
  [12, "bullet"], [13, "ordered"], [14, "code"], [15, "quote"], [17, "todo"]
]);
const CONTAINERS = new Map([[19, "提示块"], [22, "分隔线"], [24, "分栏"], [25, "分栏列"], [31, "表格"], [32, "单元格"]]);

export function orderedFeishuRows(blocks, documentId) {
  const { byId, root } = prepareBlockGraph(blocks, documentId);
  const viewDescendants = collectViewDescendants(byId);
  const rows = [];
  const warnings = [];
  walkBlockGraph(byId, root, (block, depth, blockOrder) => {
    const key = TEXT_KEYS.get(block.block_type);
    const row = { blockId: block.block_id, order: blockOrder, depth, type: "structure", label: "", text: "", segments: [] };
    if (key) {
      Object.assign(row, textRow(block, key, row));
      if (row.sourceError) warnings.push(`第 ${row.order} 块：${row.sourceError}`);
    } else if (block.block_type === 27 || block.block_type === 23) {
      const media = block.block_type === 27 ? block.image : block.file;
      row.type = block.block_type === 27 ? "image" : "file";
      row.label = row.type === "image" ? "图片" : "附件";
      row.text = media?.name || "";
      row.mediaToken = media?.token;
      if (!row.mediaToken) warnings.push(`第 ${row.order} 块缺少素材标识。`);
    } else if (block.block_type === 33) {
      Object.assign(row, recoverableViewRow(block, byId, row.order, warnings));
    } else {
      row.label = CONTAINERS.get(block.block_type) || "";
      if (!row.label) {
        if (viewDescendants.has(block.block_id)) {
          row.label = "视图内部结构";
          warnings.push(`第 ${row.order} 块是待补素材视图内的未知类型 ${block.block_type}，已保留视图占位，请在预览中核对。`);
        } else {
          row.type = "unsupported";
          row.label = `未识别内容类型 ${block.block_type}`;
          row.sourceError = `飞书第 ${row.order} 块为暂不支持的内容类型 ${block.block_type}。系统已保留原文位置，请在预览中补充内容或设为不发`;
          warnings.push(`${row.sourceError}。`);
        }
      }
      if ([24, 31].includes(block.block_type)) warnings.push(`第 ${row.order} 块为${row.label}，按块结构展开，需人工核对阅读顺序。`);
    }
    rows.push(row);
  });
  return { rows, warnings };
}

export function orderedFeishuHeadingRows(blocks, documentId) {
  const { byId, root } = prepareBlockGraph(blocks, documentId);
  const rows = [];
  walkBlockGraph(byId, root, (block, depth, blockOrder) => {
    const key = TEXT_KEYS.get(block.block_type);
    if (!key?.startsWith("heading")) return;
    const row = { blockId: block.block_id, order: blockOrder, depth, headingLevel: block.block_type - 2,
      type: "heading", label: "标题", text: "", segments: [] };
    Object.assign(row, textRow(block, key, row));
    rows.push(row);
  });
  return { rows, warnings: [] };
}

function prepareBlockGraph(blocks, documentId) {
  if (!Array.isArray(blocks)) throw new FeishuApiError("文档块响应不完整。");
  const byId = new Map();
  for (const block of blocks) {
    if (!block || typeof block !== "object" || !block.block_id || byId.has(block.block_id)) {
      throw new FeishuApiError("文档块缺少编号或重复，无法确认顺序。");
    }
    if (block.children !== undefined && !Array.isArray(block.children)) {
      throw new FeishuApiError("文档块的子内容关系无效，无法确认顺序。");
    }
    byId.set(block.block_id, block);
  }
  const root = byId.get(documentId) || blocks.find((block) => block.block_type === 1 && !block.parent_id);
  if (!root) throw new FeishuApiError("没有读取到文档根节点，无法确认完整性。");
  return { byId, root };
}

function walkBlockGraph(byId, root, visit) {
  const visited = new Set();
  const stack = [{ id: root.block_id, depth: 0 }];
  let blockOrder = 0;
  while (stack.length) {
    const { id, depth } = stack.pop();
    if (visited.has(id)) throw new FeishuApiError("文档结构存在重复引用，无法确认顺序。");
    const block = byId.get(id);
    if (!block) throw new FeishuApiError("部分子内容块缺失，不能判定读取完整。");
    visited.add(id);
    visit(block, depth, ++blockOrder);
    for (const child of [...(block.children || [])].reverse()) stack.push({ id: child, depth: depth + 1 });
  }
  if (visited.size !== byId.size) throw new FeishuApiError("存在未连接到正文结构的内容块，不能判定读取完整。");
}

function textRow(block, key, row) {
  const type = block.block_type === 1 ? "title" : key.startsWith("heading") ? "heading" : "text";
  const segments = [];
  const unsupportedElements = [];
  for (const [segmentIndex, element] of (block[key]?.elements || []).entries()) {
    if (element?.text_run) {
      segments.push({
        segmentIndex,
        text: element.text_run.content || "",
        highlighted: Boolean(element.text_run.text_element_style?.background_color)
      });
    } else {
      const elementType = Object.keys(element || {}).find((name) => name !== "text_element_style") || "未知";
      unsupportedElements.push(elementType);
    }
  }
  return {
    type,
    label: { title: "文档标题", heading: "标题", text: "文字" }[type],
    ...(type === "heading" ? { headingLevel: block.block_type - 2 } : {}),
    segments,
    text: segments.map((segment) => segment.text).join(""),
    ...(unsupportedElements.length ? {
      sourceError: `含暂不支持的内嵌内容（${[...new Set(unsupportedElements)].join("、")}），已保留能够确认的文字，缺失部分需人工补充`
    } : {})
  };
}

function recoverableViewRow(block, byId, order, warnings) {
  const children = (block.children || []).map((childId) => byId.get(childId)).filter(Boolean);
  const extraViewFields = Object.keys(block.view || {}).filter((key) => key !== "view_type");
  const confirmedVideoView = block.view?.view_type === 2 && block.children?.length &&
    children.length === block.children.length && children.every((child) => child.block_type === 23) &&
    extraViewFields.length === 0;
  if (confirmedVideoView) return { type: "structure", label: "视频视图" };

  const mediaChildren = children.filter((child) => [23, 27].includes(child.block_type));
  const viewType = block.view?.view_type;
  if (mediaChildren.length) {
    warnings.push(`第 ${order} 块是未完全识别的类型 33 视图（view_type=${viewType ?? "缺失"}），已继续读取其中 ${mediaChildren.length} 个素材子块，请在预览中核对。`);
    return { type: "structure", label: "素材视图（需核对）" };
  }

  const reason = !block.children?.length
    ? "视图没有可读取的素材子块"
    : "视图子块中没有可确认的图片或视频";
  const mediaError = `飞书第 ${order} 块为未完全识别的内容类型 33：${reason}。系统已保留待补素材位置，请在预览中选择正确的图片、表情包或视频`;
  warnings.push(`${mediaError}。`);
  return {
    type: "file",
    label: "待补素材视图",
    text: "",
    mediaKindHint: "unknown",
    mediaError
  };
}

function collectViewDescendants(byId) {
  const result = new Set();
  const stack = [...byId.values()]
    .filter((block) => block.block_type === 33)
    .flatMap((block) => block.children || []);
  while (stack.length) {
    const id = stack.pop();
    if (result.has(id)) continue;
    result.add(id);
    const block = byId.get(id);
    for (const childId of block?.children || []) stack.push(childId);
  }
  return result;
}

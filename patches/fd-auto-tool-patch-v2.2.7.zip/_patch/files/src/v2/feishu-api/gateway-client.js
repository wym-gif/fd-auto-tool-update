import fs from "node:fs/promises";
import path from "node:path";
import { createHash, createHmac, randomBytes, randomUUID } from "node:crypto";
import { getDeviceId } from "../license/license-manager.js";
import { LICENSE_COMPANY_ID, TRUSTED_LICENSE_SERVERS } from "../license/license-policy.js";
import { detectMediaType, FeishuApiError, parseFeishuDocumentUrl } from "./client.js";
import { hydrateFeishuGatewayDocument } from "./document-reader.js";
import { buildFeishuEnrollment, ensureDeviceProofKey } from "./device-proof-store.js";

const MAX_RESPONSE = 120 * 1024 * 1024;
const MAX_STREAM_MEDIA = 256 * 1024 * 1024;
const SELECTIVE_MEDIA_CAPABILITY = "selective-media-v1";
const SELECTIVE_MEDIA_VIA_READ_CAPABILITY = "selective-media-v1-via-read";

export class FeishuGatewayError extends FeishuApiError {
  constructor(code, message, statusCode = 500, diagnostics = {}) {
    super(message);
    this.code = code;
    this.statusCode = statusCode;
    this.diagnostics = diagnostics;
  }
}

export function createFeishuGatewayConnection({ projectRoot, instanceId = "", fetchImpl = fetch,
  proofKey = "", deviceProofOptions = {}, licenseConfig, appVersion, now = () => Date.now(),
  progressPollMs = 15_000, statusMinIntervalMs = 15_000, statusBackoffBaseMs = 15_000,
  statusBackoffMaxMs = 120_000, cancelPollMs = 1_000, cancelTimeoutMs = 15_000, random = Math.random } = {}) {
  let session = null;
  let nextStatusAt = 0;
  let statusBackoffAttempt = 0;
  let statusQueue = Promise.resolve();
  let resolvedProofKey = proofKey || "";

  async function reserveStatusRequest(signal) {
    const reservation = statusQueue.then(async () => {
      const delayMs = Math.max(0, nextStatusAt - now());
      if (delayMs > 0) await abortableDelay(delayMs, signal);
      nextStatusAt = now() + Math.max(10, statusMinIntervalMs);
    });
    statusQueue = reservation.catch(() => {});
    return reservation;
  }

  function recordStatusResult(error = null) {
    if (!error) {
      statusBackoffAttempt = 0;
      return;
    }
    if (Number(error?.statusCode || 0) !== 429) return;
    const retryAfterMs = Number(error?.diagnostics?.retryAfterMs || 0);
    const fallback = Math.min(statusBackoffMaxMs,
      Math.max(statusBackoffBaseMs, statusMinIntervalMs) * (2 ** statusBackoffAttempt));
    statusBackoffAttempt = Math.min(statusBackoffAttempt + 1, 3);
    const delayMs = retryAfterMs > 0 ? retryAfterMs : Math.round(fallback * (1 + Math.max(0, random()) * 0.2));
    nextStatusAt = Math.max(nextStatusAt, now() + delayMs);
  }

  async function configuration() {
    const config = licenseConfig || JSON.parse(await fs.readFile(path.join(projectRoot, "license.json"), "utf8"));
    const version = appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
    const trusted = new URL(config.licenseServer);
    if (config.enabled !== true || config.mode !== "apisix-intranet" || config.companyId !== LICENSE_COMPANY_ID ||
      !TRUSTED_LICENSE_SERVERS.includes(trusted.href)) {
      throw new FeishuGatewayError("GATEWAY_NOT_CONFIGURED", "公司飞书后台地址未正确配置。", 503);
    }
    return { origin: trusted.origin, version };
  }

  async function createSession(force = false) {
    if (!force && session?.expiresAt > now() + 30_000) return session.token;
    const { origin, version } = await configuration();
    if (!resolvedProofKey) {
      try {
        resolvedProofKey = await ensureDeviceProofKey({
          deviceId: getDeviceId(),
          proofKey: process.env.MIAOQUAN_DEVICE_PROOF_KEY || "",
          persistProvided: true,
          ...deviceProofOptions
        });
      } catch (error) {
        throw new FeishuGatewayError(error?.code || "DEVICE_PROOF_NOT_CONFIGURED",
          error?.message || "此电脑无法初始化飞书后台连接证明，请联系管理员。", 503);
      }
    }
    const timestamp = Math.floor(now() / 1000);
    const nonce = randomBytes(24).toString("hex");
    const payload = { companyId: LICENSE_COMPANY_ID, deviceId: getDeviceId(), appVersion: String(version).slice(0, 32),
      instanceId: String(instanceId || "").slice(0, 64), timestamp, nonce };
    const canonical = [payload.companyId, payload.deviceId, payload.appVersion, payload.instanceId,
      payload.timestamp, payload.nonce, "feishu-session-v1"].join("\n");
    const derived = createHash("sha256").update(resolvedProofKey).digest();
    payload.signature = createHmac("sha256", derived).update(canonical).digest("hex");
    let body;
    try {
      body = await request(new URL("/feishu/session", origin), { body: payload, timeoutMs: 10_000 });
    } catch (error) {
      if (error?.code !== "SESSION_UNAUTHORIZED") throw error;
      await enrollAuthorizedDevice(origin, version);
      const retryTimestamp = Math.floor(now() / 1000);
      const retryNonce = randomBytes(24).toString("hex");
      const retryPayload = { ...payload, timestamp: retryTimestamp, nonce: retryNonce };
      const retryCanonical = [retryPayload.companyId, retryPayload.deviceId, retryPayload.appVersion,
        retryPayload.instanceId, retryPayload.timestamp, retryPayload.nonce, "feishu-session-v1"].join("\n");
      retryPayload.signature = createHmac("sha256", derived).update(retryCanonical).digest("hex");
      body = await request(new URL("/feishu/session", origin), { body: retryPayload, timeoutMs: 10_000 });
    }
    if (typeof body.sessionToken !== "string" || body.sessionToken.length < 32 || !Number.isFinite(Number(body.expiresIn))) {
      throw new FeishuGatewayError("SESSION_RESPONSE_INVALID", "飞书后台没有返回有效连接会话。", 502);
    }
    session = {
      token: body.sessionToken,
      expiresAt: now() + Number(body.expiresIn || 600) * 1000,
      capabilities: Array.isArray(body.capabilities) ? body.capabilities.map(String) : null
    };
    return session.token;
  }

  async function enrollAuthorizedDevice(origin, version) {
    const enrollment = buildFeishuEnrollment({
      companyId: LICENSE_COMPANY_ID,
      deviceId: getDeviceId(),
      appVersion: version,
      proofKey: resolvedProofKey,
      now: now()
    });
    try {
      await request(new URL("/license/check", origin), {
        body: { ...enrollment, action: "feishu-auto-enroll" }, timeoutMs: 10_000
      });
    } catch (error) {
      if (["FEISHU_PROOF_CONFLICT", "DEVICE_DENIED", "EXPIRED"].includes(error?.code)) throw error;
      throw new FeishuGatewayError("FEISHU_AUTO_ENROLL_FAILED",
        `此电脑的软件授权有效，但飞书连接自动开通失败：${error?.message || "请稍后重试。"}`,
        Number(error?.statusCode || 503));
    }
  }

  async function gateway(pathname, body = {}, options = {}) {
    const { origin } = await configuration();
    for (let attempt = 0; attempt < 2; attempt += 1) {
      if (pathname === "/feishu/status") await reserveStatusRequest(options.signal);
      const token = await createSession(attempt > 0);
      try {
        const result = await request(new URL(pathname, origin), {
          body, token, timeoutMs: options.timeoutMs || 30_000,
          maxBytes: options.maxBytes || MAX_RESPONSE,
          signal: options.signal,
          onResponseProgress: options.onResponseProgress
        });
        if (pathname === "/feishu/status") recordStatusResult();
        return result;
      } catch (error) {
        if (pathname === "/feishu/status") recordStatusResult(error);
        if (attempt === 0 && error?.code === "SESSION_INVALID") continue;
        throw error;
      }
    }
  }

  async function gatewayMediaToFile(body, options = {}) {
    const { origin } = await configuration();
    await fs.mkdir(options.mediaCacheDir, { recursive: true });
    const tempPath = path.join(options.mediaCacheDir, `.feishu-${process.pid}-${randomUUID()}.part`);
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const token = await createSession(attempt > 0);
      if (body.mediaTokenRef && !session?.capabilities?.includes("selective-media-ref-v1")) {
        throw new FeishuGatewayError("FEISHU_MEDIA_RESUME_UNAVAILABLE", "后台尚未启用跨重启素材续取，当前预览已保留。请联系管理员更新后台。", 409);
      }
      if (Array.isArray(session?.capabilities) && !session.capabilities.includes(SELECTIVE_MEDIA_CAPABILITY)) {
        throw new FeishuGatewayError(
          "FEISHU_MEDIA_ENDPOINT_UNAVAILABLE",
          "飞书后台尚未启用按范围下载素材，请联系管理员完成后台和网关升级。",
          503
        );
      }
      let handle;
      try {
        const viaReadRoute = session?.capabilities?.includes(SELECTIVE_MEDIA_VIA_READ_CAPABILITY) === true;
        const response = await fetchImpl(new URL(viaReadRoute ? "/feishu/read" : "/feishu/media", origin), {
          method: "POST",
          redirect: "error",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify(viaReadRoute ? { ...body, operation: "download-media" } : body),
          signal: options.signal ? AbortSignal.any([options.signal, AbortSignal.timeout(300_000)]) : AbortSignal.timeout(300_000)
        });
        if (!response.ok) {
          let errorBody = {};
          try { errorBody = await response.json(); } catch {}
          if (attempt === 0 && errorBody.code === "SESSION_INVALID") continue;
          if (response.status === 404 && !errorBody.code) {
            throw new FeishuGatewayError(
              "FEISHU_MEDIA_ENDPOINT_UNAVAILABLE",
              "飞书后台的按范围素材接口尚未接通，请联系管理员完成后台和网关升级。",
              503
            );
          }
          const diagnostics = responseDiagnostics(response, {
            phase: "media",
            retryAfterMs: retryAfterDelay(response.headers.get("retry-after"), now())
          });
          throw new FeishuGatewayError(errorBody.code || "FEISHU_MEDIA_FAILED",
            errorBody.message || `飞书素材下载失败（HTTP ${response.status}）。`, response.status, diagnostics);
        }
        const declaredBytes = finiteHeaderNumber(response.headers.get("content-length"));
        if (declaredBytes > MAX_STREAM_MEDIA) throw new FeishuGatewayError("FEISHU_MEDIA_TOO_LARGE", "飞书素材超过流式下载硬上限。", 413);
        const reader = response.body?.getReader();
        if (!reader) throw new FeishuGatewayError("FEISHU_MEDIA_EMPTY", "飞书素材响应为空。", 502);
        handle = await fs.open(tempPath, "wx");
        const hasher = createHash("sha256");
        const headChunks = [];
        let headBytes = 0;
        let received = 0;
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          received += value.length;
          if (received > MAX_STREAM_MEDIA) throw new FeishuGatewayError("FEISHU_MEDIA_TOO_LARGE", "飞书素材超过流式下载硬上限。", 413);
          const chunk = Buffer.from(value);
          hasher.update(chunk);
          if (headBytes < 64) {
            const part = chunk.subarray(0, Math.min(chunk.length, 64 - headBytes));
            headChunks.push(part);
            headBytes += part.length;
          }
          await handle.write(chunk);
          options.onProgress?.({ receivedBytes: received, totalBytes: declaredBytes });
        }
        await handle.sync();
        await handle.close();
        handle = null;
        if (!received || (declaredBytes && received !== declaredBytes)) {
          throw new FeishuGatewayError("FEISHU_MEDIA_INCOMPLETE", `飞书素材传输不完整：${received}/${declaredBytes || "未知"} 字节。`, 502);
        }
        const sha256 = hasher.digest("hex");
        const expectedHash = String(response.headers.get("x-miaoquan-content-sha256") || "").toLowerCase();
        if (expectedHash && expectedHash !== sha256) throw new FeishuGatewayError("FEISHU_MEDIA_HASH_MISMATCH", "飞书素材传输校验失败。", 502);
        const declaredMime = String(response.headers.get("content-type") || "application/octet-stream").split(";", 1)[0].toLowerCase();
        const head = Buffer.concat(headChunks, headBytes);
        const mime = detectMediaType(head, declaredMime);
        const extension = extensionForMediaMime(mime);
        const finalPath = path.join(options.mediaCacheDir, `feishu-api-${String(options.assetId).padStart(4, "0")}${extension}`);
        await fs.rename(tempPath, finalPath);
        return { filePath: finalPath, mime, bytes: received, sha256, head };
      } catch (error) {
        await handle?.close().catch(() => {});
        await fs.unlink(tempPath).catch(() => {});
        if (!options.signal?.aborted && !(error instanceof FeishuGatewayError) &&
            (error?.name === "TypeError" || error?.name === "TimeoutError" ||
              ["ECONNRESET", "ECONNREFUSED", "ETIMEDOUT", "UND_ERR_SOCKET"].includes(error?.cause?.code || error?.code))) {
          throw new FeishuGatewayError("FEISHU_GATEWAY_CONNECTION_FAILED",
            "素材服务连接暂时中断，正在等待恢复；已取得的素材保留。", 503);
        }
        throw error;
      }
    }
  }

  async function request(url, { body, token = "", timeoutMs, maxBytes = 1024 * 1024, signal,
    onResponseProgress } = {}) {
    const clientRequestId = /^[a-f0-9]{16}$/i.test(body?.requestId || "") ? body.requestId : "";
    let response;
    try {
      const timeoutSignal = AbortSignal.timeout(timeoutMs);
      response = await fetchImpl(url, {
        method: "POST", redirect: "error", cache: "no-store",
        headers: { "Content-Type": "application/json", Accept: "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify(body || {}), signal: signal ? AbortSignal.any([signal, timeoutSignal]) : timeoutSignal
      });
    } catch (error) {
      if (signal?.aborted) {
        throw new FeishuGatewayError("FEISHU_READ_CANCELLED", "飞书读取已由用户取消。", 499, {
          phase: "cancelled", requestId: clientRequestId
        });
      }
      if (error?.name === "AbortError" || error?.name === "TimeoutError") {
        const suffix = clientRequestId ? `（请求编号 ${clientRequestId}）` : "";
        throw new FeishuGatewayError("FEISHU_UPSTREAM_TIMEOUT", `飞书后台连接超时，请稍后重试${suffix}。`, 504, {
          phase: "connect", requestId: clientRequestId
        });
      }
      const suffix = clientRequestId ? `（请求编号 ${clientRequestId}）` : "";
      throw new FeishuGatewayError("FEISHU_GATEWAY_CONNECTION_FAILED", `连接公司飞书后台失败，尚未生成预览${suffix}。请检查公司网络或 VPN。`, 503, {
        phase: "connect", requestId: clientRequestId
      });
    }
    const declaredBytes = finiteHeaderNumber(response.headers.get("content-length"));
    const responseRequestId = response.headers.get("x-miaoquan-request-id") || "";
    const requestId = /^[a-f0-9]{8,32}$/i.test(responseRequestId) ? responseRequestId : clientRequestId;
    const contentType = response.headers.get("content-type") || "";
    if (declaredBytes > maxBytes) {
      const diagnostics = responseDiagnostics(response, { requestId, contentType, declaredBytes, receivedBytes: 0, phase: "headers" });
      throw new FeishuGatewayError("FEISHU_RESPONSE_TOO_LARGE", `飞书后台响应超过大小上限，尚未生成预览${formatResponseContext(diagnostics)}。`, 413, diagnostics);
    }
    const reader = response.body?.getReader();
    if (!reader) {
      const diagnostics = responseDiagnostics(response, { requestId, contentType, declaredBytes, receivedBytes: 0, phase: "body" });
      throw new FeishuGatewayError("FEISHU_RESPONSE_INVALID", `飞书后台返回了空响应，尚未生成预览${formatResponseContext(diagnostics)}。`, 502, diagnostics);
    }
    const chunks = [];
    let size = 0;
    let lastProgressAt = 0;
    let lastProgressBytes = 0;
    try {
      while (true) {
        let part;
        try {
          part = await reader.read();
        } catch (error) {
          const diagnostics = responseDiagnostics(response, {
            requestId, contentType, declaredBytes, receivedBytes: size, phase: "body"
          });
          if (signal?.aborted) {
            throw new FeishuGatewayError("FEISHU_READ_CANCELLED", "飞书读取已由用户取消。", 499, diagnostics);
          }
          if (error?.name === "AbortError" || error?.name === "TimeoutError") {
            throw new FeishuGatewayError("FEISHU_UPSTREAM_TIMEOUT", `读取飞书后台响应超时，尚未生成预览${formatResponseContext(diagnostics)}。`, 504, diagnostics);
          }
          throw new FeishuGatewayError("FEISHU_RESPONSE_INTERRUPTED", `读取响应过程中连接中断，尚未生成预览${formatResponseContext(diagnostics)}。`, 502, diagnostics);
        }
        const { done, value } = part;
        if (done) break;
        size += value.byteLength;
        if (size > maxBytes) {
          const diagnostics = responseDiagnostics(response, {
            requestId, contentType, declaredBytes, receivedBytes: size, phase: "body"
          });
          throw new FeishuGatewayError("FEISHU_RESPONSE_TOO_LARGE", `飞书后台响应超过大小上限，尚未生成预览${formatResponseContext(diagnostics)}。`, 413, diagnostics);
        }
        chunks.push(Buffer.from(value));
        const progressNow = Date.now();
        if (onResponseProgress && (size === declaredBytes || size - lastProgressBytes >= 512 * 1024 || progressNow - lastProgressAt >= 500)) {
          lastProgressAt = progressNow;
          lastProgressBytes = size;
          onResponseProgress({
            phase: "response-transfer", stage: "接收后台响应", status: "running",
            receivedBytes: size, totalBytes: declaredBytes, requestId
          });
        }
      }
    } finally {
      await reader.cancel().catch(() => {});
    }
    const buffer = Buffer.concat(chunks, size);
    let result;
    try {
      result = JSON.parse(buffer.toString("utf8"));
    } catch {
      const diagnostics = responseDiagnostics(response, {
        requestId, contentType, declaredBytes, receivedBytes: size, phase: "json"
      });
      throw new FeishuGatewayError("FEISHU_RESPONSE_INVALID", `飞书后台返回了非 JSON 响应，尚未生成预览${formatResponseContext(diagnostics)}。`, 502, diagnostics);
    }
    if (!response.ok || result.ok !== true) {
      const diagnostics = responseDiagnostics(response, {
        requestId, contentType, declaredBytes, receivedBytes: size, phase: "application",
        retryAfterMs: retryAfterDelay(response.headers.get("retry-after"), now())
      });
      const suffix = requestId ? `（请求编号 ${requestId}）` : "";
      throw new FeishuGatewayError(result.code || "FEISHU_GATEWAY_ERROR", `${result.message || "飞书后台请求失败。"}${suffix}`, response.status, diagnostics);
    }
    return result;
  }

  return {
    async status() { return gateway("/feishu/status"); },
    async startOAuth() { return gateway("/feishu/oauth/start"); },
    async metadata(documentUrl, options = {}) {
      parseFeishuDocumentUrl(documentUrl);
      return (await gateway("/feishu/metadata", { documentUrl }, { signal: options.signal })).document;
    },
    async read(input, options = {}) {
      parseFeishuDocumentUrl(input.documentUrl);
      const downloadMedia = options.downloadMedia !== false;
      const requestId = randomBytes(8).toString("hex");
      options.onRequestStart?.({ requestId });
      const startedAt = Date.now();
      const emit = (progress) => {
        if (typeof options.progress !== "function") return;
        options.progress({
          requestId,
          elapsedMs: Math.max(0, Date.now() - startedAt),
          ...progress
        });
      };
      let active = true;
      let serverTerminal = false;
      let pollTimer = null;
      const pollAbort = new AbortController();
      const schedulePoll = (delay = progressPollMs) => {
        if (!active || typeof options.progress !== "function") return;
        pollTimer = setTimeout(async () => {
          try {
            const status = await gateway("/feishu/status", { requestId }, {
              timeoutMs: 10_000, signal: pollAbort.signal
            });
            if (active && status.progress?.requestId === requestId) {
              emit({
                phase: "server", source: "server", ...status.progress,
                backendStatus: status.progress.status,
                backendTerminal: status.progress.terminal === true,
                status: "running", terminal: false
              });
              serverTerminal = status.progress.terminal === true;
            }
          } catch {
            // Progress is advisory; the primary read owns success and failure.
          } finally {
            if (active && !serverTerminal) schedulePoll();
          }
        }, Math.max(10, progressPollMs));
        pollTimer.unref?.();
      };
      emit({ phase: "connecting", stage: "校验并连接飞书后台", status: "running", terminal: false });
      schedulePoll(Math.min(1000, Math.max(10, progressPollMs)));
      try {
        let response;
        const maxBusyAttempts = Math.min(3, Math.max(1, Number(options.heavyBusyAttempts ?? 3)));
        for (let attempt = 1; attempt <= maxBusyAttempts; attempt += 1) {
          try {
            response = await gateway("/feishu/read", {
              documentUrl: input.documentUrl, downloadMedia, requestId
            }, {
              timeoutMs: 300_000, maxBytes: MAX_RESPONSE, signal: options.signal,
              onResponseProgress: (progress) => {
                if (active) {
                  serverTerminal = true;
                  pollAbort.abort();
                }
                emit(progress);
              }
            });
            break;
          } catch (error) {
            if (error?.code !== "HEAVY_OPERATION_BUSY" || attempt >= maxBusyAttempts) throw error;
            const retryAfterMs = Math.min(30_000, Math.max(1_000,
              Number(error?.diagnostics?.retryAfterMs || 8_000)));
            emit({
              phase: "server-busy", stage: "服务器正在处理另一项大文案",
              status: "waiting", terminal: false, attempt, maxAttempts: maxBusyAttempts,
              retryAfterMs, reason: `本次尚未开始读取，${Math.ceil(retryAfterMs / 1000)} 秒后重试。`
            });
            await abortableDelay(retryAfterMs, options.signal);
          }
        }
        emit({ phase: "client-parse", stage: "客户端解析文档数据", status: "running", terminal: false });
        const result = hydrateFeishuGatewayDocument(response.document, {
          downloadMedia,
          headingOnly: options.headingOnly === true
        });
        emit({ phase: "read-complete", stage: "文档读取完成，正在生成预览", status: "running", terminal: false });
        return result;
      } catch (error) {
        emit({
          phase: error?.code === "FEISHU_READ_CANCELLED" ? "cancelled" : "failed",
          stage: error?.code === "FEISHU_READ_CANCELLED" ? "飞书读取已取消" : "飞书读取失败",
          status: error?.code === "FEISHU_READ_CANCELLED" ? "cancelled" : "failed", terminal: true,
          requestId: error?.diagnostics?.requestId || requestId,
          code: String(error?.code || "FEISHU_READ_FAILED").slice(0, 64),
          reason: String(error?.message || "飞书读取失败。").slice(0, 240)
        });
        throw error;
      } finally {
        active = false;
        pollAbort.abort();
        if (pollTimer) clearTimeout(pollTimer);
      }
    },
    async downloadMedia(input, options = {}) {
      parseFeishuDocumentUrl(input.documentUrl);
      if (input.tokenRef ? !/^[a-f0-9]{64}$/.test(String(input.tokenRef)) : !/^[A-Za-z0-9_-]{1,256}$/.test(String(input.token || ""))) {
        throw new FeishuGatewayError("INVALID_REQUEST", "飞书素材标识无效。", 400);
      }
      return gatewayMediaToFile({
        documentUrl: input.documentUrl,
        revision: Number(input.revision),
        ...(input.tokenRef ? { mediaTokenRef: String(input.tokenRef) } : { mediaToken: String(input.token) })
      }, { ...options, assetId: input.assetId });
    },
    async cancelRead(requestId, options = {}) {
      const normalized = String(requestId || "").toLowerCase();
      if (!/^[a-f0-9]{16}$/.test(normalized)) {
        throw new FeishuGatewayError("INVALID_REQUEST", "没有可取消的飞书读取请求。", 400);
      }
      let accepted = false;
      let cancelRouteMissing = false;
      let lastError = null;
      const timeoutMs = Math.max(250, Number(options.timeoutMs || cancelTimeoutMs) || 15_000);
      const deadline = now() + timeoutMs;
      try {
        const response = await gateway("/feishu/cancel", { requestId: normalized }, { timeoutMs: Math.min(10_000, timeoutMs) });
        accepted = response.accepted === true || response.cancelled === true;
        options.progress?.(response.progress || { requestId: normalized, stage: "cancel-requested", status: "cancelling" });
        if (response.progress?.terminal === true) return response.progress;
      } catch (error) {
        if (!['NOT_FOUND', 'FEISHU_GATEWAY_ERROR'].includes(error?.code) && Number(error?.statusCode || 0) !== 404) throw error;
        cancelRouteMissing = true;
        lastError = error;
        options.progress?.({ requestId: normalized, stage: "等待旧版后台完成", status: "cancelling", terminal: false });
      }
      while (now() < deadline) {
        await abortableDelay(Math.min(Math.max(50, cancelPollMs), Math.max(1, deadline - now())));
        if (now() >= deadline) break;
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), Math.max(1, deadline - now()));
        timer.unref?.();
        try {
          const status = await gateway("/feishu/status", { requestId: normalized }, {
            timeoutMs: Math.min(10_000, Math.max(1, deadline - now())), signal: controller.signal
          });
          const progress = status.progress;
          if (progress?.requestId === normalized) {
            options.progress?.(progress);
            if (progress.terminal === true) return { ...progress, cancelAccepted: accepted };
          }
        } catch (error) {
          lastError = error;
          options.progress?.({ requestId: normalized, stage: "等待后台取消状态", status: "cancelling",
            terminal: false, reason: String(error?.message || "状态暂不可用").slice(0, 160) });
        } finally {
          clearTimeout(timer);
        }
      }
      if (cancelRouteMissing && Number(lastError?.statusCode || 0) === 404) {
        return {
          requestId: normalized, stage: "后台未找到读取请求", status: "not_found", terminal: true,
          cancelAccepted: false, backendOutcome: "not_found",
          reason: "在限定时间内后台未找到该请求，无法确认是否曾登记或是否已因重启过期。"
        };
      }
      throw new FeishuGatewayError(
        "FEISHU_CANCEL_UNCONFIRMED",
        "本地读取已停止，但后台取消结果在限定时间内未确认。请保留请求编号并核对后台状态后再重试。",
        504,
        { requestId: normalized, timeoutMs, lastError: String(lastError?.message || "") }
      );
    }
  };
}

function extensionForMediaMime(mime) {
  return ({
    "image/png": ".png", "image/jpeg": ".jpg", "image/gif": ".gif", "image/webp": ".webp",
    "image/avif": ".avif", "video/mp4": ".mp4", "video/quicktime": ".mov", "video/webm": ".webm"
  })[String(mime || "").toLowerCase()] || ".bin";
}

function finiteHeaderNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? number : 0;
}

function responseDiagnostics(response, details = {}) {
  const result = {
    phase: details.phase || "",
    httpStatus: Number(response?.status || 0),
    contentType: String(details.contentType || "").split(";", 1)[0].slice(0, 80),
    declaredBytes: Number(details.declaredBytes || 0),
    receivedBytes: Number(details.receivedBytes || 0),
    requestId: /^[a-f0-9]{8,32}$/i.test(details.requestId || "") ? details.requestId : ""
  };
  if (Number(details.retryAfterMs || 0) > 0) result.retryAfterMs = Number(details.retryAfterMs);
  const origin = response?.headers?.get?.("x-miaoquan-media-origin");
  if (["server-queue", "feishu-upstream"].includes(origin)) result.mediaErrorOrigin = origin;
  return result;
}

function retryAfterDelay(value, nowMs) {
  const raw = String(value || "").trim();
  if (!raw) return 0;
  const seconds = Number(raw);
  if (Number.isFinite(seconds) && seconds >= 0) return Math.ceil(seconds * 1000);
  const target = Date.parse(raw);
  return Number.isFinite(target) ? Math.max(0, target - nowMs) : 0;
}

function abortableDelay(delayMs, signal) {
  if (signal?.aborted) return Promise.reject(abortError());
  return new Promise((resolve, reject) => {
    const timer = setTimeout(done, delayMs);
    timer.unref?.();
    signal?.addEventListener("abort", aborted, { once: true });
    function cleanup() { signal?.removeEventListener("abort", aborted); }
    function done() { cleanup(); resolve(); }
    function aborted() { clearTimeout(timer); cleanup(); reject(abortError()); }
  });
}

function abortError() {
  const error = new Error("The operation was aborted");
  error.name = "AbortError";
  return error;
}

function formatResponseContext(details) {
  const values = [
    details.httpStatus ? `HTTP ${details.httpStatus}` : "",
    details.contentType ? `类型 ${details.contentType}` : "",
    details.declaredBytes ? `声明 ${details.declaredBytes} 字节` : "",
    `已接收 ${details.receivedBytes} 字节`,
    details.requestId ? `请求编号 ${details.requestId}` : ""
  ].filter(Boolean);
  return values.length ? `（${values.join("；")}）` : "";
}

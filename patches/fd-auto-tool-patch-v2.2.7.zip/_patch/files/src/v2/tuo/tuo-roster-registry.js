import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { normalizeRosterKey } from "./tuo-roster.js";

export const TUO_ROSTER_REGISTRY_FILE = "tuo-roster-registry.json";

export async function registerTuoRosterIdentity({ projectRoot, rosterPath, roster = [], scopeId = "" } = {}) {
  const root = path.resolve(projectRoot || process.cwd());
  const dataDir = path.join(root, "data");
  const registryPath = path.join(dataDir, TUO_ROSTER_REGISTRY_FILE);
  await fs.mkdir(dataDir, { recursive: true });
  return withFileLock(`${registryPath}.lock`, async () => {
    const registry = await readRegistry(registryPath);
    const resolvedPath = path.resolve(rosterPath || "");
    const pathKey = normalizePath(resolvedPath);
    const fingerprint = rosterFingerprint(roster);
    const explicitScope = String(scopeId || "").trim();
    let scope = explicitScope ? registry.scopes[explicitScope] : null;
    if (!scope && explicitScope) {
      scope = createScope(explicitScope);
      registry.scopes[explicitScope] = scope;
    }
    if (!scope) scope = Object.values(registry.scopes).find((item) => item.paths?.includes(pathKey));
    if (!scope) scope = Object.values(registry.scopes).find((item) => item.fingerprints?.includes(fingerprint));
    if (!scope) {
      const nextScopeId = crypto.randomUUID();
      scope = createScope(nextScopeId);
      registry.scopes[nextScopeId] = scope;
    } else if (!scope.fingerprints?.includes(fingerprint) && !scope.paths?.includes(pathKey) && !hasRosterContinuity(scope, roster)) {
      throw identityConfirmationError("名单路径和内容都发生变化，无法确认是否仍是原业务名单。请确认继续原范围或建立新范围。", scope.scopeId);
    } else if (!scope.fingerprints?.includes(fingerprint) && scope.paths?.includes(pathKey) && !hasRosterContinuity(scope, roster)) {
      throw identityConfirmationError("当前路径的名单内容已大幅替换，无法确认是修改原名单还是更换业务名单。", scope.scopeId);
    }

    const enriched = assignAccountIds(scope, roster);
    scope.paths = unique([...(scope.paths || []), pathKey]);
    scope.fingerprints = unique([...(scope.fingerprints || []), fingerprint]).slice(-20);
    scope.updatedAt = new Date().toISOString();
    registry.updatedAt = scope.updatedAt;
    registry.revision = Number(registry.revision || 0) + 1;
    await writeJsonAtomic(registryPath, registry);
    return { scopeId: scope.scopeId, roster: enriched, registryPath, fingerprint };
  });
}

function assignAccountIds(scope, roster) {
  scope.accounts ||= {};
  const existingAccountIds = new Set(Object.keys(scope.accounts));
  const nicknameCounts = countBy(roster, (item) => normalizeRosterKey(item.nickname));
  const result = [];
  const claimed = new Set();
  for (const item of roster) {
    const externalId = normalizeRosterKey(item.externalAccountId || item.accountId);
    const nicknameKey = normalizeRosterKey(item.nickname);
    const rowSignature = accountRowSignature(item);
    const profileSignature = accountProfileSignature(item);
    let account = externalId
      ? Object.values(scope.accounts).find((entry) => normalizeRosterKey(entry.externalAccountId) === externalId)
      : null;
    if (!account) account = Object.values(scope.accounts).find((entry) => {
      if (!entry.rowSignatures?.includes(rowSignature)) return false;
      if (!externalId) return true;
      return normalizeRosterKey(entry.externalAccountId) === externalId;
    });
    if (!account) {
      const profileMatches = Object.values(scope.accounts).filter((entry) => existingAccountIds.has(entry.accountId) && entry.profileSignatures?.includes(profileSignature));
      if (profileMatches.length === 1) account = profileMatches[0];
    }
    if (!account && nicknameCounts.get(nicknameKey) === 1) {
      const matches = Object.values(scope.accounts).filter((entry) => entry.nicknameKeys?.includes(nicknameKey));
      if (matches.length === 1) account = matches[0];
    }
    if (!account && nicknameCounts.get(nicknameKey) > 1) {
      const knownSameName = Object.values(scope.accounts).filter((entry) => existingAccountIds.has(entry.accountId) && entry.nicknameKeys?.includes(nicknameKey));
      if (knownSameName.length) {
        throw identityConfirmationError(`同昵称账号“${item.nickname}”的备注或行内容已变化，无法确认对应哪个既有账号，请补充账号ID。`, scope.scopeId);
      }
    }
    if (account && claimed.has(account.accountId)) {
      throw identityConfirmationError(`名单中“${item.nickname}”无法唯一对应已有账号，请补充账号ID后再继续。`, scope.scopeId);
    }
    if (!account) {
      account = { accountId: crypto.randomUUID(), externalAccountId: item.externalAccountId || "", nicknameKeys: [], rowSignatures: [], profileSignatures: [], createdAt: new Date().toISOString() };
      scope.accounts[account.accountId] = account;
    }
    claimed.add(account.accountId);
    account.externalAccountId ||= item.externalAccountId || "";
    account.nickname = item.nickname;
    account.nicknameKeys = unique([...(account.nicknameKeys || []), nicknameKey]);
    account.rowSignatures = unique([...(account.rowSignatures || []), rowSignature]).slice(-20);
    account.profileSignatures = unique([...(account.profileSignatures || []), profileSignature]).slice(-20);
    account.updatedAt = new Date().toISOString();
    result.push({ ...item, accountId: account.accountId, scopeId: scope.scopeId });
  }
  return result;
}

function hasRosterContinuity(scope, roster) {
  const knownExternal = new Set(Object.values(scope.accounts || {}).map((item) => normalizeRosterKey(item.externalAccountId)).filter(Boolean));
  const knownNames = new Set(Object.values(scope.accounts || {}).flatMap((item) => item.nicknameKeys || []));
  if (roster.some((item) => {
    const external = normalizeRosterKey(item.externalAccountId || item.accountId);
    return external && knownExternal.has(external);
  })) return true;
  const currentNames = new Set(roster.map((item) => normalizeRosterKey(item.nickname)).filter(Boolean));
  const overlap = [...currentNames].filter((key) => knownNames.has(key)).length;
  const baseline = Math.max(1, Math.min(currentNames.size, knownNames.size));
  return overlap / baseline >= 0.5;
}

function createScope(scopeId) {
  return { scopeId, paths: [], fingerprints: [], accounts: {}, createdAt: new Date().toISOString(), updatedAt: "" };
}

function identityConfirmationError(message, scopeId = "") {
  const error = new Error(message);
  error.code = "TUO_IDENTITY_CONFIRMATION_REQUIRED";
  error.scopeId = scopeId;
  return error;
}

function rosterFingerprint(roster) {
  const rows = roster.map((item) => ({
    externalAccountId: String(item.externalAccountId || ""),
    nickname: String(item.nickname || ""),
    remark: String(item.remark || "")
  })).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b), "zh-CN"));
  return sha256(JSON.stringify(rows));
}

function accountRowSignature(item) {
  return sha256(JSON.stringify({ nickname: normalizeRosterKey(item.nickname), remark: normalizeRosterKey(item.remark) }));
}

function accountProfileSignature(item) {
  return sha256(JSON.stringify({
    remark: normalizeRosterKey(item.remark),
    externalAccountId: normalizeRosterKey(item.externalAccountId),
    exactCategories: [...(item.exactCategories || [])].sort(),
    compatibleCategories: [...(item.compatibleCategories || [])].sort()
  }));
}

async function readRegistry(filePath) {
  try {
    const parsed = JSON.parse(await fs.readFile(filePath, "utf8"));
    if (parsed?.version === 1 && parsed.scopes && typeof parsed.scopes === "object") return parsed;
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
  }
  return { version: 1, revision: 0, updatedAt: "", scopes: {} };
}

async function withFileLock(lockPath, callback, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 10000);
  const started = Date.now();
  let handle;
  while (!handle) {
    try {
      handle = await fs.open(lockPath, "wx");
      await handle.writeFile(JSON.stringify({ pid: process.pid, createdAt: new Date().toISOString() }));
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      if (Date.now() - started >= timeoutMs) throw new Error(`等待托身份注册表锁超时：${lockPath}`);
      await new Promise((resolve) => setTimeout(resolve, 30));
    }
  }
  try {
    return await callback();
  } finally {
    await handle.close().catch(() => {});
    await fs.unlink(lockPath).catch(() => {});
  }
}

async function writeJsonAtomic(filePath, value) {
  const tempPath = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(tempPath, JSON.stringify(value, null, 2), "utf8");
  await fs.rename(tempPath, filePath);
}

function normalizePath(value) {
  return path.resolve(value || "").replace(/\\/g, "/").toLowerCase();
}

function countBy(items, keyFor) {
  const result = new Map();
  for (const item of items) {
    const key = keyFor(item);
    result.set(key, (result.get(key) || 0) + 1);
  }
  return result;
}

function unique(items) {
  return [...new Set(items.filter(Boolean))];
}

function sha256(value) {
  return crypto.createHash("sha256").update(String(value || "")).digest("hex");
}

export const __test = { rosterFingerprint, accountRowSignature, accountProfileSignature, withFileLock };

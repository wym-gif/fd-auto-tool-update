import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

export async function loadTuoUsageHistory({ projectRoot, scopeId, reconcile = true } = {}) {
  const root = path.resolve(projectRoot || process.cwd());
  if (!scopeId) return { scopeId: "", accounts: {}, events: [] };
  if (reconcile) await reconcileTuoUsageHistory({ projectRoot: root, scopeId });
  const eventDir = usageEventDir(root, scopeId);
  const events = [];
  for (const name of await readDirNames(eventDir)) {
    if (!name.endsWith(".json")) continue;
    const event = await readJsonIfExists(path.join(eventDir, name));
    if (event?.scopeId === scopeId && event.accountId && event.successAt) events.push(event);
  }
  events.sort((left, right) => String(left.successAt).localeCompare(String(right.successAt)) || String(left.eventId).localeCompare(String(right.eventId)));
  const accounts = {};
  for (const event of events) {
    const state = accounts[event.accountId] || { accountId: event.accountId, successCount: 0, lastSuccessAt: "", lastSequence: -1 };
    state.successCount += 1;
    state.lastSuccessAt = event.successAt;
    state.lastSequence = events.indexOf(event);
    accounts[event.accountId] = state;
  }
  return { scopeId, accounts, events };
}

export async function recordTuoUsageEvent({ projectRoot, event } = {}) {
  validateUsageEvent(event);
  const root = path.resolve(projectRoot || process.cwd());
  const eventDir = usageEventDir(root, event.scopeId);
  await fs.mkdir(eventDir, { recursive: true });
  const eventId = event.eventId || usageEventId(event);
  const filePath = path.join(eventDir, `${eventId}.json`);
  const payload = { version: 1, ...event, eventId, recordedAt: event.recordedAt || new Date().toISOString() };
  try {
    const handle = await fs.open(filePath, "wx");
    try {
      await handle.writeFile(JSON.stringify(payload, null, 2), "utf8");
    } finally {
      await handle.close();
    }
    return { created: true, event: payload, filePath };
  } catch (error) {
    if (error?.code !== "EEXIST") throw error;
    return { created: false, event: await readJsonIfExists(filePath), filePath };
  }
}

export async function reconcileTuoUsageHistory({ projectRoot, scopeId } = {}) {
  const root = path.resolve(projectRoot || process.cwd());
  const stateFiles = await findSubmitStateFiles(root);
  const result = { scanned: stateFiles.length, recorded: 0, alreadyRecorded: 0, manualRequired: 0 };
  for (const filePath of stateFiles) {
    await mutateJsonLocked(filePath, async (state) => {
      if (!state?.tasks || typeof state.tasks !== "object") return state;
      let changed = false;
      for (const record of Object.values(state.tasks)) {
        if (record?.status !== "succeeded" || record.usageRecordedAt || record.reconciliationStatus === "manual_required") continue;
        if (record.scopeId !== scopeId) continue;
        if (!record.accountId || !record.successAt || !record.tuoGroupKey) {
          record.reconciliationStatus = "manual_required";
          record.reconciliationReason = "旧成功记录缺少可靠的名单范围、账号身份、原始说话人组或成功时间，不能自动补账";
          result.manualRequired += 1;
          changed = true;
          continue;
        }
        const event = usageEventFromSubmitRecord(state, record);
        const written = await recordTuoUsageEvent({ projectRoot: root, event });
        if (written.created) result.recorded += 1;
        else result.alreadyRecorded += 1;
        record.usageRecordedAt = new Date().toISOString();
        record.usageEventId = written.event?.eventId || usageEventId(event);
        record.reconciliationStatus = "recorded";
        changed = true;
      }
      return changed ? { ...state, updatedAt: new Date().toISOString() } : state;
    });
  }
  return result;
}

export function usageEventFromSubmitRecord(state = {}, record = {}) {
  return {
    scopeId: record.scopeId,
    accountId: record.accountId,
    runIdentity: record.runIdentity || state.runId || "",
    tuoGroupKey: record.tuoGroupKey,
    successAt: record.successAt,
    nicknameAtSuccess: record.actualRobotNickname || record.speaker || "",
    externalAccountIdAtSuccess: record.externalAccountId || "",
    cmsAccountIdentityAtSuccess: record.cmsAccountIdentity || ""
  };
}

export function usageEventId(event = {}) {
  return crypto.createHash("sha256").update([
    event.scopeId,
    event.runIdentity,
    event.tuoGroupKey,
    event.accountId
  ].map((value) => String(value || "")).join("\n")).digest("hex");
}

function validateUsageEvent(event = {}) {
  for (const field of ["scopeId", "accountId", "runIdentity", "tuoGroupKey", "successAt"]) {
    if (!String(event[field] || "").trim()) throw new Error(`托实际使用事件缺少 ${field}`);
  }
}

async function findSubmitStateFiles(root) {
  const result = [];
  for (const name of await readDirNames(root)) {
    if (!/^runs(?:-|$)/i.test(name)) continue;
    const container = path.join(root, name);
    for (const child of await readDirNames(container)) {
      const candidate = path.join(container, child, "cms-submit-state.json");
      if (await fileExists(candidate)) result.push(candidate);
    }
    const direct = path.join(container, "cms-submit-state.json");
    if (await fileExists(direct)) result.push(direct);
  }
  return [...new Set(result)];
}

async function mutateJsonLocked(filePath, mutator) {
  const lockPath = `${filePath}.lock`;
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const handle = await acquireLock(lockPath);
  try {
    const current = await readJsonIfExists(filePath);
    if (!current) return null;
    const next = await mutator(current);
    if (next !== current) await writeJsonAtomic(filePath, next);
    return next;
  } finally {
    await handle.close().catch(() => {});
    await fs.unlink(lockPath).catch(() => {});
  }
}

async function acquireLock(lockPath, timeoutMs = 10000) {
  const started = Date.now();
  while (true) {
    try {
      const handle = await fs.open(lockPath, "wx");
      await handle.writeFile(JSON.stringify({ pid: process.pid, createdAt: new Date().toISOString() }));
      return handle;
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      if (Date.now() - started >= timeoutMs) throw new Error(`等待托历史文件锁超时：${lockPath}`);
      await new Promise((resolve) => setTimeout(resolve, 30));
    }
  }
}

async function writeJsonAtomic(filePath, value) {
  const tempPath = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(tempPath, JSON.stringify(value, null, 2), "utf8");
  await fs.rename(tempPath, filePath);
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw error;
  }
}

async function readDirNames(dirPath) {
  try {
    return await fs.readdir(dirPath);
  } catch (error) {
    if (error?.code === "ENOENT") return [];
    throw error;
  }
}

async function fileExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function usageEventDir(root, scopeId) {
  return path.join(root, "data", "tuo-usage", String(scopeId), "events");
}

export const __test = { findSubmitStateFiles, mutateJsonLocked };

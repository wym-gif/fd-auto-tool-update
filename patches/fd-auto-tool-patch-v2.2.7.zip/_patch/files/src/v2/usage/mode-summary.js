export function buildUsageModeSummary({ report = {}, librarySource = {}, libraryMeta = {} } = {}) {
  const sourceMode = sourceModeLabel(report, librarySource);
  const rangeMode = rangeModeLabel(report.readRange || {});
  const scheduleMode = scheduleModeLabel(report.schedule?.mode || librarySource.scheduleMode || libraryMeta.settingsSnapshot?.scheduleMode);
  const robotStrategy = robotStrategyLabel(report.robotStrategy || librarySource.robotStrategy || libraryMeta.settingsSnapshot?.robotStrategy);
  const configMode = configModeLabel(librarySource.configMode);
  const createMode = "正式创建 CMS";
  const parts = [sourceMode, rangeMode, scheduleMode, robotStrategy, configMode, createMode].filter(Boolean);
  return {
    sourceMode,
    rangeMode,
    scheduleMode,
    robotStrategy,
    configMode,
    createMode,
    summary: parts.join(" / ")
  };
}

function sourceModeLabel(report = {}, librarySource = {}) {
  const readRange = report.readRange || {};
  const sourceMode = cleanText(readRange.sourceMode);
  if (sourceMode) return sourceMode;
  if (librarySource.id) return "文案库";
  if (readRange.mode === "document-import") return "导入文档";
  return "";
}

function rangeModeLabel(readRange = {}) {
  const mode = cleanText(readRange.mode);
  if (!mode) return "";
  if (mode === "full") return "全文读取";
  if (mode === "manual") return "指定范围";
  if (mode === "heading") {
    const rhythm = cleanText(readRange.headingRhythm);
    const day = cleanText(readRange.headingDay || readRange.headingStartDay);
    if (rhythm || day) return ["按标题范围", rhythm, day && `第${day}天`].filter(Boolean).join(" ");
    return "按标题范围";
  }
  if (mode === "document-import") return "文档导入";
  return mode;
}

function scheduleModeLabel(mode) {
  const value = cleanText(mode);
  if (value === "doc") return "文档时间";
  if (value === "realtime") return "实时跟发";
  if (value === "catchup") return "补发到文档时间";
  return value;
}

function robotStrategyLabel(strategy) {
  const value = cleanText(strategy);
  if (value === "random") return "粗略版随机托";
  if (value === "fixed") return "精细版指定托";
  if (value === "precise") return "精准托";
  return value;
}

function configModeLabel(mode) {
  const value = cleanText(mode);
  if (value === "current") return "文案库按当前页面配置";
  if (value === "saved") return "文案库按保存配置";
  return "";
}

function cleanText(value) {
  return typeof value === "string" ? value.trim() : "";
}

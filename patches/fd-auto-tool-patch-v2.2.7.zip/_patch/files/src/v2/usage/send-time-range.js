export function buildUsageSendTimeRange(tasks = []) {
  if (!Array.isArray(tasks)) return {};
  const sendable = tasks
    .map((task, position) => ({ task: task || {}, position }))
    .filter(({ task }) => task && task.skip !== true);
  if (!sendable.length) return {};
  const first = summarizeSendPoint(sendable[0]);
  const last = summarizeSendPoint(sendable[sendable.length - 1]);
  if (!first.date && !first.time && !last.date && !last.time) return {};
  return { first, last };
}

function summarizeSendPoint({ task, position }) {
  return {
    index: positiveIndex(task.index, position + 1),
    date: clippedText(task.date, 24),
    time: clippedText(task.time, 24),
    role: clippedText(task.role, 24),
    type: clippedText(task.type, 24)
  };
}

function positiveIndex(value, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0) return fallback;
  return Math.floor(number);
}

function clippedText(value, max) {
  return String(value || "").slice(0, max);
}

import fs from "node:fs/promises";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { downloadLicenseServicePayloadToFile, postLicenseServicePayload } from "../license/license-manager.js";
import { finalPreviewPath, previewTasksPath, readPreviewTasks, saveFinalPreview, reviewLibraryPreviewWarnings } from "./preview-store.js";
import { listPreviewLibrary, previewLibraryRoot, resolvePreviewLibraryItem } from "./preview-library.js";

const META_FILE = "library-meta.json";
const MAX_PACKAGE_BYTES = 250 * 1024 * 1024;
const SERVER_SAFE_PACKAGE_BYTES = 128 * 1024 * 1024;
const DIRECT_UPLOAD_BYTES = 8 * 1024 * 1024;
const UPLOAD_CHUNK_CHARS = 5 * 1024 * 1024;
const SHARED_UPLOAD_DIAGNOSTIC_DIR = "shared-upload-diagnostics";

export async function uploadSharedPreviewLibraryItem(projectRoot, id, options = {}) {
  if (options.syncBeforeUpload !== false) {
    await syncSharedPreviewLibraryState(projectRoot, options).catch(() => null);
  }
  const prepared = await prepareSharedPreviewLibraryItemForUpload(projectRoot, id);
  if (prepared.ok === false) {
    throw new SharedMediaPackageError(prepared.problems || []);
  }
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const groupName = cleanGroupName(options.groupName ?? item.shared?.groupName ?? "");
  const pack = await buildSharedPackage(item, { groupName });
  let body;
  try {
    body = await uploadSharedLibraryPackage(projectRoot, {
      action: "shared-library-upload",
      groupName,
      library: pack
    }, { ...options, timeoutMs: options.timeoutMs ?? 60000 }, "上传共享文案失败。");
  } catch (error) {
    const action = error?.diagnostics?.action;
    const mayHaveCommitted = !error?.definitiveFailure &&
      ["shared-library-upload", "shared-library-upload-complete"].includes(action);
    const recoveryOptions = action === "shared-library-upload"
      ? { ...options, recoveryDelaysMs: options.recoveryDelaysMs ?? [0] }
      : options;
    const recovered = mayHaveCommitted
      ? await recoverSharedUploadByPackageHash(projectRoot, item, pack, recoveryOptions).catch(() => null)
      : null;
    if (recovered) return recovered;
    const diagnosticPath = await writeSharedUploadDiagnostic(projectRoot, item, error, pack).catch(() => "");
    if (diagnosticPath) error.diagnosticPath = diagnosticPath;
    throw error;
  }
  await updateLocalSharedMeta(item, body.item || {}, pack.packageHash);
  return {
    ok: true,
    item: await resolvePreviewLibraryItem(projectRoot, id),
    shared: body.item,
    items: await listPreviewLibrary(projectRoot)
  };
}

export async function syncSharedPreviewLibraryState(projectRoot, options = {}) {
  const localItems = await listPreviewLibrary(projectRoot);
  const localEntries = await sharedSyncEntries(projectRoot, localItems);
  if (!localEntries.length) return { ok: true, changed: false, items: localItems };
  const body = await postSharedLibraryPayload(projectRoot, {
    action: "shared-library-list"
  }, { ...options, timeoutMs: options.timeoutMs ?? 30000 }, "同步云端文案状态失败。");
  const cloudItems = Array.isArray(body.items) ? body.items : [];
  const changed = await syncLocalSharedStateFromCloudItems(localEntries, cloudItems);
  return { ok: true, changed, items: changed ? await listPreviewLibrary(projectRoot) : localItems };
}

async function sharedSyncEntries(projectRoot, localItems = []) {
  const diagnosticHints = await sharedUploadDiagnosticHints(projectRoot).catch(() => new Map());
  const entries = [];
  for (const item of localItems) {
    const meta = await readJsonIfExists(path.join(item.runDir, META_FILE));
    const pendingHash = sharedUploadPendingHash(meta) || diagnosticHints.get(item.id)?.packageHash || "";
    if (item.shared?.cloudId || item.shared?.packageHash || pendingHash) {
      entries.push({ item, meta, pendingHash });
    }
  }
  return entries;
}

async function syncLocalSharedStateFromCloudItems(localEntries = [], cloudItems = []) {
  const cloudById = new Map(cloudItems
    .filter((item) => item?.cloudId)
    .map((item) => [String(item.cloudId), item]));
  const cloudByHash = new Map();
  for (const cloud of cloudItems) {
    const hash = String(cloud?.packageHash || "");
    if (hash && !cloudByHash.has(hash)) cloudByHash.set(hash, cloud);
  }
  let changed = false;
  for (const entry of localEntries) {
    const item = entry.item;
    const shared = item.shared || {};
    const cloudId = String(shared.cloudId || "");
    const packageHash = String(shared.packageHash || entry.pendingHash || "");
    const matched = cloudId ? cloudById.get(cloudId) : null;
    const sameHash = packageHash ? cloudByHash.get(packageHash) : null;
    const matchedHash = String(matched?.packageHash || "");
    if (matched && packageHash && matchedHash && matchedHash === packageHash) {
      changed = await writeSyncedSharedMeta(item, matched, packageHash) || changed;
    } else if (sameHash) {
      changed = await writeSyncedSharedMeta(item, sameHash, packageHash) || changed;
    } else if (!matched && (cloudId || shared.packageHash)) {
      changed = await clearLocalSharedMeta(item) || changed;
    }
  }
  return changed;
}

export async function prepareSharedPreviewLibraryItemForUpload(projectRoot, id) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const tasks = await readPreviewTasks(finalPreviewPath(item.runDir));
  const itemMediaRoot = path.resolve(item.runDir, "media-cache");
  await fs.mkdir(itemMediaRoot, { recursive: true });
  await writePersistentMediaNotice(itemMediaRoot);
  const existingNames = await fs.readdir(itemMediaRoot).catch(() => []);
  const usedNames = new Set(existingNames.map((name) => name.toLowerCase()));
  const problems = [];
  let repairedCount = 0;
  const rewrittenTasks = [];
  for (const [index, task] of (Array.isArray(tasks) ? tasks : []).entries()) {
    const next = normalizeSharedPreviewTask(task);
    const mediaPath = String(next.mediaPath || "").trim();
    if (!isMediaTask(next) || next.skip) {
      rewrittenTasks.push(next);
      continue;
    }
    if (!mediaPath) {
      problems.push(sharedMediaProblem(index, next, "素材路径为空", mediaPath));
      rewrittenTasks.push(next);
      continue;
    }
    if (!shouldPackageLocalMedia(mediaPath)) {
      problems.push(sharedMediaProblem(index, next, "素材未落地到本地，无法上传共享", mediaPath));
      rewrittenTasks.push(next);
      continue;
    }
    const source = path.resolve(item.runDir, mediaPath);
    const stat = await fs.stat(source).catch(() => null);
    if (!stat?.isFile()) {
      problems.push(sharedMediaProblem(index, next, "素材不存在", mediaPath));
      rewrittenTasks.push(next);
      continue;
    }
    if (stat.size <= 0) {
      problems.push(sharedMediaProblem(index, next, "素材文件无效", mediaPath));
      rewrittenTasks.push(next);
      continue;
    }
    if (source.startsWith(itemMediaRoot + path.sep)) {
      next.mediaPath = source;
      rewrittenTasks.push(next);
      continue;
    }
    const destName = uniqueStableMediaName(mediaPath, index, usedNames);
    const dest = path.join(itemMediaRoot, destName);
    await fs.copyFile(source, dest);
    next.mediaPath = dest;
    repairedCount += 1;
    rewrittenTasks.push(next);
  }
  if (problems.length) {
    return {
      ok: false,
      code: "SHARED_MEDIA_PACKAGE_INCOMPLETE",
      problems,
      repairedCount
    };
  }
  if (repairedCount) {
    await saveFinalPreview(item.runDir, rewrittenTasks, { requireComplete: true });
    await fs.writeFile(previewTasksPath(item.runDir), JSON.stringify(rewrittenTasks, null, 2), "utf8");
    const metaPath = path.join(item.runDir, META_FILE);
    const meta = await readJsonIfExists(metaPath);
    await fs.writeFile(metaPath, JSON.stringify({
      ...meta,
      id: item.id,
      name: item.name,
      updatedAt: new Date().toISOString(),
      runDir: item.runDir,
      previewPath: finalPreviewPath(item.runDir),
      taskCount: rewrittenTasks.length
    }, null, 2), "utf8");
  }
  return {
    ok: true,
    item: repairedCount ? await resolvePreviewLibraryItem(projectRoot, id) : item,
    repairedCount,
    problems: []
  };
}

export async function listSharedPreviewLibrary(projectRoot, options = {}) {
  const localItems = await listPreviewLibrary(projectRoot);
  const body = await postSharedLibraryPayload(projectRoot, {
    action: "shared-library-list"
  }, { ...options, timeoutMs: options.timeoutMs ?? 30000 }, "读取云端文案失败。");
  const cloudItems = Array.isArray(body.items) ? body.items : [];
  const localEntries = await sharedSyncEntries(projectRoot, localItems);
  const changed = await syncLocalSharedStateFromCloudItems(localEntries, cloudItems);
  const syncedLocalItems = changed ? await listPreviewLibrary(projectRoot) : localItems;
  const localByCloudId = new Map(localItems
    .filter((item) => item.shared?.cloudId)
    .map((item) => [item.shared.cloudId, item]));
  const syncedByCloudId = new Map(syncedLocalItems
    .filter((item) => item.shared?.cloudId)
    .map((item) => [item.shared.cloudId, item]));
  const items = cloudItems.map((cloud) => {
    const local = syncedByCloudId.get(cloud.cloudId) || localByCloudId.get(cloud.cloudId);
    const localVersion = Number(local?.shared?.cloudVersion || 0);
    const cloudVersion = Number(cloud.cloudVersion || 0);
    return {
      ...cloud,
      localId: local?.id || "",
      localVersion,
      localStatus: local
        ? (cloudVersion > localVersion ? "update_available" : "current")
        : "not_downloaded"
    };
  });
  return { ok: true, items, groups: normalizeSharedGroups(body.groups, items) };
}

export async function downloadSharedPreviewLibraryItem(projectRoot, cloudId, options = {}) {
  const transfer = await createSharedTransfer(projectRoot, options.instanceId, "download");
  try {
    await downloadLicenseServicePayloadToFile(projectRoot, {
      action: "shared-library-download",
      cloudId
    }, transfer.filePath, {
      ...options,
      firstResponseTimeoutMs: options.firstResponseTimeoutMs ?? 30000,
      idleTimeoutMs: options.idleTimeoutMs ?? 60000,
      totalTimeoutMs: options.totalTimeoutMs ?? 10 * 60 * 1000,
      maxResponseBytes: MAX_PACKAGE_BYTES + 1024 * 1024
    });
    options.onProgress?.({ stage: "validating", receivedBytes: (await fs.stat(transfer.filePath)).size, totalBytes: 0 });
    const body = await readJsonPackageFile(transfer.filePath, MAX_PACKAGE_BYTES + 1024 * 1024, "云端文案响应");
    if (!body?.ok || !body.item || !body.package) throw new Error(body?.message || "云端文案响应缺少必要字段。");
    const item = await importSharedPackage(projectRoot, body.item, body.package);
    options.onProgress?.({ stage: "complete", receivedBytes: (await fs.stat(transfer.filePath)).size, totalBytes: 0 });
    return { ok: true, item, items: await listPreviewLibrary(projectRoot) };
  } finally {
    await fs.rm(transfer.dir, { recursive: true, force: true }).catch(() => {});
  }
}

export async function deleteSharedPreviewLibraryItem(projectRoot, cloudId, options = {}) {
  const body = await postSharedLibraryPayload(projectRoot, {
    action: "shared-library-delete",
    cloudId
  }, { ...options, timeoutMs: options.timeoutMs ?? 30000 }, "删除云端文案失败。");
  return { ok: true, deleted: body.deleted || {}, items: await listSharedPreviewLibrary(projectRoot, options).then((result) => result.items) };
}

export async function exportSharedPreviewLibraryItem(projectRoot, id, options = {}) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const pack = await buildSharedPackage(item);
  const outputDir = path.resolve(options.outputDir || path.join(projectRoot, "manual-shared-packages"));
  await fs.mkdir(outputDir, { recursive: true });
  const fileName = `${timestampForFile()}-${safeFileName(pack.name || item.name || "shared-copywriting")}.mq-shared-preview.json`;
  const filePath = path.join(outputDir, fileName);
  await fs.writeFile(filePath, JSON.stringify(pack, null, 2), "utf8");
  return {
    ok: true,
    item,
    fileName,
    filePath,
    packageBytes: pack.packageBytes,
    message: "共享包已导出。"
  };
}

export async function importSharedPreviewLibraryPackage(projectRoot, input = {}) {
  const fileName = String(input.fileName || "").trim();
  const contentBase64 = String(input.contentBase64 || "").replace(/^data:[^,]+,/, "");
  if (!contentBase64) throw new Error("导入失败：共享包文件为空。");
  if (fileName && !/\.json$/i.test(fileName)) throw new Error("导入失败：共享包只支持 .json 文件。");
  const buffer = Buffer.from(contentBase64, "base64");
  if (!buffer.length) throw new Error("导入失败：共享包文件为空。");
  if (buffer.length > MAX_PACKAGE_BYTES) {
    throw new Error(`导入失败：共享包太大，当前约 ${formatBytes(buffer.length)}，上限 ${formatBytes(MAX_PACKAGE_BYTES)}。`);
  }
  let pack;
  try {
    pack = JSON.parse(buffer.toString("utf8"));
  } catch {
    throw new Error("导入失败：共享包不是有效 JSON 文件。");
  }
  const item = await importSharedPackage(projectRoot, {
    cloudId: pack.cloudId || "",
    name: pack.name || "",
    taskCount: pack.taskCount || 0,
    cloudVersion: Number(pack.baseCloudVersion || 0),
    updatedAt: pack.updatedAt || "",
    packageHash: pack.packageHash || "",
    groupName: pack.groupName || ""
  }, pack, { forceNew: true });
  return { ok: true, item, items: await listPreviewLibrary(projectRoot) };
}

export async function importSharedPreviewLibraryFile(projectRoot, input = {}, options = {}) {
  const fileName = String(input.fileName || "").trim();
  const filePath = path.resolve(String(input.filePath || ""));
  if (!filePath) throw new Error("导入失败：共享包文件为空。");
  if (fileName && !/\.json$/i.test(fileName)) throw new Error("导入失败：共享包只支持 .json 文件。");
  const pack = await readJsonPackageFile(filePath, MAX_PACKAGE_BYTES, "共享包");
  options.onProgress?.({ stage: "validating", receivedBytes: (await fs.stat(filePath)).size, totalBytes: (await fs.stat(filePath)).size });
  const item = await importSharedPackage(projectRoot, {
    cloudId: pack.cloudId || "",
    name: pack.name || "",
    taskCount: pack.taskCount || 0,
    cloudVersion: Number(pack.baseCloudVersion || 0),
    updatedAt: pack.updatedAt || "",
    packageHash: pack.packageHash || "",
    groupName: pack.groupName || ""
  }, pack, { forceNew: true });
  return { ok: true, item, items: await listPreviewLibrary(projectRoot) };
}

export async function buildSharedPackage(item, options = {}) {
  const tasks = await reviewLibraryPreviewWarnings(path.dirname(path.dirname(item.runDir)), item.runDir,
    await readPreviewTasks(finalPreviewPath(item.runDir)));
  const { rewrittenTasks, mediaFiles } = await collectMediaFiles(item.runDir, tasks);
  const rawEvents = await readJsonIfExists(path.join(item.runDir, "raw-events.json"));
  const meta = await readJsonIfExists(path.join(item.runDir, META_FILE));
  const groupName = cleanGroupName(options.groupName ?? meta.shared?.groupName ?? "");
  const pack = {
    schemaVersion: 1,
    sourceLocalId: item.id,
    cloudId: meta.shared?.cloudId || "",
    baseCloudVersion: Number(meta.shared?.cloudVersion || 0),
    name: item.name || "未命名文案",
    groupName,
    taskCount: rewrittenTasks.length,
    updatedAt: item.updatedAt || meta.updatedAt || "",
    settingsSnapshot: normalizeSettingsSnapshot(meta.settingsSnapshot),
    tasks: rewrittenTasks,
    rawEvents: Array.isArray(rawEvents) ? rawEvents : [],
    mediaFiles
  };
  assertSharedPackageComplete(pack);
  const packageHash = sharedPackageContentHash(pack);
  const packageBytes = Buffer.byteLength(JSON.stringify({ ...pack, packageHash }), "utf8");
  if (packageBytes > MAX_PACKAGE_BYTES) {
    throw new Error(`共享文案包太大：当前约 ${formatBytes(packageBytes)}，云端上传上限 ${formatBytes(MAX_PACKAGE_BYTES)}。可以改用“导出共享包”手动发送给别人导入。`);
  }
  return { ...pack, packageHash, packageBytes };
}

async function collectMediaFiles(runDir, tasks) {
  const mediaFiles = [];
  const rewrittenTasks = [];
  const seen = new Set();
  const localToPackagePath = new Map();
  const missing = [];
  for (const [index, task] of (Array.isArray(tasks) ? tasks : []).entries()) {
    const next = normalizeSharedPreviewTask(task);
    const mediaPath = String(next.mediaPath || "").trim();
    if (isMediaTask(next) && !next.skip && !mediaPath) {
      missing.push(sharedMediaProblem(index, next, "素材路径为空", mediaPath));
      rewrittenTasks.push(next);
      continue;
    }
    if (isMediaTask(next) && !next.skip && mediaPath && !shouldPackageLocalMedia(mediaPath) && !/^data:/i.test(mediaPath)) {
      missing.push(sharedMediaProblem(index, next, "素材未落地到本地，无法上传共享", mediaPath));
      rewrittenTasks.push(next);
      continue;
    }
    let packageRel = mediaPath ? mediaRelativePath(runDir, mediaPath).replace(/\\/g, "/") : "";
    let filePath = packageRel ? path.join(runDir, packageRel) : "";
    if (!packageRel && mediaPath && shouldPackageLocalMedia(mediaPath)) {
      const resolved = path.resolve(runDir, mediaPath);
      filePath = resolved;
      packageRel = localToPackagePath.get(resolved) || "";
      if (!packageRel) {
        packageRel = `media-cache/${uniquePackageMediaName(mediaPath, index, seen)}`;
        localToPackagePath.set(resolved, packageRel);
      }
    }
    if (packageRel) {
      const stat = await fs.stat(filePath).catch(() => null);
      if (!stat?.isFile()) {
        missing.push(sharedMediaProblem(index, next, "素材不存在", mediaPath));
      } else if (stat.size <= 0) {
        missing.push(sharedMediaProblem(index, next, "素材文件无效", mediaPath));
      } else {
        next.mediaPath = packageRel;
        if (!seen.has(packageRel)) {
          seen.add(packageRel);
          const buffer = await fs.readFile(filePath);
          mediaFiles.push({
            path: packageRel,
            size: buffer.length,
            sha256: sha256(buffer),
            contentBase64: buffer.toString("base64")
          });
        }
      }
    }
    rewrittenTasks.push(next);
  }
  if (missing.length) {
    throw new SharedMediaPackageError(missing);
  }
  return { rewrittenTasks, mediaFiles };
}

class SharedMediaPackageError extends Error {
  constructor(problems = []) {
    const text = problems.map((problem) => problem.message).slice(0, 8).join("；");
    super(`共享文案上传失败：有 ${problems.length} 个素材无法打包到云端。${text}${problems.length > 8 ? "；..." : ""}。已自动打开预览并定位到第一条问题素材，请在标红行重新上传素材后保存，再重新上传共享。`);
    this.name = "SharedMediaPackageError";
    this.code = "SHARED_MEDIA_PACKAGE_INCOMPLETE";
    this.problems = problems;
  }
}

function sharedMediaProblem(index, task = {}, reason = "", mediaPath = "") {
  const taskIndex = index + 1;
  const type = String(task.type || "");
  const message = `第 ${taskIndex} 条${typeLabelForProblem(type)}${reason}${mediaPath ? `：${mediaPath}` : ""}`;
  return {
    index,
    taskIndex,
    type,
    typeLabel: typeLabelForProblem(type).trim(),
    reason,
    mediaPath,
    sourceId: task.sourceId || "",
    speaker: task.speaker || "",
    message
  };
}

function typeLabelForProblem(type) {
  if (type === "image") return "图片";
  if (type === "video") return "视频";
  if (type === "sticker") return "表情包";
  return "素材";
}

function assertSharedPackageComplete(pack = {}) {
  const mediaByPath = new Map((Array.isArray(pack.mediaFiles) ? pack.mediaFiles : [])
    .map((file) => [safePackagePath(file.path), file])
    .filter(([rel]) => rel));
  const missing = [];
  for (const [index, task] of (Array.isArray(pack.tasks) ? pack.tasks : []).entries()) {
    if (!isMediaTask(task) || task.skip) continue;
    const mediaPath = String(task.mediaPath || "").trim();
    const rel = safePackagePath(mediaPath);
    if (!rel.startsWith("media-cache/")) {
      missing.push(sharedMediaProblem(index, task, "素材没有写入共享包 media-cache", mediaPath || "空"));
      continue;
    }
    const file = mediaByPath.get(rel);
    if (!file) {
      missing.push(sharedMediaProblem(index, task, "素材未包含在共享包内", rel));
      continue;
    }
    const buffer = Buffer.from(String(file.contentBase64 || ""), "base64");
    if (!buffer.length || Number(file.size || 0) <= 0) {
      missing.push(sharedMediaProblem(index, task, "素材文件为空", rel));
      continue;
    }
    if (file.sha256 && sha256(buffer) !== file.sha256) {
      missing.push(sharedMediaProblem(index, task, "素材校验失败", rel));
    }
  }
  if (missing.length) {
    throw new SharedMediaPackageError(missing);
  }
}

function mediaRelativePath(runDir, mediaPath) {
  if (/^(sample|data|https?|blob|image-blob):/i.test(mediaPath)) return "";
  const resolved = path.resolve(mediaPath);
  const mediaRoot = path.resolve(runDir, "media-cache");
  if (!resolved.startsWith(mediaRoot + path.sep)) return "";
  return path.join("media-cache", path.relative(mediaRoot, resolved));
}

function shouldPackageLocalMedia(mediaPath) {
  if (/^(sample|data|https?|blob|image-blob):/i.test(mediaPath)) return false;
  return Boolean(String(mediaPath || "").trim());
}

async function importSharedPackage(projectRoot, cloudItem = {}, pack = {}, options = {}) {
  if (!pack || pack.schemaVersion !== 1) throw new Error("云端文案包格式不支持。");
  if (!Array.isArray(pack.tasks) || !Array.isArray(pack.mediaFiles) || !Array.isArray(pack.rawEvents || [])) throw new Error("共享文案包任务或素材结构无效。");
  if (Number(pack.taskCount ?? pack.tasks.length) !== pack.tasks.length) throw new Error("共享文案包任务数量校验失败。");
  assertSharedPackageComplete(pack);
  if (pack.packageHash && sharedPackageContentHash(pack) !== pack.packageHash) throw new Error("共享文案包整体校验失败。");
  const root = previewLibraryRoot(projectRoot);
  await fs.mkdir(root, { recursive: true });
  const existing = options.forceNew ? null : await localItemByCloudId(projectRoot, cloudItem.cloudId);
  const preferredId = safeLocalId(pack.sourceLocalId) || `shared_${safeLocalId(cloudItem.cloudId) || Date.now()}`;
  const id = existing?.id || await uniqueLocalId(root, preferredId);
  const itemDir = path.join(root, id);
  const stageDir = path.join(root, `.shared-stage-${id}-${randomUUID()}`);
  try {
    await fs.mkdir(path.join(stageDir, "media-cache"), { recursive: true });
    await writePersistentMediaNotice(path.join(stageDir, "media-cache"));
    const seenMedia = new Set();
    for (const file of Array.isArray(pack.mediaFiles) ? pack.mediaFiles : []) {
      const rel = safePackagePath(file.path);
      if (!rel.startsWith("media-cache/") || seenMedia.has(rel)) throw new Error("云端素材路径不安全或重复。");
      seenMedia.add(rel);
      const buffer = Buffer.from(String(file.contentBase64 || ""), "base64");
      if (Number(file.size || 0) !== buffer.length) throw new Error(`云端素材大小校验失败：${rel}。`);
      if (file.sha256 && sha256(buffer) !== file.sha256) throw new Error(`云端素材哈希校验失败：${rel}。`);
      const dest = path.join(stageDir, ...rel.split("/"));
      await fs.mkdir(path.dirname(dest), { recursive: true });
      await fs.writeFile(dest, buffer);
    }
  const missing = [];
  let tasks = (Array.isArray(pack.tasks) ? pack.tasks : []).map((task, index) => {
    const next = normalizeSharedPreviewTask(task);
    const mediaPath = String(next.mediaPath || "").trim();
    const rel = safePackagePath(mediaPath);
    if (rel.startsWith("media-cache/")) {
      const localPath = path.join(itemDir, ...rel.split("/"));
      next.mediaPath = localPath;
    } else if (isMediaTask(next) && shouldPackageLocalMedia(mediaPath)) {
      missing.push(`第 ${index + 1} 条素材未包含在云端包内：${mediaPath}`);
    }
    return next;
  });
  const missingAfterWrite = [];
  for (const [index, task] of tasks.entries()) {
    if (!isMediaTask(task) || task.skip) continue;
    const mediaPath = String(task.mediaPath || "").trim();
    if (!shouldPackageLocalMedia(mediaPath)) continue;
    const rel = safePackagePath(path.relative(itemDir, path.resolve(mediaPath)).replace(/\\/g, "/"));
    const stat = rel ? await fs.stat(path.join(stageDir, ...rel.split("/"))).catch(() => null) : null;
    if (!stat?.isFile()) missingAfterWrite.push(`第 ${index + 1} 条素材缺失：${mediaPath}`);
  }
  const allMissing = [...missing, ...missingAfterWrite];
  if (allMissing.length) {
    throw new Error(`云端文案包缺少素材文件，无法下载使用。${allMissing.slice(0, 8).join("；")}${allMissing.length > 8 ? "；..." : ""}。请让上传方用新版重新上传，或改用“导出共享包”手动发送。`);
  }
  const stagedTasks = tasks.map((task) => ({
    ...task,
    mediaPath: String(task.mediaPath || "").startsWith(itemDir + path.sep)
      ? path.join(stageDir, path.relative(itemDir, task.mediaPath))
      : task.mediaPath
  }));
  const stagedSave = await saveFinalPreview(stageDir, stagedTasks, { requireComplete: true });
  tasks = stagedSave.tasks.map((task) => ({
    ...task,
    mediaPath: String(task.mediaPath || "").startsWith(stageDir + path.sep)
      ? path.join(itemDir, path.relative(stageDir, task.mediaPath))
      : task.mediaPath
  }));
  await saveFinalPreview(stageDir, tasks);
  await fs.writeFile(previewTasksPath(stageDir), JSON.stringify(tasks, null, 2), "utf8");
  await fs.writeFile(path.join(stageDir, "raw-events.json"), JSON.stringify(Array.isArray(pack.rawEvents) ? pack.rawEvents : [], null, 2), "utf8");
  const now = new Date().toISOString();
  const meta = {
    id,
    name: cleanName(cloudItem.name || pack.name) || "云端文案",
    createdAt: existing?.createdAt || now,
    updatedAt: cloudItem.updatedAt || pack.updatedAt || now,
    sourceRunDir: "",
    runDir: itemDir,
    previewPath: finalPreviewPath(itemDir),
    taskCount: tasks.length,
    shared: {
      cloudId: cloudItem.cloudId || pack.cloudId || "",
      cloudVersion: Number(cloudItem.cloudVersion || 0),
      groupName: cleanGroupName(cloudItem.groupName || pack.groupName || ""),
      uploadedAt: cloudItem.uploadedAt || "",
      packageHash: cloudItem.packageHash || pack.packageHash || "",
      downloadedAt: now
    },
    settingsSnapshot: normalizeSettingsSnapshot(pack.settingsSnapshot)
  };
  await fs.writeFile(path.join(stageDir, META_FILE), JSON.stringify(meta, null, 2), "utf8");
  await promoteSharedImport(stageDir, itemDir, existing);
  await listPreviewLibrary(projectRoot);
  return resolvePreviewLibraryItem(projectRoot, id);
  } catch (error) {
    await fs.rm(stageDir, { recursive: true, force: true }).catch(() => {});
    if (error?.code === "ENOSPC") throw new Error("磁盘剩余空间不足，共享包未导入。");
    throw error;
  }
}

async function promoteSharedImport(stageDir, itemDir, existing) {
  if (!existing) {
    await fs.rename(stageDir, itemDir);
    return;
  }
  const backupDir = `${itemDir}.shared-backup-${randomUUID()}`;
  await fs.rename(itemDir, backupDir);
  try {
    await fs.rename(stageDir, itemDir);
  } catch (error) {
    await fs.rename(backupDir, itemDir).catch(() => {});
    throw error;
  }
  await fs.rm(backupDir, { recursive: true, force: true }).catch(() => {});
}

async function createSharedTransfer(projectRoot, instanceId, kind) {
  const instance = safeLocalId(instanceId) || "default";
  const dir = path.join(projectRoot, "data", "shared-package-transfers", instance, `${kind}-${randomUUID()}`);
  await fs.mkdir(dir, { recursive: true });
  return { dir, filePath: path.join(dir, "package.json.part") };
}

async function readJsonPackageFile(filePath, maxBytes, label) {
  const stat = await fs.stat(filePath).catch(() => null);
  if (!stat?.isFile() || stat.size <= 0) throw new Error(`${label}文件为空。`);
  if (stat.size > maxBytes) throw new Error(`${label}太大，当前约 ${formatBytes(stat.size)}，上限 ${formatBytes(maxBytes)}。`);
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch (error) {
    if (error instanceof SyntaxError) throw new Error(`${label}不是有效 JSON，可能下载未完成或文件已损坏。`);
    throw error;
  }
}

function normalizeSettingsSnapshot(settings = {}) {
  if (!settings || typeof settings !== "object") return null;
  const snapshot = JSON.parse(JSON.stringify(settings));
  delete snapshot.cdpUrl;
  delete snapshot.updatedAt;
  return Object.keys(snapshot).length ? snapshot : null;
}

async function postSharedLibraryPayload(projectRoot, payload, options, fallback, context = {}) {
  let body;
  try {
    body = await postLicenseServicePayload(projectRoot, payload, options);
  } catch (error) {
    throw createSharedUploadError(error, fallback, context);
  }
  if (!body?.ok) throw createSharedUploadError(new Error(body?.message || body?.error || fallback), fallback, {
    ...context,
    responseCode: body?.code || "",
    definitiveFailure: body?.ok === false
  });
  return body;
}

async function uploadSharedLibraryPackage(projectRoot, payload, options, fallback) {
  const pack = payload?.library;
  const packageJson = JSON.stringify(pack || {});
  const packageBytes = Buffer.byteLength(packageJson, "utf8");
  if (packageBytes > SERVER_SAFE_PACKAGE_BYTES) {
    throw new Error(`共享文案包约 ${formatBytes(packageBytes)}，超过当前服务器 128MB 安全处理预算。未上传任何分片，也不会覆盖原云端文案；请先导出共享包，待服务器拆分或扩容后再上传。`);
  }
  const packageHash = sharedPackageContentHash(pack);
  const rawHash = sha256(packageJson);
  const appVersion = await readAppVersion(projectRoot);
  const baseContext = {
    appVersion,
    groupName: payload.groupName || "",
    packageBytes,
    packageHash,
    rawHash
  };
  if (packageBytes <= DIRECT_UPLOAD_BYTES) {
    await reportSharedUploadProgress(options, `正在上传共享文案：直传阶段，${formatBytes(packageBytes)}。请不要关闭页面。`, {
      uploadMode: "direct",
      packageBytes
    });
    return postSharedLibraryPayload(projectRoot, {
      ...payload,
      packageHash,
      rawHash,
      packageBytes
    }, options, fallback, {
      ...baseContext,
      uploadMode: "direct",
      action: payload.action || "shared-library-upload"
    });
  }
  const encoded = Buffer.from(packageJson, "utf8").toString("base64");
  const chunks = [];
  for (let offset = 0; offset < encoded.length; offset += UPLOAD_CHUNK_CHARS) {
    chunks.push(encoded.slice(offset, offset + UPLOAD_CHUNK_CHARS));
  }
  const uploadId = stableSharedUploadId(packageHash);
  const status = await readSharedUploadStatus(projectRoot, {
    action: "shared-library-upload-status",
    groupName: payload.groupName || "",
    uploadId,
    packageHash,
    rawHash,
    packageBytes,
    chunkCount: chunks.length
  }, options, {
    ...baseContext,
    uploadId,
    packageHash,
    uploadMode: "chunked",
    action: "shared-library-upload-status",
    chunkCount: chunks.length,
    base64Chars: encoded.length
  });
  if (status?.item?.cloudId) return { ok: true, item: status.item, message: status.message || "云端已有相同文案，已按上传成功处理。" };
  const existingChunks = new Set((Array.isArray(status?.existingChunks) ? status.existingChunks : [])
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value >= 0 && value < chunks.length));
  if (existingChunks.size > 0) {
    await reportSharedUploadProgress(options, `已检测到之前上传过 ${existingChunks.size}/${chunks.length} 片，本次只补传未完成分片。`, {
      ...baseContext,
      uploadId,
      packageHash,
      uploadMode: "chunked",
      action: "shared-library-upload-status",
      chunkCount: chunks.length,
      existingCount: existingChunks.size
    });
  } else {
    await reportSharedUploadProgress(options, `正在上传共享文案：准备上传 ${chunks.length} 片，${formatBytes(packageBytes)}，暂无可复用分片。`, {
      ...baseContext,
      uploadId,
      packageHash,
      uploadMode: "chunked",
      action: "shared-library-upload-status",
      chunkCount: chunks.length,
      existingCount: 0
    });
  }
  for (const [index, content] of chunks.entries()) {
    if (existingChunks.has(index)) {
      await reportSharedUploadProgress(options, sharedUploadChunkReuseMessage({ ...baseContext, uploadId, chunkIndex: index, chunkCount: chunks.length }), {
        ...baseContext,
        uploadId,
        packageHash,
        uploadMode: "chunked",
        action: "shared-library-upload-chunk",
        chunkIndex: index,
        chunkCount: chunks.length,
        reused: true
      });
      continue;
    }
    await uploadSharedLibraryChunkWithRetry(projectRoot, {
      action: "shared-library-upload-chunk",
      groupName: payload.groupName || "",
      uploadId,
      packageHash,
      rawHash,
      packageBytes,
      chunkIndex: index,
      chunkCount: chunks.length,
      content
    }, options, fallback, {
      ...baseContext,
      packageHash,
      uploadId,
      uploadMode: "chunked",
      action: "shared-library-upload-chunk",
      chunkIndex: index,
      chunkCount: chunks.length,
      chunkChars: content.length,
      base64Chars: encoded.length
    });
  }
  await reportSharedUploadProgress(options, `分片上传完成，正在合并云端文案：共 ${chunks.length} 片，${formatBytes(packageBytes)}。服务器可能还需要 1-3 分钟，请不要关闭页面。`, {
    uploadMode: "chunked",
    action: "shared-library-upload-complete",
    packageBytes,
    uploadId,
    chunkCount: chunks.length
  });
  return postSharedLibraryPayload(projectRoot, {
    action: "shared-library-upload-complete",
    groupName: payload.groupName || "",
    uploadId,
    packageHash,
    rawHash,
    packageBytes,
    chunkCount: chunks.length
  }, options, fallback, {
    ...baseContext,
    packageHash,
    uploadId,
    uploadMode: "chunked",
    action: "shared-library-upload-complete",
    chunkCount: chunks.length,
    base64Chars: encoded.length
  });
}

async function readSharedUploadStatus(projectRoot, payload, options, context = {}) {
  const maxBusyAttempts = 3;
  for (let attempt = 1; attempt <= maxBusyAttempts; attempt += 1) {
    try {
      return await postSharedLibraryPayload(projectRoot, payload, { ...options, timeoutMs: options.timeoutMs ?? 30000 }, "", context);
    } catch (error) {
      if (error?.code !== "HEAVY_OPERATION_BUSY" || attempt >= maxBusyAttempts) return null;
      const delayMs = Math.min(15000, Math.max(1000, Number(options.heavyBusyDelayMs ?? 8000)));
      await reportSharedUploadProgress(options,
        `服务器正在处理另一项大文案任务，本次尚未执行；${Math.ceil(delayMs / 1000)} 秒后重新查询上传状态（${attempt}/${maxBusyAttempts - 1}）。`,
        { ...context, waitReason: "heavy-operation-busy", attempt, maxAttempts: maxBusyAttempts, retryDelayMs: delayMs });
      await sleep(delayMs);
    }
  }
  return null;
}

async function uploadSharedLibraryChunkWithRetry(projectRoot, payload, options, fallback, context = {}) {
  const maxAttempts = sharedUploadChunkRetryAttempts(options);
  let lastError = null;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const progress = sharedUploadChunkProgressMessage(context, attempt, maxAttempts);
    await reportSharedUploadProgress(options, progress, { ...context, attempt, maxAttempts });
    try {
      await postSharedLibraryPayload(projectRoot, payload, options, fallback, {
        ...context,
        attempt,
        maxAttempts
      });
      return;
    } catch (error) {
      lastError = error;
      if (attempt >= maxAttempts || !shouldRetrySharedUploadChunk(error)) throw error;
      const delayMs = sharedUploadRetryDelayMs(attempt, options);
      await reportSharedUploadProgress(options, sharedUploadChunkRetryMessage(context, attempt + 1, maxAttempts, delayMs), {
        ...context,
        attempt: attempt + 1,
        maxAttempts,
        retryDelayMs: delayMs
      });
      await sleep(delayMs);
    }
  }
  throw lastError || new Error(fallback);
}

function sharedUploadChunkRetryAttempts(options = {}) {
  const value = Number(options.chunkRetryAttempts ?? 5);
  if (!Number.isFinite(value) || value < 1) return 5;
  return Math.min(8, Math.max(1, Math.floor(value)));
}

function sharedUploadRetryDelayMs(attempt, options = {}) {
  const configured = Number(options.chunkRetryDelayMs);
  if (Number.isFinite(configured) && configured >= 0) return Math.min(15000, Math.floor(configured));
  return Math.min(15000, 1200 * Math.max(1, attempt));
}

function shouldRetrySharedUploadChunk(error = {}) {
  const status = Number(error.responseStatus || error.diagnostics?.responseStatus || 0);
  if (status === 413 || status === 401 || status === 403) return false;
  if (status === 0 || status === 408 || status === 429 || status >= 500) return true;
  const text = String(error.message || "");
  return /网络|超时|timeout|AbortError|fetch failed|ECONN|ENOTFOUND|EAI_AGAIN|Failed to fetch|Gateway|网关|APISIX/i.test(text);
}

async function reportSharedUploadProgress(options = {}, message = "", detail = {}) {
  if (typeof options.onProgress !== "function" || !message) return;
  await options.onProgress(message, detail).catch(() => {});
}

function sharedUploadChunkProgressMessage(context = {}, attempt = 1, maxAttempts = 1) {
  const index = Number(context.chunkIndex || 0) + 1;
  const total = Number(context.chunkCount || 0) || "?";
  const packageSize = formatBytes(context.packageBytes || 0);
  const percent = sharedUploadChunkPercent(context);
  const retry = attempt > 1 ? `；第 ${attempt}/${maxAttempts} 次尝试` : "";
  return `正在上传共享文案：第 ${index}/${total} 片，${packageSize}，已完成 ${percent}%${retry}。请不要关闭页面。`;
}

function sharedUploadChunkRetryMessage(context = {}, nextAttempt = 2, maxAttempts = 5, delayMs = 0) {
  const index = Number(context.chunkIndex || 0) + 1;
  const total = Number(context.chunkCount || 0) || "?";
  const seconds = Math.max(1, Math.ceil(Number(delayMs || 0) / 1000));
  const reuseText = index <= 1
    ? "第 1 片还没有上传成功，暂无可复用内容。"
    : "前面已成功的分片会继续复用。";
  return `上传第 ${index}/${total} 片时网络没有稳定返回，${seconds} 秒后自动重试第 ${nextAttempt}/${maxAttempts} 次；${reuseText}`;
}

function sharedUploadChunkReuseMessage(context = {}) {
  const index = Number(context.chunkIndex || 0) + 1;
  const total = Number(context.chunkCount || 0) || "?";
  const percent = sharedUploadChunkPercent({ ...context, chunkIndex: index });
  return `正在上传共享文案：第 ${index}/${total} 片已在服务器上，自动复用；已完成 ${percent}%。`;
}

function sharedUploadChunkPercent(context = {}) {
  const index = Number(context.chunkIndex || 0);
  const count = Number(context.chunkCount || 0);
  if (!Number.isFinite(index) || !Number.isFinite(count) || count <= 0) return 0;
  return Math.max(0, Math.min(99, Math.floor((index / count) * 100)));
}

async function recoverSharedUploadByPackageHash(projectRoot, item, pack, options = {}) {
  const packageHashes = sharedPackageHashCandidates(pack);
  if (!packageHashes.length) return null;
  const wanted = new Set(packageHashes);
  let cloudItem = null;
  const delays = sharedUploadRecoveryDelays(options);
  for (const [attemptIndex, delayMs] of delays.entries()) {
    if (delayMs > 0) await sleep(delayMs);
    await reportSharedUploadProgress(options, `合并接口没有及时返回，正在确认云端是否已保存：第 ${attemptIndex + 1}/${delays.length} 次。请不要关闭页面。`, {
      packageHash: packageHashes[0],
      packageBytes: pack?.packageBytes || 0,
      action: "shared-library-list",
      uploadMode: "recover",
      attempt: attemptIndex + 1,
      maxAttempts: delays.length
    });
    try {
      const body = await postSharedLibraryPayload(projectRoot, {
        action: "shared-library-list"
      }, { ...options, timeoutMs: options.recoveryTimeoutMs ?? Math.min(Number(options.timeoutMs || 30000), 30000) }, "确认云端文案失败。", {
        packageHash: packageHashes[0],
        packageBytes: pack?.packageBytes || 0,
        action: "shared-library-list",
        uploadMode: "recover",
        attempt: attemptIndex + 1,
        maxAttempts: delays.length
      });
      cloudItem = (Array.isArray(body.items) ? body.items : []).find((candidate) =>
        wanted.has(String(candidate?.packageHash || ""))
      );
    } catch (error) {
      // The merge endpoint may still be occupying the backend while APISIX has
      // already timed out. Keep polling instead of turning the first check into
      // a final upload failure.
    }
    if (cloudItem) break;
  }
  if (!cloudItem) return null;
  await updateLocalSharedMeta(item, cloudItem, cloudItem.packageHash || packageHashes[0]);
  return {
    ok: true,
    recovered: true,
    message: "云端已收到这份文案，已按上传成功处理。",
    item: await resolvePreviewLibraryItem(projectRoot, item.id),
    shared: cloudItem,
    items: await listPreviewLibrary(projectRoot)
  };
}

function sharedUploadRecoveryDelays(options = {}) {
  const configured = Array.isArray(options.recoveryDelaysMs) ? options.recoveryDelaysMs : [0, 3000, 8000, 15000, 30000, 60000, 90000];
  const delays = configured
    .map((value) => Number(value))
    .filter((value) => Number.isFinite(value) && value >= 0)
    .map((value) => Math.min(Math.floor(value), 90000));
  return delays.length ? delays : [0];
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function sharedPackageHashCandidates(pack = {}) {
  const hashes = [];
  const add = (value) => {
    const hash = String(value || "");
    if (/^[a-fA-F0-9]{64}$/.test(hash) && !hashes.includes(hash)) hashes.push(hash);
  };
  add(pack.packageHash);
  try {
    add(sharedPackageContentHash(pack));
  } catch {
    // Ignore non-serializable input; buildSharedPackage returns plain objects.
  }
  try {
    add(sha256(JSON.stringify(pack || {})));
  } catch {
    // Ignore non-serializable input; buildSharedPackage returns plain objects.
  }
  return hashes;
}

async function updateLocalSharedMeta(item, cloudItem, packageHash) {
  const metaPath = path.join(item.runDir, META_FILE);
  const meta = await readJsonIfExists(metaPath);
  const { lastSharedUpload: _lastSharedUpload, ...cleanMeta } = meta;
  const next = {
    ...cleanMeta,
    shared: {
      ...(meta.shared || {}),
      cloudId: cloudItem.cloudId || meta.shared?.cloudId || "",
      cloudVersion: Number(cloudItem.cloudVersion || 0),
      groupName: cleanGroupName(cloudItem.groupName ?? meta.shared?.groupName ?? ""),
      uploadedAt: cloudItem.uploadedAt || new Date().toISOString(),
      packageHash: cloudItem.packageHash || packageHash,
      downloadedAt: meta.shared?.downloadedAt || ""
    }
  };
  await fs.writeFile(metaPath, JSON.stringify(next, null, 2), "utf8");
}

async function writeSyncedSharedMeta(item, cloudItem, packageHash = "") {
  const metaPath = path.join(item.runDir, META_FILE);
  const meta = await readJsonIfExists(metaPath);
  const current = meta.shared || {};
  const { lastSharedUpload: _lastSharedUpload, ...cleanMeta } = meta;
  const nextShared = {
    ...current,
    cloudId: cloudItem.cloudId || current.cloudId || "",
    cloudVersion: Number(cloudItem.cloudVersion || 0),
    groupName: cleanGroupName(cloudItem.groupName ?? current.groupName ?? ""),
    uploadedAt: cloudItem.uploadedAt || current.uploadedAt || "",
    packageHash: cloudItem.packageHash || packageHash || current.packageHash || "",
    downloadedAt: current.downloadedAt || ""
  };
  if (JSON.stringify(current) === JSON.stringify(nextShared) && !meta.lastSharedUpload) return false;
  await fs.writeFile(metaPath, JSON.stringify({ ...cleanMeta, shared: nextShared }, null, 2), "utf8");
  return true;
}

function sharedUploadPendingHash(meta = {}) {
  const last = meta?.lastSharedUpload;
  if (!last || typeof last !== "object") return "";
  const status = String(last.status || "");
  const hash = String(last.packageHash || "");
  if (status !== "pending_confirm") return "";
  return /^[a-fA-F0-9]{64}$/.test(hash) ? hash : "";
}

async function sharedUploadDiagnosticHints(projectRoot) {
  const root = path.join(projectRoot, "logs", SHARED_UPLOAD_DIAGNOSTIC_DIR);
  const files = await fs.readdir(root, { withFileTypes: true }).catch(() => []);
  const stats = [];
  for (const file of files) {
    if (!file.isFile() || !file.name.endsWith(".json")) continue;
    const filePath = path.join(root, file.name);
    const stat = await fs.stat(filePath).catch(() => null);
    if (stat?.isFile()) stats.push({ filePath, mtimeMs: stat.mtimeMs });
  }
  stats.sort((a, b) => b.mtimeMs - a.mtimeMs);
  const result = new Map();
  for (const entry of stats.slice(0, 200)) {
    const diagnostic = await readJsonIfExists(entry.filePath);
    const itemId = String(diagnostic?.item?.id || "");
    const packageHash = String(diagnostic?.upload?.packageHash || "");
    if (!itemId || !/^[a-fA-F0-9]{64}$/.test(packageHash) || result.has(itemId)) continue;
    result.set(itemId, { packageHash, diagnosticPath: entry.filePath });
  }
  return result;
}

async function clearLocalSharedMeta(item) {
  const metaPath = path.join(item.runDir, META_FILE);
  const meta = await readJsonIfExists(metaPath);
  if (!meta.shared) return false;
  const { shared: _shared, ...next } = meta;
  await fs.writeFile(metaPath, JSON.stringify(next, null, 2), "utf8");
  return true;
}

async function localItemByCloudId(projectRoot, cloudId) {
  const wanted = String(cloudId || "");
  if (!wanted) return null;
  const items = await listPreviewLibrary(projectRoot);
  return items.find((item) => item.shared?.cloudId === wanted) || null;
}

async function uniqueLocalId(root, preferred) {
  const base = safeLocalId(preferred) || `shared_${Date.now()}`;
  let candidate = base;
  for (let index = 2; index < 1000; index += 1) {
    if (!await pathExists(path.join(root, candidate))) return candidate;
    candidate = `${base}_${index}`;
  }
  return `${base}_${Date.now()}`;
}

function safePackagePath(value) {
  const normalized = String(value || "").replace(/\\/g, "/");
  if (!normalized || normalized.startsWith("/") || /^[a-zA-Z]:/.test(normalized) || normalized.includes("..")) return "";
  return normalized;
}

function uniquePackageMediaName(mediaPath, index, used) {
  const ext = path.extname(mediaPath) || ".bin";
  const base = path.basename(mediaPath, ext).replace(/[^\w.-]+/g, "_").slice(0, 60) || "media";
  let name = `${String(index + 1).padStart(3, "0")}-${base}${ext}`;
  let attempt = 1;
  while (used.has(`media-cache/${name}`)) {
    name = `${String(index + 1).padStart(3, "0")}-${base}-${attempt}${ext}`;
    attempt += 1;
  }
  return name;
}

function uniqueStableMediaName(mediaPath, index, used) {
  const ext = path.extname(mediaPath) || ".bin";
  const base = path.basename(mediaPath, ext).replace(/[^\w.-]+/g, "_").slice(0, 60) || "media";
  let name = `${String(index + 1).padStart(3, "0")}-${base}${ext}`;
  let attempt = 1;
  while (used.has(name.toLowerCase())) {
    name = `${String(index + 1).padStart(3, "0")}-${base}-${attempt}${ext}`;
    attempt += 1;
  }
  used.add(name.toLowerCase());
  return name;
}

function isMediaTask(task = {}) {
  return ["image", "sticker", "video"].includes(String(task.type || ""));
}

function normalizeSharedPreviewTask(task = {}) {
  const next = { ...task };
  const type = String(next.type || "");
  if (type === "text" && looksLikeFinderTaskText(next.text || next.sourceText || "")) {
    next.type = "finder";
    if (!String(next.text || "").trim() && String(next.sourceText || "").trim()) {
      next.text = String(next.sourceText);
    }
  }
  return next;
}

function looksLikeFinderTaskText(value) {
  const text = String(value || "");
  if (!text.trim()) return false;
  return /<finderFeed\b/i.test(text) || /<type>\s*51\s*<\/type>/i.test(text);
}

function safeLocalId(value) {
  const id = String(value || "").trim();
  return /^[a-zA-Z0-9_.-]+$/.test(id) ? id : "";
}

function cleanName(value) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 80);
}

function cleanGroupName(value) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 40);
}

function normalizeSharedGroups(groups, items = []) {
  const result = [];
  for (const name of ["开群组", "老群组", "合集组"]) {
    if (!result.includes(name)) result.push(name);
  }
  for (const name of Array.isArray(groups) ? groups : []) {
    const clean = cleanGroupName(name);
    if (clean && !result.includes(clean)) result.push(clean);
  }
  for (const item of Array.isArray(items) ? items : []) {
    const clean = cleanGroupName(item.groupName);
    if (clean && !result.includes(clean)) result.push(clean);
  }
  return result;
}

function safeFileName(value) {
  return cleanName(value).replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/\s+/g, "_").slice(0, 60) || "shared-copywriting";
}

function timestampForFile() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

function formatBytes(value) {
  const bytes = Number(value) || 0;
  if (bytes >= 1024 * 1024) return `${Math.ceil(bytes / 1024 / 1024)}MB`;
  if (bytes >= 1024) return `${Math.ceil(bytes / 1024)}KB`;
  return `${bytes}B`;
}

function normalizeSharedErrorMessage(message, fallback) {
  const text = String(message || "").trim();
  if (!text) return fallback;
  if (/授权服务返回非 JSON|授权服务返回内容过大/.test(text)) return text;
  if (/JSON|Unexpected token|not valid JSON|HTML|DOCTYPE|不是 JSON/i.test(text)) {
    return "授权总控返回了网页或非 JSON 内容，通常是服务地址、网关或后台服务异常。";
  }
  if (/body|size|too large|413|超过|过大|too big/i.test(text)) {
    return "共享包太大或超过服务器限制。可以改用“导出共享包”手动发送给别人导入。";
  }
  if (/timeout|超时|aborted|AbortError/i.test(text)) {
    return "连接授权总控超时，请检查公司网络或稍后重试。";
  }
  if (/fetch failed|ECONN|ENOTFOUND|EAI_AGAIN|network|网络/i.test(text)) {
    return "连接授权总控失败，请检查公司网络或 VPN。";
  }
  return text;
}

function createSharedUploadError(error, fallback, context = {}) {
  const rawMessage = error?.message || String(error || "");
  const normalized = normalizeSharedErrorMessage(rawMessage, fallback);
  const detail = sharedUploadDiagnosticSummary(context, error);
  const next = new Error(detail ? `${normalized}（${detail}）` : normalized);
  next.code = error?.code || context.responseCode || "";
  next.responseStatus = error?.responseStatus || 0;
  next.contentType = error?.contentType || "";
  next.responseSnippet = error?.responseSnippet || "";
  next.definitiveFailure = context.definitiveFailure === true ||
    (next.responseStatus >= 400 && next.responseStatus < 500 && next.responseStatus !== 408);
  next.diagnostics = buildSharedUploadDiagnostics(context, error, normalized, rawMessage);
  return next;
}

function sharedUploadDiagnosticSummary(context = {}, error = {}) {
  const parts = [];
  if (context.uploadMode === "chunked" && context.action === "shared-library-upload-chunk") {
    parts.push(`分片上传第 ${Number(context.chunkIndex || 0) + 1}/${context.chunkCount || "?"} 片`);
  } else if (context.uploadMode === "chunked" && context.action === "shared-library-upload-complete") {
    parts.push(`分片合并阶段，共 ${context.chunkCount || "?"} 片`);
  } else if (context.uploadMode === "direct") {
    parts.push("直传阶段");
  }
  if (context.packageBytes) parts.push(`包体 ${formatBytes(context.packageBytes)}`);
  if (error?.responseStatus) parts.push(`HTTP ${error.responseStatus}`);
  else if (context.uploadMode === "chunked") parts.push("网络未返回响应");
  if (error?.contentType) parts.push(`Content-Type ${String(error.contentType).slice(0, 80)}`);
  return parts.join("，");
}

function buildSharedUploadDiagnostics(context = {}, error = {}, normalizedMessage = "", rawMessage = "") {
  return {
    action: context.action || "",
    uploadMode: context.uploadMode || "",
    appVersion: context.appVersion || "",
    groupName: context.groupName || "",
    packageBytes: Number(context.packageBytes || 0),
    packageSize: formatBytes(context.packageBytes || 0),
    packageHash: context.packageHash || "",
    base64Chars: Number(context.base64Chars || 0),
    chunkIndex: Number.isFinite(Number(context.chunkIndex)) ? Number(context.chunkIndex) : null,
    chunkCount: Number.isFinite(Number(context.chunkCount)) ? Number(context.chunkCount) : null,
    chunkChars: Number(context.chunkChars || 0),
    uploadId: String(context.uploadId || "").slice(0, 120),
    responseStatus: Number(error?.responseStatus || 0),
    contentType: String(error?.contentType || "").slice(0, 160),
    responseSnippet: String(error?.responseSnippet || "").slice(0, 300),
    responseCode: context.responseCode || "",
    attempt: Number.isFinite(Number(context.attempt)) ? Number(context.attempt) : null,
    maxAttempts: Number.isFinite(Number(context.maxAttempts)) ? Number(context.maxAttempts) : null,
    normalizedMessage: String(normalizedMessage || "").slice(0, 500),
    rawMessage: String(rawMessage || "").slice(0, 500)
  };
}

async function writeSharedUploadDiagnostic(projectRoot, item, error, pack = {}) {
  const diagnostic = error?.diagnostics || {};
  const root = path.join(projectRoot, "logs", SHARED_UPLOAD_DIAGNOSTIC_DIR);
  await fs.mkdir(root, { recursive: true });
  const filePath = path.join(root, `${timestampForFile()}-${safeFileName(item?.name || item?.id || "shared-upload")}.json`);
  await rememberPendingSharedUpload(item, error, pack, diagnostic, filePath).catch(() => {});
  await fs.writeFile(filePath, JSON.stringify({
    createdAt: new Date().toISOString(),
    item: {
      id: item?.id || "",
      name: item?.name || "",
      taskCount: Number(item?.taskCount || pack?.tasks?.length || 0)
    },
    upload: diagnostic,
    error: {
      message: String(error?.message || "").slice(0, 800),
      code: error?.code || ""
    }
  }, null, 2), "utf8");
  return filePath;
}

async function rememberPendingSharedUpload(item, error, pack = {}, diagnostic = {}, diagnosticPath = "") {
  if (!item?.runDir) return;
  const packageHash = String(diagnostic.packageHash || pack.packageHash || "");
  if (!/^[a-fA-F0-9]{64}$/.test(packageHash)) return;
  const metaPath = path.join(item.runDir, META_FILE);
  const meta = await readJsonIfExists(metaPath);
  await fs.writeFile(metaPath, JSON.stringify({
    ...meta,
    lastSharedUpload: {
      status: "pending_confirm",
      packageHash,
      packageBytes: Number(diagnostic.packageBytes || pack.packageBytes || 0),
      packageSize: diagnostic.packageSize || formatBytes(diagnostic.packageBytes || pack.packageBytes || 0),
      groupName: cleanGroupName(diagnostic.groupName || pack.groupName || meta.shared?.groupName || ""),
      failedAt: new Date().toISOString(),
      action: diagnostic.action || "",
      uploadMode: diagnostic.uploadMode || "",
      uploadId: String(diagnostic.uploadId || "").slice(0, 120),
      chunkCount: diagnostic.chunkCount ?? null,
      responseStatus: Number(diagnostic.responseStatus || error?.responseStatus || 0),
      message: String(error?.message || "").slice(0, 300),
      diagnosticPath
    }
  }, null, 2), "utf8");
}

async function readAppVersion(projectRoot) {
  try {
    const pkg = JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8"));
    return String(pkg.version || "").slice(0, 32);
  } catch {
    return "";
  }
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

function sharedPackageContentHash(pack = {}) {
  return sha256(JSON.stringify(sharedPackageContentIdentity(pack)));
}

function sharedPackageContentIdentity(pack = {}) {
  const tasks = Array.isArray(pack.tasks) ? pack.tasks : [];
  const rawEvents = Array.isArray(pack.rawEvents) ? pack.rawEvents : [];
  const mediaFiles = Array.isArray(pack.mediaFiles) ? pack.mediaFiles : [];
  return {
    schemaVersion: Number(pack.schemaVersion || 1),
    name: String(pack.name || ""),
    groupName: cleanGroupName(pack.groupName || ""),
    taskCount: Number(pack.taskCount || tasks.length || 0),
    tasks,
    rawEvents,
    mediaFiles
  };
}

function stableSharedUploadId(packageHash) {
  const hash = String(packageHash || "").replace(/[^a-fA-F0-9]/g, "").toLowerCase();
  return `shared_${hash.slice(0, 64) || sha256(String(packageHash || Date.now())).slice(0, 64)}`;
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function writePersistentMediaNotice(mediaRoot) {
  await fs.writeFile(path.join(mediaRoot, "DO-NOT-DELETE-LIBRARY-MEDIA.txt"), [
    "This folder stores media files for a saved preview library item.",
    "Do not clean it as a temporary run media-cache.",
    "Delete it only by deleting the corresponding preview library item from the 2.0 console.",
    ""
  ].join("\n"), "utf8").catch(() => {});
}

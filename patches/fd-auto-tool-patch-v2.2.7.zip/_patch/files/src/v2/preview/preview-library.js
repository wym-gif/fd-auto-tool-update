import fs from "node:fs/promises";
import path from "node:path";
import { finalPreviewPath, previewTasksPath, readPreviewTasks, saveFinalPreview, reviewLibraryPreviewWarnings } from "./preview-store.js";
import { assignPreciseTuoSpeakers } from "../tuo/precise-tuo-assigner.js";
import { schedulePreviewTasks } from "../time/schedule-preview-tasks.js";

const INDEX_FILE = "index.json";
const META_FILE = "library-meta.json";
const SOURCE_FILE = "library-source.json";
const LIBRARY_DIR = "preview-library";
const PROTECTION_FILE = "DO-NOT-DELETE-PREVIEW-LIBRARY.txt";

export function previewLibraryRoot(projectRoot) {
  return path.join(projectRoot, LIBRARY_DIR);
}

export async function listPreviewLibrary(projectRoot) {
  const root = previewLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const fromIndex = normalizeIndex(await readJsonIfExists(path.join(root, INDEX_FILE)));
  const entries = [];
  const seen = new Set();
  for (const item of fromIndex.items) {
    const hydrated = await hydrateItem(root, item).catch(() => null);
    if (!hydrated) continue;
    seen.add(hydrated.id);
    entries.push(hydrated);
  }
  const dirs = await fs.readdir(root, { withFileTypes: true }).catch(() => []);
  for (const entry of dirs) {
    if (!entry.isDirectory() || seen.has(entry.name)) continue;
    const hydrated = await hydrateItem(root, { id: entry.name }).catch(() => null);
    if (hydrated) entries.push({ ...hydrated, __discovered: true });
  }
  const indexed = entries.filter((item) => !item.__discovered);
  const discovered = entries
    .filter((item) => item.__discovered)
    .sort((a, b) => String(b.updatedAt || b.createdAt || "").localeCompare(String(a.updatedAt || a.createdAt || "")))
    .map(({ __discovered, ...item }) => item);
  entries.length = 0;
  entries.push(...indexed, ...discovered);
  await writeIndex(root, entries);
  return entries;
}

export async function savePreviewToLibrary(projectRoot, sourceRunDir, tasks, options = {}) {
  const root = previewLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const existing = options.forceNew === true
    ? null
    : await resolveRunAsLibraryItem(projectRoot, sourceRunDir).catch(() => null);
  if (existing) {
    return updatePreviewLibraryContent(projectRoot, existing.id, tasks, {
      name: options.name || existing.name,
      sourceRunDir,
      settingsSnapshot: options.settingsSnapshot || options.settings
    });
  }
  const now = new Date().toISOString();
  const id = options.id || `preview_${timestampForId(new Date())}_${randomSuffix()}`;
  const itemDir = path.join(root, id);
  await ensureDir(path.join(itemDir, "media-cache"));

  const reviewedTasks = await reviewLibraryPreviewWarnings(projectRoot, sourceRunDir, tasks);
  const copiedTasks = await copyPreviewAssets(reviewedTasks, sourceRunDir, itemDir);
  await saveFinalPreview(itemDir, copiedTasks, { requireComplete: true });
  await fs.writeFile(previewTasksPath(itemDir), JSON.stringify(copiedTasks, null, 2), "utf8");
  await fs.writeFile(path.join(itemDir, "raw-events.json"), JSON.stringify([], null, 2), "utf8");

  const meta = {
    id,
    name: cleanLibraryName(options.name) || defaultLibraryName(copiedTasks, id),
    createdAt: now,
    updatedAt: now,
    sourceRunDir: path.resolve(sourceRunDir),
    runDir: itemDir,
    previewPath: finalPreviewPath(itemDir),
    taskCount: copiedTasks.length,
    settingsSnapshot: normalizeSettingsSnapshot(options.settingsSnapshot || options.settings)
  };
  await fs.writeFile(path.join(itemDir, META_FILE), JSON.stringify(meta, null, 2), "utf8");

  const items = await listPreviewLibrary(projectRoot);
  const next = [meta, ...items.filter((item) => item.id !== id)];
  await writeIndex(root, next);
  return meta;
}

export async function updatePreviewLibraryContent(projectRoot, id, tasks, options = {}) {
  const root = previewLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const previousMeta = await readJsonIfExists(path.join(item.runDir, META_FILE));
  const now = new Date().toISOString();
  const normalizedName = cleanLibraryName(options.name || previousMeta.name || item.name) || item.name;
  const sourceRunDir = options.sourceRunDir || item.runDir;
  const reviewedTasks = await reviewLibraryPreviewWarnings(projectRoot, sourceRunDir, tasks);
  const copiedTasks = await copyPreviewAssets(reviewedTasks, sourceRunDir, item.runDir);
  await saveFinalPreview(item.runDir, copiedTasks, { requireComplete: true });
  const savedTasks = await readPreviewTasks(finalPreviewPath(item.runDir));
  await fs.writeFile(previewTasksPath(item.runDir), JSON.stringify(savedTasks, null, 2), "utf8");
  await fs.writeFile(path.join(item.runDir, "raw-events.json"), JSON.stringify([], null, 2), "utf8");
  const meta = {
    ...previousMeta,
    id: item.id,
    name: normalizedName,
    createdAt: previousMeta.createdAt || item.createdAt || now,
    updatedAt: now,
    sourceRunDir: previousMeta.sourceRunDir || path.resolve(options.sourceRunDir || item.runDir),
    runDir: item.runDir,
    previewPath: finalPreviewPath(item.runDir),
    taskCount: savedTasks.length,
    settingsSnapshot: normalizeSettingsSnapshot(options.settingsSnapshot || options.settings || previousMeta.settingsSnapshot)
  };
  await fs.writeFile(path.join(item.runDir, META_FILE), JSON.stringify(meta, null, 2), "utf8");
  await rewriteIndexFromDisk(projectRoot);
  return meta;
}

export async function renamePreviewLibraryItem(projectRoot, id, name) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const metaPath = path.join(item.runDir, META_FILE);
  const previousMeta = await readJsonIfExists(metaPath);
  const nextName = cleanLibraryName(name);
  if (!nextName) throw new Error("文案库名称不能为空。");
  const meta = {
    ...previousMeta,
    id: item.id,
    name: nextName,
    createdAt: previousMeta.createdAt || item.createdAt,
    updatedAt: new Date().toISOString(),
    runDir: item.runDir,
    previewPath: finalPreviewPath(item.runDir),
    taskCount: item.taskCount
  };
  await fs.writeFile(metaPath, JSON.stringify(meta, null, 2), "utf8");
  await rewriteIndexFromDisk(projectRoot);
  return meta;
}

export async function deletePreviewLibraryItem(projectRoot, id) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const root = path.resolve(previewLibraryRoot(projectRoot));
  const itemDir = path.resolve(item.runDir);
  if (!itemDir.startsWith(root + path.sep)) {
    throw new Error("拒绝删除：文案库目录校验失败。");
  }
  const metaPath = path.join(itemDir, META_FILE);
  const metaStat = await fs.stat(metaPath).catch(() => null);
  if (!metaStat?.isFile()) {
    throw new Error("拒绝删除：目标不是有效文案库条目。");
  }
  await fs.rm(itemDir, { recursive: true, force: true });
  await rewriteIndexFromDisk(projectRoot);
  return { id: item.id, name: item.name };
}

export async function movePreviewLibraryItem(projectRoot, id, move = {}) {
  const root = previewLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const items = await listPreviewLibrary(projectRoot);
  const safeId = safeLibraryId(id);
  const index = items.findIndex((item) => item.id === safeId);
  if (index < 0) throw new Error("没有找到要排序的文案。");
  const direction = typeof move === "string" ? move : String(move.direction || "");
  const step = direction === "down" ? 1 : direction === "up" ? -1 : 0;
  if (direction === "top") {
    if (index === 0) {
      await writeIndex(root, items);
      return { item: items[index], items };
    }
    const next = [...items];
    const [picked] = next.splice(index, 1);
    next.unshift(picked);
    await writeIndex(root, next);
    return { item: picked, items: next };
  }
  if (step) {
    const target = index + step;
    if (target < 0 || target >= items.length) {
      await writeIndex(root, items);
      return { item: items[index], items };
    }
    const next = [...items];
    [next[index], next[target]] = [next[target], next[index]];
    await writeIndex(root, next);
    return { item: next[target], items: next };
  }
  const targetId = typeof move === "object" ? safeLibraryId(move.targetId) : "";
  const position = typeof move === "object" && move.position === "after" ? "after" : "before";
  if (!targetId) throw new Error("排序方向无效。");
  if (targetId === safeId) {
    await writeIndex(root, items);
    return { item: items[index], items };
  }
  const next = [...items];
  const [picked] = next.splice(index, 1);
  const targetIndex = next.findIndex((item) => item.id === targetId);
  if (targetIndex < 0) throw new Error("没有找到拖拽目标文案。");
  next.splice(position === "after" ? targetIndex + 1 : targetIndex, 0, picked);
  await writeIndex(root, next);
  return { item: picked, items: next };
}

export async function resolvePreviewLibraryItem(projectRoot, id) {
  const safeId = safeLibraryId(id);
  if (!safeId) throw new Error("没有指定文案库条目。");
  const root = previewLibraryRoot(projectRoot);
  const item = await hydrateItem(root, { id: safeId });
  return item;
}

export async function resolveRunAsLibraryItem(projectRoot, runDir) {
  const root = path.resolve(previewLibraryRoot(projectRoot));
  const resolved = path.resolve(String(runDir || ""));
  if (!resolved.startsWith(root + path.sep)) return null;
  const id = path.basename(resolved);
  return resolvePreviewLibraryItem(projectRoot, id);
}

export async function resolveRunLibrarySource(projectRoot, runDir) {
  const source = await readJsonIfExists(path.join(runDir, SOURCE_FILE));
  if (!source.id) return null;
  const item = await resolvePreviewLibraryItem(projectRoot, source.id);
  return item;
}

export async function createPreviewLibraryWorkingRun(projectRoot, id, options = {}) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const workDir = path.join(runsRoot, `v2_library_work_${timestampForId(new Date())}_${randomSuffix()}`);
  await ensureDir(workDir);
  await fs.copyFile(finalPreviewPath(item.runDir), finalPreviewPath(workDir));
  await fs.copyFile(previewTasksPath(item.runDir), previewTasksPath(workDir)).catch(async () => {
    const tasks = await readPreviewTasks(finalPreviewPath(item.runDir));
    await fs.writeFile(previewTasksPath(workDir), JSON.stringify(tasks, null, 2), "utf8");
  });
  await fs.copyFile(path.join(item.runDir, "raw-events.json"), path.join(workDir, "raw-events.json")).catch(async () => {
    await fs.writeFile(path.join(workDir, "raw-events.json"), JSON.stringify([], null, 2), "utf8");
  });
  await copyDirIfExists(path.join(item.runDir, "media-cache"), path.join(workDir, "media-cache"));
  const tasks = await reviewLibraryPreviewWarnings(projectRoot, item.runDir,
    await readPreviewTasks(finalPreviewPath(workDir)));
  const defaultDate = String(options.defaultDate || "").trim();
  let rewritten = tasks.map((task) => applyLibraryWorkingDefaults(
    rewriteLibraryMediaPathForWorkDir(task, item.runDir, workDir),
    { defaultDate }
  ));
  const hasPreciseRoster = Array.isArray(options.preciseTuoRoster) && options.preciseTuoRoster.length;
  const robotStrategy = normalizeRobotStrategy(options.robotStrategy || (hasPreciseRoster ? "precise" : "") || item.settingsSnapshot?.robotStrategy);
  if (robotStrategy && robotStrategy !== "precise") {
    rewritten = stripPreciseTuoAssignments(rewritten);
  }
  let preciseTuoReport = null;
  if (robotStrategy === "precise" && hasPreciseRoster) {
    const assigned = assignPreciseTuoSpeakers(rewritten, options.preciseTuoRoster, options.preciseTuoOptions || {});
    rewritten = assigned.tasks;
    preciseTuoReport = assigned.report;
    await fs.writeFile(path.join(workDir, "precise-tuo-report.json"), JSON.stringify(preciseTuoReport, null, 2), "utf8");
  }
  const scheduleOptions = options.scheduleOptions || null;
  if (scheduleOptions && scheduleOptions.mode) {
    rewritten = schedulePreviewTasks(rewritten, {
      ...scheduleOptions,
      phase: scheduleOptions.phase || "regenerate-preview"
    }).tasks;
  }
  await fs.writeFile(finalPreviewPath(workDir), JSON.stringify(rewritten, null, 2), "utf8");
  await fs.writeFile(previewTasksPath(workDir), JSON.stringify(rewritten, null, 2), "utf8");
  await fs.writeFile(path.join(workDir, SOURCE_FILE), JSON.stringify({
    id: item.id,
    name: item.name,
    sourceRunDir: item.runDir,
    openedAt: new Date().toISOString(),
    defaultDate,
    robotStrategy,
    configMode: options.configMode || "",
    preciseTuoReassigned: Boolean(preciseTuoReport),
    scheduleMode: scheduleOptions?.mode || "",
    schedule: previewScheduleSnapshot(scheduleOptions)
  }, null, 2), "utf8");
  return { ...item, workDir, workPreviewPath: finalPreviewPath(workDir), taskCount: rewritten.length, defaultDate, preciseTuoReport };
}

export async function createCombinedPreviewLibraryWorkingRun(projectRoot, ids = [], options = {}) {
  const orderedIds = Array.from(new Set((Array.isArray(ids) ? ids : []).map(safeLibraryId).filter(Boolean)));
  if (orderedIds.length < 2) throw new Error("拼接预览至少需要选择两份文案。");
  const items = await Promise.all(orderedIds.map((id) => resolvePreviewLibraryItem(projectRoot, id)));
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const workDir = path.join(runsRoot, `v2_library_combined_${timestampForId(new Date())}_${randomSuffix()}`);
  await ensureDir(path.join(workDir, "media-cache"));
  const defaultDate = String(options.defaultDate || "").trim();
  const segments = [];
  let rewritten = [];

  for (const [segmentOffset, item] of items.entries()) {
    const segmentIndex = segmentOffset + 1;
    const segmentKey = `segment-${String(segmentIndex).padStart(3, "0")}-${item.id}`;
    const sourceMediaRoot = path.join(item.runDir, "media-cache");
    const segmentMediaRoot = path.join(workDir, "media-cache", segmentKey);
    await copyDirIfExists(sourceMediaRoot, segmentMediaRoot);
    const tasks = await reviewLibraryPreviewWarnings(projectRoot, item.runDir,
      await readPreviewTasks(finalPreviewPath(item.runDir)));
    const segment = {
      id: segmentKey,
      itemId: item.id,
      name: item.name,
      index: segmentIndex,
      total: items.length,
      taskCount: tasks.length
    };
    segments.push(segment);
    rewritten.push(...tasks.map((task, taskOffset) => {
      const identityPrefix = `library:${segmentKey}`;
      const sourceId = String(task.sourceId || task.submitIdentity || taskOffset + 1);
      const next = rewriteCombinedLibraryMediaPath(task, sourceMediaRoot, segmentMediaRoot);
      return applyLibraryWorkingDefaults({
        ...next,
        sourceId: `${identityPrefix}:${taskOffset + 1}:${sourceId}`,
        submitIdentity: `${identityPrefix}:${taskOffset + 1}:${String(task.submitIdentity || sourceId)}`,
        interactionGroup: task.interactionGroup ? `${identityPrefix}:${task.interactionGroup}` : "",
        repairsSourceIds: Array.isArray(task.repairsSourceIds)
          ? task.repairsSourceIds.map((value) => `${identityPrefix}:${value}`)
          : task.repairsSourceIds,
        sourceLibrarySegment: segment,
        order: rewritten.length + taskOffset + 1
      }, { defaultDate });
    }));
  }

  const hasPreciseRoster = Array.isArray(options.preciseTuoRoster) && options.preciseTuoRoster.length;
  const robotStrategy = normalizeRobotStrategy(options.robotStrategy || (hasPreciseRoster ? "precise" : ""));
  if (robotStrategy && robotStrategy !== "precise") rewritten = stripPreciseTuoAssignments(rewritten);
  let preciseTuoReport = null;
  if (robotStrategy === "precise" && hasPreciseRoster) {
    const assigned = assignPreciseTuoSpeakers(rewritten, options.preciseTuoRoster, options.preciseTuoOptions || {});
    rewritten = assigned.tasks;
    preciseTuoReport = assigned.report;
    await fs.writeFile(path.join(workDir, "precise-tuo-report.json"), JSON.stringify(preciseTuoReport, null, 2), "utf8");
  }
  const scheduleOptions = options.scheduleOptions || null;
  if (scheduleOptions && scheduleOptions.mode) {
    rewritten = schedulePreviewTasks(rewritten, {
      ...scheduleOptions,
      phase: scheduleOptions.phase || "regenerate-preview"
    }).tasks;
  }
  rewritten = rewritten.map((task, index) => ({ ...task, order: index + 1 }));
  await fs.writeFile(finalPreviewPath(workDir), JSON.stringify(rewritten, null, 2), "utf8");
  await fs.writeFile(previewTasksPath(workDir), JSON.stringify(rewritten, null, 2), "utf8");
  await fs.writeFile(path.join(workDir, "raw-events.json"), JSON.stringify([], null, 2), "utf8");
  await fs.writeFile(path.join(workDir, SOURCE_FILE), JSON.stringify({
    combined: true,
    name: `拼接：${items.map((item) => item.name).join(" + ")}`,
    ids: items.map((item) => item.id),
    segments,
    openedAt: new Date().toISOString(),
    defaultDate,
    robotStrategy,
    configMode: "current",
    preciseTuoReassigned: Boolean(preciseTuoReport),
    scheduleMode: scheduleOptions?.mode || "",
    schedule: previewScheduleSnapshot(scheduleOptions)
  }, null, 2), "utf8");
  return {
    combined: true,
    name: `拼接：${items.map((item) => item.name).join(" + ")}`,
    items,
    segments,
    workDir,
    workPreviewPath: finalPreviewPath(workDir),
    taskCount: rewritten.length,
    defaultDate,
    preciseTuoReport
  };
}

function previewScheduleSnapshot(scheduleOptions) {
  if (!scheduleOptions || typeof scheduleOptions !== "object" || !scheduleOptions.mode) return {};
  return {
    mode: String(scheduleOptions.mode || ""),
    startMode: scheduleOptions.startMode === "reverse" ? "reverse" : "normal",
    startTime: String(scheduleOptions.startTime || ""),
    endTime: String(scheduleOptions.endTime || ""),
    intervals: scheduleOptions.intervals && typeof scheduleOptions.intervals === "object"
      ? JSON.parse(JSON.stringify(scheduleOptions.intervals))
      : {}
  };
}

async function hydrateItem(root, item) {
  const id = safeLibraryId(item?.id);
  if (!id) return null;
  const itemDir = path.join(root, id);
  const meta = await readJsonIfExists(path.join(itemDir, META_FILE));
  const previewPath = finalPreviewPath(itemDir);
  const stat = await fs.stat(previewPath).catch(() => null);
  if (!stat?.isFile()) return null;
  let taskCount = Number(meta.taskCount || item.taskCount || 0);
  if (!taskCount) {
    const tasks = await readPreviewTasks(previewPath).catch(() => []);
    taskCount = tasks.length;
  }
  return {
    id,
    name: cleanLibraryName(meta.name || item.name) || id,
    createdAt: meta.createdAt || item.createdAt || stat.birthtime.toISOString(),
    updatedAt: meta.updatedAt || item.updatedAt || stat.mtime.toISOString(),
    sortOrder: Number.isFinite(Number(item.sortOrder ?? meta.sortOrder)) ? Number(item.sortOrder ?? meta.sortOrder) : undefined,
    taskCount,
    shared: normalizeSharedMeta(meta.shared),
    settingsSnapshot: normalizeSettingsSnapshot(meta.settingsSnapshot),
    runDir: itemDir,
    previewPath
  };
}

function normalizeSettingsSnapshot(settings = {}) {
  if (!settings || typeof settings !== "object") return null;
  const snapshot = JSON.parse(JSON.stringify(settings));
  delete snapshot.cdpUrl;
  delete snapshot.updatedAt;
  return Object.keys(snapshot).length ? snapshot : null;
}

function normalizeRobotStrategy(value) {
  const strategy = String(value || "").trim();
  return ["random", "fixed", "precise"].includes(strategy) ? strategy : "";
}

function stripPreciseTuoAssignments(tasks) {
  return (Array.isArray(tasks) ? tasks : []).map((task) => {
    if (task?.role !== "tuo" || task?.tuoAssignment?.mode !== "precise_roster") return task;
    const next = { ...task };
    delete next.tuoAssignment;
    return next;
  });
}

function normalizeSharedMeta(shared = {}) {
  if (!shared || typeof shared !== "object") return null;
  const cloudId = String(shared.cloudId || "").trim();
  if (!cloudId) return null;
  return {
    cloudId,
    cloudVersion: Number(shared.cloudVersion || 0),
    groupName: String(shared.groupName || "").replace(/\s+/g, " ").trim().slice(0, 40),
    uploadedAt: String(shared.uploadedAt || ""),
    downloadedAt: String(shared.downloadedAt || ""),
    packageHash: String(shared.packageHash || "")
  };
}

async function copyPreviewAssets(tasks, sourceRunDir, itemDir) {
  const result = [];
  const usedNames = new Set();
  const itemMediaRoot = path.resolve(itemDir, "media-cache");
  await ensureDir(itemMediaRoot);
  await writePersistentMediaNotice(itemMediaRoot);
  for (const [index, task] of (Array.isArray(tasks) ? tasks : []).entries()) {
    const next = { ...task };
    const mediaPath = String(next.mediaPath || "").trim();
    if (mediaPath && shouldCopyMedia(mediaPath)) {
      const source = path.resolve(sourceRunDir, mediaPath);
      if (source.startsWith(itemMediaRoot + path.sep)) {
        next.mediaPath = source;
        result.push(next);
        continue;
      }
      const stat = await fs.stat(source).catch(() => null);
      if (stat?.isFile()) {
        const destName = uniqueMediaName(mediaPath, index, usedNames);
        const dest = path.join(itemMediaRoot, destName);
        await fs.copyFile(source, dest);
        next.mediaPath = dest;
      }
    }
    result.push(next);
  }
  return result;
}

function shouldCopyMedia(mediaPath) {
  if (/^(sample|data|https?|blob|image-blob):/i.test(mediaPath)) return false;
  return Boolean(mediaPath);
}

function uniqueMediaName(mediaPath, index, usedNames) {
  const ext = path.extname(mediaPath) || ".bin";
  const base = path.basename(mediaPath, ext).replace(/[^\w.-]+/g, "_").slice(0, 60) || "media";
  let name = `${String(index + 1).padStart(3, "0")}-${base}${ext}`;
  let attempt = 1;
  while (usedNames.has(name.toLowerCase())) {
    name = `${String(index + 1).padStart(3, "0")}-${base}-${attempt}${ext}`;
    attempt += 1;
  }
  usedNames.add(name.toLowerCase());
  return name;
}

function defaultLibraryName(tasks, fallback) {
  const first = (Array.isArray(tasks) ? tasks : []).find((task) => !task.skip) || tasks?.[0] || {};
  const speaker = String(first.speaker || "").trim();
  const date = String(first.date || "").trim();
  const time = String(first.time || "").trim();
  const text = String(first.text || "").replace(/\s+/g, " ").trim().slice(0, 18);
  return [speaker, date, time, text].filter(Boolean).join(" ") || fallback;
}

function cleanLibraryName(value) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 80);
}

function safeLibraryId(value) {
  const id = String(value || "").trim();
  return /^[a-zA-Z0-9_.-]+$/.test(id) ? id : "";
}

function normalizeIndex(index) {
  const items = Array.isArray(index?.items) ? index.items : [];
  const hasSortOrder = items.some((item) => Number.isFinite(Number(item?.sortOrder)));
  return {
    items: hasSortOrder
      ? [...items].sort((a, b) => Number(a.sortOrder ?? Number.MAX_SAFE_INTEGER) - Number(b.sortOrder ?? Number.MAX_SAFE_INTEGER))
      : items
  };
}

async function writeIndex(root, items) {
  await ensureLibraryRoot(root);
  await fs.writeFile(path.join(root, INDEX_FILE), JSON.stringify({
    updatedAt: new Date().toISOString(),
    items: items.map((item, index) => ({
      id: item.id,
      name: item.name,
      createdAt: item.createdAt,
      updatedAt: item.updatedAt,
      sortOrder: index,
      taskCount: item.taskCount
    }))
  }, null, 2), "utf8");
}

async function rewriteIndexFromDisk(projectRoot) {
  const root = previewLibraryRoot(projectRoot);
  const previous = normalizeIndex(await readJsonIfExists(path.join(root, INDEX_FILE))).items;
  const previousOrder = new Map(previous.map((item, index) => [safeLibraryId(item?.id), index]));
  const dirs = await fs.readdir(root, { withFileTypes: true }).catch(() => []);
  const items = [];
  for (const entry of dirs) {
    if (!entry.isDirectory()) continue;
    const hydrated = await hydrateItem(root, { id: entry.name }).catch(() => null);
    if (hydrated) items.push(hydrated);
  }
  items.sort((a, b) => {
    const aOrder = previousOrder.has(a.id) ? previousOrder.get(a.id) : Number.MAX_SAFE_INTEGER;
    const bOrder = previousOrder.has(b.id) ? previousOrder.get(b.id) : Number.MAX_SAFE_INTEGER;
    if (aOrder !== bOrder) return aOrder - bOrder;
    return String(b.updatedAt || b.createdAt || "").localeCompare(String(a.updatedAt || a.createdAt || ""));
  });
  await writeIndex(root, items);
  return items;
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true });
}

async function ensureLibraryRoot(root) {
  await ensureDir(root);
  const protectionPath = path.join(root, PROTECTION_FILE);
  await fs.writeFile(protectionPath, [
    "This folder stores saved preview copywriting and media assets.",
    "Do not clean or delete it as part of runs/media-cache cleanup.",
    "Delete items only from the 2.0 console preview library UI.",
    ""
  ].join("\n"), "utf8").catch(() => {});
}

async function writePersistentMediaNotice(mediaRoot) {
  await fs.writeFile(path.join(mediaRoot, "DO-NOT-DELETE-LIBRARY-MEDIA.txt"), [
    "This folder stores media files for a saved preview library item.",
    "Do not clean it as a temporary run media-cache.",
    "Delete it only by deleting the corresponding preview library item from the 2.0 console.",
    ""
  ].join("\n"), "utf8").catch(() => {});
}

async function copyDirIfExists(sourceDir, destDir) {
  const stat = await fs.stat(sourceDir).catch(() => null);
  if (!stat?.isDirectory()) return;
  await fs.cp(sourceDir, destDir, { recursive: true, force: true });
}

function rewriteLibraryMediaPathForWorkDir(task, sourceRunDir, workDir) {
  const next = { ...task };
  const mediaPath = String(next.mediaPath || "").trim();
  if (!mediaPath || !shouldCopyMedia(mediaPath)) return next;
  const resolved = path.resolve(sourceRunDir, mediaPath);
  const sourceCache = path.resolve(sourceRunDir, "media-cache");
  if (resolved.startsWith(sourceCache + path.sep)) {
    next.mediaPath = path.join(workDir, "media-cache", path.relative(sourceCache, resolved));
  }
  return next;
}

function rewriteCombinedLibraryMediaPath(task, sourceMediaRoot, segmentMediaRoot) {
  const next = { ...task };
  const mediaPath = String(next.mediaPath || "").trim();
  if (!mediaPath || !shouldCopyMedia(mediaPath)) return next;
  const resolved = path.resolve(mediaPath);
  const sourceRoot = path.resolve(sourceMediaRoot);
  if (resolved.startsWith(sourceRoot + path.sep)) {
    next.mediaPath = path.join(segmentMediaRoot, path.relative(sourceRoot, resolved));
  }
  return next;
}

function applyLibraryWorkingDefaults(task, options = {}) {
  if (!options.defaultDate || task.skip) return task;
  return { ...task, date: options.defaultDate };
}

function timestampForId(date) {
  const pad = (value) => String(value).padStart(2, "0");
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    "_",
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds())
  ].join("");
}

function randomSuffix() {
  return Math.random().toString(36).slice(2, 8);
}

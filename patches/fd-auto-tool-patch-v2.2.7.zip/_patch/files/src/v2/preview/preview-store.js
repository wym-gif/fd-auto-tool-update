import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { clearResolvedFinderError, isCompleteFinderXml } from "./finder-validation.js";
import { clearLegacyCollectedSpeakerWarnings } from "./source-audit.js";
import { PREVIEW_TASK_REQUIRED_FIELDS, createPreviewTask, validatePreviewTaskShape } from "../contracts/preview-task.js";
import { isRemoteMediaPath, isTemporaryBrowserMediaPath, localizePreviewTaskMediaWithFetch } from "../media/media-cache.js";

export function previewTasksPath(runDir) {
  return path.join(runDir, "preview-tasks.json");
}

export function finalPreviewPath(runDir) {
  return path.join(runDir, "preview.json");
}

export function previewDraftPath(runDir) {
  return path.join(runDir, "preview-draft.json");
}

export async function findLatestV2FlowRun(runsRoot) {
  return findLatestPreviewTaskRun(runsRoot, { prefix: "v2_flow_" });
}

export async function findLatestV2RealFlowRun(runsRoot) {
  return findLatestPreviewTaskRun(runsRoot, { prefix: "v2_real_flow_" });
}

async function findLatestPreviewTaskRun(runsRoot, options = {}) {
  const entries = await fs.readdir(runsRoot, { withFileTypes: true }).catch(() => []);
  const candidates = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || !entry.name.startsWith(options.prefix || "v2_flow_")) continue;
    const runDir = path.join(runsRoot, entry.name);
    try {
      const stat = await fs.stat(previewTasksPath(runDir));
      candidates.push({ runDir, mtimeMs: stat.mtimeMs });
    } catch {
      continue;
    }
  }
  candidates.sort((a, b) => b.mtimeMs - a.mtimeMs || b.runDir.localeCompare(a.runDir));
  return candidates[0]?.runDir || null;
}

export async function loadPreviewForOpen(runDir, options = {}) {
  const previewPath = finalPreviewPath(runDir);
  const draftPath = previewDraftPath(runDir);
  if (!options.regenerate && await isNewerFile(draftPath, previewPath)) {
    return {
      source: "preview-draft.json recovered working draft",
      path: draftPath,
      tasks: applyPreviewDefaultDate(await readPreviewForOpen(runDir, draftPath), options.defaultDate)
    };
  }
  if (!options.regenerate && await exists(previewPath)) {
    return {
      source: "preview.json",
      path: previewPath,
      tasks: applyPreviewDefaultDate(await readPreviewForOpen(runDir, previewPath), options.defaultDate)
    };
  }

  const sourcePath = previewTasksPath(runDir);
  let tasks = applyPreviewDefaultDate(await readPreviewForOpen(runDir, sourcePath), options.defaultDate);
  if (options.regenerate) {
    const existingPath = await isNewerFile(draftPath, previewPath) ? draftPath : previewPath;
    if (await exists(existingPath)) {
      const existingTasks = applyPreviewDefaultDate(await readPreviewTasks(existingPath), options.defaultDate);
      tasks = mergeRegeneratedPreviewTasks(tasks, existingTasks);
    }
  }
  const saved = await saveFinalPreview(runDir, tasks);
  if (options.regenerate) await fs.unlink(draftPath).catch(() => {});
  return {
    source: options.regenerate ? "preview-tasks.json regenerated preview.json" : "preview-tasks.json initialized preview.json",
    path: sourcePath,
    tasks: saved.tasks
  };
}

async function readPreviewForOpen(runDir, filePath) {
  const tasks = await readPreviewTasks(filePath);
  if (!tasks.some((task) => Number(task.sourceAuditVersion || 0) < 2 && task.sourceAuditIssues?.includes("generated_speaker_mismatch"))) return tasks;
  if (await exists(path.join(runDir, "library-source.json")) || await exists(path.join(runDir, "library-meta.json"))) {
    return reviewLibraryPreviewWarnings(path.dirname(path.dirname(runDir)), runDir, tasks);
  }
  // Older/imported runs can lack source evidence. Keep their warning rather
  // than inventing a match or blocking access to the saved preview.
  let events, generated;
  try {
    [events, generated] = await Promise.all([
      fs.readFile(path.join(runDir, "range-events.json"), "utf8").then(JSON.parse),
      fs.readFile(previewTasksPath(runDir), "utf8").then(JSON.parse)
    ]);
  } catch { return tasks; }
  if (!Array.isArray(events) || !Array.isArray(generated)) return tasks;
  return clearLegacyCollectedSpeakerWarnings(tasks, events, generated);
}

// Reuse only original local generation evidence to review legacy warnings.
// No live collection and no comparison with the user's edited final fields.
export async function reviewLibraryPreviewWarnings(projectRoot, runDir, tasks) {
  if (!tasks.some((task) => Number(task.sourceAuditVersion || 0) < 2
    && task.sourceAuditIssues?.includes("generated_speaker_mismatch"))) return tasks;
  const root = await fs.realpath(projectRoot);
  const readEvidence = async (file) => fs.readFile(file, "utf8").then(JSON.parse).catch(() => null);
  const visited = new Set();
  let candidate = runDir;
  for (let depth = 0; candidate && depth < 8; depth += 1) {
    // Imported absolute paths outside this project (including UNC) are not followed.
    if (typeof candidate !== "string") break;
    const relative = path.relative(path.resolve(projectRoot), path.resolve(candidate));
    if (!relative || relative.startsWith(".." + path.sep) || relative === ".." || path.isAbsolute(relative)) break;
    const dir = await fs.realpath(candidate).catch(() => "");
    if (!dir || !dir.startsWith(root + path.sep) || visited.has(dir)) break;
    visited.add(dir);
    const [events, generated] = await Promise.all([
      readEvidence(path.join(dir, "range-events.json")), readEvidence(previewTasksPath(dir))
    ]);
    if (Array.isArray(events) && events.length && Array.isArray(generated) && generated.length) {
      try {
        return clearLegacyCollectedSpeakerWarnings(tasks, events, generated, { markUnverified: true });
      } catch {
        // Damaged historical evidence must not prevent opening the final preview.
        break;
      }
    }
    const [meta, source] = await Promise.all([
      readEvidence(path.join(dir, "library-meta.json")), readEvidence(path.join(dir, "library-source.json"))
    ]);
    candidate = meta?.sourceRunDir || source?.sourceRunDir || "";
  }
  return clearLegacyCollectedSpeakerWarnings(tasks, [], [], { markUnverified: true });
}

export function mergeRegeneratedPreviewTasks(generatedTasks = [], existingTasks = []) {
  const generated = validatePreviewTasks(generatedTasks);
  const existing = validatePreviewTasks(existingTasks);
  const usedGenerated = new Set();
  const generatedByKey = new Map();
  for (const [index, task] of generated.entries()) {
    for (const key of previewSourceMatchKeys(task)) {
      if (!generatedByKey.has(key)) generatedByKey.set(key, []);
      generatedByKey.get(key).push(index);
    }
  }

  const merged = existing.map((task) => {
    const matchIndex = previewSourceMatchKeys(task)
      .flatMap((key) => generatedByKey.get(key) || [])
      .find((index) => !usedGenerated.has(index));
    if (Number.isInteger(matchIndex)) {
      usedGenerated.add(matchIndex);
      const fresh = generated[matchIndex];
      return createPreviewTask({
        ...fresh,
        ...task,
        sourceOccurrenceIds: fresh.sourceOccurrenceIds?.length ? fresh.sourceOccurrenceIds : task.sourceOccurrenceIds
      });
    }
    if (isManualPreviewTask(task)) return task;
    return createPreviewTask({
      ...task,
      previewError: task.previewError || "重新读取后没有找到这一条对应的原文位置，请核对后确认保留或设为不发。",
      previewWarning: mergeWarning(task.previewWarning, "系统已保留此前人工修改，没有用重新读取结果覆盖。"),
      recoveryRequired: true
    });
  });

  for (const [index, task] of generated.entries()) {
    if (usedGenerated.has(index)) continue;
    merged.push(createPreviewTask({
      ...task,
      previewWarning: mergeWarning(task.previewWarning, "重新读取后发现的新原文位置，请核对顺序。")
    }));
  }
  return merged.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

export function applyPreviewDefaultDate(tasks, defaultDate = "") {
  const fallback = String(defaultDate || "").trim();
  const normalized = validatePreviewTasks(tasks);
  if (!fallback) return normalized;
  return normalized.map((task) => String(task.date || "").trim()
    ? task
    : { ...task, date: fallback });
}

export function applyRestoredPreviewDate(tasks, defaultDate = "", succeededTaskKeys = new Set()) {
  const fallback = String(defaultDate || "").trim();
  const normalized = validatePreviewTasks(tasks);
  if (!fallback) return normalized;
  const succeeded = succeededTaskKeys instanceof Set ? succeededTaskKeys : new Set(succeededTaskKeys || []);
  return normalized.map((task) => {
    const taskKey = String(task.submitIdentity || "").trim();
    if (task.skip === true || (taskKey && succeeded.has(taskKey))) return task;
    return { ...task, date: fallback };
  });
}

export async function saveFinalPreview(runDir, tasks, options = {}) {
  let normalized = ensurePersistentSubmitIdentities(validatePreviewTasks(tasks));
  if (options.requireComplete === true) {
    normalized = await localizePreviewTaskMediaWithFetch(normalized, {
      runDir,
      mediaCacheDir: options.mediaCacheDir || path.join(runDir, "media-cache"),
      fetchImpl: options.fetchImpl
    });
    await validatePreviewTasksReadyForSave(normalized, { runDir });
  }
  const previewPath = finalPreviewPath(runDir);
  await atomicWritePreview(previewPath, normalized);
  if (options.requireComplete === true) await fs.unlink(previewDraftPath(runDir)).catch(() => {});
  return {
    path: previewPath,
    tasks: normalized
  };
}

export async function savePreviewDraft(runDir, tasks) {
  const normalized = ensurePersistentSubmitIdentities(validatePreviewTasks(tasks));
  const draftPath = previewDraftPath(runDir);
  await atomicWritePreview(draftPath, normalized);
  return { path: draftPath, tasks: normalized };
}

async function atomicWritePreview(previewPath, tasks) {
  const tempPath = `${previewPath}.${process.pid}.${randomUUID()}.tmp`;
  let handle;
  try {
    handle = await fs.open(tempPath, "wx");
    await handle.writeFile(JSON.stringify(tasks, null, 2), "utf8");
    await handle.sync();
    await handle.close();
    handle = null;
    await fs.rename(tempPath, previewPath);
  } finally {
    await handle?.close().catch(() => {});
    await fs.unlink(tempPath).catch(() => {});
  }
}

async function isNewerFile(candidatePath, baselinePath) {
  try {
    const candidate = await fs.stat(candidatePath);
    const baseline = await fs.stat(baselinePath).catch(() => null);
    return candidate.isFile() && (!baseline || candidate.mtimeMs >= baseline.mtimeMs);
  } catch {
    return false;
  }
}

export function ensurePersistentSubmitIdentities(tasks = []) {
  const used = new Set();
  return tasks.map((task) => {
    let identity = String(task?.submitIdentity || "").trim();
    if (!identity || used.has(identity)) identity = `task:${randomUUID()}`;
    used.add(identity);
    return { ...task, submitIdentity: identity };
  });
}

function previewSourceMatchKeys(task = {}) {
  const refs = Array.isArray(task.sourceOccurrenceIds) ? task.sourceOccurrenceIds : [];
  const keys = refs.map(sourcePositionMatchKey).filter(Boolean);
  if (keys.length) return [`refs:${[...new Set(keys)].sort().join("|")}`];
  const sourceIds = String(task.sourceId || "").split(",").map((item) => item.trim()).filter(Boolean);
  return sourceIds.length ? [`source:${sourceIds.join(",")}`] : [];
}

function sourcePositionMatchKey(value) {
  const text = String(value || "").trim();
  const match = text.match(/^feishu:[^:]+:([^:]+):\d+:([^#]+)(#.*)?$/);
  return match ? `${match[1]}:${match[2]}${match[3] || ""}` : text;
}

function isManualPreviewTask(task = {}) {
  return /^manual-/i.test(String(task.sourceId || "")) || String(task.sourceText || "") === "手动新增";
}

function mergeWarning(left, right) {
  return [...new Set([left, right].map((item) => String(item || "").trim()).filter(Boolean))].join("；");
}

export async function loadFinalPreviewForCreate(runDir) {
  const previewPath = finalPreviewPath(runDir);
  if (!await exists(previewPath)) {
    throw new Error("创建前最终核对失败：没有找到已保存的预览内容，请先确认预览。");
  }
  const tasks = await readPreviewTasks(previewPath);
  await assertRunImportCompleteness(runDir, tasks);
  return {
    source: "preview.json",
    path: previewPath,
    tasks
  };
}

export async function assertRunImportCompleteness(runDir, finalTasks = []) {
  const filePath = path.join(runDir, "feishu-media-manifest.json");
  let manifest;
  try {
    manifest = JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch (error) {
    if (error?.code === "ENOENT") return { ok: true, legacy: true };
    throw new Error("创建前素材完整性检查失败：导入素材清单损坏，不能继续创建。");
  }
  if (!Array.isArray(manifest)) throw new Error("创建前素材完整性检查失败：导入素材清单格式无效。");
  const taskSources = indexFinalTasksBySourceId(finalTasks);
  const failed = manifest.filter((item) => item?.status !== "downloaded");
  const unresolved = failed.filter((item) => !isFailedImportResolved(item, taskSources));
  if (unresolved.length) {
    const details = unresolved.slice(0, 5).map((item) => `${item?.sourceId || "未知素材"}：${item?.error || item?.status || "未完成"}`).join("；");
    throw new Error(`创建前素材完整性检查失败：原始导入有 ${unresolved.length} 项素材在最终预览中仍未解决。${details}`);
  }
  return { ok: true, count: manifest.length, manuallyResolved: failed.length - unresolved.length };
}

function indexFinalTasksBySourceId(tasks = []) {
  const result = new Map();
  for (const task of Array.isArray(tasks) ? tasks : []) {
    const sourceIds = String(task?.sourceId || "").split(",").map((value) => value.trim()).filter(Boolean);
    if (task?.importResolutionConfirmed === true) {
      sourceIds.push(...String(task?.repairsSourceIds || "").split(",").map((value) => value.trim()).filter(Boolean));
    }
    for (const sourceId of new Set(sourceIds)) {
      if (!result.has(sourceId)) result.set(sourceId, []);
      result.get(sourceId).push(task);
    }
  }
  return result;
}

function isFailedImportResolved(item, taskSources) {
  const sourceId = String(item?.sourceId || "").trim();
  if (!sourceId) return false;
  return (taskSources.get(sourceId) || []).some((task) => {
    if (task?.skip === true) return true;
    if (!["image", "sticker", "video"].includes(String(task?.type || ""))) return false;
    return Boolean(String(task?.mediaPath || "").trim()) && !String(task?.previewError || "").trim();
  });
}

export function comparePreviewTasks(leftTasks, rightTasks) {
  const left = validatePreviewTasks(leftTasks);
  const right = validatePreviewTasks(rightTasks);
  const errors = [];
  if (left.length !== right.length) {
    errors.push(`条数不一致：页面 ${left.length} 条，已保存的预览内容 ${right.length} 条`);
  }
  const count = Math.min(left.length, right.length);
  for (let index = 0; index < count; index += 1) {
    for (const field of PREVIEW_TASK_REQUIRED_FIELDS) {
      if (JSON.stringify(left[index][field]) !== JSON.stringify(right[index][field])) {
        errors.push(`第 ${index + 1} 条 ${field} 不一致`);
      }
    }
  }
  return {
    ok: errors.length === 0,
    errors
  };
}

export async function finalPreviewCheck(runDir, pageTasks) {
  await validatePreviewTasksReadyForSave(pageTasks, { runDir });
  const finalPreview = await loadFinalPreviewForCreate(runDir);
  await validatePreviewTasksReadyForSave(finalPreview.tasks, { runDir });
  const compare = comparePreviewTasks(pageTasks, finalPreview.tasks);
  if (!compare.ok) {
    throw new Error(`创建前最终核对失败：${compare.errors.join("；")}`);
  }
  return {
    ok: true,
    source: finalPreview.source,
    path: finalPreview.path,
    count: finalPreview.tasks.length
  };
}

export async function readPreviewTasks(filePath) {
  const tasks = JSON.parse(await fs.readFile(filePath, "utf8"));
  return validatePreviewTasks(tasks);
}

export function validatePreviewTasks(tasks) {
  if (!Array.isArray(tasks)) {
    throw new Error("PreviewTask 文件必须是数组。");
  }
  return tasks.map((task) => {
    const normalized = clearResolvedFinderError(createPreviewTask({ ...task }));
    if (isTemporaryBrowserMediaPath(normalized.sourceUrl)) {
      delete normalized.sourceUrl;
    }
    if (normalized.role !== "tuo" && normalized.tuoAssignment) {
      delete normalized.tuoAssignment;
    }
    validatePreviewTaskShape(normalized);
    return normalized;
  });
}

export async function validatePreviewTasksReadyForSave(tasks, options = {}) {
  const normalized = validatePreviewTasks(tasks);
  const errors = [];
  for (const [index, task] of normalized.entries()) {
    if (task.skip) continue;
    const label = `第 ${index + 1} 条`;
    if (String(task.previewError || "").trim()) errors.push(`${label} ${String(task.previewError).trim()}`);
    if (task.speakerStatus === "unconfirmed") errors.push(`${label} 说话人尚未确认`);
    if (!String(task.role || "").trim()) errors.push(`${label} 缺少角色`);
    if (!String(task.date || "").trim()) errors.push(`${label} 缺少日期`);
    if (!validPreviewDate(task.date)) errors.push(`${label} 日期格式不合法：${task.date}`);
    if (!String(task.time || "").trim()) errors.push(`${label} 缺少时间`);
    if (!validPreviewTime(task.time)) errors.push(`${label} 时间格式不合法：${task.time}`);
    if (task.type === "text" || task.type === "finder") {
      if (!String(task.text || "").trim()) errors.push(`${label} ${task.type === "finder" ? "视频号参数" : "文字正文"}为空`);
      else if (task.type === "finder" && !isCompleteFinderXml(task.text)) errors.push(`${label} 视频号代码块未完整采集，请在预览页手动补录完整参数`);
      continue;
    }
    const mediaPath = String(task.mediaPath || "").trim();
    if (!mediaPath) {
      errors.push(`${label} 素材路径为空`);
      continue;
    }
    if (isTemporaryBrowserMediaPath(mediaPath)) {
      errors.push(`${label} 是浏览器临时素材地址，不能正式发单，请重新生成预览或点“更换素材”换成本地文件：${mediaPath}`);
      continue;
    }
    if (isRemoteMediaPath(mediaPath)) {
      const detail = task.mediaDownloadError ? `，下载失败：${task.mediaDownloadError}` : "";
      errors.push(`${label} 是远程素材地址未落地，不能正式发单${detail}：${mediaPath}`);
      continue;
    }
    if (!mediaExtensionLooksValid(mediaPath, task.type)) {
      errors.push(`${label} 素材类型不匹配：${task.type} / ${mediaPath}`);
    }
    if (isLocalMediaPath(mediaPath)) {
      try {
        const stat = await fs.stat(path.resolve(options.runDir || process.cwd(), mediaPath));
        if (!stat.isFile() || stat.size <= 0) errors.push(`${label} 素材文件无效：${mediaPath}`);
      } catch {
        errors.push(`${label} 素材不存在：${mediaPath}`);
      }
    }
  }
  if (errors.length) {
    throw new Error(`保存预览内容失败：${errors.join("；")}`);
  }
  return { ok: true, count: normalized.length };
}

function validPreviewDate(value) {
  const text = String(value || "").trim();
  return /^\d{1,2}\s*[\/月-]\s*\d{1,2}\s*日?$/.test(text) || /^\d{4}-\d{1,2}-\d{1,2}$/.test(text);
}

function validPreviewTime(value) {
  const match = String(value || "").trim().match(/^(\d{1,2})[:：](\d{1,2})(?:[:：](\d{1,2}))?$/);
  if (!match) return false;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  const second = Number(match[3] || 0);
  return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59 && second >= 0 && second <= 59;
}

function isLocalMediaPath(mediaPath) {
  if (isTemporaryBrowserMediaPath(mediaPath)) return false;
  if (/^[a-z]+:\/\//i.test(mediaPath)) return false;
  if (/^data:/i.test(mediaPath)) return false;
  if (/^sample:\/\//i.test(mediaPath)) return false;
  return Boolean(mediaPath);
}

function mediaExtensionLooksValid(mediaPath, type) {
  if (/^sample:\/\//i.test(mediaPath)) return true;
  const ext = path.extname(mediaPath).toLowerCase();
  if (type === "image") return [".jpg", ".jpeg", ".png", ".webp"].includes(ext);
  if (type === "sticker") return [".gif", ".png", ".webp", ".jpg", ".jpeg"].includes(ext);
  if (type === "video") return [".mp4", ".mov", ".webm"].includes(ext);
  return false;
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

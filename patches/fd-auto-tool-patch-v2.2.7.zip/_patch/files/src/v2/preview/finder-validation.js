// This function is also embedded in the preview page so both save entry points
// resolve only the known, repaired finder error, never unrelated diagnostics.
export function isCompleteFinderXml(text) {
  const value = String(text || "").trim();
  return /<msg\b/i.test(value) && /<appmsg\b/i.test(value)
    && (/<finderFeed\b/i.test(value) || /<type>\s*51\s*<\/type>/i.test(value))
    && /<\/msg>\s*$/i.test(value);
}

export function clearResolvedFinderError(task) {
  if (task?.type === "finder" && task.previewError === "finder_xml_incomplete" && isCompleteFinderXml(task.text)) {
    delete task.previewError;
    delete task.invalidReason;
  }
  return task;
}

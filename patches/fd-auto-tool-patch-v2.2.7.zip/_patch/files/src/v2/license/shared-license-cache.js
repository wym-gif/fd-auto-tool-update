import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createHash, createPublicKey, randomUUID, verify as verifySignature } from "node:crypto";

const PROTOCOL = "miaoquan-license-v2";
const TOKEN_TYPE = "MQ-LICENSE-V1";
const TOKEN_AUDIENCE = "miaoquan-license-client";
const STATE_VERSION = 1;
const DEFAULT_TTL_SECONDS = 10 * 60;
const CLOCK_SKEW_SECONDS = 30;
const LOCK_STALE_MS = 15_000;
const LOCK_WAIT_MS = 4_000;
const memoryFlights = new Map();

export function sharedLicenseCacheRoot(options = {}) {
  if (options.sharedLicenseCacheRoot) return path.resolve(options.sharedLicenseCacheRoot);
  const base = process.env.LOCALAPPDATA || os.tmpdir();
  return path.join(base, "MiaoQuan", "license-cache-v2");
}

export function licenseTrustScope({ companyId, endpoint, deviceId, signingKeys }) {
  const keys = normalizeSigningKeys(signingKeys);
  const trust = keys.map(({ kid, publicKeyPem }) => `${kid}:${createHash("sha256").update(publicKeyPem).digest("hex")}`).sort();
  return createHash("sha256").update(JSON.stringify({
    protocol: PROTOCOL,
    companyId,
    endpoint: String(endpoint),
    deviceId,
    trust
  })).digest("hex");
}

export async function resolveSharedLicenseAuthorization(context) {
  const scope = licenseTrustScope(context);
  const flightKey = `${sharedLicenseCacheRoot(context)}|${scope}|${context.action}`;
  if (memoryFlights.has(flightKey)) return memoryFlights.get(flightKey);
  const promise = resolveSharedLicenseAuthorizationInner({ ...context, scope }).finally(() => memoryFlights.delete(flightKey));
  memoryFlights.set(flightKey, promise);
  return promise;
}

async function resolveSharedLicenseAuthorizationInner(context) {
  const nowMs = nowValue(context);
  const cached = await readSharedState(context);
  const cachedDecision = decisionFromState(cached, context, nowMs);
  if (cachedDecision.allowed && context.forceRefresh !== true) {
    if (shouldRefresh(cachedDecision, context, nowMs)) {
      return refreshSharedAuthorization(context, { cached, required: false });
    }
    return cachedDecision;
  }
  return refreshSharedAuthorization(context, { cached, required: context.forceRefresh !== true });
}

export async function refreshSharedAuthorization(context, options = {}) {
  const scope = context.scope || licenseTrustScope(context);
  const flightKey = `${sharedLicenseCacheRoot(context)}|refresh|${scope}`;
  if (memoryFlights.has(flightKey)) return memoryFlights.get(flightKey);
  const refreshGeneration = Number(options.cached?.generation || 0);
  const lockContext = { ...context, scope, refreshGeneration };
  const promise = withSharedLock(lockContext, async (lock) => {
    const current = await readSharedState({ ...context, scope });
    const currentDecision = decisionFromState(current, context, nowValue(context));
    if (options.required && currentDecision.allowed) return currentDecision;
    if (!currentDecision.allowed && Number(current?.generation || 0) > refreshGeneration) return currentDecision;
    const generation = Number(current?.generation || 0);
    let remote;
    try {
      remote = await context.fetchRemote();
    } catch (error) {
      remote = { kind: "unavailable", message: error?.message || "授权服务暂不可用。", errorCode: error?.code || "LICENSE_UNAVAILABLE" };
    }
    if (remote.kind === "denied") {
      const next = {
        version: STATE_VERSION,
        scope,
        generation: generation + 1,
        credential: "",
        deniedAt: new Date(nowValue(context)).toISOString(),
        denialCode: String(remote.code || "LICENSE_DENIED").slice(0, 80),
        denialMessage: String(remote.message || "公司授权未通过。 ").trim().slice(0, 200),
        updatedAt: new Date(nowValue(context)).toISOString()
      };
      await writeSharedState(context, next, lock);
      return deniedDecision(next.denialMessage, "revoked", next.denialCode);
    }
    if (remote.kind === "signed") {
      const verified = verifyLicenseCredential(remote.credential, context, nowValue(context));
      if (!verified.ok) return deniedDecision(verified.message, verified.state, verified.code);
      const latest = await readSharedState(context);
      if (Number(latest?.generation || 0) !== generation) {
        return deniedDecision("授权状态已被更新，本次迟到响应未采用。", "revoked", "LICENSE_STALE_RESPONSE");
      }
      const next = {
        version: STATE_VERSION,
        scope,
        generation,
        credential: remote.credential,
        deniedAt: "",
        denialCode: "",
        denialMessage: "",
        updatedAt: new Date(nowValue(context)).toISOString()
      };
      await writeSharedState(context, next, lock);
      return credentialDecision(verified.payload, "shared", false);
    }
    if (remote.kind === "legacy_allowed") {
      return {
        allowed: true,
        state: "legacy_authorized",
        shared: false,
        expiresAt: "",
        message: "授权通过；当前服务器尚未提供本机共享凭证，本次操作仍使用实时检查。"
      };
    }
    const fallback = decisionFromState(current, context, nowValue(context));
    if (fallback.allowed) {
      return { ...fallback, state: "refresh_unavailable", message: `授权刷新暂不可用；本机共享授权仍有效至 ${formatLocalTime(fallback.expiresAt)}。`, refreshError: remote.message || "" };
    }
    if (["expired", "revoked"].includes(fallback.state)) return fallback;
    return deniedDecision(remote.message || "无法确认公司授权，请检查公司网络或 VPN。", "unavailable", remote.errorCode || "LICENSE_UNAVAILABLE");
  });
  memoryFlights.set(flightKey, promise);
  try {
    return await promise;
  } finally {
    memoryFlights.delete(flightKey);
  }
}

export function verifyLicenseCredential(token, context, nowMs = Date.now()) {
  try {
    const parts = String(token || "").split(".");
    if (parts.length !== 3 || parts.some((part) => !part || !/^[A-Za-z0-9_-]+$/.test(part))) throw tokenError("授权凭证格式无效。", "LICENSE_TOKEN_FORMAT");
    const header = JSON.parse(decodeBase64Url(parts[0]));
    if (!header || Array.isArray(header) || Object.keys(header).sort().join(",") !== "alg,kid,typ"
      || header.alg !== "EdDSA" || header.typ !== TOKEN_TYPE || typeof header.kid !== "string") {
      throw tokenError("授权凭证算法或头部无效。", "LICENSE_TOKEN_HEADER");
    }
    const key = normalizeSigningKeys(context.signingKeys).find((item) => item.kid === header.kid);
    if (!key) throw tokenError("授权凭证使用了未知签名密钥，请更新程序。", "LICENSE_TOKEN_KEY");
    const validSignature = verifySignature(null, Buffer.from(`${parts[0]}.${parts[1]}`), createPublicKey(key.publicKeyPem), decodeBase64UrlBuffer(parts[2]));
    if (!validSignature) throw tokenError("授权凭证签名校验失败。", "LICENSE_TOKEN_SIGNATURE");
    const payload = JSON.parse(decodeBase64Url(parts[1]));
    const expectedKeys = ["appVersion", "aud", "companyId", "deviceId", "exp", "iat", "iss", "jti", "protocolVersion", "scopes"];
    if (!payload || Array.isArray(payload) || Object.keys(payload).sort().join(",") !== expectedKeys.sort().join(",")) {
      throw tokenError("授权凭证字段无效。", "LICENSE_TOKEN_PAYLOAD");
    }
    if (payload.iss !== "miaoquan-license-server" || payload.aud !== TOKEN_AUDIENCE || payload.protocolVersion !== PROTOCOL
      || payload.companyId !== context.companyId || payload.deviceId !== context.deviceId || payload.appVersion !== context.appVersion) {
      throw tokenError("授权凭证不属于当前公司或设备。", "LICENSE_TOKEN_BINDING");
    }
    if (!Array.isArray(payload.scopes) || payload.scopes.length < 1 || payload.scopes.length > 16
      || payload.scopes.some((value) => typeof value !== "string" || value.length > 32)) {
      throw tokenError("授权凭证用途无效。", "LICENSE_TOKEN_SCOPE");
    }
    if (!payload.scopes.includes(context.action)) throw tokenError("当前授权凭证不包含此操作权限。", "LICENSE_TOKEN_SCOPE");
    if (!Number.isInteger(payload.iat) || !Number.isInteger(payload.exp) || typeof payload.jti !== "string" || !/^[a-f0-9]{16,64}$/.test(payload.jti)) {
      throw tokenError("授权凭证时间或编号无效。", "LICENSE_TOKEN_TIME");
    }
    const nowSeconds = Math.floor(nowMs / 1000);
    if (payload.iat > nowSeconds + CLOCK_SKEW_SECONDS) throw tokenError("本机时间异常，授权凭证尚未生效。", "LICENSE_CLOCK_INVALID", "clock_invalid");
    if (payload.exp <= nowSeconds) throw tokenError("本机共享授权已到期，需要重新联网检查。", "LICENSE_TOKEN_EXPIRED", "expired");
    const maxTtl = Number(context.maxCredentialTtlSeconds || DEFAULT_TTL_SECONDS) + CLOCK_SKEW_SECONDS;
    if (payload.exp <= payload.iat || payload.exp - payload.iat > maxTtl) throw tokenError("授权凭证有效期超出客户端允许范围。", "LICENSE_TOKEN_TTL");
    return { ok: true, payload };
  } catch (error) {
    return { ok: false, state: error.state || "invalid_credential", code: error.code || "LICENSE_TOKEN_INVALID", message: error.message || "授权凭证无效。" };
  }
}

export async function invalidateSharedLicense(context, denial = {}) {
  const scope = context.scope || licenseTrustScope(context);
  return withSharedLock({ ...context, scope }, async (lock) => {
    const current = await readSharedState({ ...context, scope });
    const next = {
      version: STATE_VERSION,
      scope,
      generation: Number(current?.generation || 0) + 1,
      credential: "",
      deniedAt: new Date(nowValue(context)).toISOString(),
      denialCode: String(denial.code || "LICENSE_DENIED").slice(0, 80),
      denialMessage: String(denial.message || "公司授权已撤销。 ").trim().slice(0, 200),
      updatedAt: new Date(nowValue(context)).toISOString()
    };
    await writeSharedState(context, next, lock);
    return next;
  });
}

async function readSharedState(context) {
  const file = statePath(context);
  try {
    const raw = await fs.readFile(file, "utf8");
    if (raw.length > 32 * 1024) return null;
    const value = JSON.parse(raw);
    if (!value || Array.isArray(value) || value.version !== STATE_VERSION || value.scope !== (context.scope || licenseTrustScope(context))) return null;
    return value;
  } catch {
    return null;
  }
}

async function writeSharedState(context, value, lock) {
  await assertLockOwner(lock);
  const file = statePath(context);
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 });
  const temp = `${file}.${process.pid}.${randomUUID()}.tmp`;
  await fs.writeFile(temp, `${JSON.stringify(value)}\n`, { encoding: "utf8", mode: 0o600 });
  await fs.rename(temp, file);
}

function decisionFromState(state, context, nowMs) {
  if (state?.deniedAt && !state.credential) return deniedDecision(state.denialMessage || "公司授权未通过。", "revoked", state.denialCode || "LICENSE_DENIED");
  if (!state?.credential) return deniedDecision("尚未取得本机共享授权。", "missing", "LICENSE_TOKEN_MISSING");
  const verified = verifyLicenseCredential(state.credential, context, nowMs);
  if (!verified.ok) return deniedDecision(verified.message, verified.state, verified.code);
  return credentialDecision(verified.payload, "shared", true);
}

function credentialDecision(payload, state, cached) {
  return {
    allowed: true,
    state,
    shared: true,
    cached,
    expiresAt: new Date(payload.exp * 1000).toISOString(),
    issuedAt: new Date(payload.iat * 1000).toISOString(),
    scopes: [...payload.scopes],
    credentialId: payload.jti,
    message: `授权有效（本机共享，有效至 ${formatLocalTime(new Date(payload.exp * 1000).toISOString())}）。`
  };
}

function deniedDecision(message, state, code) {
  return { allowed: false, state, shared: false, expiresAt: "", code, message };
}

function shouldRefresh(decision, context, nowMs) {
  const refreshBeforeMs = Number(context.refreshBeforeMs ?? 5 * 60_000);
  const jitterRange = Math.max(0, Number(context.refreshJitterMs ?? 45_000));
  const stable = parseInt(createHash("sha256").update(`${context.deviceId}|${process.pid}`).digest("hex").slice(0, 8), 16);
  const jitter = jitterRange ? stable % jitterRange : 0;
  return Date.parse(decision.expiresAt) - nowMs <= refreshBeforeMs + jitter;
}

async function withSharedLock(context, task) {
  const root = path.join(sharedLicenseCacheRoot(context), context.scope || licenseTrustScope(context));
  await fs.mkdir(root, { recursive: true, mode: 0o700 });
  const lockPath = path.join(root, "refresh.lock");
  const deadline = Date.now() + Number(context.lockWaitMs || LOCK_WAIT_MS);
  while (true) {
    const owner = { token: randomUUID(), pid: process.pid, createdAt: Date.now(), scope: context.scope };
    try {
      const handle = await fs.open(lockPath, "wx", 0o600);
      await handle.writeFile(JSON.stringify(owner), "utf8");
      await handle.close();
      const lock = { path: lockPath, owner };
      try {
        return await task(lock);
      } finally {
        await releaseLock(lock);
      }
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      await recoverStaleLock(lockPath, context);
      const available = await readSharedState(context);
      const decision = decisionFromState(available, context, nowValue(context));
      if (decision.allowed) return decision;
      if (Number(available?.generation || 0) > Number(context.refreshGeneration || 0)) return decision;
      if (Date.now() >= deadline) {
        return decision.state === "expired" ? decision : deniedDecision("授权检查正在由本机其他实例处理，请稍后重试。", "busy", "LICENSE_SHARED_BUSY");
      }
      await new Promise((resolve) => setTimeout(resolve, 40));
    }
  }
}

async function recoverStaleLock(lockPath, context) {
  try {
    const stat = await fs.stat(lockPath);
    const owner = JSON.parse(await fs.readFile(lockPath, "utf8"));
    if (Date.now() - stat.mtimeMs < Number(context.lockStaleMs || LOCK_STALE_MS)) return false;
    if (owner?.pid && processIsAlive(owner.pid)) return false;
    const confirm = JSON.parse(await fs.readFile(lockPath, "utf8"));
    if (confirm.token !== owner.token || confirm.createdAt !== owner.createdAt) return false;
    await fs.unlink(lockPath);
    return true;
  } catch {
    return false;
  }
}

async function assertLockOwner(lock) {
  const current = JSON.parse(await fs.readFile(lock.path, "utf8"));
  if (current.token !== lock.owner.token || current.pid !== lock.owner.pid || current.createdAt !== lock.owner.createdAt) {
    throw Object.assign(new Error("本机共享授权锁已失效，拒绝写入迟到结果。"), { code: "LICENSE_SHARED_LOCK_LOST" });
  }
}

async function releaseLock(lock) {
  try {
    await assertLockOwner(lock);
    await fs.unlink(lock.path);
  } catch {}
}

function statePath(context) {
  const scope = context.scope || licenseTrustScope(context);
  return path.join(sharedLicenseCacheRoot(context), scope, "state.json");
}

function normalizeSigningKeys(value) {
  if (!Array.isArray(value)) return [];
  return value.filter((item) => item && typeof item.kid === "string" && /^[A-Za-z0-9._-]{1,40}$/.test(item.kid)
    && typeof item.publicKeyPem === "string" && item.publicKeyPem.includes("PUBLIC KEY"))
    .map((item) => ({ kid: item.kid, publicKeyPem: item.publicKeyPem.trim() }));
}

function processIsAlive(pid) {
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

function decodeBase64Url(value) {
  return decodeBase64UrlBuffer(value).toString("utf8");
}

function decodeBase64UrlBuffer(value) {
  return Buffer.from(String(value), "base64url");
}

function tokenError(message, code, state = "invalid_credential") {
  return Object.assign(new Error(message), { code, state });
}

function nowValue(context) {
  return typeof context.now === "function" ? Number(context.now()) : Date.now();
}

function formatLocalTime(value) {
  const time = new Date(value);
  return Number.isFinite(time.getTime()) ? time.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" }) : "未知时间";
}


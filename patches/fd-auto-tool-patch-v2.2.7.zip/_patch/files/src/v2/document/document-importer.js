import path from "node:path";
import zlib from "node:zlib";
import { detectPastedVideoPlaceholder, isPastedVideoChromeText, stripPastedVideoChromeText } from "./pasted-video-placeholder.js";
import { isLikelyTimedBodySpeaker, parseExplicitTimedRoleHeaderLine } from "../parser/role-header.js";

const SUPPORTED_EXTENSIONS = new Set([".html", ".htm", ".txt", ".md", ".docx"]);

export function importDocumentToRawEvents(input = {}, options = {}) {
  const fileName = String(input.fileName || "").trim();
  const contentType = String(input.contentType || "").trim();
  const rawContent = String(input.content || input.text || "");
  const extension = detectDocumentExtension(fileName);
  const binary = tryDecodeDocumentBinary(input);
  const binaryLooksDocx = binary ? isDocxZipBuffer(binary) : false;
  if (binaryLooksDocx || extension === ".docx" || /wordprocessingml|officedocument\.wordprocessingml/i.test(contentType)) {
    const imported = importDocxDocument(input, binary);
    const events = imported.events.map((event, index) => ({
      ...event,
      sourceId: event.sourceId || `doc-import-${index + 1}`,
      order: index + 1,
      blockIndex: index,
      importSource: input.pasteSource === "rich-text-clipboard" ? "rich-text-clipboard" : "document-import"
    }));
    return {
      events,
      diagnostics: buildImportDiagnostics({
        ...input,
        isDocx: true,
        events,
        warnings: imported.warnings
      })
    };
  }
  if (fileName && extension && !SUPPORTED_EXTENSIONS.has(extension)) {
    if (extension === ".pdf") throw new Error("PDF 暂不支持直接导入。请先从飞书/Word 导出 HTML，或复制富文本粘贴到导入框。");
    if (extension === ".doc") throw new Error("旧版 .doc 暂不支持直接导入。请在 Word/WPS 里另存为 .docx，或导出 HTML 后再导入。");
    throw new Error(`文档导入支持 HTML、TXT、MD、DOCX。当前识别到${extension ? ` ${extension}` : "未知"} 文件，请导出 HTML、另存为 DOCX，或复制富文本粘贴。`);
  }
  if (!rawContent.trim()) throw new Error("导入文档内容为空。");
  const isHtml = /html/i.test(contentType) || [".html", ".htm"].includes(extension) || looksLikeHtml(rawContent);
  let imported = isHtml ? importHtmlDocument(rawContent, input) : importPlainTextDocument(rawContent, input);
  if (isHtml && input.pasteSource === "rich-text-clipboard" && String(input.pastedPlainText || "").trim()) {
    imported = recoverPastedPlainTextBeforeMedia(imported, input.pastedPlainText);
  }
  const events = imported.events.map((event, index) => ({
    ...event,
    sourceId: event.sourceId || `doc-import-${index + 1}`,
    order: index + 1,
    blockIndex: index,
    importSource: input.pasteSource === "rich-text-clipboard" ? "rich-text-clipboard" : "document-import"
  }));
  return {
    events,
    diagnostics: buildImportDiagnostics({
      ...input,
      isHtml,
      events,
      warnings: imported.warnings
    })
  };
}

function importHtmlDocument(html, input = {}) {
  const events = [];
  const warnings = [];
  const body = extractHtmlBody(html);
  const tokens = tokenizeHtmlContent(body);
  let textBuffer = [];
  let textIndex = 1;
  let mediaIndex = 1;

  const flushText = () => {
    const text = normalizeImportedText(textBuffer.join("\n"));
    textBuffer = [];
    if (!text.trim()) return;
    for (const block of splitImportedTextBlocks(text)) {
      events.push({
        sourceId: `doc-text-${textIndex++}`,
        kind: "line",
        text: block,
        sourceText: block,
        highlighted: looksHighlightedHtmlText(block)
      });
    }
  };

  for (const token of tokens) {
    if (token.type === "text") {
      textBuffer.push(token.text);
      continue;
    }
    flushText();
    const type = token.videoPlaceholder ? "video" : token.type === "video" ? "video" : token.sticker ? "sticker" : "image";
    if (!token.src) warnings.push(`第 ${mediaIndex} 个${mediaTypeLabel(type)}没有可读取地址，已在原位置保留待补素材。`);
    if (token.videoPlaceholder?.warning) warnings.push(`第 ${mediaIndex} 个素材${token.videoPlaceholder.warning}`);
    events.push({
      sourceId: `doc-media-${mediaIndex++}`,
      kind: type,
      type,
      text: "",
      sourceText: token.alt || token.src,
      mediaPath: token.src,
      sourceUrl: token.src,
      assetUrl: token.src,
      ...(!token.src ? {
        missingMedia: true,
        previewError: `${mediaTypeLabel(type)}没有可读取地址，请在预览页补充素材后再创建。`
      } : token.videoPlaceholder?.previewError ? { previewError: token.videoPlaceholder.previewError } : {})
    });
  }
  flushText();
  return { events, warnings };
}

function importPlainTextDocument(content, input = {}) {
  const events = normalizeImportedText(content)
    .split("\n")
    .map((line) => line.trimEnd())
    .filter((line, index, lines) => line.trim() || hasNearbyMeaningfulLine(lines, index))
    .map((line, index) => ({
      sourceId: `doc-line-${index + 1}`,
      kind: "line",
      text: line,
      sourceText: line,
      highlighted: false
    }));
  return { events, warnings: [] };
}

function recoverPastedPlainTextBeforeMedia(imported, pastedPlainText) {
  const events = Array.isArray(imported?.events) ? imported.events.slice() : [];
  const plainSegments = collectPlainRoleSegments(pastedPlainText);
  if (!plainSegments.length) return imported;

  const segmentsByHeader = new Map();
  for (const segment of plainSegments) {
    const key = importedHeaderKey(segment.header);
    if (!segmentsByHeader.has(key)) segmentsByHeader.set(key, []);
    segmentsByHeader.get(key).push(segment);
  }

  const recovered = [];
  let recoveredCount = 0;
  let matchedSegmentCount = 0;
  for (let index = 0; index < events.length; index += 1) {
    const event = events[index];
    recovered.push(event);
    if (event.kind !== "line" || !looksLikeImportedRoleHeader(event.text)) continue;

    const candidates = segmentsByHeader.get(importedHeaderKey(event.text)) || [];
    const plainSegment = candidates.shift();
    if (!plainSegment) continue;
    matchedSegmentCount += 1;
    const body = plainBodyBeforeMediaPlaceholder(plainSegment.lines);
    if (!body) continue;

    const nextHeaderIndex = findNextImportedHeaderIndex(events, index + 1);
    const segmentEnd = nextHeaderIndex < 0 ? events.length : nextHeaderIndex;
    const firstMediaIndex = events.findIndex((candidate, candidateIndex) =>
      candidateIndex > index && candidateIndex < segmentEnd && isImportedMediaEvent(candidate)
    );
    if (firstMediaIndex < 0) continue;
    const hasHtmlBodyBeforeMedia = events.slice(index + 1, firstMediaIndex)
      .some((candidate) => candidate.kind === "line" && String(candidate.text || "").trim());
    if (hasHtmlBodyBeforeMedia) continue;

    recovered.push({
      sourceId: `doc-paste-plain-${++recoveredCount}`,
      kind: "line",
      text: body,
      sourceText: body,
      highlighted: looksHighlightedHtmlText(body)
    });
  }

  const unmatchedCount = Math.max(0, plainSegments.length - matchedSegmentCount);
  if (!recoveredCount && !unmatchedCount) return imported;
  return {
    ...imported,
    events: recoveredCount ? recovered : events,
    warnings: [
      ...(Array.isArray(imported.warnings) ? imported.warnings : []),
      ...(recoveredCount ? [`已从富文本粘贴的纯文本后备中补回 ${recoveredCount} 段图片前正文。`] : []),
      ...(unmatchedCount ? [`纯文本后备有 ${unmatchedCount} 段无法与 HTML 中的角色记录唯一对齐，未自动拼接，请核对对应位置。`] : [])
    ]
  };
}

function collectPlainRoleSegments(text) {
  const lines = normalizeImportedText(text).split("\n");
  const segments = [];
  let current = null;
  for (const line of lines) {
    if (looksLikeImportedRoleHeader(line)) {
      current = { header: line.trim(), lines: [] };
      segments.push(current);
      continue;
    }
    if (current) current.lines.push(line);
  }
  return segments;
}

function plainBodyBeforeMediaPlaceholder(lines) {
  const placeholderIndex = lines.findIndex(isImportedMediaPlaceholderLine);
  if (placeholderIndex < 0) return "";
  const body = trimOuterBlankLines(lines.slice(0, placeholderIndex).join("\n"));
  return body.trim() ? body : "";
}

function isImportedMediaPlaceholderLine(line) {
  return /^\s*[\[【](?:图片|表情包|动态表情|视频|素材)[\]】]\s*$/.test(String(line || ""));
}

function importedHeaderKey(line) {
  return String(line || "").trim().replace(/\s+/g, " ").toLowerCase();
}

function findNextImportedHeaderIndex(events, startIndex) {
  for (let index = startIndex; index < events.length; index += 1) {
    if (events[index]?.kind === "line" && looksLikeImportedRoleHeader(events[index].text)) return index;
  }
  return -1;
}

function isImportedMediaEvent(event) {
  return event?.kind === "image" || event?.kind === "sticker" || event?.kind === "video";
}

function importDocxDocument(input = {}, knownBuffer = null) {
  const buffer = knownBuffer || decodeDocumentBinary(input);
  const zip = readZipEntries(buffer);
  const documentXml = zip.get("word/document.xml")?.toString("utf8") || "";
  if (!documentXml.trim()) throw new Error("DOCX 中没有找到 word/document.xml，无法导入。");
  const relationships = parseDocxRelationships(zip.get("word/_rels/document.xml.rels")?.toString("utf8") || "");
  const events = [];
  const warnings = [];
  let textIndex = 1;
  let mediaIndex = 1;
  for (const item of tokenizeDocxDocumentXml(documentXml)) {
    if (item.type === "text") {
      const text = normalizeImportedText(item.text);
      if (!text.trim()) continue;
      for (const block of splitImportedTextBlocks(text)) {
        events.push({
          sourceId: `docx-text-${textIndex++}`,
          kind: "line",
          text: block,
          sourceText: block,
          highlighted: looksHighlightedHtmlText(block)
        });
      }
      continue;
    }
    const target = relationships.get(item.rId);
    if (!target) {
      warnings.push(`DOCX 第 ${mediaIndex} 个图片没有找到关系 ${item.rId}，已跳过。`);
      mediaIndex += 1;
      continue;
    }
    const normalizedTarget = normalizeDocxTarget(target);
    const mediaBuffer = zip.get(normalizedTarget);
    if (!mediaBuffer) {
      warnings.push(`DOCX 第 ${mediaIndex} 个图片没有找到文件 ${normalizedTarget}，已跳过。`);
      mediaIndex += 1;
      continue;
    }
    const mime = mimeFromFileName(normalizedTarget);
    const dataUrl = `data:${mime};base64,${mediaBuffer.toString("base64")}`;
    const isSticker = /gif/i.test(mime) || /表情|动态表情|sticker/i.test(item.alt || normalizedTarget);
    events.push({
      sourceId: `docx-media-${mediaIndex++}`,
      kind: isSticker ? "sticker" : "image",
      type: isSticker ? "sticker" : "image",
      text: "",
      sourceText: item.alt || normalizedTarget,
      mediaPath: dataUrl,
      sourceUrl: dataUrl,
      assetUrl: dataUrl
    });
  }
  return { events, warnings };
}

function tokenizeHtmlContent(html) {
  const normalized = String(html || "")
    .replace(/<\s*br\s*\/?\s*>/gi, "\n")
    .replace(/<\/(?:p|div|section|article|li|h[1-6]|tr|blockquote)>/gi, "\n")
    .replace(/<pre\b[^>]*>([\s\S]*?)<\/pre>/gi, (_, inner) => {
      const code = decodeHtml(stripHtmlTags(inner, { keepLineBreaks: true }))
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
      return "\n" + code + "\n";
    });
  const regex = /<(img|video|source)\b([^>]*)>/gi;
  const tokens = [];
  let lastIndex = 0;
  let previousVideoPlaceholder = false;
  let match;
  while ((match = regex.exec(normalized))) {
    const before = htmlTextToPlain(normalized.slice(lastIndex, match.index));
    const tag = match[1].toLowerCase();
    const attrs = parseHtmlAttributes(match[2] || "");
    const src = attrs.src || attrs["data-src"] || attrs["data-original"] || "";
    const alt = attrs.alt || attrs.title || "";
    const context = normalized.slice(Math.max(0, match.index - 500), Math.min(normalized.length, regex.lastIndex + 500));
    const videoPlaceholder = detectPastedVideoPlaceholder({ tag, attrs, src, context });
    const beforeText = videoPlaceholder ? stripPastedVideoChromeText(before) : before;
    if (beforeText.trim() && !((videoPlaceholder || previousVideoPlaceholder) && isPastedVideoChromeText(beforeText))) {
      tokens.push({ type: "text", text: beforeText });
    }
    tokens.push({
      type: tag === "img" ? "image" : "video",
      src,
      alt,
      videoPlaceholder,
      sticker: tag === "img" && (/表情|动态表情|sticker/i.test(`${alt} ${src}`) || /\.gif(?:$|[?#])/i.test(src) || /^data:image\/gif/i.test(src))
    });
    previousVideoPlaceholder = Boolean(videoPlaceholder);
    lastIndex = regex.lastIndex;
  }
  const tail = htmlTextToPlain(normalized.slice(lastIndex));
  const tailText = previousVideoPlaceholder ? stripPastedVideoChromeText(tail) : tail;
  if (tailText.trim() && !(previousVideoPlaceholder && isPastedVideoChromeText(tailText))) tokens.push({ type: "text", text: tailText });
  return mergeNestedVideoSourceTokens(tokens);
}

function mergeNestedVideoSourceTokens(tokens) {
  const merged = [];
  for (let index = 0; index < tokens.length; index += 1) {
    const token = tokens[index];
    const next = tokens[index + 1];
    if (token?.type === "video" && !token.src && next?.type === "video" && next.src) {
      merged.push({ ...token, src: next.src, alt: token.alt || next.alt });
      index += 1;
      continue;
    }
    merged.push(token);
  }
  return merged;
}

function buildImportDiagnostics(input = {}) {
  const events = Array.isArray(input.events) ? input.events : [];
  const media = events.filter((event) => ["image", "sticker", "video"].includes(event.kind));
  const remoteMedia = media.filter((event) => /^https?:\/\//i.test(event.mediaPath || event.sourceUrl || ""));
  const dataMedia = media.filter((event) => /^data:/i.test(event.mediaPath || event.sourceUrl || ""));
  const finderLikeText = events.filter((event) => event.kind === "line" && /<finderFeed\b|<appmsg\b|<msg\b/i.test(event.text || ""));
  const warnings = Array.isArray(input.warnings) ? input.warnings.slice() : [];
  if (remoteMedia.length) warnings.push(`发现 ${remoteMedia.length} 个远程素材，会尝试下载；飞书私有链接可能需要后续手动更换。`);
  if (finderLikeText.length) warnings.push(`发现 ${finderLikeText.length} 段疑似视频号代码，预览里会按视频号规则校验完整性。`);
  return {
    source: "document-import",
    fileName: String(input.fileName || "").trim(),
    contentType: String(input.contentType || "").trim(),
    importedAs: input.isDocx ? "docx" : input.isHtml ? "html" : "text",
    eventCount: events.length,
    textCount: events.filter((event) => event.kind === "line").length,
    mediaCount: media.length,
    imageCount: events.filter((event) => event.kind === "image").length,
    stickerCount: events.filter((event) => event.kind === "sticker").length,
    videoCount: events.filter((event) => event.kind === "video").length,
    remoteMediaCount: remoteMedia.length,
    dataMediaCount: dataMedia.length,
    finderLikeTextCount: finderLikeText.length,
    warnings
  };
}

function detectDocumentExtension(fileName) {
  const text = String(fileName || "").trim().toLowerCase();
  const match = text.match(/\.(html?|txt|md|docx?|pdf)(?:[\s)\]}）】"'`]*$)/i);
  if (!match) return "";
  return `.${match[1].toLowerCase()}`;
}

function tryDecodeDocumentBinary(input = {}) {
  try {
    return decodeDocumentBinary(input);
  } catch {
    return null;
  }
}

function decodeDocumentBinary(input = {}) {
  const contentBase64 = String(input.contentBase64 || "");
  if (contentBase64.trim()) {
    return Buffer.from(contentBase64.replace(/^data:[^,]+,/, ""), "base64");
  }
  const content = String(input.content || "");
  if (content.startsWith("UEs")) return Buffer.from(content, "base64");
  throw new Error("DOCX 导入缺少二进制内容，请重新上传 .docx 文件。");
}

function isDocxZipBuffer(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 4 || buffer.readUInt32LE(0) !== 0x04034b50) return false;
  try {
    return readZipEntries(buffer).has("word/document.xml");
  } catch {
    return false;
  }
}

function readZipEntries(buffer) {
  const entries = new Map();
  const eocdOffset = findEndOfCentralDirectory(buffer);
  if (eocdOffset < 0) throw new Error("DOCX 文件结构不完整，找不到 zip 目录。");
  const totalEntries = buffer.readUInt16LE(eocdOffset + 10);
  let centralOffset = buffer.readUInt32LE(eocdOffset + 16);
  for (let i = 0; i < totalEntries; i += 1) {
    if (buffer.readUInt32LE(centralOffset) !== 0x02014b50) throw new Error("DOCX zip 中央目录损坏。");
    const method = buffer.readUInt16LE(centralOffset + 10);
    const compressedSize = buffer.readUInt32LE(centralOffset + 20);
    const fileNameLength = buffer.readUInt16LE(centralOffset + 28);
    const extraLength = buffer.readUInt16LE(centralOffset + 30);
    const commentLength = buffer.readUInt16LE(centralOffset + 32);
    const localHeaderOffset = buffer.readUInt32LE(centralOffset + 42);
    const fileName = buffer.toString("utf8", centralOffset + 46, centralOffset + 46 + fileNameLength).replace(/\\/g, "/");
    const localNameLength = buffer.readUInt16LE(localHeaderOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localHeaderOffset + 28);
    const dataStart = localHeaderOffset + 30 + localNameLength + localExtraLength;
    const compressed = buffer.subarray(dataStart, dataStart + compressedSize);
    let data;
    if (method === 0) data = Buffer.from(compressed);
    else if (method === 8) data = zlib.inflateRawSync(compressed);
    else throw new Error(`DOCX zip 使用了暂不支持的压缩方式：${method}`);
    entries.set(fileName, data);
    centralOffset += 46 + fileNameLength + extraLength + commentLength;
  }
  return entries;
}

function findEndOfCentralDirectory(buffer) {
  const min = Math.max(0, buffer.length - 0xffff - 22);
  for (let offset = buffer.length - 22; offset >= min; offset -= 1) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) return offset;
  }
  return -1;
}

function parseDocxRelationships(xml) {
  const relationships = new Map();
  const regex = /<Relationship\b([^>]*)\/?>/gi;
  let match;
  while ((match = regex.exec(String(xml || "")))) {
    const attrs = parseHtmlAttributes(match[1] || "");
    if (attrs.id && attrs.target) relationships.set(attrs.id, attrs.target);
  }
  return relationships;
}

function tokenizeDocxDocumentXml(xml) {
  const tokens = [];
  const paragraphRegex = /<w:p\b[\s\S]*?<\/w:p>/gi;
  let match;
  while ((match = paragraphRegex.exec(String(xml || "")))) {
    const paragraph = match[0];
    const pieces = [];
    const innerRegex = /<w:t\b[^>]*>([\s\S]*?)<\/w:t>|<w:tab\b[^>]*\/>|<w:br\b[^>]*\/>|<(?:a:blip|v:imagedata)\b([^>]*)\/?>/gi;
    let inner;
    while ((inner = innerRegex.exec(paragraph))) {
      if (inner[1] !== undefined) {
        pieces.push({ type: "text", text: decodeHtml(inner[1]) });
        continue;
      }
      if (/^<w:tab/i.test(inner[0])) {
        pieces.push({ type: "text", text: "\t" });
        continue;
      }
      if (/^<w:br/i.test(inner[0])) {
        pieces.push({ type: "text", text: "\n" });
        continue;
      }
      const attrs = parseHtmlAttributes(inner[2] || "");
      const rId = attrs["r:embed"] || attrs["r:id"] || attrs["r:link"];
      if (rId) pieces.push({ type: "image", rId, alt: "" });
    }
    let text = "";
    for (const piece of pieces) {
      if (piece.type === "text") {
        text += piece.text;
        continue;
      }
      if (text.trim()) {
        tokens.push({ type: "text", text });
        text = "";
      }
      tokens.push(piece);
    }
    if (text.trim()) tokens.push({ type: "text", text });
  }
  return tokens;
}

function normalizeDocxTarget(target) {
  const cleaned = String(target || "").replace(/\\/g, "/");
  if (cleaned.startsWith("/")) return cleaned.replace(/^\/+/, "");
  if (cleaned.startsWith("word/")) return cleaned;
  return path.posix.normalize(`word/${cleaned}`);
}

function mimeFromFileName(fileName) {
  const ext = path.extname(String(fileName || "")).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".gif") return "image/gif";
  if (ext === ".webp") return "image/webp";
  if (ext === ".bmp") return "image/bmp";
  if (ext === ".svg") return "image/svg+xml";
  return "image/png";
}

function looksLikeHtml(text) {
  return /<\/?[a-z][\s\S]*>/i.test(String(text || ""));
}

function extractHtmlBody(html) {
  const match = String(html || "").match(/<body\b[^>]*>([\s\S]*?)<\/body>/i);
  return match ? match[1] : String(html || "");
}

function stripHtmlTags(html, options = {}) {
  const source = options.keepLineBreaks
    ? String(html || "").replace(/<\s*br\s*\/?\s*>/gi, "\n").replace(/<\/(?:p|div|li)>/gi, "\n")
    : String(html || "");
  return source.replace(/<[^>]+>/g, "");
}

function htmlTextToPlain(html) {
  return normalizeImportedText(decodeHtml(stripHtmlTags(html, { keepLineBreaks: true })));
}

function parseHtmlAttributes(source) {
  const attrs = {};
  const regex = /([:\w-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  let match;
  while ((match = regex.exec(String(source || "")))) {
    attrs[match[1].toLowerCase()] = decodeHtml(match[2] ?? match[3] ?? match[4] ?? "");
  }
  return attrs;
}

function decodeHtml(text) {
  return String(text || "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, "\"")
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&amp;/gi, "&")
    .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCodePoint(parseInt(code, 16)));
}

function normalizeImportedText(text) {
  return String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u00a0/g, " ")
    .split("\n")
    .map((line) => line.trimEnd())
    .join("\n")
    .replace(/\n{4,}/g, "\n\n\n")
    .trim();
}

function splitImportedTextBlocks(text) {
  const lines = normalizeImportedText(text).split("\n");
  const blocks = [];
  let body = [];
  let xml = [];
  const flushBody = () => {
    const value = trimOuterBlankLines(body.join("\n"));
    body = [];
    if (value.trim()) blocks.push(value);
  };
  for (const line of lines) {
    const trimmed = line.trimEnd();
    if (!xml.length && /^\s*(?:<\?xml\b|<msg\b)/i.test(trimmed)) {
      flushBody();
      xml.push(trimmed);
      continue;
    }
    if (xml.length) {
      xml.push(trimmed);
      if (/<\/msg>\s*$/i.test(trimmed)) {
        blocks.push(trimOuterBlankLines(xml.join("\n")));
        xml = [];
      }
      continue;
    }
    if (looksLikeImportedRoleHeader(trimmed)) {
      flushBody();
      blocks.push(trimmed.trim());
      continue;
    }
    if (looksLikeImportedDayHeading(trimmed)) {
      flushBody();
      blocks.push(trimmed.trim());
      continue;
    }
    body.push(trimmed);
  }
  flushBody();
  if (xml.length) blocks.push(trimOuterBlankLines(xml.join("\n")));
  return blocks;
}

function looksLikeImportedRoleHeader(line) {
  const parsed = parseExplicitTimedRoleHeaderLine(line);
  return Boolean(parsed && !isLikelyTimedBodySpeaker(parsed.speaker));
}

function mediaTypeLabel(type) {
  if (type === "video") return "视频素材";
  if (type === "sticker") return "表情包素材";
  return "图片素材";
}

function looksLikeImportedDayHeading(line) {
  const text = String(line || "").trim();
  if (!text || text.length > 24 || /\d{1,2}[:：]\d{1,2}/.test(text)) return false;
  const compact = text.replace(/\s+/g, "").toLowerCase();
  if (/^(?:第)?[一二三四五六七八九十两]+天$/.test(compact)) return true;
  if (/^第?[1-9]\d?天$/.test(compact)) return true;
  if (/^(?:d|day)[1-9]\d?$/.test(compact)) return true;
  if (/^\d{1,2}[\/月]\d{1,2}(?:日|号)?$/.test(compact)) return true;
  return /^\d{1,2}(?:日|号)$/.test(compact);
}

function trimOuterBlankLines(text) {
  const lines = String(text || "").split("\n");
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines.at(-1).trim()) lines.pop();
  return lines.join("\n");
}

function hasNearbyMeaningfulLine(lines, index) {
  return Boolean(String(lines[index - 1] || "").trim() || String(lines[index + 1] || "").trim());
}

function looksHighlightedHtmlText(text) {
  return /豆妈|退换货包运费|售后无忧/.test(String(text || ""));
}

export const PASTED_VIDEO_PLACEHOLDER_ERROR = "疑似视频只导入到封面图，未拿到视频文件，请手动更换视频素材。";

export function detectPastedVideoPlaceholder(input = {}) {
  const tag = String(input.tag || "").toLowerCase();
  if (tag !== "img") return null;
  const attrs = Object(input.attrs || {});
  const src = String(input.src || attrs.src || attrs["data-src"] || attrs["data-original"] || "");
  if (!src || looksLikeAnimatedSticker(src, attrs)) return null;
  if (looksLikeRealVideoSource(src)) return null;

  const context = [
    attrs.alt,
    attrs.title,
    attrs.class,
    attrs.role,
    attrs["aria-label"],
    attrs["data-testid"],
    attrs["data-type"],
    attrs["data-video-id"],
    attrs["data-file-type"],
    attrs["data-mime"],
    input.context
  ].map((value) => String(value || "")).join(" ");

  const hasVideoWord = /视频|video|movie|media-card|video-card|video_player|videoplayer/i.test(context);
  const hasPlaySignal = /播放|play|player|▶|►|triangle/i.test(context);
  const hasDuration = /\b\d{1,2}:\d{2}(?::\d{2})?\b/.test(context);
  const hasVideoAttribute = Object.keys(attrs).some((key) => /video|player/i.test(key));

  if (!hasVideoWord && !hasVideoAttribute && !(hasPlaySignal && hasDuration)) return null;

  return {
    previewError: PASTED_VIDEO_PLACEHOLDER_ERROR,
    warning: PASTED_VIDEO_PLACEHOLDER_ERROR
  };
}

export function isPastedVideoChromeText(text) {
  const lines = String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (!lines.length || lines.length > 3) return false;
  return lines.every(isPastedVideoChromeLine);
}

export function stripPastedVideoChromeText(text) {
  return String(text || "")
    .split(/\r?\n/)
    .filter((line) => !isPastedVideoChromeLine(line.trim()))
    .join("\n");
}

function isPastedVideoChromeLine(line) {
  return /^(?:播放|play|▶|►|\d{1,2}:\d{2}(?::\d{2})?)$/i.test(String(line || "").trim());
}

function looksLikeAnimatedSticker(src, attrs = {}) {
  const text = [src, attrs.alt, attrs.title, attrs.class].map((value) => String(value || "")).join(" ");
  return /表情|动态表情|sticker/i.test(text) || /\.gif(?:$|[?#])/i.test(src) || /^data:image\/gif/i.test(src);
}

function looksLikeRealVideoSource(src) {
  return /^data:video\//i.test(src) || /\.(mp4|mov|webm)(?:$|[?#])/i.test(src);
}

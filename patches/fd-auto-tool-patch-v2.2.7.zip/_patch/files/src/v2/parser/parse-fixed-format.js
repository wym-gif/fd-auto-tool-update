import { normalizeRawEvents } from "../contracts/raw-event.js";
import { createPreviewTask } from "../contracts/preview-task.js";
import { classifyChangeDayMarkerEvent, normalizeSendDate } from "../date/date-rules.js";
import { normalizeMessageText } from "./message-text.js";
import { detectRoleHeader, isLikelyTimedBodySpeaker, isNonSendableRemark, parseExplicitTimedRoleHeaderLine } from "./role-header.js";
import { sourceOccurrenceIdsFrom } from "../feishu-api/source-identity.js";

export function parseFixedFormatTasks(rawEvents, options = {}) {
  const diagnostics = [];
  const expandedEvents = expandMultiRoleLineEvents(normalizeRawEvents(rawEvents), diagnostics);
  const events = dropFloatingVideoPlayerEvents(expandedEvents, diagnostics);
  const tasks = [];
  const interactionGroups = new Map();
  const useSendDateContext = Boolean(options.baseSendDate || options.date);
  const baseSendDate = normalizeSendDate(options.baseSendDate || options.date || "");
  let currentSendDate = baseSendDate;
  let nextInteractionGroup = 1;
  let currentDaySegment = 1;
  let currentSourceDayHeadingSegment = 0;
  let currentSourceDayHeadingLabel = "";
  let current = null;
  let lastMediaEvent = null;
  let order = 1;
  let inlineBodyCount = 0;

  for (let eventIndex = 0; eventIndex < events.length; eventIndex += 1) {
    const event = events[eventIndex];
    if (useSendDateContext && current && isCollectedDateHeadingResidue(event, baseSendDate, events, eventIndex)) {
      diagnostics.push({
        code: "dropped_collected_date_heading_residue",
        sourceId: event.sourceId,
        message: "已忽略飞书虚拟滚动夹在正文里的日期标题残影"
      });
      continue;
    }
    const dayMarker = useSendDateContext ? classifyChangeDayMarkerEvent(event, baseSendDate) : null;
    if (dayMarker?.isHeading) {
      flushSegment(current, tasks, () => order++);
      current = null;
      lastMediaEvent = null;
      currentSourceDayHeadingSegment += 1;
      currentSourceDayHeadingLabel = sourceDayHeadingLabel(event);
      if (dayMarker.date) {
        currentSendDate = dayMarker.date;
        currentDaySegment += 1;
        interactionGroups.clear();
        diagnostics.push({
          code: "change_day_marker",
          sourceId: event.sourceId,
          date: dayMarker.date,
          message: `换天标题切换后续发单日期：${dayMarker.date}`
        });
      } else {
        diagnostics.push({
          code: dayMarker.ignoredReason || "ignored_day_marker",
          sourceId: event.sourceId,
          date: dayMarker.ignoredDate || "",
          message: `换天标题日期已过期，继续使用当前发单日期：${currentSendDate}`
        });
      }
      continue;
    }

    const header = detectRoleHeader(event, roleDetectionOptions(options, current));
    if (header) {
      if (String(header.inlineBodyText || "").trim()) inlineBodyCount += 1;
      if (isSameSegmentHeader(current, header, {
        sendDate: useSendDateContext ? currentSendDate : "",
        daySegment: currentDaySegment,
        event
      })) {
        appendHeaderContent(current, header, event);
        continue;
      }
      flushSegment(current, tasks, () => order++);
      lastMediaEvent = null;
      current = startSegment(header, event, {
        interactionGroups,
        sendDate: useSendDateContext ? currentSendDate : "",
        daySegment: currentDaySegment,
        sourceDayHeadingSegment: currentSourceDayHeadingSegment,
        sourceDayHeadingLabel: currentSourceDayHeadingLabel,
        nextInteractionGroupRef: {
          get value() {
            return nextInteractionGroup;
          },
          set value(next) {
            nextInteractionGroup = next;
          }
        }
      });
      appendHeaderContent(current, header, event);
      if (!header.time && (options.scheduleMode || "doc") === "doc") {
        diagnostics.push({
          code: "missing_document_time",
          sourceId: event.sourceId,
          message: `角色行没有时间：${event.text}`
        });
      }
      continue;
    }

    if (!current && isPreviewMediaEvent(event)) {
      current = startSegmentFromCollectedMediaContext(event, null, {
        interactionGroups,
        sendDate: useSendDateContext ? currentSendDate : "",
        daySegment: currentDaySegment,
        sourceDayHeadingSegment: currentSourceDayHeadingSegment,
        sourceDayHeadingLabel: currentSourceDayHeadingLabel,
        nextInteractionGroupRef: {
          get value() {
            return nextInteractionGroup;
          },
          set value(next) {
            nextInteractionGroup = next;
          }
        }
      });
      if (current) {
        diagnostics.push({
          code: "recovered_leading_media_context",
          sourceId: event.sourceId,
          message: `范围开头素材已使用采集到的说话人和时间恢复：${event.collectSpeaker || ""} ${event.collectTime || ""}`
        });
      }
    }
    if (!current) continue;
    if (event.kind === "divider") {
      flushSegment(current, tasks, () => order++);
      lastMediaEvent = null;
      continue;
    }
    if (event.kind === "line") {
      if (applyStandaloneStickerLabel(current, event, events[eventIndex - 1], tasks.at(-1))) {
        diagnostics.push({
          code: "sticker_type_annotation",
          sourceId: event.sourceId,
          mediaSourceId: tasks.at(-1).sourceId,
          message: "图片后的独立“表情包”用于标注素材类型，不单独发送"
        });
        continue;
      }
      if (current.finderBuffer?.length) {
        const copiedFinderXml = copiedFinderXmlFromEvent(event);
        if (copiedFinderXml) {
          replaceFinderText(current, copiedFinderXml, event);
          continue;
        }
        const textAfterCopiedFinder = textAfterCopiedFinderCodeFragment(current, event);
        if (textAfterCopiedFinder) {
          flushFinder(current, tasks, () => order++);
          appendText(current, textAfterCopiedFinder, event);
          continue;
        }
        if (shouldSkipFinderCodeFragmentAfterCopiedXml(current, event)) continue;
        if (hasUpcomingCopiedFinderXml(event, events, eventIndex)) continue;
        if (isFinderCodeBlockFragment(event)) {
          appendFinderText(current, event.text, event);
          continue;
        }
        flushFinder(current, tasks, () => order++);
        const cleanedText = cleanBodyText(event.text);
        if (cleanedText.trim() && !isNonSendableRemark(cleanedText, { insideRoleSegment: true })) appendText(current, cleanedText, event);
        continue;
      }
      const cleanedText = cleanBodyText(event.text);
      const rawText = String(event.text || "");
      if (isFinderCodeBlockChromeResidue(event, events, eventIndex)) {
        diagnostics.push({
          code: "dropped_finder_code_block_chrome",
          sourceId: event.sourceId,
          message: "已忽略飞书代码块外壳文字，避免示例代码/复制按钮进入正文"
        });
        continue;
      }
      const finderXml = extractFinderXml(rawText) || extractFinderXml(cleanedText);
      if (finderXml) {
        flushText(current, tasks, () => order++);
        appendFinderText(current, finderXml, event);
        continue;
      }
      if (isFinderXmlStart(cleanedText || rawText)) {
        flushText(current, tasks, () => order++);
        appendFinderText(current, event.text, event);
        continue;
      }
      if (cleanedText.trim() && isNonSendableRemark(cleanedText, { insideRoleSegment: true })) continue;
      if (!cleanedText.trim() && String(event.text || "").trim()) continue;
      appendText(current, cleanedText, event);
      continue;
    }
    if (event.kind === "image" || event.kind === "sticker" || event.kind === "video" || event.kind === "unknown-media") {
      if (isFeishuStickerImageEcho(event, events[eventIndex - 1], events[eventIndex + 1])) {
        diagnostics.push({
          code: "dropped_sticker_image_echo",
          sourceId: event.sourceId,
          message: "已忽略飞书同一素材同时暴露出的图片副本，保留表情包"
        });
        continue;
      }
      if (isFeishuVideoCoverEcho(event, lastMediaEvent || events[eventIndex - 1], events[eventIndex + 1])) {
        diagnostics.push({
          code: "dropped_video_cover_echo",
          sourceId: event.sourceId,
          message: "已忽略飞书同一视频同时暴露出的封面副本，保留真实视频"
        });
        continue;
      }
      if (isDuplicateSameMessageMediaEcho(event, lastMediaEvent)) {
        diagnostics.push({
          code: "dropped_duplicate_media_echo",
          sourceId: event.sourceId,
          message: "已忽略飞书同一消息重复暴露出的媒体副本"
        });
        continue;
      }
      let mediaSegment = current;
      if (shouldUseCollectedMediaContext(current, event)) {
        flushSegment(current, tasks, () => order++);
        mediaSegment = startSegmentFromCollectedMediaContext(event, current, {
          interactionGroups,
          sendDate: useSendDateContext ? currentSendDate : "",
          daySegment: currentDaySegment,
          sourceDayHeadingSegment: currentSourceDayHeadingSegment,
          sourceDayHeadingLabel: currentSourceDayHeadingLabel,
          nextInteractionGroupRef: {
            get value() {
              return nextInteractionGroup;
            },
            set value(next) {
              nextInteractionGroup = next;
            }
          }
        });
        current = mediaSegment;
        diagnostics.push({
          code: "media_collect_context_shift",
          sourceId: event.sourceId,
          message: `媒体使用自身采集上下文：${event.collectSpeaker || ""} ${event.collectTime || ""}`
        });
      }
      flushSegment(current, tasks, () => order++);
      tasks.push(makeMediaTask(mediaSegment, event, order++));
      mediaSegment.mediaCount = Number(mediaSegment.mediaCount || 0) + 1;
      lastMediaEvent = event;
    }
  }

  flushSegment(current, tasks, () => order++);
  const withoutVideoCovers = dropVideoCoverEchoTasks(tasks, diagnostics);
  const visuallyOrdered = restoreVisualTaskOrder(withoutVideoCovers, diagnostics);
  const merged = mergeCollectedTextFragmentsSeparatedByMedia(visuallyOrdered, diagnostics);
  const withoutPrefixEchoes = trimDuplicateTextPrefixEchoes(merged, diagnostics);
  const withoutSuffixEchoes = trimDuplicateTextSuffixEchoes(withoutPrefixEchoes, diagnostics);
  const withMergedSupersetText = mergeCollectedSupersetTextFragments(withoutSuffixEchoes, diagnostics);
  const withoutContainedTextFragments = dropContainedCollectedTextFragments(withMergedSupersetText, diagnostics);
  const withoutInternalRepeatedLines = trimInternalRepeatedTextLines(withoutContainedTextFragments, diagnostics);
  const withoutTextEchoes = dropDuplicateTextEchoTasks(withoutInternalRepeatedLines, diagnostics);
  const withoutCrossSpeakerMediaEchoes = dropCrossSpeakerTextEchoBeforeMedia(withoutTextEchoes, diagnostics);
  const withRestoredRepeatedText = restoreMissingRepeatedTextBetweenSameMedia(withoutCrossSpeakerMediaEchoes, diagnostics);
  const withRestoredTailText = restoreTruncatedRepeatedTextTailFragments(withRestoredRepeatedText, diagnostics);
  const withRestoredTailOrder = moveRestoredTailTextBeforeNearbyMedia(withRestoredTailText, diagnostics);
  const withRestoredAfterLeadingMedia = restoreMissingRepeatedTextAfterSameLeadingMedia(withRestoredTailOrder, diagnostics);
  const withRestoredHistoricalInviteText = restoreMissingHistoricalInviteTextAfterLeadingMedia(withRestoredAfterLeadingMedia, diagnostics);
  const withoutDuplicateRestoredText = dropDuplicateRestoredTextAtSameTime(withRestoredHistoricalInviteText, diagnostics);
  const withRestoredMediaAfterText = restoreMissingRepeatedMediaAfterExistingText(withoutDuplicateRestoredText, diagnostics);
  const withRestoredOutroText = restoreMissingRepeatedOutroAfterMedia(withRestoredMediaAfterText, diagnostics);
  const withRestoredShortMention = restoreMissingShortMentionAfterMedia(withRestoredOutroText, diagnostics);
  const withoutMisplacedOutro = dropMisplacedOutroAtMediaTime(withRestoredShortMention, diagnostics);
  const withoutDirtyOutroText = dropDirtyTextSupersededByOutroAtSameTime(withoutMisplacedOutro, diagnostics);
  const withoutDecorativeNicknameResidue = dropDecorativeNicknameResidueText(withoutDirtyOutroText, diagnostics);
  const withCleanMentionText = trimDirtyShortMentionEchoes(withoutDecorativeNicknameResidue, diagnostics);
  const withoutFinderResidue = dropTextResidueSupersededByCopiedFinder(withCleanMentionText, diagnostics);
  const withoutSupersededInvalidFinder = dropInvalidFinderPlaceholdersSupersededByCopiedXml(withoutFinderResidue, diagnostics);
  const withPreviewAccuracyWarnings = markPreviewAccuracyWarnings(withoutSupersededInvalidFinder);
  const finalTasks = stripInternalTaskHints(withPreviewAccuracyWarnings);
  assertInlineBodyCompleteness(inlineBodyCount, finalTasks);
  assertImportedEventCompleteness(events, finalTasks, diagnostics);
  if (inlineBodyCount > 0) {
    diagnostics.push({
      code: "recovered_inline_role_bodies",
      count: inlineBodyCount,
      message: `已从角色时间头同块内容中保留 ${inlineBodyCount} 段正文`
    });
  }
  return { tasks: finalTasks, diagnostics, sourceEvents: events };
}

export function expandMultiRoleLineEvents(events = [], diagnostics = []) {
  const expanded = [];
  for (const event of Array.isArray(events) ? events : []) {
    if (event?.kind !== "line") {
      expanded.push(event);
      continue;
    }
    const text = String(event.text || "").replace(/\r\n?/g, "\n");
    const lines = text.split("\n");
    const firstContentIndex = lines.findIndex((line) => line.trim());
    const headers = lines.map((line, lineIndex) => ({
      lineIndex,
      header: strictLogicalRoleHeader(line, event)
    })).filter((item) => item.header);
    const needsSplit = headers.length > 1 || (headers.length === 1 && firstContentIndex >= 0 && headers[0].lineIndex > firstContentIndex);
    if (!needsSplit) {
      expanded.push(event);
      continue;
    }

    const parts = [];
    if (firstContentIndex >= 0 && headers[0].lineIndex > firstContentIndex) {
      parts.push({
        start: firstContentIndex,
        end: headers[0].lineIndex,
        header: null
      });
    }
    for (const [index, item] of headers.entries()) {
      parts.push({
        start: item.lineIndex,
        end: headers[index + 1]?.lineIndex ?? lines.length,
        header: item.header
      });
    }

    const logicalEvents = parts.map((part, index) => logicalLineEvent(event, lines, part, index, parts.length));
    expanded.push(...logicalEvents);
    diagnostics.push({
      code: "split_multi_role_source_block",
      sourceId: String(event.sourceId || ""),
      count: logicalEvents.length,
      logicalSourceIds: logicalEvents.map((item) => item.sourceId),
      message: `一个原文块包含多位说话人，已按 ${logicalEvents.length} 个原文位置拆分`
    });
  }
  return expanded;
}

function strictLogicalRoleHeader(line, event) {
  const text = String(line || "").trim();
  if (!text) return null;
  const parsed = parseExplicitTimedRoleHeaderLine(text);
  if (!parsed || isLikelyTimedBodySpeaker(parsed.speaker)) return null;
  const detected = detectRoleHeader({
    ...event,
    kind: "line",
    type: "line",
    text,
    sourceText: text,
    highlighted: false
  }, {
    allowBareNameHeaders: false,
    allowHighlightedDouma: false,
    allowHighlightedSellerHeader: false
  });
  return detected?.explicit ? detected : null;
}

function logicalLineEvent(event, lines, part, index, count) {
  const logicalNumber = index + 1;
  const text = trimLogicalPart(lines.slice(part.start, part.end).join("\n"));
  const baseRefs = sourceOccurrenceIdsFrom(event);
  const sourceOccurrenceIds = baseRefs.map((ref) => `${ref}#logical-${logicalNumber}`);
  const orderOffset = count > 1 ? logicalNumber / (count + 1) / 1000 : 0;
  return {
    ...event,
    sourceId: `${String(event.sourceId || "event")}#logical-${logicalNumber}`,
    sourceOccurrenceId: sourceOccurrenceIds[0] || "",
    sourceOccurrenceIds,
    sourceSegmentIds: [],
    text,
    sourceText: text,
    highlighted: Boolean(part.header?.speaker?.includes("豆妈")),
    collectSpeaker: part.header?.speaker || "",
    collectTime: part.header?.time || "",
    order: Number(event.order || 0) + orderOffset,
    y: Number(event.y || 0) + orderOffset,
    raw: {
      ...event.raw,
      parentSourceId: String(event.sourceId || ""),
      logicalPart: logicalNumber,
      logicalPartCount: count
    }
  };
}

function trimLogicalPart(value) {
  return String(value || "").replace(/^\n+|\n+$/g, "");
}

export function assertInlineBodyCompleteness(inlineBodyCount, tasks) {
  const expected = Number(inlineBodyCount || 0);
  if (expected <= 0 || (Array.isArray(tasks) && tasks.some((task) => task?.type === "text"))) return;
  const error = new Error(`检测到 ${expected} 段明确正文，但未生成文字任务，已停止生成预览。`);
  error.code = "explicit_inline_body_missing";
  throw error;
}

export function assertImportedEventCompleteness(events, tasks, diagnostics = []) {
  const pastedEvents = (Array.isArray(events) ? events : [])
    .filter((event) => event?.raw?.importSource === "rich-text-clipboard");
  if (!pastedEvents.length) return;

  const accounted = new Set();
  for (const task of Array.isArray(tasks) ? tasks : []) addSourceIds(accounted, task?.sourceId);
  for (const diagnostic of Array.isArray(diagnostics) ? diagnostics : []) addSourceIds(accounted, diagnostic?.sourceId);

  const missing = [];
  for (const event of pastedEvents) {
    if (accounted.has(event.sourceId)) continue;
    if (event.kind === "divider" || event.kind === "title") continue;
    if (event.kind === "line") {
      const text = String(event.text || "");
      if (!text.trim()) continue;
      if (parseExplicitImportedHeader(text) || isNonSendableRemark(text)) continue;
    }
    missing.push(event);
  }
  if (!missing.length) return;

  const details = missing.slice(0, 4).map((event) => {
    const summary = String(event.text || event.sourceText || event.kind || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 36);
    return `${event.sourceId}${summary ? `（${summary}）` : ""}`;
  });
  const error = new Error(`富文本粘贴有 ${missing.length} 段内容未能归属到预览任务：${details.join("、")}。请核对角色时间头或在预览中补全后再继续。`);
  error.code = "pasted_content_unaccounted";
  error.sourceIds = missing.map((event) => event.sourceId);
  throw error;
}

function addSourceIds(target, value) {
  String(value || "").split(",").map((item) => item.trim()).filter(Boolean).forEach((item) => target.add(item));
}

function uniqueStrings(values = []) {
  return [...new Set((Array.isArray(values) ? values : [])
    .map((value) => String(value || "").trim())
    .filter(Boolean))];
}

function parseExplicitImportedHeader(text) {
  const firstLine = String(text || "").replace(/\r\n?/g, "\n").split("\n")[0];
  const parsed = parseExplicitTimedRoleHeaderLine(firstLine);
  return parsed && !isLikelyTimedBodySpeaker(parsed.speaker) ? parsed : null;
}

function sourceDayHeadingLabel(event) {
  return String(event?.text || event?.sourceText || "").replace(/\s+/g, " ").trim();
}

function roleDetectionOptions(options, current) {
  if (!current) return options;
  return {
    ...options,
    allowBareNameHeaders: options.allowBareNameHeadersInsideSegment === true,
    allowHighlightedDouma: false,
    currentRole: current.role || ""
  };
}

function startSegment(header, event, refs) {
  const interactionKey = header.role === "tuo" ? normalizeInteractionKey(header.speaker) : "";
  let interactionGroup = "";
  if (interactionKey) {
    if (header.continueSpeaker && !refs.interactionGroups.has(interactionKey)) {
      refs.interactionGroups.set(interactionKey, `interaction-${refs.nextInteractionGroupRef.value}`);
      refs.nextInteractionGroupRef.value += 1;
    }
    interactionGroup = refs.interactionGroups.get(interactionKey) || "";
  }

  return {
    sourceId: event.sourceId,
    headerSourceId: event.sourceId,
    sourceText: header.sourceText,
    role: header.role,
    speaker: header.speaker,
    sourceSpeaker: header.speaker,
    speakerStatus: "confirmed",
    date: refs.sendDate || header.date,
    documentDate: header.date,
    documentTime: header.time,
    daySegment: refs.daySegment || 1,
    sourceDayHeadingSegment: Number(refs.sourceDayHeadingSegment || 0),
    sourceDayHeadingLabel: String(refs.sourceDayHeadingLabel || ""),
    time: header.time,
    interactionGroup,
    continueMarker: Boolean(header.continueSpeaker),
    cleanSpeaker: header.cleanSpeaker || header.speaker,
    speakerConfidence: header.speakerConfidence || "",
    personaHint: header.personaHint || "",
    headerVisualTop: eventVisualTop(event),
    headerEventOrder: eventOrder(event),
    textBuffer: [],
    textSourceIds: [],
    textSourceOccurrenceIds: [],
    textSourceText: [],
    textVisualTop: null,
    textEventOrder: null,
    finderBuffer: [],
    finderSourceIds: [],
    finderSourceOccurrenceIds: [],
    finderSourceText: [],
    finderVisualTop: null,
    finderEventOrder: null,
    mediaCount: 0
  };
}

function startSegmentFromCollectedMediaContext(event, current, refs) {
  const speaker = String(event?.collectSpeaker || "").trim();
  const time = String(event?.collectTime || "").trim();
  const documentDate = String(event?.collectDate || current?.documentDate || "").trim();
  const headerText = [speaker, documentDate, time].filter(Boolean).join(" ");
  const header = detectRoleHeader({
    ...event,
    kind: "line",
    text: headerText,
    sourceText: headerText,
    highlighted: Boolean(event?.highlighted) || /豆妈/.test(speaker)
  });
  if (!header) return current;
  return startSegment(header, {
    ...event,
    text: headerText,
    sourceText: event.sourceText || event.text || headerText
  }, refs);
}

function shouldUseCollectedMediaContext(current, event) {
  if (!current || !event) return false;
  const speaker = String(event.collectSpeaker || "").trim();
  const time = String(event.collectTime || "").trim();
  if (!speaker || !time) return false;
  if (isFirstContentAfterExplicitHeader(current)) return false;
  const currentSpeaker = String(current.speaker || "").trim();
  const currentTime = String(current.time || "").trim();
  return normalizeInteractionKey(speaker) !== normalizeInteractionKey(currentSpeaker) || normalizeClock(time) !== normalizeClock(currentTime);
}

function isPreviewMediaEvent(event) {
  return ["image", "sticker", "video", "unknown-media"].includes(String(event?.kind || ""));
}

function isFirstContentAfterExplicitHeader(segment) {
  if (!segment) return false;
  if (Number(segment.mediaCount || 0) > 0) return false;
  return !segmentHasMeaningfulPendingContent(segment);
}

function segmentHasMeaningfulPendingContent(segment) {
  return [...(segment.textBuffer || []), ...(segment.finderBuffer || [])]
    .some((line) => String(line || "").trim());
}

function isSameSegmentHeader(current, header, refs) {
  if (!current || !header) return false;
  if (current.role !== header.role) return false;
  if (normalizeInteractionKey(current.speaker) !== normalizeInteractionKey(header.speaker)) return false;
  const nextDate = refs.sendDate || header.date;
  if (String(current.date || "") !== String(nextDate || "")) return false;
  if (String(current.documentDate || "") !== String(header.date || "")) return false;
  if (String(current.time || "") !== String(header.time || "")) return false;
  if (Number(current.daySegment || 1) !== Number(refs.daySegment || 1)) return false;
  return sameHeaderSource(current, refs.event);
}

function sameHeaderSource(current, event) {
  const currentId = String(current?.headerSourceId || current?.sourceId || "");
  const nextId = String(event?.sourceId || "");
  return Boolean(currentId && nextId && currentId === nextId && !currentId.startsWith("dom-block-"));
}

function appendText(segment, text, event, options = {}) {
  if (!segment) return;
  const preserveStructure = options.preserveStructure === true;
  const line = preserveStructure ? preserveInlineBodyText(text) : cleanBodyText(text);
  segment.textBuffer.push(line);
  segment.textSourceIds.push(event.sourceId);
  segment.textSourceOccurrenceIds.push(...sourceOccurrenceIdsFrom(event));
  segment.textSourceText.push(event.sourceText || event.text || "");
  if (line.trim()) rememberSegmentVisualSource(segment, event, "text");
  if (preserveStructure) segment.preserveTextBlankLines = true;
}

function appendHeaderContent(segment, header, event) {
  if (!segment || !header) return;
  if (Object.hasOwn(header, "inlineBodyText")) {
    if (String(header.inlineBodyText || "").trim()) {
      appendText(segment, header.inlineBodyText, event, { preserveStructure: true });
    }
    return;
  }
  if (header.useLineAsContent) appendText(segment, event.text, event);
}

function appendFinderText(segment, text, event) {
  if (!segment) return;
  segment.finderBuffer.push(String(text || "").replace(/\r\n?/g, "\n"));
  segment.finderSourceIds.push(event.sourceId);
  segment.finderSourceOccurrenceIds.push(...sourceOccurrenceIdsFrom(event));
  segment.finderSourceText.push(event.sourceText || event.text || "");
  if (String(text || "").trim()) rememberSegmentVisualSource(segment, event, "finder");
}

function replaceFinderText(segment, text, event) {
  if (!segment) return;
  segment.finderBuffer = [String(text || "").replace(/\r\n?/g, "\n")];
  segment.finderSourceIds = [event.sourceId];
  segment.finderSourceOccurrenceIds = sourceOccurrenceIdsFrom(event);
  segment.finderSourceText = [event.sourceText || event.text || ""];
  segment.finderVisualTop = null;
  segment.finderEventOrder = null;
  if (String(text || "").trim()) rememberSegmentVisualSource(segment, event, "finder");
}

function shouldSkipFinderCodeFragmentAfterCopiedXml(segment, event) {
  if (!segment?.finderBuffer?.length) return false;
  if (!segment.finderSourceIds.some((sourceId) => String(sourceId || "").startsWith("feishu-copied-finder-"))) return false;
  const currentXml = trimOuterBlankLines(segment.finderBuffer.join("\n"));
  if (!isCompleteFinderXml(currentXml)) return false;
  const sourceId = String(event?.sourceId || "");
  const text = String(event?.text || event?.sourceText || "").trim();
  if (isFinderCopiedXmlTrailingNoise(text)) return true;
  if (sourceId.startsWith("dom-block-")) return !text || isCodeBlockChromeText(text) || looksLikeXmlCodeLine(text) || looksLikeFinderXml(text);
  return isCodeBlockChromeText(text) || looksLikeXmlCodeLine(text);
}

function textAfterCopiedFinderCodeFragment(segment, event) {
  if (!segment?.finderSourceIds?.some((sourceId) => String(sourceId || "").startsWith("feishu-copied-finder-"))) return "";
  const currentXml = trimOuterBlankLines(segment.finderBuffer.join("\n"));
  if (!isCompleteFinderXml(currentXml)) return "";
  const sourceId = String(event?.sourceId || "");
  if (!sourceId.startsWith("dom-block-") && !sourceId.startsWith("feishu-block-")) return "";
  const text = String(event?.text || event?.sourceText || "");
  if (!looksLikeXmlCodeLine(text) && !looksLikeFinderXml(text)) return "";
  const cleaned = cleanBodyText(text);
  return cleaned.trim() ? cleaned : "";
}

function copiedFinderXmlFromEvent(event) {
  if (!String(event?.sourceId || "").startsWith("feishu-copied-finder-")) return "";
  return extractFinderXml(event?.text || event?.sourceText || "");
}

function isFinderCodeBlockChromeResidue(event, events, eventIndex) {
  if (!event || event.kind !== "line") return false;
  const text = String(event.text || event.sourceText || "");
  if (!isCodeBlockChromeText(text)) return false;
  const sourceId = String(event.sourceId || "");
  if (!/^(?:dom|feishu)-/.test(sourceId)) return false;
  const speaker = String(event.collectSpeaker || "").trim();
  const time = String(event.collectTime || "").trim();
  for (let index = eventIndex + 1; index < Math.min(events.length, eventIndex + 12); index += 1) {
    const next = events[index];
    if (!next || next.kind !== "line") continue;
    if (speaker && String(next.collectSpeaker || "").trim() !== speaker) continue;
    if (time && String(next.collectTime || "").trim() !== time) continue;
    if (copiedFinderXmlFromEvent(next)) return true;
    const nextText = String(next.text || next.sourceText || "");
    if (isFinderXmlStart(nextText) || looksLikeFinderXml(nextText)) return true;
  }
  return false;
}

function isFinderCodeBlockFragment(event) {
  const text = String(event?.text || event?.sourceText || "");
  if (!text.trim()) return true;
  if (isCodeBlockChromeText(text)) return true;
  if (isFinderXmlStart(text) || looksLikeFinderXml(text) || looksLikeXmlCodeLine(text)) return true;
  return false;
}

function hasUpcomingCopiedFinderXml(event, events, eventIndex) {
  const speaker = String(event?.collectSpeaker || "").trim();
  const time = String(event?.collectTime || "").trim();
  for (let index = eventIndex + 1; index < Math.min(events.length, eventIndex + 10); index += 1) {
    const next = events[index];
    if (!next || next.kind !== "line") continue;
    if (speaker && String(next.collectSpeaker || "").trim() !== speaker) continue;
    if (time && String(next.collectTime || "").trim() !== time) continue;
    if (copiedFinderXmlFromEvent(next)) return true;
  }
  return false;
}

function flushSegment(segment, tasks, nextOrder) {
  flushText(segment, tasks, nextOrder);
  flushFinder(segment, tasks, nextOrder);
}

function flushText(segment, tasks, nextOrder) {
  if (!segment || !segment.textBuffer.length) return;
  const text = segment.preserveTextBlankLines
    ? preserveInlineBodyText(segment.textBuffer.join("\n"))
    : normalizeMessageText(segment.textBuffer.join("\n"));
  segment.textBuffer = [];
  segment.preserveTextBlankLines = false;
  const sourceIds = segment.textSourceIds.splice(0);
  const sourceOccurrenceIds = uniqueStrings(segment.textSourceOccurrenceIds.splice(0));
  const sourceText = segment.textSourceText.splice(0).join("\n");
  if (!text) return;
  tasks.push(createPreviewTask({
    sourceId: sourceIds.join(",") || segment.sourceId,
    sourceOccurrenceIds,
    sourceText: sourceText || segment.sourceText,
    role: segment.role,
    speaker: segment.speaker,
    sourceSpeaker: segment.sourceSpeaker || segment.speaker,
    speakerStatus: segment.speakerStatus || "confirmed",
    date: segment.date,
    documentDate: segment.documentDate,
    documentTime: segment.documentTime,
    daySegment: segment.daySegment,
    sourceDayHeadingSegment: segment.sourceDayHeadingSegment,
    sourceDayHeadingLabel: segment.sourceDayHeadingLabel,
    time: segment.time,
    type: "text",
    text,
    mediaPath: "",
    skip: false,
    order: nextOrder(),
    interactionGroup: segment.interactionGroup,
    continueMarker: segment.continueMarker,
    cleanSpeaker: segment.cleanSpeaker,
    speakerConfidence: segment.speakerConfidence,
    personaHint: segment.personaHint,
    _visualTop: segment.textVisualTop ?? segment.headerVisualTop ?? null,
    _eventOrder: segment.textEventOrder ?? segment.headerEventOrder ?? null
  }));
  segment.textVisualTop = null;
  segment.textEventOrder = null;
}

function flushFinder(segment, tasks, nextOrder) {
  if (!segment || !segment.finderBuffer.length) return;
  const text = trimOuterBlankLines(segment.finderBuffer.join("\n"));
  segment.finderBuffer = [];
  const sourceIds = segment.finderSourceIds.splice(0);
  const sourceOccurrenceIds = uniqueStrings(segment.finderSourceOccurrenceIds.splice(0));
  const sourceText = segment.finderSourceText.splice(0).join("\n");
  if (!text) return;
  const complete = isCompleteFinderXml(text);
  tasks.push(createPreviewTask({
    sourceId: sourceIds.join(",") || segment.sourceId,
    sourceOccurrenceIds,
    sourceText: sourceText || segment.sourceText,
    role: segment.role,
    speaker: segment.speaker,
    sourceSpeaker: segment.sourceSpeaker || segment.speaker,
    speakerStatus: segment.speakerStatus || "confirmed",
    date: segment.date,
    documentDate: segment.documentDate,
    documentTime: segment.documentTime,
    daySegment: segment.daySegment,
    sourceDayHeadingSegment: segment.sourceDayHeadingSegment,
    sourceDayHeadingLabel: segment.sourceDayHeadingLabel,
    time: segment.time,
    type: "finder",
    text,
    mediaPath: "",
    skip: false,
    order: nextOrder(),
    interactionGroup: segment.interactionGroup,
    continueMarker: segment.continueMarker,
    cleanSpeaker: segment.cleanSpeaker,
    speakerConfidence: segment.speakerConfidence,
    personaHint: segment.personaHint,
    ...(complete ? {} : {
      previewError: "finder_xml_incomplete",
      invalidReason: "视频号代码块未能完整复制，请手动补录这一条完整视频号参数。"
    }),
    _visualTop: segment.finderVisualTop ?? segment.headerVisualTop ?? null,
    _eventOrder: segment.finderEventOrder ?? segment.headerEventOrder ?? null
  }));
  segment.finderVisualTop = null;
  segment.finderEventOrder = null;
}

function rememberSegmentVisualSource(segment, event, prefix) {
  const top = eventVisualTop(event);
  const order = eventOrder(event);
  const topKey = `${prefix}VisualTop`;
  const orderKey = `${prefix}EventOrder`;
  if (Number.isFinite(top) && !Number.isFinite(segment[topKey])) segment[topKey] = top;
  if (Number.isFinite(order) && !Number.isFinite(segment[orderKey])) segment[orderKey] = order;
}

function dropVideoCoverEchoTasks(tasks, diagnostics) {
  return tasks.filter((task, index) => {
    if (task.type !== "video" || !looksLikeVideoCoverMedia(task)) return true;
    const adjacent = [tasks[index - 1], tasks[index + 1]]
      .find((item) => item?.type === "video" && hasRealVideoMediaSource(item) && samePreviewTaskContext(task, item));
    if (!adjacent) return true;
    diagnostics.push({
      code: "dropped_video_cover_echo",
      sourceId: task.sourceId,
      message: "已忽略飞书同一视频同时暴露出的封面副本，保留真实视频"
    });
    return false;
  });
}

function restoreVisualTaskOrder(tasks, diagnostics) {
  const ordered = [];
  let changed = false;
  const movedSourceIds = [];
  for (const task of tasks) {
    let insertIndex = ordered.length;
    const top = taskVisualTop(task);
    if (isMediaTask(task) && Number.isFinite(top)) {
      const candidateIndex = ordered.findIndex((item) => {
        if (!sameVisualOrderingScope(task, item.task)) return false;
        const itemTop = taskVisualTop(item.task);
        return Number.isFinite(itemTop) && itemTop - top > 2;
      });
      if (candidateIndex >= 0) insertIndex = candidateIndex;
    }
    if (insertIndex !== ordered.length) {
      changed = true;
      if (task.sourceId) movedSourceIds.push(task.sourceId);
    }
    ordered.splice(insertIndex, 0, { task, index: ordered.length });
  }
  if (!changed) return tasks;
  diagnostics.push({
    code: "restored_visual_task_order",
    sourceId: movedSourceIds.join(","),
    message: "已按飞书页面视觉位置恢复预览顺序，避免延迟采集的素材插到文字后面"
  });
  return ordered.map((item, index) => createPreviewTask({ ...item.task, order: index + 1 }));
}

function sameVisualOrderingScope(left, right) {
  return Number(left?.daySegment || 1) === Number(right?.daySegment || 1) &&
    String(left?.date || "") === String(right?.date || "");
}

function taskVisualTop(task) {
  return finiteTaskNumber(task?._visualTop);
}

function finiteTaskNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function stripInternalTaskHints(tasks) {
  return tasks.map((task, index) => {
    const { _visualTop, _eventOrder, ...publicTask } = task;
    return createPreviewTask({ ...publicTask, order: index + 1 });
  });
}

function markPreviewAccuracyWarnings(tasks) {
  return tasks.map((task, index) => {
    const warnings = [];
    if (String(task?.sourceId || "").startsWith("restored-")) {
      warnings.push("这条是系统根据飞书重复节奏自动补回的内容，请重点核对原文是否一致。");
    }
    warnings.push(...detectLowConfidencePreviewWarnings(task, tasks, index));
    const previewWarning = mergePreviewWarnings(task?.previewWarning, warnings);
    if (!previewWarning || previewWarning === task?.previewWarning) return task;
    return createPreviewTask({ ...task, previewWarning });
  });
}

function detectLowConfidencePreviewWarnings(task, tasks, index) {
  const warnings = [];
  if (!task) return warnings;
  if (isTextTask(task)) {
    if (hasFinderResidueInTextTask(task)) {
      warnings.push("这条正文的原始来源里含视频号/代码块痕迹，系统已尽量解析，请核对是否应为视频号或正文。");
    }
    if (hasFragmentedCollectedTextSource(task)) {
      warnings.push("这条由多个飞书采集块拼成，可能存在拆行、漏行或串行，请核对原文。");
    }
    if (hasSuspiciousSourceTextMismatch(task)) {
      warnings.push("这条原始采集内容和预览正文差异较大，系统已自动清理/合并，请核对是否漏字或串人。");
    }
    if (hasSeparatorNearCollectedMedia(task, tasks, index)) {
      warnings.push("这条附近有分隔符和素材，飞书容易把下面内容拆开或漏掉，请核对原文连续性。");
    }
  }
  if (isMediaTask(task) && hasCollectedSameMessageTextNeighbor(task, tasks, index)) {
    warnings.push("这条素材与同时间正文相邻，飞书可能拆开同一条消息，请核对顺序和归属。");
  }
  return warnings;
}

function mergePreviewWarnings(existing, warnings) {
  const parts = [
    ...String(existing || "").split(/；|\n/),
    ...(Array.isArray(warnings) ? warnings : [])
  ]
    .map((warning) => String(warning || "").trim())
    .filter(Boolean);
  return [...new Set(parts)].join("；");
}

function hasFinderResidueInTextTask(task) {
  if (!isTextTask(task)) return false;
  const sourceText = String(task?.sourceText || "");
  if (!sourceText.trim()) return false;
  if (looksLikeFinderXml(sourceText) || isFinderXmlStart(sourceText)) return true;
  return sourceText.split("\n").some((line) => looksLikeXmlCodeLine(line) || isCodeBlockChromeText(line));
}

function hasFragmentedCollectedTextSource(task) {
  if (!isTextTask(task) || !hasCollectedDomSource(task)) return false;
  const sourceIds = sourceIdParts(task);
  if (sourceIds.length >= 3) return true;
  const sourceText = String(task?.sourceText || "");
  return (sourceText.match(/\n\s*\n/g) || []).length >= 3;
}

function hasSuspiciousSourceTextMismatch(task) {
  if (!isTextTask(task) || !hasCollectedDomSource(task)) return false;
  const sourceComparable = comparableDuplicateText(cleanBodyText(task?.sourceText || ""));
  const taskComparable = comparableDuplicateText(task?.text || "");
  if (sourceComparable.length < 30 || taskComparable.length < 8) return false;
  if (sourceComparable === taskComparable) return false;
  if (sourceComparable.includes(taskComparable) && sourceComparable.length > taskComparable.length + 40) return true;
  if (taskComparable.includes(sourceComparable) && taskComparable.length > sourceComparable.length + 40) return true;
  return false;
}

function hasSeparatorNearCollectedMedia(task, tasks, index) {
  if (!isTextTask(task) || !hasCollectedDomSource(task)) return false;
  if (!/^[\s\S]*(?:^|\n)\s*[-－—]\s*(?:\n|$)[\s\S]*$/m.test(task.text || "")) return false;
  return [tasks[index - 1], tasks[index + 1]].some((candidate) => isMediaTask(candidate) && sameTaskMessageContext(task, candidate));
}

function hasCollectedSameMessageTextNeighbor(task, tasks, index) {
  return [tasks[index - 1], tasks[index + 1]].some((candidate) => {
    if (!isTextTask(candidate) || !hasCollectedDomSource(candidate)) return false;
    if (!sameTaskMessageContext(task, candidate)) return false;
    return hasFragmentedCollectedTextSource(candidate) || hasSeparatorNearCollectedMedia(candidate, tasks, tasks.indexOf(candidate));
  });
}

function sourceIdParts(task) {
  return String(task?.sourceId || "")
    .split(",")
    .map((sourceId) => sourceId.trim())
    .filter(Boolean);
}

function dropInvalidFinderPlaceholdersSupersededByCopiedXml(tasks, diagnostics) {
  const copiedFinderKeys = new Set((Array.isArray(tasks) ? tasks : [])
    .filter((task) => task?.type === "finder" && String(task.sourceId || "").startsWith("feishu-copied-finder-") && isCompleteFinderXml(task.text))
    .map((task) => finderTaskContextKey(task))
    .filter(Boolean));
  if (!copiedFinderKeys.size) return tasks;
  return tasks.filter((task) => {
    if (task?.type !== "finder" || task.previewError !== "finder_xml_incomplete") return true;
    if (!copiedFinderKeys.has(finderTaskContextKey(task))) return true;
    diagnostics.push({
      code: "dropped_superseded_incomplete_finder_dom",
      sourceId: task.sourceId,
      message: "已忽略同一消息里被完整复制视频号覆盖的半截 DOM 代码块"
    });
    return false;
  });
}

function dropTextResidueSupersededByCopiedFinder(tasks, diagnostics) {
  const copiedFinderKeys = new Set((Array.isArray(tasks) ? tasks : [])
    .filter((task) => task?.type === "finder" && String(task.sourceId || "").startsWith("feishu-copied-finder-") && isCompleteFinderXml(task.text))
    .map((task) => finderTaskContextKey(task))
    .filter(Boolean));
  if (!copiedFinderKeys.size) return tasks;
  const dropped = [];
  const result = tasks.filter((task) => {
    if (!isTextTask(task)) return true;
    if (!hasCollectedDomSource(task)) return true;
    if (!copiedFinderKeys.has(finderTaskContextKey(task))) return true;
    if (!isFinderAdjacentTextResidue(task.text || "")) return true;
    dropped.push(task.sourceId || "");
    return false;
  });
  if (dropped.length) {
    diagnostics.push({
      code: "dropped_text_residue_superseded_by_copied_finder",
      sourceId: dropped.filter(Boolean).join(","),
      message: "已忽略同一时间视频号代码块旁边的正文残片，保留完整复制 XML"
    });
  }
  return dropped.length ? result.map((task, index) => createPreviewTask({ ...task, order: index + 1 })) : tasks;
}

function isFinderAdjacentTextResidue(text) {
  const normalized = normalizeMessageText(text || "");
  const comparable = comparableDuplicateText(normalized);
  if (comparable.length < 12 || comparable.length > 220) return false;
  if (isClosingOnlyOutroResidueText(normalized)) return true;
  const markers = [
    /进\s*V\s*I\s*P\s*大裙/i,
    /点击图片长按二维码扫码进[群裙]/,
    /扫码进[群裙]/,
    /进[群裙][:：]/,
    (value) => hasRepeatedRoseEmoji(value)
  ];
  return markers.filter((pattern) => typeof pattern === "function" ? pattern(normalized) : pattern.test(normalized)).length >= 2;
}

function finderTaskContextKey(task) {
  return [
    normalizeInteractionKey(task?.speaker || ""),
    String(task?.date || ""),
    String(task?.documentDate || ""),
    normalizeClock(task?.time || ""),
    normalizeClock(task?.documentTime || task?.time || "")
  ].join("|");
}

function dropDuplicateTextEchoTasks(tasks, diagnostics) {
  const previousTexts = [];
  const result = [];
  for (const task of tasks) {
    if (isTextTask(task)) {
      const duplicateText = comparableDuplicateText(task.text || "");
      const previous = hasCollectedDomSource(task)
        ? previousTexts.find((item) => (looksLikeDuplicateTextEcho(task) && isDirtyDuplicateTextEchoOf(task, item)) || isContainedDirtyTextEchoOf(task, item))
        : null;
      if (previous) {
        diagnostics.push({
          code: "dropped_duplicate_text_echo",
          sourceId: task.sourceId,
          previousSourceId: previous.sourceId || "",
          message: "已忽略飞书虚拟滚动重复暴露出的正文残影"
        });
        continue;
      }
      if (duplicateText) previousTexts.push(task);
    }
    result.push(task);
  }
  return result;
}

function dropCrossSpeakerTextEchoBeforeMedia(tasks, diagnostics) {
  const result = [];
  const dropped = [];
  const mediaWarnings = new Map();
  for (let index = 0; index < tasks.length; index += 1) {
    const task = tasks[index];
    const match = findCrossSpeakerTextEchoBeforeMedia(tasks, index);
    if (match) {
      dropped.push(task.sourceId || "");
      if (match.media?.sourceId) {
        mediaWarnings.set(match.media.sourceId, "已清理同时间素材前疑似上一位说话人的残影，请重点核对这条原文。");
      }
      diagnostics.push({
        code: "dropped_cross_speaker_text_echo_before_media",
        sourceId: task.sourceId,
        previousSourceId: match.previous.sourceId || "",
        mediaSourceId: match.media.sourceId || "",
        message: "已忽略飞书虚拟滚动把上一位说话人的正文挂到下一位素材前面的残影"
      });
      continue;
    }
    const warning = mediaWarnings.get(task.sourceId || "");
    result.push(warning ? createPreviewTask({ ...task, previewWarning: task.previewWarning || warning }) : task);
  }
  return dropped.length ? result.map((task, index) => createPreviewTask({ ...task, order: index + 1 })) : tasks;
}

function findCrossSpeakerTextEchoBeforeMedia(tasks, index) {
  const task = tasks[index];
  if (!isTextTask(task) || !hasCollectedDomSource(task)) return null;
  const text = comparableDuplicateText(task.text || "");
  if (text.length < 8 || text.length > 120) return null;
  const media = findSameMessageMediaAfterText(tasks, index, task);
  if (!media) return null;
  const previous = findPreviousDifferentSpeakerTextEcho(tasks, index, task, text);
  return previous ? { previous, media } : null;
}

function findSameMessageMediaAfterText(tasks, textIndex, textTask) {
  for (let index = textIndex + 1; index < Math.min(tasks.length, textIndex + 4); index += 1) {
    const candidate = tasks[index];
    if (!candidate) continue;
    if (isTextTask(candidate)) break;
    if (!isMediaTask(candidate)) continue;
    if (sameTaskMessageContext(textTask, candidate)) return candidate;
  }
  return null;
}

function findPreviousDifferentSpeakerTextEcho(tasks, textIndex, task, text) {
  for (let index = textIndex - 1; index >= Math.max(0, textIndex - 12); index -= 1) {
    const previous = tasks[index];
    if (!isTextTask(previous)) continue;
    if (Number(previous.daySegment || 1) !== Number(task.daySegment || 1)) continue;
    if (String(previous.date || "") !== String(task.date || "")) continue;
    if (normalizeInteractionKey(previous.speaker) === normalizeInteractionKey(task.speaker)) continue;
    if (String(previous.documentTime || previous.time || "") === String(task.documentTime || task.time || "")) continue;
    if (comparableDuplicateText(previous.text || "") !== text) continue;
    if (!areNearbyDocumentTimes(previous.documentTime || previous.time, task.documentTime || task.time, 15 * 60)) continue;
    return previous;
  }
  return null;
}

function sameTaskMessageContext(left, right) {
  return normalizeInteractionKey(left?.speaker) === normalizeInteractionKey(right?.speaker) &&
    String(left?.date || "") === String(right?.date || "") &&
    String(left?.documentDate || "") === String(right?.documentDate || "") &&
    normalizeClock(left?.documentTime || left?.time || "") === normalizeClock(right?.documentTime || right?.time || "") &&
    Number(left?.daySegment || 1) === Number(right?.daySegment || 1);
}

function restoreMissingRepeatedTextBetweenSameMedia(tasks, diagnostics) {
  const repeatedPatterns = collectRepeatedTextBetweenMediaPatterns(tasks);
  if (!repeatedPatterns.length) return tasks;
  const result = [];
  const movedMediaIndexes = new Set();
  let changed = false;
  for (let index = 0; index < tasks.length; index += 1) {
    if (movedMediaIndexes.has(index)) continue;
    const current = tasks[index];
    result.push(current);
    if (!isMediaTask(current)) continue;
    const pattern = repeatedPatterns.find((item) => sameRepeatedMediaEndpoint(current, item.before));
    if (!pattern) continue;
    const afterIndex = findFollowingRepeatedMedia(tasks, index, pattern);
    if (afterIndex < 0) continue;
    const next = tasks[afterIndex];
    const template = pattern.text;
    if (!template) continue;
    if (String(template.date || "") === String(current.date || "")) continue;
    if (hasTextTaskBetweenSameMedia(tasks, index, afterIndex, template)) continue;
    const restored = createPreviewTask({
      ...template,
      sourceId: `restored-missing-text:${current.sourceId}:${next.sourceId}:${template.sourceId}`,
      sourceText: template.sourceText || template.text || "",
      date: current.date,
      daySegment: current.daySegment,
      order: Number(current.order || result.length) + 0.5,
      _visualTop: midpointTaskNumber(current._visualTop, next._visualTop),
      _eventOrder: midpointTaskNumber(current._eventOrder, next._eventOrder)
    });
    result.push(restored);
    result.push(createPreviewTask({
      ...next,
      order: Number(restored.order || result.length) + 0.5
    }));
    movedMediaIndexes.add(afterIndex);
    changed = true;
    diagnostics.push({
      code: "restored_missing_repeated_text_between_media",
      sourceId: restored.sourceId,
      previousSourceId: template.sourceId || "",
      message: "已根据相同前后素材恢复飞书虚拟滚动漏采的重复正文"
    });
  }
  if (!changed) return tasks;
  return result.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

function collectRepeatedTextBetweenMediaPatterns(tasks) {
  const patterns = [];
  const seen = new Set();
  for (let index = 1; index < tasks.length - 1; index += 1) {
    const before = tasks[index - 1];
    const text = tasks[index];
    const after = tasks[index + 1];
    if (!isMediaTask(before) || !isTextTask(text) || !isMediaTask(after)) continue;
    if (!sameRepeatedTextRestoreScope(before, text) || !sameRepeatedTextRestoreScope(text, after)) continue;
    if (!isTimeBetween(text.documentTime || text.time, before.documentTime || before.time, after.documentTime || after.time)) continue;
    const key = repeatedTextBetweenMediaKey(before, after);
    if (seen.has(key)) continue;
    seen.add(key);
    patterns.push({ key, index: index - 1, before, text, after });
  }
  return patterns;
}

function findFollowingRepeatedMedia(tasks, mediaIndex, pattern) {
  const current = tasks[mediaIndex];
  for (let index = mediaIndex + 1; index < tasks.length; index += 1) {
    const candidate = tasks[index];
    if (isMediaTask(candidate) && sameRepeatedMediaEndpoint(candidate, pattern.after) && sameRepeatedTextRestoreScope(current, candidate)) {
      return index;
    }
    if (sameRepeatedTextRestoreScope(current, candidate)) continue;
    if (String(candidate?.date || "") !== String(current?.date || "") || Number(candidate?.daySegment || 1) !== Number(current?.daySegment || 1)) {
      break;
    }
  }
  return -1;
}

function sameRepeatedMediaEndpoint(task, endpoint) {
  return isMediaTask(task) &&
    mediaTaskFingerprint(task) === mediaTaskFingerprint(endpoint) &&
    String(task?.documentTime || task?.time || "") === String(endpoint?.documentTime || endpoint?.time || "") &&
    normalizeInteractionKey(task?.speaker) === normalizeInteractionKey(endpoint?.speaker);
}

function hasTextTaskBetweenSameMedia(tasks, mediaIndex, afterIndex, template) {
  const current = tasks[mediaIndex];
  const next = tasks[afterIndex];
  const textTime = String(template?.documentTime || template?.time || "");
  return tasks.some((task, index) => {
    if (index === mediaIndex || index === afterIndex || !isTextTask(task)) return false;
    if (!sameRepeatedTextRestoreScope(current, task)) return false;
    if (String(task.documentTime || task.time || "") !== textTime) return false;
    return isTimeBetween(task.documentTime || task.time, current.documentTime || current.time, next.documentTime || next.time);
  });
}

function sameRepeatedTextRestoreScope(left, right) {
  return normalizeInteractionKey(left?.speaker) === normalizeInteractionKey(right?.speaker) &&
    String(left?.date || "") === String(right?.date || "") &&
    Number(left?.daySegment || 1) === Number(right?.daySegment || 1);
}

function repeatedTextBetweenMediaKey(before, after) {
  return [
    normalizeInteractionKey(before?.speaker),
    mediaTaskFingerprint(before),
    String(before?.documentTime || before?.time || ""),
    String(after?.documentTime || after?.time || ""),
    mediaTaskFingerprint(after)
  ].join("|");
}

function mediaTaskFingerprint(task) {
  const value = String(task?.mediaPath || task?.sourceUrl || task?.sourceId || "");
  const filename = value.split(/[\\/]/).pop() || value;
  const hash = filename.match(/(?:image|video|sticker)-([a-f0-9]{8,})(?:\.|$)/i);
  if (hash) return `${task?.type || "media"}:${hash[1].toLowerCase()}`;
  return `${task?.type || "media"}:${filename}`;
}

function isTimeBetween(value, before, after) {
  const seconds = clockToSeconds(value);
  const beforeSeconds = clockToSeconds(before);
  const afterSeconds = clockToSeconds(after);
  if (!Number.isFinite(seconds) || !Number.isFinite(beforeSeconds) || !Number.isFinite(afterSeconds)) return false;
  return beforeSeconds < seconds && seconds < afterSeconds && afterSeconds - beforeSeconds <= 180;
}

function isTimeWithinAfter(value, before, toleranceSeconds) {
  const seconds = clockToSeconds(value);
  const beforeSeconds = clockToSeconds(before);
  if (!Number.isFinite(seconds) || !Number.isFinite(beforeSeconds)) return false;
  const diff = seconds - beforeSeconds;
  return diff > 0 && diff <= toleranceSeconds;
}

function clockDiffSeconds(value, before) {
  const seconds = clockToSeconds(value);
  const beforeSeconds = clockToSeconds(before);
  if (!Number.isFinite(seconds) || !Number.isFinite(beforeSeconds)) return NaN;
  return seconds - beforeSeconds;
}

function shiftClockBySeconds(value, offsetSeconds) {
  const seconds = clockToSeconds(value);
  if (!Number.isFinite(seconds) || !Number.isFinite(offsetSeconds)) return "";
  const total = ((seconds + offsetSeconds) % 86400 + 86400) % 86400;
  const hour = Math.floor(total / 3600);
  const minute = Math.floor((total % 3600) / 60);
  const second = total % 60;
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:${String(second).padStart(2, "0")}`;
}

function midpointTaskNumber(left, right) {
  const leftNumber = finiteTaskNumber(left);
  const rightNumber = finiteTaskNumber(right);
  if (Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) return (leftNumber + rightNumber) / 2;
  return Number.isFinite(leftNumber) ? leftNumber + 0.5 : null;
}

function trimDuplicateTextPrefixEchoes(tasks, diagnostics) {
  const previousTexts = [];
  return tasks.map((task) => {
    if (!isTextTask(task)) {
      return task;
    }
    let next = task;
    if (looksLikeDuplicateTextPrefixEcho(task)) {
      for (const previous of previousTexts) {
        if (!sameDuplicatePrefixScope(task, previous)) continue;
        const trimmed = trimDuplicatePrefixText(next.text || "", previous.text || "");
        if (!trimmed.changed) continue;
        diagnostics.push({
          code: "trimmed_duplicate_text_prefix_echo",
          sourceId: task.sourceId,
          previousSourceId: previous.sourceId || "",
          message: "已清理飞书虚拟滚动把旧正文粘到新正文前面的残影"
        });
        next = createPreviewTask({ ...next, text: trimmed.text });
        break;
      }
    }
    if (comparableDuplicateText(next.text || "")) previousTexts.push(next);
    return next;
  });
}

function trimDuplicateTextSuffixEchoes(tasks, diagnostics) {
  const previousTexts = [];
  return tasks.map((task) => {
    if (!isTextTask(task)) {
      return task;
    }
    let next = task;
    if (looksLikeDuplicateTextEcho(task)) {
      const trimmed = trimDuplicateSuffixText(task, previousTexts);
      if (trimmed.changed) {
        diagnostics.push({
          code: "trimmed_duplicate_text_suffix_echo",
          sourceId: task.sourceId,
          previousSourceId: trimmed.previous?.sourceId || "",
          message: "已清理飞书虚拟滚动把旧正文粘到新正文后面的残影"
        });
        next = createPreviewTask({
          ...task,
          sourceText: task.sourceText || task.text || "",
          text: trimmed.text
        });
      }
    }
    if (comparableDuplicateText(next.text || "")) previousTexts.push(next);
    return next;
  });
}

function restoreTruncatedRepeatedTextTailFragments(tasks, diagnostics) {
  const templates = [];
  return tasks.map((task) => {
    if (!isTextTask(task)) return task;
    const normalized = hasCollectedDomSource(task)
      ? findRepeatedTextSupersetTemplate(task, templates)
      : null;
    if (normalized) {
      diagnostics.push({
        code: "restored_repeated_text_superset",
        sourceId: task.sourceId,
        previousSourceId: normalized.sourceId || "",
        message: "已把飞书虚拟滚动粘入的重复尾巴还原为完整正文模板"
      });
      const next = createPreviewTask({
        ...task,
        sourceId: `restored-repeated-superset:${task.sourceId}:${normalized.sourceId}`,
        sourceText: task.sourceText || task.text || "",
        text: normalized.text || "",
        documentDate: normalized.documentDate || task.documentDate,
        documentTime: normalized.documentTime || task.documentTime,
        time: normalized.time || task.time
      });
      templates.push(next);
      return next;
    }
    const restored = hasCollectedDomSource(task)
      ? findRepeatedTextTailTemplate(task, templates)
      : null;
    const currentComparable = comparableDuplicateText(task.text || "");
    if (!restored) {
      if (currentComparable.length >= 80) templates.push(task);
      return task;
    }
    diagnostics.push({
      code: "restored_truncated_repeated_text_tail",
      sourceId: task.sourceId,
      previousSourceId: restored.sourceId || "",
      message: "已根据同说话人近时间完整模板补回飞书虚拟滚动截断的正文尾段"
    });
    const next = createPreviewTask({
      ...task,
      sourceId: `restored-truncated-tail:${task.sourceId}:${restored.sourceId}`,
      sourceText: task.sourceText || task.text || "",
      text: restored.text || "",
      documentDate: restored.documentDate || task.documentDate,
      documentTime: restored.documentTime || task.documentTime,
      time: restored.time || task.time
    });
    templates.push(next);
    return next;
  });
}

function findRepeatedTextSupersetTemplate(task, templates) {
  const text = comparableDuplicateText(task.text || "");
  if (text.length < 120) return null;
  for (let index = templates.length - 1; index >= 0; index -= 1) {
    const template = templates[index];
    if (!sameSpeakerForTemplateRestore(task, template)) continue;
    if (String(task.documentTime || task.time || "") !== String(template.documentTime || template.time || "")) continue;
    const templateText = comparableDuplicateText(template.text || "");
    if (templateText.length < 80 || text.length <= templateText.length + 8) continue;
    if (!text.startsWith(templateText)) continue;
    const residue = text.slice(templateText.length);
    if (residue.length < 8) continue;
    if (!templateText.includes(residue.slice(0, Math.min(residue.length, 30)))) continue;
    return template;
  }
  return null;
}

function restoreMissingRepeatedTextAfterSameLeadingMedia(tasks, diagnostics) {
  const patterns = collectLeadingMediaTextRestorePatterns(tasks);
  if (!patterns.length) return tasks;
  const result = [];
  let changed = false;
  for (let index = 0; index < tasks.length; index += 1) {
    const current = tasks[index];
    result.push(current);
    if (!isMediaTask(current)) continue;
    const pattern = findLeadingMediaTextPatternForTask(current, patterns, index);
    if (!pattern) continue;
    const restorePattern = refineLeadingMediaPatternFromSameSegmentEvidence(tasks, index, current, pattern);
    if (hasTextTaskForPatternInSameSegment(tasks, current, restorePattern)) continue;
    if (!canRestoreTextAfterLeadingMediaPattern(tasks, index, current, restorePattern)) continue;
    const next = tasks[index + 1] || null;
    const restored = createPreviewTask({
      ...restorePattern.text,
      sourceId: `restored-missing-text-after-media:${current.sourceId}:${restorePattern.text.sourceId}`,
      sourceText: restorePattern.text.sourceText || restorePattern.text.text || "",
      date: current.date,
      time: restorePattern.restoreTextTime || restorePattern.text.time,
      documentDate: current.documentDate || restorePattern.text.documentDate,
      documentTime: restorePattern.restoreTextTime || restorePattern.text.documentTime,
      daySegment: current.daySegment,
      order: Number(current.order || result.length) + 0.5,
      _visualTop: midpointTaskNumber(current._visualTop, next?._visualTop),
      _eventOrder: midpointTaskNumber(current._eventOrder, next?._eventOrder)
    });
    result.push(restored);
    if (restorePattern.after && restorePattern.restoreAfterTime && canRestoreAfterMediaForPattern(tasks, index, current, restorePattern, next)) {
      const restoredAfter = createPreviewTask({
        ...restorePattern.after,
        sourceId: `restored-missing-media-after-text:${current.sourceId}:${restorePattern.after.sourceId}`,
        date: current.date,
        time: restorePattern.restoreAfterTime,
        documentDate: current.documentDate || restorePattern.after.documentDate,
        documentTime: restorePattern.restoreAfterTime,
        daySegment: current.daySegment,
        order: Number(restored.order || result.length) + 0.5,
        _visualTop: midpointTaskNumber(restored._visualTop, next?._visualTop),
        _eventOrder: midpointTaskNumber(restored._eventOrder, next?._eventOrder)
      });
      result.push(restoredAfter);
      diagnostics.push({
        code: "restored_missing_media_after_repeated_text",
        sourceId: restoredAfter.sourceId,
        previousSourceId: restorePattern.after.sourceId || "",
        message: "已根据相同前置素材和固定节奏恢复飞书虚拟滚动漏采的后续素材"
      });
    }
    changed = true;
    diagnostics.push({
      code: "restored_missing_repeated_text_after_media",
      sourceId: restored.sourceId,
      previousSourceId: restorePattern.text.sourceId || "",
      message: "已根据相同前置素材恢复飞书虚拟滚动漏采的重复正文"
    });
  }
  if (!changed) return tasks;
  return result.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

function restoreMissingHistoricalInviteTextAfterLeadingMedia(tasks, diagnostics) {
  const patterns = [];
  const result = [];
  let changed = false;
  for (let index = 0; index < tasks.length; index += 1) {
    const current = tasks[index];
    result.push(current);
    if (isMediaTask(current)) {
      const pattern = findHistoricalInvitePatternForTask(current, patterns);
      if (pattern &&
        hasHistoricalCompanionMediaEvidence(tasks, current, pattern) &&
        !hasTextTaskForPatternInSameSegment(tasks, current, pattern) &&
        !hasNearbyNonPatternTaskAfterLeadingMedia(tasks, index, current, pattern) &&
        canRestoreTextAfterCurrentMedia(tasks, index, current, pattern.restoreTextTime)) {
        const next = tasks[index + 1] || null;
        const restored = createPreviewTask({
          ...pattern.text,
          sourceId: `restored-missing-historical-invite-text:${current.sourceId}:${pattern.text.sourceId}`,
          sourceText: pattern.text.sourceText || pattern.text.text || "",
          date: current.date,
          time: pattern.restoreTextTime || pattern.text.time,
          documentDate: current.documentDate || pattern.text.documentDate,
          documentTime: pattern.restoreTextTime || pattern.text.documentTime,
          daySegment: current.daySegment,
          order: Number(current.order || result.length) + 0.5,
          _visualTop: midpointTaskNumber(current._visualTop, next?._visualTop),
          _eventOrder: midpointTaskNumber(current._eventOrder, next?._eventOrder)
        });
        result.push(restored);
        changed = true;
        diagnostics.push({
          code: "restored_missing_historical_invite_text_after_media",
          sourceId: restored.sourceId,
          previousSourceId: pattern.text.sourceId || "",
          message: "已根据历史同时间固定招群模板补回飞书虚拟滚动漏采正文"
        });
      }
    }
    const learned = collectHistoricalInvitePatternAt(tasks, index);
    if (learned) patterns.push(learned);
  }
  if (!changed) return tasks;
  return result.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

function restoreMissingRepeatedOutroAfterMedia(tasks, diagnostics) {
  const patterns = collectOutroAfterMediaPatterns(tasks);
  if (!patterns.length) return tasks;
  const result = [];
  let changed = false;
  for (let index = 0; index < tasks.length; index += 1) {
    const current = tasks[index];
    result.push(current);
    if (!isMediaTask(current)) continue;
    const pattern = findOutroAfterMediaPatternForTask(current, patterns, index);
    if (!pattern) continue;
    if (hasOutroTextForPatternInSameSegment(tasks, current, pattern)) continue;
    if (!canRestoreOutroAfterCurrentMedia(tasks, index, current, pattern.restoreTextTime || pattern.text.documentTime || pattern.text.time)) continue;
    const next = tasks[index + 1] || null;
    const restored = createPreviewTask({
      ...pattern.text,
      sourceId: `restored-missing-outro-after-media:${current.sourceId}:${pattern.text.sourceId}`,
      sourceText: pattern.text.sourceText || pattern.text.text || "",
      date: current.date,
      time: pattern.restoreTextTime || pattern.text.time,
      documentDate: current.documentDate || pattern.text.documentDate,
      documentTime: pattern.restoreTextTime || pattern.text.documentTime,
      daySegment: current.daySegment,
      order: Number(current.order || result.length) + 0.5,
      _visualTop: midpointTaskNumber(current._visualTop, next?._visualTop),
      _eventOrder: midpointTaskNumber(current._eventOrder, next?._eventOrder)
    });
    result.push(restored);
    changed = true;
    const restoredOffset = clockDiffSeconds(restored.documentTime || restored.time, current.documentTime || current.time);
    if (Number.isFinite(restoredOffset) && restoredOffset > 0 && restoredOffset <= 90) {
      patterns.push({
        key: leadingMediaTextPatternKey(current, restored),
        index,
        media: current,
        text: restored,
        textOffsetSeconds: restoredOffset
      });
    }
    diagnostics.push({
      code: "restored_missing_outro_after_media",
      sourceId: current.sourceId,
      previousSourceId: pattern.text.sourceId || "",
      message: "已按同说话人同时间素材后的固定收尾文案补回漏采文本"
    });
  }
  if (!changed) return tasks;
  return result.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

function restoreMissingRepeatedMediaAfterExistingText(tasks, diagnostics) {
  const patterns = collectTextMediaPatterns(tasks);
  const result = [];
  let changed = false;
  for (let index = 0; index < tasks.length; index += 1) {
    const current = tasks[index];
    result.push(current);
    if (!isTextTask(current)) continue;
    const pattern = findTextMediaPatternForTask(current, patterns, index);
    if (pattern && !hasMediaAfterTextPatternInSameSegment(tasks, current, pattern) && canRestoreMediaAfterExistingText(tasks, index, current, pattern)) {
      const restoreMediaTime = shiftClockBySeconds(current.documentTime || current.time, pattern.mediaOffsetSeconds);
      const next = tasks[index + 1] || null;
      const restored = createPreviewTask({
        ...pattern.media,
        sourceId: `restored-missing-media-after-existing-text:${current.sourceId}:${pattern.media.sourceId}`,
        date: current.date,
        time: restoreMediaTime,
        documentDate: current.documentDate || pattern.media.documentDate,
        documentTime: restoreMediaTime,
        daySegment: current.daySegment,
        order: Number(current.order || result.length) + 0.5,
        _visualTop: midpointTaskNumber(current._visualTop, next?._visualTop),
        _eventOrder: midpointTaskNumber(current._eventOrder, next?._eventOrder)
      });
      result.push(restored);
      changed = true;
      diagnostics.push({
        code: "restored_missing_media_after_existing_text",
        sourceId: restored.sourceId,
        previousSourceId: pattern.media.sourceId || "",
        message: "已根据同说话人同原始时间正文后的固定节奏补回漏采素材"
      });
    }
  }
  if (!changed) return tasks;
  return result.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

function collectTextMediaPatterns(tasks) {
  const patterns = [];
  for (let index = 0; index < tasks.length; index += 1) {
    const pattern = collectTextMediaPatternAt(tasks, index);
    if (pattern) patterns.push(pattern);
  }
  return patterns;
}

function collectTextMediaPatternAt(tasks, textIndex) {
  const text = tasks[textIndex];
  if (!isTextTask(text)) return null;
  const comparable = comparableDuplicateText(text.text || "");
  if (comparable.length < 80) return null;
  const media = findNearbyMediaAfterText(tasks, textIndex, text, 10);
  if (!media) return null;
  const offset = clockDiffSeconds(media.documentTime || media.time, text.documentTime || text.time);
  if (!Number.isFinite(offset) || offset <= 0 || offset > 10) return null;
  return {
    key: textMediaPatternKey(text, media),
    index: textIndex,
    text,
    textComparable: comparable,
    media,
    mediaOffsetSeconds: offset
  };
}

function findNearbyMediaAfterText(tasks, textIndex, text, toleranceSeconds) {
  for (let index = textIndex + 1; index < tasks.length; index += 1) {
    const candidate = tasks[index];
    if (!sameRepeatedTextRestoreScope(text, candidate)) {
      if (String(candidate?.date || "") !== String(text?.date || "") || Number(candidate?.daySegment || 1) !== Number(text?.daySegment || 1)) break;
      continue;
    }
    const diff = clockDiffSeconds(candidate.documentTime || candidate.time, text.documentTime || text.time);
    if (Number.isFinite(diff) && diff > toleranceSeconds) return null;
    if (!isMediaTask(candidate)) continue;
    if (!Number.isFinite(diff) || diff <= 0 || diff > toleranceSeconds) continue;
    return candidate;
  }
  return null;
}

function findTextMediaPatternForTask(task, patterns, taskIndex = Number.POSITIVE_INFINITY) {
  const comparable = comparableDuplicateText(task.text || "");
  if (comparable.length < 80) return null;
  let relativeInvitePattern = null;
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (!isRestoredTextTask(task) && Number.isFinite(pattern.index) && pattern.index >= taskIndex) continue;
    if (!sameSpeakerForTemplateRestore(task, pattern.text)) continue;
    if (comparable !== pattern.textComparable && !comparable.includes(pattern.textComparable) && !pattern.textComparable.includes(comparable)) continue;
    if (!Number.isFinite(pattern.mediaOffsetSeconds) || pattern.mediaOffsetSeconds <= 0 || pattern.mediaOffsetSeconds > 10) continue;
    if (String(task.documentTime || task.time || "") !== String(pattern.text.documentTime || pattern.text.time || "")) {
      if (!relativeInvitePattern && isRestoredTextTask(task) && isRepeatedInviteBodyText(task.text || "") && isRepeatedInviteBodyText(pattern.text.text || "")) {
        relativeInvitePattern = pattern;
      }
      continue;
    }
    return pattern;
  }
  return relativeInvitePattern;
}

function textMediaPatternKey(text, media) {
  return [
    normalizeInteractionKey(text?.speaker),
    String(text?.documentTime || text?.time || ""),
    comparableDuplicateText(text?.text || ""),
    String(media?.documentTime || media?.time || ""),
    mediaTaskFingerprint(media)
  ].join("|");
}

function hasMediaAfterTextPatternInSameSegment(tasks, current, pattern) {
  const restoreMediaTime = shiftClockBySeconds(current.documentTime || current.time, pattern.mediaOffsetSeconds);
  const mediaFingerprint = mediaTaskFingerprint(pattern.media);
  return tasks.some((task) => {
    if (!isMediaTask(task)) return false;
    if (!sameRepeatedTextRestoreScope(current, task)) return false;
    if (String(task.documentTime || task.time || "") !== restoreMediaTime) return false;
    return mediaTaskFingerprint(task) === mediaFingerprint;
  });
}

function canRestoreMediaAfterExistingText(tasks, currentIndex, current, pattern) {
  const restoreMediaTime = shiftClockBySeconds(current.documentTime || current.time, pattern.mediaOffsetSeconds);
  if (!restoreMediaTime) return false;
  if (!isTimeWithinAfter(restoreMediaTime, current.documentTime || current.time, 10)) return false;
  if (hasNearbyMediaFingerprintInSameSegment(tasks, current, pattern.media)) return false;
  for (let index = currentIndex + 1; index < tasks.length; index += 1) {
    const candidate = tasks[index];
    if (sameRepeatedTextRestoreScope(current, candidate)) {
      const diff = clockDiffSeconds(candidate.documentTime || candidate.time, restoreMediaTime);
      if (Number.isFinite(diff) && diff <= 0) return false;
      return true;
    }
    if (String(candidate?.date || "") !== String(current?.date || "") || Number(candidate?.daySegment || 1) !== Number(current?.daySegment || 1)) break;
  }
  return true;
}

function restoreMissingShortMentionAfterMedia(tasks, diagnostics) {
  const patterns = [];
  const result = [];
  let changed = false;
  for (let index = 0; index < tasks.length; index += 1) {
    const current = tasks[index];
    result.push(current);
    if (!isMediaTask(current)) continue;
    if (String(current.sourceId || "").startsWith("restored-missing-media-after-text:")) continue;
    const pattern = findShortMentionAfterMediaPatternForTask(current, patterns);
    if (pattern && !hasShortMentionForPatternInSameSegment(tasks, current, pattern) && canRestoreTextAfterCurrentMedia(tasks, index, current, shiftClockBySeconds(current.documentTime || current.time, pattern.textOffsetSeconds))) {
      const restoreTextTime = shiftClockBySeconds(current.documentTime || current.time, pattern.textOffsetSeconds);
      const next = tasks[index + 1] || null;
      const restored = createPreviewTask({
        ...pattern.text,
        sourceId: `restored-missing-short-mention-after-media:${current.sourceId}:${pattern.text.sourceId}`,
        sourceText: pattern.text.sourceText || pattern.text.text || "",
        date: current.date,
        time: restoreTextTime,
        documentDate: current.documentDate || pattern.text.documentDate,
        documentTime: restoreTextTime,
        daySegment: current.daySegment,
        order: Number(current.order || result.length) + 0.5,
        _visualTop: midpointTaskNumber(current._visualTop, next?._visualTop),
        _eventOrder: midpointTaskNumber(current._eventOrder, next?._eventOrder)
      });
      result.push(restored);
      changed = true;
      diagnostics.push({
        code: "restored_missing_short_mention_after_media",
        sourceId: restored.sourceId,
        previousSourceId: pattern.text.sourceId || "",
        message: "已根据同时间素材后的固定短提醒补回漏采文本"
      });
    }
    const currentPattern = collectShortMentionAfterMediaPatternAt(tasks, index);
    if (currentPattern) patterns.push(currentPattern);
  }
  if (!changed) return tasks;
  return result.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

function collectShortMentionAfterMediaPatternAt(tasks, mediaIndex) {
  const media = tasks[mediaIndex];
  const text = tasks[mediaIndex + 1];
  if (!isMediaTask(media) || !isTextTask(text)) return null;
  if (!sameRepeatedTextRestoreScope(media, text)) return null;
  if (!isStrictShortMentionText(text.text || "")) return null;
  const offset = clockDiffSeconds(text.documentTime || text.time, media.documentTime || media.time);
  if (!Number.isFinite(offset) || offset <= 0 || offset > 5) return null;
  return {
    key: shortMentionAfterMediaPatternKey(media, text),
    index: mediaIndex,
    media,
    text,
    textOffsetSeconds: offset
  };
}

function findShortMentionAfterMediaPatternForTask(task, patterns) {
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (!sameSpeakerForTemplateRestore(task, pattern.media)) continue;
    if (String(task.documentTime || task.time || "") !== String(pattern.media.documentTime || pattern.media.time || "")) continue;
    if (mediaTaskFingerprint(task) !== mediaTaskFingerprint(pattern.media)) continue;
    if (!Number.isFinite(pattern.textOffsetSeconds) || pattern.textOffsetSeconds <= 0 || pattern.textOffsetSeconds > 5) continue;
    return pattern;
  }
  return null;
}

function shortMentionAfterMediaPatternKey(media, text) {
  return [
    normalizeInteractionKey(media?.speaker),
    mediaTaskFingerprint(media),
    String(media?.documentTime || media?.time || ""),
    String(text?.documentTime || text?.time || ""),
    comparableDuplicateText(text?.text || "")
  ].join("|");
}

function hasShortMentionForPatternInSameSegment(tasks, current, pattern) {
  const textTime = shiftClockBySeconds(current.documentTime || current.time, pattern.textOffsetSeconds);
  const textComparable = comparableDuplicateText(pattern?.text?.text || "");
  return tasks.some((task) => {
    if (!isTextTask(task)) return false;
    if (!sameRepeatedTextRestoreScope(current, task)) return false;
    if (String(task.documentTime || task.time || "") !== textTime) return false;
    return comparableDuplicateText(task.text || "") === textComparable;
  });
}

function isStrictShortMentionText(text) {
  return normalizeMessageText(text || "").trim() === "@所有人";
}

function dropMisplacedOutroAtMediaTime(tasks, diagnostics) {
  const dropped = [];
  const result = tasks.filter((task) => {
    if (!isTextTask(task)) return true;
    if (!isNarrowRepeatedOutroText(task.text || "") && !isRepeatedOutroResidueText(task.text || "")) return true;
    const taskTime = String(task.documentTime || task.time || "");
    const hasSameTimeMedia = tasks.some((candidate) =>
      isMediaTask(candidate) &&
      sameRepeatedTextRestoreScope(task, candidate) &&
      String(candidate.documentTime || candidate.time || "") === taskTime
    );
    if (!hasSameTimeMedia) return true;
    const hasLaterOutro = tasks.some((candidate) => {
      if (candidate === task || !isTextTask(candidate)) return false;
      if (!sameRepeatedTextRestoreScope(task, candidate)) return false;
      if (!isNarrowRepeatedOutroText(candidate.text || "")) return false;
      const diff = clockDiffSeconds(candidate.documentTime || candidate.time, taskTime);
      return Number.isFinite(diff) && diff > 0 && diff <= 90;
    });
    if (!hasLaterOutro) return true;
    dropped.push(task.sourceId || "");
    return false;
  });
  if (dropped.length) {
    diagnostics.push({
      code: "dropped_misplaced_outro_at_media_time",
      sourceId: dropped.filter(Boolean).join(","),
      message: "已移除飞书残影把收尾文案粘到前置素材同时间的位置"
    });
  }
  return dropped.length ? result.map((task, index) => createPreviewTask({ ...task, order: index + 1 })) : tasks;
}

function dropDirtyTextSupersededByOutroAtSameTime(tasks, diagnostics) {
  const dropped = [];
  const result = tasks.filter((task) => {
    if (!isTextTask(task)) return true;
    if (isNarrowRepeatedOutroText(task.text || "")) return true;
    if (!looksLikeOutroTimeDirtyResidue(task.text || "")) return true;
    const taskTime = String(task.documentTime || task.time || "");
    const hasOutroAtSameTime = tasks.some((candidate) =>
      candidate !== task &&
      isTextTask(candidate) &&
      sameRepeatedTextRestoreScope(task, candidate) &&
      String(candidate.documentTime || candidate.time || "") === taskTime &&
      isNarrowRepeatedOutroText(candidate.text || "")
    );
    if (!hasOutroAtSameTime) return true;
    dropped.push(task.sourceId || "");
    return false;
  });
  if (dropped.length) {
    diagnostics.push({
      code: "dropped_dirty_text_superseded_by_outro",
      sourceId: dropped.filter(Boolean).join(","),
      message: "已移除同时间被正确收尾文案覆盖的飞书脏文本"
    });
  }
  return dropped.length ? result.map((task, index) => createPreviewTask({ ...task, order: index + 1 })) : tasks;
}

function dropDecorativeNicknameResidueText(tasks, diagnostics) {
  const dropped = [];
  const result = tasks.filter((task) => {
    if (!isTextTask(task)) return true;
    if (!isDecorativeNicknameResidueText(task.text || "")) return true;
    dropped.push(task.sourceId || "");
    return false;
  });
  if (dropped.length) {
    diagnostics.push({
      code: "dropped_decorative_nickname_residue",
      sourceId: dropped.filter(Boolean).join(","),
      message: "已移除飞书虚拟滚动混入的昵称和装饰表情残片"
    });
  }
  return dropped.length ? result.map((task, index) => createPreviewTask({ ...task, order: index + 1 })) : tasks;
}

function looksLikeOutroTimeDirtyResidue(text) {
  const normalized = normalizeMessageText(text || "");
  const comparable = comparableDuplicateText(normalized);
  if (isDecorativeNicknameResidueText(normalized)) return true;
  if (comparable.length < 40) return false;
  return /进\s*V\s*I\s*P\s*大裙/i.test(normalized) ||
    /点击图片长按二维码扫码进[群裙]/.test(normalized) ||
    hasRepeatedRoseEmoji(normalized);
}

function isDecorativeNicknameResidueText(text) {
  const lines = String(text || "")
    .split(/\r?\n/)
    .map((line) => normalizeMessageText(line).trim())
    .filter(Boolean);
  if (lines.length < 2 || lines.length > 5) return false;
  const nameLines = lines.filter((line) => !isDecorativeOnlyLine(line));
  if (nameLines.length < 2 || nameLines.length > 3) return false;
  const normalizedNames = nameLines.map((line) => normalizeInteractionKey(line));
  const first = normalizedNames[0] || "";
  if (!first || first.length < 2 || first.length > 12) return false;
  if (!normalizedNames.every((line) => line === first)) return false;
  return lines.some(isDecorativeOnlyLine);
}

function isDecorativeOnlyLine(line) {
  const value = String(line || "").trim();
  if (!value) return false;
  const remaining = Array.from(value)
    .filter((char) => !["🌹", "❤", "💙", "🤍", "💕", "💖", "💗", "💓", "💞", "✨", "⭐", "🌸"].includes(char))
    .join("")
    .replace(/[\s.,，。~～!！?？\-—_·|/\\]+/g, "");
  return remaining === "" && Array.from(value).length >= 3;
}

function collectOutroAfterMediaPatterns(tasks) {
  const patterns = [];
  const seen = new Set();
  for (let index = 0; index < tasks.length - 1; index += 1) {
    const media = tasks[index];
    const text = tasks[index + 1];
    if (!isMediaTask(media) || !isTextTask(text)) continue;
    if (!sameRepeatedTextRestoreScope(media, text)) continue;
    if (!isNarrowRepeatedOutroText(text.text || "")) continue;
    const offset = clockDiffSeconds(text.documentTime || text.time, media.documentTime || media.time);
    if (!Number.isFinite(offset) || offset <= 0 || offset > 90) continue;
    const key = leadingMediaTextPatternKey(media, text);
    if (seen.has(key)) continue;
    seen.add(key);
    patterns.push({ key, index, media, text, textOffsetSeconds: offset });
  }
  return patterns;
}

function findOutroAfterMediaPatternForTask(task, patterns, taskIndex) {
  const exact = findExactOutroAfterMediaPattern(task, patterns, taskIndex);
  if (exact) return exact;
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (Number.isFinite(pattern.index) && pattern.index >= taskIndex) continue;
    if (!sameSpeakerForTemplateRestore(task, pattern.media)) continue;
    if (String(task.documentTime || task.time || "") !== String(pattern.media.documentTime || pattern.media.time || "")) continue;
    if (mediaTaskFingerprint(task) !== mediaTaskFingerprint(pattern.media)) continue;
    if (!Number.isFinite(pattern.textOffsetSeconds) || pattern.textOffsetSeconds < 25 || pattern.textOffsetSeconds > 40) continue;
    const restoreTextTime = shiftClockBySeconds(task.documentTime || task.time, pattern.textOffsetSeconds);
    if (!restoreTextTime) continue;
    return { ...pattern, restoreTextTime };
  }
  const relative = findRelativeOutroAfterMediaPattern(task, patterns, taskIndex);
  if (relative) return relative;
  return null;
}

function findRelativeOutroAfterMediaPattern(task, patterns, taskIndex) {
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (Number.isFinite(pattern.index) && pattern.index >= taskIndex) continue;
    if (!sameRepeatedTextRestoreScope(task, pattern.media)) continue;
    if (mediaTaskFingerprint(task) !== mediaTaskFingerprint(pattern.media)) continue;
    if (!Number.isFinite(pattern.textOffsetSeconds) || pattern.textOffsetSeconds < 25 || pattern.textOffsetSeconds > 40) continue;
    const restoreTextTime = shiftClockBySeconds(task.documentTime || task.time, pattern.textOffsetSeconds);
    if (!restoreTextTime) continue;
    return { ...pattern, restoreTextTime };
  }
  return null;
}

function findExactOutroAfterMediaPattern(task, patterns, taskIndex) {
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (Number.isFinite(pattern.index) && pattern.index >= taskIndex) continue;
    if (leadingMediaTextPatternKey(task, pattern.text) !== pattern.key) continue;
    return { ...pattern, restoreTextTime: pattern.text.documentTime || pattern.text.time };
  }
  return null;
}

function isNarrowRepeatedOutroText(text) {
  const normalized = comparableDuplicateText(text || "");
  if (normalized.length < 24 || normalized.length > 120) return false;
  return normalized.includes("大家进入新群后") &&
    normalized.includes("退出本群") &&
    normalized.includes("只保留一个群");
}

function isRepeatedOutroResidueText(text) {
  const normalized = comparableDuplicateText(text || "");
  if (normalized.length < 18 || normalized.length > 100) return false;
  return normalized.includes("只保留一个群") &&
    normalized.includes("感谢一路陪伴");
}

function isClosingOnlyOutroResidueText(text) {
  const normalized = comparableDuplicateText(text || "");
  if (normalized.length < 8 || normalized.length > 60) return false;
  return normalized.includes("感谢一路陪伴") && normalized.includes("新群见");
}

function isRepeatedInviteBodyText(text) {
  const normalized = normalizeMessageText(text || "");
  const comparable = comparableDuplicateText(normalized);
  if (comparable.length < 80) return false;
  return /进\s*V\s*I\s*P\s*大裙/i.test(normalized) &&
    /点击图片长按二维码扫码进[群裙]/.test(normalized) &&
    hasRepeatedRoseEmoji(normalized);
}

function hasRepeatedRoseEmoji(text) {
  let count = 0;
  for (const char of Array.from(String(text || ""))) {
    if (char === "🌹") count += 1;
    if (count >= 3) return true;
  }
  return false;
}

function hasOutroTextForPatternInSameSegment(tasks, current, pattern) {
  const textTime = String(pattern?.restoreTextTime || pattern?.text?.documentTime || pattern?.text?.time || "");
  const textComparable = comparableDuplicateText(pattern?.text?.text || "");
  return tasks.some((task) => {
    if (!isTextTask(task)) return false;
    if (!sameRepeatedTextRestoreScope(current, task)) return false;
    if (String(task.documentTime || task.time || "") !== textTime) return false;
    const currentComparable = comparableDuplicateText(task.text || "");
    return currentComparable === textComparable ||
      (isNarrowRepeatedOutroText(task.text || "") && currentComparable.length >= 24);
  });
}

function collectLeadingMediaTextRestorePatterns(tasks) {
  return [
    ...collectRepeatedTextBetweenMediaPatterns(tasks).map((pattern) => ({
      key: leadingMediaTextPatternKey(pattern.before, pattern.text),
      index: pattern.index,
      media: pattern.before,
      text: pattern.text,
      after: pattern.after,
      textOffsetSeconds: clockDiffSeconds(pattern.text.documentTime || pattern.text.time, pattern.before.documentTime || pattern.before.time),
      afterOffsetSeconds: clockDiffSeconds(pattern.after.documentTime || pattern.after.time, pattern.before.documentTime || pattern.before.time)
    })),
    ...collectRepeatedTextAfterMediaPatterns(tasks)
  ];
}

function collectRepeatedTextAfterMediaPatterns(tasks) {
  const patterns = [];
  for (let index = 0; index < tasks.length - 1; index += 1) {
    const media = tasks[index];
    const text = tasks[index + 1];
    if (!isMediaTask(media) || !isTextTask(text)) continue;
    if (!sameRepeatedTextRestoreScope(media, text)) continue;
    if (!isTimeWithinAfter(text.documentTime || text.time, media.documentTime || media.time, 20)) continue;
    if (comparableDuplicateText(text.text || "").length < 80) continue;
    const afterMedia = findNearbyAfterMediaForTextPattern(tasks, index, text);
    const key = leadingMediaTextPatternKey(media, text);
    patterns.push({
      key,
      index,
      media,
      text,
      after: afterMedia,
      textOffsetSeconds: clockDiffSeconds(text.documentTime || text.time, media.documentTime || media.time),
      afterOffsetSeconds: afterMedia ? clockDiffSeconds(afterMedia.documentTime || afterMedia.time, media.documentTime || media.time) : null
    });
  }
  return patterns;
}

function findNearbyAfterMediaForTextPattern(tasks, textIndex, text) {
  let best = null;
  let bestDiff = Number.POSITIVE_INFINITY;
  for (let index = textIndex + 2; index < tasks.length; index += 1) {
    const candidate = tasks[index];
    if (!sameRepeatedTextRestoreScope(text, candidate)) {
      if (String(candidate?.date || "") !== String(text?.date || "") || Number(candidate?.daySegment || 1) !== Number(text?.daySegment || 1)) break;
      continue;
    }
    if (!isMediaTask(candidate)) continue;
    const diff = clockDiffSeconds(candidate.documentTime || candidate.time, text.documentTime || text.time);
    if (!Number.isFinite(diff) || diff <= 0 || diff > 20) continue;
    if (diff < bestDiff) {
      best = candidate;
      bestDiff = diff;
    }
  }
  return best;
}

function findLeadingMediaTextPatternForTask(task, patterns, taskIndex = Number.POSITIVE_INFINITY) {
  const exactWithAfter = findExactLeadingMediaTextPattern(task, patterns, taskIndex, true);
  if (exactWithAfter) return exactWithAfter;
  const exact = findExactLeadingMediaTextPattern(task, patterns, taskIndex, false);
  if (exact) return exact;
  const sameTimeWithAfter = findSameTimeLeadingMediaTextPattern(task, patterns, taskIndex, true);
  if (sameTimeWithAfter) return sameTimeWithAfter;
  const sameTime = findSameTimeLeadingMediaTextPattern(task, patterns, taskIndex, false);
  if (sameTime) return sameTime;
  const relativeWithAfter = findRelativeLeadingMediaTextPattern(task, patterns, taskIndex, true);
  if (relativeWithAfter) return relativeWithAfter;
  return null;
}

function findExactLeadingMediaTextPattern(task, patterns, taskIndex, requireAfter) {
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (Number.isFinite(pattern.index) && pattern.index >= taskIndex) continue;
    if (requireAfter && !pattern.after) continue;
    if (requireAfter && !hasTightAfterMediaOffset(pattern)) continue;
    if (leadingMediaTextPatternKey(task, pattern.text) !== pattern.key) continue;
    return {
      ...pattern,
      restoreTextTime: pattern.text.documentTime || pattern.text.time,
      restoreAfterTime: pattern.after ? (pattern.after.documentTime || pattern.after.time) : ""
    };
  }
  return null;
}

function findSameTimeLeadingMediaTextPattern(task, patterns, taskIndex, requireAfter) {
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (Number.isFinite(pattern.index) && pattern.index >= taskIndex) continue;
    if (requireAfter && !pattern.after) continue;
    if (requireAfter && !hasTightAfterMediaOffset(pattern)) continue;
    if (!sameSpeakerForTemplateRestore(task, pattern.media)) continue;
    if (String(task.documentTime || task.time || "") !== String(pattern.media.documentTime || pattern.media.time || "")) continue;
    if (!Number.isFinite(pattern.textOffsetSeconds) || pattern.textOffsetSeconds <= 0 || pattern.textOffsetSeconds > 20) continue;
    const restoreTextTime = shiftClockBySeconds(task.documentTime || task.time, pattern.textOffsetSeconds);
    if (!restoreTextTime) continue;
    const restoreAfterTime = pattern.after && Number.isFinite(pattern.afterOffsetSeconds)
      ? shiftClockBySeconds(task.documentTime || task.time, pattern.afterOffsetSeconds)
      : "";
    return { ...pattern, restoreTextTime, restoreAfterTime };
  }
  return null;
}

function findRelativeLeadingMediaTextPattern(task, patterns, taskIndex, requireAfter) {
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (Number.isFinite(pattern.index) && pattern.index === taskIndex) continue;
    if (requireAfter && !pattern.after) continue;
    if (requireAfter && !hasTightAfterMediaOffset(pattern)) continue;
    if (!sameRepeatedTextRestoreScope(task, pattern.media)) continue;
    if (!sameSpeakerForTemplateRestore(task, pattern.media)) continue;
    if (mediaTaskFingerprint(task) !== mediaTaskFingerprint(pattern.media)) continue;
    if (!Number.isFinite(pattern.textOffsetSeconds) || pattern.textOffsetSeconds <= 0 || pattern.textOffsetSeconds > 20) continue;
    const restoreTextTime = shiftClockBySeconds(task.documentTime || task.time, pattern.textOffsetSeconds);
    if (!restoreTextTime) continue;
    const restoreAfterTime = pattern.after && Number.isFinite(pattern.afterOffsetSeconds)
      ? shiftClockBySeconds(task.documentTime || task.time, pattern.afterOffsetSeconds)
      : "";
    return { ...pattern, restoreTextTime, restoreAfterTime };
  }
  return null;
}

function hasTightAfterMediaOffset(pattern) {
  if (!pattern?.after) return false;
  if (!Number.isFinite(pattern.textOffsetSeconds) || !Number.isFinite(pattern.afterOffsetSeconds)) return false;
  const afterTextOffset = pattern.afterOffsetSeconds - pattern.textOffsetSeconds;
  return afterTextOffset > 0 && afterTextOffset <= 10;
}

function refineLeadingMediaPatternFromSameSegmentEvidence(tasks, currentIndex, current, pattern) {
  const textOffset = Number(pattern?.textOffsetSeconds);
  if (!Number.isFinite(textOffset) || textOffset <= 0 || textOffset > 20) return pattern;
  const currentFingerprint = mediaTaskFingerprint(current);
  const expectedText = comparableDuplicateText(pattern?.text?.text || "");
  if (expectedText.length < 80) return pattern;
  for (let index = 0; index < tasks.length - 2; index += 1) {
    if (index === currentIndex) continue;
    const media = tasks[index];
    const text = tasks[index + 1];
    const after = tasks[index + 2];
    if (!isMediaTask(media) || !isTextTask(text) || !isMediaTask(after)) continue;
    if (!sameRepeatedTextRestoreScope(current, media)) continue;
    if (!sameRepeatedTextRestoreScope(media, text) || !sameRepeatedTextRestoreScope(text, after)) continue;
    if (mediaTaskFingerprint(media) !== currentFingerprint) continue;
    const currentTextOffset = clockDiffSeconds(text.documentTime || text.time, media.documentTime || media.time);
    if (!Number.isFinite(currentTextOffset) || Math.abs(currentTextOffset - textOffset) > 1) continue;
    const evidenceText = comparableDuplicateText(text.text || "");
    if (evidenceText !== expectedText && !evidenceText.includes(expectedText) && !expectedText.includes(evidenceText)) continue;
    const afterOffset = clockDiffSeconds(after.documentTime || after.time, media.documentTime || media.time);
    if (!Number.isFinite(afterOffset) || afterOffset <= currentTextOffset || afterOffset - currentTextOffset > 10) continue;
    return {
      ...pattern,
      text: evidenceText.length > expectedText.length ? text : pattern.text,
      after,
      textOffsetSeconds: currentTextOffset,
      afterOffsetSeconds: afterOffset,
      restoreTextTime: shiftClockBySeconds(current.documentTime || current.time, currentTextOffset),
      restoreAfterTime: shiftClockBySeconds(current.documentTime || current.time, afterOffset)
    };
  }
  return pattern;
}

function canRestoreTextAfterLeadingMediaPattern(tasks, currentIndex, current, pattern) {
  const restoreTextTime = pattern.restoreTextTime || pattern.text?.documentTime || pattern.text?.time;
  if (!isTimeWithinAfter(restoreTextTime, current.documentTime || current.time, 20)) return false;
  if (hasNearbyNonPatternTaskAfterLeadingMedia(tasks, currentIndex, current, pattern)) return false;
  if (!hasSameSegmentLeadingMediaTextEvidence(tasks, currentIndex, current, pattern) &&
    !hasHistoricalLeadingMediaTextEvidence(tasks, current, pattern, currentIndex)) {
    return false;
  }
  return canRestoreTextAfterCurrentMedia(tasks, currentIndex, current, restoreTextTime);
}

function hasSameSegmentLeadingMediaTextEvidence(tasks, currentIndex, current, pattern) {
  const textOffset = Number(pattern?.textOffsetSeconds);
  if (!Number.isFinite(textOffset) || textOffset <= 0 || textOffset > 20) return false;
  const currentFingerprint = mediaTaskFingerprint(current);
  const expectedText = comparableDuplicateText(pattern?.text?.text || "");
  if (expectedText.length < 80) return false;
  for (let index = 0; index < tasks.length - 1; index += 1) {
    if (index === currentIndex) continue;
    const media = tasks[index];
    const text = tasks[index + 1];
    if (!isMediaTask(media) || !isTextTask(text)) continue;
    if (!sameRepeatedTextRestoreScope(current, media)) continue;
    if (!sameRepeatedTextRestoreScope(media, text)) continue;
    if (mediaTaskFingerprint(media) !== currentFingerprint) continue;
    const offset = clockDiffSeconds(text.documentTime || text.time, media.documentTime || media.time);
    if (!Number.isFinite(offset) || Math.abs(offset - textOffset) > 1) continue;
    const evidenceText = comparableDuplicateText(text.text || "");
    if (evidenceText !== expectedText && !evidenceText.includes(expectedText) && !expectedText.includes(evidenceText)) continue;
    return true;
  }
  return false;
}

function hasHistoricalLeadingMediaTextEvidence(tasks, current, pattern, currentIndex) {
  if (!pattern || !Number.isFinite(pattern.index) || pattern.index >= currentIndex) return false;
  if (!isMediaTask(pattern.media) || !isTextTask(pattern.text)) return false;
  if (!sameSpeakerForTemplateRestore(current, pattern.media)) return false;
  if (mediaTaskFingerprint(current) !== mediaTaskFingerprint(pattern.media)) return false;
  if (String(current.documentTime || current.time || "") !== String(pattern.media.documentTime || pattern.media.time || "")) return false;
  const textOffset = Number(pattern.textOffsetSeconds);
  if (!Number.isFinite(textOffset) || textOffset <= 0 || textOffset > 20) return false;
  if (!isRepeatedInviteBodyText(pattern.text.text || "")) return false;
  if (pattern.after && hasTightAfterMediaOffset(pattern)) return true;
  return hasHistoricalCompanionMediaEvidence(tasks, current, pattern);
}

function hasHistoricalCompanionMediaEvidence(tasks, current, pattern) {
  const textOffset = Number(pattern?.textOffsetSeconds);
  if (!Number.isFinite(textOffset) || textOffset <= 0 || textOffset > 20) return false;
  const currentTime = current.documentTime || current.time;
  return tasks.some((task) => {
    if (!isMediaTask(task)) return false;
    if (task === current || task === pattern.media) return false;
    if (!sameSpeakerForTemplateRestore(current, task)) return false;
    const diff = clockDiffSeconds(task.documentTime || task.time, currentTime);
    return Number.isFinite(diff) && diff > textOffset && diff - textOffset <= 10;
  });
}

function collectHistoricalInvitePatternAt(tasks, mediaIndex) {
  const media = tasks[mediaIndex];
  const text = tasks[mediaIndex + 1];
  if (!isMediaTask(media) || !isTextTask(text)) return null;
  if (!sameRepeatedTextRestoreScope(media, text)) return null;
  if (!isRepeatedInviteBodyText(text.text || "")) return null;
  const textOffsetSeconds = clockDiffSeconds(text.documentTime || text.time, media.documentTime || media.time);
  if (!Number.isFinite(textOffsetSeconds) || textOffsetSeconds <= 0 || textOffsetSeconds > 20) return null;
  return {
    key: historicalInvitePatternKey(media),
    index: mediaIndex,
    media,
    text,
    textOffsetSeconds,
    restoreTextTime: text.documentTime || text.time
  };
}

function findHistoricalInvitePatternForTask(task, patterns) {
  const key = historicalInvitePatternKey(task);
  for (let index = patterns.length - 1; index >= 0; index -= 1) {
    const pattern = patterns[index];
    if (pattern.key !== key) continue;
    const restoreTextTime = shiftClockBySeconds(task.documentTime || task.time, pattern.textOffsetSeconds);
    if (!restoreTextTime) continue;
    return { ...pattern, restoreTextTime };
  }
  return null;
}

function historicalInvitePatternKey(media) {
  return [
    normalizeInteractionKey(media?.speaker),
    mediaTaskFingerprint(media),
    String(media?.documentTime || media?.time || "")
  ].join("|");
}

function hasNearbyNonPatternTaskAfterLeadingMedia(tasks, currentIndex, current, pattern) {
  const allowedTimes = new Set([
    pattern.restoreTextTime || pattern.text?.documentTime || pattern.text?.time || "",
    pattern.restoreAfterTime || pattern.after?.documentTime || pattern.after?.time || ""
  ].filter(Boolean));
  for (let index = currentIndex + 1; index < tasks.length; index += 1) {
    const candidate = tasks[index];
    if (String(candidate?.date || "") !== String(current?.date || "") || Number(candidate?.daySegment || 1) !== Number(current?.daySegment || 1)) {
      break;
    }
    if (!sameRepeatedTextRestoreScope(current, candidate)) continue;
    const diff = clockDiffSeconds(candidate.documentTime || candidate.time, current.documentTime || current.time);
    if (!Number.isFinite(diff) || diff <= 0) continue;
    if (diff > 90) return false;
    if (allowedTimes.has(String(candidate.documentTime || candidate.time || ""))) continue;
    return true;
  }
  return false;
}

function leadingMediaTextPatternKey(media, text) {
  return [
    normalizeInteractionKey(media?.speaker),
    mediaTaskFingerprint(media),
    String(media?.documentTime || media?.time || ""),
    String(text?.documentTime || text?.time || "")
  ].join("|");
}

function hasTextTaskForPatternInSameSegment(tasks, current, pattern) {
  const textTime = String(pattern?.restoreTextTime || pattern?.text?.documentTime || pattern?.text?.time || "");
  return tasks.some((task) => {
    if (!isTextTask(task)) return false;
    if (!sameRepeatedTextRestoreScope(current, task)) return false;
    if (String(task.documentTime || task.time || "") !== textTime) return false;
    return Boolean(comparableDuplicateText(task.text || ""));
  });
}

function hasMediaTaskForPatternInSameSegment(tasks, current, pattern) {
  if (!pattern?.after) return true;
  const mediaTime = String(pattern.restoreAfterTime || pattern.after.documentTime || pattern.after.time || "");
  const mediaFingerprint = mediaTaskFingerprint(pattern.after);
  return tasks.some((task) => {
    if (!isMediaTask(task)) return false;
    if (!sameRepeatedTextRestoreScope(current, task)) return false;
    if (String(task.documentTime || task.time || "") !== mediaTime) return false;
    return mediaTaskFingerprint(task) === mediaFingerprint;
  });
}

function canRestoreAfterMediaForPattern(tasks, currentIndex, current, pattern, next) {
  if (!pattern?.after) return false;
  if (hasMediaTaskForPatternInSameSegment(tasks, current, pattern)) return false;
  if (hasNearbyMediaFingerprintInSameSegment(tasks, current, pattern.after)) return false;
  const restoreTime = pattern.restoreAfterTime || pattern.after.documentTime || pattern.after.time;
  if (!isTimeWithinAfter(restoreTime, current.documentTime || current.time, 90)) return false;
  if (next && sameRepeatedTextRestoreScope(current, next)) {
    const nextTime = next.documentTime || next.time;
    const nextFromCurrent = clockDiffSeconds(nextTime, current.documentTime || current.time);
    if (Number.isFinite(nextFromCurrent) && nextFromCurrent <= 0) return canRestoreTextAfterCurrentMedia(tasks, currentIndex, current, restoreTime);
    const restoreToNext = clockDiffSeconds(nextTime, restoreTime);
    if (Number.isFinite(restoreToNext) && restoreToNext <= 0) return false;
  }
  return canRestoreTextAfterCurrentMedia(tasks, currentIndex, current, restoreTime);
}

function hasNearbyMediaFingerprintInSameSegment(tasks, current, after) {
  const mediaFingerprint = mediaTaskFingerprint(after);
  for (const task of tasks) {
    if (!isMediaTask(task)) continue;
    if (!sameRepeatedTextRestoreScope(current, task)) continue;
    if (mediaTaskFingerprint(task) !== mediaFingerprint) continue;
    const diff = clockDiffSeconds(task.documentTime || task.time, current.documentTime || current.time);
    if (Number.isFinite(diff) && diff > 0 && diff <= 90) return true;
  }
  return false;
}

function canRestoreTextAfterCurrentMedia(tasks, currentIndex, current, restoreTime) {
  if (!restoreTime) return false;
  if (!isTimeWithinAfter(restoreTime, current.documentTime || current.time, 180)) return false;
  for (let index = currentIndex + 1; index < tasks.length; index += 1) {
    const candidate = tasks[index];
    if (sameRepeatedTextRestoreScope(current, candidate)) {
      const candidateTime = candidate.documentTime || candidate.time;
      const candidateFromCurrent = clockDiffSeconds(candidateTime, current.documentTime || current.time);
      if (Number.isFinite(candidateFromCurrent) && candidateFromCurrent <= 0) continue;
      const diff = clockDiffSeconds(candidateTime, restoreTime);
      if (Number.isFinite(diff) && diff <= 0) return false;
      return true;
    }
    if (String(candidate?.date || "") !== String(current?.date || "") || Number(candidate?.daySegment || 1) !== Number(current?.daySegment || 1)) {
      break;
    }
  }
  return true;
}

function canRestoreOutroAfterCurrentMedia(tasks, currentIndex, current, restoreTime) {
  if (!restoreTime) return false;
  if (!isTimeWithinAfter(restoreTime, current.documentTime || current.time, 180)) return false;
  for (let index = currentIndex + 1; index < tasks.length; index += 1) {
    const candidate = tasks[index];
    if (sameRepeatedTextRestoreScope(current, candidate)) {
      const candidateTime = candidate.documentTime || candidate.time;
      const candidateFromCurrent = clockDiffSeconds(candidateTime, current.documentTime || current.time);
      if (Number.isFinite(candidateFromCurrent) && candidateFromCurrent <= 0) continue;
      const diff = clockDiffSeconds(candidateTime, restoreTime);
      if (Number.isFinite(diff) && diff < 0) return false;
      if (Number.isFinite(diff) && diff === 0) {
        return isTextTask(candidate) && !isNarrowRepeatedOutroText(candidate.text || "");
      }
      return true;
    }
    if (String(candidate?.date || "") !== String(current?.date || "") || Number(candidate?.daySegment || 1) !== Number(current?.daySegment || 1)) {
      break;
    }
  }
  return true;
}

function dropDuplicateRestoredTextAtSameTime(tasks, diagnostics) {
  const result = [];
  const seen = new Map();
  const dropped = [];
  for (const task of tasks) {
    if (!isTextTask(task)) {
      result.push(task);
      continue;
    }
    const comparable = comparableDuplicateText(task.text || "");
    if (comparable.length < 18) {
      result.push(task);
      continue;
    }
    const key = [
      normalizeInteractionKey(task.speaker),
      String(task.date || ""),
      Number(task.daySegment || 1),
      String(task.documentTime || task.time || ""),
      comparable
    ].join("|");
    const previousIndex = seen.get(key);
    if (previousIndex == null) {
      seen.set(key, result.length);
      result.push(task);
      continue;
    }
    const previous = result[previousIndex];
    if (!isRestoredTextTask(task) && isRestoredTextTask(previous)) {
      dropped.push(previous.sourceId || "");
      result[previousIndex] = task;
      continue;
    }
    if (isRestoredTextTask(task) || isRestoredTextTask(previous)) {
      dropped.push(task.sourceId || "");
      continue;
    }
    result.push(task);
  }
  if (dropped.length) {
    diagnostics.push({
      code: "dropped_duplicate_restored_text_same_time",
      sourceId: dropped.filter(Boolean).join(","),
      message: "已移除同说话人同时间由补偿规则叠加生成的重复正文"
    });
  }
  return dropped.length ? result.map((task, index) => createPreviewTask({ ...task, order: index + 1 })) : tasks;
}

function mergeCollectedSupersetTextFragments(tasks, diagnostics) {
  const result = tasks.slice();
  const dropped = [];
  for (let index = 0; index < result.length; index += 1) {
    const task = result[index];
    if (!isTextTask(task) || !hasCollectedDomSource(task)) continue;
    const sourceText = cleanBodyText(task.sourceText || "");
    const sourceComparable = comparableDuplicateText(sourceText);
    const taskComparable = comparableDuplicateText(task.text || "");
    if (sourceComparable.length < 16 || taskComparable.length < 6 || !sourceComparable.includes(taskComparable)) continue;
    const candidateIndex = findSupersetMergeTarget(result, index, sourceComparable);
    if (candidateIndex < 0) continue;
    const previous = result[candidateIndex];
    const previousComparable = comparableDuplicateText(previous.text || "");
    if (sourceComparable.length <= previousComparable.length + 4) continue;
    result[candidateIndex] = createPreviewTask({
      ...previous,
      sourceId: mergeNonEmptyValues(previous.sourceId, task.sourceId),
      sourceText: mergeNonEmptyValues(previous.sourceText, task.sourceText, "\n"),
      text: normalizeMessageText(sourceText)
    });
    dropped.push(task.sourceId || "");
    result[index] = null;
  }
  if (dropped.length) {
    diagnostics.push({
      code: "merged_collected_superset_text_fragment",
      sourceId: dropped.filter(Boolean).join(","),
      message: "已用飞书重复采集到的完整正文合并被拆散的文本片段"
    });
  }
  return dropped.length
    ? result.filter(Boolean).map((task, index) => createPreviewTask({ ...task, order: index + 1 }))
    : tasks;
}

function findSupersetMergeTarget(tasks, currentIndex, sourceComparable) {
  const current = tasks[currentIndex];
  const candidates = [];
  for (let index = Math.max(0, currentIndex - 5); index < currentIndex; index += 1) {
    const candidate = tasks[index];
    if (!isTextTask(candidate) || !hasCollectedDomSource(candidate)) continue;
    if (!sameCollectedTextFragmentScope(candidate, current, 30)) continue;
    const candidateComparable = comparableDuplicateText(candidate.text || "");
    if (candidateComparable.length < 6 || !sourceComparable.includes(candidateComparable)) continue;
    candidates.push({ index, sameTime: String(candidate.documentTime || candidate.time || "") === String(current.documentTime || current.time || "") });
  }
  candidates.sort((left, right) => Number(right.sameTime) - Number(left.sameTime) || left.index - right.index);
  return candidates[0]?.index ?? -1;
}

function dropContainedCollectedTextFragments(tasks, diagnostics) {
  const result = [];
  const dropped = [];
  for (const task of tasks) {
    if (!isTextTask(task) || !hasCollectedDomSource(task)) {
      result.push(task);
      continue;
    }
    const text = comparableDuplicateText(task.text || "");
    if (text.length < 8) {
      result.push(task);
      continue;
    }
    const previous = result.findLast((candidate) => {
      if (!isTextTask(candidate) || !hasCollectedDomSource(candidate)) return false;
      if (!sameCollectedTextFragmentScope(candidate, task, 30)) return false;
      const previousText = comparableDuplicateText(candidate.text || "");
      return previousText.length > text.length + 4 && previousText.includes(text);
    });
    if (previous) {
      dropped.push(task.sourceId || "");
      continue;
    }
    result.push(task);
  }
  if (dropped.length) {
    diagnostics.push({
      code: "dropped_duplicate_text_echo",
      sourceId: dropped.filter(Boolean).join(","),
      message: "已移除飞书重复采集时被完整正文包含的短文本碎片"
    });
  }
  return dropped.length ? result.map((task, index) => createPreviewTask({ ...task, order: index + 1 })) : tasks;
}

function trimInternalRepeatedTextLines(tasks, diagnostics) {
  const changed = [];
  const result = tasks.map((task) => {
    if (!isTextTask(task) || !hasCollectedDomSource(task)) return task;
    const trimmed = trimRepeatedMeaningfulLines(task.text || "");
    if (!trimmed.changed) return task;
    changed.push(task.sourceId || "");
    return createPreviewTask({
      ...task,
      sourceText: task.sourceText || task.text || "",
      text: trimmed.text
    });
  });
  if (changed.length) {
    diagnostics.push({
      code: "trimmed_internal_duplicate_text_line",
      sourceId: changed.filter(Boolean).join(","),
      message: "已清理同一预览条内部由飞书重复采集造成的重复正文行"
    });
  }
  return result;
}

function trimRepeatedMeaningfulLines(text) {
  const lines = normalizeMessageText(text).split("\n");
  const meaningful = lines
    .map((line) => comparableDuplicateText(line))
    .filter((line) => line.length >= 8);
  if (meaningful.length < 2 || new Set(meaningful).size !== 1) {
    return { changed: false, text: normalizeMessageText(text) };
  }
  const seen = new Set();
  const next = [];
  let changed = false;
  for (const line of lines) {
    const comparable = comparableDuplicateText(line);
    if (comparable.length >= 8 && seen.has(comparable)) {
      changed = true;
      continue;
    }
    if (comparable.length >= 8) seen.add(comparable);
    next.push(line);
  }
  return { changed, text: normalizeMessageText(next.join("\n")) };
}

function sameCollectedTextFragmentScope(left, right, toleranceSeconds = 10) {
  return normalizeInteractionKey(left?.speaker) === normalizeInteractionKey(right?.speaker) &&
    String(left?.date || "") === String(right?.date || "") &&
    Number(left?.daySegment || 1) === Number(right?.daySegment || 1) &&
    areNearbyDocumentTimes(left?.documentTime || left?.time, right?.documentTime || right?.time, toleranceSeconds);
}

function isRestoredTextTask(task) {
  return isTextTask(task) && /^restored-/.test(String(task?.sourceId || ""));
}

function moveRestoredTailTextBeforeNearbyMedia(tasks, diagnostics) {
  const result = [];
  const movedSourceIds = [];
  for (const task of tasks) {
    if (!isRestoredTruncatedTailTask(task)) {
      result.push(task);
      continue;
    }
    let insertIndex = result.length;
    while (insertIndex > 0) {
      const previous = result[insertIndex - 1];
      if (!isMediaTask(previous)) break;
      if (!sameRepeatedTextRestoreScope(task, previous)) break;
      const textSeconds = clockToSeconds(task.documentTime || task.time);
      const mediaSeconds = clockToSeconds(previous.documentTime || previous.time);
      if (!Number.isFinite(textSeconds) || !Number.isFinite(mediaSeconds)) break;
      if (mediaSeconds <= textSeconds || mediaSeconds - textSeconds > 5) break;
      insertIndex -= 1;
    }
    if (insertIndex !== result.length) {
      movedSourceIds.push(task.sourceId || "");
      result.splice(insertIndex, 0, task);
      continue;
    }
    result.push(task);
  }
  if (movedSourceIds.length) {
    diagnostics.push({
      code: "restored_truncated_tail_order",
      sourceId: movedSourceIds.filter(Boolean).join(","),
      message: "已把补回的截断正文移回相邻素材前，保持原文时间顺序"
    });
  }
  return result.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

function isRestoredTruncatedTailTask(task) {
  return isTextTask(task) && String(task?.sourceId || "").startsWith("restored-truncated-tail:");
}

function findRepeatedTextTailTemplate(task, templates) {
  const text = comparableDuplicateText(task.text || "");
  if (text.length < 18) return null;
  for (let index = templates.length - 1; index >= 0; index -= 1) {
    const template = templates[index];
    if (!sameSpeakerForTemplateRestore(task, template)) continue;
    if (!areNearbyDocumentTimes(task.documentTime || task.time, template.documentTime || template.time, 5)) continue;
    const templateText = comparableDuplicateText(template.text || "");
    if (templateText.length < Math.max(80, text.length + 20)) continue;
    if (!templateText.endsWith(text)) continue;
    if (comparableTextStartsLikeTemplate(task.text || "", template.text || "")) continue;
    return template;
  }
  return null;
}

function sameSpeakerForTemplateRestore(task, template) {
  return normalizeInteractionKey(task?.speaker) === normalizeInteractionKey(template?.speaker);
}

function comparableTextStartsLikeTemplate(text, templateText) {
  const current = comparableDuplicateText(text);
  const template = comparableDuplicateText(templateText);
  return Boolean(current && template && template.startsWith(current.slice(0, Math.min(current.length, 24))));
}

function trimDirtyShortMentionEchoes(tasks, diagnostics) {
  const previousTexts = [];
  return tasks.map((task) => {
    let next = task;
    if (isTextTask(task) && hasCollectedDomSource(task)) {
      const mentionLine = extractStandaloneMentionLine(task.text || "");
      const residue = removeMentionLine(task.text || "", mentionLine);
      const comparableResidue = comparableDuplicateText(residue);
      if (mentionLine && comparableResidue.length >= 8 && previousTexts.some((previous) => previous.includes(comparableResidue))) {
        next = createPreviewTask({
          ...task,
          sourceText: task.sourceText || task.text || "",
          text: mentionLine
        });
        diagnostics.push({
          code: "trimmed_dirty_short_mention_echo",
          sourceId: task.sourceId,
          message: "已清理飞书残影粘到短提醒前面的旧正文"
        });
      }
    }
    const comparable = comparableDuplicateText(next.text || "");
    if (comparable) previousTexts.push(comparable);
    return next;
  });
}

function extractStandaloneMentionLine(text) {
  const lines = normalizeMessageText(text)
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean);
  const mentionLines = lines.filter((line) => line === "@所有人" || /^@[\p{L}\p{N}_.·-]{1,12}$/u.test(line));
  return mentionLines.length === 1 ? mentionLines[0] : "";
}

function removeMentionLine(text, mentionLine) {
  if (!mentionLine) return text;
  return normalizeMessageText(text)
    .split(/\n+/)
    .filter((line) => line.trim() !== mentionLine)
    .join("\n");
}

function sameDuplicatePrefixScope(task, previous) {
  return Number(task?.daySegment || 1) === Number(previous?.daySegment || 1) &&
    String(task?.date || "") === String(previous?.date || "");
}

function trimDuplicatePrefixText(currentText, previousText) {
  const current = comparableTextWithMap(currentText);
  const previous = comparableTextWithMap(previousText);
  if (previous.text.length < 4 || current.text.length <= previous.text.length) {
    return { changed: false, text: currentText };
  }
  if (!current.text.startsWith(previous.text)) {
    return { changed: false, text: currentText };
  }
  const cutIndex = current.map[previous.text.length - 1] || 0;
  const separator = String(currentText || "").slice(cutIndex);
  if (previous.text.length < 8 && !/^[\s\r\n]*\n[\s\r\n]*/.test(separator)) {
    return { changed: false, text: currentText };
  }
  const remainder = separator.replace(/^[\s\r\n]+/, "");
  if (comparableDuplicateText(remainder).length < 2) {
    return { changed: false, text: currentText };
  }
  return { changed: true, text: normalizeMessageText(remainder) };
}

function trimDuplicateSuffixText(task, previousTexts) {
  const normalized = normalizeMessageText(task?.text || "").trim();
  const lines = normalized.split("\n");
  if (lines.filter((line) => line.trim()).length < 2) {
    return { changed: false, text: task?.text || "" };
  }
  for (let index = 1; index < lines.length; index += 1) {
    const prefix = normalizeMessageText(lines.slice(0, index).join("\n")).trim();
    const suffix = normalizeMessageText(lines.slice(index).join("\n")).trim();
    const prefixComparable = comparableDuplicateText(prefix);
    const suffixComparable = comparableDuplicateText(suffix);
    if (prefixComparable.length < 4 || suffixComparable.length < 14) continue;
    const previous = previousTexts.find((item) => isDirtySuffixEchoOf(task, item, prefixComparable, suffixComparable));
    if (!previous) continue;
    return { changed: true, text: prefix, previous };
  }
  return { changed: false, text: task?.text || "" };
}

function isDirtySuffixEchoOf(task, previous, prefixComparable, suffixComparable) {
  if (!sameDuplicatePrefixScope(task, previous)) return false;
  if (samePreviewTaskContext(task, previous) && areNearbyDocumentTimes(task?.documentTime || task?.time, previous?.documentTime || previous?.time, 30)) {
    return false;
  }
  const previousComparable = comparableDuplicateText(previous?.text || "");
  if (previousComparable.length < Math.max(14, suffixComparable.length)) return false;
  if (previousComparable.includes(prefixComparable)) return false;
  if (previousComparable === suffixComparable) return true;
  return suffixComparable.length >= 18 && previousComparable.includes(suffixComparable);
}

function comparableTextWithMap(text) {
  const normalized = normalizeMessageText(text);
  const chars = [];
  const map = [];
  for (let index = 0; index < normalized.length; index += 1) {
    const char = normalized[index];
    if (/\s/.test(char)) continue;
    chars.push(char);
    map.push(index + 1);
  }
  return {
    text: chars.join(""),
    map
  };
}

function comparableDuplicateText(text) {
  return normalizeMessageText(text)
    .replace(/\s+/g, "")
    .trim();
}

function looksLikeDuplicateTextEcho(task) {
  if (!hasCollectedDomSource(task)) return false;
  const sourceIds = String(task?.sourceId || "")
    .split(",")
    .map((sourceId) => sourceId.trim())
    .filter(Boolean);
  if (sourceIds.length >= 8) return true;
  const sourceText = String(task?.sourceText || "");
  return (sourceText.match(/\n\s*\n/g) || []).length >= 4;
}

function isDirtyDuplicateTextEchoOf(task, previous) {
  const text = comparableDuplicateText(task?.text || "");
  if (!text || text.length > 80) return false;
  if (text !== comparableDuplicateText(previous?.text || "")) return false;
  if (Number(task?.daySegment || 1) !== Number(previous?.daySegment || 1)) return false;
  if (String(task?.date || "") !== String(previous?.date || "")) return false;
  if (areNearbyDocumentTimes(task?.documentTime || task?.time, previous?.documentTime || previous?.time, 10)) return true;
  if (normalizeInteractionKey(task?.speaker) !== normalizeInteractionKey(previous?.speaker) && looksLikeDuplicateTextEcho(task)) return true;
  const taskDocumentDate = String(task?.documentDate || "").trim();
  const previousDocumentDate = String(previous?.documentDate || "").trim();
  return Boolean(taskDocumentDate && previousDocumentDate && taskDocumentDate !== previousDocumentDate && looksLikeDuplicateTextEcho(task));
}

function isContainedDirtyTextEchoOf(task, previous) {
  const text = comparableDuplicateText(task?.text || "");
  const previousText = comparableDuplicateText(previous?.text || "");
  if (text.length < 8 || previousText.length < 16 || text.length >= previousText.length) return false;
  if (!previousText.includes(text)) return false;
  if (Number(task?.daySegment || 1) !== Number(previous?.daySegment || 1)) return false;
  if (String(task?.date || "") !== String(previous?.date || "")) return false;
  if (normalizeInteractionKey(task?.speaker) !== normalizeInteractionKey(previous?.speaker)) return false;
  if (areNearbyDocumentTimes(task?.documentTime || task?.time, previous?.documentTime || previous?.time, 10)) return true;
  return false;
}

function areNearbyDocumentTimes(left, right, toleranceSeconds) {
  const leftSeconds = clockToSeconds(left);
  const rightSeconds = clockToSeconds(right);
  if (!Number.isFinite(leftSeconds) || !Number.isFinite(rightSeconds)) return false;
  return Math.abs(leftSeconds - rightSeconds) <= toleranceSeconds;
}

function clockToSeconds(value) {
  const match = String(value || "").trim().match(/^(\d{1,2})[:：](\d{1,2})(?:[:：](\d{1,2}))?$/);
  if (!match) return null;
  return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0);
}

function looksLikeDuplicateTextPrefixEcho(task) {
  return hasCollectedDomSource(task);
}

function isCollectedDateHeadingResidue(event, baseSendDate, events = [], eventIndex = -1) {
  if (!event || (event.kind || event.type) !== "line") return false;
  if (!String(event.collectSpeaker || "").trim() || !String(event.collectTime || "").trim()) return false;
  const marker = classifyChangeDayMarkerEvent(event, baseSendDate);
  if (marker?.isHeading !== true) return false;
  return !isFollowedByNewExplicitRoleHeader(events, eventIndex);
}

function isFollowedByNewExplicitRoleHeader(events, eventIndex) {
  if (!Array.isArray(events) || eventIndex < 0) return false;
  for (let index = eventIndex + 1; index < Math.min(events.length, eventIndex + 16); index += 1) {
    const next = events[index];
    if (!next) continue;
    if ((next.kind || next.type) !== "line") continue;
    if (!String(next.text || next.sourceText || "").trim()) continue;
    return Boolean(detectRoleHeader(next, { allowBareNameHeaders: false }));
  }
  return false;
}

function mergeCollectedTextFragmentsSeparatedByMedia(tasks, diagnostics) {
  const result = [];
  for (let index = 0; index < tasks.length; index += 1) {
    const task = tasks[index];
    if (!isTextTask(task)) {
      result.push(task);
      continue;
    }

    const mediaTasks = [];
    let cursor = index + 1;
    let merged = { ...task };
    let didMerge = false;
    while (cursor < tasks.length) {
      const candidate = tasks[cursor];
      if (isMediaTask(candidate)) {
        mediaTasks.push(candidate);
        cursor += 1;
        continue;
      }
      if (!mediaTasks.length || !isInterleavedCollectedTextFragment(merged, candidate, mediaTasks)) break;
      merged = mergeTextPreviewTasks(merged, candidate);
      diagnostics.push({
        code: "merged_interleaved_text_fragment",
        sourceId: candidate.sourceId,
        message: "已合并飞书同一消息中被媒体块隔开的续文"
      });
      didMerge = true;
      cursor += 1;
    }

    if (!didMerge) {
      result.push(task);
      continue;
    }
    result.push(merged, ...mediaTasks);
    index = cursor - 1;
  }
  return result;
}

function isInterleavedCollectedTextFragment(left, right, mediaTasks) {
  if (!isTextTask(left) || !isTextTask(right)) return false;
  if (!mediaTasks.length || mediaTasks.some((task) => !isMediaTask(task))) return false;
  if (!samePreviewTaskContext(left, right)) return false;
  if (String(left.role || "") !== String(right.role || "")) return false;
  if (String(left.documentDate || "") !== String(right.documentDate || "")) return false;
  if (String(left.documentTime || "") !== String(right.documentTime || "")) return false;
  if (Number(left.daySegment || 1) !== Number(right.daySegment || 1)) return false;
  return [left, right, ...mediaTasks].some(hasCollectedDomSource);
}

function mergeTextPreviewTasks(left, right) {
  return {
    ...left,
    sourceId: mergeNonEmptyValues(left.sourceId, right.sourceId),
    sourceText: mergeNonEmptyValues(left.sourceText, right.sourceText, "\n"),
    text: normalizeMessageText([left.text, right.text].filter((value) => String(value || "").trim()).join("\n"))
  };
}

function mergeNonEmptyValues(left, right, separator = ",") {
  const values = [left, right]
    .flatMap((value) => String(value || "").split(separator))
    .map((value) => value.trim())
    .filter(Boolean);
  return [...new Set(values)].join(separator);
}

function isTextTask(task) {
  return task?.type === "text";
}

function isMediaTask(task) {
  return task?.type === "image" || task?.type === "sticker" || task?.type === "video";
}

function hasCollectedDomSource(task) {
  return String(task?.sourceId || "")
    .split(",")
    .some((sourceId) => /^(?:dom-block|feishu-block)-/.test(sourceId.trim()));
}

function samePreviewTaskContext(left, right) {
  return normalizeInteractionKey(left?.speaker) === normalizeInteractionKey(right?.speaker) &&
    String(left?.date || "") === String(right?.date || "") &&
    String(left?.time || "") === String(right?.time || "");
}

function cleanBodyText(text) {
  return String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/（[^）]*下面还说话[^）]*）/g, "")
    .replace(/\([^)]*下面还说话[^)]*\)/g, "")
    .replace(/【[^】]*下面还说话[^】]*】/g, "")
    .replace(/\[[^\]]*下面还说话[^\]]*\]/g, "")
    .replace(/下面还说话/g, "")
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => !isInternalXmlBodyLine(line))
    .join("\n");
}

function preserveInlineBodyText(text) {
  return String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .trim();
}

function isInternalXmlBodyLine(line) {
  const text = String(line || "")
    .trim()
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
  if (!text) return false;
  if (/^<\?xml\b[^>]*\?>$/i.test(text)) return true;
  if (/^<\/[a-z][\w:-]*>$/i.test(text)) return true;
  if (/^<[a-z][\w:-]*(?:\s+[^>]*)?>$/i.test(text)) return true;
  if (/^<[a-z][\w:-]*(?:\s+[^>]*)?\s*\/>$/i.test(text)) return true;
  return /^<([a-z][\w:-]*)(?:\s+[^>]*)?>[\s\S]*<\/\1>$/i.test(text);
}

function trimOuterBlankLines(text) {
  const lines = String(text || "").split("\n");
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines.at(-1).trim()) lines.pop();
  return lines.join("\n");
}

function makeMediaTask(segment, event, order) {
  const sourceUrl = firstStableSourceUrl(
    event.sourceUrl,
    event.raw?.sourceUrl,
    event.raw?.originalMediaPath,
    event.raw?.originalBlobMediaPath,
    event.assetUrl
  );
  const previewError = String(event.previewError || event.raw?.previewError || "").trim();
  const previewWarning = String(event.previewWarning || event.raw?.previewWarning || "").trim();
  return createPreviewTask({
    sourceId: event.sourceId,
    sourceOccurrenceIds: sourceOccurrenceIdsFrom(event),
    sourceText: event.sourceText || segment.sourceText,
    role: segment.role,
    speaker: segment.speaker,
    sourceSpeaker: segment.sourceSpeaker || segment.speaker,
    speakerStatus: segment.speakerStatus || "confirmed",
    date: segment.date,
    documentDate: segment.documentDate,
    documentTime: segment.documentTime,
    daySegment: segment.daySegment,
    sourceDayHeadingSegment: segment.sourceDayHeadingSegment,
    sourceDayHeadingLabel: segment.sourceDayHeadingLabel,
    time: segment.time,
    type: mediaTaskType(event),
    text: "",
    mediaPath: event.mediaPath || event.assetUrl,
    sourceUrl,
    skip: false,
    order,
    interactionGroup: segment.interactionGroup,
    continueMarker: segment.continueMarker,
    cleanSpeaker: segment.cleanSpeaker,
    speakerConfidence: segment.speakerConfidence,
    personaHint: segment.personaHint,
    ...(event.mediaRecoveryState ? { mediaRecoveryState: String(event.mediaRecoveryState) } : {}),
    ...(event.mediaRecoveryMessage ? { mediaRecoveryMessage: String(event.mediaRecoveryMessage) } : {}),
    ...(Number(event.mediaRetryAfterMs || 0) > 0 ? { mediaRetryAfterMs: Number(event.mediaRetryAfterMs) } : {}),
    ...(previewError ? { previewError } : {}),
    ...(previewWarning ? { previewWarning } : {}),
    _visualTop: eventVisualTop(event),
    _eventOrder: eventOrder(event)
  });
}

function extractFinderXml(text) {
  const raw = String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
  if (!looksLikeFinderXml(raw)) return "";
  const lines = raw.split("\n")
    .map((line) => line.replace(/^\s*\d+\s(?=\s*(?:<|\{))/, "").trimEnd())
    .filter((line) => {
      const compact = line.trim().replace(/\s+/g, "");
      if (!compact) return true;
      return !/^(示例代码|复制|自动换行|Python|JavaScript|Markdown|代码块)$/.test(compact);
    });
  const start = lines.findIndex((line) => /^\s*(?:<\?xml\b|<msg\b)/i.test(line));
  if (start < 0) return "";
  let end = lines.length - 1;
  for (let index = lines.length - 1; index >= start; index -= 1) {
    if (/<\/msg>\s*$/i.test(lines[index]) || /<\/appmsg>\s*$/i.test(lines[index])) {
      end = index;
      break;
    }
  }
  const xml = lines.slice(start, end + 1).join("\n").trim();
  return looksLikeFinderXml(xml) ? sanitizeFinderXmlEntities(xml) : "";
}

function isFinderXmlStart(text) {
  return /^\s*(?:<\?xml\b|<msg\b)/i.test(String(text || ""));
}

function looksLikeFinderXml(text) {
  const value = String(text || "");
  return /<msg\b/i.test(value) &&
    /<appmsg\b/i.test(value) &&
    (/<finderFeed\b/i.test(value) || /<type>\s*51\s*<\/type>/i.test(value));
}

function sanitizeFinderXmlEntities(text) {
  return String(text || "").replace(/&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9a-fA-F]+;)/g, "&amp;");
}

function isFinderCopiedXmlTrailingNoise(text) {
  const compact = String(text || "").trim().replace(/\s+/g, "");
  return !compact || /^(加载中|加载中\.{1,3}|Loading\.{0,3})$/i.test(compact);
}

function isCompleteFinderXml(text) {
  const value = String(text || "");
  return looksLikeFinderXml(value) && /<\/msg>\s*$/i.test(value.trim());
}

function isCodeBlockChromeText(text) {
  const compact = String(text || "").trim().replace(/\s+/g, "");
  const codeLanguage = "(?:Python|JavaScript|Markdown|XML|HTML|JSON)";
  return /^(示例代码|复制|自动换行|Python|JavaScript|Markdown|XML|HTML|JSON|代码块)$/i.test(compact) ||
    new RegExp(`^(?:${codeLanguage})?自动换行复制$`, "i").test(compact) ||
    new RegExp(`^(?:示例代码|代码块)(?:${codeLanguage})?(?:自动换行)?(?:复制)?$`, "i").test(compact);
}

function looksLikeXmlCodeLine(text) {
  const value = String(text || "").trim();
  return /^\d+\s*</.test(value) || /^<\??[a-z!/]/i.test(value) || /^<\/[a-z]/i.test(value);
}

function isFeishuStickerImageEcho(event, previous, next) {
  if (event?.kind !== "image") return false;
  return isDuplicateStickerImagePair(event, previous) || isDuplicateStickerImagePair(event, next);
}

function mediaTaskType(event) {
  if (event?.kind === "image" && hasExplicitStickerMarker(event)) return "sticker";
  return event.kind;
}

function applyStandaloneStickerLabel(segment, event, previous, task) {
  if (String(event.text || "").trim() !== "表情包") return false;
  if (!["image", "sticker"].includes(previous?.kind) || !["image", "sticker"].includes(task?.type)) return false;
  // Only the immediately preceding emitted image in the current message can own the label.
  if (task.sourceId !== previous.sourceId || task.speaker !== segment.speaker
    || task.documentTime !== segment.documentTime) return false;
  for (const source of [previous, event]) {
    const collected = String(source.collectSpeaker || "").trim();
    const speaker = parseExplicitTimedRoleHeaderLine(`${collected} ${source.collectTime || ""}`.trim())?.speaker || collected;
    if (speaker && speaker.replace(/\s+/g, "") !== segment.speaker.replace(/\s+/g, "")) return false;
    if (source.collectTime && normalizeClock(source.collectTime) !== normalizeClock(segment.documentTime)) return false;
  }
  task.type = "sticker";
  return true;
}

function hasExplicitStickerMarker(event) {
  const text = [
    event?.text,
    event?.sourceText,
    event?.raw?.text,
    event?.raw?.sourceText,
    event?.raw?.parentText
  ].map((value) => String(value || "").trim()).join("\n");
  return /^(表情包|动态表情)$/m.test(text) || /表情包形式/.test(text);
}

function isFeishuVideoCoverEcho(event, previous, next) {
  if (event?.kind !== "video") return false;
  if (hasRealVideoMediaSource(event)) return false;
  if (looksLikeVideoCoverMedia(event)) {
    const adjacentRealVideo = [previous, next].find((item) => item?.kind === "video" && hasRealVideoMediaSource(item));
    if (adjacentRealVideo && (sameCollectContext(event, adjacentRealVideo) || areNearbyEvents(event, adjacentRealVideo))) return true;
  }
  return isDuplicateVideoCoverPair(event, previous) || isDuplicateVideoCoverPair(event, next);
}

function isDuplicateVideoCoverPair(left, right) {
  if (!left || !right) return false;
  if (hasDistinctSourceOccurrences(left, right)) return false;
  const kinds = new Set([left.kind, right.kind]);
  if (!kinds.has("video")) return false;
  const cover = hasRealVideoMediaSource(left) ? right : left;
  const video = hasRealVideoMediaSource(left) ? left : right;
  if (!hasRealVideoMediaSource(video) || !looksLikeVideoCoverMedia(cover)) return false;
  if (String(cover.collectSpeaker || "") !== String(video.collectSpeaker || "")) return false;
  if (String(cover.collectTime || "") !== String(video.collectTime || "")) return false;
  return eventsOverlapAtSameVisualPosition(cover, video) || areNearbyEvents(cover, video);
}

function isDuplicateStickerImagePair(left, right) {
  if (!left || !right) return false;
  if (hasDistinctSourceOccurrences(left, right)) return false;
  const kinds = new Set([left.kind, right.kind]);
  if (!kinds.has("sticker") || !kinds.has("image")) return false;
  if (String(left.collectSpeaker || "") !== String(right.collectSpeaker || "")) return false;
  if (String(left.collectTime || "") !== String(right.collectTime || "")) return false;
  if (!eventsOverlapAtSameVisualPosition(left, right)) return false;
  return hasFeishuCoverSource(left) !== hasFeishuCoverSource(right) && hasTemporaryInlineImageSource(left, right);
}

function isDuplicateSameMessageMediaEcho(event, previous) {
  if (!isMediaEvent(event) || !isMediaEvent(previous)) return false;
  if (hasDistinctSourceOccurrences(event, previous)) return false;
  if (!sameCollectContext(event, previous)) return false;
  if (!areNearbyEvents(event, previous)) return false;
  const eventIdentity = mediaEventIdentity(event);
  const previousIdentity = mediaEventIdentity(previous);
  if (eventIdentity && previousIdentity && eventIdentity === previousIdentity) return true;
  return eventsShareSameMediaBox(event, previous);
}

function hasDistinctSourceOccurrences(left, right) {
  const leftRefs = sourceOccurrenceIdsFrom(left);
  const rightRefs = sourceOccurrenceIdsFrom(right);
  if (!leftRefs.length || !rightRefs.length) return false;
  const rightSet = new Set(rightRefs);
  return !leftRefs.some((ref) => rightSet.has(ref));
}

function dropFloatingVideoPlayerEvents(events, diagnostics) {
  const droppedEvents = new Set();
  const groups = new Map();
  for (const event of events) {
    const key = repeatedFloatingVideoPlayerKey(event);
    if (!key) continue;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(event);
  }

  const droppedKeys = new Set();
  for (const [key, group] of groups.entries()) {
    const contexts = new Set(group
      .map((event) => `${normalizeInteractionKey(event.collectSpeaker)}|${normalizeClock(event.collectTime)}`)
      .filter((value) => value !== "|"));
    if (group.length < 3 || contexts.size < 2) continue;
    for (const event of group) droppedEvents.add(event);
    droppedKeys.add(key);
    diagnostics.push({
      code: "dropped_repeated_floating_video_player",
      sourceId: group[0]?.sourceId || "",
      message: "已忽略飞书浮层视频控件被重复采集成多条素材"
    });
  }

  const contextTops = collectNonEmptyTextContextTops(events);
  for (const event of events) {
    if (droppedEvents.has(event)) continue;
    if (isDetachedTinyTopUiMediaEvent(event)) {
      droppedEvents.add(event);
      diagnostics.push({
        code: "dropped_detached_tiny_top_ui_media",
        sourceId: event.sourceId,
        message: "已忽略飞书页面顶部小图残影，避免头像/工具栏素材进入预览"
      });
      continue;
    }
    if (!isDetachedFloatingVideoPlayerEvent(event, contextTops)) continue;
    droppedEvents.add(event);
    diagnostics.push({
      code: "dropped_detached_floating_video_player",
      sourceId: event.sourceId,
      message: "已忽略飞书播放器浮层视频残留，避免挂到相邻文字消息下"
    });
  }

  if (!droppedEvents.size && !droppedKeys.size) return events;
  return events.filter((event) => !droppedEvents.has(event));
}

function isDetachedTinyTopUiMediaEvent(event) {
  if (!isMediaEvent(event)) return false;
  const sourceId = String(event?.sourceId || "");
  if (!sourceId.startsWith("dom-block-") && !sourceId.startsWith("feishu-block-")) return false;
  const box = normalizedEventBox(event);
  if (!box) return false;
  if (box.y > 80) return false;
  if (box.x < 1200) return false;
  if (box.width > 80 || box.height > 80) return false;
  const source = [
    event?.sourceUrl,
    event?.raw?.sourceUrl,
    event?.assetUrl,
    event?.raw?.assetUrl
  ].map((value) => String(value || "")).join("\n");
  return /s3-imfile\.feishucdn\.com|sticker_format=|static-resource/i.test(source);
}

function repeatedFloatingVideoPlayerKey(event) {
  if (event?.kind !== "video") return "";
  if (!hasRealVideoMediaSource(event)) return "";
  if (!looksLikeVideoPlayerChromeOnlyText(event)) return "";
  const sourceId = String(event.sourceId || "").trim();
  const identity = mediaEventIdentity(event);
  const boxKey = normalizedEventBoxKey(event);
  if (!sourceId || !identity || !boxKey) return "";
  return `${sourceId}|${identity}|${boxKey}`;
}

function collectNonEmptyTextContextTops(events) {
  const result = new Map();
  for (const event of events) {
    if (event?.kind !== "line" && event?.kind !== "title") continue;
    const text = String(event.text || event.sourceText || "").trim();
    if (!text) continue;
    const key = collectContextKey(event);
    if (!key) continue;
    const box = normalizedEventBox(event);
    if (!box) continue;
    const previous = result.get(key);
    if (!Number.isFinite(previous) || box.y < previous) result.set(key, box.y);
  }
  return result;
}

function collectContextKey(event) {
  const speaker = normalizeInteractionKey(event?.collectSpeaker);
  const time = normalizeClock(event?.collectTime);
  return speaker && time ? `${speaker}|${time}` : "";
}

function isDetachedFloatingVideoPlayerEvent(event, contextTops) {
  if (event?.kind !== "video") return false;
  if (!hasRealVideoMediaSource(event)) return false;
  if (!looksLikeVideoPlayerChromeOnlyText(event)) return false;
  if (!isFeishuDriveVideoSource(event)) return false;
  const contextTop = contextTops.get(collectContextKey(event));
  if (!Number.isFinite(contextTop)) return false;
  const box = normalizedEventBox(event);
  if (!box) return false;
  const bottom = box.y + box.height;
  return bottom + 80 < contextTop;
}

function isFeishuDriveVideoSource(event) {
  const text = [
    event?.mediaPath,
    event?.assetUrl,
    event?.sourceUrl,
    event?.raw?.mediaPath,
    event?.raw?.assetUrl,
    event?.raw?.sourceUrl
  ].map((value) => String(value || "")).join("\n");
  return /internal-api-drive-stream\.feishu\.cn\/space\/api\/box\/stream\/download\/video\//i.test(text);
}

function looksLikeVideoPlayerChromeOnlyText(event) {
  const lines = [
    event?.text,
    event?.sourceText,
    event?.raw?.text,
    event?.raw?.sourceText
  ].flatMap((value) => String(value || "").split(/\r?\n/))
    .map((line) => line.trim())
    .filter(Boolean);
  if (!lines.length || lines.length > 4) return false;
  return lines.every((line) => /^[a-f0-9]{16,}$/i.test(line) || /^\d{1,2}:\d{2}(?::\d{2})?$/.test(line));
}

function normalizedEventBoxKey(event) {
  const box = normalizedEventBox(event);
  if (!box) return "";
  return [
    Math.round(box.x),
    Math.round(box.y),
    Math.round(box.width),
    Math.round(box.height)
  ].join(",");
}

function isMediaEvent(event) {
  return event?.kind === "image" || event?.kind === "sticker" || event?.kind === "video";
}

function mediaEventIdentity(event) {
  const materializedHash = String(event?.materializedHash || event?.raw?.materializedHash || "").trim();
  if (materializedHash) return `hash:${materializedHash}`;
  const fileHash = [
    event?.mediaPath,
    event?.assetUrl,
    event?.sourceUrl,
    event?.raw?.mediaPath,
    event?.raw?.assetUrl,
    event?.raw?.sourceUrl
  ].map((value) => String(value || ""))
    .join("\n")
    .match(/-(?:image|sticker|video)-([a-f0-9]{10,})(?:\.[a-z0-9]+)?/i)?.[1];
  if (fileHash) return `hash:${fileHash.toLowerCase()}`;
  const stableUrl = firstStableSourceUrl(
    event?.sourceUrl,
    event?.raw?.sourceUrl,
    event?.assetUrl,
    event?.raw?.assetUrl,
    event?.mediaPath,
    event?.raw?.mediaPath
  );
  return stableUrl ? `url:${normalizeMediaIdentityUrl(stableUrl)}` : "";
}

function normalizeMediaIdentityUrl(value) {
  return String(value || "").trim().replace(/[?#].*$/, "");
}

function hasRealVideoMediaSource(event) {
  const text = [
    event?.mediaPath,
    event?.assetUrl,
    event?.sourceUrl,
    event?.raw?.mediaPath,
    event?.raw?.assetUrl,
    event?.raw?.sourceUrl
  ].map((value) => String(value || "")).join("\n");
  const lower = text.toLowerCase();
  return lower.includes(".mp4") || lower.includes("/video/") || lower.includes("quality=");
}

function looksLikeVideoCoverMedia(event) {
  const text = [
    event?.mediaPath,
    event?.assetUrl,
    event?.sourceUrl,
    event?.raw?.mediaPath,
    event?.raw?.assetUrl,
    event?.raw?.sourceUrl
  ].map((value) => String(value || "")).join("\n");
  const lower = text.toLowerCase();
  return [".jpg", ".jpeg", ".png", ".webp"].some((ext) => lower.includes(ext)) ||
    lower.includes("/cover/") ||
    lower.includes("/preview/");
}

function eventsOverlapAtSameVisualPosition(left, right) {
  const leftBox = left.boundingInfo || {};
  const rightBox = right.boundingInfo || {};
  const leftY = Number(left.y ?? leftBox.y);
  const rightY = Number(right.y ?? rightBox.y);
  if (Number.isFinite(leftY) && Number.isFinite(rightY) && Math.abs(leftY - rightY) <= 2) return true;
  const leftTop = Number(leftBox.y);
  const rightTop = Number(rightBox.y);
  const leftBottom = leftTop + Number(leftBox.height || 0);
  const rightBottom = rightTop + Number(rightBox.height || 0);
  if (![leftTop, rightTop, leftBottom, rightBottom].every(Number.isFinite)) return false;
  return Math.max(leftTop, rightTop) <= Math.min(leftBottom, rightBottom);
}

function areNearbyEvents(left, right) {
  const leftY = Number(left?.y ?? left?.boundingInfo?.y);
  const rightY = Number(right?.y ?? right?.boundingInfo?.y);
  if (Number.isFinite(leftY) && Number.isFinite(rightY) && Math.abs(leftY - rightY) <= 80) return true;
  const leftOrder = Number(left?.order);
  const rightOrder = Number(right?.order);
  return Number.isFinite(leftOrder) && Number.isFinite(rightOrder) && Math.abs(leftOrder - rightOrder) <= 1;
}

function sameCollectContext(left, right) {
  const leftSpeaker = String(left?.collectSpeaker || "").replace(/\s+/g, "");
  const rightSpeaker = String(right?.collectSpeaker || "").replace(/\s+/g, "");
  const leftTime = String(left?.collectTime || "").trim();
  const rightTime = String(right?.collectTime || "").trim();
  return Boolean(leftSpeaker && rightSpeaker && leftSpeaker === rightSpeaker && leftTime && rightTime && leftTime === rightTime);
}

function eventsShareSameMediaBox(left, right) {
  const leftBox = normalizedEventBox(left);
  const rightBox = normalizedEventBox(right);
  if (!leftBox || !rightBox) return false;
  const leftCenterX = leftBox.x + leftBox.width / 2;
  const leftCenterY = leftBox.y + leftBox.height / 2;
  const rightCenterX = rightBox.x + rightBox.width / 2;
  const rightCenterY = rightBox.y + rightBox.height / 2;
  if (Math.abs(leftCenterX - rightCenterX) <= 8 && Math.abs(leftCenterY - rightCenterY) <= 8) return true;
  const overlapWidth = Math.max(0, Math.min(leftBox.x + leftBox.width, rightBox.x + rightBox.width) - Math.max(leftBox.x, rightBox.x));
  const overlapHeight = Math.max(0, Math.min(leftBox.y + leftBox.height, rightBox.y + rightBox.height) - Math.max(leftBox.y, rightBox.y));
  const overlapArea = overlapWidth * overlapHeight;
  const minArea = Math.min(leftBox.width * leftBox.height, rightBox.width * rightBox.height);
  return minArea > 0 && overlapArea / minArea >= 0.7;
}

function normalizedEventBox(event) {
  const box = event?.boundingInfo || {};
  const x = Number(box.x);
  const y = Number(box.y ?? event?.y);
  const width = Number(box.width);
  const height = Number(box.height);
  if (![x, y, width, height].every(Number.isFinite) || width <= 0 || height <= 0) return null;
  return { x, y, width, height };
}

function eventVisualTop(event) {
  const box = normalizedEventBox(event);
  if (box) return box.y;
  const y = Number(event?.y ?? event?.raw?.y);
  return Number.isFinite(y) ? y : null;
}

function eventOrder(event) {
  const order = Number(event?.order ?? event?.raw?.order);
  return Number.isFinite(order) ? order : null;
}

function hasFeishuCoverSource(event) {
  return /internal-api-drive-stream\.feishu\.cn\/space\/api\/box\/stream\/download\/v2\/cover\//i.test([
    event.sourceUrl,
    event.assetUrl,
    event.mediaPath,
    event.raw?.sourceUrl,
    event.raw?.assetUrl,
    event.raw?.mediaPath
  ].map((value) => String(value || "")).join("\n"));
}

function hasTemporaryInlineImageSource(...events) {
  return events.some((event) => {
    const text = [event.sourceUrl, event.assetUrl, event.mediaPath, event.raw?.sourceUrl, event.raw?.assetUrl, event.raw?.mediaPath]
      .map((value) => String(value || ""))
      .join("\n");
    return Boolean(event.inlineMediaDataUrl || event.raw?.inlineMediaDataUrl || /(^|\n)(blob:|image-blob:)/i.test(text));
  });
}

function firstStableSourceUrl(...values) {
  for (const value of values) {
    const text = String(value || "").trim();
    if (!text || /^(blob:|image-blob:)/i.test(text)) continue;
    return text;
  }
  return "";
}

function normalizeInteractionKey(speaker) {
  return String(speaker || "").replace(/\s+/g, "").toLowerCase();
}

function normalizeClock(time) {
  const match = String(time || "").trim().match(/^(\d{1,2})[:：](\d{1,2})(?:[:：](\d{1,2}))?$/);
  if (!match) return String(time || "").trim();
  return `${String(match[1]).padStart(2, "0")}:${String(match[2]).padStart(2, "0")}:${String(match[3] || "00").padStart(2, "0")}`;
}

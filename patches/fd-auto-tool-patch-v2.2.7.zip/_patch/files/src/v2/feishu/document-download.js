import fs from "node:fs/promises";
import path from "node:path";

export async function downloadFeishuDocumentForImport(page, options = {}) {
  const runDir = options.runDir || process.cwd();
  const timeoutMs = Number(options.timeoutMs || 45000);
  const onProgress = typeof options.onProgress === "function" ? options.onProgress : async () => {};
  await onProgress("正在打开飞书下载菜单");
  await page.waitForLoadState("domcontentloaded", { timeout: Math.min(timeoutMs, 15000) }).catch(() => {});
  await openFeishuDownloadMenu(page, { timeoutMs: Math.min(timeoutMs, 20000), onProgress });
  await onProgress("正在点击飞书“下载为 Word”");
  const download = await clickFeishuDownloadFormat(page, "Word", { timeoutMs, onProgress });
  const suggested = sanitizeFileName(download.suggestedFilename?.() || "feishu-document.docx");
  const ext = path.extname(suggested).toLowerCase() || ".docx";
  const targetPath = path.join(runDir, `feishu-download${ext}`);
  await download.saveAs(targetPath);
  await onProgress(`飞书文档已下载：${suggested}`);
  return {
    fileName: suggested,
    filePath: targetPath,
    contentType: contentTypeFromExtension(ext),
    contentBase64: await fileToBase64(targetPath),
    downloadedAt: new Date().toISOString()
  };
}

async function openFeishuDownloadMenu(page, options = {}) {
  if (await isTextVisible(page, "下载为")) return;
  const moreSelectors = [
    "[aria-label*='更多']",
    "[title*='更多']",
    "button:has-text('更多')",
    "[role='button']:has-text('更多')",
    "[aria-label*='More']",
    "[title*='More']",
    "[data-testid*='more']",
    "[class*='more']"
  ];
  for (const selector of moreSelectors) {
    if (await clickFirstVisible(page.locator(selector), { timeoutMs: 1200 })) {
      if (await waitForText(page, "下载为", 3000)) return;
    }
  }
  const clicked = await clickRightMostMoreLikeButton(page);
  if (clicked && await waitForText(page, "下载为", 3000)) return;
  throw new Error("没有找到飞书“更多/下载为”菜单。请确认当前账号有文档下载权限，且页面已打开目标飞书文档。");
}

async function clickFeishuDownloadFormat(page, formatText, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 45000);
  const onProgress = typeof options.onProgress === "function" ? options.onProgress : async () => {};
  const downloadMenu = page.getByText("下载为", { exact: true }).first();
  await downloadMenu.hover({ timeout: 5000 }).catch(async () => {
    await downloadMenu.click({ timeout: 5000 });
  });
  await waitForText(page, formatText, 3000);
  const format = page.getByText(formatText, { exact: true }).first();
  const downloadPromise = page.waitForEvent("download", { timeout: timeoutMs });
  await format.click({ timeout: 8000 });
  await Promise.race([
    downloadPromise.then(() => "download-started"),
    confirmFeishuExportDialog(page, { timeoutMs: Math.min(12000, timeoutMs), onProgress }).then(() => "export-confirmed")
  ]).catch(() => null);
  await onProgress("正在等待飞书生成并下载 Word 文件");
  return await downloadPromise;
}

async function confirmFeishuExportDialog(page, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 12000);
  const onProgress = typeof options.onProgress === "function" ? options.onProgress : async () => {};
  const exportButton = page.getByRole("button", { name: /^导出$/ }).last();
  const hasExportDialog = await Promise.race([
    waitForText(page, "导出 Word 设置", timeoutMs),
    exportButton.waitFor({ state: "visible", timeout: timeoutMs }).then(() => true).catch(() => false)
  ]).catch(() => false);
  if (!hasExportDialog) return false;
  await onProgress("飞书弹出导出 Word 设置，正在自动确认导出");
  await exportButton.click({ timeout: 8000 });
  return true;
}

async function clickFirstVisible(locator, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 1000);
  const count = await locator.count().catch(() => 0);
  for (let index = 0; index < Math.min(count, 8); index += 1) {
    const item = locator.nth(index);
    const visible = await item.isVisible({ timeout: Math.min(timeoutMs, 500) }).catch(() => false);
    if (!visible) continue;
    await item.click({ timeout: timeoutMs }).catch(() => null);
    return true;
  }
  return false;
}

async function clickRightMostMoreLikeButton(page) {
  return await page.evaluate(() => {
    const visible = (el) => {
      const style = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
    };
    const candidates = Array.from(document.querySelectorAll("button,[role='button'],[aria-label],[title]"))
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = [
          el.textContent || "",
          el.getAttribute("aria-label") || "",
          el.getAttribute("title") || "",
          el.getAttribute("data-testid") || "",
          el.className || ""
        ].join(" ");
        let score = 0;
        if (/更多|more|ellipsis|menu|操作/i.test(text)) score += 1000;
        if (/⋯|…|\.\.\./.test(text)) score += 600;
        score += rect.left + Math.max(0, 160 - rect.top);
        return { el, score };
      })
      .filter((item) => item.score > 800)
      .sort((a, b) => b.score - a.score);
    const target = candidates[0]?.el;
    if (!target) return false;
    target.click();
    return true;
  }).catch(() => false);
}

async function isTextVisible(page, text) {
  return await page.getByText(text, { exact: true }).first().isVisible({ timeout: 500 }).catch(() => false);
}

async function waitForText(page, text, timeoutMs) {
  return await page.getByText(text, { exact: true }).first().waitFor({ state: "visible", timeout: timeoutMs }).then(() => true).catch(() => false);
}

async function fileToBase64(filePath) {
  return (await fs.readFile(filePath)).toString("base64");
}

function sanitizeFileName(name) {
  return String(name || "feishu-document.docx").replace(/[<>:"/\\|?*\x00-\x1f]/g, "_").slice(0, 160) || "feishu-document.docx";
}

function contentTypeFromExtension(ext) {
  if (ext === ".docx") return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  if (ext === ".md") return "text/markdown";
  if (ext === ".html" || ext === ".htm") return "text/html";
  if (ext === ".txt") return "text/plain";
  return "application/octet-stream";
}

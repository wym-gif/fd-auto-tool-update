// Only manual rows without provenance inherit a neighbouring day. Explicit
// boundaries and ambiguous gaps are retained, including in legacy libraries.
export function inheritManualDaySegments(tasks) {
  const manual = (task) => /^manual-/i.test(String(task?.sourceId || ""));
  const dateKey = (task) => {
    const match = String(task?.date || "").trim().match(/^(?:(\d{4})[-/])?(\d{1,2})[-/](\d{1,2})$/);
    return match ? `${match[1] || ""}/${Number(match[2])}/${Number(match[3])}` : String(task?.date || "");
  };
  return tasks.map((task, index) => {
    if (!manual(task) || String(task.daySegment || "").trim()) return task;
    const segments = new Set();
    for (const direction of [-1, 1]) {
      for (let cursor = index + direction; cursor >= 0 && cursor < tasks.length; cursor += direction) {
        const neighbour = tasks[cursor];
        if (dateKey(neighbour) !== dateKey(task)) break;
        const segment = String(neighbour.daySegment || "").trim();
        if (segment) { segments.add(segment); break; }
        if (!manual(neighbour)) break;
      }
    }
    return segments.size === 1 ? { ...task, daySegment: [...segments][0] } : task;
  });
}

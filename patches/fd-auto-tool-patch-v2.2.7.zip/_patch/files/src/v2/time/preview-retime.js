import { createPreviewTask, validatePreviewTaskShape } from "../contracts/preview-task.js";
import { clockInputToSeconds } from "./clock-input.js";
import { fitGapsForEndTime, gapRangeBetween } from "./schedule-preview-tasks.js";

export function retimePreviewTasks(tasks, options = {}) {
  const input = tasks.map((task) => {
    validatePreviewTaskShape(task);
    return createPreviewTask({ ...task });
  });
  const sendableIndexes = input
    .map((task, index) => ({ task, index }))
    .filter(({ task }) => !task.skip)
    .map(({ index }) => index);
  if (!sendableIndexes.length) {
    return { tasks: input, diagnostics: [{ code: "no_sendable_tasks", message: "没有可发送的预览条目，未重排时间。" }] };
  }

  const startMode = options.startMode === "reverse" ? "reverse" : "normal";
  const estimate = startMode === "reverse"
    ? estimatePreviewStartWindow(input, options.endTime, options)
    : null;
  const effectiveStartTime = estimate?.predictedStartTime || options.startTime;
  const startSeconds = timeToSeconds(effectiveStartTime);
  if (startSeconds === null) throw new Error("重排时间需要有效开始时间。");
  const endSeconds = timeToSeconds(options.endTime);
  const absoluteEndSeconds = endSeconds === null ? null : endSeconds >= startSeconds ? endSeconds : endSeconds + 86400;
  const baseDate = String(options.startDate || input[sendableIndexes[0]]?.date || "").trim();
  const result = input.map((task) => createPreviewTask({ ...task }));
  const sendable = sendableIndexes.map((index) => input[index]);
  const fitted = fitGapsForEndTime(gapRanges(sendable, options).map((range) => range.value), sendable, {
    ...options, startTime: effectiveStartTime
  });
  const gaps = fitted.gaps;
  let cursor = startSeconds;

  for (let position = 0; position < sendableIndexes.length; position += 1) {
    const taskIndex = sendableIndexes[position];
    const previousIndex = position > 0 ? sendableIndexes[position - 1] : null;
    if (previousIndex !== null) {
      cursor += gaps[position - 1];
    }
    const dayDelta = Math.floor(cursor / 86400);
    result[taskIndex] = createPreviewTask({
      ...result[taskIndex],
      date: shiftMonthDay(baseDate, dayDelta) || result[taskIndex].date,
      time: secondsToClock(cursor),
      ...endTimeWarningFields(result[taskIndex], cursor, absoluteEndSeconds)
    });
  }

  return {
    tasks: result,
    diagnostics: fitted.diagnostic ? [fitted.diagnostic] : [],
    gaps,
    startMode,
    startEstimate: estimate
  };
}

export function estimatePreviewStartWindow(tasks, endTime, options = {}) {
  const endSeconds = timeToSeconds(endTime);
  if (endSeconds === null) throw new Error("请先填写有效结束时间，才能反推开始时间。");
  const sendable = tasks.filter((task) => !task.skip);
  if (!sendable.length) throw new Error("没有可发送内容，不能反推开始时间。");
  const ranges = gapRanges(sendable, options);
  const minimum = ranges.reduce((sum, range) => sum + range.min, 0);
  const recommended = ranges.reduce((sum, range) => sum + range.value, 0);
  const maximum = ranges.reduce((sum, range) => sum + range.max, 0);
  return {
    endTime: secondsToClock(endSeconds),
    earliestStartTime: secondsToClock(endSeconds - maximum),
    predictedStartTime: secondsToClock(endSeconds - recommended),
    latestStartTime: secondsToClock(endSeconds - minimum),
    minimumDurationSeconds: minimum,
    recommendedDurationSeconds: recommended,
    maximumDurationSeconds: maximum,
    taskCount: sendable.length,
    gapCount: Math.max(0, sendable.length - 1)
  };
}

function gapRanges(tasks, options = {}) {
  const ranges = [];
  for (let index = 1; index < tasks.length; index += 1) {
    ranges.push(gapRangeBetween(tasks[index - 1], tasks[index], options));
  }
  return ranges;
}

function timeToSeconds(time) {
  return clockInputToSeconds(time);
}

function secondsToClock(totalSeconds) {
  const seconds = ((Math.round(Number(totalSeconds) || 0) % 86400) + 86400) % 86400;
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(Math.floor(seconds / 3600))}:${pad(Math.floor((seconds % 3600) / 60))}:${pad(seconds % 60)}`;
}

function endTimeWarningFields(task, absoluteSeconds, absoluteEndSeconds) {
  const next = { timeOverEnd: false, timeWarning: "" };
  if (absoluteEndSeconds === null || absoluteSeconds <= absoluteEndSeconds) return next;
  const order = task?.order || "";
  return {
    timeOverEnd: true,
    timeWarning: `超过结束时间：第 ${order || "?"} 条 ${secondsToClock(absoluteSeconds)} 晚于 ${secondsToClock(absoluteEndSeconds)}，请调整间隔后再次点击“按间隔重排”。`
  };
}

function shiftMonthDay(value, dayDelta) {
  const text = String(value || "").trim();
  if (!text) return "";
  const match = text.match(/^(\d{1,2})\s*[\/月-]\s*(\d{1,2})\s*日?$/);
  if (!match) return text;
  const date = new Date(new Date().getFullYear(), Number(match[1]) - 1, Number(match[2]));
  if (Number.isNaN(date.getTime())) return text;
  date.setDate(date.getDate() + Number(dayDelta || 0));
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

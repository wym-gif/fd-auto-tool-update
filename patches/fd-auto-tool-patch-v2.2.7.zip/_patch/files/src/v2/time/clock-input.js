export function normalizeClockInput(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return "";
  const text = raw
    .replace(/[：﹕]/g, ":")
    .replace(/\s*:\s*/g, ":")
    .replace(/\s+/g, " ")
    .trim();
  const separated = text.match(/^(\d{1,2})(?::|\s+)(\d{1,2})(?:(?::|\s+)(\d{1,2}))?$/);
  if (separated) return formatClockParts(separated[1], separated[2], separated[3] || 0);
  const compact = text.replace(/\s+/g, "");
  if (/^\d{3}$/.test(compact)) return formatClockParts(compact.slice(0, 1), compact.slice(1), 0);
  if (/^\d{4}$/.test(compact)) return formatClockParts(compact.slice(0, 2), compact.slice(2), 0);
  if (/^\d{5}$/.test(compact)) return formatClockParts(compact.slice(0, 1), compact.slice(1, 3), compact.slice(3));
  if (/^\d{6}$/.test(compact)) return formatClockParts(compact.slice(0, 2), compact.slice(2, 4), compact.slice(4));
  return null;
}

export function normalizeClockInputOrTrim(value) {
  const normalized = normalizeClockInput(value);
  return normalized === null ? String(value ?? "").trim() : normalized;
}

export function clockInputToSeconds(value) {
  const normalized = normalizeClockInput(value);
  if (!normalized) return null;
  const [hour, minute, second] = normalized.split(":").map((part) => Number(part));
  return hour * 3600 + minute * 60 + second;
}

function formatClockParts(hourValue, minuteValue, secondValue) {
  const hour = Number(hourValue);
  const minute = Number(minuteValue);
  const second = Number(secondValue);
  if (!Number.isInteger(hour) || !Number.isInteger(minute) || !Number.isInteger(second)) return null;
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) return null;
  return `${pad2(hour)}:${pad2(minute)}:${pad2(second)}`;
}

function pad2(value) {
  return String(value).padStart(2, "0");
}

param(
  [string]$ProjectRoot = "",
  [string]$Instance = "",
  [int]$Port = 62230,
  [switch]$WaitForPortClosed
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
  $ProjectRoot = Join-Path $PSScriptRoot "..\..\.."
}

$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$ScriptPath = Join-Path $ProjectRoot "src\v2\tools\run-console-cli.js"
$BundledNode = Join-Path $ProjectRoot "tools\node\node.exe"
$NodeExe = if (Test-Path -LiteralPath $BundledNode) { $BundledNode } else { "node.exe" }
$LocalBrowsers = Join-Path $ProjectRoot "ms-playwright"
if (Test-Path -LiteralPath $LocalBrowsers) {
  $env:PLAYWRIGHT_BROWSERS_PATH = $LocalBrowsers
}
Set-Location -LiteralPath $ProjectRoot
$LogDir = Join-Path $ProjectRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$InstanceSuffix = ""
if (-not [string]::IsNullOrWhiteSpace($Instance)) {
  $InstanceSuffix = "-$Instance"
}
$StdOut = Join-Path $LogDir "v2-console-hidden$InstanceSuffix-$Stamp.out.log"
$StdErr = Join-Path $LogDir "v2-console-hidden$InstanceSuffix-$Stamp.err.log"

if ($WaitForPortClosed) {
  $CloseDeadline = (Get-Date).AddSeconds(12)
  while ((Get-Date) -lt $CloseDeadline) {
    try {
      Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/status" -TimeoutSec 1 | Out-Null
      Start-Sleep -Milliseconds 300
    } catch {
      break
    }
  }
}

$ConsoleArgs = @($ScriptPath, "--port", "$Port", "--no-open")
if (-not [string]::IsNullOrWhiteSpace($Instance)) {
  $ConsoleArgs += @("--instance", $Instance)
}

Start-Process `
  -FilePath $NodeExe `
  -ArgumentList $ConsoleArgs `
  -WorkingDirectory $ProjectRoot `
  -WindowStyle Hidden `
  -RedirectStandardOutput $StdOut `
  -RedirectStandardError $StdErr

$ConsoleUrl = "http://127.0.0.1:$Port/?controlled=1&startup=1"
if (-not [string]::IsNullOrWhiteSpace($Instance)) {
  $ConsoleUrl = "$ConsoleUrl&instance=$Instance"
}
$Ready = $false
$Deadline = (Get-Date).AddSeconds(20)
while ((Get-Date) -lt $Deadline) {
  try {
    Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/status" -TimeoutSec 1 | Out-Null
    $Ready = $true
    break
  } catch {
    Start-Sleep -Milliseconds 400
  }
}

if (-not $Ready) {
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show("Console background service did not start. Please check the latest .err.log in logs.", "2.0 console start failed") | Out-Null
  exit 1
}

$BrowserArgs = @((Join-Path $ProjectRoot "src\v2\tools\open-controlled-cms-browser-cli.js"), "--url", $ConsoleUrl, "--console")
if (-not [string]::IsNullOrWhiteSpace($Instance)) {
  $BrowserArgs += @("--instance", $Instance)
}
$BrowserResult = & $NodeExe $BrowserArgs 2>&1
$BrowserExitCode = $LASTEXITCODE
if ($BrowserExitCode -ne 0) {
  Add-Content -LiteralPath $StdErr -Value ($BrowserResult -join "`n")
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(($BrowserResult -join "`n"), "2.0 controlled browser start failed") | Out-Null
  exit 1
}

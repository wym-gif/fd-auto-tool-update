import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { ensureV2ControlledBrowser } from "../browser/controlled-browser.js";
import { createInstanceConfig } from "../runtime/instance-config.js";

const DEFAULT_CMS_URL = "https://cms.iyunzk.com/wx/FenWei_rw";

export async function runOpenControlledCmsBrowserCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const instanceConfig = createInstanceConfig(projectRoot, {
    instance: options.instance,
    cmsDebugPort: options.port
  });
  const config = await loadCmsConfig(projectRoot);
  const url = options.url || options.cmsUrl || config.cmsUrl || DEFAULT_CMS_URL;
  const state = await ensureV2ControlledBrowser({
    projectRoot,
    config,
    url,
    port: options.port || instanceConfig.cmsDebugPort,
    profileDir: options.profileDir || instanceConfig.profileDir,
    runsDir: instanceConfig.runsDir,
    instanceId: instanceConfig.id || "",
    chromePath: options.chromePath,
    pageKind: options.pageKind,
    bringToFront: options.bringToFront === true,
    onBrowserPreparationProgress: options.onProgress
  });

  return [
    "2.0 专用可控浏览器已打开/复用",
    "",
    ...(instanceConfig.enabled ? [`实例：${instanceConfig.id} / ${instanceConfig.label}`] : []),
    `浏览器调试地址：${state.cdpUrl}`,
    `浏览器配置目录：${state.profileDir}`,
    `打开地址：${url}`,
    `状态文件：${path.join(instanceConfig.runsDir, "v2-controlled-cms-browser.json")}`,
    "",
    "控制台、飞书、预览页、云中客页面都会复用这个浏览器上下文。"
  ].join("\n");
}

export function createBrowserPreparationReporter(write = (line) => console.log(line)) {
  let lastKey = "";
  return (progress = {}) => {
    const message = browserPreparationMessage(progress);
    const key = browserPreparationProgressKey(progress);
    if (!message || key === lastKey) return;
    lastKey = key;
    write(message);
  };
}

function browserPreparationProgressKey(progress = {}) {
  if (progress.stage?.endsWith("-retry")) return `${progress.stage}:${progress.attempt}`;
  if (progress.stage !== "downloading") return String(progress.stage || "");
  const received = Math.max(0, Number(progress.receivedBytes || 0));
  const total = Math.max(0, Number(progress.totalBytes || 0));
  const bucket = total > 0 ? Math.min(100, Math.floor(received * 100 / total)) : Math.floor(received / 1024 / 1024);
  return `${progress.stage}:${bucket}`;
}

function browserPreparationMessage(progress = {}) {
  const version = progress.version ? ` ${progress.version}` : "";
  if (progress.stage === "checking") return `正在检查专用浏览器${version}...`;
  if (progress.stage === "waiting-lock") return "另一个启动窗口正在准备专用浏览器，正在等待...";
  if (progress.stage === "checking-cache") return "正在检查已保存的浏览器安装包...";
  if (progress.stage === "cache-ready") return "完整浏览器安装包校验通过，直接使用本地文件。";
  if (progress.stage === "download-retry") return `下载暂时中断，已保留进度；${Math.ceil(progress.delayMs / 1000)} 秒后重试（${progress.attempt}/${progress.attempts}）：${progress.reason}`;
  if (progress.stage === "self-test-retry") return `浏览器启动自检未通过，保留组件重试启动（${progress.attempt}/${progress.attempts}），不会重新下载。`;
  if (progress.stage === "downloading") {
    const received = Math.max(0, Number(progress.receivedBytes || 0));
    const total = Math.max(0, Number(progress.totalBytes || 0));
    const percent = total > 0 ? ` ${Math.min(100, Math.floor(received * 100 / total))}%` : "";
    return `正在${progress.resumed ? "继续" : ""}下载专用浏览器${version}${percent}（${formatMegabytes(received)} / ${total ? formatMegabytes(total) : "未知大小"}）...`;
  }
  if (progress.stage === "verifying") return `专用浏览器${version}下载完成，正在校验...`;
  if (progress.stage === "extracting") return `专用浏览器${version}校验通过，正在解压...`;
  if (progress.stage === "self-testing") return `专用浏览器${version}解压完成，正在启动自检...`;
  if (progress.stage === "ready") return `专用浏览器${version}已准备完成。`;
  return "";
}

function formatMegabytes(bytes) {
  return `${(Math.max(0, Number(bytes || 0)) / 1024 / 1024).toFixed(1)}MB`;
}

function parseArgs(argv) {
  const cmsUrlIndex = argv.indexOf("--cms-url");
  const urlIndex = argv.indexOf("--url");
  const portIndex = argv.indexOf("--port");
  const profileIndex = argv.indexOf("--profile-dir");
  const instanceIndex = argv.indexOf("--instance");
  return {
    cmsUrl: cmsUrlIndex >= 0 ? argv[cmsUrlIndex + 1] : "",
    url: urlIndex >= 0 ? argv[urlIndex + 1] : "",
    port: portIndex >= 0 ? argv[portIndex + 1] : "",
    profileDir: profileIndex >= 0 ? argv[profileIndex + 1] : "",
    instance: instanceIndex >= 0 ? argv[instanceIndex + 1] : "",
    pageKind: argv.includes("--console") ? "console" : "",
    bringToFront: argv.includes("--bring-to-front")
  };
}

async function loadCmsConfig(projectRoot) {
  try {
    return JSON.parse(await fs.readFile(path.join(projectRoot, "config.json"), "utf8"));
  } catch {
    return {};
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runOpenControlledCmsBrowserCli({
    ...parseArgs(process.argv.slice(2)),
    onProgress: createBrowserPreparationReporter()
  }).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

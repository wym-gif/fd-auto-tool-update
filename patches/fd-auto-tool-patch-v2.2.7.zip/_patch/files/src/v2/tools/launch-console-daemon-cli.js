import fs from "node:fs";
import fsp from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { installPreparedOnlineUpdate } from "../../update/online-update.js";
import { appendInstanceParams, createInstanceConfig } from "../runtime/instance-config.js";

const DEFAULT_PORT = 62230;
const AUTO_INSTANCE_IDS = ["1", "2", "3", "4", "5"];
const AUTO_INSTANCE_LOCK_STALE_MS = 120000;

async function main(argv = process.argv.slice(2)) {
  const projectRoot = path.resolve(parseArg(argv, "--project-root") || process.cwd());
  const autoSelection = argv.includes("--auto-instance")
    ? await selectAutoInstance(projectRoot)
    : null;
  const instanceConfig = createInstanceConfig(projectRoot, {
    instance: autoSelection?.id || parseArg(argv, "--instance"),
    port: parseArg(argv, "--port") || ""
  });
  try {
    const port = instanceConfig.port || DEFAULT_PORT;
    const openBrowser = !argv.includes("--no-open");
    const nodeExe = process.execPath;
    const logsDir = instanceConfig.logsDir;
    await fsp.mkdir(logsDir, { recursive: true });
    const stamp = timestamp();
    const logPrefix = instanceConfig.enabled ? `v2-console-${instanceConfig.id}-daemon` : "v2-console-daemon";
    const outPath = path.join(logsDir, `${logPrefix}-${stamp}.out.log`);
    const errPath = path.join(logsDir, `${logPrefix}-${stamp}.err.log`);
    const consoleUrl = appendInstanceParams(`http://127.0.0.1:${port}/?controlled=1&startup=1`, instanceConfig);
    const serviceUrl = `http://127.0.0.1:${port}/`;

    let consoleReady = await isConsoleReady(serviceUrl, instanceConfig, projectRoot);
    if (!consoleReady) {
      const updateResult = await installPreparedOnlineUpdate(projectRoot);
      if (!updateResult.ok) {
        console.log("检测到已下载的新版本，但自动更新失败：" + (updateResult.error || "未知错误"));
        console.log("将继续打开当前版本。");
      } else if (updateResult.applied) {
        console.log(`已自动更新到新版本：${updateResult.latestVersion || "未知版本"}`);
      }
      consoleReady = await isConsoleReady(serviceUrl, instanceConfig, projectRoot);
    }

    if (!consoleReady) {
      const out = fs.openSync(outPath, "a");
      const err = fs.openSync(errPath, "a");
      const child = spawn(nodeExe, [
        path.join(projectRoot, "src", "v2", "tools", "run-console-cli.js"),
        "--port",
        String(port),
        ...(instanceConfig.enabled ? ["--instance", instanceConfig.id] : []),
        "--no-open"
      ], {
        cwd: projectRoot,
        detached: true,
        stdio: ["ignore", out, err],
        windowsHide: true,
        env: {
          ...process.env,
          PLAYWRIGHT_BROWSERS_PATH: path.join(projectRoot, "ms-playwright")
        }
      });
      child.unref();
      fs.closeSync(out);
      fs.closeSync(err);
      await waitForConsoleReady(serviceUrl, 20000, errPath, instanceConfig, projectRoot);
    }

    if (openBrowser) await runBrowserOpener(projectRoot, nodeExe, consoleUrl, errPath, instanceConfig);
    console.log(instanceConfig.enabled
      ? `2.0 可视化控制台已打开。实例：${instanceConfig.id} / ${instanceConfig.label}`
      : "2.0 可视化控制台已打开。");
  } finally {
    await autoSelection?.release?.();
  }
}

export async function selectAutoInstance(projectRoot, options = {}) {
  const instanceIds = options.instanceIds || AUTO_INSTANCE_IDS;
  const consoleProbe = options.isConsoleReady || isConsoleReady;
  const browserProbe = options.isBrowserReady || isBrowserReady;
  const acquireLock = options.acquireLock || ((id) => acquireAutoInstanceLock(projectRoot, id));

  for (const id of instanceIds) {
    const config = createInstanceConfig(projectRoot, { instance: id });
    const consoleUrl = `http://127.0.0.1:${config.port}/`;
    const cdpUrl = `http://127.0.0.1:${config.cmsDebugPort}`;
    if (await consoleProbe(consoleUrl) && await browserProbe(cdpUrl)) continue;

    const lock = await acquireLock(id);
    if (!lock) continue;
    if (await consoleProbe(consoleUrl) && await browserProbe(cdpUrl)) {
      await lock.release();
      continue;
    }
    return { id, release: lock.release };
  }

  throw new Error("实例 1-5 均已打开，请先退出一个实例后再试。");
}

function parseArg(argv, name) {
  const index = argv.indexOf(name);
  return index >= 0 ? argv[index + 1] : "";
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

async function waitForConsoleReady(url, timeoutMs, errPath, instanceConfig, projectRoot) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (await isConsoleReady(url, instanceConfig, projectRoot)) return;
    await new Promise((resolve) => setTimeout(resolve, 350));
  }
  throw new Error(`控制台后台服务没有启动成功。请查看日志：${errPath}`);
}

export function isConsoleReady(url, expected = null, projectRoot = "") {
  return new Promise((resolve) => {
    const req = http.get(new URL("api/service-info", url), { timeout: 800 }, (res) => {
      let body = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { body += chunk; });
      res.on("end", () => {
        try {
          const parsed = JSON.parse(body || "{}");
          if (parsed?.ok !== true) return resolve(false);
          if (!expected) return resolve(true);
          const service = parsed.service || {};
          const expectedRoot = path.resolve(projectRoot || process.cwd());
          const serviceRoot = service.projectRoot ? path.resolve(service.projectRoot) : "";
          resolve(
            String(service.instanceId || "") === String(expected.id || "")
            && serviceRoot === expectedRoot
            && Number(service.consolePort || service.port || 0) === Number(expected.port || 0)
            && Number(service.cmsDebugPort || 0) === Number(expected.cmsDebugPort || 0)
            && path.resolve(service.runsDir || "") === path.resolve(expected.runsDir || "")
          );
        } catch {
          resolve(false);
        }
      });
    });
    req.on("timeout", () => {
      req.destroy();
      resolve(false);
    });
    req.on("error", () => resolve(false));
  });
}

function isBrowserReady(cdpUrl) {
  return new Promise((resolve) => {
    const req = http.get(`${String(cdpUrl).replace(/\/$/, "")}/json/version`, { timeout: 800 }, (res) => {
      res.resume();
      resolve(res.statusCode >= 200 && res.statusCode < 300);
    });
    req.on("timeout", () => {
      req.destroy();
      resolve(false);
    });
    req.on("error", () => resolve(false));
  });
}

async function acquireAutoInstanceLock(projectRoot, id) {
  const lockDir = path.join(projectRoot, "runs", ".instance-launch-locks");
  const lockPath = path.join(lockDir, `instance-${id}.lock`);
  await fsp.mkdir(lockDir, { recursive: true });
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const handle = await fsp.open(lockPath, "wx");
      await handle.writeFile(`${process.pid}\n${new Date().toISOString()}\n`, "utf8");
      return {
        release: async () => {
          await handle.close().catch(() => {});
          await fsp.unlink(lockPath).catch(() => {});
        }
      };
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      if (!await autoInstanceLockIsStale(lockPath)) return null;
      await fsp.unlink(lockPath).catch(() => {});
    }
  }
  return null;
}

async function autoInstanceLockIsStale(lockPath) {
  const [stat, contents] = await Promise.all([
    fsp.stat(lockPath).catch(() => null),
    fsp.readFile(lockPath, "utf8").catch(() => "")
  ]);
  if (!stat) return true;
  const pid = Number(String(contents || "").split(/\r?\n/)[0] || 0);
  if (pid > 0) return !isProcessAlive(pid);
  return Date.now() - stat.mtimeMs > AUTO_INSTANCE_LOCK_STALE_MS;
}

function isProcessAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

function runBrowserOpener(projectRoot, nodeExe, consoleUrl, errPath, instanceConfig = {}) {
  return new Promise((resolve, reject) => {
    let stderr = "";
    const child = spawn(nodeExe, [
      path.join(projectRoot, "src", "v2", "tools", "open-controlled-cms-browser-cli.js"),
      "--url",
      consoleUrl,
      ...(instanceConfig.enabled ? ["--instance", instanceConfig.id] : []),
      "--console"
    ], {
      cwd: projectRoot,
      windowsHide: true,
      env: {
        ...process.env,
        PLAYWRIGHT_BROWSERS_PATH: path.join(projectRoot, "ms-playwright")
      }
    });
    child.stderr.on("data", (chunk) => {
      const text = chunk.toString();
      stderr += text;
      process.stderr.write(text);
    });
    child.stdout.on("data", (chunk) => { process.stdout.write(chunk); });
    child.on("error", reject);
    child.on("close", async (code) => {
      if (code === 0) {
        resolve();
        return;
      }
      const message = stderr.trim() || `浏览器启动失败，错误码：${code}`;
      await fsp.appendFile(errPath, `\n${message}\n`, "utf8").catch(() => {});
      reject(new Error(message));
    });
  });
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main().catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

import fs from "node:fs/promises";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";

const INTENT_FILE = "cms-login-intent.json";

export async function reuseCmsLoginSession(options = {}) {
  if (options.busy === true) return outcome("busy", "目标实例正在创建，未触碰页面或登录状态。");
  if (options.exitIntent === true) return outcome("explicit_logout", "目标实例记录了主动退出意图，不会自动恢复登录。");
  const policy = normalizePolicy(options.policy);
  if (!policy.ok) return outcome("unsupported", policy.message);
  const inspect = options.inspectSession;
  if (typeof inspect !== "function") return outcome("unsupported", "缺少受控的登录状态与账号身份核验器。");
  const target = options.target;
  if (!target?.context || !target?.page) return outcome("target_unavailable", "目标实例没有可安全核验的浏览器页面。");

  const targetBefore = await safeInspect(inspect, target.page);
  if (targetBefore.state === "authenticated") {
    return { ...outcome("already_authenticated", "目标实例已经登录，保留现有账号，不覆盖。"), accountRef: accountRef(targetBefore.accountId) };
  }
  if (targetBefore.state !== "unauthenticated") {
    return outcome("target_unknown", "目标页面尚未可靠加载，未把网络异常当成登录失效，也未清理任何数据。");
  }

  const candidates = [];
  for (const source of options.sources || []) {
    if (!source?.context || !source?.page || source.busy === true) continue;
    const session = await safeInspect(inspect, source.page);
    if (session.state === "authenticated" && session.accountId) candidates.push({ ...source, session });
  }
  const accounts = new Map();
  for (const candidate of candidates) {
    const list = accounts.get(candidate.session.accountId) || [];
    list.push(candidate);
    accounts.set(candidate.session.accountId, list);
  }
  if (!accounts.size) return outcome("no_source", "没有找到同机仍有效的登录来源，请手动登录一次。");
  if (accounts.size > 1) return outcome("ambiguous_accounts", "检测到多个不同账号，不能自动猜测登录来源，请人工确认账号。");
  const [accountId, sameAccountSources] = accounts.entries().next().value;
  const source = sameAccountSources[0];
  const cookies = await source.context.cookies([policy.probeUrl]);
  const transferable = cookies.filter((cookie) => policy.cookieNames.has(cookie.name)
    && policy.cookieDomains.has(normalizeDomain(cookie.domain))
    && cookie.secure === true);
  if (!transferable.length || transferable.some((cookie) => !cookie.httpOnly && !policy.allowNonHttpOnly.has(cookie.name))) {
    return outcome("unsupported_session", "现有登录没有匹配已确认的认证字段白名单，未复制整包 Cookie 或网页存储。");
  }

  const targetCookies = await target.context.cookies([policy.probeUrl]);
  const previous = targetCookies.filter((cookie) => transferable.some((item) => sameCookieKey(item, cookie)));
  try {
    await target.context.addCookies(transferable.map(cloneCookie));
    const verified = typeof options.validateTarget === "function"
      ? await options.validateTarget(target.page)
      : await safeInspect(inspect, target.page);
    if (verified?.state !== "authenticated" || verified.accountId !== accountId) {
      await restoreTargetCookies(target.context, transferable, previous);
      return outcome("validation_failed", "登录迁移后账号身份未通过一致性校验，已只回滚本次迁移字段，请手动登录。 ");
    }
    const sourceAfter = await safeInspect(inspect, source.page);
    if (sourceAfter.state !== "authenticated" || sourceAfter.accountId !== accountId) {
      await restoreTargetCookies(target.context, transferable, previous);
      return outcome("source_invalidated", "迁移后来源会话失效，已回滚目标实例；该网站可能限制同账号多会话。");
    }
    return {
      ...outcome("reused", "已自动复用同机同账号登录；群、角色、机器人和发送设置仍由本实例单独确认。"),
      accountRef: accountRef(accountId),
      copiedCookieCount: transferable.length
    };
  } catch (error) {
    await restoreTargetCookies(target.context, transferable, previous).catch(() => {});
    return outcome("migration_failed", `自动复用登录失败，未清理来源会话：${safeError(error)}`);
  }
}

export async function withCmsLoginReuseLock(projectRoot, task, options = {}) {
  const lockDir = path.join(projectRoot, "data", "cms-login-reuse.lock");
  await fs.mkdir(path.dirname(lockDir), { recursive: true });
  const deadline = Date.now() + Number(options.waitMs || 4000);
  while (true) {
    const owner = { token: randomUUID(), pid: process.pid, createdAt: Date.now() };
    try {
      await fs.mkdir(lockDir);
      await fs.writeFile(path.join(lockDir, "owner.json"), JSON.stringify(owner), { mode: 0o600 });
      try {
        return await task();
      } finally {
        const current = await readJson(path.join(lockDir, "owner.json"));
        if (current?.token === owner.token && current?.pid === owner.pid) await fs.rm(lockDir, { recursive: true, force: true });
      }
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      await recoverStaleLock(lockDir, options);
      if (Date.now() >= deadline) return outcome("busy", "另一实例正在核验登录复用，本实例不重复迁移。");
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }
}

export async function readCmsLoginExitIntent(runsDir) {
  const value = await readJson(path.join(runsDir, INTENT_FILE));
  return value?.explicitLogout === true;
}

export async function writeCmsLoginExitIntent(runsDir, explicitLogout) {
  await fs.mkdir(runsDir, { recursive: true });
  const file = path.join(runsDir, INTENT_FILE);
  const temp = `${file}.${process.pid}.${randomUUID()}.tmp`;
  await fs.writeFile(temp, JSON.stringify({ version: 1, explicitLogout: explicitLogout === true, updatedAt: new Date().toISOString() }), { encoding: "utf8", mode: 0o600 });
  await fs.rename(temp, file);
}

function normalizePolicy(value = {}) {
  let probe;
  try { probe = new URL(value.probeUrl); } catch { return { ok: false, message: "云中客登录复用尚未配置安全探测地址。" }; }
  if (probe.protocol !== "https:" || probe.username || probe.password || probe.hash) return { ok: false, message: "云中客登录探测地址不安全。" };
  const names = Array.isArray(value.cookieNames) ? value.cookieNames.filter(validName) : [];
  const domains = Array.isArray(value.cookieDomains) ? value.cookieDomains.map(normalizeDomain).filter(Boolean) : [];
  if (!names.length || !domains.length) return { ok: false, message: "尚未通过空闲测试实例确认云中客认证字段白名单，自动登录复用未启用。" };
  if (!domains.every((domain) => probe.hostname === domain || probe.hostname.endsWith(`.${domain}`))) {
    return { ok: false, message: "认证 Cookie 域名白名单与云中客探测地址不一致。" };
  }
  return {
    ok: true,
    probeUrl: probe.href,
    cookieNames: new Set(names),
    cookieDomains: new Set(domains),
    allowNonHttpOnly: new Set(Array.isArray(value.allowNonHttpOnlyCookieNames) ? value.allowNonHttpOnlyCookieNames.filter(validName) : [])
  };
}

async function safeInspect(inspect, page) {
  try {
    const value = await inspect(page);
    if (!value || !["authenticated", "unauthenticated", "unknown"].includes(value.state)) return { state: "unknown", accountId: "" };
    return { state: value.state, accountId: typeof value.accountId === "string" ? value.accountId.trim().slice(0, 200) : "" };
  } catch {
    return { state: "unknown", accountId: "" };
  }
}

async function restoreTargetCookies(context, migrated, previous) {
  for (const cookie of migrated) {
    await context.clearCookies({ name: cookie.name, domain: cookie.domain, path: cookie.path || "/" });
  }
  if (previous.length) await context.addCookies(previous.map(cloneCookie));
}

function cloneCookie(cookie) {
  return Object.fromEntries(Object.entries(cookie).filter(([key]) => ["name", "value", "domain", "path", "expires", "httpOnly", "secure", "sameSite", "partitionKey"].includes(key)));
}

function sameCookieKey(left, right) {
  return left.name === right.name && normalizeDomain(left.domain) === normalizeDomain(right.domain) && (left.path || "/") === (right.path || "/");
}

function normalizeDomain(value) {
  return String(value || "").trim().toLowerCase().replace(/^\./, "");
}

function validName(value) {
  return typeof value === "string" && /^[A-Za-z0-9_.-]{1,80}$/.test(value);
}

function accountRef(value) {
  return createHash("sha256").update(`cms-account-ref-v1|${value}`).digest("hex").slice(0, 12);
}

function outcome(status, message) {
  return { ok: status === "reused" || status === "already_authenticated", status, message };
}

function safeError(error) {
  return String(error?.message || error || "未知错误").replace(/[<>\r\n]/g, " ").slice(0, 160);
}

async function readJson(file) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); } catch { return null; }
}

async function recoverStaleLock(lockDir, options) {
  try {
    const ownerFile = path.join(lockDir, "owner.json");
    const stat = await fs.stat(ownerFile);
    const owner = await readJson(ownerFile);
    if (Date.now() - stat.mtimeMs < Number(options.staleMs || 15_000)) return;
    if (owner?.pid && processAlive(owner.pid)) return;
    const confirm = await readJson(ownerFile);
    if (confirm?.token !== owner?.token || confirm?.createdAt !== owner?.createdAt) return;
    await fs.rm(lockDir, { recursive: true, force: true });
  } catch {}
}

function processAlive(pid) {
  try { process.kill(Number(pid), 0); return true; } catch (error) { return error?.code === "EPERM"; }
}

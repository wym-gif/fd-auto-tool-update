import { createWriteStream } from "node:fs";
import fs from "node:fs/promises";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";

// The caller names the partial file by the pinned archive hash and verifies the full hash.
// A response that ignores Range replaces the partial file; it must never be appended.
export async function downloadManagedBrowserArchive(url, destination, options = {}) {
  const attempts = Math.max(1, Math.min(5, Number(options.downloadAttempts ?? 3)));
  const expected = Number(options.expectedBytes || 0);
  for (let attempt = 1; attempt <= attempts; attempt++) {
    let offset = await fs.stat(destination).then(stat => stat.size, error => {
      if (error.code === "ENOENT") return 0;
      throw error;
    });
    if (expected && offset === expected) return;
    if (expected && offset > expected) {
      await fs.truncate(destination, 0);
      offset = 0;
    }
    const controller = new AbortController();
    const idleMs = Math.max(10, Number(options.downloadIdleTimeoutMs ?? 60000));
    let idleTimer;
    const touch = () => {
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => controller.abort(new Error("下载连接长时间没有收到数据")), idleMs);
      idleTimer.unref?.();
    };
    const totalTimer = setTimeout(() => controller.abort(new Error("本次下载等待超时")),
      Math.max(idleMs, Number(options.downloadTimeoutMs ?? 10 * 60 * 1000)));
    totalTimer.unref?.();
    let retryAfterMs = 0;
    try {
      touch();
      const response = await (options.fetchArchive || fetch)(url, {
        redirect: "follow", signal: controller.signal,
        headers: { "Accept-Encoding": "identity", ...(offset ? { Range: `bytes=${offset}-` } : {}) }
      });
      if (!response.ok || !response.body) {
        retryAfterMs = Math.min(10000, Math.max(0, Number(response.headers.get("retry-after")) * 1000 || 0));
        const error = new Error(`专用浏览器下载失败：HTTP ${response.status}`);
        error.code = "MANAGED_BROWSER_DOWNLOAD_HTTP";
        error.retryable = [408, 429].includes(response.status) || response.status >= 500;
        await response.body?.cancel().catch(() => {});
        throw error;
      }
      const encoding = response.headers.get("content-encoding");
      const range = response.headers.get("content-range")?.match(/^bytes (\d+)-(\d+)\/(\d+)$/i);
      const appending = response.status === 206;
      if ((encoding && encoding !== "identity") || (appending && (!range || Number(range[1]) !== offset
        || Number(range[2]) < offset || Number(range[2]) >= Number(range[3])
        || (expected && Number(range[3]) !== expected))) || (!appending && response.status !== 200)) {
        await response.body.cancel().catch(() => {});
        const error = new Error("专用浏览器续传响应范围不一致，已保留原下载进度，未拼接错误内容。");
        error.code = "MANAGED_BROWSER_DOWNLOAD_RANGE";
        error.retryable = false;
        throw error;
      }
      let received = appending ? offset : 0;
      const total = expected || (appending ? Number(range[3]) : Number(response.headers.get("content-length"))) || null;
      options.onProgress?.({ receivedBytes: received, totalBytes: total, resumed: appending && offset > 0, attempt });
      const source = Readable.fromWeb(response.body);
      source.on("data", chunk => {
        touch();
        received += chunk.length;
        if (total && received > total) {
          const error = new Error("专用浏览器下载超过预期大小，已停止。");
          error.code = "MANAGED_BROWSER_DOWNLOAD_SIZE";
          error.retryable = false;
          source.destroy(error);
          return;
        }
        options.onProgress?.({ receivedBytes: received, totalBytes: total, resumed: appending && offset > 0, attempt });
      });
      await pipeline(source, createWriteStream(destination, { flags: appending ? "a" : "w" }), { signal: controller.signal });
      if (total && received !== total) throw new Error(`下载尚未完整：已接收 ${received} / ${total} 字节`);
      return;
    } catch (error) {
      const reason = controller.signal.aborted ? controller.signal.reason?.message || "下载超时" : error.message;
      const retryable = error.retryable !== false && !["ENOSPC", "EACCES", "EPERM", "EROFS"].includes(error.code);
      if (!retryable || attempt === attempts) {
        const detail = error.cause?.code || error.code || error.name || "";
        const failure = new Error(`${reason}${detail ? `（${detail}）` : ""}。已保留下载文件，重新启动可继续准备。`);
        failure.code = error.code || "MANAGED_BROWSER_DOWNLOAD_FAILED";
        failure.cause = error;
        throw failure;
      }
      const delayMs = Math.max(retryAfterMs, Number(options.downloadRetryDelayMs ?? Math.min(1000 * 2 ** (attempt - 1), 5000)));
      options.onRetry?.({ attempt, attempts, delayMs, reason });
      await new Promise(resolve => setTimeout(resolve, delayMs));
    } finally {
      clearTimeout(idleTimer);
      clearTimeout(totalTimer);
      controller.abort();
    }
  }
}

(() => {
  try { globalThis.__fdTabBridgeCleanup?.(); } catch {}
  const REQUEST_EVENT = "fd-controlled-tab-display-request-v3";
  const RESPONSE_EVENT = "fd-controlled-tab-display-response";
  const REQUEST_META = "fd-controlled-tab-command";
  const RESPONSE_META = "fd-controlled-tab-response";
  const handled = new Set();

  const onRequest = async (event) => {
    // An old isolated world can outlive an extension reload. It must not race the new listener.
    if (!chrome.runtime?.id) { window.removeEventListener(REQUEST_EVENT, onRequest); return; }
    const marker = event.target;
    if (!marker?.matches?.(`meta[name="${REQUEST_META}"]`)) return;
    const requestId = marker?.getAttribute("data-request-id") || "";
    if (!requestId || handled.has(requestId)) return;
    handled.add(requestId);
    let response;
    try {
      response = await chrome.runtime.sendMessage({
        type: marker.getAttribute("data-command") === "activate"
          ? "fd-tab-display-activate"
          : "fd-tab-display-handshake",
        requestId,
        bridgeVersion: marker.getAttribute("data-bridge-version") || "",
        instanceId: marker.getAttribute("data-instance-id") || "",
        token: marker.getAttribute("content") || "",
        role: marker.getAttribute("data-role") || ""
      });
    } catch (error) {
      if (!chrome.runtime?.id || /context invalidated/i.test(error?.message || "")) {
        window.removeEventListener(REQUEST_EVENT, onRequest);
        return;
      }
      response = {
        ok: false,
        code: "TAB_DISPLAY_EXTENSION_UNAVAILABLE",
        message: error?.message || String(error),
        requestId
      };
    }
    if (!marker.isConnected) return; // The caller timed out or the page changed.
    let result = document.head?.querySelector?.(`meta[name="${RESPONSE_META}"][data-request-id="${requestId}"]`);
    if (!result && document.head) {
      result = document.createElement("meta");
      result.setAttribute("name", RESPONSE_META);
      document.head.appendChild(result);
    }
    if (!result) return;
    result.setAttribute("data-request-id", requestId);
    result.setAttribute("content", JSON.stringify(response || {}));
    window.dispatchEvent(new Event(RESPONSE_EVENT));
    if (handled.size > 100) handled.clear();
  };
  window.addEventListener(REQUEST_EVENT, onRequest);

  const onMessage = (message, _sender, sendResponse) => {
    if (message?.type !== "fd-read-tab-binding") return false;
    const marker = document.head?.querySelector?.('meta[name="fd-controlled-tab-binding"]');
    sendResponse({
      token: marker?.getAttribute("content") || "",
      instanceId: marker?.getAttribute("data-instance-id") || "",
      role: marker?.getAttribute("data-role") || ""
    });
    return false;
  };
  chrome.runtime.onMessage.addListener(onMessage);
  globalThis.__fdTabBridgeCleanup = () => {
    window.removeEventListener(REQUEST_EVENT, onRequest);
    chrome.runtime.onMessage.removeListener(onMessage);
  };
})();

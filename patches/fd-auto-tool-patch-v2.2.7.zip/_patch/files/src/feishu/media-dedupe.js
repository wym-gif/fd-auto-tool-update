import { imageSizeFromBuffer, readImageSize } from "../v2/media/image-size.js";

export { imageSizeFromBuffer, readImageSize };

export function removeStickerPreviewDuplicates(tasks) {
  const sorted = [...(tasks || [])].sort((a, b) => a.order - b.order);
  const removeIndexes = new Set();
  let removedCount = 0;
  for (let i = 0; i < sorted.length; i += 1) {
    if (removeIndexes.has(i) || !isImageLikeTask(sorted[i])) continue;
    for (let j = i + 1; j < sorted.length; j += 1) {
      if (removeIndexes.has(j) || !isImageLikeTask(sorted[j])) continue;
      if (!isLikelySameStickerPreviewPair(sorted[i], sorted[j])) continue;
      const keepIndex = mediaExtRank(sorted[i]) >= mediaExtRank(sorted[j]) ? i : j;
      const dropIndex = keepIndex === i ? j : i;
      removeIndexes.add(dropIndex);
      removedCount += 1;
      break;
    }
  }
  if (removedCount) console.log(`已合并重复表情包 ${removedCount} 处。`);
  return sorted.filter((_, index) => !removeIndexes.has(index));
}

export async function removeDownloadedStickerPreviewDuplicates(tasks) {
  const sorted = [...(tasks || [])].sort((a, b) => a.order - b.order);
  const removeIndexes = new Set();
  let removedCount = 0;
  let markedCount = 0;
  for (let i = 0; i < sorted.length - 1; i += 1) {
    const a = sorted[i];
    const b = sorted[i + 1];
    if (!isImageLikeTask(a) || !isImageLikeTask(b)) continue;
    if (!isSameDownloadedStickerPreviewOwner(a, b)) continue;
    const aExt = mediaExt(a);
    const bExt = mediaExt(b);
    const aSize = await readImageSize(a.imagePath);
    const bSize = await readImageSize(b.imagePath);
    if (!isSameImageSize(aSize, bSize)) continue;
    if (isGifStaticPreviewExtPair(aExt, bExt)) {
      const keepIndex = aExt === "gif" ? i : i + 1;
      const dropIndex = keepIndex === i ? i + 1 : i;
      removeIndexes.add(dropIndex);
      removedCount += 1;
      i += 1;
    } else if (isLikelySameStaticPreviewDuplicate(a, b, aExt, bExt)) {
      b.__skip = true;
      b.__autoSkipReason = "疑似重复图片，已默认勾选不发";
      markedCount += 1;
    }
  }
  if (removedCount) console.log(`已合并重复表情包 ${removedCount} 处。`);
  if (markedCount) console.log(`已标记疑似重复图片 ${markedCount} 处为不发，可在预览页取消。`);
  return sorted.filter((_, index) => !removeIndexes.has(index));
}

function isImageLikeTask(task) {
  return task?.type === "image" || task?.type === "sticker";
}

function isLikelySameStickerPreviewPair(a, b) {
  if (!a || !b) return false;
  if ((a.role || "") !== (b.role || "") || (a.speaker || "") !== (b.speaker || "")) return false;
  if ((a.scheduleDateKey || "") !== (b.scheduleDateKey || "")) return false;
  if (Math.abs(Number(a.order || 0) - Number(b.order || 0)) > 1.2) return false;
  const aY = Number(a.mediaY ?? a.ownerY);
  const bY = Number(b.mediaY ?? b.ownerY);
  if (Number.isFinite(aY) && Number.isFinite(bY) && Math.abs(aY - bY) > 18) return false;
  const aExt = mediaExt(a);
  const bExt = mediaExt(b);
  if (!["gif", "webp"].includes(aExt) && !["gif", "webp"].includes(bExt)) return false;
  if (aExt === bExt) return false;
  const aText = normalizedContent(`${a.parentText || ""} ${a.text || ""}`);
  const bText = normalizedContent(`${b.parentText || ""} ${b.text || ""}`);
  if (aText && bText && aText !== bText && !aText.includes(bText) && !bText.includes(aText)) return false;
  return true;
}

function mediaExtRank(task) {
  const ext = mediaExt(task);
  if (ext === "gif") return 3;
  if (ext === "webp") return 2;
  return 1;
}

function mediaExt(task) {
  const source = String(task?.imagePath || task?.assetUrl || "");
  const match = source.toLowerCase().match(/\.([a-z0-9]+)(?:[?#]|$)/);
  return match?.[1] || "";
}

function isSameDownloadedStickerPreviewOwner(a, b) {
  if (!a || !b) return false;
  if ((a.role || "") !== (b.role || "") || (a.speaker || "") !== (b.speaker || "")) return false;
  if ((a.scheduleDateKey || "") !== (b.scheduleDateKey || "")) return false;
  if (!a.imagePath || !b.imagePath) return false;
  const aY = Number(a.mediaY ?? a.ownerY);
  const bY = Number(b.mediaY ?? b.ownerY);
  if (Number.isFinite(aY) && Number.isFinite(bY) && Math.abs(aY - bY) > 80) return false;
  return true;
}

function isGifStaticPreviewExtPair(aExt, bExt) {
  const staticExts = new Set(["png", "jpg", "jpeg", "webp"]);
  return (aExt === "gif" && staticExts.has(bExt)) || (bExt === "gif" && staticExts.has(aExt));
}

function isLikelySameStaticPreviewDuplicate(a, b, aExt, bExt) {
  if (!aExt || !bExt || aExt !== bExt) return false;
  if (["gif", "webp"].includes(aExt)) return false;
  if (Math.abs(Number(a.order || 0) - Number(b.order || 0)) > 1.2) return false;
  const aY = Number(a.mediaY ?? a.ownerY);
  const bY = Number(b.mediaY ?? b.ownerY);
  if (Number.isFinite(aY) && Number.isFinite(bY) && Math.abs(aY - bY) > 32) return false;
  const aText = normalizedContent(`${a.parentText || ""} ${a.text || ""}`);
  const bText = normalizedContent(`${b.parentText || ""} ${b.text || ""}`);
  return !aText || !bText || aText === bText || aText.includes(bText) || bText.includes(aText);
}

export function isSameImageSize(a, b) {
  if (!a || !b) return false;
  if (a.width !== b.width || a.height !== b.height) return false;
  return a.width >= 48 && a.height >= 48;
}

function normalizedContent(text) {
  return String(text || "").replace(/\s+/g, "");
}

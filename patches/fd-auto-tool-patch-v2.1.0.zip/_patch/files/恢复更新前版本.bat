@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "NODE_EXE="
if exist "%~dp0tools\node\node.exe" set "NODE_EXE=%~dp0tools\node\node.exe"
if not defined NODE_EXE if exist "C:\Program Files\nodejs\node.exe" set "NODE_EXE=C:\Program Files\nodejs\node.exe"
if not defined NODE_EXE for /f "delims=" %%N in ('where node 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE (
  echo 没有找到 Node 运行环境，不能自动恢复。
  pause
  exit /b 1
)

echo 请先关闭正在运行的 START/监控预览窗口，再继续恢复。
echo.
"%NODE_EXE%" "%~dp0tools\restore-last-patch.cjs"
echo.
pause

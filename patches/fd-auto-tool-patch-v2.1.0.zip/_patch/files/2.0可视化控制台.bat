@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PLAYWRIGHT_BROWSERS_PATH=%~dp0ms-playwright"
set "NODE_EXE=%~dp0tools\node\node.exe"
set "SCRIPT=%~dp0src\v2\tools\launch-console-daemon-cli.js"

if not exist "%NODE_EXE%" (
  echo Missing runtime: %NODE_EXE%
  echo Extract the whole folder, then double-click this bat again.
  pause
  exit /b 1
)

if not exist "%SCRIPT%" (
  echo Missing startup file: %SCRIPT%
  echo Extract the whole folder, then double-click this bat again.
  pause
  exit /b 1
)

"%NODE_EXE%" "%SCRIPT%" --project-root "%CD%" --port 62230 %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
  echo.
  echo Startup failed. Exit code: %EXIT_CODE%
  echo Send a screenshot of this window to the administrator.
  pause
)
exit /b %EXIT_CODE%

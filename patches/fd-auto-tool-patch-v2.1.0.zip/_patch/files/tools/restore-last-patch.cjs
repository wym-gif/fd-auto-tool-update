const fs = require("node:fs");
const path = require("node:path");
const childProcess = require("node:child_process");

const rootDir = path.resolve(__dirname, "..");
const backupRoot = path.join(rootDir, "backups");
const lastBackupPath = path.join(backupRoot, "last-patch-backup.txt");

try {
  main();
} catch (error) {
  console.error("");
  console.error("恢复失败：" + (error && error.message ? error.message : String(error)));
  process.exit(1);
}

function main() {
  if (!fs.existsSync(lastBackupPath)) {
    fail("没有找到最近一次补丁备份记录。");
  }
  const backupDir = fs.readFileSync(lastBackupPath, "utf8").trim();
  const recordsPath = path.join(backupDir, "files.json");
  if (!backupDir || !fs.existsSync(recordsPath)) {
    fail("最近一次补丁备份不完整，不能自动恢复。");
  }
  const records = JSON.parse(fs.readFileSync(recordsPath, "utf8"));
  if (!Array.isArray(records) || !records.length) {
    fail("备份记录里没有可恢复文件。");
  }

  console.log("准备恢复最近一次补丁更新前的文件。");
  console.log("备份位置：" + backupDir);
  for (const record of [...records].reverse()) {
    const target = resolveInside(rootDir, record.path);
    const backup = resolveInside(path.join(backupDir, "files"), record.path);
    if (record.existed) {
      if (!fs.existsSync(backup)) fail("备份文件缺失：" + record.path);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(backup, target);
      console.log("已恢复：" + record.path);
    } else if (fs.existsSync(target)) {
      fs.rmSync(target, { force: true });
      console.log("已移除补丁新增文件：" + record.path);
    }
  }

  runChecks();
  fs.writeFileSync(lastBackupPath + ".restored", backupDir, "utf8");
  fs.rmSync(lastBackupPath, { force: true });
  console.log("");
  console.log("已恢复到最近一次补丁更新前。现在可以重新启动 START.cmd。");
}

function runChecks() {
  const targets = [
    "src/control-ui.js",
    "src/feishu.js",
    "src/main.js",
    "src/preview-ui.js",
    "src/cms.js",
    "src/run-with-log.cjs"
  ];
  for (const rel of targets) {
    const target = resolveInside(rootDir, rel);
    if (!fs.existsSync(target)) continue;
    const result = childProcess.spawnSync(process.execPath, ["--check", target], {
      cwd: rootDir,
      encoding: "utf8"
    });
    if (result.status !== 0) {
      const detail = (result.stderr || result.stdout || "").trim();
      throw new Error("恢复后代码检查失败：" + rel + (detail ? "\n" + detail : ""));
    }
  }
  console.log("代码检查通过。");
}

function resolveInside(base, rel) {
  const resolved = path.resolve(base, rel);
  const root = path.resolve(base);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) {
    fail("路径越界：" + rel);
  }
  return resolved;
}

function fail(message) {
  throw new Error(message);
}

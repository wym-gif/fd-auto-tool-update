const fs = require("node:fs");
const path = require("node:path");
const childProcess = require("node:child_process");

const rootDir = path.resolve(__dirname, "..");
const patchDir = path.join(rootDir, "_patch");
const filesDir = path.join(patchDir, "files");
const manifestPath = path.join(patchDir, "patch-manifest.json");
const backupRoot = path.join(rootDir, "backups");
const protectedExact = new Set([
  "config.json",
  "last-settings.json",
  "cms-page-settings.json",
  "latest-preview.json",
  "preview-last.log",
  "run-last.log",
  "watch-preview-last.log"
]);
const protectedDirs = new Set([
  "_patch",
  "backups",
  "browser-profile",
  "node_modules",
  "ms-playwright",
  "runs"
]);

try {
  main();
} catch (error) {
  console.error("");
  console.error("更新失败：" + (error && error.message ? error.message : String(error)));
  process.exit(1);
}

function main() {
  assertToolRoot();
  if (!fs.existsSync(manifestPath)) {
    fail("没有找到补丁清单：_patch\\patch-manifest.json。请先把补丁包解压到工具文件夹。");
  }
  if (!fs.existsSync(filesDir)) {
    fail("没有找到补丁文件夹：_patch\\files。请重新解压补丁包。");
  }

  const packagePath = path.join(rootDir, "package.json");
  const packageJson = readJson(packagePath, "package.json");
  const manifest = readJson(manifestPath, "_patch\\patch-manifest.json");
  const currentVersion = String(packageJson.version || "").trim();
  const targetVersion = String(manifest.targetVersion || "").trim();

  if (manifest.toolName && manifest.toolName !== "fd-auto-tool") {
    fail("这个补丁不是 fd-auto-tool 的补丁。");
  }
  if (targetVersion && currentVersion === targetVersion) {
    fail("当前已经是目标版本 " + targetVersion + "，不用重复更新。");
  }
  const allowedVersions = normalizeAllowedVersions(manifest);
  if (allowedVersions.length && !allowedVersions.includes("*") && !allowedVersions.includes(currentVersion)) {
    fail("当前版本是 " + (currentVersion || "未知") + "，补丁要求基础版本：" + allowedVersions.join(" / ") + "。请先安装对应完整包。");
  }

  const files = normalizeFiles(manifest.files);
  if (!files.length) fail("补丁清单里没有 files。");
  for (const rel of files) validatePatchFile(rel);

  const stamp = timestamp();
  const backupDir = path.join(backupRoot, "patch_" + stamp);
  const backupFilesDir = path.join(backupDir, "files");
  fs.mkdirSync(backupFilesDir, { recursive: true });
  fs.copyFileSync(manifestPath, path.join(backupDir, "patch-manifest.json"));

  const records = [];
  console.log("准备更新 fd-auto-tool");
  console.log("当前版本：" + (currentVersion || "未知"));
  if (targetVersion) console.log("目标版本：" + targetVersion);
  console.log("更新文件：" + files.length + " 个");
  console.log("备份位置：" + backupDir);

  try {
    for (const rel of files) {
      const target = resolveInside(rootDir, rel);
      const source = resolveInside(filesDir, rel);
      const backup = resolveInside(backupFilesDir, rel);
      const existed = fs.existsSync(target);
      if (existed) {
        fs.mkdirSync(path.dirname(backup), { recursive: true });
        fs.copyFileSync(target, backup);
      }
      records.push({ path: rel, existed });
    }
    fs.writeFileSync(path.join(backupDir, "files.json"), JSON.stringify(records, null, 2), "utf8");

    for (const rel of files) {
      const target = resolveInside(rootDir, rel);
      const source = resolveInside(filesDir, rel);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(source, target);
      console.log("已更新：" + rel);
    }

    runChecks(files);
    fs.mkdirSync(backupRoot, { recursive: true });
    fs.writeFileSync(path.join(backupRoot, "last-patch-backup.txt"), backupDir, "utf8");
    console.log("");
    console.log("更新成功。现在可以重新启动 START.cmd。");
  } catch (error) {
    console.error("");
    console.error("更新过程中出错，正在自动恢复更新前文件...");
    restoreRecords(backupDir, records);
    throw error;
  }
}

function assertToolRoot() {
  if (!fs.existsSync(path.join(rootDir, "package.json")) || !fs.existsSync(path.join(rootDir, "src", "main.js"))) {
    fail("当前目录不是 fd-auto-tool 工具目录。请把补丁解压到工具文件夹后再运行。");
  }
}

function normalizeAllowedVersions(manifest) {
  if (Array.isArray(manifest.baseVersions)) return manifest.baseVersions.map((item) => String(item).trim()).filter(Boolean);
  if (manifest.baseVersion) return [String(manifest.baseVersion).trim()].filter(Boolean);
  return [];
}

function normalizeFiles(files) {
  if (!Array.isArray(files)) return [];
  return files.map((item) => {
    if (typeof item === "string") return item;
    return item && typeof item.path === "string" ? item.path : "";
  }).map(normalizeRel).filter(Boolean);
}

function normalizeRel(value) {
  return String(value || "").replace(/\\/g, "/").replace(/^\/+/, "").trim();
}

function validatePatchFile(rel) {
  if (!rel) fail("补丁清单里有空文件路径。");
  if (path.isAbsolute(rel) || rel.includes("..")) fail("补丁文件路径不安全：" + rel);
  const first = rel.split("/")[0];
  const normalized = rel.replace(/\//g, path.sep);
  if (protectedExact.has(rel) || protectedDirs.has(first)) {
    fail("补丁不能覆盖受保护内容：" + rel);
  }
  const source = resolveInside(filesDir, rel);
  if (!fs.existsSync(source)) fail("补丁文件缺失：" + path.join("_patch", "files", normalized));
  if (fs.statSync(source).isDirectory()) fail("补丁清单只能列文件，不能列文件夹：" + rel);
}

function runChecks(files) {
  const checkTargets = new Set([
    "src/control-ui.js",
    "src/feishu.js",
    "src/main.js",
    "src/preview-ui.js",
    "src/cms.js",
    "src/run-with-log.cjs"
  ]);
  for (const rel of files) {
    if (/^(src\/).+\.(?:js|cjs|mjs)$/i.test(rel)) checkTargets.add(rel);
  }
  const nodeExe = process.execPath;
  for (const rel of checkTargets) {
    const target = resolveInside(rootDir, rel);
    if (!fs.existsSync(target)) continue;
    const result = childProcess.spawnSync(nodeExe, ["--check", target], {
      cwd: rootDir,
      encoding: "utf8"
    });
    if (result.status !== 0) {
      const detail = (result.stderr || result.stdout || "").trim();
      throw new Error("代码检查失败：" + rel + (detail ? "\n" + detail : ""));
    }
  }
  console.log("代码检查通过。");
}

function restoreRecords(backupDir, records) {
  for (const record of [...records].reverse()) {
    const target = resolveInside(rootDir, record.path);
    const backup = resolveInside(path.join(backupDir, "files"), record.path);
    if (record.existed) {
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(backup, target);
    } else if (fs.existsSync(target)) {
      fs.rmSync(target, { force: true });
    }
  }
}

function resolveInside(base, rel) {
  const resolved = path.resolve(base, rel);
  const root = path.resolve(base);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) {
    fail("路径越界：" + rel);
  }
  return resolved;
}

function readJson(file, label) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (error) {
    fail("无法读取 " + label + "：" + error.message);
  }
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [pad(now.getHours()), pad(now.getMinutes()), pad(now.getSeconds())].join("");
}

function fail(message) {
  throw new Error(message);
}

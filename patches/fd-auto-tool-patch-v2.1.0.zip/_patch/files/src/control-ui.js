import http from "node:http";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { readFeishuTasks } from "./feishu.js";
import {
  applyRunAction as applyRunStateAction,
  clearStepProgress,
  clearWaitProgress,
  createDefaultRunState,
  touchRunState
} from "./control/run-state.js";
import { formatDurationZh, secondsToClock, timeToSeconds } from "./schedule/time-utils.js";
import {
  CUSTOM_INTERVAL_KEYS,
  countEstimateRoles,
  defaultStartTimeAfterLead,
  estimateRealtimeGaps,
  isEstimateTask,
  validateServerCustomIntervals
} from "./schedule/realtime-estimate.js";
import { checkOnlineUpdate, installOnlineUpdate } from "./update/online-update.js";
import { parseTime } from "./utils.js";

let sharedControlSession = null;

export async function chooseSettingsInBrowser(context, config) {
  const session = await getControlSession(context, config);
  session.context = context;
  session.config = config;
  if (session.queuedFinish) {
    const queued = session.queuedFinish;
    session.queuedFinish = null;
    session.finish = null;
    session.finished = null;
    session.runState.current = "已使用页面新设置，正在重新生成预览";
    clearWaitProgress(session);
    clearStepProgress(session);
    touchRunState(session);
    return queued;
  }
  let finish;
  session.finished = new Promise((resolve) => {
    finish = resolve;
  });
  session.finish = finish;

  console.log(`\n已打开妙券自动发单🚀：${session.url}`);
  console.log("请在页面里选好本轮参数，点“保存设置，生成预览”后才会继续读取飞书。");

  if (context?.newPage) {
    if (!session.page || session.page.isClosed()) {
      session.page = await context.newPage();
      await session.page.goto(session.url, { waitUntil: "domcontentloaded" });
    } else {
      await session.page.goto(session.url, { waitUntil: "domcontentloaded" }).catch(() => {});
      await session.page.bringToFront().catch(() => {});
    }
  }

  return session.finished;
}

export async function getSharedControlForRun(context, config = {}) {
  const session = await getControlSession(context, config);
  session.context = context;
  session.config = config;
  session.runState.available = true;
  session.runState.stopped = false;
  session.runState.current = session.runState.current || "准备中";
  touchRunState(session);

  if (context?.newPage) {
    if (!session.page || session.page.isClosed()) {
      session.page = await context.newPage();
      await session.page.goto(session.url, { waitUntil: "domcontentloaded" });
    } else {
      await session.page.goto(session.url, { waitUntil: "domcontentloaded" }).catch(() => {});
    }
  }

  return {
    state: session.runState,
    async setCurrent(current) {
      session.runState.current = current || session.runState.current;
      clearWaitProgress(session);
      clearStepProgress(session);
      touchRunState(session);
    },
    async checkpoint(current) {
      if (current) {
        session.runState.current = current;
        clearWaitProgress(session);
        clearStepProgress(session);
        touchRunState(session);
      }
      if (session.runState.paused && !session.runState.pauseNoticeShown) {
        printPauseNotice(session.runState.current);
        session.runState.pauseNoticeShown = true;
        touchRunState(session);
      }
      while (session.runState.paused && !session.runState.stopped) {
        await sleep(300);
      }
      if (session.runState.stopped) {
        throw new Error("已通过控制台停止，后续任务没有继续创建");
      }
      touchRunState(session);
    },
    consumePreviewRestart() {
      if (!session.runState.restartPreviewRequested) return false;
      session.runState.restartPreviewRequested = false;
      session.runState.current = "本轮已放弃，请修改设置后保存生成预览";
      clearWaitProgress(session);
      clearStepProgress(session);
      touchRunState(session);
      return true;
    },
    peekPreviewRestart() {
      return Boolean(session.runState.restartPreviewRequested);
    },
    consumeQueuedFinish() {
      if (!session.queuedFinish) return null;
      const queued = session.queuedFinish;
      session.queuedFinish = null;
      return queued;
    },
    async waitForStandbyCommand() {
      return waitForStandbyCommand(session);
    },
    async waitForRealtimeGapChoice(info) {
      return waitForRealtimeGapChoice(session, info);
    },
    async waitForCmsSetupAction() {
      return waitForCmsSetupAction(session);
    },
    async startWaitProgress(label, totalMs) {
      session.runState.current = label || session.runState.current;
      clearStepProgress(session);
      session.runState.waitProgress = {
        label: session.runState.current,
        startedAt: Date.now(),
        totalMs: Math.max(1, Number(totalMs) || 1)
      };
      touchRunState(session);
    },
    async clearWaitProgress(label) {
      if (label) session.runState.current = label;
      clearWaitProgress(session);
      touchRunState(session);
    },
    async setProgress(label, current, total, detail = "") {
      const safeTotal = Math.max(1, Number(total) || 1);
      const safeCurrent = Math.min(safeTotal, Math.max(0, Number(current) || 0));
      session.runState.current = label || session.runState.current;
      session.runState.waitProgress = null;
      session.runState.progress = {
        label: session.runState.current,
        current: safeCurrent,
        total: safeTotal,
        percent: Math.round((safeCurrent / safeTotal) * 100),
        detail: String(detail || "")
      };
      touchRunState(session);
    },
    async clearProgress(label) {
      if (label) session.runState.current = label;
      clearStepProgress(session);
      touchRunState(session);
    }
  };
}

async function getControlSession(context, config) {
  const localSettings = await loadLocalSettings();
  const state = buildState(config, localSettings);

  if (sharedControlSession?.server?.listening) {
    sharedControlSession.state = state;
    sharedControlSession.context = context;
    sharedControlSession.config = config;
    return sharedControlSession;
  }

  const session = {
    state,
    config,
    context,
    finish: null,
    finished: null,
    queuedFinish: null,
    page: null,
    server: null,
    url: "",
    runState: createDefaultRunState()
  };

  const server = http.createServer(async (req, res) => {
    try {
      if (req.method === "GET" && req.url === "/") {
        sendHtml(res, renderPage(session.state, session.runState));
        return;
      }
      if (req.method === "POST" && req.url === "/finish") {
        const payload = JSON.parse(await readBody(req) || "{}");
        const requestedAction = payload.action || "continue";
        if (requestedAction === "restart" && !session.finish) {
          session.runState.restartPreviewRequested = true;
          session.runState.restartRequestId = Number(session.runState.restartRequestId || 0) + 1;
          session.runState.current = "本轮已放弃，请修改设置后保存生成预览";
          session.runState.paused = false;
          clearWaitProgress(session);
          clearStepProgress(session);
          touchRunState(session);
          sendJson(res, { ok: true, queued: true, state: session.runState });
          return;
        }
        const result = applySettings(session.config, payload);
        if (result.action === "continue" && !session.finish) {
          session.queuedFinish = result;
          session.runState.restartPreviewRequested = true;
          session.runState.restartRequestId = Number(session.runState.restartRequestId || 0) + 1;
          session.runState.current = "已收到新设置，正在放弃上一轮并重新生成预览";
          session.runState.paused = false;
          clearWaitProgress(session);
          clearStepProgress(session);
          touchRunState(session);
          sendJson(res, { ok: true, queued: true, state: session.runState });
          return;
        }
        if (session.finish) {
          const finishNow = session.finish;
          session.finish = null;
          finishNow(result.action === "restart" ? { action: "continue" } : result);
        }
        sendJson(res, { ok: true });
        return;
      }
      if (req.method === "POST" && req.url === "/invalidate-round") {
        const payload = JSON.parse(await readBody(req) || "{}");
        const reason = String(payload.reason || "").trim() || "链接已变，本轮已作废，请重新保存生成预览";
        session.queuedFinish = null;
        if (!session.finish) {
          session.runState.restartPreviewRequested = true;
          session.runState.restartRequestId = Number(session.runState.restartRequestId || 0) + 1;
        }
        session.runState.current = reason;
        session.runState.paused = false;
        clearWaitProgress(session);
        clearStepProgress(session);
        touchRunState(session);
        sendJson(res, { ok: true, state: session.runState });
        return;
      }
      if (req.method === "POST" && req.url === "/read-title") {
        const payload = JSON.parse(await readBody(req) || "{}");
        const feishuUrl = normalizeUrl(payload.feishuUrl);
        const projectType = "collection";
        if (!isFeishuUrl(feishuUrl)) {
          sendJson(res, { ok: false, title: "", outline: { days: [] }, error: "请粘贴完整的飞书文档链接。" });
          return;
        }
        const outline = await readFeaturedOutlineFromUrl(session.context, feishuUrl, { deepScan: false, projectType });
        const stats = featuredOutlineStats(outline);
        if (outline.days?.length) {
          sendJson(res, {
            ok: Boolean(outline.title || outline.days?.length),
            title: outline.title || "",
            outline,
            stats,
            needDeepScan: Boolean(outline.days?.length) && !isFeaturedOutlineTrusted(outline),
            error: outline.title || outline.days?.length ? "" : "暂时没有读到标题，保存后读取飞书时会再更新。"
          });
          return;
        }
        const title = outline.title || await readFeishuTitleFromUrl(session.context, feishuUrl);
        sendJson(res, { ok: Boolean(title), title, outline: { days: [] }, stats, error: title ? "" : "暂时没有读到标题，保存后读取飞书时会再更新。" });
        return;
      }
      if (req.method === "POST" && req.url === "/featured-outline") {
        const payload = JSON.parse(await readBody(req) || "{}");
        const feishuUrl = normalizeUrl(payload.feishuUrl);
        const deepScan = payload.deepScan === true;
        if (!isFeishuUrl(feishuUrl)) {
          sendJson(res, { ok: false, error: "请先粘贴完整的飞书文档链接。" });
          return;
        }
        const projectType = "collection";
        const outline = await readFeaturedOutlineFromUrl(session.context, feishuUrl, { deepScan, projectType });
        const stats = featuredOutlineStats(outline);
        sendJson(res, {
          ok: Boolean(outline.days?.length),
          outline,
          stats,
          needDeepScan: !deepScan && Boolean(outline.days?.length) && !isFeaturedOutlineTrusted(outline),
          error: outline.days?.length ? "" : "没有识别到第几天和节奏，请先用手动范围。"
        });
        return;
      }
      if (req.method === "POST" && req.url === "/estimate-start-time") {
        const payload = JSON.parse(await readBody(req) || "{}");
        const result = await estimateRealtimeStartTime(session, payload.settings || {});
        sendJson(res, result);
        return;
      }
      if (req.method === "GET" && req.url === "/run-state") {
        sendJson(res, { ok: true, state: session.runState });
        return;
      }
      if (req.method === "POST" && req.url === "/run-action") {
        const payload = JSON.parse(await readBody(req) || "{}");
        applyRunStateAction(session, payload.action, {
          onPause: printPauseNotice,
          onResume: () => console.log("已继续运行。")
        });
        sendJson(res, { ok: true, state: session.runState });
        return;
      }
      if (req.method === "POST" && req.url === "/standby-command") {
        const payload = JSON.parse(await readBody(req) || "{}");
        const result = applyStandbyCommand(session, payload);
        sendJson(res, { ok: result.ok, error: result.error || "", state: session.runState });
        return;
      }
      if (req.method === "POST" && req.url === "/realtime-gap-choice") {
        const payload = JSON.parse(await readBody(req) || "{}");
        const result = applyRealtimeGapChoice(session, payload);
        sendJson(res, { ok: result.ok, error: result.error || "", state: session.runState });
        return;
      }
      if (req.method === "POST" && req.url === "/cms-setup-action") {
        const payload = JSON.parse(await readBody(req) || "{}");
        const result = applyCmsSetupAction(session, payload);
        sendJson(res, { ok: result.ok, error: result.error || "", state: session.runState });
        return;
      }
      if (req.method === "GET" && req.url === "/update-status") {
        const result = await checkOnlineUpdate(session.config);
        sendJson(res, result);
        return;
      }
      if (req.method === "POST" && req.url === "/install-update") {
        const result = await installOnlineUpdate(session.config);
        sendJson(res, result);
        return;
      }
      res.writeHead(404);
      res.end("Not found");
    } catch (error) {
      res.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
      res.end(error.message || String(error));
    }
  });

  await listen(server);
  server.unref?.();
  const address = server.address();
  session.server = server;
  session.url = `http://127.0.0.1:${address.port}/`;
  sharedControlSession = session;
  return session;
}

function buildState(config, localSettings) {
  const savedUrl = normalizeUrl(localSettings.feishuUrl);
  const configUrl = normalizeUrl(config.feishuUrl);
  const feishuUrl = savedUrl || configUrl || "";
  const savedTitleUrl = normalizeUrl(localSettings.feishuTitleUrl);
  const configTitleUrl = normalizeUrl(config.feishuTitleUrl);
  let feishuTitle = "";
  let feishuTitleUrl = "";
  if (savedUrl && feishuUrl === savedUrl && (!savedTitleUrl || savedTitleUrl === savedUrl)) {
    feishuTitle = String(localSettings.feishuTitle || "").trim();
    feishuTitleUrl = feishuTitle ? (savedTitleUrl || savedUrl) : "";
  } else if (configUrl && feishuUrl === configUrl && (!configTitleUrl || configTitleUrl === configUrl)) {
    feishuTitle = String(config.feishuTitle || "").trim();
    feishuTitleUrl = feishuTitle ? (configTitleUrl || configUrl) : "";
  }

  return {
    feishuUrl,
    feishuTitle,
    feishuTitleUrl,
    projectType: "collection",
    tuoMode: config.tuoMode || "random",
    randomRobotNotInGroupAction: config.randomRobotNotInGroupAction || (config.ignoreRobotNotInGroup ? "confirm" : "retry"),
    fixedRolePrefix: config.roles?.tuo?.fixedRolePrefix || config.fixedRolePrefix || "",
    fixedRoleSheetUrl: config.fixedRoleSheetUrl || "",
    readRangeEnabled: Boolean(config.readRange?.enabled),
    readRangeStart: config.readRange?.start || "",
    readRangeEnd: config.readRange?.end || "",
    scheduleMode: config.scheduleMode || "doc",
    realtimeStartTime: config.realtimeStartTime || "",
    realtimeEndTime: config.realtimeEndTime || "",
    realtimeEndMode: normalizeRealtimeEndMode(config.realtimeEndMode),
    stretchGapMinMinutes: normalizeMinuteValue(config.stretchGapMinMinutes, 2),
    stretchGapMaxMinutes: normalizeMinuteValue(config.stretchGapMaxMinutes, 23),
    customIntervals: normalizeCustomIntervals(config.customIntervals || {}),
    updateSourceUrl: String(config.updateSourceUrl || process.env.FD_AUTO_TOOL_UPDATE_URL || "").trim()
  };
}

function normalizeRealtimeEndMode(value) {
  return value === "stretch" ? "stretch" : "latest";
}

function normalizeMinuteValue(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? Math.round(number) : fallback;
}

function normalizeIntervalValue(value) {
  if (value === "" || value === undefined || value === null) return "";
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? Math.round(number) : "";
}

function normalizeCustomIntervals(input = {}) {
  const result = {};
  for (const key of CUSTOM_INTERVAL_KEYS) {
    const item = input[key] || {};
    const min = normalizeIntervalValue(item.min);
    const max = normalizeIntervalValue(item.max);
    if (min !== "" || max !== "") result[key] = { min, max };
  }
  return result;
}

function applySettings(config, payload) {
  const action = payload.action || "continue";
  if (action === "fallback") return { action: "fallback" };
  if (action === "exit") return { action: "exit" };

  const settings = payload.settings || {};
  config.projectType = "collection";
  const previousFeishuUrl = normalizeUrl(config.feishuUrl);
  const feishuUrl = normalizeUrl(settings.feishuUrl);
  if (feishuUrl) config.feishuUrl = feishuUrl;
  if (feishuUrl && previousFeishuUrl !== feishuUrl) {
    config.feishuTitle = "";
    config.feishuTitleUrl = "";
  }
  const feishuTitle = String(settings.feishuTitle || "").trim();
  const feishuTitleUrl = normalizeUrl(settings.feishuTitleUrl || feishuUrl);
  if (feishuTitle && feishuUrl && (!feishuTitleUrl || feishuTitleUrl === feishuUrl)) {
    config.feishuTitle = feishuTitle;
    config.feishuTitleUrl = feishuTitleUrl || feishuUrl;
  }

  config.tuoMode = settings.tuoMode === "fixed" ? "fixed" : "random";
  if (config.tuoMode === "random") {
    const notInGroupAction = settings.randomRobotNotInGroupAction === "confirm" ? "confirm" : "retry";
    config.randomRobotNotInGroupAction = notInGroupAction;
    config.ignoreRobotNotInGroup = notInGroupAction === "confirm";
  } else {
    const prefix = String(settings.fixedRolePrefix || "").trim();
    if (prefix) {
      config.fixedRolePrefix = prefix;
      config.roles = config.roles || {};
      config.roles.tuo = config.roles.tuo || {};
      config.roles.tuo.fixedRolePrefix = prefix;
    }
    config.fixedRoleSheetUrl = normalizeUrl(settings.fixedRoleSheetUrl) || String(settings.fixedRoleSheetUrl || "").trim();
  }

  if (settings.readRangeMode === "range") {
    config.readRange = {
      enabled: true,
      start: String(settings.readRangeStart || "").trim(),
      end: String(settings.readRangeEnd || "").trim(),
      endExclusive: settings.readRangeEndExclusive === true,
      endAtDocumentEnd: settings.readRangeEndAtDocumentEnd === true
    };
  } else {
    config.readRange = { enabled: false, start: "", end: "" };
  }

  config.scheduleMode = ["doc", "realtime", "catchup"].includes(settings.scheduleMode) ? settings.scheduleMode : "doc";
  config.useDocTimes = config.scheduleMode === "doc";
  if (config.scheduleMode === "realtime" || config.scheduleMode === "catchup") {
    config.realtimeStartTime = String(settings.realtimeStartTime || "").trim() || defaultStartTimeAfterLead(config);
  }
  if (config.scheduleMode === "realtime") {
    config.realtimeEndTime = String(settings.realtimeEndTime || "").trim();
    config.realtimeEndMode = normalizeRealtimeEndMode(settings.realtimeEndMode);
    config.stretchGapMinMinutes = normalizeMinuteValue(settings.stretchGapMinMinutes, 2);
    config.stretchGapMaxMinutes = normalizeMinuteValue(settings.stretchGapMaxMinutes, 23);
    if (config.stretchGapMaxMinutes < config.stretchGapMinMinutes) {
      [config.stretchGapMinMinutes, config.stretchGapMaxMinutes] = [config.stretchGapMaxMinutes, config.stretchGapMinMinutes];
    }
  }
  config.customIntervals = normalizeCustomIntervals(settings.customIntervals || {});

  return { action: action === "restart" ? "restart" : "continue" };
}

function normalizeProjectType(value) {
  return value === "featured" ? "featured" : "collection";
}

async function estimateRealtimeStartTime(session, settings = {}) {
  if (!session?.context?.newPage) return { ok: false, error: "浏览器还没有准备好，先启动监控预览后再试。" };
  if (settings.scheduleMode !== "realtime") return { ok: false, error: "只有实时跟发模式需要反推开始时间。" };
  const endTime = parseTime(settings.realtimeEndTime);
  if (!endTime) return { ok: false, error: "请先填写正确的结束时间，例如 18:00:00。" };
  const feishuUrl = normalizeUrl(settings.feishuUrl);
  if (!isFeishuUrl(feishuUrl)) return { ok: false, error: "请先填写完整的飞书文档链接。" };
  if (settings.readRangeMode === "range" && (!settings.readRangeStart || (!settings.readRangeEnd && !settings.readRangeEndAtDocumentEnd))) {
    return { ok: false, error: "指定范围时，开始和结束关键词都要填写。" };
  }
  const intervalError = validateServerCustomIntervals(settings.customIntervals || {});
  if (intervalError) return { ok: false, error: intervalError };

  const previousCurrent = session.runState.current;
  const previousProgress = session.runState.progress;
  const previousWaitProgress = session.runState.waitProgress;
  session.runState.current = "正在估算开始时间";
  session.runState.progress = { label: "正在估算开始时间", current: 1, total: 3, percent: 33, detail: "读取飞书" };
  session.runState.waitProgress = null;
  touchRunState(session);

  let page = null;
  let shouldClosePage = false;
  try {
    const estimateConfig = JSON.parse(JSON.stringify(session.config || {}));
    applySettings(estimateConfig, { action: "continue", settings });
    estimateConfig.scheduleMode = "realtime";
    estimateConfig.feishuUrl = feishuUrl;
    estimateConfig.realtimeEndTime = endTime;
    estimateConfig.__runControl = null;

    page = findReusableFeishuPage(session.context, feishuUrl);
    if (!page) {
      page = await session.context.newPage();
      shouldClosePage = true;
    }

    session.runState.progress = { label: "正在估算开始时间", current: 2, total: 3, percent: 66, detail: "统计消息" };
    touchRunState(session);
    const runDir = path.join(os.tmpdir(), "fd-auto-tool-estimate");
    await fs.mkdir(runDir, { recursive: true });
    const tasks = await readFeishuTasks(page, estimateConfig, runDir, {
      downloadMediaFiles: false,
      dropFailedMedia: false,
      showProgress: false
    });
    const sendTasks = tasks.filter(isEstimateTask);
    if (!sendTasks.length) return { ok: false, error: "没有统计到可发送内容，请检查读取范围。" };

    session.runState.progress = { label: "正在估算开始时间", current: 3, total: 3, percent: 100, detail: `${sendTasks.length} 条` };
    touchRunState(session);
    const gaps = estimateRealtimeGaps(sendTasks, estimateConfig);
    const durationSeconds = gaps.reduce((sum, gap) => sum + gap, 0);
    const endSeconds = timeToSeconds(endTime);
    const rawStartSeconds = endSeconds - durationSeconds;
    const startTime = secondsToClock(rawStartSeconds);
    const previousDay = rawStartSeconds < 0;
    const roleStats = countEstimateRoles(sendTasks);
    return {
      ok: true,
      startTime,
      endTime,
      previousDay,
      totalTasks: sendTasks.length,
      durationSeconds,
      roleStats,
      summary: `共 ${sendTasks.length} 条，预计需要 ${formatDurationZh(durationSeconds)}。`
    };
  } catch (error) {
    return { ok: false, error: error?.message || String(error) };
  } finally {
    if (shouldClosePage && page && !page.isClosed()) await page.close().catch(() => {});
    session.runState.current = previousCurrent || "等待设置";
    session.runState.progress = previousProgress || null;
    session.runState.waitProgress = previousWaitProgress || null;
    touchRunState(session);
  }
}

function findReusableFeishuPage(context, feishuUrl) {
  const pages = typeof context.pages === "function" ? context.pages() : [];
  const target = normalizeUrl(feishuUrl);
  const targetPath = (() => {
    try {
      const url = new URL(target);
      return `${url.host}${url.pathname}`;
    } catch {
      return "";
    }
  })();
  return pages.find((page) => {
    if (!page || page.isClosed()) return false;
    const current = page.url?.() || "";
    if (!current.includes("feishu.cn/")) return false;
    if (!targetPath) return true;
    try {
      const url = new URL(current);
      return `${url.host}${url.pathname}` === targetPath;
    } catch {
      return false;
    }
  }) || pages.find((page) => page && !page.isClosed() && String(page.url?.() || "").includes("feishu.cn/")) || null;
}

function applyStandbyCommand(session, payload = {}) {
  if (!session.runState.waitingStandbyCommand) {
    return { ok: false, error: "当前还没有需要选择的下一步。" };
  }
  const action = String(payload.action || "").trim();
  const command = { action: "continue" };
  if (action === "continue") {
    // keep current settings
  } else if (["doc", "realtime", "catchup"].includes(action)) {
    command.scheduleMode = action;
  } else if (action === "change-url") {
    const feishuUrl = normalizeUrl(payload.feishuUrl);
    if (!isFeishuUrl(feishuUrl)) return { ok: false, error: "请先填写完整的飞书文档链接。" };
    command.feishuUrl = feishuUrl;
  } else if (action === "exit") {
    command.action = "exit";
  } else {
    return { ok: false, error: "这个选择没有识别，请重试。" };
  }
  session.runState.standbyCommand = command;
  session.runState.waitingStandbyCommand = false;
  session.runState.current = command.action === "exit" ? "已选择退出监控" : "已收到下一步选择";
  touchRunState(session);
  return { ok: true };
}

function waitForStandbyCommand(session) {
  session.runState.waitingStandbyCommand = true;
  session.runState.standbyCommand = null;
  session.runState.available = true;
  session.runState.current = "本轮完成，请在控制台选择下一步";
  touchRunState(session);
  return new Promise((resolve) => {
    const tick = () => {
      const command = session.runState.standbyCommand;
      if (command) {
        session.runState.standbyCommand = null;
        session.runState.waitingStandbyCommand = false;
        touchRunState(session);
        resolve(command);
        return;
      }
      if (session.runState.stopped) {
        session.runState.waitingStandbyCommand = false;
        touchRunState(session);
        resolve({ action: "exit" });
        return;
      }
      setTimeout(tick, 300);
    };
    tick();
  });
}

function applyRealtimeGapChoice(session, payload = {}) {
  if (!session.runState.waitingRealtimeGapChoice) {
    return { ok: false, error: "当前没有需要选择的时间处理方式。" };
  }
  const action = String(payload.action || "").trim();
  const mode = session.runState.realtimeGapInfo?.mode || "compressible";
  const allowed = mode === "too-short"
    ? ["min", "edit-time", "cancel"]
    : mode === "stretch-too-loose"
      ? ["stretch-fill", "stretch-max", "edit-time", "cancel"]
      : ["compress", "normal", "cancel"];
  if (!allowed.includes(action)) return { ok: false, error: "这个选择不适用于当前情况。" };
  session.runState.realtimeGapChoice = action;
  session.runState.waitingRealtimeGapChoice = false;
  session.runState.current = "已收到时间处理选择";
  touchRunState(session);
  return { ok: true };
}

function waitForRealtimeGapChoice(session, info = {}) {
  session.runState.waitingRealtimeGapChoice = true;
  session.runState.realtimeGapChoice = null;
  session.runState.realtimeGapInfo = info;
  session.runState.available = true;
  session.runState.current = "实时跟发时间放不下，请在控制台选择";
  touchRunState(session);
  return new Promise((resolve) => {
    const tick = () => {
      const choice = session.runState.realtimeGapChoice;
      if (choice) {
        session.runState.realtimeGapChoice = null;
        session.runState.waitingRealtimeGapChoice = false;
        session.runState.realtimeGapInfo = null;
        touchRunState(session);
        resolve(choice);
        return;
      }
      if (session.runState.stopped) {
        session.runState.waitingRealtimeGapChoice = false;
        session.runState.realtimeGapInfo = null;
        touchRunState(session);
        resolve("cancel");
        return;
      }
      setTimeout(tick, 300);
    };
    tick();
  });
}

function applyCmsSetupAction(session, payload = {}) {
  if (!session.runState.waitingCmsSetupAction) {
    return { ok: false, error: "当前还没到确认云中客页面的步骤。" };
  }
  const action = String(payload.action || "").trim();
  if (!["continue", "refresh", "monitor"].includes(action)) return { ok: false, error: "这个选择没有识别，请重试。" };
  session.runState.cmsSetupAction = action;
  session.runState.waitingCmsSetupAction = false;
  session.runState.current = "已收到云中客页面确认";
  touchRunState(session);
  return { ok: true };
}

function waitForCmsSetupAction(session) {
  session.runState.waitingCmsSetupAction = true;
  session.runState.cmsSetupAction = null;
  session.runState.available = true;
  session.runState.current = "请确认云中客页面准备好";
  touchRunState(session);
  return new Promise((resolve) => {
    const tick = () => {
      const action = session.runState.cmsSetupAction;
      if (action) {
        session.runState.cmsSetupAction = null;
        session.runState.waitingCmsSetupAction = false;
        touchRunState(session);
        resolve(action);
        return;
      }
      if (session.runState.stopped) {
        session.runState.waitingCmsSetupAction = false;
        touchRunState(session);
        resolve("monitor");
        return;
      }
      setTimeout(tick, 300);
    };
    tick();
  });
}

function printPauseNotice(current) {
  console.log("\n已暂停。");
  if (current) console.log(`当前停在：${current}`);
  console.log("如果是飞书文案写错了：先去飞书改文案，改好后可以在控制台点【停止】，回到监控后重新读取最新文档。");
  console.log("如果只是想临时停一下：点控制台【继续】，会按当前预览继续创建。");
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function renderPage(state, runState) {
  const json = escapeScriptJson(JSON.stringify(state));
  const runJson = escapeScriptJson(JSON.stringify(runState));
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>妙券自动发单🚀</title>
  <style>
    body { margin: 0; font-family: "Microsoft YaHei", Arial, sans-serif; color: #172033; background: #f4f7fb; }
    header { padding: 18px 24px; background: #fff; border-bottom: 1px solid #dde5f0; display: flex; align-items: center; gap: 14px; }
    h1 { margin: 0; font-size: 20px; }
    .muted { color: #68758a; font-size: 13px; }
    main { max-width: 980px; margin: 18px auto 28px; padding: 0 18px; }
    section { background: #fff; border: 1px solid #dde5f0; border-radius: 8px; padding: 16px; margin-bottom: 12px; }
    h2 { margin: 0 0 12px; font-size: 16px; }
    label { display: block; font-size: 13px; color: #4d5a70; margin-bottom: 6px; }
    input, select { width: 100%; box-sizing: border-box; border: 1px solid #cbd7e6; border-radius: 6px; padding: 9px 10px; font: inherit; background: #fff; }
    .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
    .radio-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
    .choice { border: 1px solid #cbd7e6; border-radius: 8px; padding: 12px; cursor: pointer; background: #fff; }
    .choice input { width: auto; margin-right: 8px; }
    .choice strong { display: inline-block; margin-bottom: 4px; }
    .choice.active { border-color: #2f7df6; background: #f0f6ff; }
    .hidden { display: none; }
    .run-card { border-color: #c9defc; background: #f8fbff; }
    .statusbox { display: grid; grid-template-columns: 110px 1fr; gap: 6px 10px; padding: 12px; border-radius: 8px; background: #fff; border: 1px solid #dce8f8; line-height: 1.6; }
    .status-label { color: #68758a; }
    .run-current-line { display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .run-percent { color: #1d4ed8; font-variant-numeric: tabular-nums; }
    .run-bar { display: inline-grid; grid-template-columns: repeat(10, 8px); gap: 2px; padding: 2px; border: 1px solid #cbd7e6; border-radius: 4px; background: #f8fbff; vertical-align: middle; }
    .run-bar span { width: 8px; height: 12px; border-radius: 2px; background: #e5edf8; }
    .run-bar span.on { background: #2f7df6; }
    .run-actions { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
    .standby-actions { margin-top: 12px; padding: 12px; border: 1px solid #d9e7ff; border-radius: 8px; background: #fff; }
    .gap-choice { margin-top: 12px; padding: 12px; border: 1px solid #fed7aa; border-radius: 8px; background: #fffaf4; }
    .standby-buttons { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
    .standby-url { display: flex; gap: 8px; margin-top: 10px; align-items: center; }
    .standby-url input { flex: 1; }
    button.warn { border-color: #f59e0b; background: #f59e0b; color: #fff; }
    button.ok { border-color: #16a34a; background: #16a34a; color: #fff; }
    button.danger-fill { border-color: #dc2626; background: #dc2626; color: #fff; }
    button:disabled { opacity: .58; cursor: not-allowed; }
    .pause-tip { margin-top: 10px; padding: 10px 12px; border-radius: 8px; background: #fff7ed; color: #9a3412; font-size: 13px; line-height: 1.7; }
    .actions { position: sticky; bottom: 0; background: rgba(244, 247, 251, 0.96); border-top: 1px solid #dde5f0; padding: 14px 0; display: flex; justify-content: flex-end; gap: 10px; }
    button { border: 1px solid #2f7df6; background: #2f7df6; color: #fff; border-radius: 7px; padding: 10px 16px; font-size: 14px; cursor: pointer; }
    button.secondary { background: #fff; color: #2f7df6; }
    button.danger { border-color: #d84b4b; color: #d84b4b; background: #fff; }
    .notice { margin-top: 8px; color: #b25b00; font-size: 13px; }
    .interval-box { margin-top: 12px; padding: 12px; border: 1px solid #d9e7ff; border-radius: 8px; background: #f8fbff; }
    .interval-title { font-weight: 700; margin-bottom: 4px; }
    .interval-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; margin-top: 10px; }
    .interval-row { display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 10px; border: 1px solid #e4ecf8; border-radius: 8px; background: #fff; }
    .interval-pair { display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; }
    .interval-pair input { width: 76px; }
    .time-advanced { margin-top: 10px; border: 1px solid #d9e7ff; border-radius: 8px; background: #f8fbff; }
    .time-advanced.hidden { display: none; }
    .time-advanced summary { padding: 10px 12px; cursor: pointer; color: #2f7df6; font-weight: 700; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .time-advanced-summary-note { color: #64748b; font-weight: 400; font-size: 13px; }
    .time-advanced-body { border-top: 1px solid #d9e7ff; padding: 12px; display: grid; gap: 12px; }
    .time-tool-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .stretch-inputs { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; }
    .stretch-inputs input { width: 86px; }
    .help { margin-top: 12px; padding: 12px; border-radius: 8px; background: #f7faff; border: 1px solid #d9e7ff; color: #405069; font-size: 13px; line-height: 1.7; }
    .help-title { font-weight: 700; color: #1d4f9a; margin-bottom: 4px; }
    .help ul { margin: 6px 0 0 18px; padding: 0; }
    .help code { background: #eef4ff; border-radius: 4px; padding: 1px 5px; color: #143b75; }
    .featured-picker { margin-top: 12px; padding: 12px; border: 1px solid #d9e7ff; border-radius: 8px; background: #f8fbff; }
    .featured-picker-head { display: flex; gap: 10px; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .featured-picker-title { font-weight: 700; }
    .featured-picker-list { margin-top: 8px; color: #4d5a70; font-size: 13px; line-height: 1.7; max-height: 110px; overflow: auto; }
    .featured-repair { margin-top: 10px; padding: 10px; border: 1px solid #fed7aa; border-radius: 8px; background: #fff7ed; color: #9a3412; font-size: 13px; line-height: 1.7; }
    .featured-repair button { margin-top: 8px; border-color: #f59e0b; background: #f59e0b; color: #fff; }
    .update-card { margin-left: auto; display: flex; align-items: center; gap: 8px; }
    .update-status { max-width: 360px; color: #68758a; font-size: 13px; line-height: 1.5; }
    @media (max-width: 760px) {
      .grid, .radio-grid { grid-template-columns: 1fr; }
      main { padding: 0 10px; }
      header { flex-wrap: wrap; }
      .update-card { width: 100%; margin-left: 0; justify-content: flex-start; }
    }
  </style>
</head>
<body>
  <header>
    <div>
      <h1>妙券自动发单🚀</h1>
      <div class="muted">这一页代替黑窗口里的启动选择。点保存后，才会读取飞书并生成预览。</div>
    </div>
    <div class="update-card">
      <button class="secondary" id="check-update" type="button">检查更新</button>
      <button class="secondary hidden" id="install-update" type="button">立即更新</button>
      <div class="update-status" id="update-status"></div>
    </div>
  </header>
  <main>
    <section class="run-card">
      <h2>运行控制</h2>
      <div class="statusbox">
        <div class="status-label">状态</div><div id="run-status">等待设置</div>
        <div class="status-label">当前</div><div id="run-current">等待设置</div>
        <div class="status-label">更新时间</div><div id="run-updated">-</div>
      </div>
      <div class="run-actions">
        <button class="warn" id="run-pause">暂停</button>
        <button class="ok" id="run-resume">继续</button>
        <button class="danger-fill" id="run-stop">停止</button>
      </div>
      <div class="pause-tip hidden" id="pause-tip">已暂停。如果是飞书文案写错了，先去飞书改；改好后可以点“停止”结束本轮并回监控重新读，或者点“继续”按当前预览继续跑。</div>
      <div class="gap-choice hidden" id="gap-choice">
        <div><strong>实时跟发时间放不下，怎么处理？</strong></div>
        <div class="muted" id="gap-choice-detail"></div>
        <div class="standby-buttons" id="gap-choice-compressible">
          <button class="secondary" data-gap-action="compress">压缩间隔生成预览</button>
          <button class="secondary" data-gap-action="normal">不压缩，允许超过结束时间</button>
          <button class="danger" data-gap-action="cancel">取消本次预览，回到监控</button>
        </div>
        <div class="standby-buttons hidden" id="gap-choice-too-short">
          <button class="secondary" data-gap-action="min">使用最短间隔继续排</button>
          <button class="secondary" data-gap-action="edit-time">重新输入开始/结束时间</button>
          <button class="danger" data-gap-action="cancel">取消本次预览，回到监控</button>
        </div>
        <div class="standby-buttons hidden" id="gap-choice-stretch-too-loose">
          <button class="secondary" data-gap-action="stretch-fill">放宽最长间隔，铺满结束时间</button>
          <button class="secondary" data-gap-action="stretch-max">按最长间隔排，允许提前结束</button>
          <button class="secondary" data-gap-action="edit-time">重新输入开始/结束时间</button>
          <button class="danger" data-gap-action="cancel">取消本次预览，回到监控</button>
        </div>
        <div class="notice" id="gap-choice-status"></div>
      </div>
      <div class="standby-actions hidden" id="cms-setup-action">
        <div><strong>云中客页面准备好了吗？</strong></div>
        <div class="muted">程序不会恢复上次选择。请确认托页和豆妈页都停留在创建任务页面，并且群/机器人已按需要手动选好。</div>
        <div class="standby-buttons">
          <button class="secondary" data-cms-setup-action="continue">我已手动选好，开始创建</button>
          <button class="secondary" data-cms-setup-action="refresh">重新生成预览再执行</button>
          <button class="danger" data-cms-setup-action="monitor">回到监控，不执行</button>
        </div>
        <div class="notice" id="cms-setup-status"></div>
      </div>
      <div class="standby-actions hidden" id="standby-actions">
        <div><strong>本轮已完成，下一步做什么？</strong></div>
        <div class="muted">这里代替黑窗口输入数字。选好后会继续监控或重新生成下一轮预览。</div>
        <div class="standby-buttons">
          <button class="secondary" data-standby-action="continue">继续监控当前设置</button>
          <button class="secondary" data-standby-action="doc">改为文档时间</button>
          <button class="secondary" data-standby-action="realtime">改为实时跟发</button>
          <button class="secondary" data-standby-action="catchup">改为补发到文档时间</button>
          <button class="danger" data-standby-action="exit">退出监控</button>
        </div>
        <div class="standby-url">
          <input id="standby-url" placeholder="粘贴新的飞书文档链接" />
          <button class="secondary" data-standby-action="change-url">更换飞书链接</button>
        </div>
        <div class="notice" id="standby-status"></div>
      </div>
      <div class="muted" style="margin-top:10px;">这个控制区和下面设置在同一个页面里。预览/创建任务时也不用再打开第二个控制台。</div>
    </section>

    <section>
      <h2>1. 飞书文档</h2>
      <label for="feishu-title">当前文档标题</label>
      <input id="feishu-title" disabled />
      <div class="muted" style="margin-bottom:10px;">标题来自上次成功读取飞书后的本地记录，用来确认你选的是哪份文档。</div>
      <label for="feishu-url">主飞书文档链接</label>
      <input id="feishu-url" placeholder="粘贴飞书文档链接" />
      <div class="muted">可以直接用上次链接，也可以在这里换新链接。</div>
    </section>

    <section>
      <h2>2. 发单版本</h2>
      <div class="radio-grid" id="tuo-mode">
        <label class="choice"><input type="radio" name="tuoMode" value="random" /> <strong>粗略版：随机托</strong><div class="muted">使用当前随机托流程。</div></label>
        <label class="choice"><input type="radio" name="tuoMode" value="fixed" /> <strong>精细版：固定托</strong><div class="muted">选择角色范围后再更换机器人。</div></label>
      </div>
      <div id="random-options" class="grid" style="margin-top:12px;">
        <div>
          <label for="not-in-group">遇到机器人不在群</label>
          <select id="not-in-group">
            <option value="retry">自动更换机器人重试 3 次，仍不行再问我</option>
            <option value="confirm">不更换机器人，直接按当前机器人确认创建</option>
          </select>
        </div>
      </div>
      <div id="fixed-options" class="grid hidden" style="margin-top:12px;">
        <div>
          <label for="fixed-prefix">角色范围/前缀</label>
          <input id="fixed-prefix" placeholder="例如：老群GJ、108老群GJ" />
        </div>
        <div>
          <label for="fixed-sheet">托号登记表链接</label>
          <input id="fixed-sheet" placeholder="可留空" />
        </div>
      </div>
    </section>

    <section>
      <h2>3. 读取范围</h2>
      <div id="featured-picker" class="featured-picker hidden">
        <div class="featured-picker-head">
          <div>
            <div class="featured-picker-title" id="featured-picker-title">文档目录选择</div>
            <div class="muted">先读取文档里的“第几天节奏”和下面的小节奏，再选择本次要发哪一段。</div>
          </div>
          <button class="secondary" id="scan-featured-outline" type="button">读取文档目录</button>
        </div>
        <div class="grid">
          <div>
            <label for="featured-day">第几天</label>
            <select id="featured-day"></select>
          </div>
          <div>
            <label for="featured-rhythm">节奏</label>
            <select id="featured-rhythm"></select>
          </div>
        </div>
        <div class="featured-picker-list" id="featured-outline-summary"></div>
        <div class="featured-repair hidden" id="featured-outline-repair">
          <div id="featured-outline-repair-text">只识别到第1天，可能目录不完整。</div>
          <button type="button" id="deep-scan-featured-outline">滚动正文补全目录</button>
        </div>
        <div class="notice" id="featured-outline-status"></div>
      </div>
      <div class="radio-grid" id="read-range">
        <label class="choice"><input type="radio" name="readRangeMode" value="all" /> <strong>全文读取</strong><div class="muted">适合文档本来就只放本次内容。</div></label>
        <label class="choice"><input type="radio" name="readRangeMode" value="range" /> <strong>指定开始/结束位置</strong><div class="muted">从开始位置读到结束那条为止。</div></label>
      </div>
      <div id="range-options" class="grid hidden" style="margin-top:12px;">
        <div>
          <label for="range-start">开始位置关键词</label>
          <input id="range-start" placeholder="例如：8/21+福利单之后" />
        </div>
        <div>
          <label for="range-end">结束位置关键词</label>
          <input id="range-end" placeholder="例如：情意农农 8/19 19:10:15" />
        </div>
      </div>
      <div id="range-help" class="help hidden">
        <div class="help-title">关键词可以这样填</div>
        <ul>
          <li><strong>只填标题/小标题：</strong><code>福利单之后</code>、<code>明日合集预告</code>。适合全文只有一个同名标题。</li>
          <li><strong>日期 + 标题：</strong><code>8/21+福利单之后</code>。适合同名标题很多时，先定位到 8/21，再找下面的“福利单之后”。</li>
          <li><strong>完整人名时间行：</strong><code>豆妈 8/19 11:44:40</code>、<code>情意农农 8/19 19:10:15</code>。适合从某一句话开始或结束。</li>
          <li><strong>开头第一条是图片/表情包/视频：</strong>开始关键词请填它下面的文字，或同一条的人名+时间；不要只靠图片定位。</li>
          <li><strong>结束位置：</strong>填“最后一条要发的人名+时间”。程序会读取到这一条为止，下面的内容不发。</li>
          <li><strong>找不到时：</strong>把关键词写完整一点，比如从 <code>福利单之后</code> 改成 <code>8/21+福利单之后（四件套预热）</code>。</li>
        </ul>
      </div>
    </section>

    <section>
      <h2>4. 时间模式</h2>
      <div class="radio-grid" id="schedule-mode">
        <label class="choice"><input type="radio" name="scheduleMode" value="doc" /> <strong>文档时间</strong><div class="muted">按飞书上写的时间定。（适用：文案时间已经排好，只需要照着定时）</div></label>
        <label class="choice"><input type="radio" name="scheduleMode" value="realtime" /> <strong>实时跟发</strong><div class="muted">忽略文档时间，按开始/结束时间重排。（适用：临时跟发、当前时间已经晚于文案时间）</div></label>
        <label class="choice"><input type="radio" name="scheduleMode" value="catchup" /> <strong>补发到文档时间</strong><div class="muted">过期内容实时补发，后面能接上就回到文档时间。（适用：前面已经过期，但后面还想按文档时间发）</div></label>
      </div>
      <div id="time-options" class="grid hidden" style="margin-top:12px;">
        <div>
          <label for="start-time">开始时间</label>
          <input id="start-time" placeholder="不填默认 1 分钟后开始" />
        </div>
        <div id="end-time-wrap">
          <label for="end-time">结束时间</label>
          <input id="end-time" placeholder="可留空" />
        </div>
      </div>
      <details id="time-advanced-wrap" class="time-advanced hidden">
        <summary><span>更多时间设置</span><span class="time-advanced-summary-note" id="time-advanced-summary-note">当前：最晚完成</span></summary>
        <div class="time-advanced-body">
          <div>
            <div class="interval-title">结束时间用法</div>
            <div class="radio-grid" id="realtime-end-mode">
              <label class="choice"><input type="radio" name="realtimeEndMode" value="latest" /> <strong>最晚完成</strong><div class="muted">正常间隔能提前发完就提前发完，超过结束时间才询问是否压缩。</div></label>
              <label class="choice"><input type="radio" name="realtimeEndMode" value="stretch" /> <strong>铺满到结束时间</strong><div class="muted">按区间自然铺开，让最后一条尽量接近结束时间。</div></label>
            </div>
          </div>
          <div id="stretch-options" class="time-tool-row hidden">
            <span>铺满间隔范围</span>
            <span class="stretch-inputs">
              <input id="stretch-gap-min" type="number" min="0" placeholder="最短" /> -
              <input id="stretch-gap-max" type="number" min="0" placeholder="最长" /> 分钟
            </span>
            <span class="muted">默认 2-23 分钟；豆妈/托切换仍至少 2 分钟。</span>
          </div>
          <div class="time-tool-row">
            <button type="button" class="secondary" id="estimate-start">按结束时间反推开始时间</button>
            <span class="muted" id="estimate-start-status">预览前估算；最终以生成预览后的实际时间为准。</span>
          </div>
        </div>
      </details>
      <div id="custom-interval-options" class="interval-box hidden">
        <div class="interval-title">自定义间隔范围（可选）</div>
        <div class="muted">不填就沿用默认规则；只影响实时跟发和补发到文档时间。豆妈和托切换仍至少 2 分钟。</div>
        <div class="interval-grid">
          <label class="interval-row"><span>不同托之间（非互动）</span><span class="interval-pair"><input type="number" min="0" data-interval-key="differentTuo" data-interval-side="min" placeholder="最短" /> - <input type="number" min="0" data-interval-key="differentTuo" data-interval-side="max" placeholder="最长" /> 秒</span></label>
          <label class="interval-row"><span>同一个托连续说话</span><span class="interval-pair"><input type="number" min="0" data-interval-key="sameTuo" data-interval-side="min" placeholder="最短" /> - <input type="number" min="0" data-interval-key="sameTuo" data-interval-side="max" placeholder="最长" /> 秒</span></label>
          <label class="interval-row"><span>豆妈连续内容</span><span class="interval-pair"><input type="number" min="0" data-interval-key="doumaSame" data-interval-side="min" placeholder="最短" /> - <input type="number" min="0" data-interval-key="doumaSame" data-interval-side="max" placeholder="最长" /> 秒</span></label>
          <label class="interval-row"><span>豆妈/托切换</span><span class="interval-pair"><input type="number" min="0" data-interval-key="roleSwitch" data-interval-side="min" placeholder="最短" /> - <input type="number" min="0" data-interval-key="roleSwitch" data-interval-side="max" placeholder="最长" /> 秒</span></label>
        </div>
      </div>
      <div class="notice" id="time-notice"></div>
      <div class="muted" id="default-interval-rules" style="margin-top:6px;"></div>
    </section>

    <div class="actions">
      <div class="notice" id="save-status" style="margin-right:auto;"></div>
      <button class="secondary" id="restart-preview">放弃本轮，返回修改</button>
      <button class="danger" id="exit">退出</button>
      <button id="save">保存设置，生成预览</button>
    </div>
  </main>
  <script id="state" type="application/json">${json}</script>
  <script id="run-state" type="application/json">${runJson}</script>
  <script>
    const state = JSON.parse(document.getElementById("state").textContent);
    const initialRunState = JSON.parse(document.getElementById("run-state").textContent);
    const $ = (id) => document.getElementById(id);
    const intervalKeys = ["differentTuo", "sameTuo", "doumaSame", "roleSwitch"];

    $("feishu-url").value = state.feishuUrl || "";
    $("feishu-title").value = state.feishuTitle || "未读取标题，保存后读取飞书时会更新";
    $("feishu-title").dataset.readTitle = state.feishuTitle || "";
    $("not-in-group").value = state.randomRobotNotInGroupAction || "retry";
    $("fixed-prefix").value = state.fixedRolePrefix || "";
    $("fixed-sheet").value = state.fixedRoleSheetUrl || "";
    $("range-start").value = state.readRangeStart || "";
    $("range-end").value = state.readRangeEnd || "";
    $("start-time").value = state.realtimeStartTime || "";
    $("end-time").value = state.realtimeEndTime || "";
    $("stretch-gap-min").value = state.stretchGapMinMinutes ?? 2;
    $("stretch-gap-max").value = state.stretchGapMaxMinutes ?? 23;
    setIntervalInputs(state.customIntervals || {});

    setRadio("tuoMode", state.tuoMode || "random");
    setRadio("readRangeMode", state.readRangeEnabled ? "range" : "all");
    setRadio("scheduleMode", state.scheduleMode || "doc");
    setRadio("realtimeEndMode", state.realtimeEndMode || "latest");
    refreshVisibility();

    const originalFeishuUrl = state.feishuUrl || "";
    const originalFeishuTitle = state.feishuTitle || "";
    const originalFeishuTitleUrl = state.feishuTitleUrl || (state.feishuTitle ? state.feishuUrl : "");
    let hasSubmitted = false;
    let isSubmitting = false;
    let titleReadTimer = null;
    let titleReadSeq = 0;
    let titleReadInFlightUrl = "";
    let lastTitleReadUrl = normalizeUrlClient(originalFeishuTitleUrl || originalFeishuUrl);
    let lastTitleReadValue = originalFeishuTitle || "";
    let featuredOutline = null;
    let activeDocumentUrl = normalizeUrlClient(originalFeishuUrl);
    let invalidatedDocumentUrl = "";
    let invalidateInFlight = false;
    $("feishu-title").dataset.titleUrl = originalFeishuTitleUrl || "";
    resetFeaturedOutlineSelects("请先读取目录");
    $("feishu-url").addEventListener("input", () => {
      handleFeishuUrlChanged();
      scheduleTitleRead("正在读取当前链接标题...");
    });
    $("feishu-url").addEventListener("paste", () => {
      setTimeout(() => {
        handleFeishuUrlChanged();
        scheduleTitleRead("正在读取粘贴的链接标题...", 120);
      }, 0);
    });
    $("feishu-url").addEventListener("blur", () => readTitleNow($("feishu-url").value.trim()));

    document.querySelectorAll("input[type=radio]").forEach((input) => {
      input.addEventListener("change", refreshVisibility);
    });
    document.querySelectorAll(".choice").forEach((choice) => {
      choice.addEventListener("click", () => {
        const input = choice.querySelector("input[type=radio]");
        if (input) {
          input.checked = true;
          input.dispatchEvent(new Event("change", { bubbles: true }));
        }
      });
    });
    document.querySelectorAll("input, select").forEach((input) => {
      if (input.id === "feishu-title") return;
      input.addEventListener("input", markSettingsChanged);
      input.addEventListener("change", markSettingsChanged);
    });
    ["end-time", "stretch-gap-min", "stretch-gap-max"].forEach((id) => {
      $(id).addEventListener("input", refreshVisibility);
      $(id).addEventListener("change", refreshVisibility);
    });
    $("range-start").addEventListener("input", clearFeaturedAutoRange);
    $("range-end").addEventListener("input", clearFeaturedAutoRange);
    $("scan-featured-outline").onclick = scanFeaturedOutline;
    $("deep-scan-featured-outline").onclick = deepScanFeaturedOutline;
    $("check-update").onclick = checkUpdate;
    $("install-update").onclick = installUpdate;
    $("estimate-start").onclick = estimateStartTime;
    $("featured-day").addEventListener("change", () => {
      renderFeaturedRhythmOptions();
      applyFeaturedSelectionToRange();
    });
    $("featured-rhythm").addEventListener("change", applyFeaturedSelectionToRange);

    $("restart-preview").onclick = () => {
      if (!confirm("当前已经生成但还没确认的预览会作废，不会开始发单。确定放弃本轮并返回修改设置吗？")) return;
      finish("restart", {});
    };
    $("exit").onclick = () => finish("exit");
    $("run-pause").onclick = () => sendRunAction("pause");
    $("run-resume").onclick = () => sendRunAction("resume");
    $("run-stop").onclick = () => sendRunAction("stop");
    document.querySelectorAll("[data-standby-action]").forEach((button) => {
      button.addEventListener("click", () => sendStandbyCommand(button.dataset.standbyAction));
    });
    document.querySelectorAll("[data-gap-action]").forEach((button) => {
      button.addEventListener("click", () => sendRealtimeGapChoice(button.dataset.gapAction));
    });
    document.querySelectorAll("[data-cms-setup-action]").forEach((button) => {
      button.addEventListener("click", () => sendCmsSetupAction(button.dataset.cmsSetupAction));
    });
    $("save").onclick = () => {
      const settings = collectSettings();
      fillDefaultStartTime(settings);
      const error = validate(settings);
      if (error) {
        $("save-status").textContent = error;
        return;
      }
      finish("continue", settings);
    };
    updateRunState(initialRunState);
    setInterval(refreshRunState, 900);

    function collectSettings() {
      return {
        feishuUrl: $("feishu-url").value.trim(),
        feishuTitle: $("feishu-title").dataset.readTitle || "",
        feishuTitleUrl: $("feishu-title").dataset.titleUrl || "",
        projectType: "collection",
        tuoMode: getRadio("tuoMode"),
        randomRobotNotInGroupAction: $("not-in-group").value,
        fixedRolePrefix: $("fixed-prefix").value.trim(),
        fixedRoleSheetUrl: $("fixed-sheet").value.trim(),
        readRangeMode: getRadio("readRangeMode"),
        readRangeStart: $("range-start").value.trim(),
        readRangeEnd: $("range-end").value.trim(),
        readRangeEndExclusive: $("range-start").dataset.autoRange === "featured" && $("range-end").dataset.endExclusive === "true",
        readRangeEndAtDocumentEnd: $("range-start").dataset.autoRange === "featured" && $("range-end").dataset.endAtDocumentEnd === "true",
        scheduleMode: getRadio("scheduleMode"),
        realtimeStartTime: $("start-time").value.trim(),
        realtimeEndTime: $("end-time").value.trim(),
        realtimeEndMode: getRadio("realtimeEndMode"),
        stretchGapMinMinutes: $("stretch-gap-min").value.trim(),
        stretchGapMaxMinutes: $("stretch-gap-max").value.trim(),
        customIntervals: collectCustomIntervals()
      };
    }

    function setIntervalInputs(intervals) {
      intervalKeys.forEach((key) => {
        const item = intervals[key] || {};
        document.querySelectorAll('[data-interval-key="' + key + '"]').forEach((input) => {
          input.value = item[input.dataset.intervalSide] ?? "";
        });
      });
    }

    function collectCustomIntervals() {
      const result = {};
      intervalKeys.forEach((key) => {
        const min = document.querySelector('[data-interval-key="' + key + '"][data-interval-side="min"]')?.value.trim() || "";
        const max = document.querySelector('[data-interval-key="' + key + '"][data-interval-side="max"]')?.value.trim() || "";
        if (min || max) result[key] = { min, max };
      });
      return result;
    }

    function validateCustomIntervals(intervals) {
      for (const key of intervalKeys) {
        const item = intervals[key] || {};
        const min = item.min === "" || item.min === undefined ? null : Number(item.min);
        const max = item.max === "" || item.max === undefined ? null : Number(item.max);
        if ((min !== null && (!Number.isFinite(min) || min < 0)) || (max !== null && (!Number.isFinite(max) || max < 0))) return "自定义间隔只能填写 0 以上的秒数。";
        if (min !== null && max !== null && max < min) return "自定义间隔的最长时间不能小于最短时间。";
      }
      return "";
    }

    function validate(settings) {
      if (!settings.feishuUrl) return "请先填写飞书文档链接。";
      if (!/^https?:\\/\\//.test(settings.feishuUrl) || !settings.feishuUrl.includes("feishu.cn/")) return "飞书链接看起来不对，请粘贴完整链接。";
      if (settings.tuoMode === "fixed" && !settings.fixedRolePrefix) return "精细版需要填写角色范围/前缀。";
      if (settings.readRangeMode === "range" && (!settings.readRangeStart || (!settings.readRangeEnd && !settings.readRangeEndAtDocumentEnd))) return "指定范围时，开始和结束关键词都要填写。";
      if ((settings.scheduleMode === "realtime" || settings.scheduleMode === "catchup") && !/^\\d{1,2}[:：]\\d{1,2}(:\\d{1,2})?$/.test(settings.realtimeStartTime)) return "请填写正确的开始时间，例如 10:30:00。";
      if (settings.scheduleMode === "realtime" && settings.realtimeEndTime && !/^\\d{1,2}[:：]\\d{1,2}(:\\d{1,2})?$/.test(settings.realtimeEndTime)) return "结束时间格式不对，例如 18:00:00，或者留空。";
      const stretchError = validateStretchSettings(settings);
      if (stretchError) return stretchError;
      const intervalError = validateCustomIntervals(settings.customIntervals || {});
      if (intervalError) return intervalError;
      return "";
    }

    function validateStretchSettings(settings) {
      if (settings.scheduleMode !== "realtime" || settings.realtimeEndMode !== "stretch") return "";
      if (!settings.realtimeEndTime) return "铺满到结束时间需要填写结束时间。";
      const min = Number(settings.stretchGapMinMinutes);
      const max = Number(settings.stretchGapMaxMinutes);
      if (!Number.isFinite(min) || !Number.isFinite(max) || min < 0 || max < 0) return "铺满间隔范围只能填写 0 以上的分钟数。";
      if (max < min) return "铺满间隔的最长分钟不能小于最短分钟。";
      return "";
    }

    function fillDefaultStartTime(settings) {
      if (settings.scheduleMode !== "realtime" && settings.scheduleMode !== "catchup") return;
      if (settings.realtimeStartTime) return;
      settings.realtimeStartTime = defaultStartTimeAfterLead();
      $("start-time").value = settings.realtimeStartTime;
      $("save-status").textContent = "开始时间未填写，已自动设为 1 分钟后：" + settings.realtimeStartTime;
    }

    function defaultStartTimeAfterLead() {
      const date = new Date(Date.now() + 60 * 1000);
      const pad = (value) => String(value).padStart(2, "0");
      return pad(date.getHours()) + ":" + pad(date.getMinutes()) + ":" + pad(date.getSeconds());
    }

    function refreshVisibility() {
      const tuoMode = getRadio("tuoMode");
      const readRangeMode = getRadio("readRangeMode");
      const scheduleMode = getRadio("scheduleMode");
      $("featured-picker").classList.toggle("hidden", false);
      $("featured-picker-title").textContent = "文档目录选择";
      $("scan-featured-outline").textContent = "读取文档目录";
      $("random-options").classList.toggle("hidden", tuoMode !== "random");
      $("fixed-options").classList.toggle("hidden", tuoMode !== "fixed");
      $("range-options").classList.toggle("hidden", readRangeMode !== "range");
      $("range-help").classList.toggle("hidden", readRangeMode !== "range");
      $("time-options").classList.toggle("hidden", scheduleMode === "doc");
      $("custom-interval-options").classList.toggle("hidden", scheduleMode === "doc");
      $("end-time-wrap").classList.toggle("hidden", scheduleMode !== "realtime");
      $("time-advanced-wrap").classList.toggle("hidden", scheduleMode !== "realtime");
      const realtimeEndMode = getRadio("realtimeEndMode") || "latest";
      const stretchMin = $("stretch-gap-min").value.trim() || "2";
      const stretchMax = $("stretch-gap-max").value.trim() || "23";
      $("stretch-options").classList.toggle("hidden", realtimeEndMode !== "stretch");
      $("time-advanced-summary-note").textContent = realtimeEndMode === "stretch"
        ? "当前：铺满到结束时间 " + stretchMin + "-" + stretchMax + " 分钟"
        : "当前：最晚完成";
      const latestEndHint = scheduleMode === "realtime" && realtimeEndMode !== "stretch" && $("end-time").value.trim()
        ? " 当前不会强行铺满结束时间；需要贴近结束时间时，请展开“更多时间设置”选择“铺满到结束时间”。"
        : "";
      $("time-notice").textContent = scheduleMode === "doc" ? "" :
        scheduleMode === "realtime" ? "实时跟发会按你输入的时间重新排列，但豆妈和托切换仍按规则留间隔。" + latestEndHint :
        "补发模式会把过期内容往当前时间后排，后面能接上就回到飞书原时间。";
      $("default-interval-rules").textContent = scheduleMode === "doc" ? "" :
        "默认规则：同一个托连续文字约 20-45 秒；豆妈连续内容约 45 秒；图片/表情包/视频附近约 30-50 秒；不同托非互动估算约 35 秒；豆妈/托切换至少 120 秒。";
      document.querySelectorAll(".choice").forEach((choice) => {
        const input = choice.querySelector("input[type=radio]");
        choice.classList.toggle("active", Boolean(input && input.checked));
      });
    }

    function setRadio(name, value) {
      const input = document.querySelector('input[name="' + name + '"][value="' + value + '"]');
      if (input) input.checked = true;
    }

    function getRadio(name) {
      return document.querySelector('input[name="' + name + '"]:checked')?.value || "";
    }

    async function finish(action, settings = {}) {
      if (isSubmitting) return;
      isSubmitting = true;
      $("save-status").textContent = action === "restart" ? "正在放弃本轮，请稍等..." : (action === "continue" ? "已保存，正在读取飞书并生成预览..." : "已提交。");
      $("save").disabled = true;
      $("restart-preview").disabled = true;
      let result = null;
      try {
        const response = await fetch("/finish", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ action, settings })
        });
        result = await response.json().catch(() => null);
        if (!response.ok || !result?.ok) {
          $("save-status").textContent = result?.error || "保存失败，请重试。";
          $("save").disabled = false;
          $("restart-preview").disabled = false;
          isSubmitting = false;
          return;
        }
      } catch {
        $("save-status").textContent = "保存失败，请重试。";
        $("save").disabled = false;
        $("restart-preview").disabled = false;
        isSubmitting = false;
        return;
      }
      if (result?.state) updateRunState(result.state);
      hasSubmitted = true;
      isSubmitting = false;
      $("restart-preview").disabled = false;
      if (action === "continue") {
        $("save-status").textContent = "已保存。页面会继续保留，可在上方看运行状态或暂停。";
      } else if (action === "restart") {
        hasSubmitted = false;
        $("save").disabled = false;
        $("save-status").textContent = "本轮已放弃。请修改设置后，再点“保存设置，生成预览”。";
      } else {
        $("save-status").textContent = "已退出。";
      }
    }

    function markSettingsChanged() {
      if (isSubmitting) return;
      if (!hasSubmitted) return;
      $("save").disabled = false;
      $("restart-preview").disabled = false;
      $("save-status").textContent = "设置已修改，可以再次点“保存设置，生成预览”。";
    }

    async function sendRunAction(action) {
      await fetch("/run-action", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action })
      }).then((res) => res.json()).then((result) => {
        if (result && result.state) updateRunState(result.state);
      }).catch(() => {});
    }

    async function refreshRunState() {
      try {
        const result = await fetch("/run-state").then((res) => res.json());
        if (result && result.state) updateRunState(result.state);
      } catch {}
    }

    async function checkUpdate() {
      $("check-update").disabled = true;
      $("install-update").classList.add("hidden");
      $("update-status").textContent = "正在检查更新...";
      try {
        const result = await fetch("/update-status").then((res) => res.json());
        if (!result.ok) {
          $("update-status").textContent = result.error || "检查更新失败。";
          return;
        }
        if (!result.hasUpdate) {
          $("update-status").textContent = "当前已经是最新版本：" + (result.currentVersion || "-");
          return;
        }
        const notes = Array.isArray(result.notes) && result.notes.length ? "：" + result.notes.join("；") : "";
        $("update-status").textContent = "发现新版本 " + result.latestVersion + notes;
        $("install-update").classList.remove("hidden");
      } catch {
        $("update-status").textContent = "检查更新失败，请稍后再试。";
      } finally {
        $("check-update").disabled = false;
      }
    }

    async function installUpdate() {
      $("check-update").disabled = true;
      $("install-update").disabled = true;
      const oldText = $("install-update").textContent;
      $("install-update").textContent = "正在更新...";
      $("update-status").textContent = "正在更新：检查版本并下载补丁...";
      try {
        const result = await fetch("/install-update", { method: "POST" }).then((res) => res.json());
        if (!result.ok) {
          $("update-status").textContent = result.error || "更新失败。";
          $("install-update").disabled = false;
          $("check-update").disabled = false;
          $("install-update").textContent = oldText;
          return;
        }
        if (result.alreadyLatest) {
          $("update-status").textContent = "当前已经是最新版本：" + (result.currentVersion || result.latestVersion || "-");
          $("install-update").classList.add("hidden");
          $("install-update").disabled = false;
          $("check-update").disabled = false;
          $("install-update").textContent = oldText;
          return;
        }
        $("update-status").textContent = "更新成功，请关闭当前窗口后重新打开 START.cmd。";
        $("install-update").classList.add("hidden");
      } catch (error) {
        $("update-status").textContent = "更新失败：" + (error?.message || "请检查网络后重试。");
        $("install-update").disabled = false;
        $("check-update").disabled = false;
        $("install-update").textContent = oldText;
      }
    }

    async function estimateStartTime() {
      const settings = collectSettings();
      const error = validateEstimate(settings);
      if (error) {
        $("estimate-start-status").textContent = error;
        return;
      }
      $("estimate-start").disabled = true;
      $("estimate-start-status").textContent = "正在读取飞书并估算...";
      try {
        const response = await fetch("/estimate-start-time", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ settings })
        });
        const result = await response.json().catch(() => null);
        if (!response.ok || !result?.ok) {
          $("estimate-start-status").textContent = result?.error || "估算失败，请检查飞书链接和读取范围。";
          return;
        }
        const roleStats = result.roleStats || {};
        const warning = result.previousDay ? "\\n注意：反推结果落在前一天，请确认是否符合本次安排。" : "";
        const message =
          "估算结果：" +
          "\\n" + (result.summary || ("共 " + result.totalTasks + " 条")) +
          "\\n豆妈 " + (roleStats.douma || 0) + " 条，托 " + (roleStats.tuo || 0) + " 条" +
          "\\n结束时间：" + result.endTime +
          "\\n建议开始时间：" + result.startTime +
          warning +
          "\\n\\n是否把开始时间改成 " + result.startTime + "？";
        if (confirm(message)) {
          $("start-time").value = result.startTime;
          $("estimate-start-status").textContent = "已写入建议开始时间：" + result.startTime + "。保存后再生成预览。";
          markSettingsChanged();
        } else {
          $("estimate-start-status").textContent = "已估算但未修改开始时间：" + result.startTime + "。";
        }
      } catch {
        $("estimate-start-status").textContent = "估算失败，请稍后再试。";
      } finally {
        $("estimate-start").disabled = false;
      }
    }

    function validateEstimate(settings) {
      if (settings.scheduleMode !== "realtime") return "只有实时跟发模式可以按结束时间反推。";
      if (!settings.feishuUrl) return "请先填写飞书文档链接。";
      if (!/^https?:\\/\\//.test(settings.feishuUrl) || !settings.feishuUrl.includes("feishu.cn/")) return "飞书链接看起来不对，请粘贴完整链接。";
      if (!/^\\d{1,2}[:：]\\d{1,2}(:\\d{1,2})?$/.test(settings.realtimeEndTime)) return "请先填写正确的结束时间，例如 18:00:00。";
      if (settings.readRangeMode === "range" && (!settings.readRangeStart || (!settings.readRangeEnd && !settings.readRangeEndAtDocumentEnd))) return "指定范围时，开始和结束关键词都要填写。";
      const intervalError = validateCustomIntervals(settings.customIntervals || {});
      if (intervalError) return intervalError;
      return "";
    }

    async function sendStandbyCommand(action) {
      $("standby-status").textContent = "正在提交选择...";
      const payload = { action };
      if (action === "change-url") payload.feishuUrl = $("standby-url").value.trim();
      await fetch("/standby-command", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload)
      }).then((res) => res.json()).then((result) => {
        if (!result?.ok) {
          $("standby-status").textContent = result?.error || "提交失败，请重试。";
          return;
        }
        $("standby-status").textContent = "已提交，程序会继续下一步。";
        if (result.state) updateRunState(result.state);
      }).catch(() => {
        $("standby-status").textContent = "提交失败，请重试。";
      });
    }

    async function sendRealtimeGapChoice(action) {
      $("gap-choice-status").textContent = "正在提交选择...";
      await fetch("/realtime-gap-choice", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action })
      }).then((res) => res.json()).then((result) => {
        if (!result?.ok) {
          $("gap-choice-status").textContent = result?.error || "提交失败，请重试。";
          return;
        }
        $("gap-choice-status").textContent = "已提交，正在继续生成预览。";
        if (result.state) updateRunState(result.state);
      }).catch(() => {
        $("gap-choice-status").textContent = "提交失败，请重试。";
      });
    }

    async function sendCmsSetupAction(action) {
      $("cms-setup-status").textContent = "正在提交选择...";
      await fetch("/cms-setup-action", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action })
      }).then((res) => res.json()).then((result) => {
        if (!result?.ok) {
          $("cms-setup-status").textContent = result?.error || "提交失败，请重试。";
          return;
        }
        $("cms-setup-status").textContent = "已提交，程序会继续下一步。";
        if (result.state) updateRunState(result.state);
      }).catch(() => {
        $("cms-setup-status").textContent = "提交失败，请重试。";
      });
    }

    function updateRunState(runState) {
      const status = runState.stopped ? "已停止" : runState.paused ? "已暂停" : runState.available ? "运行中" : "等待设置";
      $("run-status").textContent = status;
      renderRunCurrent(runState);
      $("run-updated").textContent = runState.updatedAt || "-";
      $("pause-tip").classList.toggle("hidden", !runState.paused || runState.stopped);
      $("run-pause").disabled = !runState.available || runState.paused || runState.stopped;
      $("run-resume").disabled = !runState.available || !runState.paused || runState.stopped;
      $("run-stop").disabled = !runState.available || runState.stopped;
      $("standby-actions").classList.toggle("hidden", !runState.waitingStandbyCommand);
      $("cms-setup-action").classList.toggle("hidden", !runState.waitingCmsSetupAction);
      updateGapChoice(runState);
    }

    function renderRunCurrent(runState) {
      const current = runState.current || "等待设置";
      const stepProgress = runState.progress || null;
      if (stepProgress && !runState.paused && !runState.stopped) {
        const percent = Math.max(0, Math.min(100, Number(stepProgress.percent) || 0));
        const filled = Math.max(0, Math.min(10, Math.floor(percent / 10)));
        const bars = Array.from({ length: 10 }, (_, index) => '<span class="' + (index < filled ? 'on' : '') + '"></span>').join("");
        const countText = '(' + Number(stepProgress.current || 0) + '/' + Number(stepProgress.total || 0) + ')';
        const detail = stepProgress.detail ? ' ' + escapeHtml(stepProgress.detail) : '';
        $("run-current").innerHTML =
          '<span class="run-current-line">' +
          '<span>' + escapeHtml(stepProgress.label || current) + '</span>' +
          '<span class="run-percent">' + percent + '%</span>' +
          '<span class="muted">' + countText + detail + '</span>' +
          '<span class="run-bar" aria-label="当前进度">' + bars + '</span>' +
          '</span>';
        return;
      }
      const progress = runState.waitProgress || null;
      if (!progress || runState.paused || runState.stopped) {
        $("run-current").textContent = current;
        return;
      }
      const totalMs = Math.max(1, Number(progress.totalMs) || 1);
      const startedAt = Number(progress.startedAt) || Date.now();
      const percent = Math.max(0, Math.min(100, Math.floor(((Date.now() - startedAt) / totalMs) * 100)));
      const filled = Math.max(0, Math.min(10, Math.floor(percent / 10)));
      const bars = Array.from({ length: 10 }, (_, index) => '<span class="' + (index < filled ? 'on' : '') + '"></span>').join("");
      $("run-current").innerHTML =
        '<span class="run-current-line">' +
        '<span>' + escapeHtml(progress.label || current) + '</span>' +
        '<span class="run-percent">' + percent + '%</span>' +
        '<span class="run-bar" aria-label="等待进度">' + bars + '</span>' +
        '</span>';
    }

    function updateGapChoice(runState) {
      const waiting = Boolean(runState.waitingRealtimeGapChoice);
      $("gap-choice").classList.toggle("hidden", !waiting);
      if (!waiting) return;
      const info = runState.realtimeGapInfo || {};
      const mode = info.mode || "compressible";
      $("gap-choice-compressible").classList.toggle("hidden", mode !== "compressible");
      $("gap-choice-too-short").classList.toggle("hidden", mode !== "too-short");
      $("gap-choice-stretch-too-loose").classList.toggle("hidden", mode !== "stretch-too-loose");
      if (mode === "too-short") {
        $("gap-choice-detail").textContent =
          "正常会排到 " + (info.normalEnd || "-") +
          "，压到最短也会排到 " + (info.minEnd || "-") +
          "，超过你填的结束时间 " + (info.endTime || "-") +
          "。豆妈和托切换至少 2 分钟，不会继续压缩。";
      } else if (mode === "stretch-too-loose") {
        $("gap-choice-detail").textContent =
          "按你填的最长间隔会排到 " + (info.maxEnd || "-") +
          "，早于结束时间 " + (info.endTime || "-") +
          "。可以放宽最长间隔铺满，也可以按最长间隔提前结束。";
      } else {
        $("gap-choice-detail").textContent =
          "正常会排到 " + (info.normalEnd || "-") +
          "，超过你填的结束时间 " + (info.endTime || "-") +
          "；压缩后预计可以在结束时间前排完。";
      }
    }

    function handleFeishuUrlChanged() {
      const nextUrl = normalizeUrlClient($("feishu-url").value.trim());
      if (!nextUrl || nextUrl === activeDocumentUrl) return;
      activeDocumentUrl = nextUrl;
      lastTitleReadUrl = "";
      lastTitleReadValue = "";
      $("feishu-title").value = "链接已变，正在重新读取标题";
      $("feishu-title").dataset.readTitle = "";
      $("feishu-title").dataset.titleUrl = "";
      resetFeaturedOutlineSelects("链接已变，请重新读取目录");
      $("featured-outline-status").textContent = "链接已变，请重新读取目录。";
      $("save-status").textContent = "已切换文档，本轮旧预览会自动作废；设置好后直接保存生成预览。";
      invalidateCurrentRound(nextUrl, "链接已变，本轮旧预览已作废，请重新保存生成预览");
    }

    async function invalidateCurrentRound(feishuUrl, reason) {
      if (!feishuUrl || invalidateInFlight || invalidatedDocumentUrl === feishuUrl) return;
      invalidatedDocumentUrl = feishuUrl;
      invalidateInFlight = true;
      try {
        const result = await fetch("/invalidate-round", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ feishuUrl, reason })
        }).then((res) => res.json()).catch(() => null);
        if (result?.state) updateRunState(result.state);
      } finally {
        invalidateInFlight = false;
      }
    }

    function scheduleTitleRead(message, delay = 900) {
      const nextUrl = normalizeUrlClient($("feishu-url").value.trim());
      if (titleReadTimer) clearTimeout(titleReadTimer);
      if (!nextUrl) {
        $("feishu-title").value = "请先粘贴飞书文档链接";
        $("feishu-title").dataset.readTitle = "";
        $("feishu-title").dataset.titleUrl = "";
        return;
      }
      if (nextUrl === titleReadInFlightUrl) {
        $("feishu-title").value = "正在读取文档标题...";
        return;
      }
      if (nextUrl === lastTitleReadUrl && lastTitleReadValue) {
        $("feishu-title").value = lastTitleReadValue;
        $("feishu-title").dataset.readTitle = lastTitleReadValue;
        $("feishu-title").dataset.titleUrl = nextUrl;
        return;
      }
      $("feishu-title").value = message || "正在读取文档标题...";
      $("feishu-title").dataset.readTitle = "";
      $("feishu-title").dataset.titleUrl = "";
      titleReadTimer = setTimeout(() => readTitleNow(nextUrl), delay);
    }

    async function readTitleNow(rawUrl, options = {}) {
      const feishuUrl = normalizeUrlClient(rawUrl);
      if (titleReadTimer) {
        clearTimeout(titleReadTimer);
        titleReadTimer = null;
      }
      if (!feishuUrl) {
        $("feishu-title").dataset.titleUrl = "";
        return;
      }
      const cachedTitleUrl = normalizeUrlClient(originalFeishuTitleUrl);
      if (!options.force && feishuUrl === normalizeUrlClient(originalFeishuUrl) && originalFeishuTitle && (!cachedTitleUrl || cachedTitleUrl === feishuUrl)) {
        $("feishu-title").value = originalFeishuTitle;
        $("feishu-title").dataset.readTitle = originalFeishuTitle;
        $("feishu-title").dataset.titleUrl = feishuUrl;
        return;
      }
      if (feishuUrl === titleReadInFlightUrl) {
        $("feishu-title").value = "正在读取文档标题...";
        return;
      }
      if (!options.force && feishuUrl === lastTitleReadUrl && lastTitleReadValue) {
        $("feishu-title").value = lastTitleReadValue;
        $("feishu-title").dataset.readTitle = lastTitleReadValue;
        $("feishu-title").dataset.titleUrl = feishuUrl;
        return;
      }
      if (!/^https?:\\/\\//.test(feishuUrl) || !feishuUrl.includes("feishu.cn/")) {
        $("feishu-title").value = "链接格式不对，标题暂时不能读取";
        $("feishu-title").dataset.readTitle = "";
        $("feishu-title").dataset.titleUrl = "";
        return;
      }
      if ($("feishu-url").value.trim() !== feishuUrl) $("feishu-url").value = feishuUrl;
      const seq = ++titleReadSeq;
      titleReadInFlightUrl = feishuUrl;
      $("feishu-title").value = "正在读取文档标题...";
      try {
        const response = await fetch("/read-title", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ feishuUrl, projectType: "collection" })
        });
        const result = await response.json();
        if (seq !== titleReadSeq) return;
        if (result.ok && (result.title || result.outline?.days?.length)) {
          if (result.title) {
            $("feishu-title").value = result.title;
            $("feishu-title").dataset.readTitle = result.title;
            $("feishu-title").dataset.titleUrl = feishuUrl;
            lastTitleReadUrl = feishuUrl;
            lastTitleReadValue = result.title;
            activeDocumentUrl = feishuUrl;
          } else {
            $("feishu-title").value = "标题暂时没读到，但目录已读取";
            $("feishu-title").dataset.readTitle = "";
            $("feishu-title").dataset.titleUrl = "";
            activeDocumentUrl = feishuUrl;
          }
          if (result.outline?.days?.length) {
            applyFeaturedOutlineResult(result, false, { fromTitleRead: true });
          }
        } else {
          $("feishu-title").value = result.error || "暂时没有读到标题，保存后会更新";
          $("feishu-title").dataset.readTitle = "";
          $("feishu-title").dataset.titleUrl = "";
        }
      } catch {
        if (seq !== titleReadSeq) return;
        $("feishu-title").value = "标题读取失败，保存后读取飞书时会再更新";
        $("feishu-title").dataset.readTitle = "";
        $("feishu-title").dataset.titleUrl = "";
      } finally {
        if (titleReadInFlightUrl === feishuUrl) titleReadInFlightUrl = "";
      }
    }

    async function scanFeaturedOutline() {
      const feishuUrl = normalizeUrlClient($("feishu-url").value.trim());
      const outlineLabel = outlineProjectLabel();
      if (!feishuUrl || !feishuUrl.includes("feishu.cn/")) {
        $("featured-outline-status").textContent = "请先粘贴完整的飞书文档链接。";
        return;
      }
      $("featured-outline-status").textContent = "正在读取" + outlineLabel + "目录...";
      $("featured-outline-repair").classList.add("hidden");
      $("scan-featured-outline").disabled = true;
      try {
        const result = await fetchFeaturedOutline(feishuUrl, false);
        if (!result.ok || !result.outline?.days?.length) {
          resetFeaturedOutlineSelects(result.error || "没有识别到目录。");
          $("featured-outline-status").textContent = result.error || "没有识别到目录，请先手动填写范围。";
          return;
        }
        applyFeaturedOutlineResult(result, false);
      } catch {
        resetFeaturedOutlineSelects("读取失败");
        $("featured-outline-status").textContent = "读取目录失败，请先手动填写范围。";
      } finally {
        $("scan-featured-outline").disabled = false;
      }
    }

    async function deepScanFeaturedOutline() {
      const feishuUrl = normalizeUrlClient($("feishu-url").value.trim());
      const outlineLabel = outlineProjectLabel();
      if (!feishuUrl || !feishuUrl.includes("feishu.cn/")) {
        $("featured-outline-status").textContent = "请先粘贴完整的飞书文档链接。";
        return;
      }
      $("featured-outline-status").textContent = "正在滚动正文补全" + outlineLabel + "目录...";
      $("deep-scan-featured-outline").disabled = true;
      $("scan-featured-outline").disabled = true;
      try {
        const result = await fetchFeaturedOutline(feishuUrl, true);
        if (!result.ok || !result.outline?.days?.length) {
          $("featured-outline-status").textContent = result.error || "滚动正文补全后仍没有识别到目录，请先手动填写范围。";
          return;
        }
        applyFeaturedOutlineResult(result, true);
      } catch {
        $("featured-outline-status").textContent = "滚动正文补全失败，请先手动填写范围。";
      } finally {
        $("deep-scan-featured-outline").disabled = false;
        $("scan-featured-outline").disabled = false;
      }
    }

    async function fetchFeaturedOutline(feishuUrl, deepScan) {
      const response = await fetch("/featured-outline", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ feishuUrl, deepScan, projectType: "collection" })
      });
      return response.json();
    }

    function applyFeaturedOutlineResult(result, deepScan, options = {}) {
      featuredOutline = result.outline;
      renderFeaturedDayOptions();
      renderFeaturedRhythmOptions();
      renderFeaturedOutlineSummary();
      applyFeaturedSelectionToRange();
      const stats = result.stats || outlineStats(featuredOutline);
      const prefix = options.fromTitleRead ? "标题和" + outlineProjectLabel() + "目录已读取" : (deepScan ? "滚动正文补全完成" : "已读取目录");
      const diagnostics = result.outline?.diagnostics || {};
      const warnings = Array.isArray(diagnostics.warnings) ? diagnostics.warnings : [];
      const detail = deepScan && Number.isFinite(Number(diagnostics.sidebarDays)) && Number.isFinite(Number(diagnostics.documentDays))
        ? "（快扫 " + diagnostics.sidebarDays + " 天，正文补全 " + diagnostics.documentDays + " 天）"
        : "";
      $("featured-outline-status").textContent = prefix + "：" + stats.days + " 天 / " + stats.rhythms + " 个节奏" + detail + "，请选择第几天和节奏。" + (warnings.length ? " 提醒：" + warnings.join("；") + "。" : "");
      if (!deepScan && result.needDeepScan) {
        $("featured-outline-repair-text").textContent = warnings.length
          ? "目录自检发现：" + warnings.join("；") + "，建议滚动正文补全后再选择。"
          : "当前只识别到 " + stats.days + " 天 / " + stats.rhythms + " 个节奏，可能目录不完整。";
        $("featured-outline-repair").classList.remove("hidden");
      } else {
        $("featured-outline-repair").classList.add("hidden");
      }
    }

    function outlineStats(outline) {
      const days = outline?.days || [];
      return {
        days: days.length,
        rhythms: days.reduce((sum, day) => sum + (day.rhythms?.length || 0), 0)
      };
    }

    function resetFeaturedOutlineSelects(message) {
      featuredOutline = null;
      $("featured-day").innerHTML = '<option value="">' + (message || "请先读取目录") + '</option>';
      $("featured-rhythm").innerHTML = '<option value="">请选择节奏</option>';
      $("featured-outline-summary").textContent = "";
      $("featured-outline-repair").classList.add("hidden");
    }

    function renderFeaturedDayOptions() {
      const days = featuredOutline?.days || [];
      $("featured-day").innerHTML = days.map((day, index) =>
        '<option value="' + index + '">' + escapeHtml(day.title || ("第" + (index + 1) + "天")) + '（' + (day.rhythms?.length || 0) + '个节奏）</option>'
      ).join("");
    }

    function renderFeaturedRhythmOptions() {
      const day = getSelectedFeaturedDay();
      const rhythms = day?.rhythms || [];
      $("featured-rhythm").innerHTML = rhythms.length
        ? rhythms.map((rhythm, index) => '<option value="' + index + '">' + escapeHtml(rhythm.title || ("节奏" + (index + 1))) + '</option>').join("")
        : '<option value="">这一天没有识别到节奏</option>';
    }

    function renderFeaturedOutlineSummary() {
      const days = featuredOutline?.days || [];
      $("featured-outline-summary").innerHTML = days.map((day) =>
        '<div><strong>' + escapeHtml(day.title) + '</strong>：' + escapeHtml((day.rhythms || []).map((rhythm) => rhythm.title).join(" / ") || "未识别到节奏") + '</div>'
      ).join("");
    }

    function applyFeaturedSelectionToRange() {
      const day = getSelectedFeaturedDay();
      const rhythm = getSelectedFeaturedRhythm();
      if (!day || !rhythm) return;
      const flat = flattenFeaturedRhythms();
      const currentIndex = flat.findIndex((item) => item.dayIndex === Number($("featured-day").value) && item.rhythmIndex === Number($("featured-rhythm").value));
      const next = flat[currentIndex + 1] || null;
      setRadio("readRangeMode", "range");
      $("range-start").value = buildFeaturedRangeKeyword(day.title, rhythm.title);
      $("range-end").value = next ? buildFeaturedRangeKeyword(next.dayTitle, next.title) : "";
      $("range-start").dataset.autoRange = "featured";
      $("range-end").dataset.endExclusive = "true";
      $("range-end").dataset.endAtDocumentEnd = next ? "false" : "true";
      $("featured-outline-status").textContent = next
        ? "已设置读取范围：" + day.title + " / " + rhythm.title + "，到下一个节奏前结束。"
        : "已设置读取范围：" + day.title + " / " + rhythm.title + "，会读到文档末尾。";
      refreshVisibility();
    }

    function getSelectedFeaturedDay() {
      const index = Number($("featured-day").value);
      return Number.isInteger(index) ? featuredOutline?.days?.[index] : null;
    }

    function getSelectedFeaturedRhythm() {
      const day = getSelectedFeaturedDay();
      const index = Number($("featured-rhythm").value);
      return Number.isInteger(index) ? day?.rhythms?.[index] : null;
    }

    function flattenFeaturedRhythms() {
      const flat = [];
      (featuredOutline?.days || []).forEach((day, dayIndex) => {
        (day.rhythms || []).forEach((rhythm, rhythmIndex) => {
          flat.push({ ...rhythm, dayTitle: day.title, dayIndex, rhythmIndex });
        });
      });
      return flat;
    }

    function buildFeaturedRangeKeyword(dayTitle, rhythmTitle) {
      if (dayTitle && dayTitle !== "全部节奏") return dayTitle + "+" + rhythmTitle;
      const title = featuredOutline?.title || "";
      return title ? title + "｜" + rhythmTitle : rhythmTitle;
    }

    function outlineProjectLabel() {
      return "文档";
    }

    function clearFeaturedAutoRange() {
      $("range-start").dataset.autoRange = "";
      $("range-end").dataset.endExclusive = "";
      $("range-end").dataset.endAtDocumentEnd = "";
    }

    function escapeHtml(value) {
      return String(value || "").replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[char]));
    }

    function normalizeUrlClient(value) {
      const raw = String(value || "").trim();
      const match = raw.match(/https?:\\/\\/[^\\s"'<>]+/);
      return match ? match[0] : raw;
    }
  </script>
</body>
</html>`;
}

function normalizeUrl(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  const match = raw.match(/https?:\/\/[^\s"'<>]+/);
  return match ? match[0] : raw;
}

function isFeishuUrl(value) {
  return /^https?:\/\//.test(value || "") && String(value || "").includes("feishu.cn/");
}

async function readFeishuTitleFromUrl(context, feishuUrl) {
  if (!context?.newPage) return "";
  let page = null;
  try {
    page = await context.newPage();
    await page.goto(feishuUrl, { waitUntil: "domcontentloaded", timeout: 25000 });
    await page.waitForTimeout(1800).catch(() => {});
    return await readFeishuDocumentTitle(page);
  } catch {
    return "";
  } finally {
    if (page && !page.isClosed()) await page.close().catch(() => {});
  }
}

async function readFeaturedOutlineFromUrl(context, feishuUrl, options = {}) {
  const empty = { title: "", days: [] };
  if (!context?.newPage) return empty;
  let page = null;
  try {
    page = await context.newPage();
    await page.goto(feishuUrl, { waitUntil: "domcontentloaded", timeout: 25000 });
    await page.waitForTimeout(Number(options.titleOnlyWaitMs || 0) || (options.deepScan ? 6200 : 5200)).catch(() => {});
    const title = await readFeishuDocumentTitle(page);
    const result = await readFeaturedOutlineFromPage(page, options);
    const days = Array.isArray(result) ? result : (result.days || []);
    return { title, days, diagnostics: result.diagnostics || {} };
  } catch {
    return empty;
  } finally {
    if (page && !page.isClosed()) await page.close().catch(() => {});
  }
}

function featuredOutlineStats(outline = {}) {
  const days = Array.isArray(outline.days) ? outline.days : [];
  return {
    days: days.length,
    rhythms: days.reduce((sum, day) => sum + (Array.isArray(day.rhythms) ? day.rhythms.length : 0), 0)
  };
}

function isFeaturedOutlineTrusted(outline = {}) {
  const days = Array.isArray(outline.days) ? outline.days : [];
  if (days.length < 2) return false;
  if (days.some((day) => day.title === "全部节奏")) return false;
  if (featuredOutlineWarnings(outline).length) return false;
  const numbers = days.map((day) => featuredDayNumber(day.title));
  if (numbers.some((number) => !Number.isFinite(number))) return false;
  for (let index = 1; index < numbers.length; index += 1) {
    if (numbers[index] !== numbers[index - 1] + 1) return false;
  }
  return days.every((day) => {
    const count = Array.isArray(day.rhythms) ? day.rhythms.length : 0;
    return count >= 1 && count <= 6;
  });
}

function featuredOutlineWarnings(outline = {}) {
  const days = Array.isArray(outline.days) ? outline.days : [];
  const warnings = [];
  const bases = ["早上晒图", "上午晒图", "中午晒图", "下午晒图", "晚上晒图"];
  for (const day of days) {
    const rhythms = (Array.isArray(day.rhythms) ? day.rhythms : []).map((rhythm) => rhythm.title);
    if (rhythms.length > 6) warnings.push(day.title + "节奏数量偏多");
    for (const base of bases) {
      if (rhythms.includes(base) && rhythms.includes(base + "互动")) {
        warnings.push(day.title + "疑似混入其他节奏");
        break;
      }
    }
  }
  return warnings;
}

function featuredDayNumber(title) {
  const dateMatch = String(title || "").trim().match(/^(\d{1,2})\/(\d{1,2})/);
  if (dateMatch) return Number(dateMatch[1]) * 100 + Number(dateMatch[2]);
  const match = String(title || "").match(/^第(\d+|[一二两三四五六七八九十]+)天/);
  if (!match) return NaN;
  const raw = match[1];
  if (/^\d+$/.test(raw)) return Number(raw);
  const cnMap = { 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 };
  if (raw === "十") return 10;
  if (raw.startsWith("十")) return 10 + (cnMap[raw.slice(1)] || 0);
  if (raw.endsWith("十")) return (cnMap[raw[0]] || 1) * 10;
  if (raw.includes("十")) {
    const [left, right] = raw.split("十");
    return (cnMap[left] || 1) * 10 + (cnMap[right] || 0);
  }
  return cnMap[raw] || NaN;
}

async function readFeaturedOutlineFromPage(page, options = {}) {
  return page.evaluate(async ({ deepScan, projectType }) => {
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const clean = (value) => String(value || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    const dayRe = /^第(?:\d+|[一二两三四五六七八九十]+)天(?:节奏|节奏表|安排)?$/;
    const dateDayRe = /^\d{1,2}\/\d{1,2}(?:[\u4e00-\u9fa5]{0,8})?$/;
    const isDayTitle = (text) => {
      const compact = clean(text).replace(/\s+/g, "");
      return dayRe.test(compact) || dateDayRe.test(compact);
    };
    const normalizeRhythmText = (text) => clean(text).replace(/\s+/g, "").replace(/^[▲△▶▷●○•·\-－—]+/, "");
    const isOperationReminder = (text) => {
      const raw = clean(text).replace(/\s+/g, "");
      const compact = normalizeRhythmText(raw);
      if (!compact || compact.length > 24) return false;
      const hasReminderPrefix = /^[▲△▶▷●○•·]/.test(raw);
      const hasOperationWord = /(?:群发|朋友圈|发圈|同步发朋友圈)/.test(compact);
      const hasTimingWord = /(?:\d{1,2}(?:点|[:：]\d{1,2})?|早上|上午|中午|下午|晚上|晚间|明早|明晚)/.test(compact);
      return hasOperationWord && (hasReminderPrefix || hasTimingWord || compact === "同步发朋友圈");
    };
    const rhythmRe = /^(?:(?:早上|上午|中午|下午|晚上|晚间|早间|午间|凌晨)?(?:\d{1,2}(?:点|[:：]\d{1,2})?)?(?:日常|小)?(?:晒图|预热|预告|反馈|返场|开团|开抢|催单|福利|科普|早餐|晚安|早安|互动|开始正文|上链接|发链接|开链接)(?:互动|预告|提醒|定时)?|预告|秒杀|开秒|开售|正式秒杀|正式开抢)$/;
    const collectionRhythmRe = /^(?:(?:早上|上午|中午|下午|傍晚|晚上|晚间|早间|午间|凌晨)?(?:\d{1,2}(?:点|[:：]\d{1,2})?)?(?:之后|以后|前|左右)?(?:日常|小)?(?:晒图|预热|预告|定时|反馈|返场|开团|开抢|催单|福利单|福利|科普|早餐|晚安|早安|互动|收割|养群|穿插养群|开始正文|正文|上链接|发链接|开链接)(?:互动|预告|提醒|定时|之后)?|(?:八点|九点|十点|\d{1,2}点)(?:之后|以后|前|左右)?|(?:早上|上午|中午|下午|傍晚|晚上|晚间|早间|午间|凌晨))$/;
    const normalizeCollectionRhythmText = (text) => normalizeRhythmText(text)
      .replace(/^第(?:\d+|[一二两三四五六七八九十]+)天/, "")
      .replace(/[（(].*?[）)]/g, "");
    const isRhythmTitle = (text) => {
      if (isOperationReminder(text)) return false;
      const compact = normalizeRhythmText(text);
      if (projectType === "collection" && collectionRhythmRe.test(normalizeCollectionRhythmText(compact))) return true;
      return rhythmRe.test(compact);
    };
    const cnMap = { 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 };
    const dayNo = (text) => {
      const dateMatch = String(text || "").trim().match(/^(\d{1,2})\/(\d{1,2})/);
      if (dateMatch) return Number(dateMatch[1]) * 100 + Number(dateMatch[2]);
      const match = String(text || "").match(/^第(\d+|[一二两三四五六七八九十]+)天/);
      if (!match) return 9999;
      const raw = match[1];
      if (/^\d+$/.test(raw)) return Number(raw);
      if (raw === "十") return 10;
      if (raw.startsWith("十")) return 10 + (cnMap[raw.slice(1)] || 0);
      if (raw.endsWith("十")) return (cnMap[raw[0]] || 1) * 10;
      if (raw.includes("十")) {
        const [left, right] = raw.split("十");
        return (cnMap[left] || 1) * 10 + (cnMap[right] || 0);
      }
      return cnMap[raw] || 9999;
    };
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
    };
    const bad = /展开显示|收起|目录|评论|分享|复制|更多|最近修改|权限|搜索|查找|http/i;
    const sidebarRightLimit = Math.min(430, Math.max(260, window.innerWidth * 0.34));
    const documentLeftLimit = Math.max(sidebarRightLimit + 40, window.innerWidth * 0.32);
    const leftLimit = sidebarRightLimit;
    const likelyContainers = () => Array.from(document.querySelectorAll([
      "[class*='catalog']",
      "[class*='outline']",
      "[class*='sidebar']",
      "[class*='side-bar']",
      "[class*='toc']",
      "[role='navigation']",
      "nav",
      "aside"
    ].join(",")))
      .filter(visible)
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.left > sidebarRightLimit || rect.right > sidebarRightLimit + 120 || rect.width > 460) return false;
        const text = clean(el.innerText || el.textContent || "");
        return isDayTitle(text) || /第(?:\d+|[一二两三四五六七八九十]+)天/.test(text) || /\d{1,2}\/\d{1,2}/.test(text) || /晒图|预热|秒杀|互动/.test(text);
      })
      .sort((a, b) => {
        const aText = clean(a.innerText || a.textContent || "");
        const bText = clean(b.innerText || b.textContent || "");
        const aDayCount = (aText.match(/第(?:\d+|[一二两三四五六七八九十]+)天/g) || []).length + (aText.match(/\d{1,2}\/\d{1,2}/g) || []).length;
        const bDayCount = (bText.match(/第(?:\d+|[一二两三四五六七八九十]+)天/g) || []).length + (bText.match(/\d{1,2}\/\d{1,2}/g) || []).length;
        const aScore = (a.scrollHeight > a.clientHeight + 10 ? 50 : 0) + aDayCount * 8 + aText.length / 1000;
        const bScore = (b.scrollHeight > b.clientHeight + 10 ? 50 : 0) + bDayCount * 8 + bText.length / 1000;
        return bScore - aScore;
      })
      .slice(0, 4);
    const looksLikeDocumentHeading = (parent, text, kind) => {
      if (kind === "day") return true;
      const element = parent?.nodeType === Node.ELEMENT_NODE ? parent : parent?.parentElement;
      if (!element) return false;
      const style = getComputedStyle(element);
      const fontSize = Number.parseFloat(style.fontSize) || 0;
      const fontWeight = Number.parseInt(style.fontWeight, 10) || 400;
      const tag = element.tagName || "";
      if (/^H[1-6]$/.test(tag)) return true;
      if (fontSize >= 18 || fontWeight >= 600) return true;
      if (element.closest?.("[class*='heading'],[class*='title'],[class*='Header']")) return true;
      return String(text || "").length <= 12 && fontSize >= 16 && fontWeight >= 500;
    };
    const readTextNodes = (roots, options = {}) => {
      const nodes = [];
      const source = options.source || "document";
      const requireLeft = options.requireLeft === true;
      const requireRight = options.requireRight === true;
      let order = 0;
      for (const root of roots) {
        const isPageScroller = root === document.body || root === document.documentElement || root === document.scrollingElement;
        const rootScrollOffset = isPageScroller
          ? (window.scrollY || document.documentElement.scrollTop || 0)
          : ((window.scrollY || document.documentElement.scrollTop || 0) + (root.scrollTop || 0));
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        while (walker.nextNode()) {
          const node = walker.currentNode;
          const text = clean(node.nodeValue || "");
          if (!text || text.length > 48 || bad.test(text)) continue;
          if (!isDayTitle(text) && !isRhythmTitle(text)) continue;
          const kind = isDayTitle(text) ? "day" : "rhythm";
          const parent = node.parentElement;
          if (!parent || !visible(parent)) continue;
          const range = document.createRange();
          range.selectNodeContents(node);
          const rect = range.getBoundingClientRect();
          range.detach();
          if (rect.width <= 0 || rect.height <= 0) continue;
          if (requireLeft && (rect.left > sidebarRightLimit || rect.right > sidebarRightLimit + 140)) continue;
          if (requireRight && rect.left < documentLeftLimit) continue;
          if (source === "document" && !looksLikeDocumentHeading(parent, text, kind)) continue;
          nodes.push({
            text,
            kind,
            source,
            order: order++,
            x: rect.left,
            y: rect.top + rootScrollOffset,
            weight: Number.parseInt(getComputedStyle(parent).fontWeight, 10) || 400
          });
        }
      }
      return nodes;
    };
    const splitSidebarLines = (text) => String(text || "")
      .split(/\r?\n/)
      .map(clean)
      .filter((line) => line && line.length <= 48 && !bad.test(line))
      .filter((line) => isDayTitle(line) || isRhythmTitle(line));
    const readSidebarOrderedItems = (roots, options = {}) => {
      const items = [];
      let order = 0;
      if (options.requireLeft !== true) {
        for (const root of roots) {
          const lines = splitSidebarLines(root.innerText || root.textContent || "");
          for (const text of lines) {
            items.push({
              text,
              kind: isDayTitle(text) ? "day" : "rhythm",
              source: "sidebar",
              order: order++
            });
          }
        }
      }
      if (items.length) return items;
      return readTextNodes(roots, { source: "sidebar", requireLeft: options.requireLeft === true })
        .sort((a, b) => a.order - b.order);
    };
    const finalizeDays = (days) => {
      const merged = [];
      for (const day of days.filter((item) => item.rhythms.length)) {
        let target = merged.find((item) => item.title === day.title);
        if (!target) {
          target = { title: day.title, rhythms: [] };
          merged.push(target);
        }
        for (const rhythm of day.rhythms) {
          if (!target.rhythms.some((item) => item.title === rhythm.title)) {
            target.rhythms.push(rhythm);
          }
        }
      }
      return merged
        .filter((day) => day.title !== "全部节奏" || !merged.some((item) => item.title !== "全部节奏"))
        .sort((a, b) => dayNo(a.title) - dayNo(b.title))
        .map(({ title, rhythms }) => ({ title, rhythms }));
    };
    const buildDaysInOrder = (items, allowFallbackAll = true) => {
      const hasDay = items.some((item) => item.kind === "day" || isDayTitle(item.text));
      const days = [];
      let current = null;
      for (const item of items) {
        if (item.kind === "day" || isDayTitle(item.text)) {
          current = { title: item.text, dayNo: dayNo(item.text), rhythms: [] };
          days.push(current);
          continue;
        }
        if (!current && !hasDay && allowFallbackAll && isRhythmTitle(item.text)) {
          current = { title: "全部节奏", dayNo: 9999, rhythms: [] };
          days.push(current);
        }
        if (!current || !isRhythmTitle(item.text)) continue;
        if (!current.rhythms.some((rhythm) => rhythm.title === item.text)) {
          current.rhythms.push({ title: item.text });
        }
      }
      return finalizeDays(days);
    };
    const outlineWarnings = (days) => {
      const warnings = [];
      const bases = ["早上晒图", "上午晒图", "中午晒图", "下午晒图", "晚上晒图"];
      for (const day of days) {
        const rhythms = (Array.isArray(day.rhythms) ? day.rhythms : []).map((rhythm) => rhythm.title);
        if (rhythms.length > 6) warnings.push(day.title + "节奏数量偏多");
        for (const base of bases) {
          if (rhythms.includes(base) && rhythms.includes(base + "互动")) {
            warnings.push(day.title + "疑似混入其他节奏");
            break;
          }
        }
      }
      return warnings;
    };
    const mergeDayLists = (lists) => {
      const merged = [];
      for (const days of lists) {
        for (const day of days) {
          let target = merged.find((item) => item.title === day.title);
          if (!target) {
            target = { title: day.title, rhythms: [] };
            merged.push(target);
          }
          for (const rhythm of day.rhythms || []) {
            if (!target.rhythms.some((item) => item.title === rhythm.title)) {
              target.rhythms.push({ title: rhythm.title });
            }
          }
        }
      }
      return merged.sort((a, b) => dayNo(a.title) - dayNo(b.title));
    };
    const keyForNode = (node) => node.text + "|" + Math.round(node.x / 8) + "|" + Math.round(node.y / 8);
    const rememberInto = (target, nodes) => {
      for (const node of nodes) {
        const key = keyForNode(node);
        if (!target.has(key)) target.set(key, node);
      }
    };

    const collectSidebarDaysOnce = async () => {
      const snapshots = [];
      let containers = likelyContainers();
      if (!containers.length) {
        return buildDaysInOrder(readSidebarOrderedItems([document.body], { requireLeft: true }), false);
      }
      containers = containers.slice(0, 1);
      for (const el of containers) el.scrollTop = 0;
      await sleep(260);
      let stale = 0;
      let previousSig = "";
      for (let step = 0; step < 50; step += 1) {
        containers = likelyContainers();
        containers = containers.slice(0, 1);
        const snapshotDays = buildDaysInOrder(readSidebarOrderedItems(containers), false);
        snapshots.push(snapshotDays);
        const currentSig = signature(snapshotDays);
        const moved = containers.some((el) => {
          const before = el.scrollTop;
          el.scrollTop = Math.min(el.scrollHeight, el.scrollTop + Math.max(160, Math.floor(el.clientHeight * 0.72)));
          return el.scrollTop !== before;
        });
        stale = currentSig && currentSig === previousSig ? stale + 1 : 0;
        previousSig = currentSig;
        if (!moved && stale >= 2) break;
        await sleep(220);
      }
      for (const el of containers) el.scrollTop = 0;
      snapshots.push(buildDaysInOrder(readSidebarOrderedItems([document.body], { requireLeft: true }), false));
      return mergeDayLists(snapshots);
    };

    const signature = (days) => days
      .map((day) => day.title + ":" + day.rhythms.map((rhythm) => rhythm.title).join(","))
      .join("|");

    const collectStableSidebar = async () => {
      const snapshots = [];
      let last = "";
      let stable = 0;
      for (let round = 0; round < 3; round += 1) {
        const days = await collectSidebarDaysOnce();
        snapshots.push(days);
        const sig = signature(days);
        if (sig && sig === last) stable += 1;
        else stable = 0;
        last = sig;
        if (round < 2) await sleep(stable >= 1 ? 450 : 850);
      }
      return mergeDayLists(snapshots);
    };

    const getPageScrollers = () => {
      const seen = new Set();
      const candidates = [document.scrollingElement, document.documentElement, document.body, ...Array.from(document.querySelectorAll("*"))]
        .filter(Boolean)
        .filter((el) => {
          if (seen.has(el)) return false;
          seen.add(el);
          if (el.scrollHeight <= el.clientHeight + 120) return false;
          const rect = el === document.body || el === document.documentElement ? { left: 0, width: window.innerWidth } : el.getBoundingClientRect();
          if (rect.width < 320) return false;
          if (rect.left <= leftLimit && rect.width < Math.max(520, window.innerWidth * 0.5)) return false;
          return true;
        })
        .sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight));
      const hasRealScroller = candidates.some((el) => el !== document.body && el !== document.documentElement && el !== document.scrollingElement);
      return candidates
        .filter((el) => {
          if (!hasRealScroller) return true;
          if (el === document.body || el === document.documentElement || el === document.scrollingElement) return false;
          return !candidates.some((other) => other !== el && other.contains?.(el) && other !== document.body && other !== document.documentElement && other !== document.scrollingElement);
        })
        .slice(0, 6);
    };
    const collectDocument = async () => {
      const deepAll = new Map();
      let scrollers = getPageScrollers();
      if (!scrollers.length) scrollers = [document.scrollingElement || document.documentElement || document.body].filter(Boolean);
      for (const el of scrollers) el.scrollTop = 0;
      window.scrollTo(0, 0);
      await sleep(700);
      let stale = 0;
      let previousSize = -1;
      for (let step = 0; step < 80; step += 1) {
        scrollers = getPageScrollers();
        if (!scrollers.length) scrollers = [document.scrollingElement || document.documentElement || document.body].filter(Boolean);
        rememberInto(deepAll, readTextNodes(scrollers, { source: "document", requireRight: true }));
        const moved = scrollers.some((el) => {
          const before = el.scrollTop;
          el.scrollTop = Math.min(el.scrollHeight, el.scrollTop + Math.max(520, Math.floor(el.clientHeight * 0.85)));
          return el.scrollTop !== before;
        });
        window.scrollBy(0, 520);
        stale = deepAll.size === previousSize ? stale + 1 : 0;
        previousSize = deepAll.size;
        if (!moved && stale >= 5) break;
        await sleep(650);
      }
      window.scrollTo(0, 0);
      for (const el of scrollers) el.scrollTop = 0;
      return Array.from(deepAll.values());
    };

    const buildDays = (nodes, allowFallbackAll = true) => {
      nodes.sort((a, b) => a.y - b.y || a.x - b.x);
      const deduped = [];
      for (const item of nodes) {
        const previous = deduped[deduped.length - 1];
        if (previous && previous.text === item.text && Math.abs(previous.y - item.y) < 8) continue;
        deduped.push(item);
      }
      return buildDaysInOrder(deduped, allowFallbackAll);
    };

    const sidebarDays = await collectStableSidebar();
    if (!deepScan) {
      return {
        days: sidebarDays,
        diagnostics: {
          source: "sidebar",
          sidebarDays: sidebarDays.length,
          sidebarRhythms: sidebarDays.reduce((sum, day) => sum + day.rhythms.length, 0),
          warnings: outlineWarnings(sidebarDays)
        }
      };
    }

    const documentNodes = await collectDocument();
    const documentDays = buildDays(documentNodes, false);
    const sidebarByTitle = new Map(sidebarDays.map((day) => [day.title, day]));
    const mergedDays = [
      ...sidebarDays,
      ...documentDays.filter((day) => !sidebarByTitle.has(day.title))
    ].sort((a, b) => dayNo(a.title) - dayNo(b.title));

    const fastDays = sidebarDays;
    const deepDays = mergedDays.length ? mergedDays : documentDays;
    const fastRhythmCount = fastDays.reduce((sum, day) => sum + day.rhythms.length, 0);
    const deepRhythmCount = deepDays.reduce((sum, day) => sum + day.rhythms.length, 0);
    const finalDays = deepDays.length > fastDays.length || deepRhythmCount > fastRhythmCount ? deepDays : fastDays;
    return {
      days: finalDays,
      diagnostics: {
        source: finalDays === sidebarDays ? "sidebar" : "document",
        sidebarDays: sidebarDays.length,
        sidebarRhythms: fastRhythmCount,
        documentDays: documentDays.length,
        documentRhythms: documentDays.reduce((sum, day) => sum + day.rhythms.length, 0),
        warnings: outlineWarnings(finalDays)
      }
    };
  }, { deepScan: options.deepScan === true }).catch(() => []);
}

async function readFeishuDocumentTitle(page) {
  return page.evaluate(() => {
    const clean = (value) => String(value || "")
      .replace(/\s*-\s*飞书云文档\s*$/i, "")
      .replace(/\s*-\s*飞书文档\s*$/i, "")
      .replace(/\s+/g, " ")
      .trim();

    const badTitleText = /最近修改|分享|编辑|云盘|外部|添加快捷方式|权限|链接|https?:\/\//;
    const isGoodTitle = (value) => {
      const text = clean(value);
      if (!text) return false;
      if (/^飞书/.test(text)) return false;
      if (badTitleText.test(text)) return false;
      if (/[>＞]/.test(text)) return false;
      if (text.length > 60) return false;
      return true;
    };

    const visible = (el) => {
      if (!el) return false;
      const style = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
    };

    const scored = Array.from(document.querySelectorAll("h1,h2,[class*='title'],[data-testid*='title']"))
      .filter(visible)
      .map((el) => {
        const text = clean(el.innerText || el.textContent || "");
        const style = window.getComputedStyle(el);
        const rect = el.getBoundingClientRect();
        const fontSize = Number.parseFloat(style.fontSize) || 0;
        const bold = Number.parseInt(style.fontWeight, 10) >= 600 ? 10 : 0;
        const centerBonus = rect.top > 80 && rect.top < window.innerHeight * 0.7 ? 8 : 0;
        const h1Bonus = el.tagName === "H1" ? 20 : el.tagName === "H2" ? 8 : 0;
        return { text, score: fontSize + bold + centerBonus + h1Bonus };
      })
      .filter((item) => isGoodTitle(item.text))
      .sort((a, b) => b.score - a.score);

    if (scored[0]?.text) return scored[0].text;

    const tabTitle = clean(document.title);
    if (isGoodTitle(tabTitle)) return tabTitle;

    const breadcrumb = Array.from(document.querySelectorAll("a,span,div"))
      .map((el) => clean(el.innerText || el.textContent || ""))
      .filter(isGoodTitle)
      .sort((a, b) => a.length - b.length);
    return breadcrumb[0] || "";
  }).catch(() => "");
}

async function loadLocalSettings() {
  try {
    const settingsPath = path.resolve(process.cwd(), "last-settings.json");
    return JSON.parse(await fs.readFile(settingsPath, "utf8"));
  } catch {
    return {};
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.setEncoding("utf8");
    req.on("data", (chunk) => {
      body += chunk;
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

function sendHtml(res, html) {
  res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  res.end(html);
}

function sendJson(res, data) {
  res.writeHead(200, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function listen(server) {
  return new Promise((resolve, reject) => {
    server.on("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
}

function closeServer(server) {
  return new Promise((resolve) => {
    server.close(() => resolve());
  });
}

function escapeScriptJson(value) {
  return String(value)
    .replace(/</g, "\\u003c")
    .replace(/>/g, "\\u003e")
    .replace(/&/g, "\\u0026")
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");
}

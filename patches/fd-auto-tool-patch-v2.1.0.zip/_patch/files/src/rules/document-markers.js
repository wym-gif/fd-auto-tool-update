export const CONTINUE_SPEAKER_REMARKS = [
  "下面还说话"
];

export function normalizeMarkerLine(text) {
  return String(text || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .trim();
}

export function compactMarkerLine(text) {
  return normalizeMarkerLine(text).replace(/\s+/g, "");
}

export function normalizeHeaderRemark(text) {
  const line = String(text || "").trim();
  const compactLine = line.replace(/\s+/g, "");
  return compactLine.replace(/^[(（【\[]/, "").replace(/[)）】\]]$/, "");
}

export function hasContinueSpeakerHint(text) {
  const compact = compactMarkerLine(text);
  return CONTINUE_SPEAKER_REMARKS.some((word) => compact.includes(word));
}

export function isHeaderRemark(text) {
  const unwrapped = normalizeHeaderRemark(text);
  return [
    ...CONTINUE_SPEAKER_REMARKS,
    "不用发",
    "不发",
    "不定时",
    "备注",
    "标注"
  ].some((word) => unwrapped.includes(word));
}

export function stripInlineHeaderRemark(text) {
  let result = String(text || "");
  for (const word of CONTINUE_SPEAKER_REMARKS) {
    const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    result = result.replace(new RegExp(`[（(【\\[][^）)】\\]]*${escaped}[^）)】\\]]*[）)】\\]]`, "g"), "");
  }
  return result.trim();
}

export function isStableDoumaMarker(text) {
  const compact = compactMarkerLine(text);
  return /^[-－—]?豆妈[:：]?$/.test(compact);
}

export function parseStableTuoMarker(text, options = {}) {
  const line = normalizeMarkerLine(text);
  const compact = compactMarkerLine(text);
  if (!compact || compact.length > 36) return null;
  if (options.headerRe?.test?.(line)) return null;
  if (/^https?:\/\//i.test(line)) return null;
  if (/\d{1,2}[：:]\d{1,2}/.test(compact)) return null;

  const match = compact.match(/^(?:T|托)(\d+)?(?::?(.*))?$/i);
  if (!match) return null;
  const hint = match[2] || "";
  if (hint && !hasContinueSpeakerHint(hint)) return null;
  const number = match[1] ? Number(match[1]) : null;

  return {
    number: Number.isFinite(number) && number > 0 ? number : null,
    hint,
    continueSpeaker: hasContinueSpeakerHint(compact),
    interactiveTuo: Boolean(hint && hasContinueSpeakerHint(hint))
  };
}

export function isMarkerOnlyWithSpeakerOrTime(text, options = {}) {
  const line = normalizeMarkerLine(text);
  const compact = compactMarkerLine(line);
  if (!compact) return false;
  if (isStableDoumaMarker(line) || parseStableTuoMarker(line, options)) return true;
  if (options.headerRe?.test?.(line)) return true;
  if (!hasContinueSpeakerHint(line) && !isHeaderRemark(line)) return false;
  return Boolean(options.headerRe?.test?.(line) || /(?:^|[-－—\s])(?:T|托)\d*/i.test(line) || /豆妈/.test(line));
}

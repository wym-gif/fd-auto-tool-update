import fs from "node:fs/promises";

export function normalizeFeishuUrl(value) {
  const text = String(value || "")
    .replace(/[<>]/g, " ")
    .replace(/[“”]/g, "\"")
    .replace(/[‘’]/g, "'")
    .trim();
  if (!text) return "";
  const markdown = text.match(/\((https?:\/\/[^)]+)\)/);
  const source = markdown?.[1] || text;
  const compactSource = source.replace(/\s+/g, "");
  const match = compactSource.match(/https:\/\/\S*feishu\.cn\/(?:docx|docs|wiki|sheets)\/\S+/i);
  const url = (match?.[0] || "").replace(/[)\]};,，。；]+$/g, "");
  if (!/^https:\/\/[^/]*feishu\.cn\/(?:docx|docs|wiki|sheets)\//i.test(url)) return "";
  return url;
}

export async function loadLocalSettings(settingsPath) {
  try {
    return JSON.parse(await fs.readFile(settingsPath, "utf8"));
  } catch {
    return {};
  }
}

export async function saveLocalSettings(settingsPath, settings) {
  await fs.writeFile(settingsPath, JSON.stringify(settings, null, 2), "utf8");
}

export async function saveLastFeishuUrl(settingsPath, feishuUrl) {
  const nextUrl = normalizeFeishuUrl(feishuUrl);
  if (!nextUrl) return;
  const settings = await loadLocalSettings(settingsPath);
  const previousUrl = normalizeFeishuUrl(settings.feishuUrl);
  if (previousUrl && previousUrl !== nextUrl) {
    delete settings.feishuTitle;
    delete settings.feishuTitleUrl;
  }
  settings.feishuUrl = nextUrl;
  settings.updatedAt = new Date().toISOString();
  await saveLocalSettings(settingsPath, settings);
}

export async function saveFixedRolePrefix(settingsPath, prefix) {
  const value = String(prefix || "").trim();
  if (!value) return;
  const settings = await loadLocalSettings(settingsPath);
  settings.fixedRolePrefix = value;
  settings.updatedAt = new Date().toISOString();
  await saveLocalSettings(settingsPath, settings);
}

export async function saveFixedRoleSheet(settingsPath, sheetUrl, title = "") {
  const nextUrl = normalizeFeishuUrl(sheetUrl);
  if (!nextUrl) return;
  const settings = await loadLocalSettings(settingsPath);
  settings.fixedRoleSheetUrl = nextUrl;
  if (title) settings.fixedRoleSheetTitle = title;
  settings.updatedAt = new Date().toISOString();
  await saveLocalSettings(settingsPath, settings);
}

export async function rememberCurrentFeishuDocument(settingsPath, page, config) {
  const feishuUrl = normalizeFeishuUrl(config.feishuUrl);
  if (!feishuUrl) return;
  const title = await readFeishuDocumentTitle(page);
  const settings = await loadLocalSettings(settingsPath);
  const previousUrl = normalizeFeishuUrl(settings.feishuUrl);
  if (previousUrl && previousUrl !== feishuUrl) {
    delete settings.feishuTitle;
    delete settings.feishuTitleUrl;
  }
  settings.feishuUrl = feishuUrl;
  settings.projectType = config.projectType === "featured" ? "featured" : "collection";
  if (title) {
    settings.feishuTitle = title;
    settings.feishuTitleUrl = feishuUrl;
    config.feishuTitle = title;
    config.feishuTitleUrl = feishuUrl;
  } else if (settings.feishuTitleUrl && normalizeFeishuUrl(settings.feishuTitleUrl) !== feishuUrl) {
    delete settings.feishuTitle;
    delete settings.feishuTitleUrl;
  }
  settings.updatedAt = new Date().toISOString();
  await saveLocalSettings(settingsPath, settings);
}

export async function readFeishuDocumentTitle(page) {
  return page.evaluate(() => {
    const clean = (value) => String(value || "")
      .replace(/\s*-\s*飞书云文档\s*$/i, "")
      .replace(/\s*-\s*飞书文档\s*$/i, "")
      .replace(/\s+/g, " ")
      .trim();
    const directText = (el) => Array.from(el?.childNodes || [])
      .filter((node) => node.nodeType === Node.TEXT_NODE)
      .map((node) => node.textContent || "")
      .join(" ");

    const badTitleText = /最近修改|分享|编辑|云盘|外部|添加快捷方式|权限|链接|问问豆包|https?:\/\//;
    const isGoodTitle = (value) => {
      const text = clean(value);
      if (!text) return false;
      if (/^飞书/.test(text)) return false;
      if (badTitleText.test(text)) return false;
      if (/[>＞]/.test(text)) return false;
      if (text.length > 60) return false;
      return true;
    };

    const visible = (el) => {
      if (!el) return false;
      const style = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
    };

    const scored = Array.from(document.querySelectorAll("h1,h2,[class*='title'],[data-testid*='title']"))
      .filter(visible)
      .flatMap((el) => {
        const texts = [directText(el), el.getAttribute("aria-label"), el.getAttribute("title"), el.innerText || el.textContent || ""]
          .map(clean)
          .filter(isGoodTitle);
        const style = window.getComputedStyle(el);
        const rect = el.getBoundingClientRect();
        const fontSize = Number.parseFloat(style.fontSize) || 0;
        const bold = Number.parseInt(style.fontWeight, 10) >= 600 ? 10 : 0;
        const centerBonus = rect.top > 80 && rect.top < window.innerHeight * 0.7 ? 8 : 0;
        const h1Bonus = el.tagName === "H1" ? 120 : el.tagName === "H2" ? 80 : 0;
        return texts.map((text) => ({ text, score: fontSize + bold + centerBonus + h1Bonus + (text.length <= 30 ? 5 : 0) }));
      })
      .sort((a, b) => b.score - a.score);

    if (scored[0]?.text) return scored[0].text;

    const tabTitle = clean(document.title);
    if (isGoodTitle(tabTitle)) return tabTitle;

    const breadcrumb = Array.from(document.querySelectorAll("a,span,div"))
      .map((el) => clean(el.innerText || el.textContent || ""))
      .filter(isGoodTitle)
      .sort((a, b) => a.length - b.length);
    return breadcrumb[0] || "";
  }).catch(() => "");
}

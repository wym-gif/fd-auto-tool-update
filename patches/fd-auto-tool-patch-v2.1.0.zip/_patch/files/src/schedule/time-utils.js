import { parseTime } from "../utils.js";

export function timeToSeconds(time) {
  const [h, m, s] = String(time || "").split(":").map(Number);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return null;
  return h * 3600 + m * 60 + (Number.isFinite(s) ? s : 0);
}

export function secondsToClock(totalSeconds) {
  const sec = ((Math.round(Number(totalSeconds) || 0) % 86400) + 86400) % 86400;
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(Math.floor(sec / 3600))}:${pad(Math.floor((sec % 3600) / 60))}:${pad(sec % 60)}`;
}

export function parseClockToAbsoluteSeconds(value, afterAbs = null) {
  const time = parseTime(value);
  if (!time) return null;
  let abs = timeToSeconds(time);
  if (abs === null) return null;
  if (afterAbs !== null && abs <= afterAbs) abs += 86400;
  return abs;
}

export function formatDurationZh(totalSeconds) {
  const seconds = Math.max(0, Math.round(Number(totalSeconds) || 0));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const rest = seconds % 60;
  const parts = [];
  if (hours) parts.push(`${hours}小时`);
  if (minutes) parts.push(`${minutes}分钟`);
  if (rest || !parts.length) parts.push(`${rest}秒`);
  return parts.join("");
}

import {
  parseClockToAbsoluteSeconds as parseClockToAbsoluteSecondsShared,
  secondsToClock as secondsToTimeShared,
  timeToSeconds as timeToSecondsShared
} from "./time-utils.js";

export function customIntervalsEnabled(config = {}) {
  const mode = config.scheduleMode || "doc";
  return mode === "realtime" || mode === "catchup";
}

export function intervalNumberOrNull(value) {
  if (value === "" || value === undefined || value === null) return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

export function customIntervalSeconds(config = {}, key, minimum = 0) {
  if (!customIntervalsEnabled(config)) return null;
  const item = config.customIntervals?.[key];
  if (!item || typeof item !== "object") return null;
  let min = intervalNumberOrNull(item.min);
  let max = intervalNumberOrNull(item.max);
  if (min === null && max === null) return null;
  if (min === null) min = max;
  if (max === null) max = min;
  min = Math.max(minimum, Math.max(0, Math.round(min)));
  max = Math.max(minimum, Math.max(0, Math.round(max)));
  if (max < min) [min, max] = [max, min];
  return Math.round((min + max) / 2);
}

export function roleSwitchGapSeconds(config = {}) {
  const configured = Number(config.realtimeRoleSwitchGapSeconds ?? 120);
  const base = Math.max(120, Number.isFinite(configured) ? configured : 120);
  return customIntervalSeconds(config, "roleSwitch", 120) ?? base;
}

export function gapKeyBetweenTasks(prev, next) {
  if (!prev || !next) return "";
  if (prev.role !== next.role) return "roleSwitch";
  if (prev.role === "douma" && next.role === "douma") return "doumaSame";
  if (prev.role === "tuo" && next.role === "tuo") {
    return prev.speaker === next.speaker ? "sameTuo" : "differentTuo";
  }
  return prev.speaker === next.speaker ? "sameTuo" : "differentTuo";
}

export function withCustomGap(defaultGap, prev, next, config = {}) {
  const key = gapKeyBetweenTasks(prev, next);
  if (!key) return defaultGap;
  const custom = customIntervalSeconds(config, key, key === "roleSwitch" ? 120 : 0);
  return custom === null ? defaultGap : custom;
}

export function customGapRange(defaultRange, prev, next, config = {}) {
  const custom = withCustomGap(null, prev, next, config);
  if (custom === null) return defaultRange;
  return {
    min: custom,
    normal: custom,
    max: custom,
    weight: defaultRange.weight ?? 1,
    stretchable: defaultRange.stretchable
  };
}

export function taskDocAbsoluteSeconds(task) {
  return Number(task.scheduleDateOffset || 0) * 86400 + timeToSeconds(task.time);
}

export function orderTasksForTiming(tasks) {
  return tasks
    .map((task, creationIndex) => ({ task, creationIndex }))
    .sort((a, b) => taskDocumentOrder(a.task, a.creationIndex) - taskDocumentOrder(b.task, b.creationIndex));
}

export function taskDocumentOrder(task, fallback) {
  const order = Number(task.order);
  return Number.isFinite(order) ? order : fallback;
}

export function buildInteractionSpanByPosition(orderedItems) {
  const spans = [];
  const covered = new Map();
  for (let index = 0; index < orderedItems.length; index += 1) {
    if (covered.has(index)) continue;
    const task = orderedItems[index].task;
    if (task.role !== "tuo" || !task.continueSpeaker || task.robotGroup === undefined || task.robotGroup === null) continue;

    const startHeader = headerOrder(task);
    let returnIndex = -1;
    for (let nextIndex = index + 1; nextIndex < orderedItems.length; nextIndex += 1) {
      const next = orderedItems[nextIndex].task;
      if (next.role !== "tuo" || next.robotGroup !== task.robotGroup) continue;
      if (headerOrder(next) === startHeader) continue;
      returnIndex = nextIndex;
      break;
    }
    if (returnIndex < 0) continue;

    const returnHeader = headerOrder(orderedItems[returnIndex].task);
    let endIndex = returnIndex;
    for (let nextIndex = returnIndex + 1; nextIndex < orderedItems.length; nextIndex += 1) {
      if (headerOrder(orderedItems[nextIndex].task) !== returnHeader) break;
      endIndex = nextIndex;
    }

    const span = { startIndex: index, endIndex };
    spans.push(span);
    for (let coveredIndex = index; coveredIndex <= endIndex; coveredIndex += 1) {
      covered.set(coveredIndex, span);
    }
  }
  return covered;
}

export function headerOrder(task) {
  const order = Number(task.order);
  return Number.isFinite(order) ? Math.floor(order) : Number.NaN;
}

export function boundaryGapSeconds(prev, next, compressed) {
  if (!prev || !next) return 0;
  return gapBetweenTasks(prev, next, compressed, {});
}

export function boundaryGapSecondsFromItems(prev, next, position, spanByPosition, compressed, config = {}) {
  if (!prev || !next) return 0;
  return gapBetweenOrderedItems(prev, next, position, spanByPosition, compressed, config);
}

export function gapBetweenOrderedItems(prevItem, nextItem, nextPosition, spanByPosition, compressed, config) {
  const span = spanByPosition.get(nextPosition);
  if (span && span.startIndex < nextPosition && shouldKeepDocumentGapInsideInteraction(config)) {
    const docGap = Math.max(0, taskDocAbsoluteSeconds(nextItem.task) - taskDocAbsoluteSeconds(prevItem.task));
    if (prevItem.task.role !== nextItem.task.role) {
      return Math.max(docGap, roleSwitchGapSeconds(config));
    }
    return docGap;
  }
  return gapBetweenTasks(prevItem.task, nextItem.task, compressed, config);
}

export function gapBetweenTasks(prev, next, compressed, config) {
  if (prev.role !== next.role) return roleSwitchGapSeconds(config);
  let gap;
  if (isMediaLikeTask(prev) || isMediaLikeTask(next)) {
    gap = compressed ? 35 : 45;
  } else if (prev.speaker === next.speaker) {
    gap = compressed ? tightSpacingSeconds(next) : spacingSeconds(next);
  } else {
    gap = compressed ? 5 : normalDifferentSpeakerGap(prev, next, config);
  }
  return withCustomGap(gap, prev, next, config);
}

export function shouldKeepDocumentGapInsideInteraction(config = {}) {
  return (config.scheduleMode || "doc") !== "realtime";
}

export function normalDifferentSpeakerGap(prev, next, config = {}) {
  if (isFeaturedProject(config) && prev.role === "tuo" && next.role === "tuo") {
    return 45;
  }
  return Math.max(15, Number(config.minOtherSpeakerGapSeconds ?? 15));
}

export function isFeaturedProject(config = {}) {
  return String(config.projectType || "").trim().toLowerCase() === "featured";
}

export function buildStartSuggestion(tasks, config) {
  const gaps = buildRealtimeGaps(tasks, config);
  const normalDuration = sumGaps(gaps, "normal");
  const minDuration = sumGaps(gaps, "min");
  const roleSwitches = countRoleSwitches(tasks);
  const media = tasks.filter((task) => ["image", "sticker", "video"].includes(task.type)).length;
  const nowAbs = currentAbsoluteSeconds();
  const minLeadSeconds = Number(config.realtimeMinLeadSeconds ?? 60);
  const configuredStart = parseClockToAbsoluteSeconds(config.realtimeStartTime) ?? nowAbs + minLeadSeconds;
  const startAbs = Math.max(configuredStart, nowAbs + minLeadSeconds);
  const endAbs = parseClockToAbsoluteSeconds(config.realtimeEndTime);

  const reasonParts = [];
  if (media) reasonParts.push(`${media} 个素材需要上传和就绪检查`);
  if (roleSwitches) reasonParts.push(`${roleSwitches} 次豆妈/托切换，每次至少 2 分钟`);
  if (tasks.length >= 20) reasonParts.push("任务较多，避免过度压缩");
  if (!reasonParts.length) reasonParts.push("内容较短，按正常间隔即可");

  if (endAbs) {
    return {
      total: tasks.length,
      media,
      roleSwitches,
      normalDuration,
      minDuration,
      endTime: secondsToTime(endAbs),
      recommendedStart: secondsToTime(endAbs - normalDuration),
      latestStart: secondsToTime(endAbs - minDuration),
      reason: reasonParts.join("; ")
    };
  }

  return {
    total: tasks.length,
    media,
    roleSwitches,
    normalDuration,
    minDuration,
    endTime: "",
    recommendedStart: secondsToTime(startAbs),
    recommendedEnd: secondsToTime(startAbs + normalDuration),
      reason: reasonParts.join("; ")
  };
}

export function countRoleSwitches(tasks) {
  let count = 0;
  for (let index = 1; index < tasks.length; index += 1) {
    if (tasks[index - 1].role !== tasks[index].role) count += 1;
  }
  return count;
}

export function formatDuration(seconds) {
  if (seconds < 60) return `${Math.max(0, Math.round(seconds))}s`;
  const minutes = Math.floor(seconds / 60);
  const rest = Math.round(seconds % 60);
  return rest ? `${minutes}m${rest}s` : `${minutes}m`;
}

export function buildRealtimeGaps(tasks, config) {
  return buildRealtimeGapsFromItems(orderTasksForTiming(tasks), config);
}

export function buildRealtimeGapsFromItems(orderedItems, config) {
  const roleSwitchMin = roleSwitchGapSeconds(config);
  const spanByPosition = buildInteractionSpanByPosition(orderedItems);
  const gaps = [];
  for (let index = 1; index < orderedItems.length; index += 1) {
    const span = spanByPosition.get(index);
    if (span && span.startIndex < index && shouldKeepDocumentGapInsideInteraction(config)) {
      const fixedGap = Math.max(
        0,
        taskDocAbsoluteSeconds(orderedItems[index].task) - taskDocAbsoluteSeconds(orderedItems[index - 1].task)
      );
      if (orderedItems[index - 1].task.role !== orderedItems[index].task.role) {
        const switchGap = Math.max(fixedGap, roleSwitchMin);
        gaps.push({ min: switchGap, normal: switchGap, max: Math.max(switchGap, 240), weight: 3, stretchable: true });
        continue;
      }
      gaps.push({ min: fixedGap, normal: fixedGap, max: fixedGap, weight: 0, stretchable: false });
      continue;
    }
    const prev = orderedItems[index - 1].task;
    const next = orderedItems[index].task;
    if (prev.role !== next.role) {
      gaps.push(customGapRange({ min: roleSwitchMin, normal: roleSwitchMin, max: Math.max(roleSwitchMin, 240), weight: 3, stretchable: true }, prev, next, config));
      continue;
    }
    if (isMediaLikeTask(prev) || isMediaLikeTask(next)) {
      const normal = prev.speaker === next.speaker ? 50 : 45;
      gaps.push(customGapRange({
        min: prev.speaker === next.speaker ? 35 : 30,
        normal,
        max: 75,
        weight: 1,
        stretchable: prev.speaker !== next.speaker
      }, prev, next, config));
      continue;
    }
    if (prev.speaker === next.speaker) {
      const normal = next.role === "douma" ? Math.max(45, spacingSeconds(next)) : spacingSeconds(next);
      gaps.push(customGapRange({
        min: tightSpacingSeconds(next),
        normal,
        max: next.role === "douma" ? 60 : Math.max(normal, 50),
        weight: 1,
        stretchable: false
      }, prev, next, config));
      continue;
    }
    gaps.push(customGapRange({
      min: 5,
      normal: next.role === "douma" ? 45 : normalDifferentSpeakerGap(prev, next, config),
      max: 60,
      weight: 1,
      stretchable: true
    }, prev, next, config));
  }
  return gaps;
}

export function planRealtimeGaps(gaps, availableSeconds) {
  if (!gaps.length) return [];
  if (availableSeconds === null) return gaps.map((gap) => gap.normal);

  const normalTotal = sumGaps(gaps, "normal");
  const minTotal = sumGaps(gaps, "min");
  if (availableSeconds <= minTotal) return gaps.map((gap) => gap.min);

  if (availableSeconds < normalTotal) {
    const ratio = (availableSeconds - minTotal) / Math.max(1, normalTotal - minTotal);
    return gaps.map((gap) => Math.round(gap.min + (gap.normal - gap.min) * ratio));
  }

  const planned = gaps.map((gap) => gap.normal);
  let remaining = availableSeconds - normalTotal;
  for (const [index, gap] of gaps.entries()) {
    if (remaining <= 0) break;
    const add = Math.min(remaining, Math.max(0, gap.max - gap.normal));
    planned[index] += add;
    remaining -= add;
  }

  if (remaining > 0) {
    const totalWeight = gaps.reduce((sum, gap) => sum + (gap.weight ?? 1), 0);
    if (totalWeight <= 0) return planned.map((gap) => Math.max(0, Math.round(gap)));
    let assigned = 0;
    for (const [index, gap] of gaps.entries()) {
      const add = Math.floor(remaining * (gap.weight ?? 1) / totalWeight);
      planned[index] += add;
      assigned += add;
    }
    planned[planned.length - 1] += remaining - assigned;
  }

  return planned.map((gap) => Math.max(0, Math.round(gap)));
}

export function planRealtimeGapsBetween(minGaps, maxGaps, availableSeconds, options = {}) {
  if (!minGaps.length) return [];
  const planned = minGaps.map((gap) => Math.max(0, Math.round(gap)));
  let remaining = Math.max(0, Math.round(availableSeconds - sumNumbers(planned)));
  const capacities = maxGaps.map((gap, index) => Math.max(0, Math.round(gap) - planned[index]));
  remaining = distributeGapExtra(planned, capacities, remaining);
  if (remaining > 0 && options.allowBeyondMax) {
    const openCaps = planned.map(() => Number.POSITIVE_INFINITY);
    distributeGapExtra(planned, openCaps, remaining);
  }
  return planned.map((gap) => Math.max(0, Math.round(gap)));
}

export function distributeGapExtra(planned, capacities, extra) {
  let remaining = Math.max(0, Math.round(extra));
  while (remaining > 0) {
    const candidates = capacities
      .map((cap, index) => ({ index, cap }))
      .filter((item) => item.cap > 0);
    if (!candidates.length) break;
    const totalWeight = candidates.reduce((sum, item) => sum + gapDistributionWeight(item.index), 0);
    let assigned = 0;
    for (const item of candidates) {
      const share = Math.max(0, Math.floor(remaining * gapDistributionWeight(item.index) / Math.max(1, totalWeight)));
      const add = Math.min(Number.isFinite(item.cap) ? item.cap : share, share);
      if (add <= 0) continue;
      planned[item.index] += add;
      if (Number.isFinite(capacities[item.index])) capacities[item.index] -= add;
      assigned += add;
    }
    if (assigned === 0) {
      const first = candidates[0];
      planned[first.index] += 1;
      if (Number.isFinite(capacities[first.index])) capacities[first.index] -= 1;
      assigned = 1;
    }
    remaining -= assigned;
  }
  return remaining;
}

export function gapDistributionWeight(index) {
  return 80 + ((index * 37) % 41);
}

export function sumGaps(gaps, key) {
  return gaps.reduce((sum, gap) => sum + Number(gap[key] || 0), 0);
}

export function sumNumbers(values) {
  return values.reduce((sum, value) => sum + Number(value || 0), 0);
}

export function normalizeStretchMinute(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? Math.round(number) : fallback;
}

export function tightSpacingSeconds(task) {
  if (task.type === "image" || task.type === "sticker" || task.type === "video") return 10;
  const len = (task.text || "").replace(/\s+/g, "").length;
  if (len <= 20) return 5;
  if (len <= 60) return 8;
  return 10;
}

export function spacingSeconds(task) {
  if (task.type === "image" || task.type === "sticker" || task.type === "video") return 30;
  const len = (task.text || "").replace(/\s+/g, "").length;
  if (len <= 20) return 20;
  if (len <= 60) return 30;
  return 45;
}

export function parseClockToAbsoluteSeconds(value, afterAbs = null) {
  return parseClockToAbsoluteSecondsShared(value, afterAbs);
}

export function currentAbsoluteSeconds() {
  const now = new Date();
  return now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
}

export function timeToSeconds(time) {
  const seconds = timeToSecondsShared(time);
  return seconds === null ? NaN : seconds;
}

export function secondsToTime(total) {
  return secondsToTimeShared(total);
}

export function applyAbsoluteSchedule(task, absoluteSeconds) {
  if (!task.originalTime) task.originalTime = task.time;
  if (task.originalScheduleDateKey === undefined) task.originalScheduleDateKey = task.scheduleDateKey;
  if (task.originalScheduleDateLabel === undefined) task.originalScheduleDateLabel = task.scheduleDateLabel;
  if (task.originalScheduleDateOffset === undefined) task.originalScheduleDateOffset = Number(task.scheduleDateOffset || 0);
  const dayOffset = Math.floor(absoluteSeconds / 86400);
  task.time = secondsToTime(absoluteSeconds);
  task.scheduleDateOffset = dayOffset;
  if (dayOffset === 0) {
    task.scheduleDateLabel = "";
    task.scheduleDateKey = "today";
    return;
  }

  const date = new Date();
  date.setDate(date.getDate() + dayOffset);
  task.scheduleDateLabel = `${date.getMonth() + 1}/${date.getDate()}`;
  task.scheduleDateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function isMediaLikeTask(task) {
  return task && (task.type === "image" || task.type === "sticker" || task.type === "video");
}

import { parseTime } from "../utils.js";
import {
  CONTINUE_SPEAKER_REMARKS,
  hasContinueSpeakerHint as markerHasContinueSpeakerHint,
  isHeaderRemark as isDocumentHeaderRemark,
  normalizeHeaderRemark as normalizeDocumentHeaderRemark,
  stripInlineHeaderRemark as stripDocumentInlineHeaderRemark
} from "../rules/document-markers.js";
import {
  cleanContentLines,
  cleanRepeatedTextBlock,
  isTimeTailFragment,
  removeContainedDuplicateTextTasks
} from "./content-cleanup.js";
import {
  assetToken,
  hasBlockingContentBetweenMediaAndDouma,
  hasRecentDividerBeforeMedia,
  hasStickerMarker,
  hasTaskForHeader,
  isDecorativeImage,
  isLikelyExplicitStickerFile,
  isLikelyFeaturedReactionMedia,
  isLikelyHeaderOnlyImage,
  isStickerMarker,
  looksLikeVideoCover,
  makeFeaturedMediaTask,
  removeFeaturedVideoCoverImages
} from "./media-owner.js";
import {
  getFeaturedInstructionTextCount,
  isFeaturedAssetLabelLine,
  isFeaturedContinueInstruction,
  isFeaturedDayAnchor,
  isFeaturedDayTitle,
  isFeaturedDoumaMarker,
  isFeaturedInteractiveTuoHint,
  isFeaturedRemarkLine,
  isFeaturedSamePersonInstruction,
  isFeaturedSmallDash,
  isFeaturedStructureOnlyLine,
  isInteractiveTuoMarkerHint,
  isLikelyFeaturedRhythmKeyword,
  normalizeFeaturedRhythmKeyword,
  parseFeaturedTuoMarker,
  parseHeaderTailTuoMarker
} from "./featured-rules.js";
import { removeStickerPreviewDuplicates } from "./media-dedupe.js";

const TIME_IN_HEADER = String.raw`\d{1,2}\s*[：:]\s*\d{1,2}(?:\s*[：:]\s*\d{1,2})?`;
const HEADER_RE = new RegExp(`^(.+?)\\s+(${TIME_IN_HEADER})(.*)$`);
const DATE_SECTION_RE = /^(\d{1,2})\/(\d{1,2})$/;
const DATE_IN_TITLE_RE = /(?:^|[^\d])(\d{1,2})\s*(?:\/|月)\s*(\d{1,2})(?:日)?(?=$|[^\d])/;

function contentCleanupOptions() {
  return {
    isChromeNoise,
    isStickerMarker,
    isHeaderRemark,
    isSectionTitle,
    isVisualSectionTitle,
    isTemplateContentInstruction,
    headerRe: HEADER_RE
  };
}

function buildProjectTasks(lines, images, videos, config = {}) {
  if (normalizeProjectType(config.projectType) === "featured") {
    return buildFeaturedProjectTasks(lines, images, videos, config);
  }
  return buildCollectionProjectTasks(lines, images, videos, config);
}

function buildCollectionProjectTasks(lines, images, videos, config = {}) {
  return buildTasks(lines, images, videos, config);
}

function buildFeaturedProjectTasks(lines, images, videos, config = {}) {
  const parsedLines = splitCollectedLines(lines);
  const featuredImages = removeFeaturedVideoCoverImages(images || [], videos || []);
  const events = [
    ...parsedLines.map((line) => ({ kind: line.isDivider ? "divider" : "line", y: Number(line.y || 0), item: line })),
    ...featuredImages.map((image) => ({ kind: "image", y: Number(image.y || 0), item: image })),
    ...(videos || []).map((video) => ({ kind: "video", y: Number(video.y || 0), item: video }))
  ].sort((a, b) => a.y - b.y || eventKindOrder(a.kind) - eventKindOrder(b.kind) || Number(a.item?.x || 0) - Number(b.item?.x || 0));

  const tasks = [];
  const state = {
    role: null,
    speaker: "",
    speakerNo: 0,
    robotGroup: null,
    speakerRobotGroups: new Map(),
    numberedTuoIdentities: new Map(),
    textLines: [],
    pendingMedia: [],
    order: 0,
    currentDateSection: defaultDateSection(),
    currentSectionTitle: "",
    currentFeaturedDayTitle: "",
    currentFeaturedRhythmTitle: "",
    continueSpeaker: "",
    continueRobotGroup: null,
    sameTuoPlan: null,
    interactiveTuoSpeakers: new Set(),
    lastTuoSpeaker: "",
    afterDivider: false,
    includeRangeMarkers: Boolean(config.readRange?.enabled)
  };

  const startRole = (role, options = {}) => {
    if (state.role && state.role !== role) flushFeaturedText(state, tasks);
    state.role = role;
    if (role === "douma") {
      state.speaker = config.roles?.douma?.tabLabel || "豆妈";
      state.robotGroup = null;
    } else if (options.speaker) {
      state.speaker = options.speaker;
      state.robotGroup = Number.isFinite(Number(options.robotGroup))
        ? Number(options.robotGroup)
        : (state.speakerRobotGroups.get(options.speaker) ?? state.robotGroup ?? state.speakerNo);
    } else if (!state.speaker || state.role !== "tuo" || options.newSpeaker) {
      state.speakerNo += 1;
      state.speaker = `托${state.speakerNo}`;
      state.robotGroup = state.speakerNo;
    }
    if (role === "tuo") {
      state.lastTuoSpeaker = state.speaker;
      if (Number.isFinite(Number(state.robotGroup))) {
        state.speakerRobotGroups.set(state.speaker, Number(state.robotGroup));
      }
    }
    flushPendingMediaToCurrent(state, tasks);
  };

  for (const event of events) {
    if (event.kind === "divider") {
      flushFeaturedText(state, tasks);
      state.afterDivider = true;
      if (state.role === "tuo") {
        state.role = null;
        state.speaker = "";
        state.robotGroup = null;
      }
      continue;
    }

    if (event.kind === "image" || event.kind === "video") {
      const afterDividerMedia = state.role === "tuo" && isFeaturedMediaAfterRecentDivider(event.item, parsedLines);
      if (afterDividerMedia) {
        flushFeaturedText(state, tasks);
        state.role = null;
        state.speaker = "";
        state.robotGroup = null;
        state.afterDivider = true;
      }
      const deferToUpcomingDouma = state.role === "tuo" && shouldDeferFeaturedMediaToUpcomingDouma(event.item, parsedLines);
      const mediaTask = makeFeaturedMediaTask(event.item, event.kind, state, parsedLines, {
        forceSticker: deferToUpcomingDouma && isLikelyFeaturedReactionMedia(event.item, parsedLines)
      });
      flushFeaturedText(state, tasks);
      if (state.role && !(state.afterDivider && state.role !== "douma") && !deferToUpcomingDouma) {
        pushFeaturedTask(tasks, mediaTask, state);
      } else {
        state.pendingMedia.push(mediaTask);
      }
      continue;
    }

    const line = event.item;
    if (isChromeNoise(line.text) || isStickerMarker(line.text) || isTimeTailFragment(line.text)) continue;

    const dateSection = parseDateSectionTitle(line);
    if (dateSection) {
      flushFeaturedText(state, tasks);
      state.currentDateSection = dateSection;
      state.currentSectionTitle = line.text;
      continue;
    }

    const rawText = String(line.text || "").trim();
    const compact = normalizeTemplateLine(rawText).replace(/\s+/g, "");
    if (!rawText) continue;

    if (isFeaturedDocumentTitle(rawText, line, state)) {
      flushFeaturedText(state, tasks);
      state.role = null;
      state.speaker = "";
      state.robotGroup = null;
      state.currentFeaturedDayTitle = rawText;
      state.currentFeaturedRhythmTitle = "";
      state.currentSectionTitle = rawText;
      state.afterDivider = false;
      pushFeaturedRangeMarker(tasks, rawText, state);
      continue;
    }

    if (isFeaturedDayTitle(rawText)) {
      flushFeaturedText(state, tasks);
      state.role = null;
      state.speaker = "";
      state.robotGroup = null;
      state.currentFeaturedDayTitle = rawText;
      state.currentFeaturedRhythmTitle = "";
      state.currentSectionTitle = rawText;
      state.afterDivider = false;
      pushFeaturedRangeMarker(tasks, rawText, state);
      continue;
    }

    if (isFeaturedRhythmTitle(rawText, line, state)) {
      flushFeaturedText(state, tasks);
      state.role = null;
      state.speaker = "";
      state.robotGroup = null;
      state.currentFeaturedRhythmTitle = rawText;
      state.currentSectionTitle = [state.currentFeaturedDayTitle, rawText].filter(Boolean).join(" ");
      state.afterDivider = false;
      pushFeaturedRangeMarker(tasks, rawText, state);
      continue;
    }

    if (isFeaturedDoumaMarker(rawText)) {
      flushFeaturedText(state, tasks);
      startRole("douma");
      state.afterDivider = false;
      continue;
    }

    if (isFeaturedRemarkLine(rawText)) continue;

    const marker = parseFeaturedTuoMarker(rawText);
    if (marker) {
      flushFeaturedText(state, tasks);
      const numberedIdentity = marker.number ? getFeaturedNumberedTuoIdentity(state, marker.number) : null;
      const reuseSpeaker = numberedIdentity?.speaker || "";
      const reuseRobotGroup = numberedIdentity?.robotGroup;
      startRole("tuo", {
        speaker: reuseSpeaker || "",
        robotGroup: reuseRobotGroup,
        newSpeaker: !reuseSpeaker
      });
      state.continueSpeaker = "";
      state.continueRobotGroup = null;
      state.afterDivider = false;
      const isInteractiveMarkedTuo = Boolean(marker.hint && isFeaturedInteractiveTuoHint(marker.hint));
      if (isInteractiveMarkedTuo) state.interactiveTuoSpeakers.add(state.speaker);
      if (marker.hint && isFeaturedSamePersonInstruction(marker.hint)) {
        state.sameTuoPlan = {
          speaker: state.speaker,
          robotGroup: state.robotGroup,
          remainingTextSegments: getFeaturedInstructionTextCount(marker.hint),
          sourceHint: marker.hint
        };
      }
      if (marker.hint && (hasTemplateContinueHint(marker.hint) || isFeaturedContinueInstruction(marker.hint))) {
        state.continueSpeaker = state.speaker;
        state.continueRobotGroup = state.robotGroup;
      }
      continue;
    }

    if (isFeaturedSamePersonInstruction(rawText)) {
      flushFeaturedText(state, tasks);
      if (state.role !== "tuo") startRole("tuo", { newSpeaker: true });
      state.sameTuoPlan = {
        speaker: state.speaker,
        robotGroup: state.robotGroup,
        remainingTextSegments: getFeaturedInstructionTextCount(rawText),
        sourceHint: rawText
      };
      state.interactiveTuoSpeakers.add(state.speaker);
      continue;
    }

    if (hasTemplateContinueHint(rawText) || isFeaturedContinueInstruction(rawText)) {
      flushFeaturedText(state, tasks);
      if (state.role === "tuo" && state.speaker) {
        state.continueSpeaker = state.speaker;
        state.continueRobotGroup = state.robotGroup;
        state.interactiveTuoSpeakers.add(state.speaker);
      } else if (state.lastTuoSpeaker) {
        state.continueSpeaker = state.lastTuoSpeaker;
        state.continueRobotGroup = state.speakerRobotGroups.get(state.lastTuoSpeaker) ?? null;
        state.interactiveTuoSpeakers.add(state.lastTuoSpeaker);
      }
      continue;
    }

    if (isFeaturedAssetLabelLine(rawText)) continue;

    if (line.highlighted) {
      if (state.role !== "douma") {
        flushFeaturedText(state, tasks);
        startRole("douma");
      }
      state.afterDivider = false;
      state.textLines.push({ ...line, text: stripInlineHeaderRemark(rawText) || rawText });
      continue;
    }

    if (isFeaturedSmallDash(rawText)) {
      if (state.role === "douma") {
        state.textLines.push({ ...line, text: "-" });
      } else if (state.role === "tuo") {
        flushFeaturedText(state, tasks);
        state.sameTuoPlan = null;
        state.continueSpeaker = "";
        state.continueRobotGroup = null;
        state.speakerNo += 1;
        state.speaker = `托${state.speakerNo}`;
        state.robotGroup = state.speakerNo;
        state.lastTuoSpeaker = state.speaker;
        state.speakerRobotGroups.set(state.speaker, state.robotGroup);
      }
      continue;
    }

    if (!state.role) {
      if (line.highlighted) startRole("douma");
      else startRole("tuo", {
        speaker: state.continueSpeaker || "",
        robotGroup: state.continueRobotGroup,
        newSpeaker: !state.continueSpeaker
      });
      state.continueSpeaker = "";
      state.continueRobotGroup = null;
    }

    const contentText = stripInlineHeaderRemark(rawText);
    if (contentText && !isFeaturedStructureOnlyLine(contentText)) {
      if (shouldSplitFeaturedSameTuoPlanText(state, line)) flushFeaturedText(state, tasks);
      state.afterDivider = false;
      state.textLines.push({ ...line, text: contentText });
    }
  }

  flushFeaturedText(state, tasks);
  return removeStickerPreviewDuplicates(removeContainedDuplicateTextTasks(tasks))
    .sort((a, b) => a.order - b.order)
    .map((task) => ({ ...task, projectType: "featured" }));
}

function normalizeProjectType(value) {
  return value === "featured" ? "featured" : "collection";
}

function eventKindOrder(kind) {
  if (kind === "divider") return 0;
  if (kind === "line") return 1;
  if (kind === "image") return 2;
  return 3;
}

function pushFeaturedTask(tasks, task, state) {
  state.order += 1;
  tasks.push({
    ...task,
    speaker: state.speaker,
    time: task.time || "00:00:00",
    originalTime: task.originalTime || "",
    role: state.role,
    highlighted: state.role === "douma",
    interactionGroup: 0,
    robotGroup: state.role === "tuo" ? (state.robotGroup ?? state.speakerNo) : null,
    continueSpeaker: Boolean(state.continueSpeaker && state.continueSpeaker === state.speaker),
    interactiveTuo: state.role === "tuo" && state.interactiveTuoSpeakers?.has(state.speaker),
    scheduleDateLabel: state.currentDateSection.label,
    scheduleDateOffset: state.currentDateSection.offset,
    scheduleDateKey: state.currentDateSection.key,
    sectionTitle: state.currentSectionTitle,
    headerText: state.speaker,
    order: state.order
  });
}

function pushFeaturedRangeMarker(tasks, title, state) {
  if (!state.includeRangeMarkers) return;
  state.order += 1;
  tasks.push({
    type: "__range_marker",
    text: title,
    markerTitle: title,
    speaker: "",
    time: "00:00:00",
    originalTime: "",
    role: "range",
    highlighted: false,
    interactionGroup: 0,
    robotGroup: null,
    continueSpeaker: false,
    scheduleDateLabel: state.currentDateSection.label,
    scheduleDateOffset: state.currentDateSection.offset,
    scheduleDateKey: state.currentDateSection.key,
    sectionTitle: state.currentSectionTitle,
    headerText: title,
    order: state.order
  });
}

function flushFeaturedText(state, tasks) {
  if (!state.role || !state.speaker || !state.textLines.length) return;
  const text = cleanRepeatedTextBlock(cleanContentLines(state.textLines, contentCleanupOptions()).join("\n").trim());
  state.textLines = [];
  if (!text) return;
  pushFeaturedTask(tasks, { type: "text", text }, state);
  if (state.sameTuoPlan?.speaker === state.speaker && state.sameTuoPlan.remainingTextSegments > 0) {
    state.sameTuoPlan.remainingTextSegments -= 1;
    if (state.sameTuoPlan.remainingTextSegments <= 0) state.sameTuoPlan = null;
  }
}

function shouldSplitFeaturedSameTuoPlanText(state, line) {
  if (state.role !== "tuo" || !state.textLines.length) return false;
  if (!state.sameTuoPlan || state.sameTuoPlan.speaker !== state.speaker) return false;
  if (Number(state.sameTuoPlan.remainingTextSegments || 0) <= 1) return false;
  if (isFeaturedSamePersonInstruction(state.sameTuoPlan.sourceHint)) return true;
  const previous = state.textLines[state.textLines.length - 1];
  const prevY = Number(previous?.y);
  const curY = Number(line?.y);
  if (!Number.isFinite(prevY) || !Number.isFinite(curY)) return false;
  const prevH = Math.max(12, Number(previous?.h || 0));
  const curH = Math.max(12, Number(line?.h || 0));
  const gap = curY - prevY;
  return gap > Math.max(30, prevH * 1.7, curH * 1.7);
}

function flushPendingMediaToCurrent(state, tasks) {
  if (!state.role || !state.speaker || !state.pendingMedia.length) return;
  const pending = state.pendingMedia.splice(0);
  for (const task of pending) pushFeaturedTask(tasks, task, state);
}

function shouldDeferFeaturedMediaToUpcomingDouma(item, lines) {
  return !hasBlockingContentBetweenMediaAndDouma(item, lines, {
    isChromeNoise,
    isTuoMarker: parseFeaturedTuoMarker,
    isDayTitle: isFeaturedDayTitle,
    isRhythmTitle: isFeaturedRhythmTitle,
    isStructureOnlyLine: isFeaturedStructureOnlyLine,
    isSmallDash: isFeaturedSmallDash,
    isRemarkLine: isFeaturedRemarkLine
  });
}

function isFeaturedMediaAfterRecentDivider(item, lines) {
  return hasRecentDividerBeforeMedia(item, lines, {
    isChromeNoise,
    isSmallDash: isFeaturedSmallDash,
    isRemarkLine: isFeaturedRemarkLine
  });
}

function getFeaturedNumberedTuoIdentity(state, number) {
  const safeNumber = Number(number);
  if (!Number.isFinite(safeNumber) || safeNumber <= 0) return null;
  const key = String(safeNumber);
  if (!state.numberedTuoIdentities.has(key)) {
    const identity = {
      speaker: `托${safeNumber}`,
      robotGroup: safeNumber
    };
    state.numberedTuoIdentities.set(key, identity);
    state.speakerRobotGroups.set(identity.speaker, identity.robotGroup);
  }
  state.speakerNo = Math.max(Number(state.speakerNo || 0), safeNumber);
  return state.numberedTuoIdentities.get(key);
}

function isFeaturedDocumentTitle(text, item = {}, state = {}) {
  const line = String(text || "").trim();
  if (!line || state.currentFeaturedDayTitle || state.currentFeaturedRhythmTitle) return false;
  if (line.length > 36 || line.length < 4) return false;
  if (isFeaturedDayTitle(line) || isFeaturedRhythmTitle(line, item, state) || isFeaturedDoumaMarker(line) || parseFeaturedTuoMarker(line) || isFeaturedRemarkLine(line)) return false;
  if (item.highlighted || HEADER_RE.test(line) || /^https?:\/\//i.test(line)) return false;
  const compact = line.replace(/\s+/g, "");
  return /(?:短袖|短裤|护肝|返场|秒杀|清仓|福利|预告|专场|合集|产品|第\d+天)/.test(compact) && isVisualSectionTitle(item);
}

function isFeaturedRhythmTitle(text, item = {}, state = {}) {
  const compact = normalizeTemplateLine(text).replace(/\s+/g, "");
  if (!compact || compact.length > 24) return false;
  if (isFeaturedDayTitle(compact) || isFeaturedDoumaMarker(compact) || parseFeaturedTuoMarker(compact) || isFeaturedRemarkLine(compact)) return false;
  if (isFeaturedSmallDash(compact) || item.highlighted) return false;
  if (!state.currentFeaturedDayTitle && !isVisualSectionTitle(item)) return /^(?:预告|秒杀|开秒|开售|正式秒杀|正式开抢)$/.test(compact);
  return isLikelyFeaturedRhythmKeyword(compact);
}

function buildTasks(lines, images, videos, config) {
  const parsedLines = splitCollectedLines(lines);
  const headers = [];
  const tasks = [];
  let current = null;
  let buffer = [];
  let order = 0;
  let interactionGroup = 0;
  let nextTuoRobotGroup = 0;
  let currentDateSection = defaultDateSection();
  let currentSectionTitle = "";
  const includeRangeMarkers = Boolean(config.readRange?.enabled);
  const templateState = { nextTuoNo: 1, pendingAutoTuo: false };
  const interactiveTuoNumbers = new Set();
  const continuedSpeakerGroups = new Map();
  const continuedSpeakerAliases = new Map();
  const recentSpeakerGroups = new Map();
  const sameInteractionWindowSeconds = Number(config.sameInteractionWindowMinutes ?? 20) * 60;

  const rememberInteractiveTuo = (number) => {
    const safeNumber = Number(number);
    if (!Number.isFinite(safeNumber) || safeNumber <= 0) return false;
    interactiveTuoNumbers.add(String(safeNumber));
    return true;
  };

  const flushText = () => {
    if (!current || buffer.length === 0) return;
    const text = cleanRepeatedTextBlock(cleanContentLines(buffer, contentCleanupOptions()).join("\n").trim());
    buffer = [];
    if (!text) return;
    tasks.push({
        type: "text",
        speaker: current.speaker,
        time: current.time,
        role: current.role,
        highlighted: current.highlighted,
        interactionGroup: current.interactionGroup,
        robotGroup: current.robotGroup,
        continueSpeaker: current.continueSpeaker,
        interactiveTuo: current.interactiveTuo,
        scheduleDateLabel: current.scheduleDateLabel,
        scheduleDateOffset: current.scheduleDateOffset,
        scheduleDateKey: current.scheduleDateKey,
        sectionTitle: current.sectionTitle,
        headerText: current.headerText,
        text,
        order: current.order + 0.01
      });
  };

  const startCurrent = ({
    speaker,
    timeText = "00:00:00",
    role,
    highlighted,
    y,
    continueSpeaker = false,
    interactiveTuo = false,
    robotGroupOverride = null,
    headerText
  }) => {
    order += 1;
    const parsedTime = parseTime(timeText);
    if (continueSpeaker) interactionGroup += 1;
    const robotGroup = role === "tuo"
      ? (robotGroupOverride || resolveTuoRobotGroup({
          speaker,
          time: parsedTime,
          continueSpeaker,
          continuedSpeakerGroups,
          recentSpeakerGroups,
          nextTuoRobotGroup,
          sameInteractionWindowSeconds
        }))
      : null;
    if (role === "tuo" && robotGroup > nextTuoRobotGroup) nextTuoRobotGroup = robotGroup;
    if (role === "tuo" && robotGroupOverride) {
      continuedSpeakerGroups.set(speaker, robotGroupOverride);
      recentSpeakerGroups.set(speaker, { group: robotGroupOverride, time: parsedTime });
    }
    current = {
      speaker,
      time: parsedTime,
      role,
      highlighted,
      y,
      interactionGroup,
      robotGroup,
      continueSpeaker,
      interactiveTuo,
      scheduleDateLabel: currentDateSection.label,
      scheduleDateOffset: currentDateSection.offset,
      scheduleDateKey: currentDateSection.key,
      sectionTitle: currentSectionTitle,
      headerText,
      order
    };
    headers.push(current);
    return current;
  };

  const pushCollectionRangeMarker = (title) => {
    if (!includeRangeMarkers) return;
    order += 1;
    tasks.push({
      type: "__range_marker",
      text: title,
      markerTitle: title,
      speaker: "",
      time: "00:00:00",
      originalTime: "",
      role: "range",
      highlighted: false,
      interactionGroup: 0,
      robotGroup: null,
      continueSpeaker: false,
      scheduleDateLabel: currentDateSection.label,
      scheduleDateOffset: currentDateSection.offset,
      scheduleDateKey: currentDateSection.key,
      sectionTitle: currentSectionTitle,
      headerText: title,
      order
    });
  };

  for (const line of parsedLines) {
    if (isChromeNoise(line.text)) continue;
    const dateSection = parseDateSectionTitle(line);
    if (dateSection) {
      flushText();
      currentDateSection = dateSection;
      currentSectionTitle = line.text;
      continue;
    }

    if (isTemplateSectionTitle(line)) {
      flushText();
      current = null;
      currentSectionTitle = line.text;
      pushCollectionRangeMarker(line.text);
      templateState.pendingAutoTuo = false;
      continue;
    }

    if (isTemplateSeparator(line.text, current)) {
      flushText();
      current = null;
      templateState.pendingAutoTuo = true;
      continue;
    }

    if (isTemplateSentenceLabel(line.text)) continue;

    const header = line.text.match(HEADER_RE);
    if (header) {
      flushText();
      let speaker = cleanSpeakerName(header[1]);
      const rawTail = header[3]?.trim() || "";
      const tailMarker = parseHeaderTailTuoMarker(rawTail, interactiveTuoNumbers);
      let role = inferRole(speaker, line.highlighted, config);
      let continueSpeaker = isContinueSpeakerRemark(rawTail);
      let interactiveTuo = role === "tuo" && continueSpeaker;
      let robotGroupOverride = null;
      const speakerKey = collectionInteractiveSpeakerKey(speaker);
      if (role === "tuo" && speakerKey && continuedSpeakerAliases.has(speakerKey)) {
        continueSpeaker = true;
        interactiveTuo = true;
        robotGroupOverride = continuedSpeakerAliases.get(speakerKey);
      }
      if (tailMarker) {
        role = "tuo";
        speaker = `托${tailMarker.number}`;
        continueSpeaker = true;
        interactiveTuo = tailMarker.interactiveTuo === true;
        if (interactiveTuo) rememberInteractiveTuo(tailMarker.number);
        if (interactiveTuoNumbers.has(String(tailMarker.number))) {
          interactiveTuo = true;
          robotGroupOverride = Number(tailMarker.number);
        }
      }
      const started = startCurrent({
        speaker,
        timeText: header[2],
        role,
        highlighted: line.highlighted,
        y: line.y,
        continueSpeaker,
        interactiveTuo,
        robotGroupOverride,
        headerText: line.text
      });
      if (role === "tuo" && !tailMarker && speakerKey && (isContinueSpeakerRemark(rawTail) || interactiveTuo)) {
        continuedSpeakerAliases.set(speakerKey, started.robotGroup);
      }
      continue;
    }

    const templateHeader = parseTemplateSpeakerInstruction(line.text, templateState);
    if (templateHeader) {
      flushText();
      const numberedInteractive = templateHeader.number &&
        (templateHeader.interactiveTuo || interactiveTuoNumbers.has(String(templateHeader.number)));
      if (templateHeader.interactiveTuo && templateHeader.number) rememberInteractiveTuo(templateHeader.number);
      startCurrent({
        speaker: templateHeader.speaker,
        role: templateHeader.role,
        highlighted: templateHeader.role === "douma" ? true : line.highlighted,
        y: line.y,
        continueSpeaker: templateHeader.continueSpeaker || numberedInteractive,
        interactiveTuo: Boolean(numberedInteractive),
        robotGroupOverride: numberedInteractive ? Number(templateHeader.number) : null,
        headerText: line.text
      });
      templateState.pendingAutoTuo = false;
      continue;
    }

    if (!current && templateState.pendingAutoTuo && shouldAutoStartTemplateText(line)) {
      const speaker = `托${templateState.nextTuoNo || 1}`;
      templateState.nextTuoNo = (templateState.nextTuoNo || 1) + 1;
      startCurrent({
        speaker,
        role: "tuo",
        highlighted: line.highlighted,
        y: line.y,
        headerText: speaker
      });
      templateState.pendingAutoTuo = false;
    }

    if (!current) continue;
    if (isStickerMarker(line.text)) continue;
    if (isSectionTitle(line.text) || isVisualSectionTitle(line)) {
      flushText();
      currentSectionTitle = line.text;
      pushCollectionRangeMarker(line.text);
      current.sectionTitle = currentSectionTitle;
      continue;
    }
    if (line.text.includes("以下不定时") && line.text.length < 30) continue;
    const contentText = stripInlineHeaderRemark(line.text);
    if (contentText) buffer.push({ ...line, text: contentText });
  }
  flushText();

  const seenImages = new Set();
  const seenVideoRows = new Set();
  for (const video of videos || []) {
    if (!video.src) continue;
    const ownerIndex = findPreviousHeaderIndex(headers, video.y);
    if (ownerIndex < 0) continue;
    const owner = headers[ownerIndex];
    const next = headers[ownerIndex + 1];
    if (next && video.y > next.y) continue;
    const token = assetToken(video.src);
    const videoKey = token ? `asset:${token}` : video.src.split("?")[0];
    if (seenImages.has(videoKey)) continue;
    seenImages.add(videoKey);
    seenVideoRows.add(Math.round(video.y / 12));
    tasks.push({
      type: "video",
      speaker: owner.speaker,
      time: owner.time,
      role: owner.role,
      highlighted: owner.highlighted,
      interactionGroup: owner.interactionGroup,
      robotGroup: owner.robotGroup,
      continueSpeaker: owner.continueSpeaker,
      interactiveTuo: owner.interactiveTuo,
      scheduleDateLabel: owner.scheduleDateLabel,
      scheduleDateOffset: owner.scheduleDateOffset,
      scheduleDateKey: owner.scheduleDateKey,
      sectionTitle: owner.sectionTitle,
      headerText: owner.headerText,
      ownerY: owner.y,
      mediaY: video.y,
      mediaOwnerDistance: Math.max(0, Number(video.y || 0) - Number(owner.y || 0)),
      nextHeaderText: next?.headerText || "",
      nextHeaderY: next?.y || null,
      assetUrl: video.src,
      order: owner.order + 0.02 + Math.max(0, (video.y - owner.y) / 100000)
    });
  }

  for (const image of images) {
    if (!image.src || isDecorativeImage(image.src)) continue;
    const ownerIndex = findPreviousHeaderIndex(headers, image.y);
    if (ownerIndex < 0) continue;
    const owner = headers[ownerIndex];
    const next = headers[ownerIndex + 1];
    const headerOnlyImage = !hasTaskForHeader(tasks, owner) && isLikelyHeaderOnlyImage(parsedLines, image, owner, {
      headerRe: HEADER_RE,
      isVisualSectionTitle
    });
    if (next && image.y > next.y && !headerOnlyImage) continue;
    if (seenVideoRows.has(Math.round(image.y / 12))) continue;
    const possibleVideoCover = looksLikeVideoCover(parsedLines, image, next);
    const isSticker = hasStickerMarker(parsedLines, image, next);
    if (!isSticker && (image.w < 80 || image.h < 80) && !headerOnlyImage) continue;
    const token = assetToken(image.src);
    const imageRow = Math.round(image.y / 12);
    const imageKey = token ? `asset:${token}` : `${image.src.split("?")[0]}|row:${imageRow}`;
    if (seenImages.has(imageKey)) continue;
    seenImages.add(imageKey);
    tasks.push({
      type: isSticker ? "sticker" : "image",
      speaker: owner.speaker,
      time: owner.time,
      role: owner.role,
      highlighted: owner.highlighted,
      interactionGroup: owner.interactionGroup,
      robotGroup: owner.robotGroup,
      continueSpeaker: owner.continueSpeaker,
      interactiveTuo: owner.interactiveTuo,
      scheduleDateLabel: owner.scheduleDateLabel,
      scheduleDateOffset: owner.scheduleDateOffset,
      scheduleDateKey: owner.scheduleDateKey,
      sectionTitle: owner.sectionTitle,
      headerText: owner.headerText,
      ownerY: owner.y,
      mediaY: image.y,
      mediaOwnerDistance: Math.max(0, Number(image.y || 0) - Number(owner.y || 0)),
      nextHeaderText: next?.headerText || "",
      nextHeaderY: next?.y || null,
      possibleVideoCover,
      assetUrl: image.src,
      order: owner.order + 0.02 + Math.max(0, (image.y - owner.y) / 100000)
    });
  }

  return removeStickerPreviewDuplicates(removeContainedDuplicateTextTasks(tasks)).sort((a, b) => a.order - b.order);
}

function splitCollectedLines(lines) {
  const result = [];
  for (const line of lines || []) {
    const rawParts = String(line.text || "")
      .split(/\r?\n/)
      .map((text) => text.trim());
    const firstTextIndex = rawParts.findIndex(Boolean);
    const lastTextIndex = rawParts.length - 1 - [...rawParts].reverse().findIndex(Boolean);
    const parts = rawParts
      .map((text, index) => ({ text, keep: Boolean(text) || (index > firstTextIndex && index < lastTextIndex) }))
      .filter((part) => part.keep);
    if (parts.length <= 1) {
      result.push(line);
      continue;
    }
    const step = Math.max(0.001, Number(line.h || 0) / Math.max(parts.length, 1));
    parts.forEach((part, index) => {
      result.push({
        ...line,
        text: part.text,
        isBlankLine: !part.text,
        y: Number(line.y || 0) + index * step,
        h: step
      });
    });
  }
  return result.sort((a, b) => a.y - b.y || a.x - b.x);
}

function inferRole(speaker, highlighted, config) {
  const doumaKeywords = config.roles?.douma?.speakerKeywords || ["璞嗗"];
  if (highlighted || doumaKeywords.some((kw) => speaker.includes(kw))) return "douma";
  return "tuo";
}

function cleanSpeakerName(raw) {
  return String(raw || "")
    .replace(/\s+\d{1,2}\/\d{1,2}\s*$/, "")
    .trim();
}

function collectionInteractiveSpeakerKey(speaker) {
  return String(speaker || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, "")
    .trim();
}

function isSectionTitle(text) {
  const line = String(text || "").trim().replace(/\s+/g, "");
  if (!line || line.length > 16) return false;
  if (/^(?:\d{1,2}|[一二两三四五六七八九十]+)点(?:钟)?(?:催单|返场|加餐|上链接|补单|捡漏|福利)?$/.test(line)) return true;
  if (/^(?:明日|明天|今日|今天|今晚)?(?:未失效|已失效|有效)?[\u4e00-\u9fa5A-Za-z0-9]{0,8}(?:合集|好物|清单|目录|汇总|专场)(?:预告|合集|好物|清单|目录|汇总|专场)?$/.test(line)) return true;
  return /^(?:催单|返场|加餐|上链接|补单|捡漏|福利)$/.test(line);
}

function parseDateSectionTitle(item) {
  const raw = String(item?.text || "").trim();
  const line = raw.replace(/\s+/g, "");
  if (!line || /^https?:\/\//i.test(line)) return null;
  if (HEADER_RE.test(raw) || /\d{1,2}[：:]\d{2}/.test(line)) return null;
  const exactMatch = line.match(DATE_SECTION_RE);
  const match = exactMatch || line.match(DATE_IN_TITLE_RE);
  if (!match) return null;
  const looksLikeTitle = isVisualSectionTitle(item) || line.length <= 22;
  if (!looksLikeTitle) return null;
  if (!exactMatch && !isAllowedDateSectionTitleLine(line)) return null;
  return buildDateSection(Number(match[1]), Number(match[2]));
}

function isAllowedDateSectionTitleLine(line) {
  const match = String(line || "").match(/(\d{1,2})\s*(?:\/|月)\s*(\d{1,2})(?:日)?/);
  if (!match) return false;
  const before = line.slice(0, match.index);
  const after = line.slice(match.index + match[0].length);
  const beforeOk = !before || /^(?:今天|明天|后天|大后天|第[一二三四五六七八九十\d]+天|[-_—~～、，,：:])+$/.test(before);
  const afterOk = !after || /^(?:早上|上午|中午|下午|晚上|凌晨|早间|午间|晚间|定时|补发|实时|跟发|催单|返场|加餐|福利|预热|测试|发单|上链接|[-_—~～、，,：:])+$/.test(after);
  return beforeOk && afterOk;
}

function defaultDateSection() {
  return { label: "", offset: 0, key: "today" };
}

function buildDateSection(month, day) {
  const today = new Date();
  const target = new Date(today.getFullYear(), month - 1, day);
  if (target.getTime() < startOfDay(today).getTime() - 180 * 86400000) {
    target.setFullYear(target.getFullYear() + 1);
  }
  const offset = Math.round((startOfDay(target).getTime() - startOfDay(today).getTime()) / 86400000);
  return {
    label: `${month}/${day}`,
    offset,
    key: `${target.getFullYear()}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`
  };
}

function startOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function isVisualSectionTitle(item) {
  const line = String(item?.text || "").trim().replace(/\s+/g, "");
  if (!line || line.length > 24 || HEADER_RE.test(line) || /^https?:\/\//i.test(line)) return false;
  const fontSize = Number(item?.fontSize || 0);
  const fontWeight = Number(item?.fontWeight || 0);
  return fontSize >= 18 || (fontSize >= 17 && fontWeight >= 600);
}

function isHeaderRemark(text) {
  return isDocumentHeaderRemark(text);
}

function stripInlineHeaderRemark(text) {
  return stripDocumentInlineHeaderRemark(text);
}

function normalizeHeaderRemark(text) {
  return normalizeDocumentHeaderRemark(text);
}

function isTemplateContentInstruction(item) {
  const text = typeof item === "string" ? item : item?.text;
  return Boolean(
    isTemplateSectionTitle(item) ||
    isTemplateSentenceLabel(text) ||
    parseTemplateSpeakerInstruction(text, { nextTuoNo: 1 }) ||
    isTemplateBareMediaPlan(text)
  );
}

function isTemplateSectionTitle(item) {
  const raw = typeof item === "string" ? item : item?.text;
  const line = normalizeTemplateLine(raw);
  const compact = compactTemplateLine(raw);
  if (!compact || compact.length > 28 || HEADER_RE.test(line) || /^https?:\/\//i.test(line)) return false;
  if (/\d{1,2}[：:]\d{1,2}/.test(compact)) return false;
  if (/^第[一二两三四五六七八九十\d]+天(?:早上|上午|中午|下午|晚上|晚间|午间|早间)?(?:日常)?晒图(?:节奏)?$/.test(compact)) return true;
  if (/^(?:早上|上午|中午|下午|晚上|晚间|午间|早间)?日常晒图[①②③④⑤⑥⑦⑧⑨\d]*$/.test(compact)) return true;
  if (/^(?:早上|上午|中午|下午|晚上|晚间|午间|早间)?晒图(?:节奏|[①②③④⑤⑥⑦⑧⑨\d]+)?$/.test(compact)) return true;
  return false;
}

function isTemplateSeparator(text, current = null) {
  const line = normalizeTemplateLine(text);
  if (/^[-－—_=]{3,}$/.test(line)) return true;
  if (!/^[-－—]$/.test(line)) return false;
  return Boolean(current?.role === "tuo" && current?.continueSpeaker && current?.headerText && !HEADER_RE.test(current.headerText));
}

function isTemplateSentenceLabel(text) {
  const compact = compactTemplateLine(text).replace(/[👇↓⬇️]+/g, "");
  return /^第[一二两三四五六七八九十\d]+句[:：、.。]*$/.test(compact);
}

function parseTemplateSpeakerInstruction(text, state = {}) {
  const line = normalizeTemplateLine(text);
  const compact = compactTemplateLine(text);
  if (!compact || compact.length > 36 || HEADER_RE.test(line) || /^https?:\/\//i.test(line)) return null;
  if (/\d{1,2}[：:]\d{1,2}/.test(compact)) return null;

  if (/^豆妈[:：]?$/.test(compact) || /^豆妈(?:发|说)?(?:一?句|两句|2句|图片|表情包)?$/.test(compact)) {
    return {
      role: "douma",
      speaker: "豆妈",
      continueSpeaker: hasTemplateContinueHint(compact)
    };
  }

  const explicitTuo = compact.match(/^(?:T|托)(\d+)?(?:[:：]?(.*))?$/i);
  if (!explicitTuo) return null;
  const hint = explicitTuo[2] || "";
  if (hint && !isTemplateTuoHint(hint)) return null;

  const number = explicitTuo[1] ? Number(explicitTuo[1]) : Number(state.nextTuoNo || 1);
  if (Number.isFinite(number) && number > 0 && !explicitTuo[1]) state.nextTuoNo = number + 1;
  if (Number.isFinite(number) && number > 0 && explicitTuo[1]) state.nextTuoNo = Math.max(Number(state.nextTuoNo || 1), number + 1);

  return {
    role: "tuo",
    speaker: `托${Number.isFinite(number) && number > 0 ? number : 1}`,
    number: Number.isFinite(number) && number > 0 ? number : 1,
    hint,
    continueSpeaker: hasTemplateContinueHint(compact),
    interactiveTuo: Boolean(hint && isInteractiveTuoMarkerHint(hint))
  };
}

function shouldAutoStartTemplateText(item) {
  const text = typeof item === "string" ? item : item?.text;
  const line = normalizeTemplateLine(text);
  if (!line || /^https?:\/\//i.test(line) || HEADER_RE.test(line)) return false;
  if (isChromeNoise(line) || isStickerMarker(line) || isHeaderRemark(line) || isTimeTailFragment(line)) return false;
  if (isSectionTitle(line) || isVisualSectionTitle(item) || isTemplateContentInstruction(item)) return false;
  return true;
}

function isTemplateBareMediaPlan(text) {
  return false;
}

function isTemplateTuoHint(hint) {
  return hasTemplateContinueHint(hint);
}

function hasTemplateContinueHint(text) {
  return markerHasContinueSpeakerHint(text);
}

function normalizeTemplateLine(text) {
  return String(text || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .trim();
}

function compactTemplateLine(text) {
  return normalizeTemplateLine(text).replace(/\s+/g, "");
}

function resolveTuoRobotGroup({
  speaker,
  time,
  continueSpeaker,
  continuedSpeakerGroups,
  nextTuoRobotGroup,
  recentSpeakerGroups,
  sameInteractionWindowSeconds
}) {
  if (continuedSpeakerGroups.has(speaker)) return continuedSpeakerGroups.get(speaker);
  const seconds = timeToSeconds(time);
  const recent = recentSpeakerGroups.get(speaker);
  const diff = recent && Number.isFinite(seconds) ? Math.abs(seconds - recent.lastSeconds) : Number.POSITIVE_INFINITY;
  if (recent && diff <= sameInteractionWindowSeconds) {
    recent.lastSeconds = Math.max(recent.lastSeconds, seconds);
    if (continueSpeaker) continuedSpeakerGroups.set(speaker, recent.group);
    return recent.group;
  }

  const group = nextTuoRobotGroup + 1;
  if (continueSpeaker) continuedSpeakerGroups.set(speaker, group);
  if (Number.isFinite(seconds)) recentSpeakerGroups.set(speaker, { group, lastSeconds: seconds });
  return group;
}

function timeToSeconds(time) {
  const parts = String(time || "00:00:00").split(":").map(Number);
  return (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0);
}

function isContinueSpeakerRemark(text) {
  const unwrapped = normalizeHeaderRemark(text);
  return CONTINUE_SPEAKER_REMARKS.some((word) => unwrapped.includes(word));
}

function findPreviousHeaderIndex(headers, y) {
  let found = -1;
  for (let i = 0; i < headers.length; i += 1) {
    if (headers[i].y <= y) found = i;
    else break;
  }
  return found;
}

function isChromeNoise(text) {
  return [
    "分享",
    "编辑",
    "评论",
    "上传日志",
    "联系客服",
    "帮助中心",
    "效率指南",
    "添加图标",
    "添加封面",
    "鍒嗕韩",
    "缂栬緫",
    "璇勮",
    "涓婁紶鏃ュ織",
    "鑱旂郴瀹㈡湇",
    "甯姪涓績",
    "鏁堢巼鎸囧崡",
    "娣诲姞鍥炬爣",
    "娣诲姞灏侀潰"
  ].includes(text);
}

export {
  HEADER_RE,
  buildProjectTasks,
  normalizeProjectType,
  parseDateSectionTitle,
  isTemplateSectionTitle,
  isVisualSectionTitle,
  isFeaturedDayTitle,
  isFeaturedRhythmTitle,
  isHeaderRemark,
  isTemplateContentInstruction,
  isFeaturedDayAnchor,
  isLikelyFeaturedRhythmKeyword,
  isDecorativeImage,
  assetToken
};

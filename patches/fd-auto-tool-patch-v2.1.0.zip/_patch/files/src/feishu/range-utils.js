export function normalizeRangeText(text) {
  return String(text || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/[：]/g, ":")
    .replace(/\s+/g, "");
}

export function splitRangeKeywords(keyword) {
  const text = String(keyword || "");
  const splitter = /[｜|]/.test(text) ? /\s*(?:｜|\|)\s*/g : /\s*(?:\+|＋|->|→)\s*/g;
  return text
    .split(splitter)
    .map((part) => part.trim())
    .filter(Boolean);
}

export function rangeLineMatches(text, normalizedKeyword) {
  const line = normalizeRangeText(text);
  return Boolean(line && normalizedKeyword && (line.includes(normalizedKeyword) || normalizedKeyword.includes(line)));
}

export function isRangeDateKeyword(keyword) {
  return /^\d{1,2}\s*(?:\/|月)\s*\d{1,2}(?:日)?$/.test(String(keyword || "").trim());
}

export function rangeSearchText(task) {
  return normalizeRangeText([
    task.headerText,
    task.speaker,
    task.scheduleDateLabel,
    task.sectionTitle,
    task.time,
    task.originalTime,
    task.type,
    task.text,
    task.assetUrl ? `[${task.type === "sticker" ? "表情包" : task.type === "video" ? "视频" : "图片"}]` : ""
  ].filter(Boolean).join(" "));
}

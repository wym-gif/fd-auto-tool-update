import {
  isRangeDateKeyword,
  normalizeRangeText,
  rangeLineMatches,
  rangeSearchText,
  splitRangeKeywords
} from "./range-utils.js";

export function createReadRangeTools(deps = {}) {
  const {
    parseDateSectionTitle = () => null,
    isTemplateSectionTitle = () => false,
    isVisualSectionTitle = () => false,
    isFeaturedDayTitle = () => false,
    isFeaturedRhythmTitle = () => false,
    isHeaderRemark = () => false,
    isTemplateContentInstruction = () => false,
    isFeaturedDayAnchor = () => false,
    isLikelyFeaturedRhythmKeyword = () => false,
    normalizeProjectType = (type) => String(type || ""),
    headerRe = { test: () => false }
  } = deps;

  function applyReadRange(tasks, config = {}, options = {}) {
    const range = config.readRange || {};
    if (!range.enabled) return tasks;

    const rawStartKeyword = String(range.start || "").trim();
    const rawEndKeyword = String(range.end || "").trim();
    const startKeyword = effectiveRangeKeyword(rawStartKeyword, config);
    const endKeyword = effectiveRangeKeyword(rawEndKeyword, config);
    if (!startKeyword || (!endKeyword && !range.endAtDocumentEnd)) return stripRangeMarkers(tasks);

    let startIndex = findRangeBoundaryIndexFrom(tasks, startKeyword, 0, config, {
      allowMissingFeaturedDay: true
    });
    if (startIndex < 0) {
      if (options.startLocatedByPage === true) {
        throw new Error(`已定位到开始关键词，但预览数据里没有采集到开始记录：${rawStartKeyword || startKeyword}。请稍后重试，或把开始关键词换成该条记录里的文字。`);
      } else {
        throw new Error(`读取范围找不到开始位置：${rawStartKeyword || startKeyword}`);
      }
    }

    const endIndex = endKeyword ? findRangeBoundaryIndexFrom(tasks, endKeyword, startIndex, config, {
      startKeyword,
      isEnd: true
    }) : tasks.length - 1;
    if (endIndex < 0) {
      const startLabel = describeFeaturedRangeKeyword(startKeyword, config);
      const endLabel = describeFeaturedRangeKeyword(endKeyword, config);
      throw new Error(`读取范围找不到结束位置：${rawEndKeyword || endKeyword}。已找到开始：${startLabel}；未确认结束：${endLabel}。请重新读取文档目录，或手动换一个更完整的结束关键词。`);
    }
    if (endIndex < startIndex) {
      throw new Error("读取范围结束位置在开始位置前面，请重新填写。");
    }

    const expandedStart = expandRangeStart(tasks, startIndex);
    const expandedEnd = shouldExcludeRangeEnd(range, config, endKeyword)
      ? Math.max(expandedStart, endIndex - 1)
      : expandRangeEnd(tasks, endIndex);
    const result = stripRangeMarkers(tasks.slice(expandedStart, expandedEnd + 1));
    attachRangeStartOmittedMedia(result, findRangeStartOmittedMedia(tasks, expandedStart, config));
    console.log(`读取范围已截取：第 ${expandedStart + 1} 条到第 ${expandedEnd + 1} 条，共 ${result.length} 条。`);
    return result;
  }

  function stripRangeMarkers(tasks) {
    return (tasks || []).filter((task) => task?.type !== "__range_marker");
  }

  function attachRangeStartOmittedMedia(tasks, omittedMedia) {
    if (!Array.isArray(tasks) || !Array.isArray(omittedMedia) || !omittedMedia.length) return tasks;
    Object.defineProperty(tasks, "__rangeStartOmittedMedia", {
      value: omittedMedia,
      enumerable: false,
      configurable: true
    });
    return tasks;
  }

  function isMediaLikeTask(task) {
    return task?.type === "image" || task?.type === "sticker" || task?.type === "video";
  }

  function findRangeStartOmittedMedia(tasks, expandedStart, config = {}) {
    if (!Array.isArray(tasks) || expandedStart <= 0) return [];
    const first = tasks[expandedStart];
    if (!first?.speaker) return [];
    const lookback = Math.max(1, Number(config.rangeStartOmittedMediaLookbackTasks ?? 6));
    const maxOrderGap = Number(config.rangeStartOmittedMediaMaxOrderGap ?? 3);
    const candidates = [];
    for (let index = expandedStart - 1; index >= 0 && index >= expandedStart - lookback; index -= 1) {
      const task = tasks[index];
      if (!isMediaLikeTask(task)) continue;
      if (task.speaker !== first.speaker || task.role !== first.role) continue;
      const orderGap = Math.abs(Number(first.order || expandedStart) - Number(task.order || index));
      if (Number.isFinite(orderGap) && orderGap > maxOrderGap) continue;
      candidates.unshift({
        task,
        reason: "读取范围开始位置前有同说话人的图片/素材，可能属于当前第一条附近内容。",
        firstTask: {
          speaker: first.speaker,
          time: first.time,
          type: first.type,
          text: first.text || "",
          headerText: first.headerText || ""
        }
      });
    }
    return candidates;
  }

  function findRangeBoundaryIndexFrom(tasks, keyword, fromIndex = 0, config = {}, options = {}) {
    const featured = parseFeaturedDayRhythmRangeKeyword(keyword, config);
    if (!featured) return findRangeStartIndexFrom(tasks, keyword, fromIndex);

    const startFeatured = parseFeaturedDayRhythmRangeKeyword(options.startKeyword || "", config);
    const sameDayAsStart = Boolean(startFeatured && normalizeRangeText(startFeatured.day) === normalizeRangeText(featured.day));
    const requireDay = options.isEnd === true && !sameDayAsStart;
    const dayIndex = findRangeTaskIndexBetween(tasks, featured.day, fromIndex, tasks.length);
    if (dayIndex >= 0) {
      const nextDayIndex = findNextFeaturedDayBoundaryIndex(tasks, dayIndex);
      const rhythmIndex = findRangeTaskIndexBetween(tasks, featured.rhythm, dayIndex, nextDayIndex);
      if (rhythmIndex >= 0) return rhythmIndex;
    }

    if (!requireDay || options.allowMissingFeaturedDay === true) {
      return findRangeTaskIndexBetween(tasks, featured.rhythm, fromIndex, tasks.length);
    }
    return -1;
  }

  function findRangeStartIndexFrom(tasks, keyword, fromIndex = 0) {
    const parts = splitRangeKeywords(keyword);
    if (parts.length <= 1) return findRangeTaskIndex(tasks, keyword, fromIndex);

    let cursor = fromIndex;
    let toIndex = tasks.length;
    let foundIndex = -1;
    for (let partIndex = 0; partIndex < parts.length; partIndex += 1) {
      const part = parts[partIndex];
      foundIndex = findRangeTaskIndexBetween(tasks, part, cursor, toIndex);
      if (foundIndex < 0) {
        if (partIndex === 0 && isLikelyFeaturedRhythmKeyword(parts[1])) continue;
        return -1;
      }
      if (partIndex === 0 && isRangeDateKeyword(part)) {
        const dateKey = tasks[foundIndex]?.scheduleDateKey || "";
        if (dateKey) toIndex = findNextDateBoundaryIndex(tasks, foundIndex, dateKey);
      }
      cursor = foundIndex;
    }
    return foundIndex;
  }

  function findNextFeaturedDayBoundaryIndex(tasks, fromIndex) {
    for (let index = Math.max(0, fromIndex + 1); index < tasks.length; index += 1) {
      const task = tasks[index] || {};
      const title = task.markerTitle || task.text || task.headerText || "";
      if (isFeaturedDayTitle(title)) return index;
    }
    return tasks.length;
  }

  function parseFeaturedDayRhythmRangeKeyword(keyword, config = {}) {
    const parts = splitRangeKeywords(effectiveRangeKeyword(keyword, config));
    if (parts.length < 2) return null;
    const day = parts[0];
    const rhythm = parts[1];
    if (!isFeaturedDayAnchor(day) || !isLikelyFeaturedRhythmKeyword(rhythm)) return null;
    return { day, rhythm };
  }

  function buildRangeBoundary(keyword, config = {}, options = {}) {
    const effective = effectiveRangeKeyword(keyword, config);
    const featured = parseFeaturedDayRhythmRangeKeyword(effective, config);
    if (!featured) {
      const normalized = normalizeRangeText(effective);
      return normalized ? { mode: "single", keyword: normalized } : null;
    }
    const startFeatured = parseFeaturedDayRhythmRangeKeyword(options.startKeyword || "", config);
    return {
      mode: "featured-day-rhythm",
      day: normalizeRangeText(featured.day),
      rhythm: normalizeRangeText(featured.rhythm),
      requireDay: !(startFeatured && normalizeRangeText(startFeatured.day) === normalizeRangeText(featured.day))
    };
  }

  function rangeBoundarySeenInLines(lines, boundary) {
    if (!boundary) return false;
    const sorted = [...(lines || [])]
      .filter((line) => !line?.isDivider)
      .sort((a, b) => Number(a?.y || 0) - Number(b?.y || 0) || Number(a?.x || 0) - Number(b?.x || 0));
    if (boundary.mode !== "featured-day-rhythm") {
      return findSingleRangeBoundaryLineIndex(sorted, boundary.keyword, 0) >= 0;
    }

    let daySeen = !boundary.requireDay;
    for (const line of sorted) {
      const text = normalizeRangeText(line?.text || "");
      if (!text) continue;
      if (!daySeen) {
        if (rangeLineMatches(text, boundary.day)) daySeen = true;
        continue;
      }
      if (rangeLineMatches(text, boundary.rhythm)) return true;
    }
    return false;
  }

  function applyRawReadRange(pageData, config = {}, options = {}) {
    const lines = [...(pageData.lines || [])].sort((a, b) => Number(a?.y || 0) - Number(b?.y || 0) || Number(a?.x || 0) - Number(b?.x || 0));
    const boundaryItems = [...(pageData.rangeTexts?.length ? pageData.rangeTexts : lines)]
      .sort((a, b) => Number(a?.y || 0) - Number(b?.y || 0) || Number(a?.x || 0) - Number(b?.x || 0));
    const startBoundary = buildRangeBoundary(config.readRange?.start || "", config);
    const endBoundary = options.endBoundary || buildRangeBoundary(config.readRange?.end || "", config, {
      startKeyword: config.readRange?.start || ""
    });
    const startLineMatch = findRangeBoundaryLineMatch(boundaryItems, startBoundary, 0);
    const startLineIndex = startLineMatch?.index ?? -1;
    const startLine = startLineIndex >= 0 ? boundaryItems[startLineIndex] : null;
    const startMediaItems = [...(pageData.images || []), ...(pageData.videos || [])];
    const startRecordLine = startLine ? findRawRangeStartRecordLine(lines, startLine, startMediaItems, config) : null;
    const startY = startRecordLine ? Number(startRecordLine.y || 0) - 2 : -Infinity;
    if (!startLine) {
      const hint = options.startLocatedByPage
        ? "已定位到开始关键词，但没有采集到开始记录。请稍后重试，或把开始关键词换成该条记录里的文字。"
        : "读取范围找不到开始位置。请换一个更完整的开始关键词，或者选择全文读取。";
      throw new Error(`${hint} 开始关键词：${config.readRange?.start || ""}`);
    }
    const contextLines = startLine ? findRawRangeContextLines(lines, startLine) : [];

    let endLineIndex = -1;
    if (endBoundary) {
      const endLineMatch = findRangeBoundaryLineMatch(boundaryItems, endBoundary, Math.max(0, startLineIndex));
      endLineIndex = endLineMatch?.endIndex ?? -1;
      if (endLineIndex < 0) {
        const startLabel = describeFeaturedRangeKeyword(config.readRange?.start || "", config);
        const endLabel = describeFeaturedRangeKeyword(config.readRange?.end || "", config);
        throw new Error(`读取范围找不到结束位置：${config.readRange?.end || ""}。已找到开始：${startLabel}；未确认结束：${endLabel}。请确认结束关键词在开始位置下方，或手动换一个更完整的结束关键词。`);
      }
    }

    const endLine = endLineIndex >= 0 ? boundaryItems[endLineIndex] : null;
    const endExclusive = shouldExcludeRangeEnd(config.readRange || {}, config, config.readRange?.end || "");
    const inclusiveEndY = endLine
      ? Number(endLine.y || 0) + Number(endLine.h || 0) + 2
      : Infinity;
    const endRecordY = endLine && !endExclusive
      ? findRawRangeEndRecordBottom(lines, endLine, inclusiveEndY, {
        boundary: endBoundary,
        match: endLineIndex >= 0 ? findRangeBoundaryLineMatch(boundaryItems, endBoundary, Math.max(0, startLineIndex)) : null
      })
      : inclusiveEndY;
    const endY = endLine
      ? Number(endLine.y || 0) + (endExclusive ? -2 : Math.max(0, endRecordY - Number(endLine.y || 0)))
      : Infinity;
    const boundedEndY = endY;
    const inRange = (item) => {
      const y = Number(item?.y || 0);
      return y >= startY && y <= boundedEndY;
    };
    const mediaOptions = { startRecordLine, startY, endLine, boundedEndY };
    const ranged = {
      lines: mergeRawRangeLines(contextLines, lines.filter(inRange)),
      images: selectRawRangeMedia(pageData.images || [], inRange, mediaOptions),
      videos: selectRawRangeMedia(pageData.videos || [], inRange, mediaOptions),
      rangeAppliedToRaw: true
    };
    const startText = `开始：${String(startLine.text || "").slice(0, 40)}`;
    const endText = endLine ? `结束：${String(endLine.text || "").slice(0, 40)}` : "结束：文档末尾";
    console.log(`已按飞书原文截取读取范围（${startText}；${endText}）。`);
    return ranged;
  }

  function selectRawRangeMedia(items, inRange, options = {}) {
    const selected = [];
    const seen = new Set();
    for (const item of items || []) {
      const ranged = inRange(item);
      const anchored = ranged ? item : anchorBoundaryMedia(item, options);
      if (!anchored) continue;
      const key = `${anchored.src || ""}|${Math.round(Number(anchored.y || 0) * 10)}|${Math.round(Number(anchored.x || 0) * 10)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      selected.push(anchored);
    }
    return selected.sort((a, b) => Number(a?.y || 0) - Number(b?.y || 0) || Number(a?.x || 0) - Number(b?.x || 0));
  }

  function anchorBoundaryMedia(item, options = {}) {
    return anchorStartBoundaryMedia(item, options);
  }

  function anchorStartBoundaryMedia(item, options = {}) {
    const header = options.startRecordLine;
    if (!isRoleHeaderLine(header)) return null;
    const mediaY = Number(item?.y);
    const mediaH = Number(item?.h || 0);
    const startY = Number(options.startY);
    const headerY = Number(header?.y);
    const headerH = Math.max(1, Number(header?.h || 0));
    if (!Number.isFinite(mediaY) || !Number.isFinite(startY) || !Number.isFinite(headerY)) return null;
    if (mediaY >= startY) return null;
    const mediaBottom = mediaY + Math.max(1, mediaH);
    const maxLookback = Math.max(40, Number(options.rangeBoundaryMediaLookbackPixels ?? 360));
    if (mediaBottom < headerY - 8) return null;
    if (startY - mediaY > maxLookback) return null;
    return {
      ...item,
      y: headerY + headerH + 1,
      rangeBoundaryAnchored: "start"
    };
  }

  function isRoleHeaderLine(line) {
    return headerLineMatches(String(line?.text || "").trim());
  }

  function findRawRangeEndRecordBottom(lines, endLine, fallbackY, options = {}) {
    const endY = Number(endLine?.y);
    if (!Number.isFinite(endY)) return fallbackY;
    if (!shouldExpandRawRangeEndToRecord(endLine, options)) return fallbackY;

    const nextBoundary = [...(lines || [])]
      .filter((line) => {
        const y = Number(line?.y);
        return Number.isFinite(y) && y > endY && isRawRangeHardBoundary(line);
      })
      .sort((a, b) => Number(a.y || 0) - Number(b.y || 0))[0];
    if (nextBoundary) return Number(nextBoundary.y || 0) - 2;

    const laterLines = [...(lines || [])]
      .filter((line) => {
        const y = Number(line?.y);
        return Number.isFinite(y) && y >= endY;
      })
      .sort((a, b) => Number(a.y || 0) - Number(b.y || 0));
    const lastLine = laterLines[laterLines.length - 1];
    if (!lastLine) return fallbackY;
    return Number(lastLine.y || 0) + Number(lastLine.h || 0) + 2;
  }

  function shouldExpandRawRangeEndToRecord(line, options = {}) {
    const text = String(line?.text || "").trim();
    if (!text) return false;
    if (parseDateSectionTitle(line)) return false;
    if (isTemplateSectionTitle(line) || isVisualSectionTitle(line)) return false;
    if (isFeaturedDayTitle(text) || isFeaturedRhythmTitle(text, line)) return false;
    if (!isRoleHeaderLine(line) && isCompleteBodyBoundaryMatch(line, options.boundary, options.match)) return false;
    return true;
  }

  function isCompleteBodyBoundaryMatch(line, boundary, match) {
    if (!boundary || boundary.mode === "featured-day-rhythm") return false;
    const keyword = normalizeRangeText(boundary.keyword);
    const text = normalizeRangeText(line?.text || "");
    if (!keyword || !text) return false;
    if (match?.kind === "window") return true;
    return text === keyword;
  }

  function isRawRangeHardBoundary(line) {
    const text = String(line?.text || "").trim();
    if (!text) return false;
    return headerLineMatches(text) ||
      parseDateSectionTitle(line) ||
      isTemplateSectionTitle(line) ||
      isVisualSectionTitle(line) ||
      isFeaturedDayTitle(text) ||
      isFeaturedRhythmTitle(text, line);
  }

  function findRawRangeStartRecordLine(lines, startLine, mediaItems = [], config = {}) {
    if (!startLine) return null;
    const startText = String(startLine.text || "").trim();
    const startY = Number(startLine.y);
    if (!Number.isFinite(startY)) return startLine;
    let startRecordLine = startLine;

    if (shouldExpandRawRangeStartToRoleHeader(startLine)) {
      const previous = [...(lines || [])]
        .filter((line) => Number.isFinite(Number(line?.y)) && Number(line.y) < startY)
        .sort((a, b) => Number(b.y || 0) - Number(a.y || 0));
      const nearestHardBoundary = previous.find((line) => isRawRangeSectionBoundary(line));
      const header = previous.find((line) => {
        const headerY = Number(line?.y || 0);
        if (nearestHardBoundary && headerY < Number(nearestHardBoundary.y || 0)) return false;
        return isRoleHeaderLine(line);
      });
      if (header) {
        console.log(`开始关键词命中正文，已从所属角色记录开头读取：${String(header.text || "").slice(0, 40)} -> ${startText.slice(0, 40)}`);
        startRecordLine = header;
      }
    }

    const mediaStartLine = findPreviousSameSpeakerMediaStartLine(lines, startRecordLine, mediaItems, config);
    if (mediaStartLine && mediaStartLine !== startRecordLine) {
      console.log(`开始关键词命中同一段后半部分，已补带前面的素材记录：${String(mediaStartLine.text || "").slice(0, 40)} -> ${startText.slice(0, 40)}`);
      return mediaStartLine;
    }
    return startRecordLine;
  }

  function shouldExpandRawRangeStartToRoleHeader(line) {
    const text = String(line?.text || "").trim();
    if (!text || headerLineMatches(text) || parseDateSectionTitle(line)) return false;
    if (isTemplateSectionTitle(line) || isVisualSectionTitle(line)) return false;
    if (isFeaturedDayTitle(text) || isFeaturedRhythmTitle(text, line)) return false;
    if (isHeaderRemark(text) || isTemplateContentInstruction(line)) return false;
    return true;
  }

  function findPreviousSameSpeakerMediaStartLine(lines, startRecordLine, mediaItems = [], config = {}) {
    if (!isRoleHeaderLine(startRecordLine)) return null;
    const speaker = roleHeaderSpeaker(startRecordLine);
    const startY = Number(startRecordLine?.y);
    if (!speaker || !Number.isFinite(startY)) return null;

    const maxLookback = Math.max(80, Number(config.rawRangeStartSameSpeakerMediaLookbackPixels ?? 1200));
    let earliest = startRecordLine;
    let earliestY = startY;
    const previous = [...(lines || [])]
      .filter((line) => {
        const y = Number(line?.y);
        return Number.isFinite(y) && y < startY && startY - y <= maxLookback;
      })
      .sort((a, b) => Number(b.y || 0) - Number(a.y || 0));

    for (const line of previous) {
      if (isRawRangeSectionBoundary(line)) break;
      if (!isRoleHeaderLine(line)) continue;
      if (roleHeaderSpeaker(line) !== speaker) break;

      const lineY = Number(line.y);
      if (!hasMediaBetweenRawRangeLines(mediaItems, lineY, earliestY, config)) break;
      earliest = line;
      earliestY = lineY;
    }

    return earliest === startRecordLine ? null : earliest;
  }

  function hasMediaBetweenRawRangeLines(mediaItems, fromY, toY, config = {}) {
    if (!Number.isFinite(fromY) || !Number.isFinite(toY)) return false;
    const topPadding = Math.max(0, Number(config.rawRangeStartMediaTopPaddingPixels ?? 40));
    const bottomPadding = Math.max(0, Number(config.rawRangeStartMediaBottomPaddingPixels ?? 16));
    return (mediaItems || []).some((item) => {
      const mediaY = Number(item?.y);
      const mediaH = Math.max(1, Number(item?.h || 0));
      if (!Number.isFinite(mediaY)) return false;
      const mediaBottom = mediaY + mediaH;
      return mediaBottom >= fromY - topPadding && mediaY <= toY + bottomPadding;
    });
  }

  function isRawRangeSectionBoundary(line) {
    const text = String(line?.text || "").trim();
    if (!text) return false;
    return parseDateSectionTitle(line) ||
      isTemplateSectionTitle(line) ||
      isVisualSectionTitle(line) ||
      isFeaturedDayTitle(text) ||
      isFeaturedRhythmTitle(text, line);
  }

  function roleHeaderSpeaker(line) {
    const text = String(line?.text || "").trim();
    if (!text) return "";
    const match = text.match(/^(.+?)\s+\d{1,2}\/\d{1,2}\s+\d{1,2}:\d{1,2}:\d{1,2}/);
    if (match) return match[1].trim();
    if (!(headerRe instanceof RegExp)) return "";
    headerRe.lastIndex = 0;
    const headerMatch = headerRe.exec(text);
    headerRe.lastIndex = 0;
    return String(headerMatch?.[1] || "").trim();
  }

  function headerLineMatches(text) {
    const value = String(text || "").trim();
    if (!value || typeof headerRe?.test !== "function") return false;
    if (headerRe instanceof RegExp) headerRe.lastIndex = 0;
    const matched = headerRe.test(value);
    if (headerRe instanceof RegExp) headerRe.lastIndex = 0;
    return matched;
  }

  function findRawRangeContextLines(lines, startLine) {
    const startY = Number(startLine?.y);
    if (!Number.isFinite(startY)) return [];
    if (headerLineMatches(String(startLine?.text || "").trim())) return [];
    const previous = [...(lines || [])]
      .filter((line) => Number.isFinite(Number(line?.y)) && Number(line.y) < startY)
      .sort((a, b) => Number(b.y || 0) - Number(a.y || 0));
    const context = [];
    const header = previous.find((line) => isRoleHeaderLine(line));
    if (header) context.unshift(header);
    const date = previous.find((line) => parseDateSectionTitle(line));
    if (date && (!header || Number(date.y || 0) < Number(header.y || 0))) context.unshift(date);
    return context;
  }

  function mergeRawRangeLines(contextLines, rangeLines) {
    const seen = new Set();
    return [...(contextLines || []), ...(rangeLines || [])]
      .filter((line) => {
        const key = `${Math.round(Number(line?.y || 0) * 10)}|${Math.round(Number(line?.x || 0) * 10)}|${line?.text || ""}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .sort((a, b) => Number(a?.y || 0) - Number(b?.y || 0) || Number(a?.x || 0) - Number(b?.x || 0));
  }

  function findRangeBoundaryLineIndex(lines, boundary, fromIndex = 0) {
    const match = findRangeBoundaryLineMatch(lines, boundary, fromIndex);
    return match?.index ?? -1;
  }

  function findRangeBoundaryLineMatch(lines, boundary, fromIndex = 0) {
    if (!boundary) return null;
    const start = Math.max(0, Number(fromIndex) || 0);
    if (boundary.mode !== "featured-day-rhythm") {
      return findSingleRangeBoundaryLineMatch(lines, boundary.keyword, start);
    }

    let daySeen = !boundary.requireDay;
    for (let index = start; index < lines.length; index += 1) {
      const line = lines[index];
      if (line?.isDivider) continue;
      const text = normalizeRangeText(line?.text || "");
      if (!text) continue;
      if (!daySeen) {
        if (rangeLineMatches(text, boundary.day)) daySeen = true;
        continue;
      }
      if (rangeLineMatches(text, boundary.rhythm)) return { index, endIndex: index, kind: "featured-day-rhythm" };
    }
    return null;
  }

  function findSingleRangeBoundaryLineIndex(lines, normalizedKeyword, fromIndex = 0) {
    const match = findSingleRangeBoundaryLineMatch(lines, normalizedKeyword, fromIndex);
    return match?.index ?? -1;
  }

  function findSingleRangeBoundaryLineMatch(lines, normalizedKeyword, fromIndex = 0) {
    const start = Math.max(0, Number(fromIndex) || 0);
    for (let index = start; index < lines.length; index += 1) {
      const line = lines[index];
      if (line?.isDivider) continue;
      if (rangeLineContainsKeyword(line?.text || "", normalizedKeyword)) {
        return { index, endIndex: index, kind: "line" };
      }
      const windowMatch = findRangeLineWindowMatch(lines, index, normalizedKeyword);
      if (windowMatch) return { index, endIndex: windowMatch.endIndex, kind: "window" };
    }
    return null;
  }

  function rangeLineContainsKeyword(text, normalizedKeyword) {
    const line = normalizeRangeText(text);
    const target = normalizeRangeText(normalizedKeyword);
    return Boolean(line && target && line.includes(target));
  }

  function rangeLineWindowMatches(lines, fromIndex, normalizedKeyword) {
    return Boolean(findRangeLineWindowMatch(lines, fromIndex, normalizedKeyword));
  }

  function findRangeLineWindowMatch(lines, fromIndex, normalizedKeyword) {
    const target = normalizeRangeText(normalizedKeyword);
    if (!target || target.length < 6) return null;
    let combined = "";
    let previousY = null;
    let used = 0;
    for (let index = fromIndex; index < lines.length && used < 8; index += 1) {
      const line = lines[index];
      if (line?.isDivider) break;
      const text = normalizeRangeText(line?.text || "");
      if (!text) continue;
      const y = Number(line?.y);
      if (Number.isFinite(y) && Number.isFinite(previousY) && y - previousY > 96) break;
      previousY = Number.isFinite(y) ? y : previousY;
      combined += text;
      used += 1;
      if (combined.includes(target)) return { endIndex: index };
      if (!target.startsWith(combined)) break;
    }
    return null;
  }

  function describeFeaturedRangeKeyword(keyword, config = {}) {
    const featured = parseFeaturedDayRhythmRangeKeyword(keyword, config);
    if (!featured) return String(keyword || "").trim();
    return `${featured.day} / ${featured.rhythm}`;
  }

  function parseFeaturedPipeRangeKeyword(keyword, config = {}) {
    if (normalizeProjectType(config.projectType) !== "featured") return null;
    const text = String(keyword || "").trim();
    if (!/[｜|]/.test(text)) return null;
    const parts = text
      .split(/\s*(?:｜|\|)\s*/g)
      .map((part) => part.trim())
      .filter(Boolean);
    if (parts.length < 2) return null;
    return {
      title: parts.slice(0, -1).join("｜"),
      keyword: parts[parts.length - 1]
    };
  }

  function effectiveRangeKeyword(keyword, config = {}) {
    const pipeRange = parseFeaturedPipeRangeKeyword(keyword, config);
    return pipeRange ? pipeRange.keyword : String(keyword || "").trim();
  }

  function shouldExcludeRangeEnd(range = {}, config = {}, endKeyword = "") {
    if (!endKeyword) return false;
    if (range.endExclusive === true) return true;
    return normalizeProjectType(config.projectType) === "featured";
  }

  function findRangeTaskIndex(tasks, keyword, fromIndex) {
    return findRangeTaskIndexBetween(tasks, keyword, fromIndex, tasks.length);
  }

  function findRangeTaskIndexBetween(tasks, keyword, fromIndex, toIndex) {
    const wanted = normalizeRangeText(keyword);
    if (!wanted) return -1;
    const end = Math.min(tasks.length, Math.max(0, Number(toIndex) || tasks.length));
    for (let index = Math.max(0, fromIndex); index < end; index += 1) {
      const source = rangeSearchText(tasks[index]);
      if (source.includes(wanted) || wanted.includes(source)) return index;
    }
    return -1;
  }

  function findNextDateBoundaryIndex(tasks, fromIndex, dateKey) {
    for (let index = Math.max(0, fromIndex + 1); index < tasks.length; index += 1) {
      const nextKey = tasks[index]?.scheduleDateKey || "";
      if (nextKey && nextKey !== dateKey) return index;
    }
    return tasks.length;
  }

  function expandRangeStart(tasks, index) {
    const key = rangeTaskGroupKey(tasks[index]);
    let current = index;
    while (current > 0 && rangeTaskGroupKey(tasks[current - 1]) === key) current -= 1;
    return current;
  }

  function expandRangeEnd(tasks, index) {
    const key = rangeTaskGroupKey(tasks[index]);
    let current = index;
    while (current < tasks.length - 1 && rangeTaskGroupKey(tasks[current + 1]) === key) current += 1;
    return current;
  }

  function rangeTaskGroupKey(task) {
    return [
      task.scheduleDateKey || "",
      task.headerText || "",
      task.speaker || "",
      task.time || "",
      Math.floor(Number(task.order || 0))
    ].join("|");
  }

  return {
    applyReadRange,
    stripRangeMarkers,
    attachRangeStartOmittedMedia,
    buildRangeBoundary,
    rangeBoundarySeenInLines,
    applyRawReadRange,
    parseFeaturedPipeRangeKeyword,
    effectiveRangeKeyword,
    parseFeaturedDayRhythmRangeKeyword,
    describeFeaturedRangeKeyword
  };
}

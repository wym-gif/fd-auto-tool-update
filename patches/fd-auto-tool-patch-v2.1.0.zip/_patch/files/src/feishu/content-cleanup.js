export function cleanContentLines(lines, options = {}) {
  const result = [];
  let previousKept = null;
  for (const raw of lines) {
    const item = typeof raw === "string" ? { text: raw } : raw;
    const line = String(item.text || "").trim();
    if (item.isBlankLine) {
      pushSingleBlank(result);
      continue;
    }
    if (
      !line ||
      options.isChromeNoise?.(line) ||
      options.isStickerMarker?.(line) ||
      options.isHeaderRemark?.(line) ||
      isTimeTailFragment(line) ||
      options.isSectionTitle?.(line) ||
      options.isVisualSectionTitle?.(item) ||
      options.headerRe?.test(line) ||
      options.isTemplateContentInstruction?.(item)
    ) continue;
    if (shouldInsertBlankLine(previousKept, item)) pushSingleBlank(result);
    result.push(line);
    previousKept = item;
  }
  return result;
}

export function cleanRepeatedTextBlock(text) {
  const lines = String(text || "").split("\n");
  const trimmedLines = lines.map((line) => line.trim());
  if (trimmedLines.length < 2) return text;

  const whole = trimmedLines.filter(Boolean);
  if (whole.length % 2 === 0 && whole.length >= 2) {
    const half = whole.length / 2;
    const left = whole.slice(0, half).join("\n");
    const right = whole.slice(half).join("\n");
    if (left === right && normalizedContent(left).length >= 12) return left;
  }

  return lines.join("\n").trim();
}

export function isTimeTailFragment(line) {
  return /^[：:]\s*\d{1,2}$/.test(String(line || "").trim());
}

export function removeContainedDuplicateTextTasks(tasks) {
  const sorted = [...tasks].sort((a, b) => a.order - b.order);
  const removeIndexes = new Set();
  for (let i = 0; i < sorted.length; i += 1) {
    const shortTask = sorted[i];
    if (shortTask.type !== "text" || isLikelyRelayText(shortTask.text)) continue;
    const shortText = normalizedContent(shortTask.text);
    if (shortText.length < 8) continue;
    for (let j = 0; j < sorted.length; j += 1) {
      if (i === j || removeIndexes.has(i)) continue;
      const longTask = sorted[j];
      if (!isSameNearTextOwner(shortTask, longTask)) continue;
      if (longTask.type !== "text") continue;
      const longText = normalizedContent(longTask.text);
      if (longText.length <= shortText.length) continue;
      if (!longText.includes(shortText)) continue;
      removeIndexes.add(i);
    }
  }
  return sorted.filter((_, index) => !removeIndexes.has(index));
}

function isSameNearTextOwner(a, b) {
  if (!a || !b) return false;
  if (a.role !== b.role || a.speaker !== b.speaker) return false;
  if ((a.scheduleDateKey || "") !== (b.scheduleDateKey || "")) return false;
  const orderDiff = Math.abs(Number(a.order || 0) - Number(b.order || 0));
  const timeDiff = Math.abs(timeToSeconds(a.time || "00:00:00") - timeToSeconds(b.time || "00:00:00"));
  return orderDiff <= 3 || timeDiff <= 180;
}

function normalizedContent(text) {
  return String(text || "").replace(/\s+/g, "");
}

function isLikelyRelayText(text) {
  const compact = normalizedContent(text);
  if (!compact || compact.length > 12) return false;
  return /^(?:我要|收到|可以|好的|好|要|抢|蹲|等|安排|来了|买了|拍了|冲|求|有|没有|谢谢|1|2|3)+[!！。~～]*$/.test(compact);
}

function pushSingleBlank(result) {
  if (result.length && result[result.length - 1] !== "") result.push("");
}

function shouldInsertBlankLine(previous, current) {
  if (!previous || !current) return false;
  const prevY = Number(previous.y);
  const curY = Number(current.y);
  if (!Number.isFinite(prevY) || !Number.isFinite(curY)) return false;
  const prevH = Math.max(12, Number(previous.h || 0));
  const curH = Math.max(12, Number(current.h || 0));
  const normalGap = Math.max(prevH, curH);
  const gap = curY - prevY;
  return gap > Math.max(28, normalGap * 1.65);
}

function timeToSeconds(time) {
  const parts = String(time || "00:00:00").split(":").map((part) => Number(part));
  if (parts.some((part) => !Number.isFinite(part))) return Number.NaN;
  const [h = 0, m = 0, s = 0] = parts;
  return h * 3600 + m * 60 + s;
}

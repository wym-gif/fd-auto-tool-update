import {
  clearProgressLine,
  reportControlProgress,
  writeProgressBar
} from "../runtime/progress.js";

export async function collectPageData(page, config = {}, options = {}, hooks = {}) {
  const checkPreviewRestartSignal = hooks.checkPreviewRestartSignal || (() => {});
  const buildRangeBoundary = hooks.buildRangeBoundary || (() => null);
  const rangeBoundarySeenInLines = hooks.rangeBoundarySeenInLines || (() => false);
  const allLines = new Map();
  const allRangeTexts = new Map();
  const allImages = new Map();
  const allVideos = new Map();
  const scrollWaitMs = Number(config.feishuScrollWaitMs ?? 520);
  const showProgress = options.showProgress === true;
  const startAtCurrentPosition = options.startAtCurrentPosition === true;
  const rangeStartHoldSteps = startAtCurrentPosition
    ? Math.max(0, Number(config.feishuRangeStartHoldSteps ?? 3))
    : 0;
  const rangeStartHoldMs = Math.max(scrollWaitMs, Number(config.feishuRangeStartHoldMs ?? 900));
  const startBoundary = options.requireStartBoundary ? buildRangeBoundary(config.readRange?.start || "", config) : null;
  const maxStartConfirmSteps = startBoundary
    ? Math.max(rangeStartHoldSteps + 3, Number(config.feishuRangeStartConfirmSteps ?? 6))
    : 0;
  const endBoundary = options.stopAfterRangeEnd ? buildRangeBoundary(config.readRange?.end || "", config, {
    startKeyword: config.readRange?.start || ""
  }) : null;
  const scrollDistance = startAtCurrentPosition
    ? Number(config.feishuRangeScrollPixels ?? 650)
    : Number(config.feishuScrollPixels ?? 900);

  await page.evaluate((keepCurrentPosition) => {
    const seen = new Set();
    const scrollers = [document.scrollingElement, document.documentElement, document.body, ...document.querySelectorAll("*")]
      .filter(Boolean)
      .filter((el) => {
        if (seen.has(el)) return false;
        seen.add(el);
        return el.scrollHeight > el.clientHeight + 20;
      });
    if (!keepCurrentPosition) {
      window.scrollTo(0, 0);
      for (const el of scrollers) el.scrollTop = 0;
    }
  }, startAtCurrentPosition).catch(() => {});
  if (!startAtCurrentPosition) await page.keyboard.press("Home").catch(() => {});
  await page.waitForTimeout(Math.max(500, scrollWaitMs));

  let staleSteps = 0;
  let lastSeenCount = 0;
  let lastScrollMark = "";
  let startSeenAtStep = -1;
  let endSeenAtStep = -1;
  const maxSteps = startAtCurrentPosition ? Number(config.feishuRangeScrollSteps ?? 120) : 180;
  for (let step = 0; step < maxSteps; step += 1) {
    checkPreviewRestartSignal(config);
    const pageData = await page.evaluate(() => {
      const normalize = (text) => (text || "").replace(/\u200b/g, "").replace(/\u00a0/g, " ").trim();
      const isVisible = (el) => {
        const r = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && style.visibility !== "hidden" && style.display !== "none";
      };
      const getScrollers = () => {
        const seen = new Set();
        return [document.scrollingElement, document.documentElement, document.body, ...document.querySelectorAll("*")]
          .filter(Boolean)
          .filter((el) => {
            if (seen.has(el)) return false;
            seen.add(el);
            return el.scrollHeight > el.clientHeight + 20;
          });
      };
      const scrollTop = Math.max(
        window.scrollY || 0,
        ...getScrollers().map((el) => el.scrollTop || 0)
      );
      const yellowish = (color) => {
        const nums = String(color || "").match(/\d+/g)?.map(Number) || [];
        if (nums.length < 3) return false;
        const [r, g, b] = nums;
        return r > 180 && g > 150 && b < 170;
      };
      const hasYellow = (el) => {
        const innerNodes = [el, ...Array.from(el.querySelectorAll("*"))];
        for (const node of innerNodes) {
          const s = getComputedStyle(node);
          if (yellowish(s.backgroundColor) || yellowish(s.background)) return true;
        }

        let cur = el;
        for (let i = 0; cur && i < 6; i += 1, cur = cur.parentElement) {
          const s = getComputedStyle(cur);
          if (yellowish(s.backgroundColor) || yellowish(s.background)) return true;
        }
        return false;
      };

      const lines = Array.from(document.querySelectorAll(".ace-line"))
        .filter(isVisible)
        .map((el) => {
          const r = el.getBoundingClientRect();
          const style = readLineStyle(el);
          return {
            text: normalize(el.innerText || el.textContent || ""),
            x: r.x,
            y: r.y + scrollTop,
            w: r.width,
            h: r.height,
            fontSize: style.fontSize,
            fontWeight: style.fontWeight,
            highlighted: hasYellow(el)
          };
        })
        .filter((line) => line.text)
        .sort((a, b) => a.y - b.y || a.x - b.x);

      const contentLeft = lines.length ? Math.max(0, Math.min(...lines.map((line) => line.x)) - 80) : Math.max(30, window.innerWidth * 0.03);
      const contentRight = lines.length ? Math.min(window.innerWidth, Math.max(...lines.map((line) => line.x + line.w)) + 100) : window.innerWidth * 0.9;
      const directText = (el) => normalize(Array.from(el.childNodes || [])
        .filter((node) => node.nodeType === Node.TEXT_NODE)
        .map((node) => node.nodeValue || "")
        .join(""));
      const neutralLineColor = (color) => {
        const nums = String(color || "").match(/\d+/g)?.map(Number) || [];
        if (nums.length < 3) return false;
        const [r, g, b] = nums;
        return Math.max(r, g, b) - Math.min(r, g, b) < 28 && r >= 160 && r <= 245;
      };
      const lineStyle = (el) => {
        const s = getComputedStyle(el);
        const borderTop = parseFloat(s.borderTopWidth) || 0;
        const borderBottom = parseFloat(s.borderBottomWidth) || 0;
        return {
          style: s,
          borderTop,
          borderBottom,
          hasBorder: borderTop > 0 || borderBottom > 0 || el.tagName === "HR",
          neutralBg: neutralLineColor(s.backgroundColor) || neutralLineColor(s.borderTopColor) || neutralLineColor(s.borderBottomColor)
        };
      };
      const isTextlessRuleBox = (el, rect) => {
        if (!rect || rect.width < 80 || rect.height > 10) return false;
        const text = normalize(el.innerText || el.textContent || "");
        if (text || directText(el)) return false;
        const info = lineStyle(el);
        return info.hasBorder || info.neutralBg || el.tagName === "HR";
      };
      const findEmbeddedRuleBox = (el) => {
        if (!el.matches?.(".ace-line, [class*='divider'], [class*='separate'], [class*='horizontal'], [class*='line']")) return null;
        const text = normalize(el.innerText || el.textContent || "");
        if (text || directText(el)) return null;
        const children = Array.from(el.querySelectorAll("hr, div, span"));
        for (const child of children) {
          if (!isVisible(child)) continue;
          const childRect = child.getBoundingClientRect();
          if (isTextlessRuleBox(child, childRect)) return childRect;
        }
        return null;
      };
      const dividerCandidates = [
        ...document.querySelectorAll("hr, [role='separator'], .ace-line, [class*='divider'], [class*='separate'], [class*='horizontal'], [class*='line']"),
        ...document.querySelectorAll("div, span")
      ];
      const dividers = Array.from(new Set(dividerCandidates))
        .filter(isVisible)
        .map((el) => {
          const r = el.getBoundingClientRect();
          const embedded = findEmbeddedRuleBox(el);
          const box = embedded || r;
          const text = normalize(el.innerText || el.textContent || "");
          const ownRule = isTextlessRuleBox(el, r);
          const emptyAceLineRule = Boolean(embedded && !text && el.matches?.(".ace-line"));
          if (!ownRule && !emptyAceLineRule) return null;
          if (box.width < 120 || r.height > 48 || box.right < contentLeft || box.left > contentRight) return null;
          return {
            text: "",
            x: box.x,
            y: box.y + scrollTop,
            w: box.width,
            h: Math.max(1, box.height),
            fontSize: 0,
            fontWeight: 400,
            highlighted: false,
            isDivider: true
          };
        })
        .filter(Boolean);

      const imageMap = new Map();
      const imageElements = Array.from(document.querySelectorAll([
        "img",
        "[style*='background-image']",
        "[data-src]",
        "[data-original]",
        "[data-image]",
        "[data-url]",
        "[data-thumbnail]",
        "[data-cover]",
        "[src]"
      ].join(",")));
      for (const el of imageElements) {
        if (!isVisible(el)) continue;
        const src = readImageSrc(el);
        if (!src || !isImageLikeSrc(src) || isUiImageSrc(src)) continue;
        const r = el.getBoundingClientRect();
        if (r.width <= 36 || r.height <= 36) continue;
        const style = getComputedStyle(el);
        if (style.position === "fixed" || style.position === "sticky") continue;
        const parent = el.closest("[class*='video'],[class*='media'],[class*='image'],[class*='picture'],.ace-line,div");
        const item = {
          x: r.x,
          y: r.y + scrollTop,
          w: r.width,
          h: r.height,
          src,
          alt: el.alt || el.getAttribute("aria-label") || "",
          parentText: normalize(parent?.innerText || parent?.textContent || "")
        };
        const key = `${Math.round(item.y / 4)}|${Math.round(item.x / 4)}|${src.split("?")[0]}`;
        if (!imageMap.has(key)) imageMap.set(key, item);
      }
      const images = Array.from(imageMap.values()).sort((a, b) => a.y - b.y || a.x - b.x);

      const videos = Array.from(document.querySelectorAll("video, video source, source[type*='video'], a[href$='.mp4'], a[href*='.mp4?'], [src$='.mp4'], [src*='.mp4?']"))
        .map((el) => {
          const src = el.currentSrc || el.src || el.href || el.getAttribute("src") || "";
          const type = el.type || el.getAttribute("type") || "";
          const host = el.closest("video,[class*='video'],[class*='media'],.ace-line,div") || el;
          const r = host.getBoundingClientRect();
          return {
            x: r.x,
            y: r.y + scrollTop,
            w: r.width,
            h: r.height,
            src,
            type,
            text: normalize(host.innerText || host.textContent || "")
          };
        })
        .filter((item) => item.src && /video|\.mp4(\?|$)|\.mov(\?|$)|\.webm(\?|$)|blob:/i.test(`${item.src} ${item.type}`))
        .sort((a, b) => a.y - b.y || a.x - b.x);
      const rangeTexts = collectVisibleTextNodes();

      const scrollers = getScrollers();
      const scrollMark = scrollers
        .map((el) => `${Math.round(el.scrollTop || 0)}/${Math.round(el.scrollHeight || 0)}`)
        .join("|");
      return {
        scrollMark,
        lines: [...lines, ...dividers].sort((a, b) => a.y - b.y || a.x - b.x),
        rangeTexts,
        images,
        videos
      };

      function readLineStyle(el) {
        const items = [el, ...Array.from(el.querySelectorAll("span,strong,b"))].map((node) => {
          const s = getComputedStyle(node);
          const fontSize = parseFloat(s.fontSize) || 0;
          const fontWeight = Number.parseInt(s.fontWeight, 10) || (s.fontWeight === "bold" ? 700 : 400);
          return { fontSize, fontWeight };
        });
        return items.reduce((best, item) => (
          item.fontSize > best.fontSize || item.fontWeight > best.fontWeight ? item : best
        ), { fontSize: 0, fontWeight: 400 });
      }

      function readImageSrc(el) {
        const direct = el.currentSrc || el.src || "";
        if (direct) return direct;
        for (const name of ["data-src", "data-original", "data-image", "data-url", "data-thumbnail", "data-cover", "src"]) {
          const value = el.getAttribute?.(name);
          if (value) return value;
        }
        const srcset = el.getAttribute?.("srcset") || el.getAttribute?.("data-srcset") || "";
        if (srcset) return srcset.split(",").map((part) => part.trim().split(/\s+/)[0]).find(Boolean) || "";
        const bg = getComputedStyle(el).backgroundImage || "";
        const match = bg.match(/url\(["']?([^"')]+)["']?\)/);
        return match?.[1] || "";
      }

      function isImageLikeSrc(src) {
        return /(?:image|img|thumbnail|preview|cover|download|stream|blob:|data:image|\.png(?:\?|$)|\.jpe?g(?:\?|$)|\.gif(?:\?|$)|\.webp(?:\?|$))/i.test(src || "");
      }

      function isUiImageSrc(src) {
        return /avatar|logo|sprite|toolbar|data:image\/svg\+xml/i.test(src || "");
      }

      function collectVisibleTextNodes() {
        const items = [];
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
          acceptNode(node) {
            const text = normalize(node.nodeValue || "");
            if (!text) return NodeFilter.FILTER_REJECT;
            const parent = node.parentElement;
            if (!parent || !isVisible(parent)) return NodeFilter.FILTER_REJECT;
            if (/^(SCRIPT|STYLE|NOSCRIPT)$/.test(parent.tagName || "")) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
          }
        });
        let node;
        while ((node = walker.nextNode())) {
          const text = normalize(node.nodeValue || "");
          if (!text) continue;
          const parent = node.parentElement;
          const parentStyle = parent ? getComputedStyle(parent) : null;
          if (parentStyle && (parentStyle.position === "fixed" || parentStyle.position === "sticky")) continue;
          const range = document.createRange();
          range.selectNodeContents(node);
          const rect = range.getBoundingClientRect();
          range.detach();
          if (!rect || rect.width <= 0 || rect.height <= 0) continue;
          if (rect.bottom < 90 || rect.top > window.innerHeight - 40) continue;
          if (lines.length) {
            if (rect.right < contentLeft || rect.left > contentRight) continue;
          } else if (rect.right < Math.max(180, window.innerWidth * 0.14)) {
            continue;
          }
          items.push({
            text,
            x: rect.x,
            y: rect.y + scrollTop,
            w: rect.width,
            h: rect.height
          });
        }
        const seen = new Set();
        return items
          .sort((a, b) => a.y - b.y || a.x - b.x)
          .filter((item) => {
            const key = `${Math.round(item.y / 3)}|${item.text}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
          });
      }
    });

    for (const line of pageData.lines) {
      const key = line.isDivider
        ? `${Math.round(line.y / 4)}|divider|${Math.round(line.x / 4)}|${Math.round(line.w / 20)}`
        : `${Math.round(line.y / 4)}|${line.text}`;
      if (!allLines.has(key)) allLines.set(key, line);
    }
    for (const image of pageData.images) {
      const key = `${Math.round(image.y / 4)}|${image.src.split("?")[0]}`;
      if (!allImages.has(key)) allImages.set(key, image);
    }
    for (const video of pageData.videos || []) {
      const key = `${Math.round(video.y / 4)}|${video.src.split("?")[0]}`;
      if (!allVideos.has(key)) allVideos.set(key, video);
    }
    for (const item of pageData.rangeTexts || []) {
      const key = `${Math.round(item.y / 3)}|${item.text}`;
      if (!allRangeTexts.has(key)) allRangeTexts.set(key, item);
    }

    const boundaryLines = Array.from(new Map([
      ...Array.from(allLines.values()).map((line) => [`line:${Math.round(Number(line.y || 0) * 3)}:${line.text}`, line]),
      ...Array.from(allRangeTexts.values()).map((line) => [`range:${Math.round(Number(line.y || 0) * 3)}:${line.text}`, line])
    ]).values());
    if (startBoundary && startSeenAtStep < 0 && rangeBoundarySeenInLines(boundaryLines, startBoundary)) {
      startSeenAtStep = step;
      if (showProgress) {
        reportControlProgress(config.__runControl, "已确认开始位置", 1, 1, "开始关键词已采集");
      }
    }
    if (endBoundary && endSeenAtStep < 0 && rangeBoundarySeenInLines(boundaryLines, endBoundary)) {
      endSeenAtStep = step;
    }
    const seenCount = allLines.size + allImages.size + allVideos.size;
    if (showProgress && (step === 0 || step % 4 === 0 || step + 1 === maxSteps)) {
      const detail = `文本 ${allLines.size} 行，素材 ${allImages.size + allVideos.size} 个`;
      writeProgressBar("扫描飞书", step + 1, maxSteps, detail);
      reportControlProgress(config.__runControl, "扫描飞书", step + 1, maxSteps, detail);
    }
    if (endSeenAtStep >= 0 && step - endSeenAtStep >= 4) break;
    const noNewContent = seenCount === lastSeenCount && pageData.scrollMark === lastScrollMark;
    staleSteps = noNewContent ? staleSteps + 1 : 0;
    const staleLimit = endBoundary && endSeenAtStep < 0 ? 18 : 8;
    if (staleSteps >= staleLimit) break;
    lastSeenCount = seenCount;
    lastScrollMark = pageData.scrollMark;
    if (step < rangeStartHoldSteps) {
      if (showProgress) {
        const detail = `文本 ${allLines.size} 行，素材 ${allImages.size + allVideos.size} 个`;
        writeProgressBar("等待开头素材", step + 1, rangeStartHoldSteps, detail);
        reportControlProgress(config.__runControl, "等待开头素材", step + 1, rangeStartHoldSteps, detail);
      }
      await page.waitForTimeout(rangeStartHoldMs);
      continue;
    }
    if (startBoundary && startSeenAtStep < 0 && step < maxStartConfirmSteps) {
      if (showProgress) {
        const detail = `文本 ${allLines.size} 行，素材 ${allImages.size + allVideos.size} 个`;
        writeProgressBar("确认开始位置", step + 1, maxStartConfirmSteps, detail);
        reportControlProgress(config.__runControl, "确认开始位置", step + 1, maxStartConfirmSteps, detail);
      }
      const nudgePixels = -Math.max(120, Math.min(260, Math.round(scrollDistance / 3)));
      await page.evaluate((distance) => {
        const seen = new Set();
        const scrollers = [document.scrollingElement, document.documentElement, document.body, ...document.querySelectorAll("*")]
          .filter(Boolean)
          .filter((el) => {
            if (seen.has(el)) return false;
            seen.add(el);
            return el.scrollHeight > el.clientHeight + 20;
          });
        window.scrollBy(0, distance);
        for (const el of scrollers) {
          el.scrollTop = Math.max(0, el.scrollTop + distance);
        }
      }, nudgePixels).catch(() => {});
      await page.waitForTimeout(rangeStartHoldMs);
      continue;
    }
    const moved = await page.evaluate((distance) => {
      const seen = new Set();
      const scrollers = [document.scrollingElement, document.documentElement, document.body, ...document.querySelectorAll("*")]
        .filter(Boolean)
        .filter((el) => {
          if (seen.has(el)) return false;
          seen.add(el);
          return el.scrollHeight > el.clientHeight + 20;
        });
      const before = scrollers.map((el) => Math.round(el.scrollTop || 0)).join("|");
      window.scrollBy(0, distance);
      for (const el of scrollers) {
        el.scrollTop = Math.min(el.scrollTop + distance, el.scrollHeight);
      }
      const after = scrollers.map((el) => Math.round(el.scrollTop || 0)).join("|");
      return before !== after;
    }, scrollDistance).catch(() => false);
    if (!moved) {
      await page.mouse.wheel(0, scrollDistance).catch(() => {});
    }
    await page.waitForTimeout(scrollWaitMs);
  }
  checkPreviewRestartSignal(config);
  if (showProgress) clearProgressLine();

  return {
    lines: removeOverlayDuplicateLines(Array.from(allLines.values()).sort((a, b) => a.y - b.y || a.x - b.x)),
    rangeTexts: Array.from(allRangeTexts.values()).sort((a, b) => a.y - b.y || a.x - b.x),
    images: Array.from(allImages.values()).sort((a, b) => a.y - b.y || a.x - b.x),
    videos: Array.from(allVideos.values()).sort((a, b) => a.y - b.y || a.x - b.x),
    rangeStartCaptured: !startBoundary || startSeenAtStep >= 0
  };
}

export function removeOverlayDuplicateLines(lines) {
  const result = [];
  for (const line of lines || []) {
    const duplicateIndex = result.findIndex((kept) => isOverlayDuplicateLine(kept, line));
    if (duplicateIndex >= 0) {
      result[duplicateIndex] = chooseBetterOverlayLine(result[duplicateIndex], line);
      continue;
    }
    result.push(line);
  }
  return result.sort((a, b) => a.y - b.y || a.x - b.x);
}

function isOverlayDuplicateLine(a, b) {
  if (!a || !b) return false;
  if (String(a.text || "").trim() !== String(b.text || "").trim()) return false;
  const ay = Number(a.y);
  const by = Number(b.y);
  const ax = Number(a.x);
  const bx = Number(b.x);
  if (!Number.isFinite(ay) || !Number.isFinite(by) || !Number.isFinite(ax) || !Number.isFinite(bx)) return false;
  const lineHeight = Math.max(12, Number(a.h || 0), Number(b.h || 0));
  const nearSameRow = Math.abs(ay - by) <= Math.max(6, lineHeight * 0.45);
  const nearSameColumn = Math.abs(ax - bx) <= 24;
  return nearSameRow && nearSameColumn;
}

function chooseBetterOverlayLine(a, b) {
  if (a.highlighted !== b.highlighted) return a.highlighted ? a : b;
  const ah = Number(a.h || 0);
  const bh = Number(b.h || 0);
  return bh > ah ? b : a;
}

import {
  hasContinueSpeakerHint as markerHasContinueSpeakerHint,
  isStableDoumaMarker
} from "../rules/document-markers.js";

export function parseFeaturedTuoMarker(text) {
  const line = normalizeTemplateLine(text);
  const match = line.match(/^[-－—]?\s*(?:T|托)\s*([0-9０-９一二三四五六七八九十]*)\s*(.*)$/i);
  if (!match) return null;
  const number = parseFeaturedTuoNumber(match[1]);
  const hint = String(match[2] || "").trim();
  const compactHint = hint.replace(/\s+/g, "");
  if (number && isBracketedFeaturedMarkerNote(compactHint)) {
    const note = unwrapFeaturedMarkerNote(hint);
    return { hint: isFeaturedTuoInstructionHint(note.replace(/\s+/g, "")) ? note : "", number };
  }
  if (!hint || isFeaturedTuoInstructionHint(compactHint)) return { hint, number };
  return null;
}

export function parseHeaderTailTuoMarker(text, knownInteractiveNumbers = new Set()) {
  const line = normalizeTemplateLine(text);
  if (!line) return null;
  const marker = parseFeaturedTuoMarker(line);
  if (!marker?.number) return null;
  const hint = normalizeTemplateLine(marker.hint || "").replace(/\s+/g, "");
  const key = String(marker.number);
  if (!hint && !knownInteractiveNumbers.has(key)) return null;
  if (hint && !isFeaturedTuoInstructionHint(hint)) return null;
  return {
    ...marker,
    interactiveTuo: knownInteractiveNumbers.has(key) || isInteractiveTuoMarkerHint(hint)
  };
}

export function isInteractiveTuoMarkerHint(text) {
  const compact = compactTemplateLine(text);
  if (!compact) return false;
  return hasTemplateContinueHint(compact) || isFeaturedInteractiveTuoHint(compact);
}

export function getFeaturedInstructionTextCount(text) {
  const compact = normalizeTemplateLine(text).replace(/\s+/g, "");
  if (/三句|3句/.test(compact)) return 3;
  if (/两句|2句|两句话|2句话/.test(compact)) return 2;
  return 1;
}

export function isFeaturedTuoInstructionHint(hint) {
  if (!hint) return true;
  return hasTemplateContinueHint(hint);
}

export function isFeaturedInteractiveTuoHint(hint) {
  return hasTemplateContinueHint(hint);
}

export function isFeaturedSamePersonInstruction() {
  return false;
}

export function isFeaturedContinueInstruction() {
  return false;
}

export function isFeaturedRemarkLine(text) {
  const compact = normalizeTemplateLine(text).replace(/\s+/g, "");
  return /^[-－—]?备注[【\[]?.*?(?:发|点|:|：)/.test(compact)
    || isFeaturedTimingNoteLine(compact)
    || isFeaturedOperationReminderLine(compact)
    || isFeaturedAssetLabelLine(compact);
}

export function isFeaturedAssetLabelLine(text) {
  const compact = normalizeTemplateLine(text).replace(/\s+/g, "");
  if (!compact || compact.length > 16) return false;
  return /^[A-ZＡ-Ｚ一二两三四五六七八九十甲乙丙丁]组(?:[A-ZＡ-Ｚ]{0,3}[0-9０-９]{2,8})?$/.test(compact);
}

export function isFeaturedTimingNoteLine(text) {
  const compact = normalizeTemplateLine(text).replace(/\s+/g, "");
  if (!compact || compact.length > 32) return false;
  if (!compact.includes("定时")) return false;
  const hasDirection = /(下面|以下|底下|后面|后续|接下来|往下|下面门)/.test(compact);
  const hasTimeOrAction = /(明早|明晚|早上|上午|中午|下午|晚上|今晚|慢慢发|慢慢出|慢慢提|慢慢|提起|发)/.test(compact);
  return hasDirection && hasTimeOrAction;
}

export function isFeaturedOperationReminderLine(text) {
  const raw = normalizeTemplateLine(text).replace(/\s+/g, "");
  const compact = normalizeFeaturedRhythmKeyword(raw);
  if (!compact || compact.length > 24) return false;
  const hasReminderPrefix = /^[▲△▶▷●○•·]/.test(raw);
  const hasOperationWord = /(?:群发|朋友圈|发圈|同步发朋友圈)/.test(compact);
  const hasTimingWord = /(?:\d{1,2}(?:点|[:：]\d{1,2})?|早上|上午|中午|下午|晚上|晚间|明早|明晚)/.test(compact);
  return hasOperationWord && (hasReminderPrefix || hasTimingWord || compact === "同步发朋友圈");
}

export function isFeaturedDayTitle(text) {
  const compact = normalizeTemplateLine(text).replace(/\s+/g, "");
  return /^第(?:\d+|[一二两三四五六七八九十]+)天(?:节奏|节奏表|安排)?$/.test(compact);
}

export function isFeaturedDoumaMarker(text) {
  return isStableDoumaMarker(text);
}

export function isFeaturedSmallDash(text) {
  return /^[-－—]$/.test(normalizeTemplateLine(text));
}

export function isFeaturedStructureOnlyLine(text) {
  return Boolean(
    isFeaturedDoumaMarker(text) ||
    parseFeaturedTuoMarker(text) ||
    isFeaturedRemarkLine(text) ||
    isFeaturedSamePersonInstruction(text) ||
    isFeaturedContinueInstruction(text) ||
    hasTemplateContinueHint(text)
  );
}

export function isFeaturedDayAnchor(keyword) {
  return /^第(?:\d+|[一二两三四五六七八九十]+)天(?:节奏|节奏表|安排)?$/.test(String(keyword || "").trim());
}

export function isLikelyFeaturedRhythmKeyword(keyword) {
  const compact = normalizeFeaturedRhythmKeyword(keyword);
  if (!compact || compact.length > 32) return false;
  if (isFeaturedOperationReminderLine(compact)) return false;
  return /^(?:(?:早上|上午|中午|下午|晚上|晚间|早间|午间|凌晨)?(?:\d{1,2}(?:点|[:：]\d{1,2})?)?(?:日常|小)?(?:晒图|预热|预告|反馈|返场|开团|开抢|催单|福利|科普|早餐|晚安|早安|互动|开始正文|上链接|发链接|开链接)(?:互动|预告|提醒|定时)?|预告|秒杀|开秒|开售|正式秒杀|正式开抢)$/.test(compact);
}

export function normalizeFeaturedRhythmKeyword(keyword) {
  return normalizeTemplateLine(keyword)
    .replace(/\s+/g, "")
    .replace(/^[▲△▶▷●○•·\-－—]+/, "");
}

function parseFeaturedTuoNumber(raw) {
  const text = String(raw || "").trim();
  if (!text) return null;
  const normalizedDigits = text.replace(/[０-９]/g, (char) => String(char.charCodeAt(0) - 0xff10));
  if (/^\d+$/.test(normalizedDigits)) {
    const value = Number(normalizedDigits);
    return Number.isFinite(value) && value > 0 ? value : null;
  }
  return parseSmallChineseNumber(normalizedDigits);
}

function parseSmallChineseNumber(text) {
  const digits = {
    一: 1,
    二: 2,
    两: 2,
    三: 3,
    四: 4,
    五: 5,
    六: 6,
    七: 7,
    八: 8,
    九: 9
  };
  if (digits[text]) return digits[text];
  if (text === "十") return 10;
  const teen = text.match(/^十([一二两三四五六七八九])$/);
  if (teen) return 10 + digits[teen[1]];
  const tens = text.match(/^([一二两三四五六七八九])十([一二两三四五六七八九])?$/);
  if (tens) return digits[tens[1]] * 10 + (digits[tens[2]] || 0);
  return null;
}

function isBracketedFeaturedMarkerNote(text) {
  const line = normalizeTemplateLine(text).replace(/\s+/g, "");
  if (!line || line.length > 40) return false;
  return /^[【\[].+[】\]]$/.test(line) || /^[（(].+[）)]$/.test(line);
}

function unwrapFeaturedMarkerNote(text) {
  return normalizeTemplateLine(text).replace(/^[（(【\[]/, "").replace(/[）)】\]]$/, "").trim();
}

function hasTemplateContinueHint(text) {
  return markerHasContinueSpeakerHint(text);
}

function normalizeTemplateLine(text) {
  return String(text || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .trim();
}

function compactTemplateLine(text) {
  return normalizeTemplateLine(text).replace(/\s+/g, "");
}

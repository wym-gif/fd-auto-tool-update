function fallbackSplitRangeKeywords(value) {
  return String(value || "")
    .split(/[+＋]/g)
    .map((part) => part.trim())
    .filter(Boolean);
}

export function createFeishuPageLocator(deps = {}) {
  const {
    checkPreviewRestartSignal = () => {},
    printProgressStep = () => {},
    splitRangeKeywords = fallbackSplitRangeKeywords,
    parseFeaturedPipeRangeKeyword = () => null
  } = deps;

  async function jumpToReadRangeStart(page, config = {}, options = {}) {
    checkPreviewRestartSignal(config);
    const rawStart = String(config.readRange?.start || "").trim();
    const pipeRange = parseFeaturedPipeRangeKeyword(rawStart, config);
    const startKeywords = pipeRange ? [pipeRange.keyword] : splitRangeKeywords(rawStart);
    const keyword = startKeywords[0] || "";
    if (!keyword) return false;
    const label = startKeywords.length > 1 ? `${startKeywords.join(" → ")}` : keyword;
    if (options.showProgress) printProgressStep(`正在定位开始位置：${label.slice(0, 40)}`);
    if (pipeRange) {
      console.log(`精推范围：${pipeRange.title} 只作为文档标题确认，正文定位关键词为：${pipeRange.keyword}`);
    }
  
    await page.bringToFront().catch(() => {});
    checkPreviewRestartSignal(config);
    if (startKeywords.length > 1) {
      const clickedSequence = await jumpToReadRangeStartSequence(page, startKeywords, config, options);
      checkPreviewRestartSignal(config);
      if (clickedSequence) {
        console.log(`已通过两段范围定位到开始位置：${label}`);
        return true;
      }
      console.log(`没有在 ${startKeywords[0]} 下方找到后续关键词：${startKeywords.slice(1).join(" → ")}`);
      return false;
    }
  
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      checkPreviewRestartSignal(config);
      try {
        await prepareFeishuDocumentForFind(page, attempt, config);
        checkPreviewRestartSignal(config);
        const filledFindBox = await openFeishuFindBox(page, keyword, config);
        checkPreviewRestartSignal(config);
        if (!filledFindBox) {
          console.log("没有打开飞书查找框，已停止定位，避免误改标题或正文。");
          await page.keyboard.press("Escape").catch(() => {});
          return false;
        }
        await page.waitForTimeout(900);
        checkPreviewRestartSignal(config);
        await page.keyboard.press("Enter").catch(() => {});
        await page.waitForTimeout(1800);
        checkPreviewRestartSignal(config);
        const found = await isRangeStartVisibleOrSearchHit(page, keyword);
        await page.keyboard.press("Escape").catch(() => {});
        await page.waitForTimeout(700);
        checkPreviewRestartSignal(config);
        if (found) {
          if (startKeywords.length > 1) {
            const anchorPoint = await findVisibleKeywordPoint(page, keyword);
            const clickedRest = await clickVisibleKeywordSequence(page, startKeywords.slice(1), {
              config,
              minY: anchorPoint ? anchorPoint.y + 4 : -Infinity
            });
            checkPreviewRestartSignal(config);
            if (!clickedRest) {
              console.log(`已定位到 ${keyword}，但没有在附近点到后续关键词：${startKeywords.slice(1).join(" → ")}`);
              return false;
            }
          }
          console.log("已定位到开始位置，将从附近开始读取。");
          return true;
        }
        console.log(`没有搜到开始关键词，继续加载正文后重试（${attempt}/3）：${keyword}`);
      } catch {
        await page.keyboard.press("Escape").catch(() => {});
      }
    }
  
    console.log("没有直接定位到开始位置，已停止读取。");
    return false;
  }
  
  async function jumpToReadRangeStartSequence(page, keywords, config = {}, options = {}) {
    const anchorKeyword = keywords[0];
    if (!anchorKeyword || keywords.length <= 1) return false;
    if (options.showProgress) printProgressStep(`正在两段定位：先找 ${anchorKeyword}，再找 ${keywords.slice(1).join(" → ")}`);
    const boundaryMode = isFeaturedDayAnchor(anchorKeyword) ? "featured-day" : "date";
  
    if (boundaryMode === "featured-day") {
      const anchorLocated = await locateFeaturedDayBySearch(page, anchorKeyword, config);
      checkPreviewRestartSignal(config);
      if (!anchorLocated) return false;
      console.log(`已定位 ${anchorKeyword}，先在左侧导航栏查找：${keywords.slice(1).join(" → ")}`);
      return findFeaturedKeywordSequenceFromSidebarOrBody(page, anchorKeyword, keywords.slice(1), config, options);
    }
  
    const anchorLocated = await locateRangeAnchorInMainDocument(page, anchorKeyword, config);
    checkPreviewRestartSignal(config);
    if (!anchorLocated) return false;
    console.log(`已定位 ${anchorKeyword}，只在它下方、本日期段内查找：${keywords.slice(1).join(" → ")}`);
  
    let anchorPoint = await findVisibleKeywordPoint(page, anchorKeyword, {
      avoidOutline: true,
      preferMainDoc: true
    });
    if (!anchorPoint) return false;
  
    for (const keyword of keywords.slice(1)) {
      checkPreviewRestartSignal(config);
      if (options.showProgress) printProgressStep(`已定位 ${anchorKeyword}，正在下方查找 ${keyword}`);
      const point = await findKeywordBelowAnchorBeforeNextDate(page, keyword, anchorPoint.y, config, { boundaryMode });
      if (!point) return false;
      console.log(`已在当前${boundaryMode === "featured-day" ? "天节奏段" : "日期段"}下方找到：${keyword}`);
      await page.mouse.move(point.x, point.y).catch(() => {});
      await page.waitForTimeout(120);
      checkPreviewRestartSignal(config);
      await page.mouse.click(point.x, point.y).catch(() => {});
      await page.waitForTimeout(650);
      anchorPoint = point;
    }
    return true;
  }
  
  function isFeaturedDayAnchor(keyword) {
    return /^第(?:\d+|[一二两三四五六七八九十]+)天(?:节奏|节奏表|安排)?$/.test(String(keyword || "").trim());
  }
  
  async function locateRangeAnchorByTextSearch(page, keyword, config = {}) {
    const visible = await scanFeaturedTextFlow(page, keyword, "", false);
    if (visible.anchorSeen) return true;
  
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      checkPreviewRestartSignal(config);
      await prepareFeishuDocumentForFind(page, attempt, config);
      checkPreviewRestartSignal(config);
      const filledFindBox = await openFeishuFindBox(page, keyword, config);
      checkPreviewRestartSignal(config);
      if (!filledFindBox) return false;
      await page.waitForTimeout(900);
      checkPreviewRestartSignal(config);
      await page.keyboard.press("Enter").catch(() => {});
      await page.waitForTimeout(1800);
      checkPreviewRestartSignal(config);
      const found = await isRangeStartVisibleOrSearchHit(page, keyword);
      await page.keyboard.press("Escape").catch(() => {});
      await page.waitForTimeout(700);
      checkPreviewRestartSignal(config);
      if (found) return true;
    }
    return false;
  }
  
  async function locateFeaturedDayBySearch(page, keyword, config = {}) {
    const visible = await scanFeaturedTextFlow(page, keyword, "", false);
    if (visible.anchorSeen) return true;
  
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      checkPreviewRestartSignal(config);
      await prepareFeishuDocumentForFind(page, attempt, config, { skipScroll: true });
      checkPreviewRestartSignal(config);
      const filledFindBox = await openFeishuFindBox(page, keyword, config);
      checkPreviewRestartSignal(config);
      if (!filledFindBox) return false;
      await page.waitForTimeout(900);
      checkPreviewRestartSignal(config);
      await page.keyboard.press("Enter").catch(() => {});
      await page.waitForTimeout(1800);
      checkPreviewRestartSignal(config);
      const found = await isRangeStartVisibleOrSearchHit(page, keyword);
      await page.keyboard.press("Escape").catch(() => {});
      await page.waitForTimeout(700);
      checkPreviewRestartSignal(config);
      if (found) return true;
    }
    return false;
  }
  
  async function locateKeywordPointInMainDocument(page, keyword, config = {}, options = {}) {
    let point = await findVisibleKeywordPoint(page, keyword, {
      avoidOutline: true,
      preferMainDoc: true
    });
    if (point) {
      await page.mouse.move(point.x, point.y).catch(() => {});
      await page.waitForTimeout(120);
      checkPreviewRestartSignal(config);
      await page.mouse.click(point.x, point.y).catch(() => {});
      await page.waitForTimeout(650);
      return point;
    }
  
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      checkPreviewRestartSignal(config);
      await prepareFeishuDocumentForFind(page, attempt, config, {
        skipScroll: options.skipPrepareScroll === true
      });
      checkPreviewRestartSignal(config);
      const filledFindBox = await openFeishuFindBox(page, keyword, config);
      checkPreviewRestartSignal(config);
      if (!filledFindBox) return null;
      await page.waitForTimeout(900);
      checkPreviewRestartSignal(config);
      await page.keyboard.press("Enter").catch(() => {});
      await page.waitForTimeout(1800);
      checkPreviewRestartSignal(config);
      await page.keyboard.press("Escape").catch(() => {});
      await page.waitForTimeout(700);
      checkPreviewRestartSignal(config);
      point = await findVisibleKeywordPoint(page, keyword, {
        avoidOutline: true,
        preferMainDoc: true
      });
      if (!point) continue;
      await page.mouse.move(point.x, point.y).catch(() => {});
      await page.waitForTimeout(120);
      checkPreviewRestartSignal(config);
      await page.mouse.click(point.x, point.y).catch(() => {});
      await page.waitForTimeout(650);
      return point;
    }
    return null;
  }
  
  async function findFeaturedKeywordSequenceFromSidebarOrBody(page, anchorKeyword, keywords, config = {}, options = {}) {
    let fallbackAnchorPoint = null;
    for (let index = 0; index < keywords.length; index += 1) {
      const keyword = keywords[index];
      checkPreviewRestartSignal(config);
      if (options.showProgress) printProgressStep(`已定位 ${anchorKeyword}，正在左侧导航查找 ${keyword}`);
      const sidebarPoint = await clickFeaturedRhythmInSidebar(page, anchorKeyword, keyword, config);
      if (sidebarPoint) {
        console.log(`已在左侧导航 ${anchorKeyword} 下找到并进入：${keyword}`);
        continue;
      }
  
      console.log(`左侧导航没有在 ${anchorKeyword} 下找到 ${keyword}，改用正文慢扫。`);
      if (!fallbackAnchorPoint) {
        fallbackAnchorPoint = await findVisibleKeywordPoint(page, anchorKeyword, {
          avoidOutline: true,
          preferMainDoc: true
        });
      }
      if (!fallbackAnchorPoint) return false;
      const point = await findKeywordBelowAnchorBeforeNextDate(page, keyword, fallbackAnchorPoint.y, config, {
        boundaryMode: "featured-day",
        anchorX: fallbackAnchorPoint.x,
        anchorKeyword
      });
      if (!point) return false;
      console.log(`已在当前天节奏段正文下方找到：${keyword}`);
      await page.mouse.move(point.x, point.y).catch(() => {});
      await page.waitForTimeout(120);
      checkPreviewRestartSignal(config);
      await page.mouse.click(point.x, point.y).catch(() => {});
      await page.waitForTimeout(650);
      fallbackAnchorPoint = point;
    }
    return true;
  }
  
  async function findFeaturedKeywordSequenceBelowAnchor(page, anchorKeyword, anchorPoint, keywords, config = {}, options = {}) {
    let currentAnchor = anchorKeyword;
    let minY = Number.isFinite(Number(anchorPoint?.y)) ? Number(anchorPoint.y) + 4 : 0;
    const anchorX = Number.isFinite(Number(anchorPoint?.x)) ? Number(anchorPoint.x) : null;
    for (let index = 0; index < keywords.length; index += 1) {
      const keyword = keywords[index];
      checkPreviewRestartSignal(config);
      if (options.showProgress) printProgressStep(`已定位 ${currentAnchor}，正在本天节奏段下方查找 ${keyword}`);
      if (index === 0) {
        const sidebarPoint = await clickFeaturedRhythmInSidebar(page, anchorKeyword, keyword, config);
        if (sidebarPoint) {
          console.log(`已在左侧导航 ${anchorKeyword} 下找到并进入：${keyword}`);
          currentAnchor = keyword;
          minY = Number(sidebarPoint.y) + 4;
          continue;
        }
        console.log(`左侧导航没有在 ${anchorKeyword} 下找到 ${keyword}，改用正文慢扫。`);
      }
      const point = await findKeywordBelowAnchorBeforeNextDate(page, keyword, minY, config, {
        boundaryMode: "featured-day",
        anchorX,
        anchorKeyword
      });
      if (!point) return false;
      console.log(`已在当前天节奏段下方找到：${keyword}`);
      await page.mouse.move(point.x, point.y).catch(() => {});
      await page.waitForTimeout(120);
      checkPreviewRestartSignal(config);
      await page.mouse.click(point.x, point.y).catch(() => {});
      await page.waitForTimeout(650);
      currentAnchor = keyword;
      minY = Number(point.y) + 4;
    }
    return true;
  }
  
  async function clickFeaturedRhythmInSidebar(page, dayKeyword, rhythmKeyword, config = {}) {
    const scan = async () => page.evaluate(({ dayKeyword, rhythmKeyword }) => {
      const normalize = (text) => String(text || "")
        .replace(/\u200b/g, "")
        .replace(/\u00a0/g, " ")
        .replace(/[：]/g, ":")
        .replace(/\s+/g, "");
      const day = normalize(dayKeyword);
      const rhythm = normalize(rhythmKeyword);
      const dayTitleRe = /^第(?:\d+|[一二两三四五六七八九十]+)天(?:节奏|节奏表|安排)?$/;
      const isVisibleRect = (rect, parent) => {
        if (!rect || rect.width <= 0 || rect.height <= 0) return false;
        if (rect.bottom < 0 || rect.top > window.innerHeight) return false;
        if (rect.right < 0 || rect.left > window.innerWidth) return false;
        const style = parent ? getComputedStyle(parent) : null;
        return !style || (style.visibility !== "hidden" && style.display !== "none");
      };
      const isBadParent = (el) => {
        if (!el?.closest) return true;
        if (el.closest("input,textarea,select,[role='dialog'],[class*='find'],[class*='search'],[class*='modal'],[class*='popover']")) return true;
        return false;
      };
      const sidebarRight = Math.max(360, window.innerWidth * 0.34);
      const items = [];
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const node = walker.currentNode;
        const text = String(node.nodeValue || "").trim();
        if (!text || text.length > 80) continue;
        const compact = normalize(text);
        if (!compact) continue;
        const parent = node.parentElement;
        if (!parent || isBadParent(parent)) continue;
        const range = document.createRange();
        range.selectNodeContents(node);
        const rect = range.getBoundingClientRect();
        range.detach();
        if (!isVisibleRect(rect, parent) || rect.left > sidebarRight) continue;
        items.push({
          compact,
          text,
          y: rect.top,
          point: {
            x: Math.min(rect.right - 2, Math.max(rect.left + 2, rect.left + rect.width * 0.5)),
            y: Math.min(rect.bottom - 2, Math.max(rect.top + 2, rect.top + rect.height * 0.5))
          }
        });
      }
      items.sort((a, b) => a.y - b.y);
      let inDay = false;
      for (const item of items) {
        const isDay = day && (item.compact === day || item.compact.includes(day) || day.includes(item.compact));
        if (!inDay && isDay) {
          inDay = true;
          continue;
        }
        if (!inDay) continue;
        if (dayTitleRe.test(item.compact)) break;
        const exact = item.compact === rhythm;
        const contains = item.compact.includes(rhythm) || rhythm.includes(item.compact);
        if (exact || contains) {
          return {
            point: item.point,
            seenInDay: items.filter((entry) => entry.y > item.y - 1000).map((entry) => entry.text).slice(0, 40),
            items: items.map((entry) => ({ compact: entry.compact, text: entry.text, point: entry.point }))
          };
        }
      }
      const seenInDay = [];
      let currentDay = "";
      for (const item of items) {
        if (dayTitleRe.test(item.compact)) {
          currentDay = item.compact;
          continue;
        }
        if (currentDay === day) seenInDay.push(item.text);
      }
      return {
        point: null,
        seenInDay,
        items: items.map((entry) => ({ compact: entry.compact, text: entry.text, point: entry.point }))
      };
    }, { dayKeyword, rhythmKeyword }).catch(() => null);
  
    const resetSidebar = async () => page.evaluate(() => {
      const seen = new Set();
      const sidebarRight = Math.max(360, window.innerWidth * 0.34);
      const scrollers = [document.scrollingElement, document.documentElement, document.body, ...document.querySelectorAll("*")]
        .filter(Boolean)
        .filter((el) => {
          if (seen.has(el)) return false;
          seen.add(el);
          if (el.scrollHeight <= el.clientHeight + 20) return false;
          if (el === document.scrollingElement || el === document.documentElement || el === document.body) return false;
          const rect = el.getBoundingClientRect();
          return rect.width > 60 && rect.height > 80 && rect.left < sidebarRight + 80 && rect.width < Math.max(560, window.innerWidth * 0.46);
        });
      for (const el of scrollers) el.scrollTop = 0;
      return scrollers.length;
    }).catch(() => 0);
  
    const scrollSidebar = async () => page.evaluate(() => {
      const seen = new Set();
      const sidebarRight = Math.max(360, window.innerWidth * 0.34);
      const scrollers = [document.scrollingElement, document.documentElement, document.body, ...document.querySelectorAll("*")]
        .filter(Boolean)
        .filter((el) => {
          if (seen.has(el)) return false;
          seen.add(el);
          if (el.scrollHeight <= el.clientHeight + 20) return false;
          if (el === document.scrollingElement || el === document.documentElement || el === document.body) return false;
          const rect = el.getBoundingClientRect();
          return rect.width > 60 && rect.height > 80 && rect.left < sidebarRight + 80 && rect.width < Math.max(560, window.innerWidth * 0.46);
        });
      let changed = false;
      for (const el of scrollers) {
        const before = el.scrollTop || 0;
        el.scrollTop = Math.min(el.scrollHeight, before + Math.max(120, Math.floor(el.clientHeight * 0.45)));
        if (Math.abs((el.scrollTop || 0) - before) > 2) changed = true;
      }
      return changed;
    }).catch(() => false);
  
    const seenInDay = new Set();
    const normalizeSidebarText = (text) => String(text || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/[：]/g, ":")
      .replace(/\s+/g, "");
    const day = normalizeSidebarText(dayKeyword);
    const rhythm = normalizeSidebarText(rhythmKeyword);
    const dayTitleRe = /^第(?:\d+|[一二两三四五六七八九十]+)天(?:节奏|节奏表|安排)?$/;
    let insideTargetDay = false;
    const rememberSeen = (result) => {
      for (const text of result?.seenInDay || []) {
        const normalized = String(text || "").trim();
        if (normalized) seenInDay.add(normalized);
      }
    };
    const findPointWithScrollMemory = (result) => {
      for (const item of result?.items || []) {
        const compact = normalizeSidebarText(item.compact || item.text);
        if (!compact) continue;
        if (dayTitleRe.test(compact)) {
          insideTargetDay = day && (compact === day || compact.includes(day) || day.includes(compact));
          continue;
        }
        if (!insideTargetDay) continue;
        seenInDay.add(item.text);
        const exact = compact === rhythm;
        const contains = compact.includes(rhythm) || rhythm.includes(compact);
        if (exact || contains) return item.point;
      }
      return null;
    };
    let result = await scan();
    rememberSeen(result);
    let point = result?.point || findPointWithScrollMemory(result);
    if (!point) {
      await resetSidebar();
      await page.waitForTimeout(250).catch(() => {});
      insideTargetDay = false;
    }
    for (let step = 0; step < 50; step += 1) {
      checkPreviewRestartSignal(config);
      result = await scan();
      rememberSeen(result);
      point = result?.point || findPointWithScrollMemory(result);
      if (point) break;
      const moved = await scrollSidebar();
      if (!moved) {
        if (seenInDay.size) {
          console.log(`${dayKeyword} 下左侧导航已看到：${Array.from(seenInDay).slice(0, 18).join(" / ")}`);
        }
        return null;
      }
      await page.waitForTimeout(180).catch(() => {});
    }
    if (!point) {
      if (seenInDay.size) {
        console.log(`${dayKeyword} 下左侧导航已看到：${Array.from(seenInDay).slice(0, 18).join(" / ")}`);
      }
      return null;
    }
    await page.mouse.move(point.x, point.y).catch(() => {});
    await page.waitForTimeout(120).catch(() => {});
    checkPreviewRestartSignal(config);
    await page.mouse.click(point.x, point.y).catch(() => {});
    await page.waitForTimeout(1200).catch(() => {});
    checkPreviewRestartSignal(config);
    return await findVisibleKeywordPoint(page, rhythmKeyword, {
      avoidOutline: true,
      preferMainDoc: true
    }) || point;
  }
  
  async function findFeaturedKeywordSequenceByTextFlow(page, anchorKeyword, keywords, config = {}, options = {}) {
    let currentAnchor = anchorKeyword;
    for (const keyword of keywords) {
      checkPreviewRestartSignal(config);
      if (options.showProgress) printProgressStep(`已定位 ${currentAnchor}，正在文字流下方查找 ${keyword}`);
      const point = await findFeaturedKeywordAfterAnchorByTextFlow(page, currentAnchor, keyword, config);
      if (!point) return false;
      console.log(`已在当前天节奏段下方找到：${keyword}`);
      await page.mouse.move(point.x, point.y).catch(() => {});
      await page.waitForTimeout(120);
      checkPreviewRestartSignal(config);
      await page.mouse.click(point.x, point.y).catch(() => {});
      await page.waitForTimeout(650);
      currentAnchor = keyword;
    }
    return true;
  }
  
  async function findFeaturedKeywordAfterAnchorByTextFlow(page, anchorKeyword, keyword, config = {}) {
    const maxSteps = Number(config.feishuRangeBoundedSearchSteps ?? 24);
    const scrollDistance = Number(config.feishuRangeBoundedScrollDistance ?? 650);
    let anchorSeen = true;
  
    for (let step = 0; step < maxSteps; step += 1) {
      checkPreviewRestartSignal(config);
      const result = await scanFeaturedTextFlow(page, anchorKeyword, keyword, anchorSeen);
      if (result.anchorSeen) anchorSeen = true;
      if (result.point) return result.point;
      if (result.blockedByNextDay) {
        console.log(`已到下一个天节奏标题 ${result.nextDayText || ""}，仍未找到 ${keyword}，停止向下查找。`);
        return null;
      }
      const moved = await scrollFeishuDocumentDown(page, scrollDistance);
      if (!moved) return null;
      await page.waitForTimeout(450);
    }
    return null;
  }
  
  async function scanFeaturedTextFlow(page, anchorKeyword, keyword, anchorAlreadySeen = false) {
    return page.evaluate(({ anchorKeyword, keyword, anchorAlreadySeen }) => {
      const normalize = (text) => String(text || "")
        .replace(/\u200b/g, "")
        .replace(/\u00a0/g, " ")
        .replace(/[：]/g, ":")
        .replace(/\s+/g, "");
      const anchor = normalize(anchorKeyword);
      const target = normalize(keyword);
      const dayTitleRe = /^第(?:\d+|[一二两三四五六七八九十]+)天(?:节奏|节奏表|安排)?$/;
      const isVisibleRect = (rect, parent) => {
        if (!rect || rect.width <= 0 || rect.height <= 0) return false;
        if (rect.bottom < 0 || rect.top > window.innerHeight) return false;
        if (rect.right < 0 || rect.left > window.innerWidth) return false;
        const style = parent ? getComputedStyle(parent) : null;
        return !style || (style.visibility !== "hidden" && style.display !== "none");
      };
      const isBadParent = (el) => {
        if (!el?.closest) return true;
        if (el.closest("input,textarea,select,[role='dialog'],[class*='find'],[class*='search'],[class*='modal'],[class*='popover'],[role='navigation'],[class*='sidebar'],[class*='catalog'],[class*='outline']")) return true;
        return false;
      };
      const items = [];
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const node = walker.currentNode;
        const text = String(node.nodeValue || "").trim();
        if (!text || text.length > 140) continue;
        const compact = normalize(text);
        if (!compact) continue;
        const parent = node.parentElement;
        if (!parent || isBadParent(parent)) continue;
        const range = document.createRange();
        range.selectNodeContents(node);
        const rect = range.getBoundingClientRect();
        range.detach();
        if (!isVisibleRect(rect, parent)) continue;
        items.push({
          compact,
          text,
          point: {
            x: Math.min(rect.right - 2, Math.max(rect.left + 2, rect.left + rect.width * 0.5)),
            y: Math.min(rect.bottom - 2, Math.max(rect.top + 2, rect.top + rect.height * 0.5))
          }
        });
      }
  
      let anchorSeen = Boolean(anchorAlreadySeen);
      for (const item of items) {
        const isAnchor = anchor && (item.compact === anchor || item.compact.includes(anchor) || anchor.includes(item.compact));
        if (!anchorSeen && isAnchor) {
          anchorSeen = true;
          continue;
        }
        if (!anchorSeen) continue;
        if (isAnchor) continue;
        if (dayTitleRe.test(item.compact)) {
          return { anchorSeen, point: null, blockedByNextDay: true, nextDayText: item.text };
        }
        if (!target) continue;
        const exact = item.compact === target;
        const contains = item.compact.includes(target) || target.includes(item.compact);
        if (exact || contains) {
          return { anchorSeen, point: item.point, blockedByNextDay: false, nextDayText: "" };
        }
      }
      return { anchorSeen, point: null, blockedByNextDay: false, nextDayText: "" };
    }, { anchorKeyword, keyword, anchorAlreadySeen }).catch(() => ({
      anchorSeen: Boolean(anchorAlreadySeen),
      point: null,
      blockedByNextDay: false,
      nextDayText: ""
    }));
  }
  
  async function locateRangeAnchorInMainDocument(page, keyword, config = {}) {
    const visiblePoint = await findVisibleKeywordPoint(page, keyword, {
      avoidOutline: true,
      preferMainDoc: true
    });
    if (visiblePoint) {
      await page.mouse.move(visiblePoint.x, visiblePoint.y).catch(() => {});
      await page.waitForTimeout(120);
      await page.mouse.click(visiblePoint.x, visiblePoint.y).catch(() => {});
      await page.waitForTimeout(650);
      return true;
    }
  
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      checkPreviewRestartSignal(config);
      await prepareFeishuDocumentForFind(page, attempt, config);
      checkPreviewRestartSignal(config);
      const filledFindBox = await openFeishuFindBox(page, keyword, config);
      checkPreviewRestartSignal(config);
      if (!filledFindBox) return false;
      await page.waitForTimeout(900);
      checkPreviewRestartSignal(config);
      await page.keyboard.press("Enter").catch(() => {});
      await page.waitForTimeout(1800);
      checkPreviewRestartSignal(config);
      const found = await isRangeStartVisibleOrSearchHit(page, keyword);
      await page.keyboard.press("Escape").catch(() => {});
      await page.waitForTimeout(700);
      checkPreviewRestartSignal(config);
      if (!found) continue;
      const point = await findVisibleKeywordPoint(page, keyword, {
        avoidOutline: true,
        preferMainDoc: true
      });
      if (point) return true;
    }
    return false;
  }
  
  async function findKeywordBelowAnchorBeforeNextDate(page, keyword, anchorY, config = {}, options = {}) {
    let minY = Number.isFinite(Number(anchorY)) ? Number(anchorY) + 4 : 0;
    const boundaryMode = options.boundaryMode || "date";
    const isFeatured = boundaryMode === "featured-day";
    const maxSteps = Number(config.feishuRangeBoundedSearchSteps ?? (isFeatured ? 36 : 24));
    const scrollDistance = Number(config.feishuRangeBoundedScrollDistance ?? (isFeatured ? 280 : 650));
    if (isFeatured) {
      await page.waitForTimeout(650).catch(() => {});
    }
  
    for (let step = 0; step < maxSteps; step += 1) {
      checkPreviewRestartSignal(config);
      const result = await findMainDocKeywordBetweenAnchorAndNextDate(page, keyword, minY, {
        boundaryMode,
        anchorX: options.anchorX,
        anchorKeyword: options.anchorKeyword
      });
      if (result.point) return result.point;
      if (result.blockedByNextDate) {
        console.log(`已到下一个${boundaryMode === "featured-day" ? "天节奏" : "日期"}标题 ${result.nextDateText || ""}，仍未找到 ${keyword}，停止向下查找。`);
        return null;
      }
      const moved = await scrollFeishuDocumentDown(page, scrollDistance, {
        boundaryMode,
        anchorX: options.anchorX
      });
      if (!moved) return null;
      await page.waitForTimeout(isFeatured ? 750 : 450);
      minY = 40;
    }
    return null;
  }
  
  async function findMainDocKeywordBetweenAnchorAndNextDate(page, keyword, minY, options = {}) {
    return page.evaluate(({ wanted, minY, boundaryMode, anchorX, anchorKeyword }) => {
      const normalize = (text) => String(text || "")
        .replace(/\u200b/g, "")
        .replace(/\u00a0/g, " ")
        .replace(/[：]/g, ":")
        .replace(/\s+/g, "");
      const target = normalize(wanted);
      const currentAnchor = normalize(anchorKeyword);
      const minTop = Number.isFinite(Number(minY)) ? Number(minY) : 0;
      const isVisibleRect = (rect, parent) => {
        if (!rect || rect.width <= 0 || rect.height <= 0) return false;
        if (rect.bottom < 0 || rect.top > window.innerHeight) return false;
        if (rect.right < 0 || rect.left > window.innerWidth) return false;
        const style = parent ? getComputedStyle(parent) : null;
        return !style || (style.visibility !== "hidden" && style.display !== "none");
      };
      const isBadParent = (el) => {
        if (!el?.closest) return true;
        if (el.closest("input,textarea,select,[role='dialog'],[class*='find'],[class*='search'],[class*='modal'],[class*='popover'],[role='navigation'],[class*='sidebar'],[class*='catalog'],[class*='outline']")) return true;
        return false;
      };
      const isMainDocRect = (rect) => {
        if (boundaryMode === "featured-day") {
          const anchor = Number.isFinite(Number(anchorX)) ? Number(anchorX) : Math.max(300, window.innerWidth * 0.28);
          const leftLimit = Math.max(180, anchor - 190);
          const rightLimit = Math.min(window.innerWidth - 20, anchor + Math.max(520, window.innerWidth * 0.45));
          return rect.left >= leftLimit && rect.left <= rightLimit;
        }
        const leftLimit = Math.max(280, window.innerWidth * 0.22);
        const rightLimit = window.innerWidth * 0.86;
        return rect.left >= leftLimit && rect.left <= rightLimit;
      };
      const candidates = [];
      const boundaries = [];
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const node = walker.currentNode;
        const text = String(node.nodeValue || "").trim();
        if (!text || text.length > 140) continue;
        const parent = node.parentElement;
        if (!parent || isBadParent(parent)) continue;
        const range = document.createRange();
        range.selectNodeContents(node);
        const rect = range.getBoundingClientRect();
        range.detach();
        if (!isVisibleRect(rect, parent) || !isMainDocRect(rect) || rect.top < minTop) continue;
        const compact = normalize(text);
        const isBoundary = boundaryMode === "featured-day"
          ? /^第(?:\d+|[一二两三四五六七八九十]+)天(?:节奏|节奏表|安排)?$/.test(compact)
          : /^\d{1,2}\/\d{1,2}$/.test(compact);
        if (isBoundary) {
          if (boundaryMode === "featured-day" && currentAnchor && compact === currentAnchor) continue;
          boundaries.push({ y: rect.top, text });
          continue;
        }
        if (!target) continue;
        const exact = compact === target;
        const contains = compact.includes(target) || target.includes(compact);
        if (!exact && !contains) continue;
        candidates.push({
          x: Math.min(rect.right - 2, Math.max(rect.left + 2, rect.left + rect.width * 0.5)),
          y: Math.min(rect.bottom - 2, Math.max(rect.top + 2, rect.top + rect.height * 0.5)),
          score: exact ? 300 : 120,
          text
        });
      }
      boundaries.sort((a, b) => a.y - b.y);
      const boundary = boundaries[0] || null;
      const boundedCandidates = boundary ? candidates.filter((item) => item.y < boundary.y) : candidates;
      boundedCandidates.sort((a, b) => b.score - a.score || a.y - b.y);
      return {
        point: boundedCandidates[0] || null,
        blockedByNextDate: Boolean(boundary && !boundedCandidates[0]),
        nextDateText: boundary?.text || ""
      };
    }, {
      wanted: keyword,
      minY,
      boundaryMode: options.boundaryMode || "date",
      anchorX: options.anchorX,
      anchorKeyword: options.anchorKeyword
    }).catch(() => ({ point: null, blockedByNextDate: false, nextDateText: "" }));
  }
  
  async function scrollFeishuDocumentDown(page, distance, options = {}) {
    const moved = await page.evaluate(({ distance, options }) => {
      const seen = new Set();
      const anchor = Number.isFinite(Number(options?.anchorX)) ? Number(options.anchorX) : Math.max(300, window.innerWidth * 0.28);
      const isFeatured = options?.boundaryMode === "featured-day";
      const scrollers = [document.scrollingElement, document.documentElement, document.body, ...document.querySelectorAll("*")]
        .filter(Boolean)
        .filter((el) => {
          if (seen.has(el)) return false;
          seen.add(el);
          if (el.scrollHeight <= el.clientHeight + 20) return false;
          if (!isFeatured || el === document.scrollingElement || el === document.documentElement || el === document.body) return true;
          const rect = el.getBoundingClientRect();
          if (rect.width <= 0 || rect.height <= 0) return false;
          if (rect.right < Math.max(180, anchor - 220)) return false;
          return true;
        });
      let changed = false;
      window.scrollBy(0, distance);
      for (const el of scrollers) {
        const before = el.scrollTop || 0;
        el.scrollTop = Math.min(el.scrollTop + distance, el.scrollHeight);
        if (Math.abs((el.scrollTop || 0) - before) > 2) changed = true;
      }
      return changed;
    }, { distance, options }).catch(() => false);
    if (!moved) {
      await page.mouse.wheel(0, distance).catch(() => {});
    }
    return true;
  }
  
  async function clickVisibleKeywordSequence(page, keywords, options = {}) {
    let minY = Number.isFinite(Number(options.minY)) ? Number(options.minY) : -Infinity;
    for (const keyword of keywords) {
      checkPreviewRestartSignal(options.config);
      const point = await findVisibleKeywordPoint(page, keyword, { minY });
      checkPreviewRestartSignal(options.config);
      if (!point) return false;
      await page.mouse.move(point.x, point.y).catch(() => {});
      await page.waitForTimeout(120);
      checkPreviewRestartSignal(options.config);
      await page.mouse.click(point.x, point.y).catch(() => {});
      minY = point.y + 4;
      await page.waitForTimeout(650);
    }
    return true;
  }
  
  async function clickVisibleKeyword(page, keyword) {
    const point = await findVisibleKeywordPoint(page, keyword);
  
    if (!point) return false;
    await page.mouse.move(point.x, point.y).catch(() => {});
    await page.waitForTimeout(120);
    await page.mouse.click(point.x, point.y).catch(() => {});
    return true;
  }
  
  async function findVisibleKeywordPoint(page, keyword, options = {}) {
    const points = await findVisibleKeywordPoints(page, keyword, options);
    const minY = Number.isFinite(Number(options.minY)) ? Number(options.minY) : -Infinity;
    return points.find((point) => point.y >= minY) || null;
  }
  
  async function findVisibleKeywordPoints(page, keyword, options = {}) {
    return page.evaluate(({ wanted, options }) => {
      const normalize = (text) => String(text || "")
        .replace(/\u200b/g, "")
        .replace(/\u00a0/g, " ")
        .replace(/[：]/g, ":")
        .replace(/\s+/g, "");
      const target = normalize(wanted);
      if (!target) return null;
      const isVisibleRect = (rect, parent) => {
        if (!rect || rect.width <= 0 || rect.height <= 0) return false;
        if (rect.bottom < 0 || rect.top > window.innerHeight) return false;
        if (rect.right < 0 || rect.left > window.innerWidth) return false;
        const style = parent ? getComputedStyle(parent) : null;
        return !style || (style.visibility !== "hidden" && style.display !== "none");
      };
      const isBadParent = (el) => {
        if (!el?.closest) return true;
        if (el.closest("input,textarea,select,[role='dialog'],[class*='find'],[class*='search'],[class*='modal'],[class*='popover']")) return true;
        return false;
      };
      const candidates = [];
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const node = walker.currentNode;
        const text = String(node.nodeValue || "").trim();
        if (!text || text.length > 120) continue;
        const compact = normalize(text);
        if (!compact) continue;
        const exact = compact === target;
        const contains = compact.includes(target) || target.includes(compact);
        if (!exact && !contains) continue;
        const parent = node.parentElement;
        if (!parent || isBadParent(parent)) continue;
        const range = document.createRange();
        range.selectNodeContents(node);
        const rect = range.getBoundingClientRect();
        range.detach();
        if (!isVisibleRect(rect, parent)) continue;
        const style = getComputedStyle(parent);
        const fontSize = Number.parseFloat(style.fontSize) || 0;
        const fontWeight = Number.parseInt(style.fontWeight, 10) || 400;
        const inOutline = rect.left < Math.max(280, window.innerWidth * 0.22);
        const inMainDoc = rect.left > Math.max(120, window.innerWidth * 0.12) && rect.left < window.innerWidth * 0.82;
        if (options?.avoidOutline && inOutline) continue;
        if (options?.preferMainDoc && !inMainDoc) continue;
        let score = exact ? 300 : 120;
        if (inOutline) score += 120;
        if (inMainDoc) score += 60;
        if (fontSize >= 16 || fontWeight >= 600) score += 20;
        if (rect.top > 50 && rect.top < window.innerHeight - 40) score += 20;
        candidates.push({
          x: Math.min(rect.right - 2, Math.max(rect.left + 2, rect.left + rect.width * 0.5)),
          y: Math.min(rect.bottom - 2, Math.max(rect.top + 2, rect.top + rect.height * 0.5)),
          score,
          text
        });
      }
      candidates.sort((a, b) => b.score - a.score || a.y - b.y);
      return candidates;
    }, { wanted: keyword, options }).catch(() => []);
  }
  
  async function prepareFeishuDocumentForFind(page, attempt = 1, config = {}, options = {}) {
    checkPreviewRestartSignal(config);
    await page.keyboard.press("Escape").catch(() => {});
    await page.waitForTimeout(180);
    checkPreviewRestartSignal(config);
    const scrollDistance = attempt === 1 ? 850 : attempt === 2 ? 1500 : 2200;
    if (options.skipScroll !== true) {
      await page.evaluate((distance) => {
        const seen = new Set();
        const scrollers = [document.scrollingElement, document.documentElement, document.body, ...document.querySelectorAll("*")]
          .filter(Boolean)
          .filter((el) => {
            if (seen.has(el)) return false;
            seen.add(el);
            return el.scrollHeight > el.clientHeight + 20;
          });
        window.scrollBy(0, distance);
        for (const el of scrollers) {
          el.scrollTop = Math.min(el.scrollTop + distance, el.scrollHeight);
        }
      }, scrollDistance).catch(() => {});
      await page.mouse.wheel(0, scrollDistance).catch(() => {});
      await page.waitForTimeout(650);
    } else {
      await page.waitForTimeout(250);
    }
    checkPreviewRestartSignal(config);
    const focused = await focusFeishuDocumentBody(page, attempt).catch(() => false);
    checkPreviewRestartSignal(config);
    if (!focused) {
      await clickFeishuDocumentSafeArea(page, attempt).catch(() => false);
    }
  }
  
  async function openFeishuFindBox(page, keyword, config = {}) {
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      checkPreviewRestartSignal(config);
      await page.keyboard.press("Escape").catch(() => {});
      await page.waitForTimeout(120);
      checkPreviewRestartSignal(config);
      const focused = await focusFeishuDocumentBody(page, attempt);
      checkPreviewRestartSignal(config);
      if (!focused) {
        console.log("没有识别到正文文字，改用安全位置打开飞书查找框。");
        await clickFeishuDocumentSafeArea(page, attempt).catch(() => false);
      }
      console.log(`已轻点正文区域，正在打开飞书查找框（第 ${attempt} 次）...`);
      await page.waitForTimeout(180);
      checkPreviewRestartSignal(config);
      await pressFindShortcut(page);
      await page.waitForTimeout(900);
      checkPreviewRestartSignal(config);
      if (await fillVisibleFindBox(page, keyword)) {
        console.log("已打开飞书查找框，正在搜索开始位置。");
        return true;
      }
      await page.keyboard.press("Escape").catch(() => {});
      await page.waitForTimeout(250);
    }
    return false;
  }
  
  async function clickFeishuDocumentSafeArea(page, attempt = 1) {
    const viewport = page.viewportSize?.() || { width: 1400, height: 900 };
    const width = viewport.width || 1400;
    const height = viewport.height || 900;
    const points = [
      { x: width * 0.30, y: height * 0.60 },
      { x: width * 0.38, y: height * 0.68 },
      { x: width * 0.45, y: height * 0.55 }
    ];
    const point = points[Math.min(points.length - 1, Math.max(0, attempt - 1))];
    await page.mouse.click(point.x, point.y).catch(() => {});
    return true;
  }
  
  async function pressFindShortcut(page) {
    const modifier = process.platform === "darwin" ? "Meta" : "Control";
    await page.keyboard.down(modifier).catch(() => {});
    await page.keyboard.press("KeyF").catch(() => {});
    await page.keyboard.up(modifier).catch(() => {});
  }
  
  async function focusFeishuDocumentBody(page, attempt = 1) {
    const point = await page.evaluate(() => {
      const isVisible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 &&
          rect.height > 0 &&
          rect.bottom >= 120 &&
          rect.top <= window.innerHeight - 80 &&
          style.visibility !== "hidden" &&
          style.display !== "none";
      };
  
      const isInDocumentArea = (el) => {
        if (!el || !el.closest) return false;
        if (el.closest("button,a,input,textarea,select,[role='button'],[role='tab'],[role='navigation'],[class*='toolbar'],[class*='menu'],[class*='sidebar'],[class*='header']")) return false;
        const rect = el.getBoundingClientRect();
        if (rect.right < 90 || rect.left > window.innerWidth - 90) return false;
        return true;
      };
  
      const textNodeCandidates = [];
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const node = walker.currentNode;
        const text = String(node.nodeValue || "").trim();
        if (!text || text.length < 2 || text.length > 120) continue;
        const parent = node.parentElement;
        if (!parent || !isVisible(parent) || !isInDocumentArea(parent)) continue;
        const range = document.createRange();
        range.selectNodeContents(node);
        const rect = range.getBoundingClientRect();
        range.detach();
        if (rect.width <= 0 || rect.height <= 0) continue;
        if (rect.bottom < 110 || rect.top > window.innerHeight - 80) continue;
        const style = getComputedStyle(parent);
        const fontSize = Number.parseFloat(style.fontSize) || 0;
        const fontWeight = Number.parseInt(style.fontWeight, 10) || 400;
        const looksLikeTitle = fontSize >= 24 || (fontSize >= 20 && fontWeight >= 600);
        let score = 80;
        if (!looksLikeTitle) score += 40;
        if (rect.top > 180) score += 30;
        if (rect.left > 100 && rect.left < window.innerWidth * 0.85) score += 20;
        if (/^\d{1,2}\s*\/\s*\d{1,2}$/.test(text.replace(/\s+/g, ""))) score -= 30;
        textNodeCandidates.push({
          x: Math.min(rect.right - 3, Math.max(rect.left + 3, rect.left + rect.width * 0.35)),
          y: Math.min(rect.bottom - 3, Math.max(rect.top + 3, rect.top + rect.height * 0.5)),
          score,
          source: "text"
        });
      }
      textNodeCandidates.sort((a, b) => b.score - a.score);
      if (textNodeCandidates[0]) return textNodeCandidates[0];
  
      const textOf = (el) => String(el.innerText || el.textContent || "").trim();
      const isBadTarget = (el) => {
        const text = textOf(el).replace(/\s+/g, "");
        if (!text) return true;
        if (/^(分享|编辑|评论|权限设置|最近修改|添加快捷方式|查找|替换|搜索)$/.test(text)) return true;
        if (!isInDocumentArea(el)) return true;
        return false;
      };
  
      const preferredSelectors = [
        ".ace-line",
        "[data-block-id]",
        "[class*='docx'] [contenteditable='true']",
        "[class*='docx'] h1",
        "[class*='docx'] h2",
        "[class*='docx'] h3",
        "[class*='docx'] p",
        "h1",
        "h2",
        "h3",
        "p"
      ];
  
      const elements = [];
      for (const selector of preferredSelectors) {
        for (const el of document.querySelectorAll(selector)) {
          if (!elements.includes(el)) elements.push(el);
        }
      }
  
      const candidates = elements
        .filter(isVisible)
        .filter((el) => !isBadTarget(el))
        .map((el) => {
          const rect = el.getBoundingClientRect();
          const text = textOf(el);
          const style = getComputedStyle(el);
          const fontSize = Number.parseFloat(style.fontSize) || 0;
          const fontWeight = Number.parseInt(style.fontWeight, 10) || 400;
          const looksLikeTitle = fontSize >= 24 || (fontSize >= 20 && fontWeight >= 600);
          let score = 20;
          if (el.matches(".ace-line,[data-block-id],p")) score += 60;
          if (el.matches("h1,h2,h3")) score += 35;
          if (looksLikeTitle) score += 10;
          if (rect.top > 120 && rect.top < window.innerHeight - 80) score += 20;
          if (rect.left > 90 && rect.left < window.innerWidth * 0.85) score += 12;
          if (text.length >= 2 && text.length <= 80) score += 8;
          return {
            x: Math.min(rect.right - 8, Math.max(rect.left + 8, rect.left + rect.width * 0.35)),
            y: Math.min(rect.bottom - 6, Math.max(rect.top + 6, rect.top + rect.height * 0.5)),
            score
          };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score);
      return candidates[0] || {
        x: Math.max(160, Math.min(window.innerWidth * 0.42, window.innerWidth - 160)),
        y: attempt === 1 ? Math.max(180, window.innerHeight * 0.32) : Math.max(120, window.innerHeight * 0.18),
        score: 1
      };
    }, attempt).catch(() => null);
  
    if (!point) return false;
    await page.mouse.click(point.x, point.y).catch(() => {});
    await page.waitForTimeout(120);
    await page.mouse.click(point.x, point.y).catch(() => {});
    return true;
  }
  
  async function fillVisibleFindBox(page, keyword) {
    const id = await page.evaluate(() => {
      const isVisible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 &&
          rect.height > 0 &&
          rect.bottom >= 0 &&
          rect.top <= window.innerHeight &&
          style.visibility !== "hidden" &&
          style.display !== "none";
      };
      const editables = Array.from(document.querySelectorAll("input, textarea"))
        .filter(isVisible)
        .map((el, index) => {
          const rect = el.getBoundingClientRect();
          const panel = el.closest("[role='dialog'],[class*='find'],[class*='search'],[class*='modal'],[class*='popover'],[class*='panel']") || el.parentElement;
          const text = [
            el.getAttribute("placeholder"),
            el.getAttribute("aria-label"),
            el.getAttribute("data-placeholder"),
            el.className,
            panel?.innerText,
            panel?.textContent
          ].filter(Boolean).join(" ");
          let score = 0;
          if (document.activeElement === el) score += 50;
          if (/在文档内查找/.test(String(el.getAttribute("placeholder") || ""))) score += 200;
          if (/在文档内查找/.test(text)) score += 160;
          if (/查找/.test(text) && /替换/.test(text)) score += 80;
          if (rect.top < 240) score += 20;
          if (rect.left < window.innerWidth * 0.65 && rect.top < window.innerHeight * 0.45) score += 8;
          return { el, index, score };
        })
        .sort((a, b) => b.score - a.score);
      const best = editables[0];
      if (!best || best.score < 180) return "";
      const marker = `fd-find-${Date.now()}-${best.index}`;
      best.el.setAttribute("data-fd-find-input", marker);
      return marker;
    }).catch(() => "");
  
    if (!id) return false;
    const locator = page.locator(`[data-fd-find-input="${id}"]`).first();
    await locator.click({ timeout: 1200 }).catch(() => {});
    await page.keyboard.press(process.platform === "darwin" ? "Meta+A" : "Control+A").catch(() => {});
    await page.keyboard.press("Backspace").catch(() => {});
    await page.waitForTimeout(80);
    await page.keyboard.insertText(keyword);
    await page.waitForTimeout(120);
    const valueOk = await locator.evaluate((el, wanted) => String(el.value || el.textContent || "").includes(wanted), keyword).catch(() => false);
    if (!valueOk) {
      await locator.fill(keyword).catch(() => {});
      await page.waitForTimeout(120);
    }
    return true;
  }
  
  async function isRangeStartVisibleOrSearchHit(page, keyword) {
    return page.evaluate((wanted) => {
      const normalize = (text) => String(text || "")
        .replace(/\u200b/g, "")
        .replace(/\u00a0/g, " ")
        .replace(/[：]/g, ":")
        .replace(/\s+/g, "");
      const isVisible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 &&
          rect.height > 0 &&
          rect.bottom >= -80 &&
          rect.top <= window.innerHeight + 80 &&
          style.visibility !== "hidden" &&
          style.display !== "none";
      };
      const target = normalize(wanted);
      if (!target) return false;
  
      const findPanels = Array.from(document.querySelectorAll("body *"))
        .filter(isVisible)
        .map((el) => {
          const text = String(el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
          const rect = el.getBoundingClientRect();
          return { text, rect };
        })
        .filter((item) =>
          item.text &&
          item.rect.top < window.innerHeight * 0.55 &&
          item.rect.left < window.innerWidth * 0.75 &&
          (/在文档内查找/.test(item.text) || (/查找/.test(item.text) && /替换/.test(item.text)))
        )
        .sort((a, b) => (a.rect.top - b.rect.top) || (a.rect.left - b.rect.left));
      const searchText = findPanels.map((item) => item.text).join(" ");
      if (/(?:^|\D)[1-9]\d*\s*\/\s*[1-9]\d*(?:\D|$)/.test(searchText)) return true;
      const noSearchHit = /0\s*\/\s*0|无结果|没有找到|未找到/.test(searchText);
  
      const visibleDocText = Array.from(document.querySelectorAll("body *"))
        .filter(isVisible)
        .map((el) => {
          const rect = el.getBoundingClientRect();
          const text = String(el.innerText || el.textContent || "");
          return { rect, text };
        })
        .filter((item) =>
          item.text &&
          item.rect.top > 90 &&
          item.rect.bottom < window.innerHeight + 80 &&
          item.rect.left > 40 &&
          item.rect.right < window.innerWidth - 40 &&
          !/查找|替换|在文档内查找|上一处|下一处/.test(item.text)
        )
        .map((item) => normalize(item.text))
        .join("");
      if (visibleDocText.includes(target)) return true;
      if (noSearchHit) {
        const parts = target
          .split(/[，,。！？!?、；;：:~～\-\[\]【】（）()]+/g)
          .map((part) => part.trim())
          .filter((part) => part.length >= 4);
        if (parts.some((part) => visibleDocText.includes(part))) return true;
      }
  
      return false;
    }, keyword).catch(() => false);
  }

  return {
    jumpToReadRangeStart
  };
}

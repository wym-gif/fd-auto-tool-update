import { isTimeTailFragment } from "./content-cleanup.js";

export function removeFeaturedVideoCoverImages(images, videos) {
  if (!Array.isArray(images) || !images.length || !Array.isArray(videos) || !videos.length) return images || [];
  return images.filter((image) => !isFeaturedVideoCoverImage(image, videos));
}

export function isFeaturedVideoCoverImage(image, videos) {
  if (!image?.src || isLikelyExplicitStickerFile(image)) return false;
  return videos.some((video) => isSameFeaturedVideoBox(image, video));
}

export function makeFeaturedMediaTask(item, kind, state, lines, options = {}) {
  const isVideo = kind === "video";
  const isSticker = !isVideo && (
    options.forceSticker ||
    hasStickerMarker(lines, item, null) ||
    isLikelyExplicitStickerFile(item)
  );
  return {
    type: isVideo ? "video" : isSticker ? "sticker" : "image",
    assetUrl: item.src,
    mediaY: item.y,
    mediaOwnerDistance: 0,
    ownerY: item.y,
    parentText: item.parentText || item.text || ""
  };
}

export function isLikelyFeaturedReactionMedia(item, lines) {
  return isLikelyExplicitStickerFile(item) || hasStickerMarker(lines, item, null);
}

export function isLikelyExplicitStickerFile(item) {
  const src = String(item?.src || item?.assetUrl || "");
  return /\.(?:gif|webp)(?:[?#]|$)/i.test(src);
}

export function hasTaskForHeader(tasks, header) {
  return tasks.some((task) =>
    task.headerText === header.headerText &&
    task.speaker === header.speaker &&
    task.time === header.time
  );
}

export function isLikelyHeaderOnlyImage(lines, image, header, options = {}) {
  const headerY = Number(header?.y);
  const imageY = Number(image?.y);
  if (!Number.isFinite(headerY) || !Number.isFinite(imageY)) return false;
  if (imageY < headerY - 30 || imageY - headerY > 900) return false;

  return !lines.some((line) => {
    const y = Number(line?.y);
    const text = String(line?.text || "").trim();
    if (!text || !Number.isFinite(y)) return false;
    if (y <= headerY + 2 || y >= imageY - 2) return false;
    if (options.headerRe?.test(text)) return false;
    if (isStickerMarker(text)) return false;
    if (options.isVisualSectionTitle?.(line)) return false;
    return true;
  });
}

export function isDecorativeImage(src) {
  return /avatar|logo|sprite|toolbar/i.test(src || "");
}

export function assetToken(src) {
  const match = String(src || "").match(/\/(?:preview|cover)\/([^/?]+)/);
  return match?.[1] || "";
}

export function isStickerMarker(text) {
  const line = String(text || "").trim();
  return line === "表情包" || line === "动态表情" || line.includes("表情包形式");
}

export function hasStickerMarker(lines, image, nextHeader) {
  const imageBottom = image.y + image.h;
  const labelText = `${image.alt || ""} ${image.parentText || ""}`;
  if (isStickerMarker(labelText)) return true;
  const limit = nextHeader ? nextHeader.y : imageBottom + 240;
  return lines.some((line) => {
    if (line.y < image.y - 24 || line.y > limit) return false;
    if (line.y > imageBottom && line.y - imageBottom > 220) return false;
    return isStickerMarker(line.text);
  });
}

export function looksLikeVideoCover(lines, image, nextHeader) {
  const srcText = `${image.src || ""} ${image.alt || ""} ${image.parentText || ""}`;
  if (/视频|video|播放|\.mp4(\?|$)|\.mov(\?|$)|\.webm(\?|$)/i.test(srcText)) return true;

  const imageBottom = image.y + image.h;
  const limit = nextHeader ? nextHeader.y : imageBottom + 180;
  return lines.some((line) => {
    if (line.y < image.y - 60 || line.y > limit) return false;
    return /视频|播放/.test(line.text);
  });
}

export function hasBlockingContentBetweenMediaAndDouma(item, lines, options = {}) {
  const mediaY = Number(item?.y || 0);
  const mediaBottom = mediaY + Math.max(0, Number(item?.h || 0));
  if (!Number.isFinite(mediaY)) return true;
  const lookaheadLimit = mediaBottom + 520;
  const canSkipPlainTextBeforeDouma = isLikelyFeaturedReactionMedia(item, lines);
  const candidates = (lines || [])
    .filter((line) => Number(line?.y) > mediaY + 2 && Number(line?.y) <= lookaheadLimit)
    .sort((a, b) => Number(a.y || 0) - Number(b.y || 0));
  for (const line of candidates) {
    if (line.isDivider) continue;
    const text = String(line.text || "").trim();
    if (!text || options.isChromeNoise?.(text) || isStickerMarker(text) || isTimeTailFragment(text)) continue;
    if (options.isTuoMarker?.(text) || options.isDayTitle?.(text) || options.isRhythmTitle?.(text)) return true;
    if (line.highlighted) return false;
    if (
      !options.isStructureOnlyLine?.(text) &&
      !options.isSmallDash?.(text) &&
      !options.isRemarkLine?.(text) &&
      !canSkipPlainTextBeforeDouma
    ) return true;
  }
  return true;
}

export function hasRecentDividerBeforeMedia(item, lines, options = {}) {
  const mediaY = Number(item?.y || 0);
  if (!Number.isFinite(mediaY)) return false;
  const candidates = (lines || [])
    .filter((line) => Number.isFinite(Number(line?.y)) && Number(line.y) < mediaY + 8 && Number(line.y) >= mediaY - 260)
    .sort((a, b) => Number(b.y || 0) - Number(a.y || 0));
  for (const line of candidates) {
    const text = String(line.text || "").trim();
    if (line.isDivider) return true;
    if (!text || options.isChromeNoise?.(text) || isStickerMarker(text) || isTimeTailFragment(text)) continue;
    if (options.isSmallDash?.(text) || options.isRemarkLine?.(text)) continue;
    return false;
  }
  return false;
}

function isSameFeaturedVideoBox(image, video) {
  if (!video?.src) return false;
  const imageRect = mediaRect(image);
  const videoRect = mediaRect(video);
  if (!imageRect || !videoRect) return false;

  const overlapX = rectOverlap(imageRect.left, imageRect.right, videoRect.left, videoRect.right);
  const overlapY = rectOverlap(imageRect.top, imageRect.bottom, videoRect.top, videoRect.bottom);
  const minW = Math.min(imageRect.width, videoRect.width);
  const minH = Math.min(imageRect.height, videoRect.height);
  if (minW <= 0 || minH <= 0) return false;

  const mostlySameBox = overlapX >= minW * 0.55 && overlapY >= minH * 0.45;
  if (!mostlySameBox) return false;

  const centerXNear = Math.abs(imageRect.centerX - videoRect.centerX) <= Math.max(80, minW * 0.45);
  const centerYNear = Math.abs(imageRect.centerY - videoRect.centerY) <= Math.max(80, minH * 0.45);
  if (centerXNear && centerYNear) return true;

  const sourceText = [
    image.src,
    image.alt,
    image.parentText,
    video.src,
    video.type,
    video.text
  ].filter(Boolean).join(" ");
  return /cover|preview|thumbnail|poster|video|播放|\.mp4(?:\?|$)|\.mov(?:\?|$)|\.webm(?:\?|$)|blob:/i.test(sourceText);
}

function mediaRect(item) {
  const left = Number(item?.x);
  const top = Number(item?.y);
  const width = Number(item?.w);
  const height = Number(item?.h);
  if (![left, top, width, height].every(Number.isFinite) || width <= 0 || height <= 0) return null;
  return {
    left,
    top,
    width,
    height,
    right: left + width,
    bottom: top + height,
    centerX: left + width / 2,
    centerY: top + height / 2
  };
}

function rectOverlap(aStart, aEnd, bStart, bEnd) {
  return Math.max(0, Math.min(aEnd, bEnd) - Math.max(aStart, bStart));
}

import fs from "node:fs/promises";

export function removeStickerPreviewDuplicates(tasks) {
  const sorted = [...(tasks || [])].sort((a, b) => a.order - b.order);
  const removeIndexes = new Set();
  let removedCount = 0;
  for (let i = 0; i < sorted.length; i += 1) {
    if (removeIndexes.has(i) || !isImageLikeTask(sorted[i])) continue;
    for (let j = i + 1; j < sorted.length; j += 1) {
      if (removeIndexes.has(j) || !isImageLikeTask(sorted[j])) continue;
      if (!isLikelySameStickerPreviewPair(sorted[i], sorted[j])) continue;
      const keepIndex = mediaExtRank(sorted[i]) >= mediaExtRank(sorted[j]) ? i : j;
      const dropIndex = keepIndex === i ? j : i;
      removeIndexes.add(dropIndex);
      removedCount += 1;
      break;
    }
  }
  if (removedCount) console.log(`已合并重复表情包 ${removedCount} 处。`);
  return sorted.filter((_, index) => !removeIndexes.has(index));
}

export async function removeDownloadedStickerPreviewDuplicates(tasks) {
  const sorted = [...(tasks || [])].sort((a, b) => a.order - b.order);
  const removeIndexes = new Set();
  let removedCount = 0;
  let markedCount = 0;
  for (let i = 0; i < sorted.length - 1; i += 1) {
    const a = sorted[i];
    const b = sorted[i + 1];
    if (!isImageLikeTask(a) || !isImageLikeTask(b)) continue;
    if (!isSameDownloadedStickerPreviewOwner(a, b)) continue;
    const aExt = mediaExt(a);
    const bExt = mediaExt(b);
    const aSize = await readImageSize(a.imagePath);
    const bSize = await readImageSize(b.imagePath);
    if (!isSameImageSize(aSize, bSize)) continue;
    if (isGifStaticPreviewExtPair(aExt, bExt)) {
      const keepIndex = aExt === "gif" ? i : i + 1;
      const dropIndex = keepIndex === i ? i + 1 : i;
      removeIndexes.add(dropIndex);
      removedCount += 1;
      i += 1;
    } else if (isLikelySameStaticPreviewDuplicate(a, b, aExt, bExt)) {
      b.__skip = true;
      b.__autoSkipReason = "疑似重复图片，已默认勾选不发";
      markedCount += 1;
    }
  }
  if (removedCount) console.log(`已合并重复表情包 ${removedCount} 处。`);
  if (markedCount) console.log(`已标记疑似重复图片 ${markedCount} 处为不发，可在预览页取消。`);
  return sorted.filter((_, index) => !removeIndexes.has(index));
}

function isImageLikeTask(task) {
  return task?.type === "image" || task?.type === "sticker";
}

function isLikelySameStickerPreviewPair(a, b) {
  if (!a || !b) return false;
  if ((a.role || "") !== (b.role || "") || (a.speaker || "") !== (b.speaker || "")) return false;
  if ((a.scheduleDateKey || "") !== (b.scheduleDateKey || "")) return false;
  if (Math.abs(Number(a.order || 0) - Number(b.order || 0)) > 1.2) return false;
  const aY = Number(a.mediaY ?? a.ownerY);
  const bY = Number(b.mediaY ?? b.ownerY);
  if (Number.isFinite(aY) && Number.isFinite(bY) && Math.abs(aY - bY) > 18) return false;
  const aExt = mediaExt(a);
  const bExt = mediaExt(b);
  if (!["gif", "webp"].includes(aExt) && !["gif", "webp"].includes(bExt)) return false;
  if (aExt === bExt) return false;
  const aText = normalizedContent(`${a.parentText || ""} ${a.text || ""}`);
  const bText = normalizedContent(`${b.parentText || ""} ${b.text || ""}`);
  if (aText && bText && aText !== bText && !aText.includes(bText) && !bText.includes(aText)) return false;
  return true;
}

function mediaExtRank(task) {
  const ext = mediaExt(task);
  if (ext === "gif") return 3;
  if (ext === "webp") return 2;
  return 1;
}

function mediaExt(task) {
  const source = String(task?.imagePath || task?.assetUrl || "");
  const match = source.toLowerCase().match(/\.([a-z0-9]+)(?:[?#]|$)/);
  return match?.[1] || "";
}

function isSameDownloadedStickerPreviewOwner(a, b) {
  if (!a || !b) return false;
  if ((a.role || "") !== (b.role || "") || (a.speaker || "") !== (b.speaker || "")) return false;
  if ((a.scheduleDateKey || "") !== (b.scheduleDateKey || "")) return false;
  if (!a.imagePath || !b.imagePath) return false;
  const aY = Number(a.mediaY ?? a.ownerY);
  const bY = Number(b.mediaY ?? b.ownerY);
  if (Number.isFinite(aY) && Number.isFinite(bY) && Math.abs(aY - bY) > 80) return false;
  return true;
}

function isGifStaticPreviewExtPair(aExt, bExt) {
  const staticExts = new Set(["png", "jpg", "jpeg", "webp"]);
  return (aExt === "gif" && staticExts.has(bExt)) || (bExt === "gif" && staticExts.has(aExt));
}

function isLikelySameStaticPreviewDuplicate(a, b, aExt, bExt) {
  if (!aExt || !bExt || aExt !== bExt) return false;
  if (["gif", "webp"].includes(aExt)) return false;
  if (Math.abs(Number(a.order || 0) - Number(b.order || 0)) > 1.2) return false;
  const aY = Number(a.mediaY ?? a.ownerY);
  const bY = Number(b.mediaY ?? b.ownerY);
  if (Number.isFinite(aY) && Number.isFinite(bY) && Math.abs(aY - bY) > 32) return false;
  const aText = normalizedContent(`${a.parentText || ""} ${a.text || ""}`);
  const bText = normalizedContent(`${b.parentText || ""} ${b.text || ""}`);
  return !aText || !bText || aText === bText || aText.includes(bText) || bText.includes(aText);
}

export function isSameImageSize(a, b) {
  if (!a || !b) return false;
  if (a.width !== b.width || a.height !== b.height) return false;
  return a.width >= 48 && a.height >= 48;
}

export async function readImageSize(filePath) {
  if (!filePath) return null;
  try {
    const buffer = await fs.readFile(filePath);
    return imageSizeFromBuffer(buffer);
  } catch {
    return null;
  }
}

export function imageSizeFromBuffer(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 10) return null;
  if (buffer.length >= 10 && ["GIF87a", "GIF89a"].includes(buffer.slice(0, 6).toString("ascii"))) {
    return { width: buffer.readUInt16LE(6), height: buffer.readUInt16LE(8) };
  }
  if (buffer.length >= 24 && buffer.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) {
    return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
  }
  if (buffer.length >= 12 && buffer.slice(0, 4).toString("ascii") === "RIFF" && buffer.slice(8, 12).toString("ascii") === "WEBP") {
    return webpSizeFromBuffer(buffer);
  }
  if (buffer[0] === 0xff && buffer[1] === 0xd8) return jpegSizeFromBuffer(buffer);
  return null;
}

function webpSizeFromBuffer(buffer) {
  const type = buffer.slice(12, 16).toString("ascii");
  if (type === "VP8 " && buffer.length >= 30) {
    return { width: buffer.readUInt16LE(26) & 0x3fff, height: buffer.readUInt16LE(28) & 0x3fff };
  }
  if (type === "VP8L" && buffer.length >= 25) {
    const bits = buffer.readUInt32LE(21);
    return { width: (bits & 0x3fff) + 1, height: ((bits >> 14) & 0x3fff) + 1 };
  }
  if (type === "VP8X" && buffer.length >= 30) {
    return {
      width: 1 + buffer.readUIntLE(24, 3),
      height: 1 + buffer.readUIntLE(27, 3)
    };
  }
  return null;
}

function jpegSizeFromBuffer(buffer) {
  let offset = 2;
  while (offset + 9 < buffer.length) {
    if (buffer[offset] !== 0xff) {
      offset += 1;
      continue;
    }
    const marker = buffer[offset + 1];
    const length = buffer.readUInt16BE(offset + 2);
    if (length < 2) return null;
    if ((marker >= 0xc0 && marker <= 0xc3) || (marker >= 0xc5 && marker <= 0xc7) || (marker >= 0xc9 && marker <= 0xcb) || (marker >= 0xcd && marker <= 0xcf)) {
      return { width: buffer.readUInt16BE(offset + 7), height: buffer.readUInt16BE(offset + 5) };
    }
    offset += 2 + length;
  }
  return null;
}

function normalizedContent(text) {
  return String(text || "").replace(/\s+/g, "");
}

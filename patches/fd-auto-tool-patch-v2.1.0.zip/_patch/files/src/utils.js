import fs from "node:fs/promises";
import path from "node:path";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

export async function readJson(file) {
  return JSON.parse(await fs.readFile(file, "utf8"));
}

export async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true });
}

export function stamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

export async function askEnter(message) {
  const rl = readline.createInterface({ input, output });
  await rl.question(`${message}\n按回车继续...`);
  rl.close();
}

export async function askChoice(message, choices, defaultValue) {
  const rl = readline.createInterface({ input, output });
  try {
    while (true) {
      console.log(`\n${message}`);
      for (const choice of choices) {
        console.log(`${choice.key}. ${choice.label}`);
      }
      const hint = defaultValue ? `，直接回车默认 ${defaultValue}` : "";
      const answer = (await rl.question(`请选择${hint}: `)).trim();
      const value = answer || defaultValue;
      const choice = choices.find((item) => item.key === value);
      if (choice) return choice.value;
      console.log("输入不对，请重新选。");
    }
  } finally {
    rl.close();
  }
}

export async function askText(message, defaultValue = "") {
  const rl = readline.createInterface({ input, output });
  try {
    const hint = defaultValue ? `，直接回车默认 ${defaultValue}` : "";
    const answer = (await rl.question(`${message}${hint}: `)).trim();
    return answer || defaultValue;
  } finally {
    rl.close();
  }
}

export async function waitEnterOrTimeout(message, timeoutMs) {
  const rl = readline.createInterface({ input, output });
  let timer = null;
  try {
    return await Promise.race([
      rl.question(`${message}\n`).then(() => "enter"),
      new Promise((resolve) => {
        timer = setTimeout(() => resolve("timeout"), timeoutMs);
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
    rl.close();
  }
}

export function toAbs(baseDir, maybeRelative) {
  if (!maybeRelative) return maybeRelative;
  return path.isAbsolute(maybeRelative) ? maybeRelative : path.resolve(baseDir, maybeRelative);
}

export function parseTime(raw) {
  const m = String(raw || "").match(/(\d{1,2})\s*[：:]\s*(\d{1,2})(?:\s*[：:]\s*(\d{1,2}))?/);
  if (!m) return null;
  return `${m[1].padStart(2, "0")}:${m[2].padStart(2, "0")}:${(m[3] || "00").padStart(2, "0")}`;
}

export function shiftTimes(tasks, startTime) {
  const first = tasks.find((t) => t.time)?.time;
  const start = parseTime(startTime);
  if (!first || !start) return tasks;
  const toSec = (t) => {
    const [h, m, s] = t.split(":").map(Number);
    return h * 3600 + m * 60 + s;
  };
  const from = toSec(first);
  const target = toSec(start);
  const pad = (n) => String(n).padStart(2, "0");
  return tasks.map((task) => {
    if (!task.time) return task;
    let sec = toSec(task.time) - from + target;
    sec = ((sec % 86400) + 86400) % 86400;
    return {
      ...task,
      originalTime: task.time,
      time: `${pad(Math.floor(sec / 3600))}:${pad(Math.floor((sec % 3600) / 60))}:${pad(sec % 60)}`
    };
  });
}

export function printTasks(tasks) {
  console.log("\n按实际创建顺序预览：");
  for (const [i, task] of tasks.entries()) {
    const robotLabel = task.role === "tuo" && task.robotGroup ? `（托段${task.robotGroup}）` : "";
    const tags = task.previewTags?.length ? ` / 标签：${task.previewTags.join("、")}` : "";
    const body =
      task.type === "image"
        ? `[${task.possibleVideoCover ? "图片/疑似视频封面" : "图片"}] ${task.imagePath || task.assetUrl || ""}`
        : task.type === "sticker"
          ? `[表情包] ${task.imagePath || task.assetUrl || ""}`
          : task.type === "video"
            ? `[视频] ${task.imagePath || task.assetUrl || ""}`
            : task.text;
    const shifted = task.originalTime ? `，原时间 ${task.originalTime}` : "";
    const dateLabel = task.scheduleDateLabel ? ` / 日期：${task.scheduleDateLabel}` : "";
    console.log(`${i + 1}. ${task.role}${robotLabel} / ${task.speaker} / ${task.time}${shifted}${dateLabel}${tags} / ${body}`);
  }
}

import fs from "node:fs/promises";
import path from "node:path";
import { readFeishuTasks } from "../feishu.js";
import { rememberCurrentFeishuDocument } from "../settings/local-settings.js";
import { UserCanceledPreview } from "../runtime/errors.js";
import {
  roleSwitchGapSeconds,
  withCustomGap,
  taskDocAbsoluteSeconds,
  orderTasksForTiming,
  buildInteractionSpanByPosition,
  isMediaLikeTask,
  shouldKeepDocumentGapInsideInteraction,
  parseClockToAbsoluteSeconds,
  currentAbsoluteSeconds,
  secondsToTime,
  applyAbsoluteSchedule
} from "../schedule/task-schedule.js";

export async function previewSelfCheck(tasks, config, runDir, phase, options = {}) {
  if (config.previewSelfCheck === false || !Array.isArray(tasks) || !tasks.length) return tasks;

  let checkedTasks = tasks.map((task) => ({ ...task }));
  const beforeTasks = checkedTasks.map((task) => ({ ...task }));
  const fixes = [];
  const warnings = [];
  const mode = config.scheduleMode || "doc";
  const preserveConfirmedPreviewTiming = options.preserveConfirmedPreviewTiming === true;

  const beforeTiming = previewTimingSummary(checkedTasks, config);
  const shouldRebuild = shouldRebuildScheduleForNow(checkedTasks, config);
  if ((mode === "realtime" || mode === "catchup") && shouldRebuild && preserveConfirmedPreviewTiming) {
    warnings.push("正式执行前检测到时间接近或早于当前时间，但这批任务来自已确认预览，已保留你在预览页确认的时间；如需重排，请点重新生成预览。");
  } else if ((mode === "realtime" || mode === "catchup") && shouldRebuild) {
    const sourceTasks = restoreSourceScheduleTasks(checkedTasks);
    checkedTasks = await options.prepareTasksForScheduleMode(sourceTasks, config);
    fixes.push(`时间已接近或早于当前时间，已按当前时间重新生成${mode === "realtime" ? "实时跟发" : "补发"}预览。`);
  }

  if ((mode === "realtime" || mode === "catchup") && preserveConfirmedPreviewTiming) {
    warnings.push("正式执行前已跳过自动间隔修正，创建任务将使用预览页最终确认的时间。");
  } else if (mode === "realtime" || mode === "catchup") {
    const repaired = repairPreviewScheduleGaps(checkedTasks, config);
    checkedTasks = repaired.tasks;
    fixes.push(...repaired.fixes);
  }

  let report = buildPreviewSelfCheckReport(beforeTasks, checkedTasks, config, phase, beforeTiming, fixes, warnings);
  const repaired = await autoRepairPreviewMediaIssues(report, config, runDir, phase, options);
  if (repaired) {
    checkedTasks = repaired.tasks;
    report = repaired.report;
  }
  config.__lastPreviewSelfCheckReport = report;
  const filename = phase.includes("正式执行") ? "preview-check-before-run.txt" : "preview-check.txt";
  const textPath = path.join(runDir, filename);
  await fs.writeFile(textPath, report.text, "utf8");
  printPreviewSelfCheckSummary(report, textPath);
  if (phase.includes("正式执行") && hasPreviewMediaIssues(report)) {
    throw new UserCanceledPreview("自检仍有素材缺失或疑似挂错，已停止正式执行。请检查自检文件后重新生成预览。");
  }
  return checkedTasks;
}

async function autoRepairPreviewMediaIssues(report, config, runDir, phase, options = {}) {
  if (config.autoRepairMediaIssues === false) return null;
  if (!options.feishuPage) return null;
  if (!hasPreviewMediaIssues(report)) return null;

  const maxRetries = Math.max(0, Number(config.mediaIssueAutoRepairRetries ?? 2));
  if (!maxRetries) return null;

  let bestTasks = null;
  let bestReport = report;
  let bestCount = previewMediaIssueCount(report);
  for (let attempt = 1; attempt <= maxRetries; attempt += 1) {
    console.log(`\n自检发现素材问题：缺失 ${report.missingMediaRows.length} 条，疑似挂错 ${report.suspiciousMediaOwnerRows.length} 条。`);
    console.log(`正在第 ${attempt}/${maxRetries} 次自动重读修正，请稍等...`);

    const repairConfig = buildMediaRepairConfig(config, attempt);
    const retryBefore = await readFeishuTasks(options.feishuPage, repairConfig, runDir, { dropFailedMedia: false });
    await rememberCurrentFeishuDocument(options.localSettingsPath, options.feishuPage, repairConfig);
    let retryTasks = await options.prepareTasksForScheduleMode(retryBefore, repairConfig);
    const retryFixes = [`发现素材问题后已自动重读第 ${attempt}/${maxRetries} 次。`];
    if (repairConfig.scheduleMode === "realtime" || repairConfig.scheduleMode === "catchup") {
      const repairedTiming = repairPreviewScheduleGaps(retryTasks, repairConfig);
      retryTasks = repairedTiming.tasks;
      retryFixes.push(...repairedTiming.fixes);
    }

    const retryReport = buildPreviewSelfCheckReport(
      retryBefore.map((task) => ({ ...task })),
      retryTasks,
      repairConfig,
      `${phase} 自动重读第 ${attempt} 次`,
      previewTimingSummary(retryBefore, repairConfig),
      retryFixes,
      []
    );
    const remaining = previewMediaIssueCount(retryReport);
    console.log(`自动重读第 ${attempt}/${maxRetries} 次完成：剩余素材问题 ${remaining} 条。`);

    if (!bestReport || remaining < bestCount) {
      bestTasks = retryTasks;
      bestReport = retryReport;
      bestCount = remaining;
    }
    if (remaining === 0) {
      console.log("素材问题已自动修正。");
      return { tasks: retryTasks, report: retryReport };
    }
  }

  console.log("自动重读后仍有素材问题，已保留风险提示，请按自检结果人工确认。");
  return bestTasks ? { tasks: bestTasks, report: bestReport } : null;
}

function hasPreviewMediaIssues(report) {
  return previewMediaIssueCount(report) > 0;
}

function previewMediaIssueCount(report) {
  return (report?.missingMediaRows?.length || 0) + (report?.suspiciousMediaOwnerRows?.length || 0);
}

function buildMediaRepairConfig(config, attempt) {
  return {
    ...config,
    feishuScrollWaitMs: Math.max(Number(config.feishuScrollWaitMs ?? 520), 650 + attempt * 150),
    feishuRangeScrollPixels: Math.min(Number(config.feishuRangeScrollPixels ?? 650), 420),
    feishuScrollPixels: Math.min(Number(config.feishuScrollPixels ?? 900), 620),
    feishuRangeScrollSteps: Math.max(Number(config.feishuRangeScrollSteps ?? 120), 180),
    mediaIssueAutoRepairPass: attempt
  };
}

function shouldRebuildScheduleForNow(tasks, config) {
  const mode = config.scheduleMode || "doc";
  if (mode !== "realtime" && mode !== "catchup") return false;
  const orderedItems = orderTasksForTiming(tasks);
  if (!orderedItems.length) return false;
  const firstAbs = taskDocAbsoluteSeconds(orderedItems[0].task);
  const nowAbs = currentAbsoluteSeconds();
  const minLeadSeconds = Number(config.realtimeMinLeadSeconds ?? 60);
  return firstAbs <= nowAbs + minLeadSeconds;
}

function restoreSourceScheduleTasks(tasks) {
  return tasks.map((task) => {
    const next = { ...task };
    if (next.originalTime) next.time = next.originalTime;
    if (next.originalScheduleDateKey !== undefined) next.scheduleDateKey = next.originalScheduleDateKey;
    if (next.originalScheduleDateLabel !== undefined) next.scheduleDateLabel = next.originalScheduleDateLabel;
    if (next.originalScheduleDateOffset !== undefined) next.scheduleDateOffset = Number(next.originalScheduleDateOffset || 0);
    return next;
  });
}

function repairPreviewScheduleGaps(tasks, config) {
  const orderedItems = orderTasksForTiming(tasks);
  if (!orderedItems.length) return { tasks, fixes: [] };

  const fixedByCreationIndex = new Map();
  const fixes = [];
  const nowAbs = currentAbsoluteSeconds();
  const minLeadSeconds = Number(config.realtimeMinLeadSeconds ?? 60);
  const spanByPosition = buildInteractionSpanByPosition(orderedItems);
  let previousAbs = null;

  for (let index = 0; index < orderedItems.length; index += 1) {
    const item = orderedItems[index];
    const currentAbs = taskDocAbsoluteSeconds(item.task);
    let targetAbs = currentAbs;
    if (index === 0) {
      const minFirstAbs = nowAbs + minLeadSeconds;
      if (targetAbs < minFirstAbs) {
        targetAbs = minFirstAbs;
        fixes.push(`${formatPreviewTask(item.task)}：开始时间已过，改为 ${secondsToTime(targetAbs)}。`);
      }
    } else {
      const prevItem = orderedItems[index - 1];
      const originalGap = Math.max(0, currentAbs - taskDocAbsoluteSeconds(prevItem.task));
      const requiredGap = previewRequiredGap(prevItem, item, index, spanByPosition, originalGap, config);
      const minAbs = previousAbs + requiredGap;
      if (targetAbs < minAbs) {
        targetAbs = minAbs;
        fixes.push(`${formatPreviewTask(item.task)}：与上一条间隔不足，改为 ${secondsToTime(targetAbs)}。`);
      }
    }
    previousAbs = targetAbs;
    fixedByCreationIndex.set(item.creationIndex, targetAbs);
  }

  return {
    tasks: tasks.map((task, index) => {
      if (!fixedByCreationIndex.has(index)) return task;
      const next = { ...task };
      const oldLabel = `${next.scheduleDateLabel || next.scheduleDateKey || "今天"} ${next.time}`;
      applyAbsoluteSchedule(next, fixedByCreationIndex.get(index));
      const newLabel = `${next.scheduleDateLabel || next.scheduleDateKey || "今天"} ${next.time}`;
      if (oldLabel !== newLabel) next.selfCheckAdjusted = true;
      return next;
    }),
    fixes
  };
}

function previewRequiredGap(prevItem, nextItem, nextPosition, spanByPosition, originalGap, config) {
  const span = spanByPosition.get(nextPosition);
  if (span && span.startIndex < nextPosition && shouldKeepDocumentGapInsideInteraction(config)) {
    const docGap = Math.max(0, taskDocAbsoluteSeconds(nextItem.task) - taskDocAbsoluteSeconds(prevItem.task));
    if (prevItem.task.role !== nextItem.task.role) {
      return Math.max(docGap, roleSwitchGapSeconds(config));
    }
    return docGap;
  }
  const prev = prevItem.task;
  const next = nextItem.task;
  if (prev.role !== next.role) return Math.max(originalGap, roleSwitchGapSeconds(config));
  return withCustomGap(originalGap, prev, next, config);
}

function buildPreviewSelfCheckReport(beforeTasks, tasks, config, phase, beforeTiming, fixes, warnings) {
  const timing = previewTimingSummary(tasks, config);
  const roleSwitchProblems = previewRoleSwitchProblems(tasks, config);
  const pastRows = previewPastRows(tasks);
  const missingMediaRows = tasks
    .map((task, index) => ({ task, index }))
    .filter(({ task }) => isMediaLikeTask(task) && !task.imagePath);
  const suspiciousMediaOwnerRows = previewSuspiciousMediaOwnerRows(tasks, config);
  const endAbs = parseClockToAbsoluteSeconds(config.realtimeEndTime, timing.firstAbs ?? null);
  if ((config.scheduleMode === "realtime" || config.scheduleMode === "catchup") && endAbs && timing.lastAbs > endAbs) {
    warnings.push(`预计结束 ${secondsToTime(timing.lastAbs)}，超过你设置的结束时间 ${secondsToTime(endAbs)}。`);
  }
  for (const row of roleSwitchProblems) {
    warnings.push(`豆妈/托切换间隔不足：${formatPreviewTask(row.prev)} -> ${formatPreviewTask(row.next)}，当前 ${row.gap} 秒。`);
  }
  if ((config.scheduleMode || "doc") === "doc" && pastRows.length) {
    warnings.push(`文档时间模式有 ${pastRows.length} 条时间已经早于当前时间，创建时可能会变成立即执行。`);
  }
  for (const row of missingMediaRows) {
    warnings.push(`素材缺失：${row.index + 1}. ${formatPreviewTask(row.task)}。`);
  }
  for (const row of suspiciousMediaOwnerRows) {
    const nextHint = row.task.nextHeaderText ? `；下一个标题：${row.task.nextHeaderText}` : "";
    warnings.push(`疑似素材归属异常：${row.index + 1}. ${formatPreviewTask(row.task)}，素材离标题约 ${Math.round(row.distance)}px${nextHint}。`);
  }

  const changedRows = tasks
    .map((task, index) => ({ before: beforeTasks[index], task, index }))
    .filter(({ before, task }) => before && (before.time !== task.time || before.scheduleDateKey !== task.scheduleDateKey));

  const lines = [];
  lines.push(`预览自检结果：${phase}`);
  lines.push(`生成时间：${new Date().toLocaleString()}`);
  lines.push(`时间模式：${config.scheduleMode || "doc"}`);
  lines.push(`任务数量：${tasks.length} 条`);
  lines.push("");
  lines.push(`当前时间：${secondsToTime(currentAbsoluteSeconds())}`);
  lines.push(`自检前范围：${beforeTiming.firstText || "-"} 到 ${beforeTiming.lastText || "-"}`);
  lines.push(`自检后范围：${timing.firstText || "-"} 到 ${timing.lastText || "-"}`);
  lines.push("");
  lines.push("检查项：");
  lines.push(`- 日期/时间：${changedRows.length ? `已修正 ${changedRows.length} 条` : "未发现需要自动修正的时间"}`);
  lines.push(`- 豆妈/托切换：${roleSwitchProblems.length ? `仍有 ${roleSwitchProblems.length} 条需要人工确认` : "通过"}`);
  lines.push(`- 过期时间：${pastRows.length ? `发现 ${pastRows.length} 条` : "通过"}`);
  lines.push(`- 素材路径：${missingMediaRows.length ? `发现 ${missingMediaRows.length} 条素材缺失` : "通过"}`);
  lines.push(`- 素材归属：${suspiciousMediaOwnerRows.length ? `发现 ${suspiciousMediaOwnerRows.length} 条疑似挂错人` : "通过"}`);
  lines.push(`- 结束时间：${warnings.some((line) => line.includes("超过你设置的结束时间")) ? "需要人工确认" : "通过"}`);
  lines.push("");

  if (fixes.length || changedRows.length) {
    lines.push("自动修正：");
    const printed = new Set();
    for (const fix of fixes) {
      if (printed.has(fix)) continue;
      printed.add(fix);
      lines.push(`- ${fix}`);
    }
    for (const row of changedRows) {
      lines.push(`- ${row.index + 1}. ${row.before.role}/${row.before.speaker}：${row.before.scheduleDateLabel || row.before.scheduleDateKey || "今天"} ${row.before.time} -> ${row.task.scheduleDateLabel || row.task.scheduleDateKey || "今天"} ${row.task.time}`);
    }
    lines.push("");
  }

  if (warnings.length) {
    lines.push("需要你确认：");
    for (const warning of Array.from(new Set(warnings))) lines.push(`- ${warning}`);
    lines.push("");
  }

  if (!fixes.length && !changedRows.length && !warnings.length) {
    lines.push("结论：自检通过，没有发现需要修正的问题。");
    lines.push("");
  }

  return {
    text: `${lines.join("\n")}\n`,
    fixes,
    warnings,
    changedRows,
    pastRows,
    roleSwitchProblems,
    missingMediaRows,
    suspiciousMediaOwnerRows
  };
}

function printPreviewSelfCheckSummary(report, textPath) {
  const fixCount = report.changedRows.length || report.fixes.length;
  console.log(`\n预览自检：修正 ${fixCount} 处，风险 ${report.warnings.length} 条。`);
  if (report.warnings.length) {
    for (const warning of Array.from(new Set(report.warnings)).slice(0, 3)) console.log(`- ${warning}`);
    if (report.warnings.length > 3) console.log(`- 还有 ${report.warnings.length - 3} 条，详见自检文件。`);
  } else {
    console.log("预览自检通过：没有发现明显风险。");
  }
  console.log(`自检文件：${textPath}`);
}

export function printPreviewReadySummary(tasks, config, previewPath) {
  const mediaTasks = tasks.filter((task) => isMediaLikeTask(task));
  const mediaOk = mediaTasks.filter((task) => task.imagePath).length;
  const mediaFailed = mediaTasks.length - mediaOk;
  const report = config.__lastPreviewSelfCheckReport || {};
  const fixCount = report.changedRows?.length || report.fixes?.length || 0;
  const warningCount = report.warnings?.length || 0;

  console.log("\n预览生成完成：");
  console.log(`- 任务：${tasks.length} 条`);
  console.log(`- 素材：${mediaTasks.length} 个，成功 ${mediaOk} 个，失败 ${mediaFailed} 个`);
  console.log(`- 自检：修正 ${fixCount} 处，风险 ${warningCount} 条`);
  console.log(`- 预览文件：${previewPath}`);
  console.log("- 下一步：确认发单页面准备好后，输入 1 开始");
}

function previewTimingSummary(tasks, config) {
  const ordered = orderTasksForTiming(tasks);
  if (!ordered.length) return { firstAbs: null, lastAbs: null, firstText: "", lastText: "" };
  const first = ordered[0].task;
  const last = ordered[ordered.length - 1].task;
  const firstAbs = taskDocAbsoluteSeconds(first);
  const lastAbs = taskDocAbsoluteSeconds(last);
  return {
    firstAbs,
    lastAbs,
    firstText: `${first.scheduleDateLabel || first.scheduleDateKey || "今天"} ${first.time}`,
    lastText: `${last.scheduleDateLabel || last.scheduleDateKey || "今天"} ${last.time}`
  };
}

function previewRoleSwitchProblems(tasks, config) {
  const minGap = roleSwitchGapSeconds(config);
  const ordered = orderTasksForTiming(tasks);
  const problems = [];
  for (let index = 1; index < ordered.length; index += 1) {
    const prev = ordered[index - 1].task;
    const next = ordered[index].task;
    if (prev.role === next.role) continue;
    const gap = taskDocAbsoluteSeconds(next) - taskDocAbsoluteSeconds(prev);
    if (gap < minGap) problems.push({ prev, next, gap });
  }
  return problems;
}

function previewPastRows(tasks) {
  const nowAbs = currentAbsoluteSeconds();
  return tasks
    .map((task, index) => ({ task, index }))
    .filter(({ task }) => taskDocAbsoluteSeconds(task) <= nowAbs);
}

function previewSuspiciousMediaOwnerRows(tasks, config) {
  const threshold = Number(config.mediaOwnerDistanceWarningPixels ?? 430);
  return tasks
    .map((task, index) => ({
      task,
      index,
      distance: Number(task.mediaOwnerDistance)
    }))
    .filter(({ task, distance }) => {
      if (!isMediaLikeTask(task)) return false;
      if (!Number.isFinite(distance)) return false;
      return shouldWarnMediaOwnerDistance(task, distance, config, threshold);
    });
}

function shouldWarnMediaOwnerDistance(task, distance, config, threshold) {
  if (task.__ignoreMediaOwnerDistanceWarning) return false;
  const hardThreshold = Number(config.mediaOwnerDistanceHardWarningPixels ?? 650);
  const continueThreshold = Number(config.continueMediaOwnerDistanceWarningPixels ?? 360);
  const nextHeaderDistance = Number(task.nextHeaderY || 0) - Number(task.mediaY || 0);
  if (task.continueSpeaker && distance >= continueThreshold) return true;
  if (distance >= hardThreshold) return true;
  return distance >= threshold && (!Number.isFinite(nextHeaderDistance) || nextHeaderDistance > 80);
}

function formatPreviewTask(task) {
  return `${task.role || ""}/${task.speaker || ""}/${task.scheduleDateLabel || task.scheduleDateKey || "今天"} ${task.time || ""}/${task.type || ""}`;
}

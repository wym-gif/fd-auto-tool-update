import fs from "node:fs/promises";
import path from "node:path";

export function latestPreviewPath(rootDir, config) {
  return path.resolve(rootDir, config.latestPreviewFile || "./latest-preview.json");
}

export async function loadLatestPreviewData(rootDir, config, options = {}) {
  if (config.useLatestPreviewOnRun === false) return null;
  const latestPath = latestPreviewPath(rootDir, config);
  try {
    const data = JSON.parse(await fs.readFile(latestPath, "utf8"));
    if (!Array.isArray(data.tasks) || !data.tasks.length) return null;
    return data;
  } catch {
    if (!options.silent) console.log(`\n${options.missingMessage || "没有找到监控预览结果，改为现场读飞书"}`);
    return null;
  }
}

export async function loadLatestPreviewTasksFromData(rootDir, config, runDir, latestPreviewData = null, options = {}) {
  if (config.useLatestPreviewOnRun === false) return null;
  const data = latestPreviewData || await loadLatestPreviewData(rootDir, config, options);
  if (!data) return null;
  const latestPath = latestPreviewPath(rootDir, config);
  console.log(`\n${options.usedMessage || "已使用监控预览的最新结果，本次不重新读飞书"}: ${latestPath}`);
  if (data.updatedAt) console.log(`Preview updated at: ${new Date(data.updatedAt).toLocaleString()}`);
  await fs.writeFile(path.join(runDir, "latest-preview-used.json"), JSON.stringify(data, null, 2), "utf8");
  return data.tasks;
}

export async function saveRunPreview(runDir, tasks) {
  const previewPath = path.join(runDir, "preview.json");
  await fs.writeFile(previewPath, JSON.stringify(tasks, null, 2), "utf8");
  return previewPath;
}

export async function saveLatestPreview(rootDir, config, data) {
  const latestPath = latestPreviewPath(rootDir, config);
  await fs.writeFile(latestPath, JSON.stringify(data, null, 2), "utf8");
  return latestPath;
}

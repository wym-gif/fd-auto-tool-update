export function createDefaultRunState() {
  return {
    available: false,
    paused: false,
    stopped: false,
    current: "等待设置",
    pauseNoticeShown: false,
    restartPreviewRequested: false,
    restartRequestId: 0,
    waitingStandbyCommand: false,
    standbyCommand: null,
    waitingRealtimeGapChoice: false,
    realtimeGapChoice: null,
    realtimeGapInfo: null,
    waitingCmsSetupAction: false,
    cmsSetupAction: null,
    waitProgress: null,
    progress: null,
    updatedAt: new Date().toLocaleTimeString()
  };
}

export function touchRunState(session) {
  session.runState.updatedAt = new Date().toLocaleTimeString();
}

export function clearWaitProgress(session) {
  if (session?.runState) session.runState.waitProgress = null;
}

export function clearStepProgress(session) {
  if (session?.runState) session.runState.progress = null;
}

export function applyRunAction(session, action, options = {}) {
  if (action === "pause") {
    session.runState.paused = true;
    session.runState.pauseNoticeShown = false;
    options.onPause?.(session.runState.current);
    session.runState.pauseNoticeShown = true;
  } else if (action === "resume") {
    session.runState.paused = false;
    session.runState.pauseNoticeShown = false;
    options.onResume?.();
  } else if (action === "stop") {
    session.runState.stopped = true;
    session.runState.paused = false;
    session.runState.pauseNoticeShown = false;
  }
  touchRunState(session);
}

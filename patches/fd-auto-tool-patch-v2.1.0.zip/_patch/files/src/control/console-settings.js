import {
  loadLocalSettings,
  normalizeFeishuUrl,
  saveFixedRolePrefix,
  saveFixedRoleSheet,
  saveLastFeishuUrl
} from "../settings/local-settings.js";
import { secondsToClock } from "../schedule/time-utils.js";
import { askChoice, askText } from "../utils.js";
import { UserCanceledPreview } from "../runtime/errors.js";

const BACK = "__back";
const EXIT = "__exit";

export async function askManualSyncConfirm(config) {
  while (true) {
    const raw = (await askText(
      "检测到飞书有变化。请先把文案改完；输入 1 同步当前飞书，或直接粘贴新的飞书链接切换文档；输入 q 退出监控"
    )).trim();
    const answer = raw.toLowerCase();
    if (answer === "1") return { action: "sync" };
    if (answer === "q" || answer === "quit" || answer === "exit") return { action: "exit" };
    const feishuUrl = normalizeFeishuUrl(raw);
    if (feishuUrl) return { action: "sync", feishuUrl };
    if (normalizeFeishuUrl(config?.feishuUrl) && !raw) {
      console.log("还没有确认同步。请输入 1，或粘贴新的飞书链接，或输入 q 退出。");
      continue;
    }
    console.log("输入不对，没有读取也没有执行。请输入 1，或粘贴新的飞书链接，或输入 q 退出。");
  }
}

export async function askWatchStandbyCommand(config, control = null) {
  if (control?.waitForStandbyCommand) {
    console.log("\n本轮文档已经定完，请在妙券自动发单🚀控制台选择下一步。");
    console.log("如果控制台按钮不可用，仍可以回到黑窗口输入 1/2/3/4 或 q。");
    return await control.waitForStandbyCommand();
  }
  while (true) {
    console.log("\n本轮文档已经定完，请选择下一步：");
    console.log("1. 继续当前飞书和当前时间模式");
    console.log("2. 改为文档时间");
    console.log("3. 改为实时跟发");
    console.log("4. 改为补发到文档时间");
    console.log("也可以直接粘贴新的飞书链接切换文档；切换后会重新选择读取范围；输入 q 退出监控。");
    const raw = (await askText("请输入选项")).trim();
    const answer = raw.toLowerCase();
    if (answer === "1") return { action: "continue" };
    if (answer === "2") return { action: "continue", scheduleMode: "doc" };
    if (answer === "3") return { action: "continue", scheduleMode: "realtime" };
    if (answer === "4") return { action: "continue", scheduleMode: "catchup" };
    if (answer === "q" || answer === "quit" || answer === "exit") return { action: "exit" };
    const feishuUrl = normalizeFeishuUrl(raw);
    if (feishuUrl) return { action: "continue", feishuUrl };
    console.log("输入不对。请输入 1/2/3/4，或粘贴飞书链接，或输入 q 退出。");
  }
}

export async function askRunFailureCommand() {
  while (true) {
    const raw = (await askText("本轮运行失败。请输入 1 检查页面后重试这份预览；输入 2 回到监控；输入 q 退出（直接回车不会执行）")).trim().toLowerCase();
    if (raw === "1") return "retry";
    if (raw === "2") return "monitor";
    if (raw === "q" || raw === "quit" || raw === "exit") return "exit";
    console.log("请输入 1 重试、2 回监控，或 q 退出。");
  }
}

export async function applyStandbyScheduleMode(config, scheduleMode, messages) {
  config.scheduleMode = scheduleMode;
  if (scheduleMode === "doc") {
    console.log("Switched to document-time mode.");
    return;
  }

  const defaultStart = config.realtimeStartTime || secondsToClock(currentAbsoluteSeconds() + Number(config.realtimeMinLeadSeconds ?? 60));
  if (scheduleMode === "realtime") {
    console.log("Switched to realtime-follow mode.");
    config.realtimeStartTime = await askText(messages.realtimeStartPrompt, defaultStart);
    config.realtimeEndTime = await askText(messages.realtimeEndPrompt, config.realtimeEndTime || "");
    return;
  }

  if (scheduleMode === "catchup") {
    console.log("Switched to catch-up-to-document-time mode.");
    config.realtimeStartTime = await askText(messages.realtimeStartPrompt, defaultStart);
  }
}

export async function chooseInteractiveSettings(config, options) {
  const { localSettingsPath, messages } = options;
  while (true) {
    const feishuResult = await chooseFeishuUrl(config, localSettingsPath);
    if (feishuResult === EXIT) throw new UserCanceledPreview("已退出。");

    while (true) {
      config.tuoMode = await chooseTuoMode(config, messages, { allowBack: true });
      if (config.tuoMode === BACK) break;
      console.log(config.tuoMode === "fixed" ? messages.modeFixed : messages.modeRandom);

      while (true) {
        const roleResult = config.tuoMode === "fixed"
          ? await chooseFixedTuoSettings(config, localSettingsPath, { allowBack: true })
          : await chooseRandomTuoSettings(config, { allowBack: true });
        if (roleResult === BACK) break;

        while (true) {
          const rangeResult = await chooseReadRange(config, { allowBack: true });
          if (rangeResult === BACK) break;

          const scheduleResult = await chooseScheduleMode(config, messages, { allowBack: true });
          if (scheduleResult === BACK) continue;
          return;
        }
      }
    }
  }
}

export async function chooseReadRange(config, options = {}) {
  if (config.promptReadRange === false) return;
  while (true) {
    const choices = [
      { key: "1", label: "全文读取", value: "all" },
      { key: "2", label: "指定开始/结束位置，只读取中间这一段", value: "range" }
    ];
    if (options.allowBack) choices.push({ key: "0", label: "返回上一步", value: BACK });
    const action = await askChoice("请选择本次读取范围", choices, config.readRange?.enabled ? "2" : "1");
    if (action === BACK) return BACK;
    if (action === "all") {
      config.readRange = { enabled: false, start: "", end: "" };
      console.log("本次读取范围：全文。");
      return;
    }

    const start = (await askText(`请输入【开始位置关键词】${options.allowBack ? "；输入 0 返回上一步" : ""}`, config.readRange?.start || "")).trim();
    if (options.allowBack && start === "0") continue;
    if (!start) {
      console.log("开始位置不能为空。");
      continue;
    }
    const end = (await askText(`请输入【结束位置关键词】${options.allowBack ? "；输入 0 返回上一步" : ""}`, config.readRange?.end || "")).trim();
    if (options.allowBack && end === "0") continue;
    if (!end) {
      console.log("结束位置不能为空。");
      continue;
    }
    config.readRange = { enabled: true, start, end };
    console.log(`本次读取范围：从「${start}」到「${end}」。`);
    return;
  }
}

async function chooseFeishuUrl(config, localSettingsPath) {
  if (config.promptFeishuUrl === false) return;
  const lastSettings = await loadLocalSettings(localSettingsPath);
  const savedUrl = normalizeFeishuUrl(lastSettings.feishuUrl);
  const configUrl = normalizeFeishuUrl(config.feishuUrl);
  const current = savedUrl || configUrl;
  const savedTitle = String(lastSettings.feishuTitle || "").trim();
  if (savedTitle || current) {
    console.log("\n上次主飞书文档：");
    console.log(`标题：${savedTitle || "未读取标题"}`);
    if (current) console.log(`链接：${current}`);
  }
  while (true) {
    const raw = await askText("请输入【主飞书文档链接】；直接回车=使用上面这个文档；粘贴新链接=切换文档；输入 q 退出", current || "");
    if (["q", "quit", "exit"].includes(raw.trim().toLowerCase())) return EXIT;
    const nextUrl = normalizeFeishuUrl(raw || current);
    if (nextUrl) {
      config.feishuUrl = nextUrl;
      await saveLastFeishuUrl(localSettingsPath, nextUrl);
      console.log(`当前飞书链接：${config.feishuUrl}`);
      return;
    }
    console.log("飞书链接识别不了，请重新粘贴完整链接。");
  }
}

async function chooseTuoMode(config, messages, options = {}) {
  if (config.promptTuoMode === false) return config.tuoMode || "random";
  const choices = [
    { key: "1", label: messages.randomVersion, value: "random" },
    { key: "2", label: messages.fixedVersion, value: "fixed" }
  ];
  if (options.allowBack) choices.push({ key: "0", label: "返回上一步", value: BACK });
  return askChoice(
    messages.selectVersion,
    choices,
    config.tuoMode === "fixed" ? "2" : "1"
  );
}

async function chooseRandomTuoSettings(config, options = {}) {
  const choices = [
    { key: "1", label: "遇到不在群：自动更换机器人重试 3 次；仍不行再问我", value: "retry" },
    { key: "2", label: "遇到不在群：不更换机器人，直接按当前机器人确认创建", value: "confirm" }
  ];
  if (options.allowBack) choices.push({ key: "0", label: "返回上一步", value: BACK });
  const action = await askChoice(
    "粗略版遇到机器人不在群时，怎么处理？",
    choices,
    config.randomRobotNotInGroupAction === "confirm" ? "2" : "1"
  );
  if (action === BACK) return BACK;
  config.randomRobotNotInGroupAction = action;
  config.ignoreRobotNotInGroup = action === "confirm";
  console.log(action === "confirm"
    ? "粗略版：遇到不在群会直接确认创建，不自动更换机器人。"
    : "粗略版：遇到不在群会自动更换机器人重试 3 次；仍不行时，会在当前步骤窗口问你怎么处理。");
}

async function chooseFixedTuoSettings(config, localSettingsPath, options = {}) {
  const localSettings = await loadLocalSettings(localSettingsPath);
  let oldPrefix = String(localSettings.fixedRolePrefix || config.roles?.tuo?.fixedRolePrefix || config.fixedRolePrefix || "").trim();
  while (true) {
    const prefix = (await askText(`请输入【精细版角色范围/前缀】，例如：老群GJ、108老群GJ、某组宝妈${options.allowBack ? "；输入 0 返回上一步" : ""}${oldPrefix ? `；直接回车使用上次：${oldPrefix}` : ""}`, oldPrefix || "")).trim();
    if (options.allowBack && prefix === "0") return BACK;
    if (prefix) {
      config.fixedRolePrefix = prefix;
      config.roles = config.roles || {};
      config.roles.tuo = config.roles.tuo || {};
      config.roles.tuo.fixedRolePrefix = prefix;
      await saveFixedRolePrefix(localSettingsPath, prefix);
      oldPrefix = prefix;
      console.log(`本次精细托角色范围：${prefix}`);
    } else {
      console.log("精细版必须填写本次要使用的角色范围/前缀。");
      continue;
    }

    const oldSheetUrl = normalizeFeishuUrl(localSettings.fixedRoleSheetUrl || config.fixedRoleSheetUrl);
    const oldSheetTitle = String(localSettings.fixedRoleSheetTitle || "").trim();
    if (oldSheetUrl) {
      console.log("\n上次托号登记表：");
      console.log(`标题：${oldSheetTitle || "未读取标题"}`);
      console.log(`链接：${oldSheetUrl}`);
    }
    while (true) {
      const raw = await askText(`请输入【托号登记表飞书链接】${oldSheetUrl ? "；直接回车使用上次托号表" : "；没有就直接回车跳过"}；输入 skip/无/不用 可跳过${options.allowBack ? "；输入 0 返回上一步" : ""}`, oldSheetUrl || "");
      if (options.allowBack && raw.trim() === "0") break;
      if (["skip", "无", "不用"].includes(raw.trim().toLowerCase())) {
        config.fixedRoleSheetUrl = "";
        console.log("本次不使用托号登记表。");
        return;
      }
      if (!raw.trim() && !oldSheetUrl) {
        config.fixedRoleSheetUrl = "";
        console.log("本次不使用托号登记表。");
        return;
      }
      const sheetUrl = normalizeFeishuUrl(raw);
      if (sheetUrl) {
        config.fixedRoleSheetUrl = sheetUrl;
        await saveFixedRoleSheet(localSettingsPath, sheetUrl, oldSheetUrl === sheetUrl ? oldSheetTitle : "");
        console.log(`本次托号登记表：${sheetUrl}`);
        return;
      }
      console.log("托号登记表链接不对，请重新粘贴飞书表格链接。");
    }
  }
}

async function chooseScheduleMode(config, messages, options = {}) {
  if (config.promptScheduleMode === false) {
    config.scheduleMode = config.scheduleMode || "doc";
    return;
  }

  while (true) {
    const choices = [
      { key: "1", label: messages.docTimeMode, value: "doc" },
      { key: "2", label: messages.realtimeMode, value: "realtime" },
      { key: "3", label: "补发到文档时间：过期内容实时补发，后面能接上就回到飞书时间", value: "catchup" }
    ];
    if (options.allowBack) choices.push({ key: "0", label: "返回上一步", value: BACK });
    config.scheduleMode = await askChoice(
      messages.selectTimeMode,
      choices,
      config.scheduleMode === "realtime" ? "2" : config.scheduleMode === "catchup" ? "3" : "1"
    );
    if (config.scheduleMode === BACK) return BACK;

    if (config.scheduleMode !== "realtime" && config.scheduleMode !== "catchup") return;
    const defaultStart = config.realtimeStartTime || secondsToClock(currentAbsoluteSeconds() + Number(config.realtimeMinLeadSeconds ?? 60));
    const startTime = await askText(`${messages.realtimeStartPrompt}${options.allowBack ? "；输入 0 返回上一步" : ""}`, defaultStart);
    if (options.allowBack && startTime.trim() === "0") continue;
    config.realtimeStartTime = startTime;
    if (config.scheduleMode === "realtime") {
      const endTime = await askText(`${messages.realtimeEndPrompt}${options.allowBack ? "；输入 0 返回上一步" : ""}`, config.realtimeEndTime || "");
      if (options.allowBack && endTime.trim() === "0") continue;
      config.realtimeEndTime = endTime;
    }
    return;
  }
}

function currentAbsoluteSeconds() {
  const now = new Date();
  return now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
}

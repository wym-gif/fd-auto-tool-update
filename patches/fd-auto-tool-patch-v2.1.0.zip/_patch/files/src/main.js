﻿import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { chromium } from "playwright";
import { writeRunAudit } from "./audit/run-audit.js";
import { createRunControl } from "./control.js";
import { checkCmsTaskList, createCmsTasks, prepareCmsPages } from "./cms.js";
import { readFeishuTasks } from "./feishu.js";
import { chooseSettingsInBrowser } from "./control-ui.js";
import { reviewPreviewInBrowser } from "./preview-ui.js";
import {
  loadLatestPreviewData,
  loadLatestPreviewTasksFromData,
  saveLatestPreview,
  saveRunPreview
} from "./preview/preview-state.js";
import { previewSelfCheck, printPreviewReadySummary } from "./preview/self-check.js";
import {
  taskDocAbsoluteSeconds,
  orderTasksForTiming,
  buildInteractionSpanByPosition,
  boundaryGapSecondsFromItems,
  gapBetweenOrderedItems,
  gapBetweenTasks,
  buildStartSuggestion,
  formatDuration,
  buildRealtimeGaps,
  buildRealtimeGapsFromItems,
  planRealtimeGaps,
  planRealtimeGapsBetween,
  sumGaps,
  sumNumbers,
  normalizeStretchMinute,
  parseClockToAbsoluteSeconds,
  currentAbsoluteSeconds,
  timeToSeconds,
  secondsToTime,
  applyAbsoluteSchedule
} from "./schedule/task-schedule.js";
import {
  normalizeFeishuUrl,
  rememberCurrentFeishuDocument,
  saveLastFeishuUrl
} from "./settings/local-settings.js";
import {
  applyStandbyScheduleMode,
  askManualSyncConfirm,
  askRunFailureCommand,
  askWatchStandbyCommand,
  chooseInteractiveSettings,
  chooseReadRange
} from "./control/console-settings.js";
import { launchRunBat } from "./runtime/launcher.js";
import { controlledSleep } from "./runtime/sleep.js";
import {
  isBrowserTargetClosed,
  isControlStopped,
  isWatchMode,
  UserCanceledPreview
} from "./runtime/errors.js";
import { ensureDir, printTasks, readJson, shiftTimes, stamp, toAbs, askEnter, askChoice, askText, parseTime, waitEnterOrTimeout } from "./utils.js";

const ZH = {
  missingConfig: "\u6ca1\u6709\u627e\u5230 config.json\uff0c\u8bf7\u5148\u521b\u5efa config.json\u3002",
  modeRandom: "\u5f53\u524d\u6a21\u5f0f\uff1a\u7c97\u7565\u7248\uff08\u968f\u673a\u6258\uff09",
  modeFixed: "\u5f53\u524d\u6a21\u5f0f\uff1a\u7cbe\u7ec6\u7248\uff08\u56fa\u5b9a\u6258\uff09",
  fixedNotReady: "\u7cbe\u7ec6\u56fa\u5b9a\u6258\u7248\u672c\u5165\u53e3\u5df2\u6253\u5f00\uff0c\u4f46\u56fa\u5b9a\u89d2\u8272\u5206\u914d\u8fd8\u6ca1\u63a5\u597d\u3002\u8bf7\u5148\u9009 1 \u4f7f\u7528\u5f53\u524d\u7a33\u5b9a\u7684\u7c97\u7565\u7248\u3002",
  readingFeishu: "\u6b63\u5728\u8bfb\u53d6\u98de\u4e66\u6587\u6863...",
  previewSaved: "\u9884\u89c8\u5df2\u4fdd\u5b58",
  previewOnly: "\u5f53\u524d\u53ea\u662f\u9884\u89c8\uff0c\u6ca1\u6709\u521b\u5efa\u53d1\u5355\u4efb\u52a1\u3002\u68c0\u67e5\u65e0\u8bef\u540e\u518d\u8fd0\u884c run.bat\u3002",
  previewFinished: "\u9884\u89c8\u7ed3\u675f",
  watchStarted: "\u5df2\u5f00\u59cb\u76d1\u63a7\u98de\u4e66\u6587\u6863\uff0c\u53d1\u73b0\u5185\u5bb9\u53d8\u5316\u4f1a\u81ea\u52a8\u91cd\u65b0\u751f\u6210\u9884\u89c8\u3002",
  watchNoChange: "\u98de\u4e66\u5185\u5bb9\u6ca1\u6709\u53d8\u5316",
  watchChanged: "\u53d1\u73b0\u98de\u4e66\u5185\u5bb9\u53d8\u5316\uff0c\u7b49\u5f85\u4f60\u786e\u8ba4\u540e\u518d\u540c\u6b65\u3002",
  watchSaved: "\u65b0\u9884\u89c8\u5df2\u4fdd\u5b58",
  latestPreviewSaved: "\u5df2\u540c\u6b65\u5230 run \u53ef\u76f4\u63a5\u4f7f\u7528\u7684\u6700\u65b0\u9884\u89c8",
  latestPreviewUsed: "\u5df2\u4f7f\u7528\u76d1\u63a7\u9884\u89c8\u7684\u6700\u65b0\u7ed3\u679c\uff0c\u672c\u6b21\u4e0d\u91cd\u65b0\u8bfb\u98de\u4e66",
  latestPreviewMissing: "\u6ca1\u6709\u627e\u5230\u76d1\u63a7\u9884\u89c8\u7ed3\u679c\uff0c\u6539\u4e3a\u73b0\u573a\u8bfb\u98de\u4e66",
  loadLatestAfterSetup: "\u6b63\u5728\u51c6\u5907\u9884\u89c8\u6570\u636e\uff0c\u4f1a\u5148\u8ba9\u4f60\u786e\u8ba4\u9884\u89c8\uff0c\u518d\u53bb\u51c6\u5907\u53d1\u5355\u9875\u9762",
  watchHint: "\u4fdd\u6301\u8fd9\u4e2a\u7a97\u53e3\u5f00\u7740\u5c31\u4f1a\u7ee7\u7eed\u76d1\u63a7\uff1b\u53ef\u4ee5\u5728\u53d1\u5355\u63a7\u5236\u53f0\u70b9\u6682\u505c\u3001\u7ee7\u7eed\u6216\u505c\u6b62\u3002",
  confirmReady: "\u786e\u8ba4\u9884\u89c8\u65e0\u8bef\uff0c\u5e76\u4e14\u53d1\u5355\u9875\u9762\u5df2\u51c6\u5907\u597d",
  allDone: "\u5168\u90e8\u5904\u7406\u5b8c\u6210\uff0c\u7ed3\u679c\u5df2\u4fdd\u5b58",
  checkBeforeClose: "\u7ed3\u675f\u524d\u68c0\u67e5\u9875\u9762",
  runFailed: "\u8fd0\u884c\u5931\u8d25\uff1a",
  selectVersion: "\u8bf7\u9009\u62e9\u53d1\u5355\u7248\u672c",
  randomVersion: "\u7c97\u7565\u7248\uff1a\u968f\u673a\u6258\uff08\u5f53\u524d\u7a33\u5b9a\uff09",
  fixedVersion: "\u7cbe\u7ec6\u7248\uff1a\u56fa\u5b9a\u6258\uff08\u9009\u8001\u7fa4GJ\u89d2\u8272\u8303\u56f4\u540e\u66f4\u6362\uff09",
  selectTimeMode: "\u8bf7\u9009\u62e9\u65f6\u95f4\u6a21\u5f0f",
  docTimeMode: "\u6587\u6863\u65f6\u95f4\uff1a\u6309\u98de\u4e66\u4e0a\u9762\u7684\u65f6\u95f4\u5b9a",
  realtimeMode: "\u5b9e\u65f6\u8ddf\u53d1\uff1a\u5ffd\u7565\u6587\u6863\u65f6\u95f4\uff0c\u6309\u4f60\u8f93\u5165\u7684\u5f00\u59cb/\u7ed3\u675f\u65f6\u95f4\u91cd\u65b0\u6392",
  realtimeStartPrompt: "\u8bf7\u8f93\u5165\u5b9e\u65f6\u8ddf\u53d1\u5f00\u59cb\u65f6\u95f4\uff08\u4f8b\u5982 10:30:00\uff09",
  realtimeEndPrompt: "\u8bf7\u8f93\u5165\u5b9e\u65f6\u8ddf\u53d1\u7ed3\u675f\u65f6\u95f4\uff08\u53ef\u7559\u7a7a\uff09"
};

const rootDir = path.resolve(process.cwd());
const mode = process.argv[2] || "preview";
const configPath = path.resolve(rootDir, "config.json");
const localSettingsPath = path.resolve(rootDir, "last-settings.json");
async function main() {
  const config = await readJson(configPath).catch(async () => {
    throw new Error(ZH.missingConfig);
  });

  const profileDir = toAbs(rootDir, config.profileDir || "./browser-profile");
  const context = await chromium.launchPersistentContext(profileDir, {
    headless: Boolean(config.headless) === true,
    viewport: { width: 1440, height: 1000 }
  });

  try {
  const latestPreviewData = mode === "run" || (isWatchMode(mode) && process.env.FD_REUSE_LATEST_SETTINGS === "1")
    ? await loadLatestPreviewData(rootDir, config, { silent: true, missingMessage: ZH.latestPreviewMissing })
    : null;
  if (latestPreviewData) {
    applyLatestPreviewMeta(config, latestPreviewData);
          console.log("监控预览已确认，准备开始运行。");
    console.log(config.tuoMode === "fixed" ? ZH.modeFixed : ZH.modeRandom);
  } else {
    await chooseStartupSettings(context, config);
  }

  const runDir = path.resolve(rootDir, config.outputDir || "./runs", stamp());
  await ensureDir(runDir);

    if (isWatchMode(mode)) {
      await watchPreview(context, config);
      return;
    }

    if (mode === "run") {
      await runLatestPreviewInContext(context, config, latestPreviewData, { pauseAtEnd: true, runDir });
      await askEnter(ZH.checkBeforeClose);
      return;
    }

    let tasks = null;
    let previewPath = "";
    while (true) {
      const feishuPage = await context.newPage();
      console.log(ZH.readingFeishu);
      tasks = await readFeishuTasks(feishuPage, config, runDir, { dropFailedMedia: false });
      await rememberCurrentFeishuDocument(localSettingsPath, feishuPage, config);
      tasks = await prepareTasksForScheduleMode(tasks, config);
      tasks = await previewSelfCheck(tasks, config, runDir, "预览生成后", { feishuPage, localSettingsPath, prepareTasksForScheduleMode });
      previewPath = await saveRunPreview(runDir, tasks);
      const review = await maybeReviewPreview(context, tasks, config, runDir, previewPath, "预览生成后");
      if (review.action === "monitor") {
        console.log("已在可视化预览页取消，本轮不继续执行。");
        return;
      }
      if (review.action === "refresh") {
        console.log("已选择重新读取飞书，正在按最新设置重新生成预览。");
        continue;
      }
      tasks = review.tasks;
      printTasks(tasks);
      console.log(`\n${ZH.previewSaved}: ${previewPath}`);
      printPreviewReadySummary(tasks, config, previewPath);
      break;
    }

    if (mode === "preview") {
      console.log(`\n${ZH.previewOnly}`);
      await askEnter(ZH.previewFinished);
      return;
    }

    if (config.confirmBeforeRun !== false) {
      await askEnter(ZH.confirmReady);
    }
  } finally {
    await context.close().catch(() => {});
  }
}

async function chooseStartupSettings(context, config) {
  if (config.visualControlPanel === false) {
    await chooseInteractiveSettings(config, { localSettingsPath, messages: ZH });
    return { action: "continue" };
  }
  const result = await chooseSettingsInBrowser(context, config);
  if (result.action === "fallback") {
    await chooseInteractiveSettings(config, { localSettingsPath, messages: ZH });
    return { action: "continue" };
  }
  if (result.action === "exit") throw new UserCanceledPreview("已退出。");
  return result;
}

async function watchPreview(context, config) {
  let feishuPage = await context.newPage();
  const control = await createRunControl(context, config);
  config.__runControl = control;
  await control.setCurrent("监控飞书：准备中");
  const intervalSeconds = Math.max(10, Number(config.watchIntervalSeconds || config.monitorIntervalSeconds || 30));
  const watchDir = path.resolve(rootDir, config.outputDir || "./runs", `watch_${stamp()}`);
  await ensureDir(watchDir);

  let lastHash = "";
  let round = 0;
  let confirmedByCommand = false;
  console.log(`\n${ZH.watchStarted}`);
        console.log(`检查间隔：${intervalSeconds} 秒`);
  console.log(ZH.watchHint);

  while (true) {
    round += 1;
    console.log(`\n[${new Date().toLocaleTimeString()}] 正在检查飞书...`);
    try {
      await control.checkpoint("正在检查飞书");
      await control.setCurrent("正在读取飞书");
      feishuPage = await ensureFeishuPageOpen(context, feishuPage, config, control);
      let scanTasks = await readFeishuTasks(feishuPage, config, watchDir, {
        downloadMediaFiles: false,
        dropFailedMedia: false
      });
      await rememberCurrentFeishuDocument(localSettingsPath, feishuPage, config);
      const hash = taskFingerprint(scanTasks);
      const forceGenerate = !lastHash || confirmedByCommand;
      if (!lastHash) {
        lastHash = hash;
        console.log("已读取当前飞书，直接生成本轮预览。");
      }
      if (!forceGenerate && hash === lastHash) {
        console.log(`${ZH.watchNoChange}；${intervalSeconds} 秒后再看。`);
      } else {
        if (forceGenerate) {
          console.log("已收到继续指令，正在重新读取飞书最新内容。");
          confirmedByCommand = false;
        } else {
          console.log(ZH.watchChanged);
          if (config.manualSyncBeforePreview !== false) {
            const syncCommand = await askManualSyncConfirm(config);
            if (syncCommand.action === "exit") return;
            if (syncCommand.feishuUrl) {
              config.feishuUrl = syncCommand.feishuUrl;
            await saveLastFeishuUrl(localSettingsPath, config.feishuUrl);
            console.log(`已切换飞书链接：${config.feishuUrl}`);
            feishuPage = await ensureFeishuPageOpen(context, feishuPage, config, control);
            await feishuPage.goto(config.feishuUrl, { waitUntil: "domcontentloaded" });
            await feishuPage.waitForTimeout(2000);
            await chooseReadRange(config, { allowBack: false });
            lastHash = "";
          }
          }
        }
        if (!forceGenerate && config.manualSyncBeforePreview !== false) {
          feishuPage = await ensureFeishuPageOpen(context, feishuPage, config, control);
          scanTasks = await readFeishuTasks(feishuPage, config, watchDir, {
            downloadMediaFiles: false,
            dropFailedMedia: false
          });
          await rememberCurrentFeishuDocument(localSettingsPath, feishuPage, config);
          const confirmedHash = taskFingerprint(scanTasks);
          if (lastHash && confirmedHash === lastHash) console.log("重新读取后内容没有变化，继续使用当前预览。");
          lastHash = confirmedHash;
        } else {
          lastHash = hash;
        }
        const runDir = path.join(watchDir, `${String(round).padStart(3, "0")}_${stamp()}`);
        await ensureDir(runDir);
        await control.setCurrent("正在扫描正文和素材");
        feishuPage = await ensureFeishuPageOpen(context, feishuPage, config, control);
        let tasks = await readFeishuTasks(feishuPage, config, runDir, { dropFailedMedia: false });
        await rememberCurrentFeishuDocument(localSettingsPath, feishuPage, config);
        await control.setCurrent("正在生成预览");
        tasks = await prepareTasksForScheduleMode(tasks, config);
        tasks = await previewSelfCheck(tasks, config, runDir, "监控预览生成后", { feishuPage, localSettingsPath, prepareTasksForScheduleMode });
        const previewPath = await saveRunPreview(runDir, tasks);
        const review = await maybeReviewPreview(context, tasks, config, runDir, previewPath, "监控预览生成后");
        if (review.action === "monitor") {
          console.log("已在可视化预览页取消，本轮回到监控。");
          continue;
        }
        if (review.action === "refresh") {
          console.log("已在可视化预览页选择重新读取飞书。");
          lastHash = "";
          confirmedByCommand = true;
          continue;
        }
        tasks = review.tasks;
        const latestPath = await saveLatestPreview(rootDir, config, {
          updatedAt: new Date().toISOString(),
          sourcePreviewPath: previewPath,
          feishuUrl: config.feishuUrl,
          projectType: config.projectType || "collection",
          tuoMode: config.tuoMode || "random",
          randomRobotNotInGroupAction: config.randomRobotNotInGroupAction || "retry",
          randomSkipAfterNotInGroupRetry: Boolean(config.randomSkipAfterNotInGroupRetry),
          scheduleMode: config.scheduleMode || "doc",
          fixedRolePrefix: config.roles?.tuo?.fixedRolePrefix || config.fixedRolePrefix || "",
          fixedRoleSheetUrl: config.fixedRoleSheetUrl || "",
          realtimeStartTime: config.realtimeStartTime || "",
          realtimeEndTime: config.realtimeEndTime || "",
          realtimeEndMode: config.realtimeEndMode === "stretch" ? "stretch" : "latest",
          stretchGapMinMinutes: normalizeStretchMinute(config.stretchGapMinMinutes, 2),
          stretchGapMaxMinutes: normalizeStretchMinute(config.stretchGapMaxMinutes, 23),
          realtimeRoleSwitchGapSeconds: Number(config.realtimeRoleSwitchGapSeconds ?? 120),
          customIntervals: config.customIntervals || {},
          tasks
        });
        printTasks(tasks);
        if (config.scheduleMode === "realtime") printStartSuggestion(tasks, config);
        console.log(`\n${ZH.watchSaved}: ${previewPath}`);
        console.log(`${ZH.latestPreviewSaved}: ${latestPath}`);
        printPreviewReadySummary(tasks, config, previewPath);
        if (config.autoOpenRunAfterWatchPreview !== false) {
          console.log("监控预览已确认，准备开始运行。");
          console.log("本次在同一个黑窗口运行，不再额外打开第二个窗口。");
          if (config.openRunInNewWindow === true) {
            await context.close();
            launchRunBat(rootDir);
          } else {
            let runFailed = false;
            while (true) {
              try {
                await runLatestPreviewInContext(context, config, {
                  updatedAt: new Date().toISOString(),
                  sourcePreviewPath: previewPath,
                  projectType: config.projectType || "collection",
                  tasks
                }, { control });
                runFailed = false;
                break;
              } catch (error) {
                if (error?.userCanceledPreview) {
                  console.log(error.message || "已回到监控。");
                  runFailed = false;
                  break;
                }
                runFailed = true;
                console.log(`\n运行失败：${error.message || error}`);
                const action = await askRunFailureCommand();
                if (action === "retry") {
                  console.log("正在重试当前预览。请先检查云中客页面是否还停在创建任务页。");
                  continue;
                }
                if (action === "exit") return;
                break;
              }
            }
            if (runFailed) {
              confirmedByCommand = false;
              continue;
            }
            if (config.waitCommandAfterRun !== false) {
              const command = await askWatchStandbyCommand(config, control);
              if (command.action === "exit") return;
              let shouldOpenSettingsPage = false;
              if (command.scheduleMode) {
                await applyStandbyScheduleMode(config, command.scheduleMode, ZH);
                shouldOpenSettingsPage = true;
              }
              if (command.feishuUrl) {
                config.feishuUrl = command.feishuUrl;
                await saveLastFeishuUrl(localSettingsPath, config.feishuUrl);
                console.log(`当前飞书链接：${config.feishuUrl}`);
                shouldOpenSettingsPage = true;
              }
              if (shouldOpenSettingsPage) {
                console.log("已切换设置，请在可视化设置页确认读取范围和时间模式。");
                await chooseStartupSettings(context, config);
              }
              lastHash = "";
              confirmedByCommand = true;
            }
          }
          continue;
        }
      }
    } catch (error) {
      if (error?.previewRestartRequested) {
        console.log("已收到放弃本轮请求，已回到设置页。请修改后点“保存设置，生成预览”。");
        control.consumePreviewRestart?.();
        await chooseStartupSettings(context, config);
        lastHash = "";
        confirmedByCommand = true;
        continue;
      }
      if (error?.userCanceledPreview) {
        console.log(error.message || "已取消本次预览。");
        await controlledSleep(control, intervalSeconds * 1000, `监控飞书：等待 ${intervalSeconds} 秒后再检查`);
        continue;
      }
      if (isControlStopped(error)) {
        console.log(error.message);
        return;
      }
      if (isBrowserTargetClosed(error)) {
        try {
          feishuPage = await reopenFeishuPage(context, config, control);
          lastHash = "";
          confirmedByCommand = true;
          console.log("飞书页面已自动重新打开，下一轮会重新读取。");
        } catch (reopenError) {
          await control.setCurrent("飞书页面已关闭，请重新打开文档或重新读取");
          console.log(`自动重新打开飞书失败：${reopenError.message || reopenError}`);
        }
      }
      console.log(`监控读取失败：${error.message || error}`);
      await waitEnterOrTimeout(`按回车立即重新监控一次；不操作则 ${intervalSeconds} 秒后自动重试。`, intervalSeconds * 1000);
      continue;
    }
    await controlledSleep(control, intervalSeconds * 1000, `监控飞书：等待 ${intervalSeconds} 秒后再检查`);
  }
}

async function ensureFeishuPageOpen(context, page, config, control = null) {
  if (page && !page.isClosed?.()) return page;
  return reopenFeishuPage(context, config, control);
}

async function reopenFeishuPage(context, config, control = null) {
  const feishuUrl = normalizeFeishuUrl(config.feishuUrl || config.feishuTitleUrl);
  if (!feishuUrl) {
    throw new Error("没有可用的飞书链接");
  }
  await control?.setCurrent?.("飞书页面已关闭，正在自动重新打开");
  console.log("飞书页面已关闭，正在自动重新打开...");
  const page = await context.newPage();
  await page.goto(feishuUrl, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2000);
  await control?.setCurrent?.("飞书页面已重新打开，准备继续读取");
  return page;
}

async function runLatestPreviewInContext(context, config, latestPreviewData = null, options = {}) {
  const runDir = options.runDir || path.resolve(rootDir, config.outputDir || "./runs", stamp());
  await ensureDir(runDir);
  const control = options.control || await createRunControl(context, config);
  config.__runControl = control;
  config.currentRunDir = runDir;
  let pages = null;
  let tasks = null;
  let previewPath = "";
  let feishuPage = null;
  let usingConfirmedPreview = false;
  while (true) {
    console.log(`\n${ZH.loadLatestAfterSetup}`);
    if (!tasks) {
      tasks = await loadLatestPreviewTasksFromData(rootDir, config, runDir, latestPreviewData, {
        usedMessage: ZH.latestPreviewUsed,
        missingMessage: ZH.latestPreviewMissing
      });
      usingConfirmedPreview = Boolean(tasks);
    }
    if (!tasks) {
      feishuPage = await context.newPage();
      console.log(ZH.readingFeishu);
      tasks = await readFeishuTasks(feishuPage, config, runDir, { dropFailedMedia: false });
      await rememberCurrentFeishuDocument(localSettingsPath, feishuPage, config);
      tasks = await prepareTasksForScheduleMode(tasks, config);
      usingConfirmedPreview = false;
    }
    tasks = await previewSelfCheck(tasks, config, runDir, "正式执行前", {
      localSettingsPath,
      prepareTasksForScheduleMode,
      feishuPage,
      preserveConfirmedPreviewTiming: usingConfirmedPreview
    });
    previewPath = await saveRunPreview(runDir, tasks);
    const review = await maybeReviewPreview(context, tasks, config, runDir, previewPath, "正式执行前");
    if (review.action === "monitor") {
      throw new UserCanceledPreview("已在可视化预览页取消，本轮没有创建发单任务。");
    }
    if (review.action === "refresh") {
      latestPreviewData = null;
      tasks = null;
      usingConfirmedPreview = false;
      console.log("已在可视化预览页选择重新读取飞书。");
      continue;
    }
    tasks = review.tasks;
    usingConfirmedPreview = true;
    printTasks(tasks);
    console.log(`\n${ZH.previewSaved}: ${previewPath}`);
    printPreviewReadySummary(tasks, config, previewPath);
    pages = await prepareCmsPages(context, config);
    const setupAction = config.__cmsSetupAction || "continue";
    config.__cmsSetupAction = "";
    if (setupAction === "monitor") {
      throw new UserCanceledPreview("已回到监控，本轮没有创建发单任务。");
    }
    if (setupAction === "refresh") {
      latestPreviewData = null;
      tasks = null;
      usingConfirmedPreview = false;
      pages = null;
      console.log("已选择重新生成预览：会按当前时间重新读取飞书并重排。");
      continue;
    }
    break;
  }
  let results = [];
  try {
    results = await createCmsTasks(pages, tasks, config, control);
  } catch (error) {
    const partialResults = Array.isArray(config.__latestTaskResults) ? config.__latestTaskResults : [];
    await writeRunAudit(runDir, tasks, partialResults, { error });
    throw error;
  }
  const resultPath = path.join(runDir, "result.json");
  await fs.writeFile(resultPath, JSON.stringify(results, null, 2), "utf8");
  await writeRunAudit(runDir, tasks, results);
  await maybeCheckTaskList(context, config, tasks, results, runDir);
  console.log(`\n${ZH.allDone}: ${resultPath}`);
  return results;
}

async function maybeCheckTaskList(context, config, tasks, results, runDir) {
  if (config.promptTaskListCheck !== true) return;
  const action = await askChoice(
    "本轮定时已创建完成，是否现在检查云中客任务列表？",
    [
      { key: "1", label: "检查任务列表，只输出检查结果", value: "check" },
      { key: "2", label: "不检查，直接结束", value: "skip" }
    ],
    "2"
  );
  if (action !== "check") return;

  console.log("\n正在打开任务列表并检查本轮创建结果...");
  try {
    const report = await checkCmsTaskList(context, config, tasks, results);
    const textPath = path.join(runDir, "task-list-check.txt");
    const csvPath = path.join(runDir, "task-list-check.csv");
    await fs.writeFile(textPath, report.text, "utf8");
    await fs.writeFile(csvPath, report.csv, "utf8");
    printTaskListCheckSummary(report, textPath);
  } catch (error) {
    console.log(`任务列表检查失败：${error.message || error}`);
  }
}

function printTaskListCheckSummary(report, textPath) {
  console.log(`\n任务列表检查已保存：${textPath}`);
  console.log(`检查结果：匹配 ${report.matchedRows.length} 条，疑似漏定 ${report.missingRows.length} 条，疑似错定 ${report.wrongRows.length} 条。`);
  if (report.uncertainRows.length) console.log(`需要人工看一眼：${report.uncertainRows.length} 条。`);
  if (report.problemRows.length) {
    console.log("需要重点检查：");
    for (const row of report.problemRows.slice(0, 12)) {
      console.log(`- ${row.status}：${row.label}${row.message ? ` / ${row.message}` : ""}`);
    }
    if (report.problemRows.length > 12) console.log(`还有 ${report.problemRows.length - 12} 条，详见检查文件。`);
  } else {
    console.log("任务列表检查通过：没有发现明显漏定或错定。");
  }
}

function applyLatestPreviewMeta(config, data) {
  const previewFeishuUrl = normalizeFeishuUrl(data.feishuUrl);
  if (previewFeishuUrl) {
      console.log(`当前飞书链接：${config.feishuUrl}`);
  }
  config.projectType = data.projectType === "featured" ? "featured" : (config.projectType || "collection");
  config.tuoMode = data.tuoMode || config.tuoMode || "random";
  if (typeof data.randomRobotNotInGroupAction === "string") {
    config.randomRobotNotInGroupAction = data.randomRobotNotInGroupAction;
    config.ignoreRobotNotInGroup = data.randomRobotNotInGroupAction === "confirm";
  }
  if (data.randomSkipAfterNotInGroupRetry !== undefined) {
    config.randomSkipAfterNotInGroupRetry = Boolean(data.randomSkipAfterNotInGroupRetry);
  }
  config.scheduleMode = data.scheduleMode || config.scheduleMode || "doc";
  if (typeof data.fixedRolePrefix === "string" && data.fixedRolePrefix.trim()) {
    config.fixedRolePrefix = data.fixedRolePrefix.trim();
    config.roles = config.roles || {};
    config.roles.tuo = config.roles.tuo || {};
    config.roles.tuo.fixedRolePrefix = config.fixedRolePrefix;
  }
  if (typeof data.fixedRoleSheetUrl === "string" && data.fixedRoleSheetUrl.trim()) {
    config.fixedRoleSheetUrl = data.fixedRoleSheetUrl.trim();
  }
  if (typeof data.realtimeStartTime === "string") config.realtimeStartTime = data.realtimeStartTime;
  if (typeof data.realtimeEndTime === "string") config.realtimeEndTime = data.realtimeEndTime;
  if (typeof data.realtimeEndMode === "string") config.realtimeEndMode = data.realtimeEndMode === "stretch" ? "stretch" : "latest";
  if (data.stretchGapMinMinutes !== undefined) config.stretchGapMinMinutes = normalizeStretchMinute(data.stretchGapMinMinutes, 2);
  if (data.stretchGapMaxMinutes !== undefined) config.stretchGapMaxMinutes = normalizeStretchMinute(data.stretchGapMaxMinutes, 23);
  if (data.realtimeRoleSwitchGapSeconds !== undefined) {
    config.realtimeRoleSwitchGapSeconds = Number(data.realtimeRoleSwitchGapSeconds);
  }
  if (data.customIntervals && typeof data.customIntervals === "object") {
    config.customIntervals = data.customIntervals;
  }
}

async function prepareTasksForScheduleMode(tasks, config) {
  const mode = config.scheduleMode || (config.useDocTimes ? "doc" : "legacy");
  if (mode === "doc") return tasks;
  if (mode === "realtime") return await applyRealtimeFollowTimes(tasks, config);
  if (mode === "catchup") return await applyCatchupToDocTimes(tasks, config);
  if (mode === "legacy" && config.startTime) return shiftTimes(tasks, config.startTime);
  return tasks;
}

async function maybeReviewPreview(context, tasks, config, runDir, previewPath, phase) {
  if (config.visualPreviewEditor === false || !Array.isArray(tasks) || !tasks.length) {
    return { action: "continue", tasks };
  }
  const control = await createRunControl(context, config);
  await control.setCurrent?.("预览已生成，等待确认");
  const restartWatcher = createPreviewRestartWatcher(control);
  let result;
  try {
    result = await reviewPreviewInBrowser(context, tasks, {
      runDir,
      previewPath,
      phase,
      title: "妙券自动发单🚀 - 预览确认",
      externalActionPromise: restartWatcher.promise
    });
  } finally {
    restartWatcher.stop();
  }
  if (result.action === "settings") {
    console.log("已选择返回上一页修改设置。请在设置页改好后点“保存设置，生成预览”，程序会重新读取并生成预览。");
    await chooseStartupSettings(context, config);
    return { action: "refresh", tasks };
  }
  if (result.action === "continue" && Array.isArray(result.tasks)) {
    await fs.writeFile(previewPath, JSON.stringify(result.tasks, null, 2), "utf8");
    console.log(`可视化预览已保存：${previewPath}`);
    return { action: "continue", tasks: result.tasks };
  }
  return {
    action: result.action || "continue",
    tasks: Array.isArray(result.tasks) ? result.tasks : tasks
  };
}

function createPreviewRestartWatcher(control) {
  let stopped = false;
  const promise = new Promise((resolve) => {
    const tick = () => {
      if (stopped) return;
      if (control?.consumePreviewRestart?.()) {
        resolve({ action: "settings" });
        return;
      }
      setTimeout(tick, 300);
    };
    tick();
  });
  return {
    promise,
    stop() {
      stopped = true;
    }
  };
}

async function applyCatchupToDocTimes(tasks, config) {
  if (!tasks.length) return tasks;
  const nowAbs = currentAbsoluteSeconds();
  const minLeadSeconds = Number(config.realtimeMinLeadSeconds ?? 60);
  const startAbs = Math.max(
    parseClockToAbsoluteSeconds(config.realtimeStartTime) ?? nowAbs + minLeadSeconds,
    nowAbs + minLeadSeconds
  );
  const decision = chooseCatchupPlan(tasks, config, startAbs);
  printCatchupPlan(decision);

  let useCompressed = decision.mode === "compressed";
  if (decision.needConfirm) {
    const answer = await askChoice(
      "补发会影响后面的文档时间，是否使用压缩补发？",
      [
        { key: "1", label: "使用压缩补发", value: "yes" },
        { key: "2", label: "不用压缩，按正常间隔", value: "no" },
        { key: "0", label: "取消本次预览，回到监控待命", value: "cancel" }
      ],
      "1"
    );
    if (answer === "cancel") throw new UserCanceledPreview("已取消本次预览，回到监控待命。");
    useCompressed = answer === "yes";
  }

  return buildCatchupTasks(tasks, config, startAbs, decision.splitIndex, useCompressed);
}

function chooseCatchupPlan(tasks, config, startAbs) {
  const orderedItems = orderTasksForTiming(tasks);
  const orderedTasks = orderedItems.map((item) => item.task);
  const spanByPosition = buildInteractionSpanByPosition(orderedItems);
  const candidates = [];
  for (let splitIndex = 0; splitIndex < orderedTasks.length; splitIndex += 1) {
    const docAbs = taskDocAbsoluteSeconds(orderedTasks[splitIndex]);
    if (docAbs > startAbs) candidates.push({ splitIndex, docAbs });
  }

  for (const candidate of candidates) {
    const normalEnd = catchupEndSecondsFromItems(orderedItems.slice(0, candidate.splitIndex), config, startAbs, false);
    const boundaryNormal = boundaryGapSecondsFromItems(
      orderedItems[candidate.splitIndex - 1],
      orderedItems[candidate.splitIndex],
      candidate.splitIndex,
      spanByPosition,
      false,
      config
    );
    if (normalEnd + boundaryNormal <= candidate.docAbs) {
      return {
        splitIndex: candidate.splitIndex,
        mode: "normal",
        needConfirm: false,
        startAbs,
        normalEnd,
        compressedEnd: catchupEndSecondsFromItems(orderedItems.slice(0, candidate.splitIndex), config, startAbs, true),
        docAbs: candidate.docAbs,
        nextTask: orderedTasks[candidate.splitIndex]
      };
    }

    const compressedEnd = catchupEndSecondsFromItems(orderedItems.slice(0, candidate.splitIndex), config, startAbs, true);
    const boundaryCompressed = boundaryGapSecondsFromItems(
      orderedItems[candidate.splitIndex - 1],
      orderedItems[candidate.splitIndex],
      candidate.splitIndex,
      spanByPosition,
      true,
      config
    );
    if (compressedEnd + boundaryCompressed <= candidate.docAbs) {
      return {
        splitIndex: candidate.splitIndex,
        mode: "compressed",
        needConfirm: true,
        startAbs,
        normalEnd,
        compressedEnd,
        docAbs: candidate.docAbs,
        nextTask: orderedTasks[candidate.splitIndex]
      };
    }
  }

  return {
    splitIndex: orderedTasks.length,
    mode: "normal",
    needConfirm: false,
    startAbs,
    normalEnd: catchupEndSecondsFromItems(orderedItems, config, startAbs, false),
    compressedEnd: catchupEndSecondsFromItems(orderedItems, config, startAbs, true),
    docAbs: null,
    nextTask: null
  };
}

function printCatchupPlan(decision) {
  console.log("\n补发到文档时间判断：");
  console.log(`- 补发开始：${secondsToTime(decision.startAbs)}`);
  if (!decision.splitIndex) {
    console.log("- 没有需要补发的任务，全部按文档时间。");
    return;
  }
  console.log(`- 前 ${decision.splitIndex} 条会作为补发任务。`);
  console.log(`- 正常补发预计到：${secondsToTime(decision.normalEnd)}`);
  console.log(`- 压缩补发预计到：${secondsToTime(decision.compressedEnd)}`);
  if (decision.nextTask) {
    console.log(`- 后面的任务会从 ${secondsToTime(decision.docAbs)} 回到文档时间。`);
  } else {
    console.log("- 后面没有可以接回的文档时间，全部按补发间隔。");
  }
  if (decision.needConfirm) {
    console.log("- 正常间隔会影响后面的文档时间，压缩后可以接上。");
  } else if (decision.mode === "normal") {
    console.log("- 正常间隔不会影响后面的文档时间。");
  }
}

function buildCatchupTasks(tasks, config, startAbs, splitIndex, useCompressed) {
  const orderedItems = orderTasksForTiming(tasks);
  const spanByPosition = buildInteractionSpanByPosition(orderedItems);
  const scheduledByCreationIndex = new Map();
  let cursor = startAbs;
  for (let index = 0; index < orderedItems.length; index += 1) {
    const item = orderedItems[index];
    if (index < splitIndex) {
      if (index > 0) cursor += gapBetweenOrderedItems(orderedItems[index - 1], item, index, spanByPosition, useCompressed, config);
      scheduledByCreationIndex.set(item.creationIndex, cursor);
    }
  }
  return tasks.map((task, index) => {
    const next = { ...task };
    if (!scheduledByCreationIndex.has(index)) return next;
    next.originalTime = next.originalTime || next.time;
    applyAbsoluteSchedule(next, scheduledByCreationIndex.get(index));
    return next;
  });
}

function catchupEndSeconds(prefixTasks, config, startAbs, compressed) {
  if (!prefixTasks.length) return startAbs;
  let cursor = startAbs;
  for (let index = 1; index < prefixTasks.length; index += 1) {
    cursor += gapBetweenTasks(prefixTasks[index - 1], prefixTasks[index], compressed, config);
  }
  return cursor;
}

function catchupEndSecondsFromItems(items, config, startAbs, compressed) {
  if (!items.length) return startAbs;
  const spanByPosition = buildInteractionSpanByPosition(items);
  let cursor = startAbs;
  for (let index = 1; index < items.length; index += 1) {
    cursor += gapBetweenOrderedItems(items[index - 1], items[index], index, spanByPosition, compressed, config);
  }
  return cursor;
}

function printStartSuggestion(tasks, config) {
  if (!tasks.length) return;
  const summary = buildStartSuggestion(tasks, config);
  console.log("\n开始时间建议：");
  console.log(`- 任务：${summary.total} 条，素材：${summary.media} 个，豆妈/托切换：${summary.roleSwitches} 次。`);
  console.log(`- 正常耗时：${formatDuration(summary.normalDuration)}；最快：${formatDuration(summary.minDuration)}。`);
  if (summary.endTime) {
    console.log(`- 你填的结束时间：${summary.endTime}`);
    console.log(`- 建议开始时间：${summary.recommendedStart} 左右`);
    console.log(`- 最晚开始时间：${summary.latestStart} 左右（再晚就会很赶）`);
  } else {
    console.log(`- 建议开始时间：${summary.recommendedStart} 左右`);
    console.log(`- 按正常节奏预计结束：${summary.recommendedEnd} 左右`);
  }
  console.log(`- 原因：${summary.reason}`);
}

async function applyRealtimeFollowTimes(tasks, config) {
  if (!tasks.length) return tasks;
  while (true) {
    const nowAbs = currentAbsoluteSeconds();
    const minLeadSeconds = Number(config.realtimeMinLeadSeconds ?? 60);
    const startAbs = Math.max(
      parseClockToAbsoluteSeconds(config.realtimeStartTime) ?? nowAbs + minLeadSeconds,
      nowAbs + minLeadSeconds
    );
    const endAbs = parseClockToAbsoluteSeconds(config.realtimeEndTime, startAbs);
    const orderedItems = orderTasksForTiming(tasks);
    const gaps = buildRealtimeGapsFromItems(orderedItems, config);
    const plannedGaps = await chooseRealtimeGapPlan(gaps, startAbs, endAbs, config);
    if (plannedGaps === "edit-time") {
      const defaultStart = secondsToTime(startAbs);
      config.realtimeStartTime = await askText("请重新输入实时跟发开始时间", defaultStart);
      config.realtimeEndTime = await askText("请重新输入实时跟发结束时间（可留空）", config.realtimeEndTime || "");
      continue;
    }
    if (plannedGaps === "cancel") throw new UserCanceledPreview("已取消本次实时跟发预览，回到监控待命。");

    let cursor = startAbs;
    const scheduledByCreationIndex = new Map();
    for (const [index, item] of orderedItems.entries()) {
      if (index > 0) cursor += plannedGaps[index - 1] || 0;
      scheduledByCreationIndex.set(item.creationIndex, cursor);
    }

    return tasks.map((task, index) => {
      const next = { ...task };
      next.originalTime = next.originalTime || next.time;
      applyAbsoluteSchedule(next, scheduledByCreationIndex.get(index));
      return next;
    });
  }
}

async function chooseRealtimeGapPlan(gaps, startAbs, endAbs, config) {
  if (!endAbs) return gaps.map((gap) => gap.normal);
  if (config.realtimeEndMode === "stretch") {
    return await chooseStretchRealtimeGapPlan(gaps, startAbs, endAbs, config);
  }
  const normalEnd = startAbs + sumGaps(gaps, "normal");
  const minEnd = startAbs + sumGaps(gaps, "min");
  const endText = secondsToTime(endAbs);
  if (normalEnd <= endAbs) {
    console.log(`实时跟发：按正常间隔可在 ${endText} 前完成，预计到 ${secondsToTime(normalEnd)}。`);
    return gaps.map((gap) => gap.normal);
  }

  if (minEnd <= endAbs) {
    console.log("\n实时跟发时间判断：");
    console.log(`- 正常间隔会排到 ${secondsToTime(normalEnd)}，超过你填的结束时间 ${endText}。`);
    console.log(`- 压缩后预计可排到 ${secondsToTime(endAbs)} 前。`);
    const answer = await askRealtimeGapChoice(config, {
      mode: "compressible",
      normalEnd: secondsToTime(normalEnd),
      minEnd: secondsToTime(minEnd),
      endTime: endText
    }, () => askChoice(
        "是否压缩间隔？",
        [
          { key: "1", label: "压缩间隔，尽量在结束时间前排完", value: "compress" },
          { key: "2", label: "不压缩，按正常间隔排（允许超过结束时间）", value: "normal" },
          { key: "0", label: "取消本次预览，回到监控待命", value: "cancel" }
        ],
        "1"
      ));
    if (answer === "cancel") return "cancel";
    if (answer === "normal") return gaps.map((gap) => gap.normal);
    return planRealtimeGaps(gaps, Math.max(0, endAbs - startAbs));
  }

  console.log("\n实时跟发时间判断：");
  console.log(`- 正常间隔会排到 ${secondsToTime(normalEnd)}。`);
  console.log(`- 已压到最短也会排到 ${secondsToTime(minEnd)}，仍超过你填的结束时间 ${endText}。`);
  console.log("- 豆妈和托切换的 2 分钟会强制保留，不会继续压缩。");
  const answer = await askRealtimeGapChoice(config, {
    mode: "too-short",
    normalEnd: secondsToTime(normalEnd),
    minEnd: secondsToTime(minEnd),
    endTime: endText
  }, () => askChoice(
      "这段时间放不下，请选择下一步",
      [
        { key: "1", label: "使用最短间隔继续排，允许超过结束时间", value: "min" },
        { key: "2", label: "重新输入开始/结束时间", value: "edit-time" },
        { key: "0", label: "取消本次预览，回到监控待命", value: "cancel" }
      ],
      "2"
    ));
  if (answer === "cancel") return "cancel";
  if (answer === "edit-time") return "edit-time";
  return gaps.map((gap) => gap.min);
}

async function chooseStretchRealtimeGapPlan(gaps, startAbs, endAbs, config) {
  if (!gaps.length) return [];
  const availableSeconds = Math.max(0, endAbs - startAbs);
  const hardMinTotal = sumGaps(gaps, "min");
  const minMinutes = normalizeStretchMinute(config.stretchGapMinMinutes, 2);
  const maxMinutes = Math.max(minMinutes, normalizeStretchMinute(config.stretchGapMaxMinutes, 23));
  const stretchMinSeconds = Math.round(minMinutes * 60);
  const stretchMaxSeconds = Math.round(maxMinutes * 60);
  const minGaps = gaps.map((gap) => gap.stretchable === false ? Number(gap.normal || gap.min || 0) : Math.max(Number(gap.min || 0), stretchMinSeconds));
  const maxGaps = gaps.map((gap) => gap.stretchable === false ? Number(gap.normal || gap.min || 0) : Math.max(Number(gap.min || 0), stretchMaxSeconds));
  const minStretchTotal = sumNumbers(minGaps);
  const maxStretchTotal = sumNumbers(maxGaps);
  const endText = secondsToTime(endAbs);

  if (availableSeconds < hardMinTotal) {
    const hardMinEnd = secondsToTime(startAbs + hardMinTotal);
    console.log("\n实时跟发时间判断：");
    console.log(`- 已压到最短也会排到 ${hardMinEnd}，仍超过你填的结束时间 ${endText}。`);
    console.log("- 豆妈和托切换的 2 分钟会强制保留，不会继续压缩。");
    const answer = await askRealtimeGapChoice(config, {
      mode: "too-short",
      normalEnd: hardMinEnd,
      minEnd: hardMinEnd,
      endTime: endText
    }, () => askChoice(
        "这段时间放不下，请选择下一步",
        [
          { key: "1", label: "使用最短间隔继续排，允许超过结束时间", value: "min" },
          { key: "2", label: "重新输入开始/结束时间", value: "edit-time" },
          { key: "0", label: "取消本次预览，回到监控待命", value: "cancel" }
        ],
        "2"
      ));
    if (answer === "cancel") return "cancel";
    if (answer === "edit-time") return "edit-time";
    return gaps.map((gap) => gap.min);
  }

  if (availableSeconds < minStretchTotal) {
    console.log("\n实时跟发铺满判断：");
    console.log(`- 按 ${minMinutes}-${maxMinutes} 分钟区间会超过 ${endText}。`);
    console.log("- 可以压缩到默认硬间隔内继续排，豆妈和托切换至少 2 分钟不变。");
    const answer = await askRealtimeGapChoice(config, {
      mode: "compressible",
      normalEnd: secondsToTime(startAbs + minStretchTotal),
      minEnd: secondsToTime(startAbs + hardMinTotal),
      endTime: endText
    }, () => askChoice(
        "是否压缩间隔？",
        [
          { key: "1", label: "压缩间隔，尽量在结束时间前排完", value: "compress" },
          { key: "2", label: "不压缩，按最短铺满间隔排（允许超过结束时间）", value: "normal" },
          { key: "0", label: "取消本次预览，回到监控待命", value: "cancel" }
        ],
        "1"
      ));
    if (answer === "cancel") return "cancel";
    if (answer === "normal") return minGaps;
    return planRealtimeGapsBetween(gaps.map((gap) => Number(gap.min || 0)), minGaps, availableSeconds);
  }

  if (availableSeconds > maxStretchTotal) {
    console.log("\n实时跟发铺满判断：");
    console.log(`- 按 ${minMinutes}-${maxMinutes} 分钟区间最晚会排到 ${secondsToTime(startAbs + maxStretchTotal)}。`);
    console.log(`- 仍早于你填的结束时间 ${endText}。`);
    const answer = await askRealtimeGapChoice(config, {
      mode: "stretch-too-loose",
      maxEnd: secondsToTime(startAbs + maxStretchTotal),
      endTime: endText
    }, () => askChoice(
        "内容偏少，是否放宽最长间隔铺满结束时间？",
        [
          { key: "1", label: "允许超过最长间隔，铺满结束时间", value: "stretch-fill" },
          { key: "2", label: "按最长间隔排，允许提前结束", value: "stretch-max" },
          { key: "3", label: "重新输入开始/结束时间", value: "edit-time" },
          { key: "0", label: "取消本次预览，回到监控待命", value: "cancel" }
        ],
        "1"
      ));
    if (answer === "cancel") return "cancel";
    if (answer === "edit-time") return "edit-time";
    if (answer === "stretch-max") return maxGaps;
    return planRealtimeGapsBetween(minGaps, maxGaps, availableSeconds, { allowBeyondMax: true });
  }

  console.log(`实时跟发：按 ${minMinutes}-${maxMinutes} 分钟区间铺满，预计最后一条接近 ${endText}。`);
  return planRealtimeGapsBetween(minGaps, maxGaps, availableSeconds);
}

async function askRealtimeGapChoice(config, info, fallback) {
  if (config.__runControl?.waitForRealtimeGapChoice) {
    console.log("请在妙券自动发单🚀控制台选择时间处理方式。");
    return await config.__runControl.waitForRealtimeGapChoice(info);
  }
  return await fallback();
}

function taskFingerprint(tasks) {
  const stable = tasks.map((task) => ({
    role: task.role,
    speaker: task.speaker,
    time: task.time,
    date: task.scheduleDateKey || "today",
    type: task.type,
    text: task.text || "",
    highlighted: Boolean(task.highlighted)
  }));
  return crypto.createHash("sha1").update(JSON.stringify(stable)).digest("hex");
}

main().catch((err) => {
  if (err?.previewRestartRequested) {
    console.log("已收到放弃本轮请求，请重新生成预览。");
    return;
  }
  if (err?.userCanceledPreview) {
    console.log(err.message || "已退出。");
    return;
  }
  console.error(`\n${ZH.runFailed}`);
  console.error(err.message || err);
  process.exitCode = 1;
});

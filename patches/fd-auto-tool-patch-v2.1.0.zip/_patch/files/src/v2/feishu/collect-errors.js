export class FeishuCollectError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = "FeishuCollectError";
    this.code = code;
    this.details = details;
  }
}

export function collectError(code, detail = "") {
  const suffix = detail ? `：${detail}` : "";
  return new FeishuCollectError(code, `飞书采集不完整，暂不进入范围/解析测试${suffix}`);
}

export function isFeishuCollectError(error) {
  return error instanceof FeishuCollectError || error?.name === "FeishuCollectError";
}

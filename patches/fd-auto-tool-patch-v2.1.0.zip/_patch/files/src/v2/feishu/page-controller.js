import { chromium } from "playwright";
import { feishuCollectSampleHtml } from "../fixtures/feishu-collect-sample.js";

export async function openV2CollectTestPage(options = {}) {
  const browser = await chromium.launch({ headless: options.headless !== false });
  const page = await browser.newPage({ viewport: { width: 1100, height: 900 } });
  if (options.url) {
    await page.goto(options.url, { waitUntil: "domcontentloaded" });
  } else {
    await page.setContent(feishuCollectSampleHtml(), { waitUntil: "domcontentloaded" });
  }
  return { browser, page };
}

export async function openRealFeishuCollectPage(options = {}) {
  if (options.cdpUrl) {
    const browser = await chromium.connectOverCDP(options.cdpUrl);
    const context = browser.contexts()[0] || await browser.newContext();
    try {
      const page = await reuseOrOpenFeishuPage(context, options);
      await ensureFeishuPageAlive(page);
      await ensureFeishuPageMatchesTarget(page, options.url);
      if (options.focusBody !== false) await focusFeishuBody(page);
      const title = await getFeishuPageTitle(page);
      return { context, browser, page, title, shouldClose: false };
    } catch (error) {
      await browser.disconnect?.().catch(() => {});
      throw error;
    }
  }

  const profileDir = options.profileDir || "./browser-profile";
  const context = await chromium.launchPersistentContext(profileDir, {
    headless: Boolean(options.headless) === true,
    viewport: options.viewport || { width: 1440, height: 1000 }
  });
  let page;
  try {
    page = await reuseOrOpenFeishuPage(context, options);
    await ensureFeishuPageAlive(page);
    await ensureFeishuPageMatchesTarget(page, options.url);
    if (options.focusBody !== false) await focusFeishuBody(page);
    const title = await getFeishuPageTitle(page);
    return { context, browser: context, page, title, shouldClose: true };
  } catch (error) {
    await context.close().catch(() => {});
    throw error;
  }
}

export async function reuseOrOpenFeishuPage(context, options = {}) {
  const pages = (context.pages() || []).filter((page) => page && !page.isClosed?.());
  const targetUrl = normalizeFeishuUrl(options.url);
  const existing = findFeishuPage(pages, targetUrl);
  if (existing) {
    await existing.bringToFront().catch(() => {});
    await existing.waitForLoadState("domcontentloaded", { timeout: options.timeoutMs || 15000 }).catch(() => {});
    await ensureFeishuPageMatchesTarget(existing, targetUrl);
    await closeExtraFeishuPages(context, existing);
    return existing;
  }

  if (!targetUrl) {
    await closeExtraFeishuPages(context, null);
    throw new Error("没有找到可用的飞书文档页面，也没有提供飞书链接。请先打开飞书文档，或在 config.json/last-settings.json 里保存飞书链接。");
  }

  const reusableFeishu = pages.find((item) => isFeishuUrl(item.url?.() || ""));
  const page = reusableFeishu || pages.find((item) => item.url() === "about:blank") || await context.newPage();
  await page.goto(targetUrl, { waitUntil: "domcontentloaded", timeout: options.timeoutMs || 30000 });
  await page.bringToFront().catch(() => {});
  await ensureFeishuPageMatchesTarget(page, targetUrl);
  await closeExtraFeishuPages(context, page);
  return page;
}

export async function ensureFeishuPageAlive(page) {
  if (!page || page.isClosed?.()) {
    throw new Error("飞书页面已经关闭，请重新打开飞书文档后再采集。");
  }
  const url = page.url?.() || "";
  if (!isFeishuUrl(url)) {
    throw new Error("当前页面不是飞书文档页面，请先打开飞书文档后再采集。");
  }
}

export async function ensureFeishuPageMatchesTarget(page, targetUrl) {
  const targetDocId = extractFeishuDocId(targetUrl);
  if (!targetDocId) return { ok: true, skipped: true, reason: "no_target_doc_id" };
  const pageUrl = page?.url?.() || "";
  const pageDocId = extractFeishuDocId(pageUrl);
  if (pageDocId !== targetDocId) {
    throw new Error([
      "当前飞书文档不一致，已停止采集。",
      `目标 docId=${targetDocId}`,
      `实际 docId=${pageDocId || "未识别"}`,
      `目标链接=${normalizeFeishuUrl(targetUrl) || targetUrl || ""}`,
      `实际页面=${pageUrl || "空"}`
    ].join(" "));
  }
  return { ok: true, targetDocId, pageDocId, targetUrl: normalizeFeishuUrl(targetUrl), pageUrl };
}

export async function focusFeishuBody(page) {
  await page.evaluate(() => {
    const candidates = [
      "[contenteditable='true']",
      ".ace-line",
      "[class*='editor']",
      "[class*='docx']",
      "main",
      "article",
      "body"
    ];
    const target = candidates
      .map((selector) => document.querySelector(selector))
      .find(Boolean);
    if (target) {
      target.scrollIntoView?.({ block: "center", inline: "nearest" });
      if (typeof target.focus === "function") target.focus();
    }
  }).catch(() => {});
}

export async function getFeishuPageTitle(page) {
  return page.evaluate(() => {
    const clean = (value) => String(value || "")
      .replace(/\s*-\s*飞书云文档\s*$/i, "")
      .replace(/\s*-\s*飞书文档\s*$/i, "")
      .replace(/\s+/g, " ")
      .trim();
    const directText = (el) => Array.from(el?.childNodes || [])
      .filter((node) => node.nodeType === Node.TEXT_NODE)
      .map((node) => node.textContent || "")
      .join(" ");
    const badTitleText = /最近修改|分享|编辑|云盘|外部|添加快捷方式|权限|链接|问问豆包|https?:\/\//;
    const isGoodTitle = (value) => {
      const text = clean(value);
      if (!text) return false;
      if (/^飞书/.test(text)) return false;
      if (badTitleText.test(text)) return false;
      if (/[>＞]/.test(text)) return false;
      if (text.length > 60) return false;
      return true;
    };
    const visible = (el) => {
      if (!el) return false;
      const style = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
    };
    const scored = Array.from(document.querySelectorAll("h1,h2,[class*='title'],[data-testid*='title']"))
      .filter(visible)
      .flatMap((el) => {
        const style = window.getComputedStyle(el);
        const rect = el.getBoundingClientRect();
        const fontSize = Number.parseFloat(style.fontSize) || 0;
        const bold = Number.parseInt(style.fontWeight, 10) >= 600 ? 10 : 0;
        const tag = String(el.tagName || "").toUpperCase();
        const tagBonus = tag === "H1" ? 120 : tag === "H2" ? 80 : 0;
        const centerBonus = rect.top > 60 && rect.top < window.innerHeight * 0.75 ? 12 : 0;
        return [
          { text: directText(el), sourceBonus: 24 },
          { text: el.innerText || el.textContent || "", sourceBonus: 10 },
          { text: el.getAttribute("aria-label"), sourceBonus: 4 },
          { text: el.getAttribute("title"), sourceBonus: 4 }
        ]
          .map((item) => ({ text: clean(item.text), score: tagBonus + fontSize + bold + centerBonus + item.sourceBonus + (clean(item.text).length <= 30 ? 5 : 0) }))
          .filter((item) => isGoodTitle(item.text));
      })
      .sort((a, b) => b.score - a.score || a.text.length - b.text.length);
    if (scored[0]?.text) return scored[0].text;
    const tabTitle = clean(document.title);
    return isGoodTitle(tabTitle) ? tabTitle : "";
  }).catch(() => "");
}

export function findFeishuPage(pages = [], targetUrl = "") {
  const normalizedTarget = normalizeFeishuUrl(targetUrl);
  const targetDocId = extractFeishuDocId(normalizedTarget);
  return pages.find((page) => {
    if (!page || page.isClosed?.()) return false;
    const pageUrl = page.url?.() || "";
    if (!isFeishuUrl(pageUrl)) return false;
    if (!normalizedTarget) return true;
    return extractFeishuDocId(pageUrl) === targetDocId;
  }) || null;
}

export async function closeExtraFeishuPages(context, keepPage = null) {
  const pages = context?.pages?.() || [];
  const closed = [];
  for (const page of pages) {
    if (!page || page === keepPage || page.isClosed?.()) continue;
    const url = page.url?.() || "";
    if (!isFeishuUrl(url)) continue;
    try {
      await page.close?.();
      closed.push(url);
    } catch {}
  }
  return { closedCount: closed.length, closedUrls: closed };
}

export async function closeFeishuCollectPage(opened) {
  if (!opened) return { ok: true, closed: false, reason: "no_page" };
  if (opened.shouldClose !== false) {
    await opened.context?.close?.().catch(() => {});
    if (opened.browser !== opened.context) await opened.browser?.close?.().catch(() => {});
    return { ok: true, closed: true, closedBrowserContext: true };
  }

  const page = opened.page;
  if (!page || page.isClosed?.()) {
    await opened.browser?.disconnect?.().catch(() => {});
    return { ok: true, closed: false, reason: "already_closed" };
  }
  const url = page.url?.() || "";
  if (!isFeishuUrl(url)) {
    await opened.browser?.disconnect?.().catch(() => {});
    return { ok: true, closed: false, reason: "not_feishu_page", url };
  }

  try {
    await page.close?.();
    await opened.browser?.disconnect?.().catch(() => {});
    return { ok: true, closed: true, url };
  } catch (error) {
    await opened.browser?.disconnect?.().catch(() => {});
    return { ok: false, closed: false, url, error: error?.message || String(error) };
  }
}

export function isFeishuUrl(value) {
  return /^https:\/\/[^/]*feishu\.cn\/(?:docx|docs|wiki|sheets)\//i.test(String(value || ""));
}

export function extractFeishuDocId(value) {
  const url = normalizeFeishuUrl(value) || String(value || "").trim();
  const match = url.match(/^https:\/\/[^/]*feishu\.cn\/(docx|docs|wiki|sheets)\/([^/?#]+)/i);
  if (!match) return "";
  return `${match[1].toLowerCase()}/${decodeURIComponent(match[2])}`;
}

export function normalizeFeishuUrl(value) {
  const text = String(value || "")
    .replace(/[<>]/g, " ")
    .replace(/[“”]/g, "\"")
    .replace(/[‘’]/g, "'")
    .trim();
  if (!text) return "";
  const markdown = text.match(/\((https?:\/\/[^)]+)\)/);
  const source = markdown?.[1] || text;
  const compactSource = source.replace(/\s+/g, "");
  const match = compactSource.match(/https:\/\/\S*feishu\.cn\/(?:docx|docs|wiki|sheets)\/\S+/i);
  const url = (match?.[0] || "").replace(/[)\]};,，。；]+$/g, "");
  return isFeishuUrl(url) ? url : "";
}

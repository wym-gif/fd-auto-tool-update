const TIME_RE = /(?:(\d{1,2})[\/月](\d{1,2})(?:日)?\s*)?(\d{1,2})[：:](\d{1,2})(?:[：:](\d{1,2}))?/;
const CONTINUE_HINT = "下面还说话";

export function detectRoleHeader(event, options = {}) {
  if (!event || event.kind !== "line") return null;
  const rawText = normalizeText(event.text);
  if (!rawText || isNonHeaderText(rawText)) return null;

  const withoutHint = stripContinueHint(rawText);
  const time = parseHeaderTime(withoutHint);
  const speakerPart = time
    ? withoutHint.slice(0, time.index).trim()
    : withoutHint.trim();
  const speaker = cleanSpeaker(speakerPart);
  if (options.currentRole === "douma" && time && isDoumaBodyTimeReminder(withoutHint, speakerPart, time)) {
    return null;
  }

  const numbered = parseNumberedTuoMarker(speaker || withoutHint);
  if (numbered) {
    return buildHeader({
      role: "tuo",
      speaker: numbered.speaker,
      date: time?.date || "",
      time: time?.time || "",
      sourceText: rawText,
      explicit: true
    });
  }

  if (isExplicitDoumaHeader(speaker, withoutHint, time)) {
    return buildHeader({
      role: "douma",
      speaker: speaker || "豆妈",
      date: time?.date || "",
      time: time?.time || "",
      sourceText: rawText,
      explicit: true
    });
  }

  if (event.highlighted && time && speaker && options.allowHighlightedSellerHeader !== false) {
    return buildHeader({
      role: "douma",
      speaker,
      date: time.date,
      time: time.time,
      sourceText: rawText,
      explicit: true
    });
  }

  if (time && !speaker && hasAbnormalTimedSpeaker(speakerPart)) {
    return buildHeader({
      role: "tuo",
      speaker: speakerPart.trim(),
      cleanSpeaker: "匿名托",
      speakerConfidence: "low",
      date: time.date,
      time: time.time,
      sourceText: rawText,
      explicit: true
    });
  }

  if (time && speaker) {
    return buildHeader({
      role: "tuo",
      speaker,
      date: time.date,
      time: time.time,
      sourceText: rawText,
      explicit: true
    });
  }

  if (isBarePersonHeader(speaker || withoutHint, options)) {
    return buildHeader({
      role: "tuo",
      speaker: speaker || withoutHint,
      date: "",
      time: "",
      sourceText: rawText,
      explicit: true
    });
  }

  if (event.highlighted && options.allowHighlightedDouma !== false) {
    return buildHeader({
      role: "douma",
      speaker: "豆妈",
      date: "",
      time: "",
      sourceText: rawText,
      explicit: false,
      useLineAsContent: true
    });
  }

  return null;
}

export function hasContinueHint(text) {
  return normalizeText(text).replace(/\s+/g, "").includes(CONTINUE_HINT);
}

export function isNonSendableRemark(text, options = {}) {
  const compact = normalizeText(text).replace(/\s+/g, "");
  if (!compact) return true;
  if (compact.includes(CONTINUE_HINT)) return true;
  if (/^备注/.test(compact)) return true;
  if (isRhythmHeadingText(compact, options)) return true;
  if (isStandaloneCollectionHeadingText(compact)) return true;
  if (isMediaAnnotationText(compact)) return true;
  if (/^(图|图片|视频|素材|物料)(?:要)?(?:换|替换|换一下|需换|需要换)$/.test(compact)) return true;
  if (/^(不发|不用发|不定时|标注)$/.test(compact)) return true;
  return false;
}

function isMediaAnnotationText(compact) {
  if (compact.length > 24) return false;
  if (/^(?:换|改|替换|换成|改成|替换成)(?:自己|自己的|我们自己的|我的)?(?:到货|实拍|晒单|买家秀)?(?:图|图片|照片)$/.test(compact)) return true;
  if (/^(?:自己|自己的|我们自己的|我的)(?:到货|实拍|晒单|买家秀)(?:图|图片|照片)$/.test(compact)) return true;
  return false;
}

function isStandaloneCollectionHeadingText(compact) {
  if (compact.length > 16 || !compact.includes("合集")) return false;
  return /^(?:未失效|已失效|失效|有效|不过期)?(?:好物|商品|福利|链接)?合集(?:好物|商品|清单|链接|福利)?$/.test(compact)
    || /^(?:未失效|已失效|失效|有效|不过期)?(?:好物|商品|福利|链接)(?:合集)$/.test(compact);
}

function isRhythmHeadingText(compact, options = {}) {
  if (options.insideRoleSegment && isBareLinkCommandText(compact)) return false;
  return /^(?:(?:早上|上午|中午|下午|傍晚|晚上|晚间|早间|午间|凌晨)?(?:\d{1,2}(?:点|点半|[:：]\d{1,2})?)?(?:之后|以后|前|左右)?(?:日常|小)?(?:晒图|预热|预告|定时|反馈|返场|开团|开抢|催单|福利单|福利|科普|早餐|晚安|早安|互动|收割|养群|穿插养群|开始正文|正文|上链接|发链接|开链接)(?:互动|预告|提醒|定时|之后)?|(?:八点|九点|十点|\d{1,2}点)(?:之后|以后|前|左右)?|(?:早上|上午|中午|下午|傍晚|晚上|晚间|早间|午间|凌晨))$/.test(compact);
}

function isBareLinkCommandText(compact) {
  return /^(?:上链接|发链接|开链接)$/.test(compact);
}

function isDoumaBodyTimeReminder(text, speakerPart, time) {
  const compact = normalizeText(text).replace(/\s+/g, "");
  const prefix = normalizeText(speakerPart).replace(/\s+/g, "");
  const afterTime = compact.slice(Math.max(0, time.index + time.raw.length));
  if (!afterTime) return false;
  if (prefix && !/(?:^|[⏰⏱️🔔📢])(?:明天|明日|明早|明晚|今天|今晚|上午|下午|晚上|早上|中午|凌晨|午间|晚间)/.test(prefix)) return false;
  return /(?:买|抢|开抢|置顶|定好?闹钟|闹钟|提醒|蹲|拍|下单|上链接|开链接|发链接|开团|开售|开卖|秒杀|预告)/.test(afterTime);
}

function buildHeader(fields) {
  return {
    ...fields,
    continueSpeaker: hasContinueHint(fields.sourceText)
  };
}

function parseHeaderTime(text) {
  const match = String(text || "").match(TIME_RE);
  if (!match) return null;
  const [, month, day, hour, minute, second] = match;
  return {
    date: month && day ? `${Number(month)}/${Number(day)}` : "",
    time: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:${String(second || "00").padStart(2, "0")}`,
    raw: match[0],
    index: match.index
  };
}

function parseNumberedTuoMarker(text) {
  const compact = normalizeText(text).replace(/\s+/g, "");
  const match = compact.match(/^(?:T|托)(\d*)$/i);
  if (!match) return null;
  const prefix = compact[0].toUpperCase() === "T" ? "T" : "托";
  return { speaker: `${prefix}${match[1] || ""}` };
}

function stripContinueHint(text) {
  return normalizeText(text)
    .replace(new RegExp(`（[^）]*${CONTINUE_HINT}[^）]*）`, "g"), "")
    .replace(new RegExp(`\\([^)]*${CONTINUE_HINT}[^)]*\\)`, "g"), "")
    .replace(new RegExp(`【[^】]*${CONTINUE_HINT}[^】]*】`, "g"), "")
    .replace(new RegExp(`\\[[^\\]]*${CONTINUE_HINT}[^\\]]*\\]`, "g"), "")
    .replace(new RegExp(CONTINUE_HINT, "g"), "")
    .trim();
}

function isExplicitDoumaHeader(speaker, text, time) {
  const clean = cleanSpeaker(speaker || text);
  const compact = clean.replace(/\s+/g, "");
  if (!compact.includes("豆妈")) return false;
  if (time) return true;
  return /^豆妈(?:[🍒🌸❤️❤💕💖]*)?$/.test(compact);
}

function cleanSpeaker(text) {
  return normalizeText(text)
    .replace(/(?:[:：]|[!！?？])+\s*[(（]\s*$/, "")
    .replace(/[，,。；;：:]+$/, "")
    .trim();
}

function hasAbnormalTimedSpeaker(text) {
  const raw = normalizeText(text);
  if (!raw) return false;
  if (/^\d+$/.test(raw)) return false;
  return true;
}

function isBarePersonHeader(text, options = {}) {
  const line = cleanSpeaker(text);
  if (!line || line.includes("豆妈")) return false;
  if (Array.isArray(options.knownSpeakers) && options.knownSpeakers.includes(line)) return true;
  if (options.allowBareNameHeaders === false) return false;
  if (line.length > 6) return false;
  if (/https?:\/\//i.test(line)) return false;
  if (/[，,。！？!?；;：:、]/.test(line)) return false;
  if (/\s/.test(line)) return false;
  if (/^(图片|视频|表情包|动态表情|备注|不发|不用发|不定时)$/.test(line)) return false;
  return true;
}

function isNonHeaderText(text) {
  const line = normalizeText(text);
  if (/^https?:\/\//i.test(line)) return true;
  return false;
}

function normalizeText(text) {
  return String(text || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .trim();
}

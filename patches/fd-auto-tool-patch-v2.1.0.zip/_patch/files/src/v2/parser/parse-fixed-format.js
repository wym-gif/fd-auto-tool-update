import { normalizeRawEvents } from "../contracts/raw-event.js";
import { createPreviewTask } from "../contracts/preview-task.js";
import { classifyChangeDayMarkerEvent, normalizeSendDate } from "../date/date-rules.js";
import { normalizeMessageText } from "./message-text.js";
import { detectRoleHeader, isNonSendableRemark } from "./role-header.js";

export function parseFixedFormatTasks(rawEvents, options = {}) {
  const events = normalizeRawEvents(rawEvents);
  const tasks = [];
  const diagnostics = [];
  const interactionGroups = new Map();
  const useSendDateContext = Boolean(options.baseSendDate || options.date);
  const baseSendDate = normalizeSendDate(options.baseSendDate || options.date || "");
  let currentSendDate = baseSendDate;
  let nextInteractionGroup = 1;
  let currentDaySegment = 1;
  let current = null;
  let lastMediaEvent = null;
  let order = 1;

  for (let eventIndex = 0; eventIndex < events.length; eventIndex += 1) {
    const event = events[eventIndex];
    const dayMarker = useSendDateContext ? classifyChangeDayMarkerEvent(event, baseSendDate) : null;
    if (dayMarker?.isHeading) {
      flushSegment(current, tasks, () => order++);
      current = null;
      lastMediaEvent = null;
      if (dayMarker.date) {
        currentSendDate = dayMarker.date;
        currentDaySegment += 1;
        interactionGroups.clear();
        diagnostics.push({
          code: "change_day_marker",
          sourceId: event.sourceId,
          date: dayMarker.date,
          message: `换天标题切换后续发单日期：${dayMarker.date}`
        });
      } else {
        diagnostics.push({
          code: dayMarker.ignoredReason || "ignored_day_marker",
          sourceId: event.sourceId,
          date: dayMarker.ignoredDate || "",
          message: `换天标题日期已过期，继续使用当前发单日期：${currentSendDate}`
        });
      }
      continue;
    }

    const header = detectRoleHeader(event, roleDetectionOptions(options, current));
    if (header) {
      if (isSameSegmentHeader(current, header, {
        sendDate: useSendDateContext ? currentSendDate : "",
        daySegment: currentDaySegment
      })) {
        if (header.useLineAsContent) appendText(current, event.text, event);
        continue;
      }
      flushSegment(current, tasks, () => order++);
      lastMediaEvent = null;
      current = startSegment(header, event, {
        interactionGroups,
        sendDate: useSendDateContext ? currentSendDate : "",
        daySegment: currentDaySegment,
        nextInteractionGroupRef: {
          get value() {
            return nextInteractionGroup;
          },
          set value(next) {
            nextInteractionGroup = next;
          }
        }
      });
      if (header.useLineAsContent) appendText(current, event.text, event);
      if (!header.time && (options.scheduleMode || "doc") === "doc") {
        diagnostics.push({
          code: "missing_document_time",
          sourceId: event.sourceId,
          message: `角色行没有时间：${event.text}`
        });
      }
      continue;
    }

    if (!current) continue;
    if (event.kind === "divider") {
      flushSegment(current, tasks, () => order++);
      lastMediaEvent = null;
      continue;
    }
    if (event.kind === "line") {
      if (current.finderBuffer?.length) {
        appendFinderText(current, event.text, event);
        continue;
      }
      const cleanedText = cleanBodyText(event.text);
      if (isFinderXmlStart(cleanedText || event.text)) {
        flushText(current, tasks, () => order++);
        appendFinderText(current, event.text, event);
        continue;
      }
      if (cleanedText.trim() && isNonSendableRemark(cleanedText, { insideRoleSegment: true })) continue;
      if (!cleanedText.trim() && String(event.text || "").trim()) continue;
      appendText(current, cleanedText, event);
      continue;
    }
    if (event.kind === "image" || event.kind === "sticker" || event.kind === "video") {
      if (isFeishuStickerImageEcho(event, events[eventIndex - 1], events[eventIndex + 1])) {
        diagnostics.push({
          code: "dropped_sticker_image_echo",
          sourceId: event.sourceId,
          message: "已忽略飞书同一素材同时暴露出的图片副本，保留表情包"
        });
        continue;
      }
      if (isFeishuVideoCoverEcho(event, lastMediaEvent || events[eventIndex - 1], events[eventIndex + 1])) {
        diagnostics.push({
          code: "dropped_video_cover_echo",
          sourceId: event.sourceId,
          message: "已忽略飞书同一视频同时暴露出的封面副本，保留真实视频"
        });
        continue;
      }
      flushSegment(current, tasks, () => order++);
      tasks.push(makeMediaTask(current, event, order++));
      lastMediaEvent = event;
    }
  }

  flushSegment(current, tasks, () => order++);
  return { tasks: dropVideoCoverEchoTasks(tasks, diagnostics), diagnostics };
}

function roleDetectionOptions(options, current) {
  if (!current) return options;
  return {
    ...options,
    allowBareNameHeaders: options.allowBareNameHeadersInsideSegment === true,
    allowHighlightedDouma: false,
    currentRole: current.role || ""
  };
}

function startSegment(header, event, refs) {
  const interactionKey = header.role === "tuo" ? normalizeInteractionKey(header.speaker) : "";
  let interactionGroup = "";
  if (interactionKey) {
    if (header.continueSpeaker && !refs.interactionGroups.has(interactionKey)) {
      refs.interactionGroups.set(interactionKey, `interaction-${refs.nextInteractionGroupRef.value}`);
      refs.nextInteractionGroupRef.value += 1;
    }
    interactionGroup = refs.interactionGroups.get(interactionKey) || "";
  }

  return {
    sourceId: event.sourceId,
    sourceText: header.sourceText,
    role: header.role,
    speaker: header.speaker,
    date: refs.sendDate || header.date,
    documentDate: header.date,
    documentTime: header.time,
    daySegment: refs.daySegment || 1,
    time: header.time,
    interactionGroup,
    continueMarker: Boolean(header.continueSpeaker),
    cleanSpeaker: header.cleanSpeaker || header.speaker,
    speakerConfidence: header.speakerConfidence || "",
    textBuffer: [],
    textSourceIds: [],
    textSourceText: [],
    finderBuffer: [],
    finderSourceIds: [],
    finderSourceText: []
  };
}

function isSameSegmentHeader(current, header, refs) {
  if (!current || !header) return false;
  if (current.role !== header.role) return false;
  if (normalizeInteractionKey(current.speaker) !== normalizeInteractionKey(header.speaker)) return false;
  const nextDate = refs.sendDate || header.date;
  if (String(current.date || "") !== String(nextDate || "")) return false;
  if (String(current.documentDate || "") !== String(header.date || "")) return false;
  if (String(current.time || "") !== String(header.time || "")) return false;
  if (Number(current.daySegment || 1) !== Number(refs.daySegment || 1)) return false;
  return true;
}

function appendText(segment, text, event) {
  if (!segment) return;
  const line = cleanBodyText(text);
  segment.textBuffer.push(line);
  segment.textSourceIds.push(event.sourceId);
  segment.textSourceText.push(event.sourceText || event.text || "");
}

function appendFinderText(segment, text, event) {
  if (!segment) return;
  segment.finderBuffer.push(String(text || "").replace(/\r\n?/g, "\n"));
  segment.finderSourceIds.push(event.sourceId);
  segment.finderSourceText.push(event.sourceText || event.text || "");
}

function flushSegment(segment, tasks, nextOrder) {
  flushText(segment, tasks, nextOrder);
  flushFinder(segment, tasks, nextOrder);
}

function flushText(segment, tasks, nextOrder) {
  if (!segment || !segment.textBuffer.length) return;
  const text = normalizeMessageText(segment.textBuffer.join("\n"));
  segment.textBuffer = [];
  const sourceIds = segment.textSourceIds.splice(0);
  const sourceText = segment.textSourceText.splice(0).join("\n");
  if (!text) return;
  tasks.push(createPreviewTask({
    sourceId: sourceIds.join(",") || segment.sourceId,
    sourceText: sourceText || segment.sourceText,
    role: segment.role,
    speaker: segment.speaker,
    date: segment.date,
    documentDate: segment.documentDate,
    documentTime: segment.documentTime,
    daySegment: segment.daySegment,
    time: segment.time,
    type: "text",
    text,
    mediaPath: "",
    skip: false,
    order: nextOrder(),
    interactionGroup: segment.interactionGroup,
    continueMarker: segment.continueMarker,
    cleanSpeaker: segment.cleanSpeaker,
    speakerConfidence: segment.speakerConfidence
  }));
}

function flushFinder(segment, tasks, nextOrder) {
  if (!segment || !segment.finderBuffer.length) return;
  const text = trimOuterBlankLines(segment.finderBuffer.join("\n"));
  segment.finderBuffer = [];
  const sourceIds = segment.finderSourceIds.splice(0);
  const sourceText = segment.finderSourceText.splice(0).join("\n");
  if (!text) return;
  tasks.push(createPreviewTask({
    sourceId: sourceIds.join(",") || segment.sourceId,
    sourceText: sourceText || segment.sourceText,
    role: segment.role,
    speaker: segment.speaker,
    date: segment.date,
    documentDate: segment.documentDate,
    documentTime: segment.documentTime,
    daySegment: segment.daySegment,
    time: segment.time,
    type: "finder",
    text,
    mediaPath: "",
    skip: false,
    order: nextOrder(),
    interactionGroup: segment.interactionGroup,
    continueMarker: segment.continueMarker,
    cleanSpeaker: segment.cleanSpeaker,
    speakerConfidence: segment.speakerConfidence
  }));
}

function dropVideoCoverEchoTasks(tasks, diagnostics) {
  return tasks.filter((task, index) => {
    if (task.type !== "video" || !looksLikeVideoCoverMedia(task)) return true;
    const adjacent = [tasks[index - 1], tasks[index + 1]]
      .find((item) => item?.type === "video" && hasRealVideoMediaSource(item) && samePreviewTaskContext(task, item));
    if (!adjacent) return true;
    diagnostics.push({
      code: "dropped_video_cover_echo",
      sourceId: task.sourceId,
      message: "已忽略飞书同一视频同时暴露出的封面副本，保留真实视频"
    });
    return false;
  });
}

function samePreviewTaskContext(left, right) {
  return normalizeInteractionKey(left?.speaker) === normalizeInteractionKey(right?.speaker) &&
    String(left?.date || "") === String(right?.date || "") &&
    String(left?.time || "") === String(right?.time || "");
}

function cleanBodyText(text) {
  return String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/（[^）]*下面还说话[^）]*）/g, "")
    .replace(/\([^)]*下面还说话[^)]*\)/g, "")
    .replace(/【[^】]*下面还说话[^】]*】/g, "")
    .replace(/\[[^\]]*下面还说话[^\]]*\]/g, "")
    .replace(/下面还说话/g, "")
    .split("\n")
    .map((line) => line.trim())
    .join("\n");
}

function trimOuterBlankLines(text) {
  const lines = String(text || "").split("\n");
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines.at(-1).trim()) lines.pop();
  return lines.join("\n");
}

function makeMediaTask(segment, event, order) {
  const sourceUrl = firstStableSourceUrl(
    event.sourceUrl,
    event.raw?.sourceUrl,
    event.raw?.originalMediaPath,
    event.raw?.originalBlobMediaPath,
    event.assetUrl
  );
  return createPreviewTask({
    sourceId: event.sourceId,
    sourceText: event.sourceText || segment.sourceText,
    role: segment.role,
    speaker: segment.speaker,
    date: segment.date,
    documentDate: segment.documentDate,
    documentTime: segment.documentTime,
    daySegment: segment.daySegment,
    time: segment.time,
    type: mediaTaskType(event),
    text: "",
    mediaPath: event.mediaPath || event.assetUrl,
    sourceUrl,
    skip: false,
    order,
    interactionGroup: segment.interactionGroup,
    continueMarker: segment.continueMarker,
    cleanSpeaker: segment.cleanSpeaker,
    speakerConfidence: segment.speakerConfidence
  });
}

function isFinderXmlStart(text) {
  return /^\s*(?:<\?xml\b|<msg\b)/i.test(String(text || ""));
}

function isFeishuStickerImageEcho(event, previous, next) {
  if (event?.kind !== "image") return false;
  return isDuplicateStickerImagePair(event, previous) || isDuplicateStickerImagePair(event, next);
}

function mediaTaskType(event) {
  if (event?.kind === "image" && hasExplicitStickerMarker(event)) return "sticker";
  return event.kind;
}

function hasExplicitStickerMarker(event) {
  const text = [
    event?.text,
    event?.sourceText,
    event?.raw?.text,
    event?.raw?.sourceText,
    event?.raw?.parentText
  ].map((value) => String(value || "").trim()).join("\n");
  return /^(表情包|动态表情)$/m.test(text) || /表情包形式/.test(text);
}

function isFeishuVideoCoverEcho(event, previous, next) {
  if (event?.kind !== "video") return false;
  if (hasRealVideoMediaSource(event)) return false;
  if (looksLikeVideoCoverMedia(event)) {
    const adjacentRealVideo = [previous, next].find((item) => item?.kind === "video" && hasRealVideoMediaSource(item));
    if (adjacentRealVideo && (sameCollectContext(event, adjacentRealVideo) || areNearbyEvents(event, adjacentRealVideo))) return true;
  }
  return isDuplicateVideoCoverPair(event, previous) || isDuplicateVideoCoverPair(event, next);
}

function isDuplicateVideoCoverPair(left, right) {
  if (!left || !right) return false;
  const kinds = new Set([left.kind, right.kind]);
  if (!kinds.has("video")) return false;
  const cover = hasRealVideoMediaSource(left) ? right : left;
  const video = hasRealVideoMediaSource(left) ? left : right;
  if (!hasRealVideoMediaSource(video) || !looksLikeVideoCoverMedia(cover)) return false;
  if (String(cover.collectSpeaker || "") !== String(video.collectSpeaker || "")) return false;
  if (String(cover.collectTime || "") !== String(video.collectTime || "")) return false;
  return eventsOverlapAtSameVisualPosition(cover, video) || areNearbyEvents(cover, video);
}

function isDuplicateStickerImagePair(left, right) {
  if (!left || !right) return false;
  const kinds = new Set([left.kind, right.kind]);
  if (!kinds.has("sticker") || !kinds.has("image")) return false;
  if (String(left.collectSpeaker || "") !== String(right.collectSpeaker || "")) return false;
  if (String(left.collectTime || "") !== String(right.collectTime || "")) return false;
  if (!eventsOverlapAtSameVisualPosition(left, right)) return false;
  return hasFeishuCoverSource(left) !== hasFeishuCoverSource(right) && hasTemporaryInlineImageSource(left, right);
}

function hasRealVideoMediaSource(event) {
  const text = [
    event?.mediaPath,
    event?.assetUrl,
    event?.sourceUrl,
    event?.raw?.mediaPath,
    event?.raw?.assetUrl,
    event?.raw?.sourceUrl
  ].map((value) => String(value || "")).join("\n");
  const lower = text.toLowerCase();
  return lower.includes(".mp4") || lower.includes("/video/") || lower.includes("quality=");
}

function looksLikeVideoCoverMedia(event) {
  const text = [
    event?.mediaPath,
    event?.assetUrl,
    event?.sourceUrl,
    event?.raw?.mediaPath,
    event?.raw?.assetUrl,
    event?.raw?.sourceUrl
  ].map((value) => String(value || "")).join("\n");
  const lower = text.toLowerCase();
  return [".jpg", ".jpeg", ".png", ".webp"].some((ext) => lower.includes(ext)) ||
    lower.includes("/cover/") ||
    lower.includes("/preview/");
}

function eventsOverlapAtSameVisualPosition(left, right) {
  const leftBox = left.boundingInfo || {};
  const rightBox = right.boundingInfo || {};
  const leftY = Number(left.y ?? leftBox.y);
  const rightY = Number(right.y ?? rightBox.y);
  if (Number.isFinite(leftY) && Number.isFinite(rightY) && Math.abs(leftY - rightY) <= 2) return true;
  const leftTop = Number(leftBox.y);
  const rightTop = Number(rightBox.y);
  const leftBottom = leftTop + Number(leftBox.height || 0);
  const rightBottom = rightTop + Number(rightBox.height || 0);
  if (![leftTop, rightTop, leftBottom, rightBottom].every(Number.isFinite)) return false;
  return Math.max(leftTop, rightTop) <= Math.min(leftBottom, rightBottom);
}

function areNearbyEvents(left, right) {
  const leftY = Number(left?.y ?? left?.boundingInfo?.y);
  const rightY = Number(right?.y ?? right?.boundingInfo?.y);
  if (Number.isFinite(leftY) && Number.isFinite(rightY) && Math.abs(leftY - rightY) <= 80) return true;
  const leftOrder = Number(left?.order);
  const rightOrder = Number(right?.order);
  return Number.isFinite(leftOrder) && Number.isFinite(rightOrder) && Math.abs(leftOrder - rightOrder) <= 1;
}

function sameCollectContext(left, right) {
  const leftSpeaker = String(left?.collectSpeaker || "").replace(/\s+/g, "");
  const rightSpeaker = String(right?.collectSpeaker || "").replace(/\s+/g, "");
  const leftTime = String(left?.collectTime || "").trim();
  const rightTime = String(right?.collectTime || "").trim();
  return Boolean(leftSpeaker && rightSpeaker && leftSpeaker === rightSpeaker && leftTime && rightTime && leftTime === rightTime);
}

function hasFeishuCoverSource(event) {
  return /internal-api-drive-stream\.feishu\.cn\/space\/api\/box\/stream\/download\/v2\/cover\//i.test([
    event.sourceUrl,
    event.assetUrl,
    event.mediaPath,
    event.raw?.sourceUrl,
    event.raw?.assetUrl,
    event.raw?.mediaPath
  ].map((value) => String(value || "")).join("\n"));
}

function hasTemporaryInlineImageSource(...events) {
  return events.some((event) => {
    const text = [event.sourceUrl, event.assetUrl, event.mediaPath, event.raw?.sourceUrl, event.raw?.assetUrl, event.raw?.mediaPath]
      .map((value) => String(value || ""))
      .join("\n");
    return Boolean(event.inlineMediaDataUrl || event.raw?.inlineMediaDataUrl || /(^|\n)(blob:|image-blob:)/i.test(text));
  });
}

function firstStableSourceUrl(...values) {
  for (const value of values) {
    const text = String(value || "").trim();
    if (!text || /^(blob:|image-blob:)/i.test(text)) continue;
    return text;
  }
  return "";
}

function normalizeInteractionKey(speaker) {
  return String(speaker || "").replace(/\s+/g, "").toLowerCase();
}

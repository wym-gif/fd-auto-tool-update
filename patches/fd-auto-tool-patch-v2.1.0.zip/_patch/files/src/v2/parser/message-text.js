export function normalizeMessageText(text) {
  return String(text || "")
    .replace(/\r\n?/g, "\n")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .trim()
    .replace(/[ \t\f\v]*\n[ \t\f\v]*\n(?:[ \t\f\v]*\n)+/g, "\n\n");
}

export function fixedFormatSampleRawEvents() {
  return [
    { sourceId: "douma-header", kind: "line", text: "豆妈🍒 8/7 09:13:50", order: 1 },
    { sourceId: "douma-text", kind: "line", text: "豆妈正文内容", order: 2 },
    { sourceId: "douma-remark", kind: "line", text: "备注：这句不要发", order: 3 },

    { sourceId: "person-header", kind: "line", text: "阿老 8/7 09:10:22", order: 10 },
    { sourceId: "person-image", kind: "image", assetUrl: "sample://opening-image.jpg", order: 11 },
    { sourceId: "person-text", kind: "line", text: "人名托文字", order: 12 },
    { sourceId: "person-sticker", kind: "sticker", assetUrl: "sample://sticker.gif", order: 13 },
    { sourceId: "person-video", kind: "video", assetUrl: "sample://video.mp4", order: 14 },

    { sourceId: "t-header", kind: "line", text: "T", order: 20 },
    { sourceId: "t-text", kind: "line", text: "T 的内容", order: 21 },

    { sourceId: "t1-header", kind: "line", text: "T1 09:18:00（下面还说话）", order: 30 },
    { sourceId: "t1-text-a", kind: "line", text: "T1 第一段", order: 31 },

    { sourceId: "tuo-header", kind: "line", text: "托", order: 40 },
    { sourceId: "tuo-text", kind: "line", text: "托的内容", order: 41 },

    { sourceId: "tuo1-header", kind: "line", text: "托1", order: 50 },
    { sourceId: "tuo1-text", kind: "line", text: "托1 的内容", order: 51 },

    { sourceId: "no-time-header", kind: "line", text: "今天愉快", order: 60 },
    { sourceId: "no-time-text", kind: "line", text: "无时间角色内容", order: 61 },

    { sourceId: "t1-return-header", kind: "line", text: "T1 09:20:30", order: 70 },
    { sourceId: "t1-text-b", kind: "line", text: "T1 第二段", order: 71 },

    { sourceId: "divider", kind: "divider", order: 80 },
    { sourceId: "after-divider", kind: "line", text: "分割线后的内容仍归 T1", order: 81 },
    { sourceId: "inline-marker", kind: "line", text: "下面还说话", order: 82 }
  ];
}


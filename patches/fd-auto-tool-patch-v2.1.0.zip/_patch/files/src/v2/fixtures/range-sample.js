export function rangeSampleRawEvents() {
  return [
    { sourceId: "before-header", kind: "line", text: "前面的人 08:30:00", order: 1 },
    { sourceId: "before-text", kind: "line", text: "范围外内容", order: 2 },

    { sourceId: "start-header", kind: "line", text: "阿老 8/7 09:10:22", order: 10 },
    { sourceId: "start-image", kind: "image", assetUrl: "sample://start-image.jpg", order: 11 },
    { sourceId: "start-sticker", kind: "sticker", assetUrl: "sample://start-sticker.gif", order: 12 },
    { sourceId: "start-video", kind: "video", assetUrl: "sample://start-video.mp4", order: 13 },
    { sourceId: "start-body-a", kind: "line", text: "第一句在图后面", order: 14 },
    { sourceId: "start-body-b", kind: "line", text: "开始关键词在这一句中间", order: 15 },

    { sourceId: "middle-header", kind: "line", text: "豆妈🍒 8/7 09:13:50", order: 20 },
    { sourceId: "middle-text", kind: "line", text: "豆妈中间内容", order: 21 },

    { sourceId: "end-header", kind: "line", text: "今天愉快 09:20:30", order: 30 },
    { sourceId: "end-text", kind: "line", text: "结束关键词命中这一条正文", order: 31 },
    { sourceId: "after-header", kind: "line", text: "后面的人 09:30:00", order: 40 },
    { sourceId: "after-text", kind: "line", text: "范围外结尾", order: 41 }
  ];
}


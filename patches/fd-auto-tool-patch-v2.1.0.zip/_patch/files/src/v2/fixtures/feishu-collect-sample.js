export function feishuCollectSampleHtml() {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>2.0 Feishu Collect Fixture</title>
  <style>
    body { margin: 0; font-family: Arial, "Microsoft YaHei", sans-serif; background: #f5f7fb; color: #1f2937; }
    main { width: 760px; margin: 32px auto; padding: 24px 28px; background: white; }
    h1 { font-size: 24px; margin: 0 0 18px; }
    .ace-line { min-height: 24px; line-height: 24px; margin: 6px 0; font-size: 16px; }
    .yellow { background: #fff176; }
    .media { display: block; width: 180px; height: 120px; object-fit: cover; margin: 8px 0; border: 1px solid #d1d5db; }
    video.media { background: #111827; }
    hr { margin: 16px 0; border: none; border-top: 1px solid #cbd5e1; }
  </style>
</head>
<body>
  <main data-v2-feishu-fixture>
    <h1 data-v2-kind="title">第八天节奏</h1>
    <div class="ace-line">阿老 8/7 09:10:22</div>
    <img class="media" data-v2-kind="image" alt="opening" src="sample://opening-image.jpg">
    <div class="ace-line">开始关键词在这一句中间</div>
    <div class="ace-line">表情包</div>
    <img class="media" data-v2-kind="sticker" alt="sticker" src="sample://sticker.gif">
    <div class="ace-line">表情包</div>
    <video class="media" data-v2-kind="video" src="sample://video.mp4"></video>
    <hr data-v2-kind="divider">
    <div class="ace-line yellow">豆妈🍒 8/7 09:13:50</div>
    <div class="ace-line yellow">豆妈正文内容</div>
    <div class="ace-line">结束关键词命中这一句</div>
  </main>
</body>
</html>`;
}

export function expectedFeishuCollectChecks() {
  return {
    startKeyword: "开始关键词",
    endKeyword: "结束关键词",
    requireFirstImage: true,
    requireSticker: true,
    requireVideo: true
  };
}

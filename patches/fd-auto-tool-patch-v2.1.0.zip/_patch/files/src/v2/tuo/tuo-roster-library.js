import fs from "node:fs/promises";
import path from "node:path";
import { loadTuoRoster } from "./tuo-roster.js";

const INDEX_FILE = "index.json";
const LIBRARY_DIR = "tuo-roster-library";

export function tuoRosterLibraryRoot(projectRoot) {
  return path.join(projectRoot, LIBRARY_DIR);
}

export async function listTuoRosterLibrary(projectRoot) {
  const root = tuoRosterLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const index = normalizeIndex(await readJsonIfExists(path.join(root, INDEX_FILE)));
  const items = [];
  for (const item of index.items) {
    const hydrated = await hydrateRosterItem(projectRoot, item).catch(() => null);
    if (hydrated) items.push(hydrated);
  }
  items.sort((a, b) => String(b.updatedAt || b.createdAt || "").localeCompare(String(a.updatedAt || a.createdAt || "")));
  await writeIndex(root, items);
  return items;
}

export async function saveTuoRosterToLibrary(projectRoot, options = {}) {
  const sourcePath = String(options.sourcePath || "").trim();
  if (!sourcePath) throw new Error("请先上传或选择托名单。");
  const { roster, filePath } = await loadTuoRoster(sourcePath, { projectRoot });
  const root = tuoRosterLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const now = new Date();
  const id = options.id || `tuo_roster_${timestampForId(now)}_${randomSuffix()}`;
  const ext = path.extname(filePath).toLowerCase() || ".json";
  const filesDir = path.join(root, "files");
  await fs.mkdir(filesDir, { recursive: true });
  const storedFileName = `${id}${ext}`;
  const storedPath = path.join(filesDir, storedFileName);
  await fs.copyFile(filePath, storedPath);
  const item = {
    id,
    name: cleanRosterName(options.name) || defaultRosterName(filePath, now),
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
    originalPath: path.resolve(filePath),
    filePath: storedPath,
    fileName: storedFileName,
    rosterCount: roster.length
  };
  const items = await listTuoRosterLibrary(projectRoot);
  await writeIndex(root, [item, ...items.filter((entry) => entry.id !== id)]);
  return item;
}

export async function renameTuoRosterLibraryItem(projectRoot, id, name) {
  const item = await resolveTuoRosterLibraryItem(projectRoot, id);
  const nextName = cleanRosterName(name);
  if (!nextName) throw new Error("托人设名称不能为空。");
  const root = tuoRosterLibraryRoot(projectRoot);
  const items = await listTuoRosterLibrary(projectRoot);
  const now = new Date().toISOString();
  const updated = { ...item, name: nextName, updatedAt: now };
  await writeIndex(root, items.map((entry) => entry.id === item.id ? updated : entry));
  return updated;
}

export async function deleteTuoRosterLibraryItem(projectRoot, id) {
  const item = await resolveTuoRosterLibraryItem(projectRoot, id);
  const root = path.resolve(tuoRosterLibraryRoot(projectRoot));
  const filePath = path.resolve(item.filePath);
  if (!filePath.startsWith(root + path.sep)) throw new Error("拒绝删除：托人设库目录校验失败。");
  await fs.rm(filePath, { force: true });
  const items = await listTuoRosterLibrary(projectRoot);
  await writeIndex(root, items.filter((entry) => entry.id !== item.id));
  return { id: item.id, name: item.name };
}

export async function resolveTuoRosterLibraryItem(projectRoot, id) {
  const safeId = safeRosterId(id);
  if (!safeId) throw new Error("没有指定托人设。");
  const items = await listTuoRosterLibrary(projectRoot);
  const item = items.find((entry) => entry.id === safeId);
  if (!item) throw new Error("托人设不存在或文件已丢失。");
  return item;
}

async function hydrateRosterItem(projectRoot, item = {}) {
  const id = safeRosterId(item.id);
  if (!id) return null;
  const filePath = resolveLibraryFilePath(projectRoot, item.filePath);
  const stat = await fs.stat(filePath).catch(() => null);
  if (!stat?.isFile()) return null;
  let rosterCount = Number(item.rosterCount || 0);
  if (!rosterCount) {
    const loaded = await loadTuoRoster(filePath, { projectRoot }).catch(() => null);
    rosterCount = loaded?.roster?.length || 0;
  }
  return {
    id,
    name: cleanRosterName(item.name) || path.basename(filePath),
    createdAt: item.createdAt || stat.birthtime.toISOString(),
    updatedAt: item.updatedAt || stat.mtime.toISOString(),
    originalPath: item.originalPath || "",
    filePath,
    fileName: path.basename(filePath),
    rosterCount
  };
}

function resolveLibraryFilePath(projectRoot, value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  if (path.isAbsolute(raw)) return raw;
  return path.resolve(projectRoot, raw);
}

function normalizeIndex(value) {
  const items = Array.isArray(value?.items) ? value.items : [];
  return { items };
}

async function ensureLibraryRoot(root) {
  await fs.mkdir(root, { recursive: true });
}

async function writeIndex(root, items) {
  await ensureLibraryRoot(root);
  await fs.writeFile(path.join(root, INDEX_FILE), JSON.stringify({ items }, null, 2), "utf8");
}

async function readJsonIfExists(filePath) {
  const text = await fs.readFile(filePath, "utf8").catch(() => "");
  if (!text) return {};
  return JSON.parse(text);
}

function cleanRosterName(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 80);
}

function defaultRosterName(filePath, date) {
  const base = path.basename(filePath, path.extname(filePath)) || "托人设";
  return cleanRosterName(base) || `托人设 ${timestampForId(date)}`;
}

function safeRosterId(value) {
  const raw = String(value || "").trim();
  return /^[A-Za-z0-9_-]{1,80}$/.test(raw) ? raw : "";
}

function timestampForId(date) {
  const pad = (value) => String(value).padStart(2, "0");
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds())
  ].join("");
}

function randomSuffix() {
  return Math.random().toString(36).slice(2, 8);
}

import { inferTuoIntent } from "./tuo-intent.js";
import { normalizeRosterKey } from "./tuo-roster.js";

const DEFAULT_COOLDOWN = 5;
const DEFAULT_CANDIDATE_COUNT = 4;

export function assignPreciseTuoSpeakers(tasks = [], roster = [], options = {}) {
  const cooldown = Number.isFinite(Number(options.cooldown)) ? Number(options.cooldown) : DEFAULT_COOLDOWN;
  const candidateCount = Math.max(1, Number(options.candidateCount || DEFAULT_CANDIDATE_COUNT));
  const recentNicknames = [];
  const usedCounts = new Map();
  const assignments = [];
  const nextTasks = tasks.map((task, index) => {
    if (task?.role !== "tuo") return task;
    const intent = inferTuoIntent(task);
    const decision = chooseRosterItem(roster, intent, {
      recentNicknames,
      usedCounts,
      cooldown
    });
    if (!decision.item) {
      assignments.push({
        index: task.index || index + 1,
        sourceId: task.sourceId || "",
        previousSpeaker: task.speaker || "",
        assignedSpeaker: "",
        reason: "没有可用托名单候选",
        fallback: true,
        backup: false,
        tags: intent.tags
      });
      return task;
    }
    const candidates = chooseRosterCandidates(roster, intent, {
      recentNicknames,
      usedCounts,
      cooldown,
      limit: candidateCount,
      primaryNickname: decision.item.nickname
    });
    rememberUse(decision.item.nickname, recentNicknames, usedCounts, cooldown);
    assignments.push({
      index: task.index || index + 1,
      sourceId: task.sourceId || "",
      previousSpeaker: task.speaker || "",
      assignedSpeaker: decision.item.nickname,
      remark: decision.item.remark,
      reason: decision.reason,
      fallback: decision.fallback,
      backup: decision.item.backup,
      tags: intent.tags,
      candidateSpeakers: candidates.map((item) => item.nickname)
    });
    return {
      ...task,
      speaker: decision.item.nickname,
      cleanSpeaker: decision.item.nickname,
      tuoAssignment: buildTuoAssignment(decision.item, candidates, intent, {
        reason: decision.reason,
        fallback: decision.fallback,
        cooldown
      })
    };
  });

  return {
    tasks: nextTasks,
    report: buildAssignmentReport(assignments, roster)
  };
}

export function chooseRosterItem(roster = [], intent = {}, context = {}) {
  const candidates = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!candidates.length) return { item: null, reason: "名单为空", fallback: true };
  const explicitKey = normalizeRosterKey(intent.explicitNickname);
  if (explicitKey) {
    const exact = pickBest(candidates.filter((item) => normalizeRosterKey(item.nickname) === explicitKey), intent, context, { allowBackup: true });
    if (exact) return { item: exact.item, reason: "按文案指定托分配", fallback: false };
  }

  const primary = pickBest(candidates.filter((item) => !item.backup), intent, context, { allowBackup: false });
  if (primary && primary.score > 0) return { item: primary.item, reason: primary.reason, fallback: false };

  const anyPrimary = pickBest(candidates.filter((item) => !item.backup), intent, context, { allowBackup: false, ignoreTags: true });
  if (anyPrimary) return { item: anyPrimary.item, reason: "没有明显身份命中，按最少使用托兜底", fallback: true };

  const backup = pickBest(candidates, intent, context, { allowBackup: true, ignoreTags: true });
  if (backup) return { item: backup.item, reason: "主名单不可用，使用备用托兜底", fallback: true };
  return { item: null, reason: "没有可用候选", fallback: true };
}

export function chooseRosterCandidates(roster = [], intent = {}, context = {}) {
  const limit = Math.max(1, Number(context.limit || DEFAULT_CANDIDATE_COUNT));
  const candidates = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!candidates.length) return [];
  const primaryKey = normalizeRosterKey(context.primaryNickname);
  const exact = primaryKey ? candidates.find((item) => normalizeRosterKey(item.nickname) === primaryKey) : null;
  const scored = rankRosterCandidates(candidates, intent, context, { allowBackup: true })
    .filter((entry) => normalizeRosterKey(entry.item.nickname) !== primaryKey)
    .map((entry) => entry.item);
  const ordered = exact ? [exact, ...scored] : scored;
  const seen = new Set();
  const result = [];
  for (const item of ordered) {
    const key = normalizeRosterKey(item.nickname);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    result.push(item);
    if (result.length >= limit) break;
  }
  return result;
}

function pickBest(candidates, intent, context, options = {}) {
  return rankRosterCandidates(candidates, intent, context, options)[0] || null;
}

function rankRosterCandidates(candidates, intent, context, options = {}) {
  return candidates
    .filter((item) => options.allowBackup || !item.backup)
    .map((item) => scoreCandidate(item, intent, context, options))
    .filter((item) => item.score > -1000)
    .sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      if (left.used !== right.used) return left.used - right.used;
      return left.item.order - right.item.order;
    });
}

function scoreCandidate(item, intent, context, options = {}) {
  const used = context.usedCounts?.get(item.nickname) || 0;
  const recent = context.recentNicknames?.includes(item.nickname);
  const wantedTags = options.ignoreTags ? [] : intent.tags || [];
  let score = options.ignoreTags ? 1 : 0;
  const matched = [];
  for (const tag of wantedTags) {
    if (item.tags?.includes(tag)) {
      score += tag === "female" || tag === "male" ? 1 : 4;
      matched.push(tag);
    }
  }
  if (!options.ignoreTags && wantedTags.length && !matched.length) score -= 2;
  if (recent) score -= 6;
  if (item.backup) score -= 20;
  score -= used;
  return {
    item,
    score,
    used,
    reason: matched.length ? `身份命中：${matched.join("/")}` : "按最少使用托兜底"
  };
}

function rememberUse(nickname, recentNicknames, usedCounts, cooldown) {
  usedCounts.set(nickname, (usedCounts.get(nickname) || 0) + 1);
  recentNicknames.push(nickname);
  while (recentNicknames.length > cooldown) recentNicknames.shift();
}

function buildAssignmentReport(assignments, roster) {
  const assigned = assignments.filter((item) => item.assignedSpeaker);
  return {
    ok: true,
    rosterCount: roster.length,
    tuoTaskCount: assignments.length,
    assignedCount: assigned.length,
    fallbackCount: assignments.filter((item) => item.fallback).length,
    backupCount: assignments.filter((item) => item.backup).length,
    assignments
  };
}

function buildTuoAssignment(primary, candidates, intent, options = {}) {
  return {
    mode: "precise_roster",
    cooldown: options.cooldown || DEFAULT_COOLDOWN,
    reason: options.reason || "",
    fallback: Boolean(options.fallback),
    intentTags: intent.tags || [],
    intentReasons: intent.reasons || [],
    primary: serializeCandidate(primary),
    candidates: candidates.map(serializeCandidate)
  };
}

function serializeCandidate(item = {}) {
  return {
    nickname: item.nickname || "",
    remark: item.remark || "",
    tags: item.tags || [],
    backup: Boolean(item.backup),
    order: item.order ?? 0
  };
}

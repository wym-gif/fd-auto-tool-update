export function inferTuoIntent(task = {}) {
  const text = [
    task.sourceText || "",
    task.text || "",
    task.speaker || "",
    task.cleanSpeaker || ""
  ].join("\n");
  const tags = new Set();
  const reasons = [];

  addIf(tags, reasons, "mom", /宝妈|妈妈|孩子|娃|宝宝|小朋友|上学|幼儿园|早餐|家里人|老人孩子/.test(text), "母婴/家庭语境");
  addIf(tags, reasons, "work", /上班|工作|办公室|同事|打工|下班|通勤|开会/.test(text), "工作语境");
  addIf(tags, reasons, "mature", /配料|成分|保质期|安全|放心|品质|囤|家用|实惠|性价比|养生|健康/.test(text), "成熟理性语境");
  addIf(tags, reasons, "young", /姐妹|爱了|冲|颜值|好看|追剧|减脂|低卡|下午茶|零食|拍照/.test(text), "年轻女性语境");
  addIf(tags, reasons, "female", /姐妹|女性|女生|宝妈|妈妈|女/.test(text), "女性语境");
  addIf(tags, reasons, "male", /男士|男性|爸爸|老公/.test(text), "男性语境");

  const explicitNickname = extractExplicitNickname(text);
  return {
    tags: [...tags],
    reasons,
    explicitNickname
  };
}

function addIf(tags, reasons, tag, condition, reason) {
  if (!condition) return;
  tags.add(tag);
  reasons.push(reason);
}

function extractExplicitNickname(text) {
  const source = String(text || "");
  const match = source.match(/(?:指定托|固定托|指定说话人|说话人)\s*[：:]\s*([^\n｜|，,。；;]{1,24})/);
  return match ? match[1].trim() : "";
}

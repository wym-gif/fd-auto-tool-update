export function createConsoleState() {
  const state = {
    step: "idle",
    status: "ready",
    runDir: "",
    previewPath: "",
    previewUrl: "",
    successCount: 0,
    failureCount: 0,
    currentIndex: 0,
    lastCompletedIndex: 0,
    resumeTargetIndex: 0,
    totalCount: 0,
    waitingReason: "",
    failureStep: "",
    failureReason: "",
    missingFiles: [],
    manualAction: null,
    control: "ready",
    activeLibraryItemId: "",
    activeLibraryItemName: "",
    logs: [],
    updatedAt: new Date().toISOString()
  };

  return {
    snapshot() {
      return { ...state, logs: [...state.logs] };
    },
    update(patch = {}) {
      Object.assign(state, patch, { updatedAt: new Date().toISOString() });
      return this.snapshot();
    },
    pause(reason = "用户点击暂停") {
      if (state.status === "running") {
        state.status = "paused";
        state.control = "paused";
        state.waitingReason = reason;
        state.updatedAt = new Date().toISOString();
        this.log(reason);
      }
      return this.snapshot();
    },
    resume(reason = "用户点击继续") {
      if (state.control === "awaiting_error_action") {
        return this.retryCurrentTask("用户点击继续，重试当前失败条");
      }
      if (state.status === "paused") {
        state.status = "running";
        state.control = "running";
        state.waitingReason = reason;
        state.updatedAt = new Date().toISOString();
        this.log(reason);
      }
      return this.snapshot();
    },
    stop(reason = "用户点击停止") {
      if (state.status === "running" || state.status === "paused") {
        state.status = "stopped";
        state.control = "stopped";
        state.waitingReason = reason;
        state.manualAction = null;
        state.updatedAt = new Date().toISOString();
        this.log(reason);
      }
      return this.snapshot();
    },
    waitForManualTaskError({ taskIndex = 0, totalCount = 0, reason = "", task = {} } = {}) {
      state.status = "paused";
      state.step = "等待人工处理";
      state.control = "awaiting_error_action";
      state.currentIndex = Number(taskIndex || task.index || state.currentIndex || 0);
      state.totalCount = Number(totalCount || state.totalCount || 0);
      state.failureStep = `第 ${state.currentIndex || "?"} 条创建失败`;
      state.failureReason = String(reason || "");
      state.waitingReason = `第 ${state.currentIndex || "?"} 条创建失败，请选择重试这一条、跳过这一条或停止本轮。`;
      state.manualAction = {
        type: "task_error",
        taskIndex: state.currentIndex,
        totalCount: state.totalCount,
        role: task.role || "",
        speaker: task.speaker || task.cleanSpeaker || "",
        taskType: task.type || "",
        reason: state.failureReason
      };
      state.updatedAt = new Date().toISOString();
      this.log(`等待人工处理：第 ${state.currentIndex || "?"} 条创建失败：${state.failureReason}`);
      return this.snapshot();
    },
    retryCurrentTask(reason = "人工选择重试当前条") {
      if (state.control === "awaiting_error_action") {
        state.status = "running";
        state.control = "retry_current";
        state.waitingReason = reason;
        state.manualAction = null;
        state.updatedAt = new Date().toISOString();
        this.log(reason);
      }
      return this.snapshot();
    },
    skipCurrentTask(reason = "人工选择跳过当前条") {
      if (state.control === "awaiting_error_action") {
        state.status = "running";
        state.control = "skip_current";
        state.waitingReason = reason;
        state.manualAction = null;
        state.updatedAt = new Date().toISOString();
        this.log(reason);
      }
      return this.snapshot();
    },
    resumeFromIndex(index, reason) {
      const targetIndex = Number(index || 0);
      if (!targetIndex || targetIndex < 1) return this.snapshot();
      if (state.status === "paused" || state.control === "paused") {
        state.status = "running";
        state.control = "resume_from_index";
        state.resumeTargetIndex = targetIndex;
        state.manualAction = null;
        state.waitingReason = reason || `人工选择从第 ${targetIndex} 条开始继续创建`;
        state.updatedAt = new Date().toISOString();
        this.log(state.waitingReason);
      }
      return this.snapshot();
    },
    clearResumeFromIndex(targetIndex = 0) {
      if (state.control === "resume_from_index") {
        state.status = "running";
        state.control = "running";
        state.resumeTargetIndex = 0;
        state.waitingReason = targetIndex ? `已按选择从第 ${targetIndex} 条继续创建` : "已按选择继续创建";
        state.updatedAt = new Date().toISOString();
      }
      return this.snapshot();
    },
    log(message, fields = {}) {
      const entry = {
        time: new Date().toISOString(),
        message: String(message || ""),
        ...fields
      };
      state.logs.push(entry);
      if (state.logs.length > 1000) state.logs.splice(0, state.logs.length - 1000);
      state.updatedAt = entry.time;
      return entry;
    },
    fail(step, reason, fields = {}) {
      state.status = "failed";
      state.step = "失败";
      state.failureStep = step;
      state.failureReason = String(reason || "");
      state.failureCount += 1;
      state.waitingReason = "";
      Object.assign(state, fields, { updatedAt: new Date().toISOString() });
      this.log(`失败：${step}：${reason}`);
      return this.snapshot();
    },
    resetTerminalState(reason = "重新打开控制台，清理上次终态") {
      if (!["failed", "stopped", "disconnected"].includes(state.status)) return this.snapshot();
      Object.assign(state, {
        step: "idle",
        status: "ready",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        successCount: 0,
        failureCount: 0,
        currentIndex: 0,
        lastCompletedIndex: 0,
        resumeTargetIndex: 0,
        totalCount: 0,
        waitingReason: "",
        failureStep: "",
        failureReason: "",
        missingFiles: [],
        manualAction: null,
        control: "ready",
        activeLibraryItemId: "",
        activeLibraryItemName: "",
        updatedAt: new Date().toISOString()
      });
      this.log(reason);
      return this.snapshot();
    },
    resetForStartup(reason = "正式入口重新打开：已清理上次运行状态") {
      Object.assign(state, {
        step: "idle",
        status: "ready",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        successCount: 0,
        failureCount: 0,
        currentIndex: 0,
        lastCompletedIndex: 0,
        resumeTargetIndex: 0,
        totalCount: 0,
        waitingReason: "控制台已重新打开，可以生成新预览，或选择恢复上次预览",
        failureStep: "",
        failureReason: "",
        missingFiles: [],
        manualAction: null,
        control: "ready",
        activeLibraryItemId: "",
        activeLibraryItemName: "",
        logs: [],
        updatedAt: new Date().toISOString()
      });
      this.log(reason);
      return this.snapshot();
    },
    resetForNextRun(reason = "开始下一轮发单：已清理本轮运行状态", waitingReason = "可以修改飞书链接、时间模式或直接生成下一轮预览") {
      Object.assign(state, {
        step: "idle",
        status: "ready",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        successCount: 0,
        failureCount: 0,
        currentIndex: 0,
        lastCompletedIndex: 0,
        resumeTargetIndex: 0,
        totalCount: 0,
        waitingReason,
        failureStep: "",
        failureReason: "",
        missingFiles: [],
        manualAction: null,
        control: "ready",
        activeLibraryItemId: "",
        activeLibraryItemName: "",
        logs: [],
        updatedAt: new Date().toISOString()
      });
      this.log(reason);
      return this.snapshot();
    },
    resetForRun(step) {
      Object.assign(state, {
        step,
        status: "running",
        runDir: "",
        previewPath: "",
        previewUrl: "",
        successCount: 0,
        failureCount: 0,
        currentIndex: 0,
        lastCompletedIndex: 0,
        resumeTargetIndex: 0,
        totalCount: 0,
        waitingReason: "",
        failureStep: "",
        failureReason: "",
        missingFiles: [],
        manualAction: null,
        control: "running",
        activeLibraryItemId: "",
        activeLibraryItemName: "",
        logs: [],
        updatedAt: new Date().toISOString()
      });
      this.log(`开始：${step}`);
      return this.snapshot();
    }
  };
}

export function createWorkflowControl(consoleState) {
  return {
    async checkpoint(label) {
      const text = String(label || "");
      const match = text.match(/第\s*(\d+)\s*条/);
      const successMatch = text.match(/第\s*(\d+)\s*条创建成功/);
      const before = consoleState.snapshot();
      if (before.control === "stopped") {
        throw new Error(`用户已停止，后台停在检查点：${text}`);
      }
      if (before.control === "resume_from_index") {
        throwResumeFromIndex(before);
      }
      consoleState.update({
        step: "正式创建 CMS",
        status: before.control === "paused" ? "paused" : "running",
        control: before.control === "paused" ? "paused" : "running",
        currentIndex: match ? Number(match[1]) : consoleState.snapshot().currentIndex,
        lastCompletedIndex: successMatch ? Number(successMatch[1]) : before.lastCompletedIndex || 0,
        waitingReason: text
      });
      consoleState.log(text);
      while (consoleState.snapshot().control === "paused") {
        await sleep(500);
      }
      const afterWait = consoleState.snapshot();
      if (afterWait.control === "resume_from_index") {
        throwResumeFromIndex(afterWait);
      }
      if (afterWait.control === "stopped") {
        throw new Error(`用户已停止，后台停在检查点：${text}`);
      }
    },
    async handleTaskError({ task = {}, totalCount = 0, message = "" } = {}) {
      consoleState.waitForManualTaskError({
        task,
        taskIndex: task.index,
        totalCount,
        reason: message
      });
      while (true) {
        const snapshot = consoleState.snapshot();
        if (snapshot.control === "retry_current") {
          consoleState.update({
            status: "running",
            control: "running",
            waitingReason: `正在重试第 ${task.index || "?"} 条`
          });
          return "retry";
        }
        if (snapshot.control === "skip_current") {
          consoleState.update({
            status: "running",
            control: "running",
            waitingReason: `已跳过第 ${task.index || "?"} 条，继续下一条`
          });
          return "skip";
        }
        if (snapshot.control === "stopped") return "stop";
        await sleep(500);
      }
    },
    clearResumeFromIndex(targetIndex) {
      consoleState.clearResumeFromIndex?.(targetIndex);
    }
  };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function throwResumeFromIndex(snapshot = {}) {
  const error = new Error(`人工选择从第 ${snapshot.resumeTargetIndex || "?"} 条继续创建`);
  error.code = "resume_from_index";
  error.targetIndex = snapshot.resumeTargetIndex;
  throw error;
}

import fs from "node:fs/promises";
import path from "node:path";

const SETTINGS_FILE = "last-console-settings.json";
const INTERVAL_PRESETS_FILE = "interval-presets.json";
const INTERVAL_FIELDS = [
  "sameTuoMin",
  "sameTuoMax",
  "differentTuoMin",
  "differentTuoMax",
  "mediaMin",
  "mediaMax",
  "doumaSameMin",
  "doumaSameMax",
  "roleSwitchMin",
  "roleSwitchMax"
];
const VISIBLE_INTERVAL_FIELDS = [
  "sameTuoMin",
  "sameTuoMax",
  "differentTuoMin",
  "differentTuoMax",
  "doumaSameMin",
  "doumaSameMax",
  "roleSwitchMin",
  "roleSwitchMax"
];
const INTERVAL_GROUPS = [
  ["sameTuo", "sameTuoMin", "sameTuoMax"],
  ["differentTuo", "differentTuoMin", "differentTuoMax"],
  ["media", "mediaMin", "mediaMax"],
  ["doumaSame", "doumaSameMin", "doumaSameMax"],
  ["roleSwitch", "roleSwitchMin", "roleSwitchMax"]
];

export async function loadConsoleSettings(projectRoot) {
  const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
  const lastSettings = await readJsonIfExists(path.join(projectRoot, "last-settings.json"));
  const consoleSettings = await readJsonIfExists(path.join(projectRoot, SETTINGS_FILE));
  const loaded = {
    feishuUrl: consoleSettings.feishuUrl || lastSettings.feishuUrl || config.feishuUrl || "",
    feishuTitle: consoleSettings.feishuTitle || lastSettings.feishuTitle || "",
    feishuTitleUrl: consoleSettings.feishuTitleUrl || lastSettings.feishuTitleUrl || "",
    rangeMode: consoleSettings.rangeMode || "range",
    startKeyword: consoleSettings.startKeyword || "",
    endKeyword: consoleSettings.endKeyword || "",
    headingDay: consoleSettings.headingDay || "",
    headingRhythm: consoleSettings.headingRhythm || "",
    scheduleMode: consoleSettings.scheduleMode || config.scheduleMode || "doc",
    realtimeStartTime: consoleSettings.realtimeStartTime || config.realtimeStartTime || "",
    realtimeEndTime: consoleSettings.realtimeEndTime || config.realtimeEndTime || "",
    currentTime: consoleSettings.currentTime || "",
    ...loadedIntervalSettings(consoleSettings),
    cmsUrl: consoleSettings.cmsUrl || config.cmsUrl || "",
    cdpUrl: consoleSettings.cdpUrl || "",
    robotStrategy: consoleSettings.robotStrategy || config.tuoMode || "random",
    tuoRosterPath: consoleSettings.tuoRosterPath || config.tuoRosterPath || "",
    robotNotInGroupPolicy: consoleSettings.robotNotInGroupPolicy || config.robotNotInGroupPolicy || "ignore",
    robotNotInGroupMaxRetries: Number(consoleSettings.robotNotInGroupMaxRetries || config.robotNotInGroupMaxRetries || 3),
    restoreSelection: consoleSettings.restoreSelection !== false,
    date: "",
    updatedAt: consoleSettings.updatedAt || ""
  };
  const normalized = normalizeConsoleSettings(loaded);
  if (normalized.feishuTitle && !loaded.feishuTitleUrl) {
    normalized.feishuTitle = "";
    normalized.feishuTitleUrl = "";
  }
  return { ...normalized, updatedAt: loaded.updatedAt };
}

export async function saveConsoleSettings(projectRoot, settings = {}) {
  const normalized = normalizeConsoleSettings(settings);
  const intervalError = validateCustomIntervalSettings(normalized);
  if (intervalError) throw new Error(intervalError);
  await fs.writeFile(path.join(projectRoot, SETTINGS_FILE), JSON.stringify({
    ...normalized,
    customIntervalsEnabled: hasAnyCustomInterval(normalized),
    updatedAt: new Date().toISOString()
  }, null, 2), "utf8");
  await saveLastSettings(projectRoot, normalized);
  return normalized;
}

export async function loadIntervalPresets(projectRoot) {
  const store = await readJsonIfExists(path.join(projectRoot, INTERVAL_PRESETS_FILE));
  return sanitizeIntervalPresetList(store.presets);
}

export async function saveIntervalPreset(projectRoot, preset = {}) {
  const filePath = path.join(projectRoot, INTERVAL_PRESETS_FILE);
  const store = await readJsonIfExists(filePath);
  const presets = sanitizeIntervalPresetList(store.presets);
  const intervals = normalizeIntervalPresetIntervals(preset.intervals || preset);
  const intervalError = validateCustomIntervalSettings(intervals);
  if (intervalError) throw new Error(intervalError);
  if (!hasAnyVisibleCustomInterval(intervals)) throw new Error("请先填写至少一组自定义间隔，再保存为方案。");

  const now = new Date().toISOString();
  const id = String(preset.id || "").trim() || `preset_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const existingIndex = presets.findIndex((item) => item.id === id);
  const existing = existingIndex >= 0 ? presets[existingIndex] : {};
  const nextPreset = {
    id,
    name: String(preset.name || "").trim() || defaultIntervalPresetName(intervals),
    intervals,
    createdAt: existing.createdAt || now,
    updatedAt: now
  };
  if (existingIndex >= 0) presets[existingIndex] = nextPreset;
  else presets.push(nextPreset);
  await fs.writeFile(filePath, JSON.stringify({ presets }, null, 2), "utf8");
  return { preset: nextPreset, presets };
}

export async function deleteIntervalPreset(projectRoot, id) {
  const filePath = path.join(projectRoot, INTERVAL_PRESETS_FILE);
  const presets = sanitizeIntervalPresetList((await readJsonIfExists(filePath)).presets)
    .filter((item) => item.id !== String(id || "").trim());
  await fs.writeFile(filePath, JSON.stringify({ presets }, null, 2), "utf8");
  return { presets };
}

export function normalizeConsoleSettings(settings = {}) {
  const rangeMode = ["full", "range", "heading"].includes(settings.rangeMode) ? settings.rangeMode : "range";
  const normalized = {
    feishuUrl: String(settings.feishuUrl || "").trim(),
    feishuTitle: String(settings.feishuTitle || "").trim(),
    feishuTitleUrl: String(settings.feishuTitleUrl || "").trim(),
    rangeMode,
    startKeyword: String(settings.startKeyword || "").trim(),
    endKeyword: String(settings.endKeyword || "").trim(),
    headingDay: String(settings.headingDay || "").trim(),
    headingRhythm: String(settings.headingRhythm || "").trim(),
    scheduleMode: ["doc", "realtime", "catchup"].includes(settings.scheduleMode) ? settings.scheduleMode : "doc",
    realtimeStartTime: String(settings.realtimeStartTime || "").trim(),
    realtimeEndTime: String(settings.realtimeEndTime || "").trim(),
    currentTime: String(settings.currentTime || "").trim(),
    sameTuoMin: intervalValueOrEmpty(settings.sameTuoMin),
    sameTuoMax: intervalValueOrEmpty(settings.sameTuoMax),
    differentTuoMin: intervalValueOrEmpty(settings.differentTuoMin),
    differentTuoMax: intervalValueOrEmpty(settings.differentTuoMax),
    mediaMin: intervalValueOrEmpty(settings.mediaMin),
    mediaMax: intervalValueOrEmpty(settings.mediaMax),
    doumaSameMin: intervalValueOrEmpty(settings.doumaSameMin),
    doumaSameMax: intervalValueOrEmpty(settings.doumaSameMax),
    roleSwitchMin: intervalValueOrEmpty(settings.roleSwitchMin),
    roleSwitchMax: intervalValueOrEmpty(settings.roleSwitchMax),
    date: String(settings.date || "").trim(),
    cmsUrl: String(settings.cmsUrl || "").trim(),
    cdpUrl: String(settings.cdpUrl || "").trim(),
    robotStrategy: normalizeRobotStrategy(settings.robotStrategy),
    tuoRosterPath: String(settings.tuoRosterPath || "").trim(),
    robotNotInGroupPolicy: ["ignore", "switch_robot"].includes(settings.robotNotInGroupPolicy) ? settings.robotNotInGroupPolicy : "ignore",
    robotNotInGroupMaxRetries: numberOrDefault(settings.robotNotInGroupMaxRetries, 3),
    restoreSelection: settings.restoreSelection !== false
  };
  return isolateRangeModeState(normalizeFeishuTitleBinding(normalized));
}

export function normalizeFeishuTitleBinding(settings = {}) {
  const normalized = { ...settings };
  if (!normalized.feishuTitle || isPlaceholderFeishuTitle(normalized.feishuTitle)) {
    normalized.feishuTitle = normalized.feishuTitle || "";
    normalized.feishuTitleUrl = "";
    return normalized;
  }
  normalized.feishuTitleUrl = normalized.feishuTitleUrl || normalized.feishuUrl || "";
  if (!sameFeishuDocument(normalized.feishuUrl, normalized.feishuTitleUrl)) {
    normalized.feishuTitle = "";
    normalized.feishuTitleUrl = "";
  }
  return normalized;
}

export function isolateRangeModeState(settings = {}) {
  const isolated = { ...settings };
  if (isolated.rangeMode === "full") {
    isolated.startKeyword = "";
    isolated.endKeyword = "";
    isolated.headingDay = "";
    isolated.headingRhythm = "";
  } else if (isolated.rangeMode === "heading") {
    isolated.startKeyword = "";
    isolated.endKeyword = "";
  } else {
    isolated.headingDay = "";
    isolated.headingRhythm = "";
  }
  return isolated;
}

export function collectGenerateOptions(settings = {}) {
  const normalized = normalizeConsoleSettings(settings);
  const options = {
    url: normalized.feishuUrl,
    startKeyword: normalized.rangeMode === "range" ? normalized.startKeyword : "",
    endKeyword: normalized.rangeMode === "range" ? normalized.endKeyword : "",
    endAtDocumentEnd: normalized.rangeMode !== "range" || !normalized.endKeyword,
    headingDay: normalized.rangeMode === "heading" ? normalized.headingDay : "",
    headingRhythm: normalized.rangeMode === "heading" ? normalized.headingRhythm : "",
    scheduleMode: normalized.scheduleMode,
    realtimeStartTime: normalized.realtimeStartTime,
    realtimeEndTime: normalized.realtimeEndTime,
    currentTime: normalized.currentTime,
    intervals: buildCustomIntervals(normalized)
  };
  return Object.fromEntries(Object.entries(options).filter(([, value]) => value !== ""));
}

export function cmsRunOptions(settings = {}) {
  const normalized = normalizeConsoleSettings(settings);
  return {
    cmsUrl: normalized.cmsUrl,
    cdpUrl: normalized.cdpUrl,
    useAllPreviewTasks: true,
    assumeYes: true,
    confirmText: "YES",
    scheduleMode: normalized.scheduleMode,
    intervals: buildCustomIntervals(normalized),
    robotStrategy: normalized.robotStrategy === "precise" ? "fixed" : normalized.robotStrategy,
    robotNotInGroupPolicy: normalized.robotNotInGroupPolicy,
    robotNotInGroupMaxRetries: normalized.robotNotInGroupMaxRetries
  };
}

async function saveLastSettings(projectRoot, settings) {
  const filePath = path.join(projectRoot, "last-settings.json");
  const current = await readJsonIfExists(filePath);
  await fs.writeFile(filePath, JSON.stringify({
    ...current,
    feishuUrl: settings.feishuUrl || current.feishuUrl || "",
    feishuTitle: settings.feishuTitle || "",
    feishuTitleUrl: settings.feishuTitle ? (settings.feishuTitleUrl || settings.feishuUrl || "") : "",
    updatedAt: new Date().toISOString()
  }, null, 2), "utf8");
}

function normalizeRobotStrategy(value) {
  const strategy = String(value || "random").trim();
  return ["random", "fixed", "precise"].includes(strategy) ? strategy : "random";
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

function numberOrDefault(value, fallback) {
  if (value === undefined || value === null || String(value).trim() === "") return fallback;
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function loadedIntervalSettings(consoleSettings = {}) {
  if (consoleSettings.customIntervalsEnabled !== true) {
    return Object.fromEntries(INTERVAL_FIELDS.map((field) => [field, ""]));
  }
  return Object.fromEntries(INTERVAL_FIELDS.map((field) => [field, intervalValueOrEmpty(consoleSettings[field])]));
}

function sanitizeIntervalPresetList(value) {
  if (!Array.isArray(value)) return [];
  const presets = [];
  for (const item of value) {
    if (!item || typeof item !== "object") continue;
    const id = String(item.id || "").trim();
    if (!id) continue;
    const intervals = normalizeIntervalPresetIntervals(item.intervals || {});
    if (!hasAnyVisibleCustomInterval(intervals)) continue;
    presets.push({
      id,
      name: String(item.name || "").trim() || defaultIntervalPresetName(intervals),
      intervals,
      createdAt: String(item.createdAt || "").trim(),
      updatedAt: String(item.updatedAt || "").trim()
    });
  }
  return presets;
}

function normalizeIntervalPresetIntervals(settings = {}) {
  const intervals = Object.fromEntries(INTERVAL_FIELDS.map((field) => [field, ""]));
  for (const field of VISIBLE_INTERVAL_FIELDS) {
    intervals[field] = intervalValueOrEmpty(settings[field]);
  }
  return intervals;
}

function intervalValueOrEmpty(value) {
  if (value === undefined || value === null || String(value).trim() === "") return "";
  const text = String(value).trim();
  return /^\d+$/.test(text) ? Number(text) : text;
}

function buildCustomIntervals(settings = {}) {
  const intervals = {};
  for (const [key, minKey, maxKey] of INTERVAL_GROUPS) {
    if (settings[minKey] === "" && settings[maxKey] === "") continue;
    intervals[key] = { min: settings[minKey], max: settings[maxKey] };
  }
  return intervals;
}

export function validateCustomIntervalSettings(settings = {}) {
  for (const [, minKey, maxKey] of INTERVAL_GROUPS) {
    const minRaw = settings[minKey];
    const maxRaw = settings[maxKey];
    const hasMin = String(minRaw ?? "").trim() !== "";
    const hasMax = String(maxRaw ?? "").trim() !== "";
    if (hasMin !== hasMax) return "自定义间隔的最短和最长要么都填，要么都不填。";
    if (!hasMin) continue;
    if (!positiveInteger(minRaw) || !positiveInteger(maxRaw)) return "自定义间隔只能填写正整数秒数。";
    if (Number(minRaw) > Number(maxRaw)) return "自定义间隔的最短不能大于最长。";
  }
  return "";
}

function hasAnyCustomInterval(settings = {}) {
  return INTERVAL_FIELDS.some((field) => String(settings[field] ?? "").trim() !== "");
}

function hasAnyVisibleCustomInterval(settings = {}) {
  return VISIBLE_INTERVAL_FIELDS.some((field) => String(settings[field] ?? "").trim() !== "");
}

function defaultIntervalPresetName(settings = {}) {
  const pairs = [
    ["不同托", "differentTuoMin", "differentTuoMax"],
    ["同托", "sameTuoMin", "sameTuoMax"],
    ["豆妈连续", "doumaSameMin", "doumaSameMax"],
    ["豆妈托切换", "roleSwitchMin", "roleSwitchMax"]
  ];
  const filled = pairs
    .map(([label, minKey, maxKey]) => ({ label, min: settings[minKey], max: settings[maxKey] }))
    .filter((item) => String(item.min ?? "").trim() !== "" && String(item.max ?? "").trim() !== "");
  if (filled.length === 1) return `${filled[0].label} ${filled[0].min}-${filled[0].max}秒`;
  if (filled.length > 1 && filled.every((item) => item.min === filled[0].min && item.max === filled[0].max)) {
    return `统一间隔 ${filled[0].min}-${filled[0].max}秒`;
  }
  const pad = (value) => String(value).padStart(2, "0");
  const now = new Date();
  return `间隔方案 ${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
}

function positiveInteger(value) {
  return /^\d+$/.test(String(value ?? "").trim()) && Number(value) > 0;
}

function isPlaceholderFeishuTitle(value) {
  return ["待读取", "未读取到标题"].includes(String(value || "").trim());
}

function sameFeishuDocument(left, right) {
  const leftKey = feishuDocumentKey(left);
  const rightKey = feishuDocumentKey(right);
  return Boolean(leftKey && rightKey && leftKey === rightKey);
}

function feishuDocumentKey(value) {
  const text = String(value || "")
    .replace(/[<>]/g, " ")
    .replace(/[“”]/g, "\"")
    .replace(/[‘’]/g, "'")
    .trim();
  if (!text) return "";
  const markdown = text.match(/\((https?:\/\/[^)]+)\)/);
  const source = (markdown?.[1] || text).replace(/\s+/g, "");
  const match = source.match(/https:\/\/([^/]*feishu\.cn)\/(docx|docs|wiki|sheets)\/([^?#\s)\]}；;，,。]+)/i);
  if (!match) return "";
  return `${match[1].toLowerCase()}/${match[2].toLowerCase()}/${match[3]}`;
}

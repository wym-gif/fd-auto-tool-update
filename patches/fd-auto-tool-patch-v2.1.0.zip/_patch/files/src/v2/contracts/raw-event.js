export const RAW_EVENT_KINDS = new Set(["line", "title", "image", "sticker", "video", "divider"]);

export function normalizeRawEvent(event, index = 0) {
  const raw = Object(event || {});
  const kind = String(raw.kind || (raw.isDivider ? "divider" : "line")).trim();
  if (!RAW_EVENT_KINDS.has(kind)) {
    throw new Error(`RawEvent 类型无效：${kind}`);
  }
  return {
    sourceId: String(raw.sourceId || `event-${index + 1}`),
    kind,
    type: String(raw.type || kind),
    text: String(raw.text || ""),
    sourceText: String(raw.sourceText || raw.text || ""),
    highlighted: Boolean(raw.highlighted),
    assetUrl: String(raw.assetUrl || raw.src || ""),
    mediaPath: String(raw.mediaPath || raw.imagePath || ""),
    sourceUrl: String(raw.sourceUrl || raw.originalMediaPath || raw.originalBlobMediaPath || raw.assetUrl || raw.src || ""),
    inlineMediaDataUrl: String(raw.inlineMediaDataUrl || raw.raw?.inlineMediaDataUrl || ""),
    inlineMediaMime: String(raw.inlineMediaMime || raw.raw?.inlineMediaMime || ""),
    materializedHash: String(raw.materializedHash || raw.raw?.materializedHash || ""),
    materializedMime: String(raw.materializedMime || raw.raw?.materializedMime || ""),
    materializedSize: Number.isFinite(Number(raw.materializedSize ?? raw.raw?.materializedSize)) ? Number(raw.materializedSize ?? raw.raw?.materializedSize) : 0,
    collectSpeaker: String(raw.collectSpeaker || raw.raw?.collectSpeaker || ""),
    collectTime: String(raw.collectTime || raw.raw?.collectTime || ""),
    blockIndex: Number.isFinite(Number(raw.blockIndex)) ? Number(raw.blockIndex) : index,
    boundingInfo: normalizeBoundingInfo(raw.boundingInfo || raw.bounds || raw.rect),
    y: Number.isFinite(Number(raw.y)) ? Number(raw.y) : index,
    order: Number.isFinite(Number(raw.order)) ? Number(raw.order) : index,
    raw
  };
}

export function normalizeRawEvents(events = []) {
  return events
    .map((event, index) => normalizeRawEvent(event, index))
    .sort((a, b) => a.order - b.order || a.y - b.y);
}

function normalizeBoundingInfo(value) {
  const box = Object(value || {});
  return {
    x: numberOrZero(box.x),
    y: numberOrZero(box.y),
    width: numberOrZero(box.width ?? box.w),
    height: numberOrZero(box.height ?? box.h)
  };
}

function numberOrZero(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

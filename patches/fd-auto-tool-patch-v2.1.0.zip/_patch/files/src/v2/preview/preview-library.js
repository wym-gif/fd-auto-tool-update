import fs from "node:fs/promises";
import path from "node:path";
import { finalPreviewPath, previewTasksPath, readPreviewTasks, saveFinalPreview } from "./preview-store.js";

const INDEX_FILE = "index.json";
const META_FILE = "library-meta.json";
const SOURCE_FILE = "library-source.json";
const LIBRARY_DIR = "preview-library";
const PROTECTION_FILE = "DO-NOT-DELETE-PREVIEW-LIBRARY.txt";

export function previewLibraryRoot(projectRoot) {
  return path.join(projectRoot, LIBRARY_DIR);
}

export async function listPreviewLibrary(projectRoot) {
  const root = previewLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const fromIndex = normalizeIndex(await readJsonIfExists(path.join(root, INDEX_FILE)));
  const entries = [];
  const seen = new Set();
  for (const item of fromIndex.items) {
    const hydrated = await hydrateItem(root, item).catch(() => null);
    if (!hydrated) continue;
    seen.add(hydrated.id);
    entries.push(hydrated);
  }
  const dirs = await fs.readdir(root, { withFileTypes: true }).catch(() => []);
  for (const entry of dirs) {
    if (!entry.isDirectory() || seen.has(entry.name)) continue;
    const hydrated = await hydrateItem(root, { id: entry.name }).catch(() => null);
    if (hydrated) entries.push(hydrated);
  }
  entries.sort((a, b) => String(b.updatedAt || b.createdAt || "").localeCompare(String(a.updatedAt || a.createdAt || "")));
  await writeIndex(root, entries);
  return entries;
}

export async function savePreviewToLibrary(projectRoot, sourceRunDir, tasks, options = {}) {
  const root = previewLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const existing = options.forceNew === true
    ? null
    : await resolveRunAsLibraryItem(projectRoot, sourceRunDir).catch(() => null);
  if (existing) {
    return updatePreviewLibraryContent(projectRoot, existing.id, tasks, {
      name: options.name || existing.name,
      sourceRunDir
    });
  }
  const now = new Date().toISOString();
  const id = options.id || `preview_${timestampForId(new Date())}_${randomSuffix()}`;
  const itemDir = path.join(root, id);
  await ensureDir(path.join(itemDir, "media-cache"));

  const copiedTasks = await copyPreviewAssets(tasks, sourceRunDir, itemDir);
  await saveFinalPreview(itemDir, copiedTasks, { requireComplete: true });
  await fs.writeFile(previewTasksPath(itemDir), JSON.stringify(copiedTasks, null, 2), "utf8");
  await fs.writeFile(path.join(itemDir, "raw-events.json"), JSON.stringify([], null, 2), "utf8");

  const meta = {
    id,
    name: cleanLibraryName(options.name) || defaultLibraryName(copiedTasks, id),
    createdAt: now,
    updatedAt: now,
    sourceRunDir: path.resolve(sourceRunDir),
    runDir: itemDir,
    previewPath: finalPreviewPath(itemDir),
    taskCount: copiedTasks.length
  };
  await fs.writeFile(path.join(itemDir, META_FILE), JSON.stringify(meta, null, 2), "utf8");

  const items = await listPreviewLibrary(projectRoot);
  const next = [meta, ...items.filter((item) => item.id !== id)];
  await writeIndex(root, next);
  return meta;
}

export async function updatePreviewLibraryContent(projectRoot, id, tasks, options = {}) {
  const root = previewLibraryRoot(projectRoot);
  await ensureLibraryRoot(root);
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const previousMeta = await readJsonIfExists(path.join(item.runDir, META_FILE));
  const now = new Date().toISOString();
  const normalizedName = cleanLibraryName(options.name || previousMeta.name || item.name) || item.name;
  await saveFinalPreview(item.runDir, tasks, { requireComplete: true });
  const savedTasks = await readPreviewTasks(finalPreviewPath(item.runDir));
  await fs.writeFile(previewTasksPath(item.runDir), JSON.stringify(savedTasks, null, 2), "utf8");
  await fs.writeFile(path.join(item.runDir, "raw-events.json"), JSON.stringify([], null, 2), "utf8");
  const meta = {
    ...previousMeta,
    id: item.id,
    name: normalizedName,
    createdAt: previousMeta.createdAt || item.createdAt || now,
    updatedAt: now,
    sourceRunDir: previousMeta.sourceRunDir || path.resolve(options.sourceRunDir || item.runDir),
    runDir: item.runDir,
    previewPath: finalPreviewPath(item.runDir),
    taskCount: savedTasks.length
  };
  await fs.writeFile(path.join(item.runDir, META_FILE), JSON.stringify(meta, null, 2), "utf8");
  await rewriteIndexFromDisk(projectRoot);
  return meta;
}

export async function renamePreviewLibraryItem(projectRoot, id, name) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const metaPath = path.join(item.runDir, META_FILE);
  const previousMeta = await readJsonIfExists(metaPath);
  const nextName = cleanLibraryName(name);
  if (!nextName) throw new Error("文案库名称不能为空。");
  const meta = {
    ...previousMeta,
    id: item.id,
    name: nextName,
    createdAt: previousMeta.createdAt || item.createdAt,
    updatedAt: new Date().toISOString(),
    runDir: item.runDir,
    previewPath: finalPreviewPath(item.runDir),
    taskCount: item.taskCount
  };
  await fs.writeFile(metaPath, JSON.stringify(meta, null, 2), "utf8");
  await rewriteIndexFromDisk(projectRoot);
  return meta;
}

export async function deletePreviewLibraryItem(projectRoot, id) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const root = path.resolve(previewLibraryRoot(projectRoot));
  const itemDir = path.resolve(item.runDir);
  if (!itemDir.startsWith(root + path.sep)) {
    throw new Error("拒绝删除：文案库目录校验失败。");
  }
  const metaPath = path.join(itemDir, META_FILE);
  const metaStat = await fs.stat(metaPath).catch(() => null);
  if (!metaStat?.isFile()) {
    throw new Error("拒绝删除：目标不是有效文案库条目。");
  }
  await fs.rm(itemDir, { recursive: true, force: true });
  await rewriteIndexFromDisk(projectRoot);
  return { id: item.id, name: item.name };
}

export async function resolvePreviewLibraryItem(projectRoot, id) {
  const safeId = safeLibraryId(id);
  if (!safeId) throw new Error("没有指定文案库条目。");
  const root = previewLibraryRoot(projectRoot);
  const item = await hydrateItem(root, { id: safeId });
  return item;
}

export async function resolveRunAsLibraryItem(projectRoot, runDir) {
  const root = path.resolve(previewLibraryRoot(projectRoot));
  const resolved = path.resolve(String(runDir || ""));
  if (!resolved.startsWith(root + path.sep)) return null;
  const id = path.basename(resolved);
  return resolvePreviewLibraryItem(projectRoot, id);
}

export async function resolveRunLibrarySource(projectRoot, runDir) {
  const source = await readJsonIfExists(path.join(runDir, SOURCE_FILE));
  if (!source.id) return null;
  const item = await resolvePreviewLibraryItem(projectRoot, source.id);
  return item;
}

export async function createPreviewLibraryWorkingRun(projectRoot, id) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const runsRoot = path.join(projectRoot, "runs");
  const workDir = path.join(runsRoot, `v2_library_work_${timestampForId(new Date())}_${randomSuffix()}`);
  await ensureDir(workDir);
  await fs.copyFile(finalPreviewPath(item.runDir), finalPreviewPath(workDir));
  await fs.copyFile(previewTasksPath(item.runDir), previewTasksPath(workDir)).catch(async () => {
    const tasks = await readPreviewTasks(finalPreviewPath(item.runDir));
    await fs.writeFile(previewTasksPath(workDir), JSON.stringify(tasks, null, 2), "utf8");
  });
  await fs.copyFile(path.join(item.runDir, "raw-events.json"), path.join(workDir, "raw-events.json")).catch(async () => {
    await fs.writeFile(path.join(workDir, "raw-events.json"), JSON.stringify([], null, 2), "utf8");
  });
  await copyDirIfExists(path.join(item.runDir, "media-cache"), path.join(workDir, "media-cache"));
  const tasks = await readPreviewTasks(finalPreviewPath(workDir));
  const rewritten = tasks.map((task) => rewriteLibraryMediaPathForWorkDir(task, item.runDir, workDir));
  await fs.writeFile(finalPreviewPath(workDir), JSON.stringify(rewritten, null, 2), "utf8");
  await fs.writeFile(previewTasksPath(workDir), JSON.stringify(rewritten, null, 2), "utf8");
  await fs.writeFile(path.join(workDir, SOURCE_FILE), JSON.stringify({
    id: item.id,
    name: item.name,
    sourceRunDir: item.runDir,
    openedAt: new Date().toISOString()
  }, null, 2), "utf8");
  return { ...item, workDir, workPreviewPath: finalPreviewPath(workDir), taskCount: rewritten.length };
}

async function hydrateItem(root, item) {
  const id = safeLibraryId(item?.id);
  if (!id) return null;
  const itemDir = path.join(root, id);
  const meta = await readJsonIfExists(path.join(itemDir, META_FILE));
  const previewPath = finalPreviewPath(itemDir);
  const stat = await fs.stat(previewPath).catch(() => null);
  if (!stat?.isFile()) return null;
  let taskCount = Number(meta.taskCount || item.taskCount || 0);
  if (!taskCount) {
    const tasks = await readPreviewTasks(previewPath).catch(() => []);
    taskCount = tasks.length;
  }
  return {
    id,
    name: cleanLibraryName(meta.name || item.name) || id,
    createdAt: meta.createdAt || item.createdAt || stat.birthtime.toISOString(),
    updatedAt: meta.updatedAt || item.updatedAt || stat.mtime.toISOString(),
    taskCount,
    runDir: itemDir,
    previewPath
  };
}

async function copyPreviewAssets(tasks, sourceRunDir, itemDir) {
  const result = [];
  const usedNames = new Set();
  for (const [index, task] of (Array.isArray(tasks) ? tasks : []).entries()) {
    const next = { ...task };
    const mediaPath = String(next.mediaPath || "").trim();
    if (mediaPath && shouldCopyMedia(mediaPath)) {
      const source = path.resolve(sourceRunDir, mediaPath);
      const stat = await fs.stat(source).catch(() => null);
      if (stat?.isFile()) {
        const destName = uniqueMediaName(mediaPath, index, usedNames);
        const dest = path.join(itemDir, "media-cache", destName);
        await fs.copyFile(source, dest);
        next.mediaPath = dest;
      }
    }
    result.push(next);
  }
  return result;
}

function shouldCopyMedia(mediaPath) {
  if (/^(sample|data|https?|blob|image-blob):/i.test(mediaPath)) return false;
  return Boolean(mediaPath);
}

function uniqueMediaName(mediaPath, index, usedNames) {
  const ext = path.extname(mediaPath) || ".bin";
  const base = path.basename(mediaPath, ext).replace(/[^\w.-]+/g, "_").slice(0, 60) || "media";
  let name = `${String(index + 1).padStart(3, "0")}-${base}${ext}`;
  let attempt = 1;
  while (usedNames.has(name.toLowerCase())) {
    name = `${String(index + 1).padStart(3, "0")}-${base}-${attempt}${ext}`;
    attempt += 1;
  }
  usedNames.add(name.toLowerCase());
  return name;
}

function defaultLibraryName(tasks, fallback) {
  const first = (Array.isArray(tasks) ? tasks : []).find((task) => !task.skip) || tasks?.[0] || {};
  const speaker = String(first.speaker || "").trim();
  const date = String(first.date || "").trim();
  const time = String(first.time || "").trim();
  const text = String(first.text || "").replace(/\s+/g, " ").trim().slice(0, 18);
  return [speaker, date, time, text].filter(Boolean).join(" ") || fallback;
}

function cleanLibraryName(value) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 80);
}

function safeLibraryId(value) {
  const id = String(value || "").trim();
  return /^[a-zA-Z0-9_.-]+$/.test(id) ? id : "";
}

function normalizeIndex(index) {
  return { items: Array.isArray(index?.items) ? index.items : [] };
}

async function writeIndex(root, items) {
  await ensureLibraryRoot(root);
  await fs.writeFile(path.join(root, INDEX_FILE), JSON.stringify({
    updatedAt: new Date().toISOString(),
    items: items.map((item) => ({
      id: item.id,
      name: item.name,
      createdAt: item.createdAt,
      updatedAt: item.updatedAt,
      taskCount: item.taskCount
    }))
  }, null, 2), "utf8");
}

async function rewriteIndexFromDisk(projectRoot) {
  const root = previewLibraryRoot(projectRoot);
  const dirs = await fs.readdir(root, { withFileTypes: true }).catch(() => []);
  const items = [];
  for (const entry of dirs) {
    if (!entry.isDirectory()) continue;
    const hydrated = await hydrateItem(root, { id: entry.name }).catch(() => null);
    if (hydrated) items.push(hydrated);
  }
  items.sort((a, b) => String(b.updatedAt || b.createdAt || "").localeCompare(String(a.updatedAt || a.createdAt || "")));
  await writeIndex(root, items);
  return items;
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true });
}

async function ensureLibraryRoot(root) {
  await ensureDir(root);
  const protectionPath = path.join(root, PROTECTION_FILE);
  await fs.writeFile(protectionPath, [
    "This folder stores saved preview copywriting and media assets.",
    "Do not clean or delete it as part of runs/media-cache cleanup.",
    "Delete items only from the 2.0 console preview library UI.",
    ""
  ].join("\n"), "utf8").catch(() => {});
}

async function copyDirIfExists(sourceDir, destDir) {
  const stat = await fs.stat(sourceDir).catch(() => null);
  if (!stat?.isDirectory()) return;
  await fs.cp(sourceDir, destDir, { recursive: true, force: true });
}

function rewriteLibraryMediaPathForWorkDir(task, sourceRunDir, workDir) {
  const next = { ...task };
  const mediaPath = String(next.mediaPath || "").trim();
  if (!mediaPath || !shouldCopyMedia(mediaPath)) return next;
  const resolved = path.resolve(sourceRunDir, mediaPath);
  const sourceCache = path.resolve(sourceRunDir, "media-cache");
  if (resolved.startsWith(sourceCache + path.sep)) {
    next.mediaPath = path.join(workDir, "media-cache", path.relative(sourceCache, resolved));
  }
  return next;
}

function timestampForId(date) {
  const pad = (value) => String(value).padStart(2, "0");
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    "_",
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds())
  ].join("");
}

function randomSuffix() {
  return Math.random().toString(36).slice(2, 8);
}

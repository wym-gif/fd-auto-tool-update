import { normalizeMessageText } from "../parser/message-text.js";

export async function fillTextWithReadbackGuard(page, expectedText, options = {}) {
  const text = normalizeText(expectedText);
  if (!text) throw new Error("文本输入校验失败：预期文本为空");

  await writeText(page, text, "direct");
  if (await inputMatches(page, text)) return { ok: true, method: "direct" };

  await clearText(page);
  await writeText(page, text, "refill");
  if (await inputMatches(page, text)) return { ok: true, method: "refill" };

  await clearText(page);
  if (!page.writeClipboardText || !page.pasteText) {
    throw new Error("文本输入校验失败：重填后仍不一致，且页面不支持剪贴板兜底");
  }
  await page.writeClipboardText(text);
  await page.pasteText();
  if (await inputMatches(page, text)) return { ok: true, method: "clipboard" };

  const actual = await page.readTextInput();
  throw new Error(`文本输入校验失败：剪贴板兜底后仍不一致，预期 "${compact(text)}"，实际 "${compact(actual)}"`);
}

async function writeText(page, text, method) {
  if (!page.fillTextInput) throw new Error("文本输入校验失败：页面缺少 fillTextInput");
  await page.fillTextInput(text, { method });
}

async function clearText(page) {
  if (!page.clearTextInput) throw new Error("文本输入校验失败：页面缺少 clearTextInput");
  await page.clearTextInput();
}

async function inputMatches(page, expectedText) {
  if (!page.readTextInput) throw new Error("文本输入校验失败：页面缺少 readTextInput");
  const actual = await page.readTextInput();
  return normalizeComparableText(actual) === normalizeComparableText(expectedText);
}

function normalizeText(text) {
  return normalizeMessageText(text);
}

function normalizeComparableText(text) {
  return normalizeText(text).replace(/\s+/g, " ");
}

function compact(text) {
  return String(text || "").replace(/\s+/g, " ").trim().slice(0, 80);
}

import fs from "node:fs/promises";
import path from "node:path";
import { PREVIEW_TASK_REQUIRED_FIELDS, validatePreviewTaskShape } from "../contracts/preview-task.js";
import { loadFinalPreviewForCreate } from "../preview/preview-store.js";
import { findLatestPreviewJsonRun } from "./preview-run-source.js";

export async function findLatestV2PreviewRun(runsRoot) {
  return findLatestPreviewJsonRun(runsRoot);
}

export async function runCreatePreflight(runDir, options = {}) {
  const finalPreview = await loadFinalPreviewForCreate(runDir);
  const tasks = finalPreview.tasks;
  const errors = [];
  const createTasks = [];
  const skippedTasks = [];

  for (const [index, task] of tasks.entries()) {
    try {
      validatePreviewTaskShape(task);
      await validateCreateReadyTask(task, index, { ...options, runDir });
      if (task.skip) skippedTasks.push(task);
      else createTasks.push(task);
    } catch (error) {
      errors.push(error?.message || String(error));
    }
  }

  if (errors.length) {
    throw new Error(`创建前校对失败：${errors.join("；")}`);
  }

  return {
    ok: true,
    source: "preview.json",
    path: finalPreview.path,
    total: tasks.length,
    skipped: skippedTasks.length,
    createCount: createTasks.length,
    tasks,
    createTasks,
    skippedTasks,
    fields: PREVIEW_TASK_REQUIRED_FIELDS
  };
}

export async function validateCreateReadyTask(task, index, options = {}) {
  const label = `第 ${index + 1} 条`;
  if (task.skip) return true;
  if (task.type === "text" || task.type === "finder") {
    if (!String(task.text || "").trim()) {
      throw new Error(`${label} ${task.type === "finder" ? "视频号参数" : "文本"}为空`);
    }
    return true;
  }
  if (task.type === "image" || task.type === "sticker" || task.type === "video") {
    const mediaLabel = `${label} ${task.type}`;
    const mediaPath = String(task.mediaPath || "").trim();
    if (!mediaPath) {
      throw new Error(`${mediaLabel} 素材路径为空`);
    }
    if (isBlobMediaPath(mediaPath)) {
      throw new Error(`${mediaLabel} 是浏览器临时素材地址，不能正式创建，请先在预览页点“更换素材”换成本地文件：${mediaPath}`);
    }
    if (isLocalMediaPath(mediaPath) && options.checkFileExists !== false) {
      const localPath = resolveLocalMediaPath(mediaPath, options.runDir);
      try {
        await fs.access(localPath);
      } catch {
        throw new Error(`${mediaLabel} 素材不存在：${localPath}`);
      }
    }
    return true;
  }
  throw new Error(`${label} 类型无效：${task.type}`);
}

export function buildCreatePreflightReport(result) {
  return [
    "2.0 创建前校对",
    "",
    `创建前校对来源：${result.source}`,
    `文件：${result.path}`,
    `预览总数：${result.total}`,
    `跳过不发：${result.skipped}`,
    `待创建：${result.createCount}`,
    `校对字段：${result.fields.join(" / ")}`,
    "",
    "待创建列表：",
    ...result.createTasks.map((task, index) => formatCreateLine(task, index)),
    "",
    "校对通过：CMS 创建阶段只能使用 preview.json"
  ].join("\n");
}

function formatCreateLine(task, index) {
  const summary = task.type === "text" || task.type === "finder"
    ? compact(task.text)
    : compact(task.mediaPath);
  return `${index + 1}. ${roleLabel(task.role)} / ${task.speaker || ""} / ${task.date || ""} ${task.time || ""} / ${task.type} / ${summary}`;
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "";
}

function compact(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > 46 ? `${text.slice(0, 45)}...` : text;
}

function isLocalMediaPath(mediaPath) {
  if (isBlobMediaPath(mediaPath)) return false;
  if (/^[a-z]+:\/\//i.test(mediaPath)) return false;
  if (/^data:/i.test(mediaPath)) return false;
  return Boolean(mediaPath);
}

function resolveLocalMediaPath(mediaPath, runDir = "") {
  if (path.isAbsolute(mediaPath)) return mediaPath;
  return path.resolve(runDir || process.cwd(), mediaPath);
}

function isBlobMediaPath(mediaPath) {
  return /^blob:/i.test(String(mediaPath || "").trim());
}

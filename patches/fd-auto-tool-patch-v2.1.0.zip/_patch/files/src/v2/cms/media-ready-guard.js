import fs from "node:fs/promises";

export async function ensureMediaReadyBeforeSubmit(page, mediaPath, options = {}) {
  const path = String(mediaPath || "").trim();
  if (!path) throw new Error("媒体校验失败：素材路径为空");
  if (isLocalMediaPath(path)) {
    try {
      await fs.access(path);
    } catch {
      throw new Error(`媒体校验失败：素材不存在：${path}`);
    }
  }
  if (!page.waitForMediaReady) throw new Error("媒体校验失败：页面缺少 waitForMediaReady");
  const timeoutMs = Math.min(options.timeoutMs || 60000, 60000);
  const ready = await page.waitForMediaReady({
    expectedStatus: options.expectedStatus || "极速就绪",
    timeoutMs,
    mediaPath: path,
    taskType: options.taskType || options.type || ""
  });
  if (!ready) throw new Error(`媒体校验失败：素材未就绪：没有等到绿色“极速就绪”：${path}`);
  return { ok: true, mediaPath: path, status: "极速就绪" };
}

function isLocalMediaPath(mediaPath) {
  if (/^[a-z]+:\/\//i.test(mediaPath)) return false;
  if (/^data:/i.test(mediaPath)) return false;
  return Boolean(mediaPath);
}

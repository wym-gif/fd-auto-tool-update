import { parseMonthDay } from "../date/date-rules.js";

export function resolveCmsScheduleDateOption(taskDate, options = {}) {
  const now = resolveNow(options.now);
  const today = startOfLocalDay(now);
  const parsed = parseMonthDay(taskDate);
  if (!parsed) {
    throw new Error(`preview 日期无效：${taskDate || "空"}`);
  }
  const target = dateFromMonthDayNearToday(parsed, today);
  const offset = Math.round((target.getTime() - today.getTime()) / 86400000);
  if (offset < 0) {
    throw new Error(`任务日期已经过去，不能默认选今天硬发：${formatMonthDay(target)} ${options.time || ""}`.trim());
  }
  if (offset > 7) {
    throw new Error(`CMS 定时日期最多支持 +7 天：${formatMonthDay(target)} ${options.time || ""}`.trim());
  }
  return {
    offset,
    day: target.getDate(),
    taskDate: formatMonthDay(target),
    todayDate: formatMonthDay(today),
    optionText: scheduleDateOptionText(offset, target.getDate())
  };
}

export function scheduleDateOptionText(offset, day) {
  if (offset === 0) return `今天(${day}号)`;
  if (offset === 1) return `明天(${day}号)`;
  if (offset === 2) return `后天(${day}号)`;
  return `+${offset}天(${day}号)`;
}

export function verifyCmsScheduleDateSelectedText(text, targetDate) {
  const normalized = String(text || "").replace(/\s+/g, "");
  if (!normalized) return false;
  const prefix = scheduleDateOptionPrefix(targetDate.offset);
  if (!normalized.includes(prefix)) return false;
  const day = `${Number(targetDate.day)}号`;
  if (/\d{1,2}号/.test(normalized) && !normalized.includes(day)) return false;
  return true;
}

function scheduleDateOptionPrefix(offset) {
  if (offset === 0) return "今天";
  if (offset === 1) return "明天";
  if (offset === 2) return "后天";
  return `+${offset}天`;
}

function resolveNow(value) {
  if (typeof value === "function") return new Date(value());
  if (value) return new Date(value);
  return new Date();
}

function startOfLocalDay(value) {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
}

function dateFromMonthDayNearToday(parsed, today) {
  const year = parsed.year || today.getFullYear();
  const date = new Date(year, parsed.month - 1, parsed.day);
  date.setHours(0, 0, 0, 0);
  if (parsed.year) return date;
  const diff = Math.round((date.getTime() - today.getTime()) / 86400000);
  if (diff < -180) date.setFullYear(year + 1);
  if (diff > 180) date.setFullYear(year - 1);
  return date;
}

function formatMonthDay(date) {
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

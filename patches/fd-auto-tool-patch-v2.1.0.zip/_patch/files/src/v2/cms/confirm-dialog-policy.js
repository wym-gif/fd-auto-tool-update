export async function handleRobotNotInGroup({
  page,
  role,
  task,
  policy = "ignore",
  maxRetries = 3,
  switchRobot,
  openConfirmDialog,
  getCurrentSelection,
  log
} = {}) {
  let dialog = await readSubmitConfirmDialog(page);
  if (!dialog.present || !dialog.robotNotInGroup) return { canSubmit: true, dialog, attempts: 0 };

  const normalizedPolicy = normalizePolicy(policy);
  if (normalizedPolicy === "ignore") {
    await log?.({
      event: "robot_not_in_group_ignored",
      taskIndex: task?.index,
      role,
      speaker: task?.speaker || task?.cleanSpeaker || "",
      dialogText: dialog.text
    });
    return { canSubmit: true, dialog, attempts: 0, ignored: true };
  }

  const limit = Math.max(0, Number(maxRetries || 3));
  for (let attempt = 1; attempt <= limit; attempt += 1) {
    if (!dialog.cancelPoint) {
      return stopResult({ role, task, attempts: attempt - 1, dialog, getCurrentSelection, reason: "确认弹窗内没有找到“取消”按钮" });
    }
    await log?.({
      event: "robot_not_in_group_retry",
      taskIndex: task?.index,
      role,
      speaker: task?.speaker || task?.cleanSpeaker || "",
      attempt,
      candidate: nextRobotCandidate(task, attempt),
      dialogText: dialog.text,
      cancelPoint: dialog.cancelPoint
    });
    const cancelResult = await clickCancelAndWaitForClose(page, dialog);
    if (!cancelResult.closed) {
      await log?.({
        event: "robot_not_in_group_cancel_failed",
        taskIndex: task?.index,
        role,
        speaker: task?.speaker || task?.cleanSpeaker || "",
        attempt,
        dialogText: cancelResult.dialog?.text || dialog.text,
        cancelPoint: cancelResult.dialog?.cancelPoint || dialog.cancelPoint,
        reason: cancelResult.reason
      });
      return stopResult({
        role,
        task,
        attempts: attempt - 1,
        dialog: cancelResult.dialog || dialog,
        getCurrentSelection,
        reason: cancelResult.reason || "取消按钮点击后确认弹窗未关闭"
      });
    }
    if (typeof switchRobot !== "function") {
      return stopResult({ role, task, attempts: attempt - 1, dialog, getCurrentSelection, reason: "当前 CMS 页面不支持更换机器人" });
    }
    const candidate = nextRobotCandidate(task, attempt);
    if (hasPreciseCandidates(task) && !candidate) {
      return stopResult({ role, task, attempts: attempt - 1, dialog, getCurrentSelection, reason: "同身份候补托已用完" });
    }
    await switchRobot({ role, task, attempt, dialogText: dialog.text, candidate });
    if (typeof openConfirmDialog !== "function") {
      return stopResult({ role, task, attempts: attempt, dialog, getCurrentSelection, reason: "缺少重新打开确认弹窗的方法" });
    }
    const opened = await openConfirmDialog({ role, task, attempt });
    dialog = opened?.present ? opened : await readSubmitConfirmDialog(page);
    if (!dialog.present) {
      return stopResult({ role, task, attempts: attempt, dialog, getCurrentSelection, reason: "更换机器人后没有重新出现确认创建弹窗" });
    }
    if (!dialog.robotNotInGroup) {
      await log?.({
        event: "robot_not_in_group_switched",
        taskIndex: task?.index,
        role,
        speaker: task?.speaker || task?.cleanSpeaker || "",
        attempt,
        candidate,
        dialogText: dialog.text
      });
      return { canSubmit: true, dialog, attempts: attempt, switched: true };
    }
  }

  await log?.({
    event: "robot_not_in_group_stop",
    taskIndex: task?.index,
    role,
    speaker: task?.speaker || task?.cleanSpeaker || "",
    attempt: limit,
    dialogText: dialog.text
  });
  return stopResult({ role, task, attempts: limit, dialog, getCurrentSelection, reason: "更换机器人后仍检测到机器人不在群" });
}

export function nextRobotCandidate(task = {}, attempt = 1) {
  const candidates = Array.isArray(task?.tuoAssignment?.candidates) ? task.tuoAssignment.candidates : [];
  return candidates[Number(attempt || 1)] || null;
}

function hasPreciseCandidates(task = {}) {
  return task?.tuoAssignment?.mode === "precise_roster" && Array.isArray(task?.tuoAssignment?.candidates);
}

export async function readSubmitConfirmDialog(page) {
  if (!page || typeof page.evaluate !== "function") {
    return { present: false, text: "", robotNotInGroup: false, confirmPoint: null, cancelPoint: null };
  }
  return page.evaluate(() => {
    const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const normalize = (value) => compact(value).replace(/\s+/g, "");
    const visible = (el) => {
      const r = el?.getBoundingClientRect?.();
      const s = el ? getComputedStyle(el) : null;
      return r && r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none"
        && r.left < innerWidth && r.right > 0 && r.top < innerHeight && r.bottom > 0;
    };
    const textOf = (el) => compact(el?.innerText || el?.textContent);
    const dialogSelectors = [
      ".el-message-box",
      ".el-dialog",
      "[role='dialog']",
      ".ant-modal",
      ".modal",
      "[class*='message-box']",
      "[class*='dialog']",
      "[class*='modal']"
    ].join(",");
    const dialogs = Array.from(document.querySelectorAll(dialogSelectors))
      .filter(visible)
      .map((el, order) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return {
          el,
          order,
          zIndex: Number.parseInt(style.zIndex || "0", 10) || 0,
          area: rect.width * rect.height,
          text: textOf(el)
        };
      })
      .filter((item) => {
        const text = normalize(item.text);
        return text.includes("确认创建") || text.includes("确定创建") || /确定要执行发送|当前已选择/.test(item.text);
      });
    dialogs.sort((a, b) => b.zIndex - a.zIndex || b.order - a.order || b.area - a.area);
    if (!dialogs.length) return { present: false, text: "", robotNotInGroup: false, confirmPoint: null, cancelPoint: null };

    const dialog = dialogs[0];
    const buttons = Array.from(dialog.el.querySelectorAll("button,[role='button'],.el-button,a"))
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = textOf(el);
        const normalized = normalize(text);
        return {
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2,
          text,
          normalized,
          blue: elementLooksBlue(el),
          area: rect.width * rect.height,
          top: rect.top
        };
      });
    const confirmLabels = ["确认创建", "确定创建"].map(normalize);
    const cancelLabels = ["取消", "关闭"].map(normalize);
    const confirmCandidates = buttons
      .filter((item) => confirmLabels.some((label) => item.normalized.includes(label)))
      .sort((a, b) => Number(b.blue) - Number(a.blue) || a.area - b.area || b.top - a.top);
    const cancelCandidates = buttons
      .filter((item) => cancelLabels.includes(item.normalized))
      .sort((a, b) => Number(a.blue) - Number(b.blue) || a.area - b.area || b.top - a.top);
    return {
      present: true,
      text: dialog.text.slice(0, 1200),
      robotNotInGroup: /机器人\s*不在群/.test(compact(dialog.text)),
      confirmPoint: confirmCandidates[0] ? { x: confirmCandidates[0].x, y: confirmCandidates[0].y } : null,
      cancelPoint: cancelCandidates[0] ? { x: cancelCandidates[0].x, y: cancelCandidates[0].y } : null
    };

    function elementLooksBlue(el) {
      const className = String(el.className || "");
      if (/primary|blue/i.test(className)) return true;
      const style = getComputedStyle(el);
      const colors = [style.backgroundColor, style.borderColor, style.borderTopColor, style.color]
        .map(parseColor)
        .filter(Boolean);
      return colors.some((color) => color.b >= 120 && color.b > color.r * 1.15 && color.b >= color.g * 0.85);
    }

    function parseColor(value) {
      const text = String(value || "").trim();
      const rgb = text.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (rgb) return { r: Number(rgb[1]), g: Number(rgb[2]), b: Number(rgb[3]) };
      const hex = text.match(/^#([0-9a-f]{6})$/i);
      if (!hex) return null;
      const n = Number.parseInt(hex[1], 16);
      return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    }
  }).catch((error) => ({
    present: false,
    text: error?.message || "",
    robotNotInGroup: false,
    confirmPoint: null,
    cancelPoint: null
  }));
}

async function clickCancelAndWaitForClose(page, dialog) {
  let current = dialog;
  for (let clickAttempt = 1; clickAttempt <= 2; clickAttempt += 1) {
    if (!current?.cancelPoint) {
      return {
        closed: false,
        dialog: current,
        reason: clickAttempt === 1 ? "确认弹窗内没有找到“取消”按钮" : "重新读取弹窗后没有找到“取消”按钮"
      };
    }
    await page.mouse.click(current.cancelPoint.x, current.cancelPoint.y);
    const closed = await waitForSubmitConfirmDialogClosed(page, { timeoutMs: 2500 });
    if (closed) return { closed: true, clickAttempts: clickAttempt };
    current = await readSubmitConfirmDialog(page);
  }
  return {
    closed: false,
    dialog: current,
    reason: "取消按钮点击后确认弹窗未关闭"
  };
}

async function waitForSubmitConfirmDialogClosed(page, { timeoutMs = 2500, intervalMs = 150 } = {}) {
  const started = Date.now();
  while (Date.now() - started <= timeoutMs) {
    await wait(page, intervalMs);
    const latest = await readSubmitConfirmDialog(page);
    if (!latest.present) return true;
  }
  return false;
}

async function stopResult({ role, task, attempts, dialog, getCurrentSelection, reason }) {
  const selection = typeof getCurrentSelection === "function" ? await getCurrentSelection().catch(() => ({})) : {};
  const roleText = role === "douma" ? "豆妈" : "托";
  const speaker = task?.speaker || task?.cleanSpeaker || "";
  const group = selection?.group || selection?.shortcutGroup || selection?.quickGroup || "未识别";
  const message = [
    `第 ${task?.index ?? "?"} 条：机器人不在群处理失败，已停止当前批次。`,
    `role=${roleText}`,
    `speaker=${speaker || "未识别"}`,
    `当前群/快捷分组=${group}`,
    `已尝试更换机器人 ${attempts} 次`,
    `原因=${reason}`,
    `弹窗原始提示=${dialog?.text || "未读取到弹窗文字"}`
  ].join(" / ");
  return { canSubmit: false, needStop: true, attempts, dialog, selection, message };
}

function normalizePolicy(policy) {
  const value = String(policy || "ignore").trim();
  return value === "switch_robot" ? "switch_robot" : "ignore";
}

function wait(page, ms) {
  if (page?.waitForTimeout) return page.waitForTimeout(ms).catch(() => {});
  return new Promise((resolve) => setTimeout(resolve, ms));
}

import { normalizeRawEvents } from "../contracts/raw-event.js";
import { normalizeKeyword } from "./locate-range.js";

const CHINESE_DAY_NUMBERS = new Map([
  ["一", 1],
  ["二", 2],
  ["三", 3],
  ["四", 4],
  ["五", 5],
  ["六", 6],
  ["七", 7],
  ["日", 7],
  ["天", 7]
]);

const RHYTHM_PATTERNS = [
  /(?:早上|早晨|上午|中午|下午|晚上|傍晚|凌晨)?\d{1,2}(?::|：)\d{2}(?:正文|上链接|催单|预热|预告)/,
  /(?:早上|早晨|上午|中午|下午|晚上|傍晚|凌晨)日常晒图/,
  /(?:早上|早晨|上午|中午|下午|晚上|傍晚|凌晨)晒图互动/,
  /(?:早上|早晨|上午|中午|下午|晚上|傍晚|凌晨)?\d{1,2}(?::|：)?\d{0,2}(?:点|点半)?(?:预热|小互动|互动)/,
  /(?:早上|早晨|上午|中午|下午|晚上|傍晚|凌晨)(?:福利单|定时|预热|预告|上图|晒图互动|晒图|小互动|互动)/,
  /福利单之后/,
  /(?:催单|秒杀|预告|上链接|正文|上图|晒图互动|晒图|收到)\d*/,
  /(?:周日休息|休息)/
];

export async function collectHeadingStructureFromPage(page, options = {}) {
  const headings = await collectFeishuOutlineTexts(page, options);
  return buildHeadingStructure(headings);
}

export async function clickFeishuOutlineHeading(page, title, options = {}) {
  const target = String(title || "").trim();
  if (!target) return { ok: false, reason: "未指定目录标题" };
  const settleMs = Number(options.settleMs || 500);
  await openFeishuOutlineIfNeeded(page, options);
  const match = await page.evaluate((targetTitle) => {
    const normalize = (value) => String(value || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/[：]/g, ":")
      .replace(/\s+/g, "");
    const clean = (value) => String(value || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    const visible = (el) => {
      const rect = el.getBoundingClientRect?.();
      const style = getComputedStyle(el);
      return rect && rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
    };
    const directText = (el) => clean(Array.from(el.childNodes || [])
      .filter((node) => node.nodeType === Node.TEXT_NODE)
      .map((node) => node.textContent || "")
      .join(" "));
    const lineCount = (value) => String(value || "").split(/\r?\n/).filter((line) => clean(line)).length;
    const elementSignature = (el) => clean(`${el.className || ""} ${el.id || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("data-testid") || ""} ${el.getAttribute("role") || ""}`);
    const isLeftOutlineGeometry = (el) => {
      const rect = el.getBoundingClientRect?.();
      if (!rect) return false;
      const maxLeft = Math.max(360, window.innerWidth * 0.32);
      const maxRight = Math.max(460, window.innerWidth * 0.42);
      return rect.left <= maxLeft && rect.right <= maxRight && rect.width >= 80 && rect.height >= 80;
    };
    const isExplicitOutlineContainer = (el) => /catalog|outline|toc|目录|大纲|tree/i.test(elementSignature(el));
    const itemText = (el) => {
      const role = el.getAttribute("role") || "";
      const tag = el.tagName || "";
      const attrText = clean(el.getAttribute("aria-label") || el.getAttribute("title") || "");
      const own = directText(el);
      const rawInner = el.innerText || el.textContent || "";
      const signature = elementSignature(el);
      let text = attrText || own;
      if (!text && /^(A|BUTTON)$/i.test(tag)) text = clean(rawInner);
      if (!text && /treeitem|listitem|menuitem|option/i.test(role)) text = clean(rawInner);
      if (!text && /catalog|outline|toc|目录|大纲|tree|item/i.test(signature) && lineCount(rawInner) <= 2) text = clean(rawInner);
      return text && lineCount(text) <= 2 ? text : "";
    };
    const rowsFor = (container) => Array.from(container.querySelectorAll("[role='treeitem'],[role='listitem'],[role='menuitem'],[role='option'],a,button,div,span"))
      .filter(visible)
      .map((el) => ({ el, text: itemText(el) }))
      .filter((item) => item.text);
    const expandToCandidateContainers = (elements) => {
      const output = [];
      const seen = new Set();
      const add = (el) => {
        if (!el || seen.has(el)) return;
        seen.add(el);
        output.push(el);
      };
      for (const el of elements) {
        add(el);
        let current = el.parentElement;
        let depth = 0;
        while (current && depth < 6) {
          if (isLeftOutlineGeometry(current)) add(current);
          current = current.parentElement;
          depth += 1;
        }
      }
      return output;
    };
    const matchedOutlineElements = Array.from(document.querySelectorAll([
      "[data-testid*='catalog' i]",
      "[data-testid*='outline' i]",
      "[data-testid*='toc' i]",
      "[aria-label*='目录' i]",
      "[aria-label*='大纲' i]",
      "[aria-label*='outline' i]",
      "[aria-label*='catalog' i]",
      "[class*='catalog' i]",
      "[class*='outline' i]",
      "[class*='toc' i]",
      "[role='tree']"
    ].join(","))).filter(visible);
    const containers = expandToCandidateContainers(matchedOutlineElements)
      .filter((el) => isLeftOutlineGeometry(el))
      .map((el) => {
        const rows = rowsFor(el);
        return { el, rows, score: (isExplicitOutlineContainer(el) ? 20 : 0) + rows.length };
      })
      .filter((item) => item.rows.length)
      .sort((a, b) => b.score - a.score);
    const target = normalize(targetTitle);
    for (const container of containers) {
      const exact = container.rows.find((item) => normalize(item.text) === target);
      const contained = container.rows.find((item) => normalize(item.text).includes(target) || target.includes(normalize(item.text)));
      const selected = exact || contained;
      if (!selected) continue;
      const clickable = selected.el.closest?.("a,button,[role='treeitem'],[role='listitem'],[role='menuitem'],[role='option'],[class*='item' i],[class*='title' i]") || selected.el;
      const marker = `v2-heading-outline-click-${Date.now()}-${Math.random().toString(16).slice(2)}`;
      clickable.setAttribute("data-v2-heading-outline-click", marker);
      const rect = clickable.getBoundingClientRect();
      return {
        ok: true,
        marker,
        matchedText: selected.text,
        rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
      };
    }
    return { ok: false, reason: "左侧目录里没有找到对应标题" };
  }, target).catch((error) => ({ ok: false, reason: error?.message || String(error) }));

  if (!match.ok || !match.marker) return match;
  const locator = page.locator(`[data-v2-heading-outline-click="${match.marker}"]`).first();
  await locator.click({ timeout: 1200 }).catch(async () => {
    const rect = match.rect || {};
    if (Number.isFinite(rect.x) && Number.isFinite(rect.y)) {
      await page.mouse.click(rect.x + Math.min(24, Math.max(8, rect.width / 4)), rect.y + Math.max(8, rect.height / 2)).catch(() => {});
    }
  });
  await page.waitForTimeout(settleMs).catch(() => {});
  return { ...match, clicked: true };
}

export async function collectFeishuOutlineTexts(page, options = {}) {
  const maxScrolls = Number(options.maxScrolls || 16);
  const settleMs = Number(options.settleMs || 120);
  const pageUrl = typeof page.url === "function" ? page.url() : "";
  const outlineReadyTimeoutMs = Number(options.outlineReadyTimeoutMs ?? (/feishu\.cn/i.test(pageUrl) ? 30000 : 0));
  const outlineReadyPollMs = Number(options.outlineReadyPollMs || 250);
  await openFeishuOutlineIfNeeded(page, options);
  return page.evaluate(async ({ maxScrolls, settleMs, outlineReadyTimeoutMs, outlineReadyPollMs }) => {
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const visible = (el) => {
      const rect = el.getBoundingClientRect?.();
      const style = getComputedStyle(el);
      return rect && rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
    };
    const clean = (value) => String(value || "")
      .replace(/\u200b/g, "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    const lineCount = (value) => String(value || "").split(/\r?\n/).filter((line) => clean(line)).length;
    const directText = (el) => clean(Array.from(el.childNodes || [])
      .filter((node) => node.nodeType === Node.TEXT_NODE)
      .map((node) => node.textContent || "")
      .join(" "));
    const elementSignature = (el) => clean(`${el.className || ""} ${el.id || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("data-testid") || ""} ${el.getAttribute("role") || ""}`);
    const isPlainDateHeading = (text) => {
      const match = clean(text).replace(/\s+/g, "").match(/^(\d{1,2})[\/月](\d{1,2})(?:日|号)?$/);
      if (!match) return false;
      const month = Number(match[1]);
      const day = Number(match[2]);
      return month >= 1 && month <= 12 && day >= 1 && day <= 31;
    };
    const isLeftOutlineGeometry = (el) => {
      const rect = el.getBoundingClientRect?.();
      if (!rect) return false;
      const maxLeft = Math.max(360, window.innerWidth * 0.32);
      const maxRight = Math.max(460, window.innerWidth * 0.42);
      return rect.left <= maxLeft && rect.right <= maxRight && rect.width >= 80 && rect.height >= 120;
    };
    const isExplicitOutlineContainer = (el) => /catalog|outline|toc|目录|大纲|tree/i.test(elementSignature(el));
    const isForbiddenOutlineText = (text) => {
      const value = clean(text);
      const compact = value.replace(/\s+/g, "");
      if (!value) return true;
      if (value.length > 80) return true;
      if (/^https?:\/\//i.test(value)) return true;
      if (isPlainDateHeading(value)) return false;
      if (/^(展开|收起|更多|复制|评论|分享|搜索|今天修改|可见|下载)$/.test(compact)) return true;
      if (/^评论[（(]?\d*[）)]?$/.test(compact)) return true;
      if (/^\d{1,2}\/\d{1,2}\d{1,2}[:：]\d{2}(?:[:：]\d{2})?$/.test(compact)) return true;
      if (/^\d{1,2}\/\d{1,2}\s+\d{1,2}[:：]\d{2}(?:[:：]\d{2})?$/.test(value)) return true;
      if (/^[A-Za-z0-9一-龥_.·-]{1,18}\d{1,2}\/\d{1,2}\d{1,2}[:：]\d{2}(?:[:：]\d{2})?$/.test(compact)) return true;
      if (/^\d{1,4}[:：]\d{2}(?:[:：]\d{2})?$/.test(compact)) return true;
      if (/^\d{1,2}\/\d{1,2}\d{0,6}$/.test(compact)) return true;
      if (/[？?！!，,。；;]/.test(value) && !/(预热|定时|催单|秒杀|预告|上图|晒图|福利单|收到|休息|节奏|朋友圈)/.test(value)) return true;
      if (/[\\[\\]【】]/.test(value) && !/(预热|定时|催单|秒杀|预告|上图|晒图|福利单|收到|休息|节奏|朋友圈)/.test(value)) return true;
      return false;
    };
    const itemText = (el) => {
      const role = el.getAttribute("role") || "";
      const tag = el.tagName || "";
      const attrText = clean(el.getAttribute("aria-label") || el.getAttribute("title") || "");
      const own = directText(el);
      const rawInner = el.innerText || el.textContent || "";
      const signature = elementSignature(el);
      let text = attrText || own;
      if (!text && /^(A|BUTTON)$/i.test(tag)) text = clean(rawInner);
      if (!text && /treeitem|listitem|menuitem|option/i.test(role)) text = clean(rawInner);
      if (!text && /catalog|outline|toc|目录|大纲|tree|item/i.test(signature) && lineCount(rawInner) <= 2) text = clean(rawInner);
      if (!text || lineCount(text) > 2 || isForbiddenOutlineText(text)) return "";
      return text;
    };
    const collectRowsFromContainer = (container) => {
      const items = Array.from(container.querySelectorAll("[role='treeitem'],[role='listitem'],[role='menuitem'],[role='option'],a,button,div,span"))
        .filter(visible);
      const rows = [];
      const accepted = [];
      for (const el of items) {
        const text = itemText(el);
        if (!text) continue;
        const classLevel = String(el.className || el.closest("[class*='heading-'],[class*='indent-level-']")?.className || "").match(/(?:heading|indent-level)-(\d+)/);
        const level = Number(el.getAttribute("aria-level") || el.closest("[aria-level]")?.getAttribute("aria-level") || classLevel?.[1] || "");
        const rect = el.getBoundingClientRect?.();
        const levelValue = Number.isFinite(level) && level > 0 ? level : null;
        const top = rect ? Math.round(rect.top) : null;
        const center = rect ? Math.round(rect.top + rect.height / 2) : null;
        const sameRowDuplicate = accepted.some((item) =>
          item.text === text &&
          item.level === levelValue &&
          Number.isFinite(item.center) &&
          Number.isFinite(center) &&
          Math.abs(item.center - center) <= 12
        );
        if (sameRowDuplicate) continue;
        accepted.push({ text, level: levelValue, center });
        rows.push({
          text,
          level: levelValue,
          top
        });
      }
      return rows;
    };
    const scoreContainer = (el) => {
      if (!isLeftOutlineGeometry(el)) return 0;
      const rows = collectRowsFromContainer(el);
      if (!rows.length) return 0;
      const explicit = isExplicitOutlineContainer(el);
      if (!explicit && rows.length < 2) return 0;
      let score = explicit ? 8 : 2;
      score += Math.min(rows.length, 8);
      if (el.scrollHeight > el.clientHeight + 20) score += 1;
      return score;
    };
    const expandToCandidateContainers = (elements) => {
      const output = [];
      const seen = new Set();
      const add = (el) => {
        if (!el || seen.has(el)) return;
        seen.add(el);
        output.push(el);
      };
      for (const el of elements) {
        add(el);
        let current = el.parentElement;
        let depth = 0;
        while (current && depth < 6) {
          if (isLeftOutlineGeometry(current)) add(current);
          current = current.parentElement;
          depth += 1;
        }
      }
      return output;
    };
    const findBestContainer = () => {
      const matchedOutlineElements = Array.from(document.querySelectorAll([
        "[data-testid*='catalog' i]",
        "[data-testid*='outline' i]",
        "[data-testid*='toc' i]",
        "[aria-label*='目录' i]",
        "[aria-label*='大纲' i]",
        "[aria-label*='outline' i]",
        "[aria-label*='catalog' i]",
        "[class*='catalog' i]",
        "[class*='outline' i]",
        "[class*='toc' i]",
        "[role='tree']"
      ].join(","))).filter(visible);
      const containers = expandToCandidateContainers(matchedOutlineElements);
      return containers
        .map((el) => ({ el, score: scoreContainer(el) }))
        .filter((item) => item.score > 0)
        .sort((a, b) => b.score - a.score)[0]?.el || null;
    };
    const waitForBestContainer = async () => {
      const deadline = Date.now() + Math.max(0, outlineReadyTimeoutMs);
      let latest = null;
      while (Date.now() <= deadline || !latest && outlineReadyTimeoutMs <= 0) {
        latest = findBestContainer();
        if (latest && collectRowsFromContainer(latest).length) return latest;
        if (Date.now() >= deadline) break;
        await sleep(Math.max(50, outlineReadyPollMs));
      }
      return latest;
    };
    const container = await waitForBestContainer();
    if (!container) return [];

    const seen = new Set();
    const rows = [];
    let lastSnapshotSignature = "";
    const collect = () => {
      const snapshot = collectRowsFromContainer(container);
      const snapshotSignature = snapshot.map((item) => `${item.text}|${item.level || ""}`).join("\n");
      if (snapshotSignature && snapshotSignature === lastSnapshotSignature) return;
      lastSnapshotSignature = snapshotSignature;
      for (const item of snapshot) {
        const key = `${item.text}|${item.level || ""}|${item.top ?? ""}`;
        if (seen.has(key)) continue;
        seen.add(key);
        rows.push(item);
      }
    };

    collect();
    for (let i = 0; i < maxScrolls; i += 1) {
      const before = container.scrollTop;
      container.scrollTop = Math.min(container.scrollHeight, container.scrollTop + Math.max(120, container.clientHeight * 0.8));
      await sleep(settleMs);
      if (container.scrollTop === before || container.scrollTop + container.clientHeight >= container.scrollHeight - 4) break;
      collect();
    }
    return rows;
  }, { maxScrolls, settleMs, outlineReadyTimeoutMs, outlineReadyPollMs });
}

async function openFeishuOutlineIfNeeded(page, options = {}) {
  const pageUrl = typeof page.url === "function" ? page.url() : "";
  const isRealFeishuPage = /feishu\.cn/i.test(pageUrl);
  const settleMs = Number(options.outlineOpenSettleMs || (isRealFeishuPage ? 500 : 350));
  const attempts = Number(options.outlineOpenAttempts ?? (isRealFeishuPage ? 60 : 3));
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const result = await page.evaluate(() => {
      const clean = (value) => String(value || "")
        .replace(/\u200b/g, "")
        .replace(/\u00a0/g, " ")
        .replace(/\s+/g, " ")
        .trim();
      const visible = (el) => {
        const rect = el.getBoundingClientRect?.();
        const style = getComputedStyle(el);
        return rect && rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
      };
      const directText = (el) => clean(Array.from(el.childNodes || [])
        .filter((node) => node.nodeType === Node.TEXT_NODE)
        .map((node) => node.textContent || "")
        .join(" "));
      const lineCount = (value) => String(value || "").split(/\r?\n/).filter((line) => clean(line)).length;
      const elementSignature = (el) => clean(`${el.className || ""} ${el.id || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("title") || ""} ${el.getAttribute("data-testid") || ""} ${el.getAttribute("role") || ""}`);
      const isOutlineText = (text) => {
        const value = clean(text);
        return Boolean(value && value.length <= 80 && (
          /第[一二三四五六七日天\d]{1,2}天/.test(value) ||
          /(预热|定时|催单|秒杀|预告|上链接|正文|上图|晒图|福利单|收到|节奏|朋友圈|私人号群发)/.test(value)
        ));
      };
      const hasOpenOutline = () => Array.from(document.querySelectorAll("[data-testid*='catalog' i],[data-testid*='outline' i],[data-testid*='toc' i],[aria-label*='目录' i],[aria-label*='大纲' i],[aria-label*='outline' i],[aria-label*='catalog' i],[class*='catalog' i],[class*='outline' i],[class*='toc' i],[role='tree']"))
        .filter(visible)
        .some((el) => {
          const rect = el.getBoundingClientRect();
          if (rect.left > Math.max(360, window.innerWidth * 0.32) || rect.width < 80 || rect.height < 80) return false;
          const texts = Array.from(el.querySelectorAll("[role='treeitem'],[role='listitem'],a,button,div,span"))
            .map((item) => clean(directText(item) || item.getAttribute("aria-label") || item.getAttribute("title") || ""))
            .filter((text) => text && lineCount(text) <= 2 && isOutlineText(text));
          return texts.length >= 2;
        });
      if (hasOpenOutline()) return { opened: true, clicked: false };
      const toggles = Array.from(document.querySelectorAll("button,[role='button'],a,div,span"))
        .filter(visible)
        .map((el) => {
          const rect = el.getBoundingClientRect();
          const signature = elementSignature(el);
          const text = clean(directText(el) || el.getAttribute("aria-label") || el.getAttribute("title") || "");
          const compact = `${text} ${signature}`.replace(/\s+/g, "");
          const looksLikeToggle = /目录|大纲|catalog|outline|toc|sidebar|侧边栏|菜单|menu/i.test(compact) || /^[☰≡≣三]$/.test(text);
          const geometry = rect.left <= 90 && rect.top >= 60 && rect.top <= Math.max(260, window.innerHeight * 0.45) && rect.width >= 10 && rect.width <= 90 && rect.height >= 10 && rect.height <= 90;
          return { el, rect, text, signature, score: (looksLikeToggle ? 10 : 0) + (geometry ? 5 : 0) };
        })
        .filter((item) => item.score >= 10 || item.score >= 5 && /menu|sidebar|catalog|outline|toc/i.test(item.signature))
        .sort((a, b) => b.score - a.score);
      const selected = toggles[0];
      if (!selected) return { opened: false, clicked: false, reason: "没有找到目录按钮" };
      selected.el.click();
      return { opened: false, clicked: true, text: selected.text, signature: selected.signature };
    }).catch((error) => ({ opened: false, clicked: false, reason: error?.message || String(error) }));
    if (result.opened) return result;
    if (!result.clicked) {
      if ((isRealFeishuPage || options.outlineOpenAttempts) && attempt < attempts - 1) {
        await page.waitForTimeout(settleMs).catch(() => {});
        continue;
      }
      return result;
    }
    await page.waitForTimeout(settleMs).catch(() => {});
  }
  return { opened: false, clicked: true };
}

export function buildHeadingStructure(input = []) {
  const headings = normalizeHeadingInputs(input);
  let currentDay = null;
  const enriched = headings.map((heading, index) => {
    const day = detectDay(heading.text) || currentDay;
    if (detectDay(heading.text)) currentDay = detectDay(heading.text);
    const rhythm = detectRhythm(heading.text, day);
    const skipped = isMomentsHeading(heading.text);
    return {
      ...heading,
      index,
      day: day?.label || "",
      dayNumber: day?.number || null,
      rhythm,
      skipped,
      selectable: Boolean((day || rhythm) && !skipped)
    };
  });
  const selectable = enriched.filter((item) => item.selectable);
  return {
    headings: enriched,
    days: uniqueOptions(selectable.map((item) => item.day).filter(Boolean)),
    rhythms: uniqueOptions(selectable.map((item) => item.rhythm).filter(Boolean)),
    choices: selectable.map((item) => ({
      day: item.day,
      rhythm: item.rhythm,
      title: item.text,
      index: item.index
    })),
    skippedHeadings: enriched.filter((item) => item.skipped).map((item) => item.text)
  };
}

export function resolveHeadingSelection(structure = {}, selection = {}) {
  const headings = Array.isArray(structure.headings) ? structure.headings : [];
  const day = String(selection.headingDay || selection.day || "").trim();
  const rhythm = String(selection.headingRhythm || selection.rhythm || "").trim();
  if (!day) throw new Error("按节奏/天数选择模式必须先选择第几天。");

  const candidates = headings.filter((item) => item.selectable && item.day === day);
  if (!candidates.length) throw new Error(`标题结构里没有找到 ${day}。`);
  const selected = rhythm
    ? candidates.find((item) => item.rhythm === rhythm || item.text === rhythm)
    : candidates[0];
  if (!selected) throw new Error(`标题结构里没有找到 ${day} / ${rhythm}。`);

  const end = rhythm
    ? findNextBoundaryHeading(headings, selected)
    : findNextDayBoundaryHeading(headings, selected);
  return {
    mode: "heading",
    day,
    rhythm,
    startTitle: selected.text,
    endTitle: end?.text || "",
    selectedHeading: selected,
    headingTitles: headings.map((item) => item.text),
    skippedHeadings: headings.filter((item) => item.skipped).map((item) => item.text),
    label: rhythm ? `${day} / ${rhythm}` : day
  };
}

export function locateHeadingRange(rawEvents, resolved = {}) {
  const events = normalizeRawEvents(rawEvents);
  const startMatch = findHeadingEventMatch(events, [resolved.startTitle]);
  const assumedStartBelowTitle = startMatch.index < 0;
  const startExclusive = assumedStartBelowTitle ? 0 : startMatch.index + 1;
  const startTail = assumedStartBelowTitle ? null : eventTextAfterHeading(startMatch.event, startMatch.title);
  const boundary = findSectionBoundary(events, startExclusive, resolved);
  const endExclusive = boundary.index >= 0 ? boundary.index : events.length;
  const sectionEvents = [
    ...(startTail ? [startTail] : []),
    ...events.slice(startExclusive, endExclusive),
    ...(boundary.beforeEvent ? [boundary.beforeEvent] : [])
  ];
  const included = removeSkippedHeadingSections(sectionEvents, resolved.skippedHeadings || [], resolved.headingTitles || []);
  if (!included.length) throw new Error(`按节奏/天数选择后没有读到可发送内容：${resolved.label || resolved.startTitle}`);
  return {
    events: included,
    diagnostics: {
      mode: "heading",
      label: resolved.label || "",
      startTitle: resolved.startTitle || "",
      endTitle: resolved.endTitle || "",
      startMatchedEvent: summarizeEvent(startMatch.event),
      endMatchedEvent: summarizeEvent(boundary.event),
      actualBodyStartEvent: summarizeEvent(included[0]),
      actualBodyEndEvent: summarizeEvent(included.at(-1)),
      stopTitle: boundary.title || resolved.endTitle || "",
      stopReason: boundary.reason || "document_end",
      includedEventCount: included.length,
      skippedMoments: Boolean((resolved.skippedHeadings || []).length),
      assumedStartBelowTitle
    }
  };
}

export function removeSkippedHeadingSections(events = [], skippedHeadings = [], headingTitles = []) {
  const skipped = skippedHeadings.map(normalizeKeyword).filter(Boolean);
  const titles = headingTitles.map(normalizeKeyword).filter(Boolean);
  if (!skipped.length && !titles.length) return events;
  const output = [];
  let skipping = false;
  for (const event of events) {
    const text = normalizeKeyword(event?.text || event?.sourceText || "");
    const skippedMatch = text ? findMatchingHeadingLine(event, skipped) : null;
    const knownMatch = text ? findMatchingHeadingLine(event, titles) : null;
    const isSkippedHeading = Boolean(skippedMatch);
    const isKnownHeading = Boolean(knownMatch);
    if (isSkippedHeading) {
      skipping = true;
      if (skippedMatch.beforeEvent) output.push(skippedMatch.beforeEvent);
      continue;
    }
    if (skipping && (isKnownHeading || hasLikelyHeadingLine(event?.text || event?.sourceText || ""))) {
      skipping = false;
      continue;
    }
    if (isKnownHeading) {
      if (knownMatch.beforeEvent) output.push(knownMatch.beforeEvent);
      continue;
    }
    if (!skipping) output.push(event);
  }
  return output;
}

function normalizeHeadingInputs(input) {
  return input
    .map((item) => typeof item === "string" ? { text: item } : item)
    .map((item) => ({
      text: cleanHeadingText(item?.text),
      level: Number.isFinite(Number(item?.level)) ? Number(item.level) : null
    }))
    .filter((item) => item.text);
}

function detectDay(text) {
  const normalized = cleanCompact(text);
  let match = normalized.match(/第([一二三四五六七日天]|\d{1,2})天/);
  if (!match) match = normalized.match(/^(\d{1,2})[\/月]\d{1,2}(?:日|号)?$/);
  if (!match) return null;
  const raw = match[1];
  const number = /^\d+$/.test(raw) ? Number(raw) : CHINESE_DAY_NUMBERS.get(raw);
  const label = match[0].includes("/") || match[0].includes("月") ? match[0].replace("月", "/").replace(/[日号]/g, "") : `第${toChineseDayNumber(number)}天`;
  return { number, label };
}

function detectRhythm(text, day) {
  if (isMomentsHeading(text)) return "朋友圈（默认跳过）";
  if (isDayContainerHeading(text)) return "";
  let rest = cleanCompact(text);
  if (day?.label) {
    rest = rest.replace(new RegExp(escapeRegExp(day.label)), "");
    if (day.label.includes("/")) {
      rest = rest.replace(new RegExp(escapeRegExp(day.label.replace("/", "月")) + "(?:日|号)?"), "");
    }
  }
  if (!rest) return "";
  rest = rest.replace(/.*?第[一二三四五六七日天\d]{1,2}天(?:节奏)?/, "");
  for (const pattern of RHYTHM_PATTERNS) {
    const match = rest.match(pattern) || cleanCompact(text).match(pattern);
    if (match) return normalizeRhythmLabel(match[0]);
  }
  if (day && rest && rest.length <= 24) return rest;
  return "";
}

function isMomentsHeading(text) {
  const value = cleanDecoratedCompact(text);
  if (!value) return false;
  if (value === "朋友圈") return true;
  return /^(?:\d{1,2}[:：]\d{2})?(?:发朋友圈|私人号群发|同步发朋友圈)$/.test(value);
}

function isDayContainerHeading(text) {
  return /^第[一二三四五六七日天\d]{1,2}天(?:晒图)?节奏$/.test(cleanDecoratedCompact(text));
}

function isLikelyHeadingText(text) {
  const value = cleanCompact(text);
  return Boolean(detectDay(value) || detectRhythm(value, detectDay(value)) || isMomentsHeading(value));
}

function findNextBoundaryHeading(headings, selected) {
  const selectedLevel = Number(selected.level || 0);
  return headings.slice(selected.index + 1).find((item) => {
    if (item.skipped) return false;
    if (selectedLevel && item.level) return item.level <= selectedLevel;
    return isLikelyHeadingText(item.text);
  }) || null;
}

function findNextDayBoundaryHeading(headings, selected) {
  return headings.slice(selected.index + 1).find((item) => item.day && item.day !== selected.day) || null;
}

function findSectionBoundary(events, fromIndex, resolved = {}) {
  const explicitEnd = normalizeKeyword(resolved.endTitle);
  if (explicitEnd) {
    const endMatch = findHeadingEventMatch(events, [resolved.endTitle], fromIndex);
    if (endMatch.index >= 0) return { ...endMatch, reason: "end_title" };
  }
  const knownTitles = (resolved.headingTitles || [])
    .filter((title) => normalizeKeyword(title) && normalizeKeyword(title) !== normalizeKeyword(resolved.startTitle))
    .filter((title) => !isMomentsHeading(title));
  const knownMatch = findHeadingEventMatch(events, knownTitles, fromIndex);
  if (knownMatch.index >= 0) return { ...knownMatch, reason: "known_heading" };
  const likelyMatch = findLikelyHeadingEventMatch(events, fromIndex);
  if (likelyMatch.index >= 0) return { ...likelyMatch, reason: "likely_heading" };
  return { index: -1, event: null, title: "", beforeEvent: null, reason: "document_end" };
}

function findHeadingEventMatch(events, titles = [], fromIndex = 0) {
  const targets = titles.map((title) => ({ title, normalized: normalizeKeyword(title) })).filter((item) => item.normalized);
  if (!targets.length) return { index: -1, event: null, title: "", beforeEvent: null };
  for (let index = Math.max(0, fromIndex); index < events.length; index += 1) {
    const match = findMatchingHeadingLine(events[index], targets);
    if (match) return { index, event: events[index], title: match.title, beforeEvent: match.beforeEvent };
  }
  return { index: -1, event: null, title: "", beforeEvent: null };
}

function findMatchingHeadingLine(event, titlesOrTargets = []) {
  const targets = titlesOrTargets
    .map((item) => typeof item === "string" ? { title: item, normalized: normalizeKeyword(item) } : item)
    .filter((item) => item.normalized);
  if (!event || !targets.length) return null;
  const text = String(event.text || event.sourceText || "");
  const lines = text.split(/\r?\n/);
  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const normalizedLine = normalizeKeyword(lines[lineIndex]);
    if (!normalizedLine) continue;
    const target = targets.find((item) => normalizedLine === item.normalized || normalizedLine.includes(item.normalized) || item.normalized.includes(normalizedLine));
    if (!target) continue;
    return {
      title: target.title,
      lineIndex,
      beforeEvent: eventTextBeforeLine(event, lines, lineIndex)
    };
  }
  return null;
}

function findLikelyHeadingEventMatch(events, fromIndex = 0) {
  for (let index = Math.max(0, fromIndex); index < events.length; index += 1) {
    const text = String(events[index]?.text || events[index]?.sourceText || "");
    const lines = text.split(/\r?\n/);
    for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
      if (!isLikelyHeadingText(lines[lineIndex])) continue;
      return {
        index,
        event: events[index],
        title: cleanHeadingText(lines[lineIndex]),
        beforeEvent: eventTextBeforeLine(events[index], lines, lineIndex)
      };
    }
  }
  return { index: -1, event: null, title: "", beforeEvent: null };
}

function eventTextBeforeLine(event, lines, lineIndex) {
  if (!event || event.kind !== "line" || lineIndex <= 0) return null;
  const text = trimOuterBlankLines(lines.slice(0, lineIndex).join("\n"));
  if (!text) return null;
  return { ...event, text, sourceText: text };
}

function eventTextAfterHeading(event, title) {
  if (!event || event.kind !== "line") return null;
  const target = normalizeKeyword(title);
  if (!target) return null;
  const lines = String(event.text || event.sourceText || "").split(/\r?\n/);
  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const normalizedLine = normalizeKeyword(lines[lineIndex]);
    if (normalizedLine && (normalizedLine === target || normalizedLine.includes(target) || target.includes(normalizedLine))) {
      const text = trimOuterBlankLines(lines.slice(lineIndex + 1).join("\n"));
      return text ? { ...event, text, sourceText: text } : null;
    }
  }
  return null;
}

function hasLikelyHeadingLine(text) {
  return String(text || "").split(/\r?\n/).some((line) => isLikelyHeadingText(line));
}

function uniqueOptions(values) {
  return Array.from(new Set(values)).map((value) => ({ value, label: value }));
}

function cleanHeadingText(value) {
  return String(value || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function cleanCompact(value) {
  return cleanHeadingText(value).replace(/\s+/g, "");
}

function cleanDecoratedCompact(value) {
  return cleanCompact(value).replace(/^[▲△▴▵⚠!！\s]+/, "");
}

function trimOuterBlankLines(text) {
  const lines = String(text || "").split(/\r?\n/);
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines.at(-1).trim()) lines.pop();
  return lines.join("\n");
}

function normalizeRhythmLabel(value) {
  return cleanHeadingText(value).replace(/：/g, ":");
}

function toChineseDayNumber(number) {
  return ["", "一", "二", "三", "四", "五", "六", "七"][number] || String(number);
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function summarizeEvent(event) {
  if (!event) return null;
  return {
    sourceId: event.sourceId,
    kind: event.kind,
    text: event.text,
    sourceText: event.sourceText,
    order: event.order
  };
}

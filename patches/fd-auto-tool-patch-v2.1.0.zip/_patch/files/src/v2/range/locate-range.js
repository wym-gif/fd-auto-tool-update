import { normalizeRawEvents } from "../contracts/raw-event.js";
import { detectChangeDayMarkerEvent } from "../date/date-rules.js";
import { detectRoleHeader } from "../parser/role-header.js";
import { rangeError } from "./range-errors.js";

export function locateRange(rawEvents, range = {}, options = {}) {
  const events = normalizeRawEvents(rawEvents);
  const startKeyword = normalizeKeyword(range.start || "");
  const endKeyword = normalizeKeyword(range.end || "");
  if (!startKeyword) throw rangeError("missing_start_keyword");

  const startMatch = findEventMatch(events, range.start || startKeyword, 0, options);
  const startMatchIndex = startMatch.index;
  if (startMatchIndex < 0) {
    throw rangeError(isAmbiguousMatch(startMatch) ? "ambiguous_start_keyword" : "start_keyword_not_found", {
      keyword: range.start,
      diagnostics: emptyDiagnostics(events, startMatch)
    });
  }

  const startExpandedIndex = expandStartToRoleRecord(events, startMatchIndex, options);
  if (startExpandedIndex < 0) {
    throw rangeError("start_record_not_found", {
      keyword: range.start,
      diagnostics: diagnosticsFromIndexes(events, startMatchIndex, -1, -1, [], null, { startMatch })
    });
  }

  let endMatchIndex = events.length - 1;
  let endMatch = null;
  let endExpandedIndex = events.length - 1;
  if (endKeyword && !range.endAtDocumentEnd) {
    endMatch = findEventMatch(events, range.end || endKeyword, startMatchIndex, options);
    endMatchIndex = endMatch.index;
    if (endMatchIndex < 0) {
      throw rangeError(isAmbiguousMatch(endMatch) ? "ambiguous_end_keyword" : "end_keyword_not_found", {
        keyword: range.end,
        diagnostics: diagnosticsFromIndexes(events, startMatchIndex, startExpandedIndex, -1, [], null, { startMatch, endMatch })
      });
    }
    endExpandedIndex = expandEndToRoleRecord(events, endMatchIndex, options);
  }

  if (endExpandedIndex < startExpandedIndex) {
    throw rangeError("end_before_start", {
      diagnostics: diagnosticsFromIndexes(events, startMatchIndex, startExpandedIndex, endMatchIndex, [], null, { startMatch, endMatch })
    });
  }

  const leadingDayMarker = findPreviousChangeDayMarker(events, startExpandedIndex, options);
  const included = [
    ...(leadingDayMarker ? [leadingDayMarker] : []),
    ...events.slice(startExpandedIndex, endExpandedIndex + 1)
  ];
  if (!included.length) {
    throw rangeError("empty_range", {
      diagnostics: diagnosticsFromIndexes(events, startMatchIndex, startExpandedIndex, endMatchIndex, included, null, { startMatch, endMatch })
    });
  }

  return {
    events: included,
    diagnostics: diagnosticsFromIndexes(events, startMatchIndex, startExpandedIndex, endMatchIndex, included, leadingDayMarker, { startMatch, endMatch })
  };
}

export function findEventIndex(events, keyword, fromIndex = 0) {
  return findEventMatch(events, keyword, fromIndex).index;
}

export function findEventMatch(events, keyword, fromIndex = 0, options = {}) {
  const anchor = parseRangeAnchorKeyword(keyword);
  const searchKeywords = rangeAnchorSearchVariants(anchor);
  const normalizedKeywords = searchKeywords.map(normalizeKeyword).filter(Boolean);
  const structured = Boolean(anchor.time || anchor.date);
  if (structured) {
    const candidates = findRangeAnchorCandidates(events, anchor, fromIndex, options);
    const selected = selectRangeAnchorCandidate(candidates);
    const reason = selected ? "structured_match" : (candidates.length ? "ambiguous_structured_match" : "no_structured_match");
    return {
      index: selected?.index ?? -1,
      anchor,
      searchKeywords,
      candidates: candidates.map(summarizeCandidate),
      selected: selected ? summarizeCandidate(selected) : null,
      reason
    };
  }
  if (!normalizedKeywords.length) {
    return { index: -1, anchor, searchKeywords, candidates: [], selected: null, reason: "empty_keyword" };
  }
  const candidates = [];
  for (let index = Math.max(0, fromIndex); index < events.length; index += 1) {
    const text = eventSearchText(events[index]);
    const matchedKeyword = normalizedKeywords.find((normalizedKeyword) => text.includes(normalizedKeyword));
    if (matchedKeyword) {
      candidates.push({
        index,
        event: events[index],
        score: 1,
        reasons: ["text"],
        header: findPreviousRoleHeaderIndex(events, index, options) >= 0 ? events[findPreviousRoleHeaderIndex(events, index, options)] : null,
        matchedKeyword
      });
    }
  }
  if (candidates.length === 1) {
    const selected = summarizeCandidate(candidates[0]);
    return { index: candidates[0].index, anchor, searchKeywords, candidates: [selected], selected, reason: "text_match" };
  }
  if (candidates.length > 1) {
    return {
      index: -1,
      anchor,
      searchKeywords,
      candidates: candidates.map(summarizeCandidate),
      selected: null,
      reason: "ambiguous_text_match"
    };
  }
  return { index: -1, anchor, searchKeywords, candidates: [], selected: null, reason: "no_text_match" };
}

export function parseRangeAnchorKeyword(value) {
  const original = String(value || "").trim();
  const normalizedOriginal = normalizeKeyword(original);
  const parsed = parseAnchorDateTime(original);
  const date = parsed.date;
  const time = parsed.time;
  const rawBefore = parsed.matched ? original.slice(0, parsed.startIndex).trim() : "";
  const speaker = parsed.matched ? cleanAnchorSpeaker(rawBefore) : "";
  const cleanSpeaker = cleanSpeakerName(speaker);
  return {
    original,
    normalizedOriginal,
    speaker,
    cleanSpeaker,
    date,
    time
  };
}

function parseAnchorDateTime(value) {
  const original = String(value || "");
  const timeMatch = original.match(/(\d{1,2})[：:](\d{2})(?:[：:](\d{2}))?/);
  if (!timeMatch) return { matched: false, startIndex: -1, date: "", time: "" };

  const prefix = original.slice(0, timeMatch.index);
  const explicitDate = prefix.match(/(\d{1,2})\s*[\/月]\s*(\d{1,2})(?:日|号)?\s*$/);
  if (explicitDate) {
    const hour = Number(timeMatch[1]);
    return {
      matched: true,
      startIndex: explicitDate.index,
      date: `${Number(explicitDate[1])}/${Number(explicitDate[2])}`,
      time: normalizeAnchorTime(`${hour}:${timeMatch[2]}:${timeMatch[3] || "00"}`)
    };
  }

  const compactDateTime = prefix.match(/(\d{1,2})[\/月](\d{2,4})$/);
  if (compactDateTime) {
    const month = Number(compactDateTime[1]);
    const tail = compactDateTime[2];
    const splits = tail.length >= 3 ? [2, 1] : [1];
    for (const hourDigits of splits) {
      const dayText = tail.slice(0, tail.length - hourDigits);
      const hourText = tail.slice(tail.length - hourDigits);
      const day = Number(dayText);
      const hour = Number(hourText);
      if (month >= 1 && month <= 12 && day >= 1 && day <= 31 && hour >= 0 && hour <= 23) {
        return {
          matched: true,
          startIndex: compactDateTime.index,
          date: `${month}/${day}`,
          time: normalizeAnchorTime(`${hour}:${timeMatch[2]}:${timeMatch[3] || "00"}`)
        };
      }
    }
  }

  return {
    matched: true,
    startIndex: timeMatch.index,
    date: "",
    time: normalizeAnchorTime(timeMatch[0])
  };
}

export function rangeAnchorSearchVariants(anchorOrValue) {
  const anchor = typeof anchorOrValue === "string" ? parseRangeAnchorKeyword(anchorOrValue) : anchorOrValue || {};
  const variants = [];
  const add = (value) => {
    const text = String(value || "").trim();
    if (text && !variants.includes(text)) variants.push(text);
  };
  const dateTime = [anchor.date, anchor.time].filter(Boolean).join(" ");
  if (anchor.speaker && dateTime) add(`${anchor.speaker} ${dateTime}`);
  if (anchor.cleanSpeaker && dateTime && anchor.cleanSpeaker !== anchor.speaker) add(`${anchor.cleanSpeaker} ${dateTime}`);
  if (anchor.speaker && anchor.time) add(`${anchor.speaker} ${anchor.time}`);
  if (anchor.cleanSpeaker && anchor.time && anchor.cleanSpeaker !== anchor.speaker) add(`${anchor.cleanSpeaker} ${anchor.time}`);
  if (dateTime) add(dateTime);
  if (anchor.time) add(anchor.time);
  add(anchor.original);
  for (const variant of keywordSearchVariants(anchor.original)) add(variant);
  return variants;
}

export function findRangeAnchorCandidates(events, anchorOrValue, fromIndex = 0, options = {}) {
  const normalized = normalizeRawEvents(events);
  const anchor = typeof anchorOrValue === "string" ? parseRangeAnchorKeyword(anchorOrValue) : anchorOrValue || {};
  const candidates = [];
  for (let index = Math.max(0, fromIndex); index < normalized.length; index += 1) {
    const event = normalized[index];
    const headerIndex = isRoleHeader(normalized, index, options) ? index : findPreviousRoleHeaderIndex(normalized, index, options);
    const header = headerIndex >= 0 ? normalized[headerIndex] : null;
    const candidate = scoreRangeAnchorCandidate(normalized, index, header, anchor);
    if (candidate) candidates.push(candidate);
  }
  return candidates;
}

function scoreRangeAnchorCandidate(events, index, header, anchor) {
  const event = events[index];
  const eventText = eventSearchText(event);
  const headerText = eventSearchText(header);
  const nearbyText = eventSearchText(events[index - 1]) + eventSearchText(events[index + 1]);
  const combinedText = `${headerText}${eventText}${nearbyText}`;
  const isHeaderEvent = Boolean(header && index === events.indexOf(header));
  const parsedHeader = parseRangeAnchorKeyword(header?.text || header?.sourceText || "");
  const parsedEvent = parseRangeAnchorKeyword(event?.text || event?.sourceText || "");
  const candidateDate = parsedEvent.date || parsedHeader.date || extractAnchorDate(combinedText);
  const candidateTime = parsedEvent.time || parsedHeader.time || extractAnchorTime(combinedText);
  const headerSpeakerText = normalizeKeyword([parsedHeader.speaker, parsedHeader.cleanSpeaker, header?.text, header?.sourceText].filter(Boolean).join(" "));

  const reasons = [];
  let score = 0;
  if (anchor.time) {
    if (!isHeaderEvent && !eventText.includes(normalizeKeyword(anchor.time))) return null;
    if (candidateTime !== anchor.time && !combinedText.includes(normalizeKeyword(anchor.time))) return null;
    reasons.push("time");
    score += 3;
  }
  if (anchor.date) {
    if (!isHeaderEvent && !anchorDateTextMatches(eventText, anchor.date)) return null;
    const dateMatched = candidateDate === anchor.date || combinedText.includes(normalizeKeyword(anchor.date));
    if (!dateMatched) return null;
    reasons.push("date");
    score += 3;
  }
  if (anchor.speaker || anchor.cleanSpeaker) {
    const speakerCandidates = [anchor.speaker, anchor.cleanSpeaker].map(normalizeKeyword).filter(Boolean);
    const speakerMatched = speakerCandidates.some((speaker) => headerSpeakerText.includes(speaker));
    if (!speakerMatched) return null;
    reasons.push("speaker");
    score += 5;
  }
  const originalMatched = anchor.normalizedOriginal && (eventText.includes(anchor.normalizedOriginal) || headerText.includes(anchor.normalizedOriginal));
  if (originalMatched) {
    reasons.push("original");
    score += 2;
  }
  if (!anchor.time && !anchor.date) return null;
  if (isHeaderEvent) score += 1;
  return {
    index,
    event,
    header,
    date: candidateDate,
    time: candidateTime,
    speaker: parsedHeader.speaker || "",
    cleanSpeaker: parsedHeader.cleanSpeaker || "",
    score,
    reasons
  };
}

function selectRangeAnchorCandidate(candidates = []) {
  if (!candidates.length) return null;
  const sorted = [...candidates].sort((a, b) => b.score - a.score || a.index - b.index);
  const best = sorted[0];
  const tied = sorted.filter((item) => item.score === best.score);
  if (tied.length > 1) {
    if (sameNearbyDuplicateAnchorCandidates(tied)) return best;
    const uniqueHeaders = new Set(tied.map((item) => item.header?.sourceId || (item.header?.order ?? item.index)));
    if (uniqueHeaders.size > 1) return null;
  }
  return best;
}

function sameNearbyDuplicateAnchorCandidates(candidates = []) {
  if (candidates.length < 2) return false;
  const indexes = candidates.map((item) => item.index).sort((a, b) => a - b);
  if (indexes.at(-1) - indexes[0] > 3) return false;
  if (!hasMixedDomDuplicateSources(candidates)) return false;
  const firstKey = duplicateAnchorCandidateKey(candidates[0]);
  if (!firstKey) return false;
  return candidates.every((candidate) => duplicateAnchorCandidateKey(candidate) === firstKey);
}

function hasMixedDomDuplicateSources(candidates = []) {
  const sourceKinds = new Set(candidates.map((candidate) => duplicateSourceKind(candidate?.event?.sourceId)));
  return sourceKinds.has("dom-block") && sourceKinds.has("stable");
}

function duplicateSourceKind(sourceId) {
  const text = String(sourceId || "");
  if (/^dom-block-\d+$/.test(text)) return "dom-block";
  return text ? "stable" : "unknown";
}

function duplicateAnchorCandidateKey(candidate) {
  const eventText = eventSearchText(candidate?.event);
  const headerText = eventSearchText(candidate?.header);
  const identityText = eventText || headerText;
  if (!identityText) return "";
  return [
    identityText,
    candidate.date || "",
    candidate.time || "",
    normalizeKeyword(candidate.speaker || ""),
    normalizeKeyword(candidate.cleanSpeaker || "")
  ].join("|");
}

function summarizeCandidate(candidate) {
  if (!candidate) return null;
  return {
    index: candidate.index,
    score: candidate.score,
    reasons: candidate.reasons || [],
    speaker: candidate.speaker || "",
    cleanSpeaker: candidate.cleanSpeaker || "",
    date: candidate.date || "",
    time: candidate.time || "",
    matchedKeyword: candidate.matchedKeyword || "",
    contextText: candidateContextText(candidate),
    event: summarizeEvent(candidate.event),
    header: summarizeEvent(candidate.header)
  };
}

function candidateContextText(candidate) {
  return [candidate.header?.text || candidate.header?.sourceText, candidate.event?.text || candidate.event?.sourceText]
    .filter(Boolean)
    .join(" / ")
    .slice(0, 240);
}

export function expandStartToRoleRecord(events, startMatchIndex, options = {}) {
  const startEvent = events[startMatchIndex];
  if (!startEvent) return -1;
  if (isRoleHeader(events, startMatchIndex, options)) return startMatchIndex;

  for (let index = startMatchIndex - 1; index >= 0; index -= 1) {
    if (isRoleHeader(events, index, options)) return index;
  }
  return -1;
}

export function expandEndToRoleRecord(events, endMatchIndex, options = {}) {
  const endEvent = events[endMatchIndex];
  if (!endEvent) return -1;
  if (!isRoleHeader(events, endMatchIndex, options)) return endMatchIndex;

  for (let index = endMatchIndex + 1; index < events.length; index += 1) {
    if (isRoleHeader(events, index, options)) return index - 1;
  }
  return events.length - 1;
}

export function isRoleHeader(events, index, options = {}) {
  const event = events[index];
  if (!event || event.kind !== "line") return false;
  const previousHeaderSeen = events.slice(0, index).some((item, itemIndex) => {
    return itemIndex !== index && Boolean(detectRoleHeader(item, {
      ...options,
      allowBareNameHeaders: false,
      allowHighlightedDouma: false
    }));
  });
  return Boolean(detectRoleHeader(event, {
    ...options,
    allowBareNameHeaders: !previousHeaderSeen && options.allowBareNameHeaders !== false,
    allowHighlightedDouma: false
  }) || detectLooseTimedRangeHeader(event));
}

function detectLooseTimedRangeHeader(event) {
  const text = String(event?.text || event?.sourceText || "").replace(/\s+/g, " ").trim();
  if (!text || text.length > 80 || /[。！？!?，,；;]$/.test(text)) return false;
  const anchor = parseRangeAnchorKeyword(text);
  if (!anchor.time || !anchor.date) return false;
  const beforeDate = text.slice(0, text.search(/\d{1,2}\s*[\/月]\s*\d{1,2}/)).trim();
  if (beforeDate.length > 32) return false;
  return true;
}

export function findPreviousChangeDayMarker(events, startIndex, options = {}) {
  const baseDate = options.baseSendDate || options.date || "";
  for (let index = startIndex - 1; index >= 0; index -= 1) {
    const markerDate = detectChangeDayMarkerEvent(events[index], baseDate);
    if (markerDate) {
      return {
        ...events[index],
        rangeContextOnly: true,
        rangeContextDate: markerDate
      };
    }
  }
  return null;
}

export function eventSearchText(event) {
  return normalizeKeyword([
    event?.text,
    event?.sourceText,
    event?.assetUrl,
    event?.mediaPath
  ].filter(Boolean).join(" "));
}

export function normalizeKeyword(value) {
  return String(value || "")
    .replace(/\u200b/g, "")
    .replace(/\u00a0/g, " ")
    .replace(/[：]/g, ":")
    .replace(/\s+/g, "")
    .trim();
}

function keywordSearchVariants(value) {
  const text = String(value || "").trim();
  const variants = [];
  const add = (item) => {
    const normalized = String(item || "").trim();
    if (normalized && !variants.includes(normalized)) variants.push(normalized);
  };
  add(text);
  add(text.replace(/(\d)F(?=装)/gi, "$1斤"));
  add(text.replace(/(\d)斤(?=装)/g, "$1F"));

  const dateTime = text.match(/\d{1,2}\s*\/\s*\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?/);
  if (dateTime) add(dateTime[0]);
  const time = text.match(/\d{1,2}:\d{2}(?::\d{2})?/);
  if (time) add(time[0]);

  return variants;
}

function isAmbiguousMatch(match = {}) {
  return /^ambiguous_/.test(String(match.reason || ""));
}

function diagnosticsFromIndexes(events, startMatchedIndex, startExpandedIndex, endMatchedIndex, included, leadingDayMarker = null, matches = {}) {
  return {
    startMatchedEvent: summarizeEvent(events[startMatchedIndex]),
    startExpandedToEvent: summarizeEvent(events[startExpandedIndex]),
    endMatchedEvent: summarizeEvent(events[endMatchedIndex]),
    leadingDayMarker: summarizeEvent(leadingDayMarker),
    includedEventCount: included.length,
    startAnchor: matches.startMatch?.anchor || null,
    startSearchKeywords: matches.startMatch?.searchKeywords || [],
    startCandidates: matches.startMatch?.candidates || [],
    startSelectedCandidate: matches.startMatch?.selected || null,
    startMatchReason: matches.startMatch?.reason || "",
    endAnchor: matches.endMatch?.anchor || null,
    endSearchKeywords: matches.endMatch?.searchKeywords || [],
    endCandidates: matches.endMatch?.candidates || [],
    endSelectedCandidate: matches.endMatch?.selected || null,
    endMatchReason: matches.endMatch?.reason || ""
  };
}

function emptyDiagnostics(events = [], match = null) {
  return {
    startMatchedEvent: null,
    startExpandedToEvent: null,
    endMatchedEvent: null,
    includedEventCount: 0,
    startAnchor: match?.anchor || null,
    startSearchKeywords: match?.searchKeywords || [],
    startCandidates: match?.candidates || [],
    startSelectedCandidate: match?.selected || null,
    startMatchReason: match?.reason || ""
  };
}

function summarizeEvent(event) {
  if (!event) return null;
  return {
    sourceId: event.sourceId,
    kind: event.kind,
    text: event.text,
    sourceText: event.sourceText,
    mediaPath: event.mediaPath,
    assetUrl: event.assetUrl,
    rangeContextOnly: Boolean(event.rangeContextOnly),
    rangeContextDate: event.rangeContextDate,
    order: event.order
  };
}

function findPreviousRoleHeaderIndex(events, fromIndex, options = {}) {
  for (let index = fromIndex; index >= 0; index -= 1) {
    if (isRoleHeader(events, index, options)) return index;
  }
  return -1;
}

function cleanAnchorSpeaker(value) {
  const text = String(value || "")
    .replace(/^[\s.。·•、,，:：;；-]+/g, "")
    .replace(/[\s.。·•、,，:：;；-]+$/g, "")
    .trim();
  if (!text || /^[.。·•、,，:：;；-]+$/.test(text)) return "";
  if (/^(?:第[一二三四五六七日天\d]+天|今天|明天|后天|上午|下午|晚上|早上|中午|傍晚|凌晨)$/.test(text)) return "";
  return text;
}

function cleanSpeakerName(value) {
  return cleanAnchorSpeaker(value)
    .replace(/[（(][^）)]*[）)]/g, "")
    .trim();
}

function normalizeAnchorTime(value) {
  const match = String(value || "").match(/(\d{1,2})[：:](\d{2})(?:[：:](\d{2}))?/);
  if (!match) return "";
  return `${String(match[1]).padStart(2, "0")}:${match[2]}:${String(match[3] || "00").padStart(2, "0")}`;
}

function extractAnchorTime(value) {
  return normalizeAnchorTime(String(value || ""));
}

function extractAnchorDate(value) {
  const match = String(value || "").match(/(\d{1,2})\s*[\/月]\s*(\d{1,2})(?:日|号)?/);
  if (!match) return "";
  return `${Number(match[1])}/${Number(match[2])}`;
}

function anchorDateTextMatches(normalizedText, date) {
  const match = String(date || "").match(/^(\d{1,2})\/(\d{1,2})$/);
  if (!match) return normalizedText.includes(normalizeKeyword(date));
  const month = Number(match[1]);
  const day = Number(match[2]);
  return [
    `${month}/${day}`,
    `${month}月${day}`,
    `${month}月${day}日`,
    `${month}月${day}号`
  ].some((variant) => normalizedText.includes(normalizeKeyword(variant)));
}

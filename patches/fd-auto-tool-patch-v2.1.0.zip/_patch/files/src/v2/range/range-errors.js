export class RangeLocateError extends Error {
  constructor(code, message, diagnostics = {}) {
    super(message);
    this.name = "RangeLocateError";
    this.code = code;
    this.diagnostics = diagnostics;
  }
}

export function rangeError(code, details = {}) {
  const messages = {
    missing_start_keyword: "没有填写开始关键词。",
    start_keyword_not_found: `没找到开始关键词：${details.keyword || ""}`,
    end_keyword_not_found: `没找到结束关键词：${details.keyword || ""}`,
    ambiguous_start_keyword: `开始位置无法唯一定位：${details.keyword || ""}`,
    ambiguous_end_keyword: `结束位置无法唯一定位：${details.keyword || ""}`,
    start_record_not_found: `找到了开始关键词，但没有确认它属于哪条角色记录：${details.keyword || ""}`,
    end_before_start: "结束关键词在开始关键词之前，范围边界无法确认。",
    empty_range: "找到了范围边界，但中间没有可读取内容。"
  };
  return new RangeLocateError(code, messages[code] || "范围读取失败。", details.diagnostics || {});
}

export function isRangeLocateError(error) {
  return error instanceof RangeLocateError || error?.name === "RangeLocateError";
}


import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createPreviewTask } from "../contracts/preview-task.js";
import { estimateRealtimeStartFromEnd, orderInteractionGroups, schedulePreviewTasks } from "../time/schedule-preview-tasks.js";
import { formatTasksTable } from "./test-parser-cli.js";

export async function runTimeCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runRoot = options.runRoot || path.join(projectRoot, "runs");
  const runDir = path.join(runRoot, options.runName || `v2_time_${timestamp()}`);
  await fs.mkdir(runDir, { recursive: true });

  const doc = schedulePreviewTasks(docModeSampleTasks(), { mode: "doc", phase: "generate-preview" });
  const realtime = schedulePreviewTasks(realtimeSampleTasks(), {
    mode: "realtime",
    phase: "generate-preview",
    startTime: "10:00:00",
    endTime: "10:08:00"
  });
  const catchup = schedulePreviewTasks(catchupSampleTasks(), {
    mode: "catchup",
    phase: "generate-preview",
    currentTime: "09:05:00"
  });
  const interaction = orderInteractionGroups(interactionSampleTasks());
  const reverse = estimateRealtimeStartFromEnd(realtimeSampleTasks(), "10:10:00", {
    phase: "reverse-estimate"
  });

  const output = {
    doc,
    realtime,
    catchup,
    interaction,
    reverse
  };
  await fs.writeFile(path.join(runDir, "scheduled-preview-tasks.json"), JSON.stringify(output, null, 2), "utf8");
  await fs.writeFile(path.join(runDir, "time-diagnostics.json"), JSON.stringify({
    doc: doc.diagnostics,
    catchup: catchup.diagnostics,
    reverse
  }, null, 2), "utf8");

  return buildTimeReport(runDir, output);
}

export function buildTimeReport(runDir, output) {
  return [
    "2.0 时间模块测试",
    "",
    `保存目录：${runDir}`,
    `scheduled-preview-tasks.json：${path.join(runDir, "scheduled-preview-tasks.json")}`,
    `time-diagnostics.json：${path.join(runDir, "time-diagnostics.json")}`,
    "",
    `文档时间：${output.doc.diagnostics.length ? "有诊断" : "通过"}`,
    `实时跟发：${output.realtime.tasks[0].time} -> ${output.realtime.tasks.at(-1).time}`,
    `补发到文档时间：${output.catchup.tasks.map((task) => task.time).join(" / ")}`,
    `互动托排序不改时间：${output.interaction.map((task) => `${task.speaker}-${task.time}`).join(" / ")}`,
    `按结束时间反推开始时间：${output.reverse.predictedStartTime}（只作预测）`,
    "用户预览修改时间优先：通过，preview.json 存在时默认禁止覆盖",
    "创建阶段不调用时间模块：通过，CMS 模块静态测试会检查",
    "",
    "实时跟发 PreviewTask：",
    formatTasksTable(output.realtime.tasks),
    "",
    "时间模块测试完成。"
  ].join("\n");
}

function docModeSampleTasks() {
  return [
    task({ sourceId: "doc-1", speaker: "阿老", time: "09:10:22", text: "有时间角色" }),
    task({ sourceId: "doc-2", speaker: "托1", time: "", text: "无时间角色" })
  ];
}

function realtimeSampleTasks() {
  return [
    task({ sourceId: "rt-1", speaker: "阿老", time: "09:10:22", text: "第一句" }),
    task({ sourceId: "rt-2", speaker: "阿老", time: "09:10:50", text: "同托连续说话" }),
    task({ sourceId: "rt-3", speaker: "阿老啊", time: "09:11:30", text: "不同普通托" }),
    task({ sourceId: "rt-4", speaker: "阿老啊", time: "09:12:00", type: "sticker", mediaPath: "sample://sticker.gif" }),
    task({ sourceId: "rt-5", role: "douma", speaker: "豆妈", time: "09:13:50", text: "豆妈内容" })
  ];
}

function catchupSampleTasks() {
  return [
    task({ sourceId: "cu-1", speaker: "阿老", time: "09:00:00", text: "过期内容" }),
    task({ sourceId: "cu-2", speaker: "阿老", time: "09:03:00", text: "继续补发" }),
    task({ sourceId: "cu-3", speaker: "阿老啊", time: "09:08:00", text: "接回文档时间" })
  ];
}

function interactionSampleTasks() {
  return [
    task({ sourceId: "ia-1", speaker: "托1", time: "12:00:00", text: "A", interactionGroup: "interaction-1", order: 1 }),
    task({ sourceId: "ib-1", speaker: "托2", time: "12:00:45", text: "B", order: 2 }),
    task({ sourceId: "ia-2", speaker: "托1", time: "12:01:30", text: "C", interactionGroup: "interaction-1", order: 3 })
  ];
}

function task(fields) {
  return createPreviewTask({
    sourceId: "",
    sourceText: "",
    role: "tuo",
    speaker: "阿老",
    date: "8/7",
    time: "",
    type: "text",
    text: "",
    mediaPath: "",
    skip: false,
    order: 1,
    interactionGroup: "",
    ...fields
  });
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runTimeCli().then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

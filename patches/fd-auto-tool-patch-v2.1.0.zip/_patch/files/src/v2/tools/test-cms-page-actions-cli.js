import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findLatestV2PageActionSource, runPageActionCheck } from "../cms/page-actions.js";
import { missingPreviewJsonMessage } from "../cms/preview-run-source.js";

export async function runCmsPageActionsCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const runDir = options.runDir || await findLatestV2PageActionSource(runsRoot);
  if (!runDir) {
    return missingPreviewJsonMessage();
  }
  const result = await runPageActionCheck(runDir, options.page || createSafePageProbe(), options.control || {}, options);
  const logPath = path.join(runDir, "page-action-check.log");
  await fs.writeFile(logPath, result.log, "utf8");
  return [
    result.log,
    "",
    `page-action-check.log：${logPath}`
  ].join("\n");
}

export function createSafePageProbe(options = {}) {
  let input = "";
  let clipboard = "";
  let fillCount = 0;
  return {
    submitCount: 0,
    async fillTextInput(text) {
      fillCount += 1;
      input = options.badFillUntil && fillCount <= options.badFillUntil ? `${text}错` : text;
    },
    async clearTextInput() {
      input = "";
    },
    async readTextInput() {
      return input;
    },
    async writeClipboardText(text) {
      clipboard = text;
    },
    async pasteText() {
      input = options.badClipboard ? `${clipboard}错` : clipboard;
    },
    async waitForMediaReady() {
      return options.mediaReady !== false;
    },
    async assertNoRealSubmit() {
      if (options.allowSubmit) this.submitCount += 1;
      if (this.submitCount > 0) throw new Error("页面动作校验失败：禁止点击真实创建/确认按钮");
    }
  };
}

function parseArgs(argv) {
  const runDirIndex = argv.indexOf("--run-dir");
  return {
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : ""
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runCmsPageActionsCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

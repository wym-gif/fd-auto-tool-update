import path from "node:path";
import { fileURLToPath } from "node:url";
import { buildCreateDryRunReport, findLatestV2DryRunSource, runCreateDryRun } from "../cms/create-plan.js";
import { missingPreviewJsonMessage } from "../cms/preview-run-source.js";

export async function runCmsDryRunCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const runDir = options.runDir || await findLatestV2DryRunSource(runsRoot);
  if (!runDir) {
    return missingPreviewJsonMessage();
  }
  const result = await runCreateDryRun(runDir, options);
  return buildCreateDryRunReport(result);
}

function parseArgs(argv) {
  const runDirIndex = argv.indexOf("--run-dir");
  return {
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : ""
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runCmsDryRunCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

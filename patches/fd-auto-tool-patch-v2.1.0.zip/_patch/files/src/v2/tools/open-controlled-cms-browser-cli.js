import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { ensureV2ControlledBrowser } from "../browser/controlled-browser.js";

const DEFAULT_CMS_URL = "https://cms.iyunzk.com/wx/FenWei_rw";

export async function runOpenControlledCmsBrowserCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const config = await loadCmsConfig(projectRoot);
  const url = options.url || options.cmsUrl || config.cmsUrl || DEFAULT_CMS_URL;
  const state = await ensureV2ControlledBrowser({
    projectRoot,
    config,
    url,
    port: options.port,
    profileDir: options.profileDir,
    chromePath: options.chromePath,
    pageKind: options.pageKind
  });

  return [
    "2.0 专用可控浏览器已打开/复用",
    "",
    `浏览器调试地址：${state.cdpUrl}`,
    `浏览器配置目录：${state.profileDir}`,
    `打开地址：${url}`,
    `状态文件：${path.join(projectRoot, "runs", "v2-controlled-cms-browser.json")}`,
    "",
    "控制台、飞书、预览页、云中客页面都会复用这个浏览器上下文。"
  ].join("\n");
}

function parseArgs(argv) {
  const cmsUrlIndex = argv.indexOf("--cms-url");
  const urlIndex = argv.indexOf("--url");
  const portIndex = argv.indexOf("--port");
  const profileIndex = argv.indexOf("--profile-dir");
  return {
    cmsUrl: cmsUrlIndex >= 0 ? argv[cmsUrlIndex + 1] : "",
    url: urlIndex >= 0 ? argv[urlIndex + 1] : "",
    port: portIndex >= 0 ? argv[portIndex + 1] : "",
    profileDir: profileIndex >= 0 ? argv[profileIndex + 1] : "",
    pageKind: argv.includes("--console") ? "console" : ""
  };
}

async function loadCmsConfig(projectRoot) {
  try {
    return JSON.parse(await fs.readFile(path.join(projectRoot, "config.json"), "utf8"));
  } catch {
    return {};
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runOpenControlledCmsBrowserCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

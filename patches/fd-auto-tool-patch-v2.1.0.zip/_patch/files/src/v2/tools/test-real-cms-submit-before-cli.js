import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { buildCreateRunnerReport, findLatestV2RunnerSource, runCreateRunner } from "../cms/create-runner.js";
import { runMediaLocalCheck } from "../cms/media-local-check.js";
import { missingPreviewJsonMessage } from "../cms/preview-run-source.js";
import { createRealCmsSubmitBeforeAdapter, openRealCmsPage } from "../cms/real-cms-adapter.js";

export async function runRealCmsSubmitBeforeCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const runDir = options.runDir || await findLatestV2RunnerSource(runsRoot);
  if (!runDir) return missingPreviewJsonMessage();

  const config = await loadCmsConfig(projectRoot);
  const controlledBrowser = await loadControlledBrowserState(projectRoot, config);
  const mediaManifest = await runMediaLocalCheck(runDir, {
    ...options,
    profileDir: path.resolve(projectRoot, config.profileDir || "./browser-profile")
  });

  let opened;
  try {
    opened = await openRealCmsPage({
      projectRoot,
      cmsUrl: options.cmsUrl || config.cmsUrl,
      cdpUrl: options.cdpUrl || controlledBrowser.cdpUrl,
      profileDir: path.resolve(projectRoot, config.profileDir || "./browser-profile"),
      requireExistingCreatePage: true,
      headless: options.headless === true,
      timeoutMs: options.timeoutMs || 30000
    });
    const adapter = createRealCmsSubmitBeforeAdapter(opened.page, {
      config,
      mediaManifest,
      media: { timeoutMs: options.mediaReadyTimeoutMs || config.mediaReadyTimeoutMs || 90000 },
      roleTargets: options.roleTargets || {}
    });
    const result = await runCreateRunner(runDir, {
      ...options,
      adapter,
      allowRealSubmit: false
    });
    return buildRealCmsSubmitBeforeReport(result, mediaManifest);
  } finally {
    if (opened?.shouldClose !== false) await opened?.context?.close?.().catch(() => {});
  }
}

export function buildRealCmsSubmitBeforeReport(result, mediaManifest) {
  return [
    "2.0 真实 CMS 提交前适配",
    "",
    "来源链路：preview.json -> create-preflight -> create-plan -> media-local-check -> real CMS adapter",
    `preview.json：${result.previewPath}`,
    `预览总数：${result.total}`,
    `跳过不发：${result.skipped}`,
    `待创建：${result.createCount}`,
    `本地媒体：${mediaManifest.checkedCount}`,
    "真实提交：关闭",
    "",
    result.log,
    "",
    "提交前适配完成：没有点击真正创建/确认。"
  ].join("\n");
}

function parseArgs(argv) {
  const runDirIndex = argv.indexOf("--run-dir");
  const cmsUrlIndex = argv.indexOf("--cms-url");
  const cdpUrlIndex = argv.indexOf("--cdp-url");
  return {
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : "",
    cmsUrl: cmsUrlIndex >= 0 ? argv[cmsUrlIndex + 1] : "",
    cdpUrl: cdpUrlIndex >= 0 ? argv[cdpUrlIndex + 1] : "",
    headless: argv.includes("--headless")
  };
}

async function loadCmsConfig(projectRoot) {
  try {
    return JSON.parse(await fs.readFile(path.join(projectRoot, "config.json"), "utf8"));
  } catch {
    return {};
  }
}

async function loadControlledBrowserState(projectRoot, config = {}) {
  const statePath = path.join(projectRoot, "runs", "v2-controlled-cms-browser.json");
  const state = await readJsonIfExists(statePath);
  const port = Number(state.port || config.cmsDebugPort || 9333);
  const cdpUrl = state.cdpUrl || `http://127.0.0.1:${port}`;
  if (await canReachCdp(cdpUrl)) return { cdpUrl, port };
  return {};
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function canReachCdp(cdpUrl) {
  try {
    const response = await fetch(`${cdpUrl.replace(/\/$/, "")}/json/version`, { signal: AbortSignal.timeout(1500) });
    return response.ok;
  } catch {
    return false;
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runRealCmsSubmitBeforeCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

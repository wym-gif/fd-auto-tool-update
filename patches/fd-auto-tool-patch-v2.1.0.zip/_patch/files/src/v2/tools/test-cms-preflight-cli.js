import path from "node:path";
import { fileURLToPath } from "node:url";
import { buildCreatePreflightReport, findLatestV2PreviewRun, runCreatePreflight } from "../cms/create-preflight.js";
import { missingPreviewJsonMessage } from "../cms/preview-run-source.js";

export async function runCmsPreflightCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const runDir = options.runDir || await findLatestV2PreviewRun(runsRoot);
  if (!runDir) {
    return missingPreviewJsonMessage();
  }
  const result = await runCreatePreflight(runDir, options);
  return buildCreatePreflightReport(result);
}

function parseArgs(argv) {
  const runDirIndex = argv.indexOf("--run-dir");
  return {
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : ""
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runCmsPreflightCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createConsoleServer } from "../console/server.js";
import { ensureV2ControlledBrowser } from "../browser/controlled-browser.js";

const DEFAULT_CONSOLE_PORT = 62230;

export async function runConsoleCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const licenseOptions = pickLicenseOptions(options);
  const port = options.port === undefined ? DEFAULT_CONSOLE_PORT : Number(options.port);
  const existingUrl = port > 0 ? `http://127.0.0.1:${port}/` : "";
  const currentService = await buildExpectedServiceInfo(projectRoot);
  if (existingUrl) {
    const reuse = await inspectExistingConsole(existingUrl, currentService);
    if (reuse.action === "reuse") {
      if (options.openBrowser !== false) await openConsoleInControlledBrowser(projectRoot, withControlledFlag(existingUrl));
      return [
        "2.0 可视化控制台已复用",
        "",
        `控制台地址：${existingUrl}`,
        `项目目录：${projectRoot}`,
        "",
        "检测到该端口已有当前版本的 2.0 控制台服务，已直接打开现有页面。"
      ].join("\n");
    }
    if (reuse.action === "blocked") {
      throw new Error(reuse.reason);
    }
    if (reuse.action === "restart") {
      await shutdownExistingConsole(existingUrl);
      await waitForConsoleClosed(existingUrl);
    }
  }

  let server;
  try {
    server = await createConsoleServer(projectRoot, { port, ...licenseOptions });
  } catch (error) {
    if (error?.code === "EADDRINUSE" && existingUrl) {
      throw new Error(`2.0 控制台端口 ${port} 已被占用，但不是可复用的控制台服务。请关闭占用该端口的程序后重试。`);
    }
    throw error;
  }
  if (options.openBrowser !== false) await openConsoleInControlledBrowser(projectRoot, withControlledFlag(server.url));
  return [
    "2.0 可视化控制台已启动",
    "",
    `控制台地址：${server.url}`,
    `项目目录：${projectRoot}`,
    "",
    "规则：控制台只编排流程，采集/解析/时间/预览/CMS 仍由各自模块执行。",
    "正式入口会隐藏后台服务窗口；调试入口可保留此窗口查看原始日志。",
    "使用结束后可在页面点击“退出”关闭控制台服务。"
  ].join("\n");
}

function pickLicenseOptions(options = {}) {
  return {
    licenseFetch: options.licenseFetch,
    fetch: options.licenseFetch,
    licenseConfig: options.licenseConfig,
    appVersion: options.appVersion
  };
}

function parseArgs(argv = []) {
  const portIndex = argv.indexOf("--port");
  return {
    port: portIndex >= 0 ? Number(argv[portIndex + 1]) : undefined,
    openBrowser: !argv.includes("--no-open")
  };
}

async function isConsoleServerAlive(url) {
  try {
    const status = await requestJson(new URL("api/status", url));
    return status?.ok === true && status?.state && typeof status.state.step === "string";
  } catch {
    return false;
  }
}

async function inspectExistingConsole(url, expectedService) {
  const status = await readExistingStatus(url);
  if (!status?.ok) return { action: "start" };
  const busy = ["running", "paused"].includes(status.state?.status);
  const service = await readExistingServiceInfo(url);
  const sameService = service?.protocol === expectedService.protocol
    && samePath(service.projectRoot) === samePath(expectedService.projectRoot)
    && String(service.codeRevision || "") === String(expectedService.codeRevision || "");
  if (sameService) return { action: "reuse" };
  if (busy) {
    return {
      action: "blocked",
      reason: "检测到旧版控制台后台仍在运行任务，不能自动重启。请先在控制台停止当前流程或点击退出后再重新打开。"
    };
  }
  return { action: "restart" };
}

async function readExistingStatus(url) {
  try {
    const status = await requestJson(new URL("api/status", url));
    return status?.ok === true && status?.state && typeof status.state.step === "string" ? status : null;
  } catch {
    return null;
  }
}

async function readExistingServiceInfo(url) {
  try {
    const info = await requestJson(new URL("api/service-info", url));
    return info?.ok === true ? info.service : null;
  } catch {
    return null;
  }
}

async function shutdownExistingConsole(url) {
  await postJson(new URL("api/shutdown", url), {});
}

async function waitForConsoleClosed(url, timeoutMs = 5000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (!await isConsoleServerAlive(url)) return;
    await new Promise((resolve) => setTimeout(resolve, 150));
  }
  throw new Error("旧版控制台后台未能关闭，已停止启动新服务。请先点击控制台退出或结束旧后台进程后重试。");
}

function requestJson(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { timeout: 1200 }, (res) => {
      let body = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { body += chunk; });
      res.on("end", () => {
        try {
          resolve(JSON.parse(body || "{}"));
        } catch (error) {
          reject(error);
        }
      });
    });
    req.on("timeout", () => {
      req.destroy(new Error("timeout"));
    });
    req.on("error", reject);
  });
}

function postJson(url, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body || {});
    const req = http.request(url, {
      method: "POST",
      timeout: 1500,
      headers: {
        "content-type": "application/json",
        "content-length": Buffer.byteLength(data)
      }
    }, (res) => {
      let responseBody = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { responseBody += chunk; });
      res.on("end", () => {
        try {
          resolve(JSON.parse(responseBody || "{}"));
        } catch (error) {
          reject(error);
        }
      });
    });
    req.on("timeout", () => {
      req.destroy(new Error("timeout"));
    });
    req.on("error", reject);
    req.end(data);
  });
}

async function buildExpectedServiceInfo(projectRoot) {
  return {
    protocol: "v2-console-service-v2-license",
    projectRoot: path.resolve(projectRoot),
    codeRevision: await readGitRevision(projectRoot)
  };
}

async function readGitRevision(projectRoot) {
  try {
    const gitDir = path.join(projectRoot, ".git");
    const head = String(await fs.readFile(path.join(gitDir, "HEAD"), "utf8")).trim();
    if (head.startsWith("ref:")) {
      const refPath = head.slice(5).trim().replace(/\//g, path.sep);
      return String(await fs.readFile(path.join(gitDir, refPath), "utf8")).trim();
    }
    return head;
  } catch {
    return "";
  }
}

function samePath(value) {
  return path.resolve(String(value || "")).toLowerCase();
}

async function openConsoleInControlledBrowser(projectRoot, url) {
  const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
  await ensureV2ControlledBrowser({ projectRoot, config, url, pageKind: "console" });
}

function withControlledFlag(url) {
  const parsed = new URL(url);
  parsed.searchParams.set("controlled", "1");
  return parsed.toString();
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runConsoleCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

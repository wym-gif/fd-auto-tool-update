import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { collectRawEventsFromPageWithDiagnostics, materializeRawEventMediaFromPage, summarizeRawEvents, validateCollectedRawEvents } from "../feishu/collector.js";
import { isFeishuCollectError } from "../feishu/collect-errors.js";
import { collectError } from "../feishu/collect-errors.js";
import { normalizeFeishuUrl, openRealFeishuCollectPage } from "../feishu/page-controller.js";
import { locateRange } from "../range/locate-range.js";
import { isRangeLocateError } from "../range/range-errors.js";
import { parseFixedFormatTasks } from "../parser/parse-fixed-format.js";
import { validatePreviewTaskShape } from "../contracts/preview-task.js";
import { buildPreviewScheduleOptions, preparePreviewTasksForGeneration } from "../time/schedule-preview-tasks.js";
import { buildFlowReport } from "./test-collect-range-parse-cli.js";

export async function runRealCollectRangeParseCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runRoot = options.runRoot || path.join(projectRoot, "runs");
  const runDir = path.join(runRoot, options.runName || `v2_real_flow_${timestamp()}`);
  const settings = await loadSettings(projectRoot);
  const url = normalizeFeishuUrl(options.url || settings.url);
  const range = buildRange(options);
  const checks = buildChecks(options, range);
  let opened;

  try {
    if (!range.start) {
      throw new Error("请提供开始关键词。真实串联测试必须先明确开始位置。");
    }

    await fs.mkdir(runDir, { recursive: true });
    opened = options.openPage ? await options.openPage() : await openRealFeishuCollectPage({
      url,
      profileDir: path.resolve(projectRoot, settings.profileDir || "./browser-profile"),
      headless: options.headless === true,
      timeoutMs: options.timeoutMs || 30000
    });
    if (options.waitMs !== 0) {
      await opened.page.waitForTimeout(options.waitMs || 2500);
    }

    const collected = await collectRawEventsFromPageWithDiagnostics(opened.page, {
      scanFullPage: options.scanFullPage !== false,
      stepPixels: options.stepPixels,
      waitMs: options.scanWaitMs,
      maxSteps: options.maxSteps,
      startKeyword: range.start,
      endKeyword: range.endAtDocumentEnd ? "" : range.end,
      deferMediaMaterialization: true,
      mediaCacheDir: path.join(runDir, "media-cache")
    });
    await saveJson(path.join(runDir, "collect-diagnostics.json"), collected.diagnostics);
    if (collected.diagnostics?.failure) {
      throw collectError("missing_end_keyword_after_scroll", collected.diagnostics.failure);
    }
    const rawEvents = validateCollectedRawEvents(collected.events, {
      ...checks,
      allowTemporaryMedia: true
    });
    await saveJson(path.join(runDir, "raw-events.json"), rawEvents);

    const rangeResult = locateRange(rawEvents, range, options.rangeOptions || {});
    const rangeEvents = validateCollectedRawEvents(await materializeRawEventMediaFromPage(opened.page, rangeResult.events, {
      mediaCacheDir: path.join(runDir, "media-cache")
    }), {
      requireLocalMedia: true
    });
    await saveJson(path.join(runDir, "range-events.json"), rangeEvents);
    await saveJson(path.join(runDir, "range-diagnostics.json"), rangeResult.diagnostics);

    const scheduleOptions = buildPreviewScheduleOptions(settings, options);
    const parsed = parseFixedFormatTasks(rangeEvents, {
      scheduleMode: scheduleOptions.mode,
      ...options.parseOptions
    });
    const prepared = preparePreviewTasksForGeneration(parsed.tasks, scheduleOptions);
    for (const task of prepared.tasks) validatePreviewTaskShape(task);
    await saveJson(path.join(runDir, "preview-tasks.json"), prepared.tasks);

    return [
      "2.0 真实采集 -> 范围 -> 固定解析串联输出",
      "",
      `文档标题：${opened.title || "未读取到标题"}`,
      `文档地址：${opened.page.url()}`,
      "",
      formatCollectDiagnostics(collected.diagnostics),
      "",
      buildFlowReport({
        runDir,
        rawEvents,
        range,
        rangeResult: { ...rangeResult, events: rangeEvents },
        tasks: prepared.tasks,
        diagnostics: [...parsed.diagnostics, ...prepared.diagnostics],
        schedule: prepared
      }),
      "",
      "说明：本入口不会写 preview.json，不打开预览页，不创建 CMS 任务。"
    ].join("\n");
  } catch (error) {
    if (isFeishuCollectError(error) || isRangeLocateError(error)) {
      await saveFlowError(runDir, error);
      return `${error.message}\n失败目录：${runDir}\n真实串联测试已停止，没有生成缺内容 PreviewTask。`;
    }
    throw error;
  } finally {
    await opened?.context?.close?.().catch(() => {});
    await opened?.browser?.close?.().catch(() => {});
  }
}

export function formatCollectDiagnostics(diagnostics = {}) {
  const logs = Array.isArray(diagnostics.logs) ? diagnostics.logs : [];
  const keywordJumps = Array.isArray(diagnostics.keywordJumps) ? diagnostics.keywordJumps : [];
  const last = diagnostics.lastEvent || {};
  return [
    "采集 diagnostics:",
    ...keywordJumps.map((item) => `- 关键词定位(${item.label || ""})：${item.foundVisibleAfterJump ? "成功" : "未成功"}，查找框：${item.openedFindBox ? "已打开" : "未打开"}，原因：${item.reason || ""}`),
    ...keywordJumps.flatMap(formatKeywordSearchTrace),
    `- 滚动次数：${diagnostics.scrollCount ?? 0}`,
    `- 当前采集条数：${diagnostics.collectedEventCount ?? 0}`,
    `- 是否找到开始关键词：${formatBoolean(diagnostics.foundStartKeyword)}`,
    `- 是否找到结束关键词：${formatBoolean(diagnostics.foundEndKeyword)}`,
    `- 最后一条采集内容：${last.text || last.mediaPath || ""}`,
    `- 停止原因：${diagnostics.stoppedBecause || ""}`,
    `- 采集日志条数：${logs.length}`
  ].join("\n");
}

function formatKeywordSearchTrace(jump = {}) {
  const traces = Array.isArray(jump.searchTrace) ? jump.searchTrace : [];
  const label = jump.label === "start" ? "开始" : (jump.label === "end" ? "结束" : "关键词");
  return traces.map((item) => {
    const details = [
      item.url ? `url=${item.url}` : "",
      item.title ? `标题=${item.title}` : "",
      item.point ? `点击=(${Math.round(Number(item.point.x) || 0)},${Math.round(Number(item.point.y) || 0)})` : "",
      item.text ? `文字=${String(item.text).slice(0, 80)}` : "",
      item.candidateCount !== undefined ? `候选=${item.candidateCount}` : "",
      item.inputValue !== undefined ? `输入=${String(item.inputValue).slice(0, 80)}` : "",
      item.visibleTextContainsKeyword !== undefined && item.visibleTextContainsKeyword !== null ? `可见包含关键词=${item.visibleTextContainsKeyword ? "是" : "否"}` : ""
    ].filter(Boolean).join("；");
    return `  - 搜索阶段(${label}/${item.index || "-"})：${item.message || item.stage || ""}${details ? `；${details}` : ""}`;
  });
}

function formatBoolean(value) {
  if (value === null || value === undefined) return "未指定";
  return value ? "是" : "否";
}

export function parseArgs(argv = []) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    const next = argv[index + 1];
    if (arg === "--url") {
      options.url = next;
      index += 1;
    } else if (arg === "--start") {
      options.startKeyword = next;
      index += 1;
    } else if (arg === "--end") {
      options.endKeyword = next;
      index += 1;
    } else if (arg === "--end-at-document-end") {
      options.endAtDocumentEnd = true;
    } else if (arg === "--require-first-image") {
      options.requireFirstImage = true;
    } else if (arg === "--require-sticker") {
      options.requireSticker = true;
    } else if (arg === "--require-video") {
      options.requireVideo = true;
    } else if (arg === "--schedule-mode") {
      options.scheduleMode = next;
      index += 1;
    } else if (arg === "--realtime-start") {
      options.realtimeStartTime = next;
      index += 1;
    } else if (arg === "--realtime-end") {
      options.realtimeEndTime = next;
      index += 1;
    } else if (arg === "--current-time") {
      options.currentTime = next;
      index += 1;
    } else if (arg === "--visible-only") {
      options.scanFullPage = false;
    } else if (arg === "--headless") {
      options.headless = true;
    } else if (arg === "--max-steps") {
      options.maxSteps = Number(next);
      index += 1;
    }
  }
  return options;
}

async function loadSettings(projectRoot) {
  const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
  const lastSettings = await readJsonIfExists(path.join(projectRoot, "last-settings.json"));
  return {
    ...config,
    url: normalizeFeishuUrl(lastSettings.feishuUrl) || normalizeFeishuUrl(config.feishuUrl),
    profileDir: config.profileDir || "./browser-profile"
  };
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

function buildRange(options) {
  return {
    start: String(options.startKeyword || "").trim(),
    end: String(options.endKeyword || "").trim(),
    endAtDocumentEnd: Boolean(options.endAtDocumentEnd || !String(options.endKeyword || "").trim())
  };
}

function buildChecks(options, range) {
  const checks = {};
  if (range.start) checks.startKeyword = range.start;
  if (range.end && !range.endAtDocumentEnd) checks.endKeyword = range.end;
  if (options.requireFirstImage) checks.requireFirstImage = true;
  if (options.requireSticker) checks.requireSticker = true;
  if (options.requireVideo) checks.requireVideo = true;
  return checks;
}

async function saveJson(filePath, value) {
  await fs.writeFile(filePath, JSON.stringify(value, null, 2), "utf8");
}

async function saveFlowError(runDir, error) {
  try {
    await fs.mkdir(runDir, { recursive: true });
    await saveJson(path.join(runDir, "flow-error.json"), {
      ok: false,
      code: error?.code || error?.name || "error",
      message: error?.message || String(error),
      failedAt: new Date().toISOString()
    });
  } catch {
    // The console report still carries the failure; do not hide the original error.
  }
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runRealCollectRangeParseCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
    if (isStoppedReport(report)) process.exitCode = 1;
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

function isStoppedReport(report) {
  return /已停止|飞书采集不完整|范围定位失败|没有生成缺内容 PreviewTask/.test(String(report || ""));
}

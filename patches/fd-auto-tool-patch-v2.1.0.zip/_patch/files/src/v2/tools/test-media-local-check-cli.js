import path from "node:path";
import { fileURLToPath } from "node:url";
import { buildMediaLocalCheckReport, runMediaLocalCheck } from "../cms/media-local-check.js";
import { missingPreviewJsonMessage, findLatestPreviewJsonRun } from "../cms/preview-run-source.js";

export async function runMediaLocalCheckCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const runDir = options.runDir || await findLatestPreviewJsonRun(runsRoot);
  if (!runDir) {
    return missingPreviewJsonMessage();
  }
  const result = await runMediaLocalCheck(runDir, options);
  return buildMediaLocalCheckReport(result);
}

function parseArgs(argv) {
  const runDirIndex = argv.indexOf("--run-dir");
  return {
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : ""
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runMediaLocalCheckCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

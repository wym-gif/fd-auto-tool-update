import fs from "node:fs/promises";
import path from "node:path";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { fileURLToPath } from "node:url";
import { findLatestV2RunnerSource, runCreateRunner } from "../cms/create-runner.js";
import { runCreateDryRun } from "../cms/create-plan.js";
import { runMediaLocalCheck } from "../cms/media-local-check.js";
import { missingPreviewJsonMessage } from "../cms/preview-run-source.js";
import { createRealCmsSubmitBeforeAdapter, openRealCmsCreatePages, pageLooksLikeCreateForm, readCurrentCmsSelection } from "../cms/real-cms-adapter.js";
import { assertCompanyAccessAllowed } from "../license/license-manager.js";

const CMS_PAGE_BINDINGS_FILE = "cms-page-bindings.json";

export async function runRealCmsCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  await assertCompanyAccessAllowed(projectRoot, "cli-start-cms", options);
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const runDir = options.runDir || await findLatestV2RunnerSource(runsRoot);
  if (!runDir) return missingPreviewJsonMessage();

  const config = {
    ...await loadCmsConfig(projectRoot),
    ...(options.robotStrategy ? { tuoMode: options.robotStrategy } : {})
  };
  const controlledBrowser = await loadControlledBrowserState(projectRoot, config);
  await reportProgress(options, "正式创建准备：正在生成创建计划。");
  const dryRun = await runCreateDryRun(runDir, options);
  const useAllPreviewTasks = options.useAllPreviewTasks === true;
  const fullBatch = options.fullBatch === true;
  const batchSize = normalizedBatchSize(options);
  const batchMode = useAllPreviewTasks || fullBatch || batchSize > 1;
  const limitedDryRun = useAllPreviewTasks || fullBatch ? limitDryRunToAll(dryRun) : batchMode ? limitDryRunToMixedBatch(dryRun, batchSize) : limitDryRunToFirstTask(dryRun);
  if (!limitedDryRun.plan.length) throw new Error("正式运行已停止：preview.json 里没有待创建任务。");
  const requiredRoles = requiredRolesForTasks(limitedDryRun.plan);
  await reportProgress(options, `正式创建准备：创建计划已生成，待创建 ${limitedDryRun.plan.length} 条，正在校验本地素材。`);

  const mediaManifest = await runMediaLocalCheck(runDir, {
    ...options,
    includeSourceIds: limitedDryRun.plan.map((task) => task.sourceId),
    profileDir: path.resolve(projectRoot, config.profileDir || "./browser-profile")
  });
  await reportProgress(options, "正式创建准备：本地素材校验通过，正在复用云中客页面。");
  const cdpUrl = options.cdpUrl || controlledBrowser.cdpUrl;
  if (!options.preparedCmsPages && !cdpUrl && options.noLaunchBrowser) {
    throw new Error("正式创建需要复用可控制的云中客页面，但当前没有检测到 2.0 受控浏览器/CDP 连接。已停止，且不会启动新的浏览器 profile。");
  }
  await assertCurrentRunBindings(runDir, dryRun);

  let opened;
  try {
    opened = options.preparedCmsPages || await openRealCmsCreatePages({
      projectRoot,
      cmsUrl: options.cmsUrl || config.cmsUrl,
      cdpUrl,
      profileDir: path.resolve(projectRoot, config.profileDir || "./browser-profile"),
      requireExistingCreatePage: true,
      requiredRoles,
      headless: options.headless === true,
      timeoutMs: options.timeoutMs || 30000
    });
    await reportProgress(options, `正式创建准备：已复用 ${opened.pages?.length || 0} 个云中客创建页，正在读取当前群和机器人。`);
    const pageInfos = await readCmsPageInfos(opened.pages, options);
    await reportProgress(options, "正式创建准备：CMS 页面信息读取完成，正在绑定托/豆妈页面。");
    const pageBindings = await resolveCmsPageBindings(pageInfos, requiredRoles, config, options);
    await markCmsBindingsForRun(runDir, pageBindings);
    const bindingState = await saveCmsPageBindings(runDir, pageBindings, {
      source: "start-cms",
      runId: dryRun.runId
    });
    assertBindingStateMatchesRun(runDir, dryRun, bindingState);
    await reportProgress(options, "正式创建准备：托/豆妈页面绑定完成，正在做最后创建确认。");
    const pageSelections = Object.fromEntries(Object.entries(pageBindings).map(([role, info]) => [role, info.selection]));
    const review = buildRealCmsReview({
      previewPath: dryRun.previewPath,
      tasks: limitedDryRun.plan,
      pageSelections,
      pageBindings,
      mediaManifest,
      batchMode,
      fullBatch,
      useAllPreviewTasks
    });
    const confirmed = await confirmRealCmsRun(review, { ...options, batchMode, fullBatch });
    if (!confirmed) throw new Error("正式运行已取消：没有收到确认，不会点击执行发送/确认创建。");
    await reportProgress(options, options.assumeYes === true
      ? "正式创建准备：控制台已确认开始，已跳过隐藏 CLI 二次确认，开始逐条创建。"
      : "正式创建准备：已收到最终确认，开始逐条创建。");

    const adaptersByRole = Object.fromEntries(Object.entries(pageBindings).map(([role, info]) => [
      role,
      createRealCmsSubmitBeforeAdapter(info.page, {
        config,
        mediaManifest,
        allowRealSubmit: true,
        media: { timeoutMs: options.mediaReadyTimeoutMs || config.mediaReadyTimeoutMs || 90000 },
        roleTargets: options.roleTargets || {},
        control: options.control,
        submitSuccessTimeoutMs: options.submitSuccessTimeoutMs || config.submitSuccessTimeoutMs || 12000,
        robotNotInGroupPolicy: options.robotNotInGroupPolicy || config.robotNotInGroupPolicy || "ignore",
        robotNotInGroupMaxRetries: options.robotNotInGroupMaxRetries || config.robotNotInGroupMaxRetries || 3,
        resetBeforeEachTask: true,
        skipPageReset: options.skipPageReset === true,
        timeoutMs: options.timeoutMs || 30000,
        pageResetWaitMs: options.pageResetWaitMs || 1200
      })
    ]));
    const result = await runCreateRunner(runDir, {
      ...options,
      dryRunResult: limitedDryRun,
      adapterForTask: (task) => {
        const adapter = adaptersByRole[task.role];
        if (!adapter) throw new Error(`第 ${task.index} 条找不到 ${roleLabel(task.role)} 页面，已停止。`);
        return adapter;
      },
      validateTaskBinding: async (task) => {
        const binding = pageBindings[task.role];
        return await validateTaskCmsPageBinding(task, binding, { runId: dryRun.runId });
      },
      allowRealSubmit: true
    });
    return buildRealCmsRunReport(result, review, { batchMode, fullBatch, useAllPreviewTasks });
  } finally {
    if (opened?.shouldClose !== false) await opened?.context?.close?.().catch(() => {});
  }
}

export function buildOneTaskReview({ previewPath, task, pageSelection, mediaManifest }) {
  return buildRealCmsReview({ previewPath, tasks: [task], pageSelection, mediaManifest, batchMode: false });
}

export function buildRealCmsReview({ previewPath, tasks, pageSelection, pageSelections, pageBindings, mediaManifest, batchMode = false, fullBatch = false, useAllPreviewTasks = false }) {
  const selectedTasks = tasks || [];
  const title = useAllPreviewTasks
    ? `2.0 正式运行：按 preview.json 执行 ${selectedTasks.length} 条`
    : fullBatch
    ? `2.0 正式运行：全量 ${selectedTasks.length} 条`
    : batchMode
    ? `2.0 正式运行：小批量 ${selectedTasks.length} 条`
    : "2.0 正式运行：只创建第 1 条";
  const lines = [
    title,
    "",
    `preview.json：${previewPath}`,
    ""
  ];
  const bindingLines = buildPageBindingReviewLines(pageBindings, pageSelections);
  if (bindingLines.length) {
    lines.push("CMS 页面绑定：");
    lines.push(...bindingLines);
    lines.push("");
  }
  selectedTasks.forEach((task, index) => {
    const content = taskContentForReview(task, mediaManifest);
    const binding = pageBindingForTask(task, { pageBindings });
    const selection = pageSelectionForTask(task, { pageSelection, pageSelections, pageBindings });
    lines.push(`第 ${index + 1} 条：`);
    lines.push(`role：${task.role || ""}（${roleLabel(task.role)}）`);
    lines.push(`将使用页面：${roleLabel(task.role)}页面${binding?.index ? `（页面 ${binding.index}）` : ""}`);
    lines.push(`页面当前群：${selection.group}`);
    lines.push(`页面当前机器人：${selection.robot}`);
    lines.push(`页面任务备注：${selection.taskRemark || "空"}`);
    lines.push(`发送时间：${task.date || ""} ${task.time || ""}`.trim());
    lines.push(`类型：${task.type}`);
    lines.push(`内容/素材路径：${compact(content, 180)}`);
    lines.push("");
  });
  lines.push(useAllPreviewTasks
    ? `确认后会按保存后的 preview.json 创建 ${selectedTasks.length} 条；不发项已跳过，每条成功后才进入下一条，任意失败立即停止。`
    : batchMode
    ? `确认后会依次创建以上 ${selectedTasks.length} 条；每条成功后才进入下一条，任意失败立即停止。`
    : "确认后只会点击这一条的“执行发送”和“确认创建”，成功后自动停住，不会继续第 2 条。");
  return lines.join("\n");
}

function pageSelectionForTask(task, options = {}) {
  const binding = pageBindingForTask(task, options);
  if (binding?.selection) return binding.selection;
  return options.pageSelections?.[task.role] || options.pageSelection || {
    group: "未识别，请以当前云中客页面已选群为准",
    robot: "未识别，请以当前云中客页面已选机器人为准",
    taskRemark: ""
  };
}

function pageBindingForTask(task, options = {}) {
  return options.pageBindings?.[task.role] || null;
}

function buildPageBindingReviewLines(pageBindings, pageSelections) {
  if (pageBindings) {
    return Object.entries(pageBindings)
      .sort((a, b) => (a[1]?.index || 0) - (b[1]?.index || 0))
      .map(([role, info]) => {
        const selection = info.selection || {};
        return `页面 ${info.index} => ${roleLabel(role)}页面 / 群=${selection.group || ""} / 机器人=${selection.robot || ""} / 任务备注=${selection.taskRemark || "空"}`;
      });
  }
  if (!pageSelections) return [];
  return Object.entries(pageSelections)
    .map(([role, selection]) => `${roleLabel(role)}页面 / 群=${selection.group || ""} / 机器人=${selection.robot || ""} / 任务备注=${selection.taskRemark || "空"}`);
}

function taskContentForReview(task, mediaManifest) {
  const localMedia = (mediaManifest?.items || []).find((item) => String(item.sourceId || "") === String(task.sourceId || ""));
  return task.type === "text"
    ? task.text
    : localMedia?.localPath || task.mediaPath || "";
}

export function buildRealCmsRunReport(result, review, options = {}) {
  const batchMode = options.batchMode === true;
  const fullBatch = options.fullBatch === true;
  const useAllPreviewTasks = options.useAllPreviewTasks === true;
  const completedLines = result.completed.map((item, index) => (
    `第 ${index + 1} 条：preview第 ${item.index} 条 / ${item.type} / 发送时间=${`${item.date || ""} ${item.time || ""}`.trim()} / ${item.submitted ? "提交成功" : "未提交"}`
  ));
  return [
    review,
    "",
    result.log,
    "",
    useAllPreviewTasks
      ? `正式运行完成：已按保存后的 preview.json 提交 ${result.completed.length} 条。`
      : fullBatch
      ? `正式运行完成：已提交 ${result.completed.length} 条，全量结束。`
      : batchMode
      ? `正式运行完成：已提交 ${result.completed.length} 条，小批量结束，没有继续全量。`
      : "正式运行完成：已提交 1 条，并按规则停住，没有继续第 2 条。",
    "",
    "提交结果：",
    ...completedLines,
    "",
    "核对提醒：请核对发送时间，不看创建时间。",
    "",
    `create-runner.log：${path.join(result.runDir, "create-runner.log")}`,
    `create-runner-actions.json：${path.join(result.runDir, "create-runner-actions.json")}`
  ].join("\n");
}

function limitDryRunToFirstTask(dryRun) {
  return {
    ...dryRun,
    createCount: Math.min(1, dryRun.plan.length),
    plan: dryRun.plan.slice(0, 1)
  };
}

export function limitDryRunToMixedBatch(dryRun, limit = 3) {
  const plan = dryRun.plan || [];
  const ordered = plan.slice(0, limit);
  return {
    ...dryRun,
    createCount: ordered.length,
    plan: ordered
  };
}

export function limitDryRunToAll(dryRun) {
  const plan = dryRun.plan || [];
  return {
    ...dryRun,
    createCount: plan.length,
    plan
  };
}

export async function readCmsPageInfos(pages, options = {}) {
  const infos = [];
  for (const [index, page] of (pages || []).entries()) {
    await reportProgress(options, `正式创建准备：正在读取第 ${index + 1} 个云中客页面的群和机器人。`);
    const selection = await withTimeout(
      readCurrentCmsSelection(page),
      options.pageInfoTimeoutMs || 10000,
      `读取第 ${index + 1} 个云中客页面当前群和机器人超时，请确认页面没有弹窗遮挡且仍是创建任务页。`
    );
    infos.push({
      index: index + 1,
      page,
      url: page.url?.() || "",
      cmsRole: page.__v2CmsRole || "",
      selection
    });
  }
  return infos;
}

async function reportProgress(options, message) {
  if (!message) return;
  if (typeof options.onProgress === "function") {
    await options.onProgress(message);
    return;
  }
  if (options.control?.checkpoint) {
    await options.control.checkpoint(message);
  }
}

async function withTimeout(promise, timeoutMs, message) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(message)), timeoutMs);
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function resolveCmsPageBindings(pageInfos, requiredRoles, config = {}, options = {}) {
  const defaultBindings = buildDefaultCmsRoleBindings(pageInfos, requiredRoles);
  if (options.assumeYes === true || options.nonInteractive === true) {
    if (hasRequiredBindings(defaultBindings, requiredRoles)) return defaultBindings;
  }
  const manualBindings = await askManualCmsPageBindings(pageInfos, requiredRoles, {
    ...options,
    defaultBindings
  });
  const bindings = Object.keys(manualBindings).length ? manualBindings : defaultBindings;
  if (hasRequiredBindings(bindings, requiredRoles)) return bindings;
  const missing = requiredRoles.filter((role) => !bindings[role]).map(roleLabel).join("、");
  throw new Error(`正式运行已停止：找不到对应 CMS 页面：${missing}。不能 fallback 到另一个页面。`);
}

export function buildDefaultCmsRoleBindings(pageInfos, requiredRoles = ["tuo", "douma"]) {
  const pages = pageInfos || [];
  const bindings = {};
  for (const info of pages) {
    const role = info?.cmsRole === "douma" ? "douma" : info?.cmsRole === "tuo" ? "tuo" : "";
    if (!role || !requiredRoles.includes(role) || bindings[role]) continue;
    bindings[role] = {
      ...info,
      role,
      bindingSource: "marked-create-page-role"
    };
  }
  const defaults = [
    ["tuo", pages[0]],
    ["douma", pages[1]]
  ];
  for (const [role, info] of defaults) {
    if (!info || !requiredRoles.includes(role) || bindings[role]) continue;
    bindings[role] = {
      ...info,
      role,
      bindingSource: "fixed-create-page-order"
    };
  }
  return bindings;
}

export function cmsPageBindingsPath(runDir) {
  return path.join(runDir, CMS_PAGE_BINDINGS_FILE);
}

export function runIdFromRunDir(runDir) {
  return path.basename(path.resolve(runDir || ""));
}

export async function clearCmsPageBindings(runDir) {
  if (!runDir) return;
  await fs.unlink(cmsPageBindingsPath(runDir)).catch((error) => {
    if (error?.code !== "ENOENT") throw error;
  });
}

export async function createCmsPageBindingsForRun(runDir, pageInfos, requiredRoles = ["tuo", "douma"], options = {}) {
  const bindings = buildDefaultCmsRoleBindings(pageInfos, requiredRoles);
  if (!hasRequiredBindings(bindings, requiredRoles)) {
    const missing = requiredRoles.filter((role) => !bindings[role]).map(roleLabel).join("、");
    throw new Error(`CMS 准备已停止：找不到对应云中客创建页：${missing}。第 1 页必须是托，第 2 页必须是豆妈。`);
  }
  await markCmsBindingsForRun(runDir, bindings);
  return await saveCmsPageBindings(runDir, bindings, {
    source: options.source || "prepare-cms",
    runId: options.runId || runIdFromRunDir(runDir)
  });
}

export async function saveCmsPageBindings(runDir, pageBindings, options = {}) {
  const runId = options.runId || runIdFromRunDir(runDir);
  const roles = {};
  for (const [role, info] of Object.entries(pageBindings || {})) {
    const page = info.page;
    roles[role] = {
      role,
      pageIndex: Number(info.index || 0),
      pageId: bindingPageId(page, runId, info.index),
      url: page?.url?.() || info.url || "",
      title: await safePageTitle(page) || info.title || "",
      marker: page?.__v2CmsRole || info.cmsRole || role,
      runId: page?.__v2CmsRunId || runId,
      selection: info.selection || {},
      bindingSource: info.bindingSource || ""
    };
  }
  const payload = {
    runId,
    runDir,
    source: options.source || "",
    createdAt: new Date().toISOString(),
    roles
  };
  await fs.writeFile(cmsPageBindingsPath(runDir), JSON.stringify(payload, null, 2), "utf8");
  return payload;
}

export async function loadCmsPageBindings(runDir) {
  const state = await readJsonIfExists(cmsPageBindingsPath(runDir));
  return state?.runId ? state : null;
}

export async function assertCurrentRunBindings(runDir, dryRun) {
  const state = await loadCmsPageBindings(runDir);
  if (!state?.runId) {
    throw new Error("正式运行已停止：当前 preview 没有 CMS 页面绑定。请先点击“确认无误进入云中客设置”，重新建立本轮托页/豆妈页绑定。");
  }
  assertBindingStateMatchesRun(runDir, dryRun, state);
  return state;
}

export function assertBindingStateMatchesRun(runDir, dryRun, bindingState) {
  const currentRunId = dryRun?.runId || runIdFromRunDir(runDir);
  const bindingRunId = bindingState?.runId || "";
  if (bindingRunId !== currentRunId) {
    throw new Error(`正式运行已停止：CMS 页面绑定属于旧预览 runId=${bindingRunId || "空"}，当前预览 runId=${currentRunId}。请重新点击“确认无误进入云中客设置”。`);
  }
  return true;
}

export async function markCmsBindingsForRun(runDir, pageBindings) {
  const runId = runIdFromRunDir(runDir);
  for (const [role, info] of Object.entries(pageBindings || {})) {
    const page = info.page;
    if (!page || page.isClosed?.()) {
      throw new Error(`${roleLabel(role)}页面已经关闭，请重新进入云中客设置。`);
    }
    const pageId = bindingPageId(page, runId, info.index);
    page.__v2CmsRunId = runId;
    page.__v2CmsRole = role;
    page.__v2CmsPageBindingId = pageId;
    await page.evaluate?.(({ role, runId, pageId }) => {
      window.__v2CmsRole = role;
      window.__v2CmsRunId = runId;
      window.__v2CmsPageBindingId = pageId;
      try {
        sessionStorage.setItem("__v2CmsRole", role);
        sessionStorage.setItem("__v2CmsRunId", runId);
        sessionStorage.setItem("__v2CmsPageBindingId", pageId);
      } catch {}
    }, { role, runId, pageId }).catch(() => {});
  }
}

export async function validateTaskCmsPageBinding(task, binding, options = {}) {
  const role = task.role === "douma" ? "douma" : "tuo";
  const label = roleLabel(role);
  const runId = String(options.runId || "").trim();
  if (!binding) throw new Error(`第 ${task.index} 条 ${label} 找不到当前 run 的页面绑定，已停止。`);
  const page = binding.page;
  if (!page || page.isClosed?.()) throw new Error(`第 ${task.index} 条 ${label} 绑定页已关闭/丢失，已停止。请重新进入云中客设置。`);
  if (!await pageLooksLikeCreateForm(page)) {
    throw new Error(`第 ${task.index} 条 ${label} 页面已经不是云中客创建任务页，已停止。请重新点击“确认无误进入云中客设置”。`);
  }
  if (binding.role && binding.role !== role) {
    throw new Error(`第 ${task.index} 条 ${label} 页面绑定角色错位：绑定为 ${roleLabel(binding.role)}，不能继续写入。`);
  }
  const pageState = await readRuntimePageBindingState(page);
  const pageRole = pageState.role || page.__v2CmsRole || binding.cmsRole || "";
  const pageRunId = pageState.runId || page.__v2CmsRunId || "";
  if (pageRole !== role) {
    throw new Error(`第 ${task.index} 条 ${label} 页面角色校验失败：当前页面标记=${roleLabel(pageRole) || "空"}，目标=${label}。已停止，避免写错页面。`);
  }
  if (runId && pageRunId && pageRunId !== runId) {
    throw new Error(`第 ${task.index} 条 ${label} 页面 runId 校验失败：页面=${pageRunId}，当前=${runId}。请重新进入云中客设置。`);
  }
  return {
    role,
    roleLabel: label,
    pageIndex: binding.index,
    pageId: page.__v2CmsPageBindingId || pageState.pageId || "",
    runId: pageRunId || runId
  };
}

function bindingPageId(page, runId, index) {
  if (!page) return `${runId}:page-${index || 0}`;
  if (!page.__v2CmsPageBindingId) {
    page.__v2CmsPageBindingId = `${runId}:page-${index || 0}`;
  }
  return page.__v2CmsPageBindingId;
}

async function safePageTitle(page) {
  if (!page || typeof page.title !== "function") return "";
  return await page.title().catch(() => "");
}

async function readRuntimePageBindingState(page) {
  if (!page || typeof page.evaluate !== "function") {
    return {
      role: page?.__v2CmsRole || "",
      runId: page?.__v2CmsRunId || "",
      pageId: page?.__v2CmsPageBindingId || ""
    };
  }
  const state = await page.evaluate(() => {
    const get = (key) => {
      try {
        return sessionStorage.getItem(key) || "";
      } catch {
        return "";
      }
    };
    return {
      role: window.__v2CmsRole || get("__v2CmsRole"),
      runId: window.__v2CmsRunId || get("__v2CmsRunId"),
      pageId: window.__v2CmsPageBindingId || get("__v2CmsPageBindingId")
    };
  }).catch(() => ({}));
  return {
    role: state.role || page.__v2CmsRole || "",
    runId: state.runId || page.__v2CmsRunId || "",
    pageId: state.pageId || page.__v2CmsPageBindingId || ""
  };
}

async function askManualCmsPageBindings(pageInfos, requiredRoles, options = {}) {
  if (options.pageBindings) return bindingsFromManualMap(pageInfos, requiredRoles, options.pageBindings);
  if (options.assumeYes === true || options.nonInteractive === true) return {};
  const defaultText = describeBindings(options.defaultBindings || {});
  if (!input.isTTY) return {};
  console.log("\nCMS 页面默认绑定：第 1 个云中客创建页 = 托页面；第 2 个云中客创建页 = 豆妈页面。");
  for (const info of pageInfos) {
    console.log(`页面 ${info.index}：群=${info.selection.group} / 机器人=${info.selection.robot} / 任务备注=${info.selection.taskRemark || "空"} / ${info.url}`);
  }
  if (defaultText) console.log(`当前默认绑定：${defaultText}`);
  console.log("直接回车按默认绑定继续；如果页面反过来，输入：1=douma,2=tuo。");
  const rl = readline.createInterface({ input, output });
  try {
    const answer = await rl.question("页面绑定：");
    if (!String(answer || "").trim()) return {};
    return parseManualCmsPageBindings(answer, pageInfos, requiredRoles);
  } finally {
    rl.close();
  }
}

export function parseManualCmsPageBindings(answer, pageInfos, requiredRoles = ["tuo", "douma"]) {
  const bindings = {};
  const byIndex = new Map((pageInfos || []).map((info) => [String(info.index), info]));
  const used = new Set();
  for (const part of String(answer || "").split(/[，,;\s]+/).filter(Boolean)) {
    const match = part.match(/^(\d+)\s*[:=：]\s*(tuo|douma|托|豆妈)$/i);
    if (!match) continue;
    const info = byIndex.get(match[1]);
    if (!info || used.has(info.index)) continue;
    const role = normalizeManualRole(match[2]);
    if (!requiredRoles.includes(role) || bindings[role]) continue;
    bindings[role] = info;
    used.add(info.index);
  }
  return bindings;
}

function bindingsFromManualMap(pageInfos, requiredRoles, pageBindings) {
  const answer = Object.entries(pageBindings)
    .map(([role, index]) => `${index}=${role}`)
    .join(",");
  return parseManualCmsPageBindings(answer, pageInfos, requiredRoles);
}

function describeBindings(bindings) {
  return Object.entries(bindings)
    .map(([role, info]) => `${info.index}=${role}`)
    .join("，");
}

function normalizeManualRole(value) {
  const text = String(value || "").trim().toLowerCase();
  if (text === "豆妈" || text === "douma") return "douma";
  if (text === "托" || text === "tuo") return "tuo";
  return "";
}

export function requiredRolesForTasks(tasks) {
  const roles = new Set((tasks || []).map((task) => task.role).filter((role) => role === "tuo" || role === "douma"));
  return ["tuo", "douma"].filter((role) => roles.has(role));
}

function hasRequiredBindings(bindings, requiredRoles) {
  return requiredRoles.every((role) => bindings[role]);
}

async function confirmRealCmsRun(review, options = {}) {
  if (options.confirmText !== undefined) {
    return isConfirmText(options.confirmText);
  }
  if (options.assumeYes === true) return true;
  console.log(review);
  if (!input.isTTY) return false;
  const rl = readline.createInterface({ input, output });
  try {
    const prompt = options.fullBatch
      ? "\n输入 YES 确认创建以上全量任务；直接回车取消："
      : options.batchMode
      ? "\n输入 YES 确认创建以上小批量；直接回车取消："
      : "\n输入 YES 确认只创建这一条；直接回车取消：";
    const answer = await rl.question(prompt);
    return isConfirmText(answer);
  } finally {
    rl.close();
  }
}

function isConfirmText(value) {
  const text = String(value || "").trim();
  return text === "YES" || text === "确认";
}

function compact(value, max = 80) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max - 1)}...` : text;
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "";
}

function parseArgs(argv) {
  const runDirIndex = argv.indexOf("--run-dir");
  const cmsUrlIndex = argv.indexOf("--cms-url");
  const cdpUrlIndex = argv.indexOf("--cdp-url");
  const batchSizeIndex = argv.indexOf("--batch-size");
  return {
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : "",
    cmsUrl: cmsUrlIndex >= 0 ? argv[cmsUrlIndex + 1] : "",
    cdpUrl: cdpUrlIndex >= 0 ? argv[cdpUrlIndex + 1] : "",
    headless: argv.includes("--headless"),
    fullBatch: argv.includes("--full-batch"),
    batchMixed3: argv.includes("--batch-mixed-3"),
    batchSize: batchSizeIndex >= 0 ? Number(argv[batchSizeIndex + 1]) : 0
  };
}

function normalizedBatchSize(options = {}) {
  if (options.fullBatch === true) return 0;
  if (options.batchMixed3 === true) return 3;
  const value = Number(options.batchSize || 0);
  if (!Number.isFinite(value) || value <= 1) return 1;
  return Math.floor(value);
}

async function loadCmsConfig(projectRoot) {
  try {
    return JSON.parse(await fs.readFile(path.join(projectRoot, "config.json"), "utf8"));
  } catch {
    return {};
  }
}

async function loadControlledBrowserState(projectRoot, config = {}) {
  const statePath = path.join(projectRoot, "runs", "v2-controlled-cms-browser.json");
  const state = await readJsonIfExists(statePath);
  const port = Number(state.port || config.cmsDebugPort || 9333);
  const cdpUrl = state.cdpUrl || `http://127.0.0.1:${port}`;
  if (await canReachCdp(cdpUrl)) return { cdpUrl, port };
  return {};
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function canReachCdp(cdpUrl) {
  try {
    const response = await fetch(`${cdpUrl.replace(/\/$/, "")}/json/version`, { signal: AbortSignal.timeout(1500) });
    return response.ok;
  } catch {
    return false;
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runRealCmsCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

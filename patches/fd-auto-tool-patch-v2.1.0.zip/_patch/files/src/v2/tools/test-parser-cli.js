import { fileURLToPath } from "node:url";
import { fixedFormatSampleRawEvents } from "../fixtures/fixed-format-sample.js";
import { parseFixedFormatTasks } from "../parser/parse-fixed-format.js";

export function buildParserCliReport(rawEvents = fixedFormatSampleRawEvents(), options = {}) {
  const { tasks, diagnostics } = parseFixedFormatTasks(rawEvents, {
    scheduleMode: "realtime",
    knownSpeakers: ["今天愉快"],
    ...options
  });
  return [
    "2.0 固定格式解析 PreviewTask 输出",
    "",
    formatTasksTable(tasks),
    "",
    formatDiagnostics(diagnostics)
  ].join("\n");
}

export function formatTasksTable(tasks) {
  const rows = [
    ["序号", "角色", "说话人", "时间", "类型", "内容", "素材", "不发", "interactionGroup", "continueMarker", "cleanSpeaker"],
    ...tasks.map((task, index) => [
      String(index + 1),
      roleLabel(task.role),
      task.speaker || "",
      task.time || "(无时间)",
      task.type || "",
      compact(task.text || ""),
      task.mediaPath || "",
      task.skip ? "是" : "否",
      task.interactionGroup || "",
      task.continueMarker ? "是" : "否",
      task.cleanSpeaker || ""
    ])
  ];
  const widths = columnWidths(rows);
  return rows.map((row, rowIndex) => {
    const line = row.map((cell, index) => padCell(cell, widths[index])).join(" | ");
    if (rowIndex === 0) {
      return [
        line,
        widths.map((width) => "-".repeat(width)).join("-|-")
      ].join("\n");
    }
    return line;
  }).join("\n");
}

export function formatDiagnostics(diagnostics) {
  if (!diagnostics.length) return "诊断：无";
  return [
    "诊断：",
    ...diagnostics.map((item) => `- ${item.message || item.code || "未知提示"}`)
  ].join("\n");
}

function roleLabel(role) {
  if (role === "douma") return "豆妈";
  if (role === "tuo") return "托";
  return role || "";
}

function compact(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > 28 ? `${text.slice(0, 27)}...` : text;
}

function columnWidths(rows) {
  return rows[0].map((_, index) => Math.max(...rows.map((row) => displayWidth(row[index]))));
}

function padCell(value, width) {
  const text = String(value ?? "");
  return text + " ".repeat(Math.max(0, width - displayWidth(text)));
}

function displayWidth(value) {
  return Array.from(String(value ?? "")).reduce((sum, char) => {
    return sum + (char.charCodeAt(0) > 0x7f ? 2 : 1);
  }, 0);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  console.log(buildParserCliReport());
}

Option Explicit

Dim shell, fso, projectRoot, psScript, command

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

If WScript.Arguments.Count > 0 Then
  projectRoot = WScript.Arguments(0)
Else
  projectRoot = fso.GetParentFolderName(fso.GetParentFolderName(fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName))))
End If

projectRoot = fso.GetAbsolutePathName(projectRoot)
psScript = fso.BuildPath(projectRoot, "src\v2\tools\launch-console-hidden.ps1")

command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Quote(psScript) & " -ProjectRoot " & Quote(projectRoot)
shell.Run command, 0, False

Function Quote(value)
  Quote = Chr(34) & value & Chr(34)
End Function

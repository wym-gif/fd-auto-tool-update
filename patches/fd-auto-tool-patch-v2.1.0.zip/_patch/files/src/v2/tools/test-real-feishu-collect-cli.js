import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { collectRawEventsFromPage, saveRawEvents, summarizeRawEvents, validateCollectedRawEvents } from "../feishu/collector.js";
import { isFeishuCollectError } from "../feishu/collect-errors.js";
import { normalizeFeishuUrl, openRealFeishuCollectPage } from "../feishu/page-controller.js";

export async function runRealFeishuCollectCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runRoot = options.runRoot || path.join(projectRoot, "runs");
  const settings = await loadCollectSettings(projectRoot);
  const url = normalizeFeishuUrl(options.url || settings.url);
  const checks = buildChecks(options);
  const runName = options.runName || `v2_real_collect_${timestamp()}`;
  const runDir = path.join(runRoot, runName);
  let opened;
  try {
    await fs.mkdir(runDir, { recursive: true });
    opened = await openRealFeishuCollectPage({
      url,
      profileDir: path.resolve(projectRoot, settings.profileDir || "./browser-profile"),
      headless: options.headless === true,
      timeoutMs: options.timeoutMs || 30000
    });
    if (options.waitMs !== 0) {
      await opened.page.waitForTimeout(options.waitMs || 2500);
    }
    const events = await collectRawEventsFromPage(opened.page, {
      scanFullPage: options.scanFullPage !== false,
      stepPixels: options.stepPixels,
      waitMs: options.scanWaitMs,
      maxSteps: options.maxSteps,
      mediaCacheDir: path.join(runDir, "media-cache")
    });
    const validated = validateCollectedRawEvents(events, {
      ...checks,
      requireLocalMedia: true
    });
    const saved = await saveRawEvents(runRoot, validated, { runName });
    return buildRealCollectReport(validated, saved, { title: opened.title, url: opened.page.url(), checks });
  } catch (error) {
    if (isFeishuCollectError(error)) {
      return `${error.message}\n采集已停止，没有进入范围/解析测试。`;
    }
    throw error;
  } finally {
    await opened?.context?.close?.().catch(() => {});
  }
}

export function buildRealCollectReport(events, saved, meta = {}) {
  const summary = summarizeRawEvents(events);
  return [
    "2.0 真实飞书采集 rawEvents 输出",
    "",
    `文档标题：${meta.title || "未读取到标题"}`,
    `文档地址：${meta.url || ""}`,
    `保存文件：${saved.filePath}`,
    "",
    "采集统计：",
    `- 总数：${summary.total}`,
    `- 文本：${summary.line}`,
    `- 标题：${summary.title}`,
    `- 图片：${summary.image}`,
    `- 表情包：${summary.sticker}`,
    `- 视频：${summary.video}`,
    `- 分割线：${summary.divider}`,
    "",
    "完整性检查：",
    ...describeChecks(meta.checks),
    "",
    "首条记录：",
    JSON.stringify(compactEvent(summary.firstEvent), null, 2),
    "",
    "末条记录：",
    JSON.stringify(compactEvent(summary.lastEvent), null, 2),
    "",
    "采集完整性：通过",
    "说明：本入口只保存 raw-events.json，不生成预览，不创建 CMS 任务。"
  ].join("\n");
}

export function parseArgs(argv = []) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    const next = argv[index + 1];
    if (arg === "--url") {
      options.url = next;
      index += 1;
    } else if (arg === "--start") {
      options.startKeyword = next;
      index += 1;
    } else if (arg === "--end") {
      options.endKeyword = next;
      index += 1;
    } else if (arg === "--require-first-image") {
      options.requireFirstImage = true;
    } else if (arg === "--require-sticker") {
      options.requireSticker = true;
    } else if (arg === "--require-video") {
      options.requireVideo = true;
    } else if (arg === "--headless") {
      options.headless = true;
    } else if (arg === "--no-wait") {
      options.waitMs = 0;
    } else if (arg === "--visible-only") {
      options.scanFullPage = false;
    } else if (arg === "--max-steps") {
      options.maxSteps = Number(next);
      index += 1;
    }
  }
  return options;
}

async function loadCollectSettings(projectRoot) {
  const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
  const lastSettings = await readJsonIfExists(path.join(projectRoot, "last-settings.json"));
  return {
    url: normalizeFeishuUrl(lastSettings.feishuUrl) || normalizeFeishuUrl(config.feishuUrl),
    profileDir: config.profileDir || "./browser-profile"
  };
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

function buildChecks(options) {
  const checks = {};
  if (options.startKeyword) checks.startKeyword = options.startKeyword;
  if (options.endKeyword) checks.endKeyword = options.endKeyword;
  if (options.requireFirstImage) checks.requireFirstImage = true;
  if (options.requireSticker) checks.requireSticker = true;
  if (options.requireVideo) checks.requireVideo = true;
  return checks;
}

function describeChecks(checks = {}) {
  const lines = [];
  if (checks.startKeyword) lines.push(`- 开始关键词：${checks.startKeyword}`);
  if (checks.endKeyword) lines.push(`- 结束关键词：${checks.endKeyword}`);
  if (checks.requireFirstImage) lines.push("- 第一张图片：要求采到");
  if (checks.requireSticker) lines.push("- 表情包：要求采到");
  if (checks.requireVideo) lines.push("- 视频：要求采到");
  return lines.length ? lines : ["- 未指定关键词/素材强校验，本次只检查页面可采集。"];
}

function compactEvent(event) {
  if (!event) return null;
  return {
    sourceId: event.sourceId,
    order: event.order,
    type: event.type,
    text: event.text,
    mediaPath: event.mediaPath,
    blockIndex: event.blockIndex,
    boundingInfo: event.boundingInfo
  };
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runRealFeishuCollectCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

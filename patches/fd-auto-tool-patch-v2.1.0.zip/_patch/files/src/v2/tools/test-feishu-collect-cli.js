import path from "node:path";
import { fileURLToPath } from "node:url";
import { expectedFeishuCollectChecks } from "../fixtures/feishu-collect-sample.js";
import { collectRawEventsFromPage, saveRawEvents, summarizeRawEvents, validateCollectedRawEvents } from "../feishu/collector.js";
import { isFeishuCollectError } from "../feishu/collect-errors.js";
import { openV2CollectTestPage } from "../feishu/page-controller.js";

export async function runFeishuCollectCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runRoot = options.runRoot || path.join(projectRoot, "runs");
  let browser;
  try {
    const opened = await openV2CollectTestPage({ headless: true, url: options.url });
    browser = opened.browser;
    const events = await collectRawEventsFromPage(opened.page);
    const validated = validateCollectedRawEvents(events, options.checks || expectedFeishuCollectChecks());
    const saved = await saveRawEvents(runRoot, validated);
    return buildCollectReport(validated, saved);
  } catch (error) {
    if (isFeishuCollectError(error)) {
      return `${error.message}\n采集已停止，没有进入范围/解析测试。`;
    }
    throw error;
  } finally {
    await browser?.close().catch(() => {});
  }
}

export function buildCollectReport(events, saved) {
  const summary = summarizeRawEvents(events);
  return [
    "2.0 飞书采集 rawEvents 输出",
    "",
    `保存文件：${saved.filePath}`,
    "",
    "采集统计：",
    `- 总数：${summary.total}`,
    `- 文本：${summary.line}`,
    `- 标题：${summary.title}`,
    `- 图片：${summary.image}`,
    `- 表情包：${summary.sticker}`,
    `- 视频：${summary.video}`,
    `- 分割线：${summary.divider}`,
    "",
    "首条记录：",
    JSON.stringify(compactEvent(summary.firstEvent), null, 2),
    "",
    "末条记录：",
    JSON.stringify(compactEvent(summary.lastEvent), null, 2),
    "",
    "采集完整性：通过"
  ].join("\n");
}

function compactEvent(event) {
  if (!event) return null;
  return {
    sourceId: event.sourceId,
    order: event.order,
    type: event.type,
    text: event.text,
    mediaPath: event.mediaPath,
    blockIndex: event.blockIndex,
    boundingInfo: event.boundingInfo
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runFeishuCollectCli().then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

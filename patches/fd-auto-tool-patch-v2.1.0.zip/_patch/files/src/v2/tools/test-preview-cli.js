import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { runCollectRangeParseCli } from "./test-collect-range-parse-cli.js";
import { createPreviewTestServer } from "../preview/preview-page.js";
import { findLatestV2FlowRun, finalPreviewPath, loadFinalPreviewForCreate, loadPreviewForOpen } from "../preview/preview-store.js";

export async function runPreviewCli(options = {}) {
  if (options.selfTest) return runPreviewSelfTest(options);

  const projectRoot = options.projectRoot || process.cwd();
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const runDir = options.runDir || await findLatestV2FlowRun(runsRoot);
  if (!runDir) {
    return [
      "没有找到 runs\\v2_flow_xxx\\preview-tasks.json。",
      "请先运行 测试2.0采集范围解析.bat，再运行这个预览测试入口。"
    ].join("\n");
  }

  const state = await loadPreviewForOpen(runDir);
  const preview = await createPreviewTestServer(runDir);
  await openDefaultBrowser(preview.url);
  return [
    "2.0 预览页测试版已启动",
    "",
    `预览地址：${preview.url}`,
    `运行目录：${runDir}`,
    `当前读取：${state.source}`,
    `最终文件：${finalPreviewPath(runDir)}`,
    "",
    "规则：preview.json 一旦存在，二次打开、确认和创建前核对都优先读取 preview.json。",
    "只有点击页面里的“重新生成预览”，才会用 preview-tasks.json 覆盖 preview.json。",
    "",
    "保持这个窗口打开。测试结束后按 Ctrl+C 关闭预览服务。"
  ].join("\n");
}

export async function runPreviewSelfTest(options = {}) {
  const tempRoot = options.runRoot || await fs.mkdtemp(path.join(os.tmpdir(), "v2-preview-cli-"));
  await runCollectRangeParseCli({
    projectRoot: options.projectRoot || process.cwd(),
    runRoot: tempRoot,
    runName: "v2_flow_preview_self_test"
  });
  const runDir = path.join(tempRoot, "v2_flow_preview_self_test");
  const preview = await createPreviewTestServer(runDir);
  const browser = await chromium.launch({ headless: true });
  try {
    const page = await browser.newPage();
    await page.goto(preview.url, { waitUntil: "domcontentloaded" });
    await page.locator("tbody tr").nth(1).locator("[data-field='speaker']").fill("用户改过的说话人");
    await page.locator("tbody tr").nth(1).locator("[data-field='time']").fill("10:11:12");
    await page.locator("tbody tr").nth(1).locator("[data-field='text']").fill("用户改过的正文");
    await page.locator("tbody tr").nth(1).locator("[data-field='skip']").check();
    await page.getByText("确认无误，进入云中客设置").click();
    await page.waitForFunction(() => document.getElementById("status")?.textContent.includes("已保存并核对通过"));

    const saved = await loadFinalPreviewForCreate(runDir);
    const changed = saved.tasks[1];
    if (changed.speaker !== "用户改过的说话人" || changed.time !== "10:11:12" || changed.text !== "用户改过的正文" || changed.skip !== true) {
      throw new Error("预览自测失败：preview.json 没有保存用户修改。");
    }

    const reopened = await loadPreviewForOpen(runDir);
    if (reopened.source !== "preview.json" || reopened.tasks[1].text !== "用户改过的正文") {
      throw new Error("预览自测失败：二次打开没有优先读取 preview.json。");
    }

    await page.reload({ waitUntil: "domcontentloaded" });
    await page.getByText("确认无误，进入云中客设置").click();
    await page.waitForFunction(() => document.getElementById("status")?.textContent.includes("已保存并核对通过"));

    await page.on("dialog", (dialog) => dialog.accept());
    await page.getByRole("button", { name: "重新生成预览" }).click();
    await page.waitForFunction(() => document.getElementById("status")?.textContent.includes("已重新生成"));
    const regenerated = await loadFinalPreviewForCreate(runDir);
    if (regenerated.tasks[1].text === "用户改过的正文") {
      throw new Error("预览自测失败：点击重新生成后没有覆盖 preview.json。");
    }

    return [
      "2.0 预览页自测通过",
      `运行目录：${runDir}`,
      `最终文件：${finalPreviewPath(runDir)}`,
      "已验证：保存用户修改、二次打开优先读取 preview.json、确认只核对 preview.json、重新生成才覆盖。"
    ].join("\n");
  } finally {
    await browser.close().catch(() => {});
    await preview.close();
  }
}

function openDefaultBrowser(url) {
  if (process.platform !== "win32") return Promise.resolve();
  return new Promise((resolve) => {
    execFile("cmd", ["/c", "start", "", url], () => resolve());
  });
}

function parseArgs(argv) {
  const args = new Set(argv);
  const runDirIndex = argv.indexOf("--run-dir");
  return {
    selfTest: args.has("--self-test"),
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : ""
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runPreviewCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

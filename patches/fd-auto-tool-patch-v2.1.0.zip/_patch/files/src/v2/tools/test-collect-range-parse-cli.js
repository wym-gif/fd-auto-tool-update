import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { expectedFeishuCollectChecks } from "../fixtures/feishu-collect-sample.js";
import { collectRawEventsFromPage, summarizeRawEvents, validateCollectedRawEvents } from "../feishu/collector.js";
import { isFeishuCollectError } from "../feishu/collect-errors.js";
import { openV2CollectTestPage } from "../feishu/page-controller.js";
import { locateRange } from "../range/locate-range.js";
import { isRangeLocateError } from "../range/range-errors.js";
import { parseFixedFormatTasks } from "../parser/parse-fixed-format.js";
import { PREVIEW_TASK_REQUIRED_FIELDS, validatePreviewTaskShape } from "../contracts/preview-task.js";
import { buildPreviewScheduleOptions, preparePreviewTasksForGeneration } from "../time/schedule-preview-tasks.js";
import { formatDiagnostics, formatTasksTable } from "./test-parser-cli.js";

export async function runCollectRangeParseCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runRoot = options.runRoot || path.join(projectRoot, "runs");
  const runDir = path.join(runRoot, options.runName || `v2_flow_${timestamp()}`);
  let browser;
  try {
    await fs.mkdir(runDir, { recursive: true });
    const opened = await openV2CollectTestPage({ headless: true, url: options.url });
    browser = opened.browser;

    const collected = await collectRawEventsFromPage(opened.page);
    const rawEvents = validateCollectedRawEvents(collected, options.checks || expectedFeishuCollectChecks());
    await saveJson(path.join(runDir, "raw-events.json"), rawEvents);

    const range = options.range || {
      start: "开始关键词",
      end: "结束关键词"
    };
    const rangeResult = locateRange(rawEvents, range, options.rangeOptions || {});
    await saveJson(path.join(runDir, "range-events.json"), rangeResult.events);
    await saveJson(path.join(runDir, "range-diagnostics.json"), rangeResult.diagnostics);

    const scheduleOptions = buildPreviewScheduleOptions({
      scheduleMode: "realtime",
      realtimeStartTime: "10:00:00"
    }, options);
    const parsed = parseFixedFormatTasks(rangeResult.events, {
      scheduleMode: scheduleOptions.mode,
      ...options.parseOptions
    });
    const prepared = preparePreviewTasksForGeneration(parsed.tasks, scheduleOptions);
    for (const task of prepared.tasks) validatePreviewTaskShape(task);
    await saveJson(path.join(runDir, "preview-tasks.json"), prepared.tasks);

    return buildFlowReport({
      runDir,
      rawEvents,
      range,
      rangeResult,
      tasks: prepared.tasks,
      diagnostics: [...parsed.diagnostics, ...prepared.diagnostics],
      schedule: prepared
    });
  } catch (error) {
    if (isFeishuCollectError(error) || isRangeLocateError(error)) {
      return `${error.message}\n串联测试已停止，没有生成缺内容 PreviewTask。`;
    }
    throw error;
  } finally {
    await browser?.close().catch(() => {});
  }
}

export function buildFlowReport({ runDir, rawEvents, range, rangeResult, tasks, diagnostics, schedule }) {
  const summary = summarizeRawEvents(rawEvents);
  return [
    "2.0 采集 -> 范围 -> 固定解析串联输出",
    "",
    `保存目录：${runDir}`,
    `rawEvents：${path.join(runDir, "raw-events.json")}`,
    `rangeEvents：${path.join(runDir, "range-events.json")}`,
    `rangeDiagnostics：${path.join(runDir, "range-diagnostics.json")}`,
    `previewTasks：${path.join(runDir, "preview-tasks.json")}`,
    "",
    "采集完整性：通过",
    `采集统计：总数 ${summary.total}，文本 ${summary.line}，标题 ${summary.title}，图片 ${summary.image}，表情包 ${summary.sticker}，视频 ${summary.video}，分割线 ${summary.divider}`,
    "",
    `开始关键词：${range.start}`,
    `结束关键词：${range.end}`,
    `范围内 ${rangeResult.events.length} 条，其中生成 PreviewTask ${tasks.length} 条，过滤非发送项 ${rangeResult.events.length - tasks.length} 条`,
    "",
    "范围 diagnostics:",
    JSON.stringify(rangeResult.diagnostics, null, 2),
    "",
    `PreviewTask 合约字段：${PREVIEW_TASK_REQUIRED_FIELDS.join(" / ")}`,
    "",
    `预览编排：互动托${schedule?.interactionReordered ? "已重排" : "无需重排"}，时间模式=${schedule?.mode || "未指定"}；文档时间模式不改原文时间，正式创建只按 preview.json 最终顺序执行。`,
    "",
    formatTasksTable(tasks),
    "",
    formatDiagnostics(diagnostics),
    "",
    "串联测试完成：PreviewTask 已使用正式 2.0 合约结构保存。"
  ].join("\n");
}

async function saveJson(filePath, value) {
  await fs.writeFile(filePath, JSON.stringify(value, null, 2), "utf8");
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runCollectRangeParseCli().then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

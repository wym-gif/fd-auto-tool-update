import { assertCompanyAccessAllowed, getDeviceId } from "../license/license-manager.js";
if (process.argv.includes("--device-id")) {
  console.log(getDeviceId());
} else {
  try {
    await assertCompanyAccessAllowed(process.cwd(), "launch");
    console.log("授权通过。");
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}

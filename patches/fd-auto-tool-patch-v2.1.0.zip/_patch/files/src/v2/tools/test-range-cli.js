import { fileURLToPath } from "node:url";
import { rangeSampleRawEvents } from "../fixtures/range-sample.js";
import { locateRange } from "../range/locate-range.js";
import { parseFixedFormatTasks } from "../parser/parse-fixed-format.js";
import { formatDiagnostics, formatTasksTable } from "./test-parser-cli.js";

export function buildRangeCliReport(rawEvents = rangeSampleRawEvents(), range = defaultRange(), options = {}) {
  const rangeResult = locateRange(rawEvents, range, options);
  const parsed = parseFixedFormatTasks(rangeResult.events, {
    scheduleMode: "realtime",
    ...options
  });
  return [
    "2.0 范围读取 + 固定格式解析输出",
    "",
    `开始关键词：${range.start}`,
    `结束关键词：${range.end}`,
    "",
    "范围 diagnostics:",
    JSON.stringify(rangeResult.diagnostics, null, 2),
    "",
    formatTasksTable(parsed.tasks),
    "",
    formatDiagnostics(parsed.diagnostics)
  ].join("\n");
}

function defaultRange() {
  return {
    start: "开始关键词",
    end: "结束关键词命中这一条正文"
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  console.log(buildRangeCliReport());
}


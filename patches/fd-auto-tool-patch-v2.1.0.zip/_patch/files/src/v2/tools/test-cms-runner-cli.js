import path from "node:path";
import { fileURLToPath } from "node:url";
import { buildCreateRunnerReport, findLatestV2RunnerSource, runCreateRunner } from "../cms/create-runner.js";
import { createFakeCmsAdapter } from "../cms/cms-adapter.js";
import { missingPreviewJsonMessage } from "../cms/preview-run-source.js";

export async function runCmsRunnerCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const runDir = options.runDir || await findLatestV2RunnerSource(runsRoot);
  if (!runDir) {
    return missingPreviewJsonMessage();
  }
  const result = await runCreateRunner(runDir, {
    ...options,
    adapter: options.adapter || createFakeCmsAdapter(),
    allowRealSubmit: options.allowRealSubmit === true
  });
  return buildCreateRunnerReport(result);
}

function parseArgs(argv) {
  const runDirIndex = argv.indexOf("--run-dir");
  return {
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : "",
    allowRealSubmit: argv.includes("--allow-real-submit")
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runCmsRunnerCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import http from "node:http";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { createPreviewTestServer } from "../preview/preview-page.js";
import { finalPreviewPath, findLatestV2RealFlowRun, loadFinalPreviewForCreate, loadPreviewForOpen, previewTasksPath } from "../preview/preview-store.js";
import { runRealCollectRangeParseCli } from "./test-real-collect-range-parse-cli.js";
import { openV2CollectTestPage } from "../feishu/page-controller.js";

export async function runRealPreviewCli(options = {}) {
  if (options.selfTest) return runRealPreviewSelfTest(options);

  const projectRoot = options.projectRoot || process.cwd();
  const runsRoot = options.runsRoot || path.join(projectRoot, "runs");
  const latestRealFlow = options.runDir ? null : await findLatestRealFlowDirectory(runsRoot);
  if (latestRealFlow && !latestRealFlow.hasPreviewTasks) {
    const failure = await readRealFlowFailure(latestRealFlow.runDir);
    const failurePage = await createPreviewFailureServer({
      runDir: latestRealFlow.runDir,
      reason: failure.reason,
      files: latestRealFlow.files
    });
    if (options.openBrowser !== false) await openDefaultBrowser(failurePage.url);
    if (options.closeServerAfterStart) await failurePage.close();
    return [
      "最新真实采集范围解析目录没有 preview-tasks.json，不能打开旧预览。",
      `最新目录：${latestRealFlow.runDir}`,
      `失败原因：${failure.reason}`,
      `失败页：${failurePage.url}`,
      `文件状态：raw-events=${formatExists(latestRealFlow.files.rawEvents)} / preview-tasks=${formatExists(latestRealFlow.files.previewTasks)} / preview.json=${formatExists(latestRealFlow.files.previewJson)}`,
      "处理完失败后，重新运行 测试2.0重新生成真实预览.bat。"
    ].join("\n");
  }
  const runDir = options.runDir || latestRealFlow?.runDir || await findLatestV2RealFlowRun(runsRoot);
  if (!runDir) {
    return [
      "没有找到 runs\\v2_real_flow_xxx\\preview-tasks.json。",
      "请先运行 测试2.0真实采集范围解析.bat，再运行这个真实预览测试入口。",
      "注意：测试2.0真实飞书采集.bat 只生成 raw-events.json，不会生成预览任务。"
    ].join("\n");
  }

  const state = await loadPreviewForOpen(runDir);
  const preview = await createPreviewTestServer(runDir);
  if (options.openBrowser !== false) await openDefaultBrowser(preview.url);
  const report = [
    "2.0 真实预览页测试版已启动",
    "",
    `预览地址：${preview.url}`,
    `运行目录：${runDir}`,
    `当前来源：${state.source}`,
    `最终文件：${finalPreviewPath(runDir)}`,
    "",
    "规则：本入口只验证真实 PreviewTask 进入预览页并保存 preview.json。",
    "保存后的 preview.json 是后续唯一最终数据源。",
    "本入口不读取飞书，不重新解析，不创建 CMS 任务。",
    "如果要应用新的采集/解析规则，必须先重新运行 测试2.0真实采集范围解析.bat，生成新的 v2_real_flow_xxx。",
    "",
    "保持这个窗口打开。测试结束后按 Ctrl+C 关闭预览服务。"
  ].join("\n");
  if (options.closeServerAfterStart) await preview.close();
  return report;
}

async function findLatestRealFlowDirectory(runsRoot) {
  const entries = await fs.readdir(runsRoot, { withFileTypes: true }).catch(() => []);
  const candidates = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || !entry.name.startsWith("v2_real_flow_")) continue;
    const runDir = path.join(runsRoot, entry.name);
    const stat = await fs.stat(runDir).catch(() => null);
    if (!stat) continue;
    candidates.push({
      runDir,
      mtimeMs: stat.mtimeMs,
      hasPreviewTasks: await exists(previewTasksPath(runDir)),
      files: {
        rawEvents: await exists(path.join(runDir, "raw-events.json")),
        previewTasks: await exists(previewTasksPath(runDir)),
        previewJson: await exists(finalPreviewPath(runDir)),
        flowError: await exists(path.join(runDir, "flow-error.json")),
        collectDiagnostics: await exists(path.join(runDir, "collect-diagnostics.json"))
      }
    });
  }
  candidates.sort((a, b) => b.mtimeMs - a.mtimeMs || b.runDir.localeCompare(a.runDir));
  return candidates[0] || null;
}

async function readRealFlowFailure(runDir) {
  const errorPath = path.join(runDir, "flow-error.json");
  try {
    const error = JSON.parse(await fs.readFile(errorPath, "utf8"));
    if (error?.message) return { reason: error.message, source: errorPath };
  } catch {}

  const diagnosticsPath = path.join(runDir, "collect-diagnostics.json");
  try {
    const diagnostics = JSON.parse(await fs.readFile(diagnosticsPath, "utf8"));
    if (diagnostics?.failure) return { reason: diagnostics.failure, source: diagnosticsPath };
    return {
      reason: [
        "最新目录缺少 preview-tasks.json。",
        `采集条数：${diagnostics?.collectedEventCount ?? "未知"}`,
        `找到开始关键词：${formatBoolean(diagnostics?.foundStartKeyword)}`,
        `找到结束关键词：${formatBoolean(diagnostics?.foundEndKeyword)}`,
        `停止原因：${diagnostics?.stoppedBecause || "未知"}`
      ].join(" "),
      source: diagnosticsPath
    };
  } catch {}

  return {
    reason: "最新目录缺少 preview-tasks.json，且没有找到 flow-error.json 或 collect-diagnostics.json。",
    source: ""
  };
}

async function createPreviewFailureServer(failure) {
  const server = http.createServer((req, res) => {
    if ((req.url || "/").split("?")[0] !== "/") {
      res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
      res.end("Not found");
      return;
    }
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    res.end(renderPreviewFailurePage(failure));
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });
  const address = server.address();
  return {
    server,
    url: `http://127.0.0.1:${address.port}/`,
    close: () => new Promise((resolve) => server.close(resolve))
  };
}

function renderPreviewFailurePage(failure) {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>2.0 真实预览生成失败</title>
  <style>
    body { margin: 0; font-family: Arial, "Microsoft YaHei", sans-serif; color: #111827; background: #f8fafc; }
    main { max-width: 980px; margin: 48px auto; background: #fff; border: 1px solid #fecaca; border-radius: 8px; padding: 24px; }
    h1 { margin: 0 0 16px; font-size: 22px; color: #b91c1c; }
    .label { font-weight: 700; margin-top: 18px; }
    pre { white-space: pre-wrap; word-break: break-word; background: #f3f4f6; border: 1px solid #e5e7eb; padding: 12px; border-radius: 6px; }
    ul { padding-left: 22px; }
    li { margin: 6px 0; }
  </style>
</head>
<body>
  <main>
    <h1>真实预览生成失败，已禁止打开旧 preview.json</h1>
    <div class="label">失败目录</div>
    <pre>${escapeHtml(failure.runDir)}</pre>
    <div class="label">失败原因</div>
    <pre>${escapeHtml(failure.reason)}</pre>
    <div class="label">关键文件</div>
    <ul>
      <li>raw-events.json：${formatExists(failure.files?.rawEvents)}</li>
      <li>preview-tasks.json：${formatExists(failure.files?.previewTasks)}</li>
      <li>preview.json：${formatExists(failure.files?.previewJson)}</li>
      <li>flow-error.json：${formatExists(failure.files?.flowError)}</li>
      <li>collect-diagnostics.json：${formatExists(failure.files?.collectDiagnostics)}</li>
    </ul>
    <div class="label">下一步</div>
    <pre>处理失败原因后，重新运行“测试2.0重新生成真实预览.bat”。成功时打开的预览页顶部路径必须是最新 v2_real_flow 目录。</pre>
  </main>
</body>
</html>`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatExists(value) {
  return value ? "有" : "无";
}

function formatBoolean(value) {
  if (value === true) return "是";
  if (value === false) return "否";
  return "未知";
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

export async function runRealPreviewSelfTest(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const tempRoot = options.runRoot || await fs.mkdtemp(path.join(os.tmpdir(), "v2-real-preview-"));
  const runName = "v2_real_flow_preview_self_test";
  const fixtureUrl = "data:text/html;charset=utf-8," + encodeURIComponent(`<!doctype html>
    <main data-v2-feishu-fixture>
      <h1 data-v2-kind="title">真实预览自测</h1>
      <div class="ace-line">阿老 8/7 09:10:22</div>
      <div class="ace-line">开始词进入预览</div>
      <div class="ace-line">豆妈 8/7 09:13:50</div>
      <div class="ace-line">结束词进入预览</div>
    </main>`);

  await runRealCollectRangeParseCli({
    projectRoot,
    runRoot: tempRoot,
    runName,
    openPage: () => openV2CollectTestPage({ headless: true, url: fixtureUrl }),
    startKeyword: "开始词",
    endKeyword: "结束词",
    headless: true,
    waitMs: 0
  });

  const runDir = path.join(tempRoot, runName);
  const preview = await createPreviewTestServer(runDir);
  const browser = await chromium.launch({ headless: true });
  try {
    const page = await browser.newPage();
    await page.goto(preview.url, { waitUntil: "domcontentloaded" });
    await page.locator("tbody tr").first().locator("[data-field='speaker']").fill("真实预览改后说话人");
    await page.locator("tbody tr").first().locator("[data-field='time']").fill("12:34:56");
    await page.locator("tbody tr").first().locator("[data-field='text']").fill("真实预览用户改过的正文");
    await page.locator("tbody tr").first().locator("[data-field='skip']").check();
    await page.getByText("确认无误，进入云中客设置").click();
    await page.waitForFunction(() => document.getElementById("status")?.textContent.includes("已保存并核对通过"));

    const saved = await loadFinalPreviewForCreate(runDir);
    const changed = saved.tasks[0];
    if (changed.speaker !== "真实预览改后说话人" || changed.time !== "12:34:56" || changed.text !== "真实预览用户改过的正文" || changed.skip !== true) {
      throw new Error("真实预览自测失败：preview.json 没有保存用户修改。");
    }

    const reopened = await loadPreviewForOpen(runDir);
    if (reopened.source !== "preview.json" || reopened.tasks[0].text !== "真实预览用户改过的正文") {
      throw new Error("真实预览自测失败：二次打开没有优先读取 preview.json。");
    }

    await page.reload({ waitUntil: "domcontentloaded" });
    await page.getByText("确认无误，进入云中客设置").click();
    await page.waitForFunction(() => document.getElementById("status")?.textContent.includes("已保存并核对通过"));

    return [
      "2.0 真实预览页自测通过",
      `运行目录：${runDir}`,
      `最终文件：${finalPreviewPath(runDir)}`,
      "已验证：真实 PreviewTask 能进入预览页、用户修改能保存到 preview.json、二次打开优先读取 preview.json、最终核对只读 preview.json。"
    ].join("\n");
  } finally {
    await browser.close().catch(() => {});
    await preview.close();
  }
}

function openDefaultBrowser(url) {
  if (process.platform !== "win32") return Promise.resolve();
  return new Promise((resolve) => {
    execFile("cmd", ["/c", "start", "", url], () => resolve());
  });
}

export function parseArgs(argv = []) {
  const args = new Set(argv);
  const runDirIndex = argv.indexOf("--run-dir");
  return {
    selfTest: args.has("--self-test"),
    runDir: runDirIndex >= 0 ? argv[runDirIndex + 1] : ""
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runRealPreviewCli(parseArgs(process.argv.slice(2))).then((report) => {
    console.log(report);
    if (isRealPreviewFailureReport(report)) process.exitCode = 1;
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

function isRealPreviewFailureReport(report) {
  return /不能打开旧预览|没有找到 runs\\v2_real_flow_xxx\\preview-tasks\.json/.test(String(report || ""));
}

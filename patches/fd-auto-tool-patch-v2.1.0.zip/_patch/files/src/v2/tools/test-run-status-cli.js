import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createRunControl } from "../runtime/run-control.js";
import { humanizeRuntimeError, RUN_STAGES } from "../runtime/run-status.js";

export async function runStatusCli(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const runRoot = options.runRoot || path.join(projectRoot, "runs");
  const runDir = path.join(runRoot, options.runName || `v2_status_${timestamp()}`);
  const control = await createRunControl(runDir);
  const lines = ["2.0 状态/运行控制测试", "", `保存目录：${runDir}`];

  await control.setStage(RUN_STAGES.WAITING_SETTINGS);
  lines.push("状态：等待设置");
  await control.setStage(RUN_STAGES.READING_FEISHU);
  lines.push("状态：读取飞书");
  await control.progress(RUN_STAGES.SCANNING_CONTENT, 30, 100, "扫描正文和素材");
  lines.push("状态：扫描正文和素材 30%");
  await control.progress(RUN_STAGES.DOWNLOADING_MEDIA, 8, 13, "素材下载 8/13");
  lines.push("状态：下载素材 8/13");
  await control.setStage(RUN_STAGES.GENERATING_PREVIEW);
  lines.push("状态：生成预览");
  await control.setStage(RUN_STAGES.WAITING_CONFIRM);
  lines.push("状态：等待确认");
  await control.progress(RUN_STAGES.CREATING_TASKS, 41, 63, "创建 41/63");
  lines.push("状态：创建任务 41/63");
  await control.pause("用户点击暂停");
  lines.push("状态：暂停");
  await control.stop("用户点击停止");
  lines.push("状态：停止");
  await control.fail(new Error("ENOENT: no such file or directory"), { index: 3 });
  lines.push(`状态：失败：${humanizeRuntimeError(new Error("ENOENT"), { index: 3 })}`);

  const statusPath = path.join(runDir, "status.json");
  const eventsPath = path.join(runDir, "status-events.json");
  await fs.access(statusPath);
  await fs.access(eventsPath);
  lines.push("");
  lines.push(`status.json：${statusPath}`);
  lines.push(`status-events.json：${eventsPath}`);
  lines.push("状态控制测试完成。");
  return lines.join("\n");
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  runStatusCli().then((report) => {
    console.log(report);
  }).catch((error) => {
    console.error(error?.message || error);
    process.exitCode = 1;
  });
}

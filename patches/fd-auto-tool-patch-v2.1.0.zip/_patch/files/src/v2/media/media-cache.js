import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

const MEDIA_TYPES = new Set(["image", "sticker", "video"]);

export function isMediaType(type) {
  return MEDIA_TYPES.has(String(type || ""));
}

export function isTemporaryBrowserMediaPath(value) {
  return /^(blob:|image-blob:)/i.test(String(value || "").trim());
}

export function isFetchableTemporaryMediaPath(value) {
  return /^blob:/i.test(String(value || "").trim());
}

export function isRemoteMediaPath(value) {
  return /^https?:\/\//i.test(String(value || "").trim());
}

export function isDataMediaPath(value) {
  return /^data:(?:image|video)\//i.test(String(value || "").trim());
}

export function shouldLocalizeMediaPath(value) {
  const text = String(value || "").trim();
  return isRemoteMediaPath(text) || isTemporaryBrowserMediaPath(text) || isDataMediaPath(text);
}

export async function localizeMediaItemsFromPage(page, items = [], options = {}) {
  const cacheDir = options.mediaCacheDir || options.blobMediaDir || options.materializeBlobMediaDir || "";
  if (!cacheDir) return items;
  const getType = typeof options.getType === "function"
    ? options.getType
    : (item) => item?.type || item?.kind;
  const entries = items
    .map((item, index) => ({
      item,
      index,
      type: String(getType(item) || ""),
      mediaPath: mediaPathForItem(item)
    }))
    .filter((entry) => isMediaType(entry.type) && shouldLocalizeMediaPath(entry.mediaPath));
  if (!entries.length) return items;

  const byUrl = await localizeMediaEntriesFromPage(page, entries, cacheDir, {
    onProgress: options.onProgress
  });
  return items.map((item) => {
    const original = mediaPathForItem(item);
    const local = byUrl.get(original);
    if (!local) return item;
    return localizeItem(item, original, local);
  });
}

export async function localizePreviewTaskMediaWithFetch(tasks = [], options = {}) {
  const cacheDir = options.mediaCacheDir || path.join(options.runDir || process.cwd(), "media-cache");
  await fs.mkdir(cacheDir, { recursive: true });
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  return Promise.all(tasks.map(async (task, index) => {
    const type = String(task?.type || "");
    const source = String(task?.mediaPath || "").trim();
    if (!isMediaType(type) || !shouldLocalizeMediaPath(source)) return task;
    if (isTemporaryBrowserMediaPath(source) && !isDataMediaPath(source)) return task;
    if (!fetchImpl) return task;
    try {
      const media = isDataMediaPath(source)
        ? decodeDataMediaUrl(source)
        : await fetchRemoteMedia(fetchImpl, source, options);
      const local = await saveMediaBuffer(cacheDir, {
        source,
        type,
        index,
        buffer: media.buffer,
        mime: media.mime || "",
        suggestedExt: extensionFromUrl(source)
      });
      return localizeItem(task, source, local);
    } catch (error) {
      return {
        ...task,
        sourceUrl: task.sourceUrl || source,
        mediaDownloadError: error?.message || String(error)
      };
    }
  }));
}

async function localizeMediaEntriesFromPage(page, entries, cacheDir, options = {}) {
  await fs.mkdir(cacheDir, { recursive: true });
  const byUrl = new Map();
  const uniqueEntries = [];
  for (const entry of entries) {
    if (!entry.mediaPath || byUrl.has(entry.mediaPath) || uniqueEntries.some((item) => item.mediaPath === entry.mediaPath)) continue;
    uniqueEntries.push(entry);
  }

  const onProgress = typeof options.onProgress === "function" ? options.onProgress : null;
  const total = uniqueEntries.length;
  for (let offset = 0; offset < uniqueEntries.length; offset += 1) {
    const entry = uniqueEntries[offset];
    const current = offset + 1;
    let media = null;
    try {
      onProgress?.({
        phase: "start",
        current,
        total,
        type: entry.type,
        index: entry.index,
        item: entry.item,
        source: entry.mediaPath
      });
      const inlineMediaDataUrl = entry.item?.inlineMediaDataUrl || entry.item?.raw?.inlineMediaDataUrl || "";
      if (isDataMediaPath(inlineMediaDataUrl)) {
        media = decodeDataMediaUrl(inlineMediaDataUrl);
      } else if (isDataMediaPath(entry.mediaPath)) {
        media = decodeDataMediaUrl(entry.mediaPath);
      } else if (isFetchableTemporaryMediaPath(entry.mediaPath) || isRemoteMediaPath(entry.mediaPath)) {
        media = await fetchMediaWithPage(page, entry.mediaPath);
      }
      if (!media?.buffer?.length) {
        onProgress?.({
          phase: "failed",
          current,
          total,
          type: entry.type,
          index: entry.index,
          item: entry.item,
          source: entry.mediaPath,
          error: "素材内容为空"
        });
        continue;
      }
      const local = await saveMediaBuffer(cacheDir, {
        source: entry.mediaPath,
        type: entry.type,
        index: entry.index,
        buffer: media.buffer,
        mime: media.mime || "",
        suggestedExt: extensionFromUrl(entry.mediaPath)
      });
      byUrl.set(entry.mediaPath, local);
      onProgress?.({
        phase: "done",
        current,
        total,
        type: entry.type,
        index: entry.index,
        item: entry.item,
        source: entry.mediaPath,
        localPath: local.path,
        size: local.size
      });
    } catch (error) {
      onProgress?.({
        phase: "failed",
        current,
        total,
        type: entry.type,
        index: entry.index,
        item: entry.item,
        source: entry.mediaPath,
        error: error?.message || String(error)
      });
      // The caller keeps the original URL; validation later reports the exact failed item.
    }
  }
  return byUrl;
}

async function fetchMediaWithPage(page, url) {
  const pageResult = await page.evaluate(async (targetUrl) => {
    try {
      const response = await fetch(targetUrl, { credentials: "include", redirect: "follow" });
      if (!response.ok) return { ok: false, error: `HTTP ${response.status}` };
      const blob = await response.blob();
      const buffer = await blob.arrayBuffer();
      return {
        ok: true,
        mime: blob.type || response.headers.get("content-type") || "",
        base64: arrayBufferToBase64(buffer)
      };
    } catch (error) {
      return { ok: false, error: error?.message || String(error) };
    }

    function arrayBufferToBase64(buffer) {
      let binary = "";
      const bytes = new Uint8Array(buffer);
      const chunkSize = 0x8000;
      for (let offset = 0; offset < bytes.length; offset += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
      }
      return btoa(binary);
    }
  }, url).catch((error) => ({ ok: false, error: error?.message || String(error) }));
  if (pageResult?.ok && pageResult.base64) {
    return {
      buffer: Buffer.from(pageResult.base64, "base64"),
      mime: pageResult.mime || ""
    };
  }

  if (isRemoteMediaPath(url)) {
    const response = await page.context().request.get(url, {
      timeout: 30000,
      headers: {
        referer: page.url() || "https://miaoquan.feishu.cn/"
      }
    });
    if (!response.ok()) throw new Error(`HTTP ${response.status()}`);
    const buffer = await response.body();
    return {
      buffer,
      mime: response.headers()["content-type"] || ""
    };
  }

  throw new Error(pageResult?.error || "浏览器临时素材读取失败");
}

async function fetchRemoteMedia(fetchImpl, url, options = {}) {
  const controller = new AbortController();
  const timeoutMs = options.timeoutMs || 30000;
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchImpl(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "user-agent": "fd-auto-tool-v2-preview-media",
        referer: "https://miaoquan.feishu.cn/"
      }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const buffer = Buffer.from(await response.arrayBuffer());
    if (!buffer.length) throw new Error("下载内容为空");
    return {
      buffer,
      mime: response.headers?.get?.("content-type") || ""
    };
  } finally {
    clearTimeout(timer);
  }
}

async function saveMediaBuffer(cacheDir, entry) {
  const ext = mediaExtensionFromMime(entry.mime) || entry.suggestedExt || mediaExtensionFromEventType(entry.type);
  const hash = crypto.createHash("sha1").update(entry.buffer).digest("hex").slice(0, 10);
  const fileName = `${String(entry.index + 1).padStart(3, "0")}-${entry.type}-${hash}${ext}`;
  const filePath = path.join(cacheDir, fileName);
  await fs.writeFile(filePath, entry.buffer);
  return {
    path: filePath,
    mime: entry.mime || "",
    size: entry.buffer.length,
    hash
  };
}

function localizeItem(item, original, local) {
  return {
    ...item,
    mediaPath: local.path,
    assetUrl: local.path,
    src: local.path,
    sourceUrl: item.sourceUrl || original,
    raw: {
      ...item.raw,
      originalMediaPath: item.raw?.originalMediaPath || original,
      sourceUrl: item.raw?.sourceUrl || item.sourceUrl || original,
      materializedHash: local.hash,
      materializedMime: local.mime,
      materializedSize: local.size
    },
    materializedHash: local.hash,
    materializedMime: local.mime,
    materializedSize: local.size
  };
}

function mediaPathForItem(item) {
  return String(item?.mediaPath || item?.assetUrl || item?.src || "").trim();
}

function decodeDataMediaUrl(value) {
  const match = String(value || "").match(/^data:([^;,]+)?(?:;[^,]*)?,(.*)$/i);
  if (!match) throw new Error("data 素材格式不合法");
  const mime = match[1] || "";
  const payload = match[2] || "";
  const isBase64 = /;base64,/i.test(String(value));
  return {
    buffer: isBase64 ? Buffer.from(payload, "base64") : Buffer.from(decodeURIComponent(payload)),
    mime
  };
}

function extensionFromUrl(value) {
  const pathname = String(value || "").split(/[?#]/)[0].toLowerCase();
  const match = pathname.match(/\.(jpg|jpeg|png|webp|gif|mp4|mov|webm)$/);
  return match ? `.${match[1]}` : "";
}

function mediaExtensionFromMime(mime) {
  const value = String(mime || "").split(";")[0].trim().toLowerCase();
  if (value === "image/jpeg" || value === "image/jpg") return ".jpg";
  if (value === "image/png") return ".png";
  if (value === "image/gif") return ".gif";
  if (value === "image/webp") return ".webp";
  if (value === "video/mp4") return ".mp4";
  if (value === "video/quicktime") return ".mov";
  if (value === "video/webm") return ".webm";
  return "";
}

function mediaExtensionFromEventType(type) {
  if (type === "video") return ".mp4";
  if (type === "sticker") return ".gif";
  return ".jpg";
}

// Fixed company gateway. Runtime configuration cannot select another server.
export const TRUSTED_LICENSE_SERVERS = Object.freeze(["https://api.qzmq.cn/license/check"]);
export const LICENSE_COMPANY_ID = "miaoquan";

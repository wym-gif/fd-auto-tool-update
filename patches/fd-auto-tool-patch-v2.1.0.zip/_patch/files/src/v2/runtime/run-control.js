import fs from "node:fs/promises";
import path from "node:path";
import { createRunStatus, humanizeRuntimeError, RUN_STAGES, statusEvent } from "./run-status.js";

export class RunControlSignal extends Error {
  constructor(code, message, status) {
    super(message);
    this.name = "RunControlSignal";
    this.code = code;
    this.status = status;
  }
}

export async function createRunControl(runDir, options = {}) {
  const control = new FileRunControl(runDir, options);
  await control.init();
  return control;
}

export class FileRunControl {
  constructor(runDir, options = {}) {
    this.runDir = runDir;
    this.statusPath = options.statusPath || path.join(runDir, "status.json");
    this.eventsPath = options.eventsPath || path.join(runDir, "status-events.json");
    this.status = createRunStatus(options.initialStatus || {});
  }

  async init() {
    await fs.mkdir(this.runDir, { recursive: true });
    await this.writeStatus(this.status, "init");
    return this;
  }

  async setStage(stage, progress = {}) {
    return this.writeStatus(createRunStatus({
      ...this.status,
      ...progress,
      stage,
      label: progress.label,
      paused: false,
      stopped: false,
      error: null
    }), "stage");
  }

  async progress(stage, current, total, detail = "") {
    return this.writeStatus(createRunStatus({
      ...this.status,
      stage,
      current,
      total,
      detail,
      paused: false,
      stopped: false,
      error: null
    }), "progress");
  }

  async pause(detail = "用户点击暂停") {
    return this.writeStatus(createRunStatus({
      ...this.status,
      stage: RUN_STAGES.PAUSED,
      detail,
      paused: true,
      stopped: false
    }), "pause");
  }

  async resume(detail = "用户点击继续") {
    return this.writeStatus(createRunStatus({
      ...this.status,
      stage: RUN_STAGES.CREATING_TASKS,
      detail,
      paused: false,
      stopped: false,
      error: null
    }), "resume");
  }

  async stop(detail = "用户点击停止") {
    return this.writeStatus(createRunStatus({
      ...this.status,
      stage: RUN_STAGES.STOPPED,
      detail,
      paused: false,
      stopped: true
    }), "stop");
  }

  async fail(error, context = {}) {
    return this.writeStatus(createRunStatus({
      ...this.status,
      stage: RUN_STAGES.FAILED,
      detail: humanizeRuntimeError(error, context),
      error: {
        message: humanizeRuntimeError(error, context),
        rawMessage: String(error?.message || error || "")
      },
      paused: false,
      stopped: false
    }), "fail");
  }

  async done(detail = "完成") {
    return this.writeStatus(createRunStatus({
      ...this.status,
      stage: RUN_STAGES.DONE,
      detail,
      paused: false,
      stopped: false,
      error: null
    }), "done");
  }

  async checkpoint(label = "") {
    const latest = await this.readStatus();
    if (latest.stopped || latest.stage === RUN_STAGES.STOPPED) {
      throw new RunControlSignal("stopped", `已停止，后台停在检查点：${label}`, latest);
    }
    if (latest.paused || latest.stage === RUN_STAGES.PAUSED) {
      throw new RunControlSignal("paused", `已暂停，后台停在检查点：${label}`, latest);
    }
    return latest;
  }

  async readStatus() {
    try {
      this.status = createRunStatus(JSON.parse(await fs.readFile(this.statusPath, "utf8")));
    } catch {
      this.status = createRunStatus(this.status);
    }
    return this.status;
  }

  async readEvents() {
    try {
      return JSON.parse(await fs.readFile(this.eventsPath, "utf8"));
    } catch {
      return [];
    }
  }

  async writeStatus(status, event) {
    this.status = createRunStatus(status);
    await fs.writeFile(this.statusPath, JSON.stringify(this.status, null, 2), "utf8");
    const events = await this.readEvents();
    events.push(statusEvent(this.status, event));
    await fs.writeFile(this.eventsPath, JSON.stringify(events, null, 2), "utf8");
    return this.status;
  }
}

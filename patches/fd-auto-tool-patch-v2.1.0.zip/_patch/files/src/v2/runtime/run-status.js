export const RUN_STAGES = Object.freeze({
  WAITING_SETTINGS: "waiting-settings",
  READING_FEISHU: "reading-feishu",
  SCANNING_CONTENT: "scanning-content",
  DOWNLOADING_MEDIA: "downloading-media",
  GENERATING_PREVIEW: "generating-preview",
  WAITING_CONFIRM: "waiting-confirm",
  CREATING_TASKS: "creating-tasks",
  PAUSED: "paused",
  STOPPED: "stopped",
  FAILED: "failed",
  DONE: "done"
});

export const RUN_STAGE_LABELS = Object.freeze({
  [RUN_STAGES.WAITING_SETTINGS]: "等待设置",
  [RUN_STAGES.READING_FEISHU]: "读取飞书",
  [RUN_STAGES.SCANNING_CONTENT]: "扫描正文和素材",
  [RUN_STAGES.DOWNLOADING_MEDIA]: "下载素材",
  [RUN_STAGES.GENERATING_PREVIEW]: "生成预览",
  [RUN_STAGES.WAITING_CONFIRM]: "等待确认",
  [RUN_STAGES.CREATING_TASKS]: "创建任务",
  [RUN_STAGES.PAUSED]: "暂停",
  [RUN_STAGES.STOPPED]: "停止",
  [RUN_STAGES.FAILED]: "失败",
  [RUN_STAGES.DONE]: "完成"
});

export function createRunStatus(fields = {}) {
  const current = numberOrZero(fields.current);
  const total = numberOrZero(fields.total);
  const stage = fields.stage || RUN_STAGES.WAITING_SETTINGS;
  return {
    stage,
    label: fields.label || RUN_STAGE_LABELS[stage] || stage,
    current,
    total,
    percent: percent(current, total),
    detail: String(fields.detail || ""),
    paused: Boolean(fields.paused),
    stopped: Boolean(fields.stopped),
    error: fields.error || null,
    updatedAt: fields.updatedAt || new Date().toISOString()
  };
}

export function statusEvent(status, event = "status") {
  return {
    event,
    stage: status.stage,
    label: status.label,
    current: status.current,
    total: status.total,
    percent: status.percent,
    detail: status.detail,
    paused: status.paused,
    stopped: status.stopped,
    error: status.error,
    updatedAt: status.updatedAt
  };
}

export function humanizeRuntimeError(error, context = {}) {
  const message = String(error?.message || error || "");
  const itemPrefix = context.index ? `第 ${context.index} 条` : "";
  if (/Target page, context or browser has been closed|Target page has been closed|Target closed|Browser has been closed|Page closed/i.test(message)) {
    return `${context.source || "页面"}已关闭，请重新打开后再试。`;
  }
  if (/start_keyword_not_found|没找到开始关键词|Cannot find start/i.test(message)) {
    return "没找到开始关键词。";
  }
  if (/end_keyword_not_found|没找到结束关键词|Cannot find end/i.test(message)) {
    return "没找到结束关键词。";
  }
  if (/start_record_not_found|找到了开始关键词，但没有确认/i.test(message)) {
    return "找到了开始关键词，但没采到它所属的完整角色记录。";
  }
  if (/素材不存在|ENOENT/i.test(message)) {
    return `${itemPrefix || "当前条"}素材不存在。`;
  }
  if (/文本输入校验失败|文本.*不一致|预览文字为空/i.test(message)) {
    return `${itemPrefix || "当前条"}文本填入不完整。`;
  }
  if (/locator|timeout/i.test(message)) {
    return `${context.source || "云中客"}页面异常：元素定位或等待超时。`;
  }
  if (/已暂停|暂停/i.test(message)) return "已暂停，后台已停在当前检查点。";
  if (/已停止|停止/i.test(message)) return "已停止，后台不会继续创建下一条。";
  return message || "运行失败。";
}

function percent(current, total) {
  if (!total) return 0;
  return Math.max(0, Math.min(100, Math.round((current / total) * 100)));
}

function numberOrZero(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

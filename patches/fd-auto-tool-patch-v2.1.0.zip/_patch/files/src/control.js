import { getSharedControlForRun } from "./control-ui.js";

export async function createRunControl(context, config = {}) {
  return getSharedControlForRun(context, config);
}

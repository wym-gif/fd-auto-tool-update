﻿import fs from "node:fs/promises";
import path from "node:path";
import { ensureDir } from "./utils.js";
import {
  splitRangeKeywords
} from "./feishu/range-utils.js";
import { createReadRangeTools } from "./feishu/read-range.js";
import { createFeishuPageLocator } from "./feishu/page-locator.js";
import { removeDownloadedStickerPreviewDuplicates } from "./feishu/media-dedupe.js";
import { collectPageData } from "./feishu/collect-page-data.js";
import {
  HEADER_RE,
  buildProjectTasks,
  normalizeProjectType,
  parseDateSectionTitle,
  isTemplateSectionTitle,
  isVisualSectionTitle,
  isFeaturedDayTitle,
  isFeaturedRhythmTitle,
  isHeaderRemark,
  isTemplateContentInstruction,
  isFeaturedDayAnchor,
  isLikelyFeaturedRhythmKeyword
} from "./feishu/task-parser.js";
import {
  clearProgressLine,
  printProgressStep,
  reportControlProgress,
  writeProgressBar
} from "./runtime/progress.js";
import { secondsToClock as secondsToTimeShared, timeToSeconds as timeToSecondsShared } from "./schedule/time-utils.js";

const {
  applyReadRange,
  stripRangeMarkers,
  attachRangeStartOmittedMedia,
  buildRangeBoundary,
  rangeBoundarySeenInLines,
  applyRawReadRange,
  parseFeaturedPipeRangeKeyword
} = createReadRangeTools({
  parseDateSectionTitle,
  isTemplateSectionTitle,
  isVisualSectionTitle,
  isFeaturedDayTitle,
  isFeaturedRhythmTitle,
  isHeaderRemark,
  isTemplateContentInstruction,
  isFeaturedDayAnchor,
  isLikelyFeaturedRhythmKeyword,
  normalizeProjectType,
  headerRe: HEADER_RE
});
export async function readFeishuTasks(page, config, runDir, options = {}) {
  checkPreviewRestartSignal(config);
  const downloadMediaFiles = options.downloadMediaFiles !== false;
  const dropFailedMedia = options.dropFailedMedia !== false;
  const showProgress = options.showProgress !== false && downloadMediaFiles;
  if (showProgress) printProgressStep("正在读取飞书...");
  await page.goto(config.feishuUrl, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(2000);
  checkPreviewRestartSignal(config);

  const rangeEnabled = Boolean(config.readRange?.enabled && config.readRange?.start && (config.readRange?.end || config.readRange?.endAtDocumentEnd));
  const rangeStartLocated = rangeEnabled
    ? await jumpToReadRangeStart(page, config, { showProgress })
    : false;
  if (rangeEnabled && !rangeStartLocated) {
    console.log("没有直接定位到开始位置，改为全文扫描后按原文关键词截取范围。");
  }
  if (showProgress) printProgressStep("正在扫描正文和素材...");
  checkPreviewRestartSignal(config);
  const pageData = await collectPageData(page, config, {
    showProgress,
    startAtCurrentPosition: rangeStartLocated,
    requireStartBoundary: rangeStartLocated,
    stopAfterRangeEnd: rangeStartLocated
  }, {
    checkPreviewRestartSignal,
    buildRangeBoundary,
    rangeBoundarySeenInLines
  });
  const rangedPageData = rangeEnabled
    ? applyRawReadRange(pageData, config, { startLocatedByPage: rangeStartLocated })
    : pageData;
  checkPreviewRestartSignal(config);
  if (showProgress) printProgressStep("正在生成预览...");
  const parsedTasks = buildProjectTasks(rangedPageData.lines, rangedPageData.images, rangedPageData.videos, config);
  const rangedTasks = rangedPageData.rangeAppliedToRaw
    ? stripRangeMarkers(parsedTasks)
    : applyReadRange(parsedTasks, config, { startLocatedByPage: rangeStartLocated });
  const rangeStartOmittedMedia = rangedTasks.__rangeStartOmittedMedia || [];
  const spacedTasks = applyTimeSpacing(rangedTasks, config);
  attachRangeStartOmittedMedia(spacedTasks, rangeStartOmittedMedia);
  const tasks = shouldApplyInteractionOrder(config) ? applyInteractionOrder(spacedTasks, config) : spacedTasks;
  attachRangeStartOmittedMedia(tasks, rangeStartOmittedMedia);
  if (downloadMediaFiles) {
    await downloadMedia(page, [...tasks, ...rangeStartOmittedMedia.map((item) => item.task)], runDir, { showProgress, control: config.__runControl });
  }
  const dedupedTasks = downloadMediaFiles ? await removeDownloadedStickerPreviewDuplicates(tasks) : tasks;
  const runnableTasks = downloadMediaFiles && dropFailedMedia ? dropMissingMedia(dedupedTasks) : dedupedTasks;
  const taggedTasks = tagTuoTasks(runnableTasks);
  attachRangeStartOmittedMedia(taggedTasks, rangeStartOmittedMedia);
  return taggedTasks;
}

function checkPreviewRestartSignal(config = {}) {
  if (!config.__runControl?.peekPreviewRestart?.()) return;
  const error = new Error("已收到放弃本轮并重新生成预览的请求");
  error.previewRestartRequested = true;
  throw error;
}

function shouldApplyInteractionOrder(config) {
  if (config.reorderTuoInteractions === false) return false;
  return true;
}

const { jumpToReadRangeStart } = createFeishuPageLocator({
  checkPreviewRestartSignal,
  printProgressStep,
  splitRangeKeywords,
  parseFeaturedPipeRangeKeyword
});

function applyInteractionOrder(tasks, config = {}) {
  const used = new Set();
  const result = [];
  for (let i = 0; i < tasks.length; i += 1) {
    if (used.has(i)) continue;
    const task = tasks[i];
    result.push(task);
    used.add(i);

    if (task.role !== "tuo" || task.robotGroup === undefined || task.robotGroup === null) continue;
    if (!canPullTuoInteractionForward(task, tasks, config)) continue;
    for (let j = i + 1; j < tasks.length; j += 1) {
      if (used.has(j)) continue;
      const next = tasks[j];
      const sameTuoRobot = next.role === "tuo" &&
        next.robotGroup === task.robotGroup &&
        sameInteractionScope(task, next, config);
      if (sameTuoRobot) {
        result.push(next);
        used.add(j);
      }
    }
  }
  return result;
}

function canPullTuoInteractionForward(task, tasks, config) {
  const hasExplicitInteraction = tasks.some((next) =>
    next.role === "tuo" &&
    next.robotGroup === task.robotGroup &&
    sameInteractionScope(task, next, config) &&
    (next.continueSpeaker === true || next.interactiveTuo === true)
  );
  if (!hasExplicitInteraction) return false;
  if (config.scheduleMode !== "realtime" && config.scheduleMode !== "catchup") return true;
  if (config.reorderTuoInteractionsInRealtime === true) return true;
  if (config.realtimeInteractionOrderMode === "all") return true;
  return true;
}

function sameInteractionScope(a, b, config = {}) {
  return true;
}

function applyTimeSpacing(tasks, config) {
  const minOtherSpeakerGap = Number(config.minOtherSpeakerGapSeconds ?? 15);
  const result = [];
  const featuredInteractionTuoGap = Number(config.featuredInteractionTuoGapSeconds ?? 60);
  const featuredProject = normalizeProjectType(config.projectType) === "featured";
  for (let index = 0; index < tasks.length; index += 1) {
    const task = tasks[index];
    const next = { ...task };
    const prev = result[result.length - 1];
    if (prev && prev.time && next.time) {
      const prevSec = taskToAbsoluteSeconds(prev);
      const nextSec = taskToAbsoluteSeconds(next);
      if (prev.speaker === next.speaker && prev.role === next.role) {
        const gap = spacingSeconds(next);
        next.originalTime = next.originalTime || next.time;
        applyAbsoluteSeconds(next, prevSec + gap);
      } else {
        const gap = featuredProject && isFeaturedInteractiveTuoSwitch(tasks, index)
          ? Math.max(minOtherSpeakerGap, featuredInteractionTuoGap)
          : minOtherSpeakerGap;
        if (nextSec - prevSec < gap) {
          next.originalTime = next.originalTime || next.time;
          applyAbsoluteSeconds(next, prevSec + gap);
        }
      }
    }
    result.push(next);
  }
  return result;
}

function isFeaturedInteractiveTuoSwitch(tasks, index) {
  const current = tasks[index];
  const prev = tasks[index - 1];
  if (!prev || !current) return false;
  if (prev.role !== "tuo" || current.role !== "tuo") return false;
  if (prev.robotGroup === undefined || prev.robotGroup === null) return false;
  if (current.robotGroup === undefined || current.robotGroup === null) return false;
  if (String(prev.robotGroup) === String(current.robotGroup)) return false;

  const prevGroup = String(prev.robotGroup);
  const currentGroup = String(current.robotGroup);
  const prevAppearsLater = tasks.slice(index + 1).some((task) =>
    task.role === "tuo" && String(task.robotGroup) === prevGroup
  );
  const currentAppearedEarlier = tasks.slice(0, index - 1).some((task) =>
    task.role === "tuo" && String(task.robotGroup) === currentGroup
  );
  return prevAppearsLater || currentAppearedEarlier;
}

function spacingSeconds(task) {
  if (task.type === "image" || task.type === "sticker" || task.type === "video") return 30;
  const len = (task.text || "").replace(/\s+/g, "").length;
  if (len <= 20) return 20;
  if (len <= 60) return 30;
  return 45;
}

function timeToSeconds(time) {
  const seconds = timeToSecondsShared(time);
  return seconds === null ? NaN : seconds;
}

function taskToAbsoluteSeconds(task) {
  const dayOffset = Number(task.scheduleDateOffset || 0);
  return dayOffset * 86400 + timeToSeconds(task.time);
}

function applyAbsoluteSeconds(task, absoluteSeconds) {
  const dayOffset = Math.floor(absoluteSeconds / 86400);
  task.time = secondsToTime(absoluteSeconds);
  if (dayOffset !== Number(task.scheduleDateOffset || 0)) {
    const date = new Date();
    date.setDate(date.getDate() + dayOffset);
    task.scheduleDateOffset = dayOffset;
    task.scheduleDateLabel = `${date.getMonth() + 1}/${date.getDate()}`;
    task.scheduleDateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }
}

function secondsToTime(total) {
  return secondsToTimeShared(total);
}

async function downloadMedia(page, tasks, runDir, options = {}) {
  const imgDir = path.join(runDir, "images");
  await ensureDir(imgDir);
  let count = 0;
  const mediaTasks = tasks.filter((t) => t.type === "image" || t.type === "sticker" || t.type === "video");
  if (options.showProgress) printProgressStep(mediaTasks.length ? `正在下载素材：共 ${mediaTasks.length} 个` : "没有需要下载的素材");
  for (const task of mediaTasks) {
    count += 1;
    const detail = `${task.role || ""}/${task.speaker || ""}/${task.type || ""}`;
    if (options.showProgress) {
      writeProgressBar("素材下载", count, mediaTasks.length, detail);
      reportControlProgress(options.control, "素材下载", count, mediaTasks.length, detail);
    }
    if (!task.assetUrl) continue;
    try {
      const bytes = await page.evaluate(async (url) => {
        const res = await window.fetch(url, { credentials: "include" });
        const buf = await res.arrayBuffer();
        return Array.from(new Uint8Array(buf));
      }, task.assetUrl);
      const buffer = Buffer.from(bytes);
      const file = path.join(imgDir, `image_${String(count).padStart(2, "0")}${detectMediaExt(buffer, task.assetUrl)}`);
      await fs.writeFile(file, buffer);
      task.imagePath = file;
    } catch {
      task.imagePath = "";
      task.imageDownloadError = "素材原文件下载失败，需要手动保存或换用复制/上传流程";
    }
  }
  if (options.showProgress) clearProgressLine();
}

export async function downloadTaskMedia(page, task, runDir, index = 0) {
  if (!(task.type === "image" || task.type === "sticker" || task.type === "video")) return task;
  if (task.imagePath) return task;
  if (!task.assetUrl) return task;

  const imgDir = path.join(runDir, "images");
  await ensureDir(imgDir);
  const safeIndex = String(index + 1).padStart(3, "0");
  try {
    const buffer = await fetchMediaBuffer(page, task.assetUrl);
    const file = path.join(imgDir, `image_${safeIndex}${detectMediaExt(buffer, task.assetUrl)}`);
    await fs.writeFile(file, buffer);
    task.imagePath = file;
    task.imageDownloadError = "";
  } catch {
    task.imagePath = "";
    task.imageDownloadError = "素材原文件下载失败，需要手动保存或换用复制/上传流程";
  }
  return task;
}

async function fetchMediaBuffer(page, url) {
  try {
    const response = await page.context().request.get(url, {
      timeout: 30000,
      headers: {
        referer: "https://miaoquan.feishu.cn/"
      }
    });
    if (!response.ok()) throw new Error(`HTTP ${response.status()}`);
    return await response.body();
  } catch (firstError) {
    const helper = await page.context().newPage();
    try {
      await helper.goto("https://miaoquan.feishu.cn/", { waitUntil: "domcontentloaded", timeout: 20000 }).catch(() => {});
      const bytes = await helper.evaluate(async (mediaUrl) => {
        const res = await window.fetch(mediaUrl, { credentials: "include" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const buf = await res.arrayBuffer();
        return Array.from(new Uint8Array(buf));
      }, url);
      return Buffer.from(bytes);
    } finally {
      await helper.close().catch(() => {});
    }
  }
}

function dropMissingMedia(tasks) {
  return tasks.filter((task) => {
    const isMedia = task.type === "image" || task.type === "sticker" || task.type === "video";
    if (!isMedia || task.imagePath) return true;
    console.log(`跳过未下载成功的素材：${task.role} / ${task.speaker} / ${task.time}`);
    return false;
  });
}

function tagTuoTasks(tasks) {
  const groupText = new Map();
  for (const task of tasks) {
    if (task.role !== "tuo") continue;
    const key = task.robotGroup ?? task.speaker;
    const previous = groupText.get(key) || "";
    groupText.set(key, `${previous}\n${task.text || ""}`);
  }

  return tasks.map((task) => {
    if (task.role !== "tuo") return task;
    const key = task.robotGroup ?? task.speaker;
    const context = `${groupText.get(key) || ""}\n${task.text || ""}`;
    const personaTags = inferPersonaTags(context);
    const contentTags = inferContentTags(task, context);
    return {
      ...task,
      personaTags,
      contentTags,
      previewTags: [...personaTags, ...contentTags]
    };
  });
}

function inferPersonaTags(text) {
  const source = String(text || "");
  const tags = [];
  if (hasAny(source, ["老公", "孩子", "小孩", "儿子", "女儿", "宝宝", "家里", "老人", "爸妈", "妈妈"])) tags.push("宝妈");
  if (hasAny(source, ["学生", "上学", "宿舍", "早八", "学校", "同学"])) tags.push("学生");
  if (hasAny(source, ["上班", "工位", "同事", "加班", "熬夜", "通勤"])) tags.push("上班族/年轻女");
  if (!tags.length) tags.push("普通");
  return tags;
}

function inferContentTags(task, text) {
  const source = String(text || "");
  const tags = [];
  if (hasAny(source, ["怎么样", "好不好", "适合吗", "能不能", "有没有", "请问", "问下"]) || /[吗嘛么]？?$/.test(source.trim())) tags.push("疑问托");
  if (hasAny(source, ["实拍", "晒图", "晒", "到了", "收到", "用了", "喝了", "好用", "不错"])) tags.push("反馈");
  if (hasAny(source, ["买了", "拍了", "下单", "订单", "付款", "入手"])) tags.push("订单/购买");
  if (task.type === "image") tags.push("图片");
  if (task.type === "sticker") tags.push("表情包");
  if (task.type === "video") tags.push("视频");
  if (!tags.length) tags.push("普通互动");
  return tags;
}

function hasAny(text, words) {
  return words.some((word) => text.includes(word));
}

function detectMediaExt(buffer, url = "") {
  if (/\.mp4(\?|$)/i.test(url)) return ".mp4";
  if (/\.mov(\?|$)/i.test(url)) return ".mov";
  if (/\.webm(\?|$)/i.test(url)) return ".webm";
  if (buffer.length >= 12 && buffer.slice(4, 8).toString("ascii") === "ftyp") return ".mp4";
  if (buffer.length >= 4 && buffer[0] === 0x1a && buffer[1] === 0x45 && buffer[2] === 0xdf && buffer[3] === 0xa3) return ".webm";
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return ".jpg";
  if (buffer.length >= 8 && buffer.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return ".png";
  if (buffer.length >= 6 && ["GIF87a", "GIF89a"].includes(buffer.slice(0, 6).toString("ascii"))) return ".gif";
  if (buffer.length >= 12 && buffer.slice(0, 4).toString("ascii") === "RIFF" && buffer.slice(8, 12).toString("ascii") === "WEBP") return ".webp";
  return ".png";
}

import fs from "node:fs/promises";
import path from "node:path";

export async function writeRunAudit(runDir, tasks, results, options = {}) {
  const audit = buildRunAudit(tasks, results, options);
  const textPath = path.join(runDir, "run-audit.txt");
  const csvPath = path.join(runDir, "run-audit.csv");
  await fs.writeFile(textPath, audit.text, "utf8");
  await fs.writeFile(csvPath, audit.csv, "utf8");
  printRunAuditSummary(audit, textPath);
}

export function buildRunAudit(tasks, results, options = {}) {
  const byIndex = new Map();
  for (const item of results || []) {
    const index = Number.isInteger(item?.index) ? item.index : findResultTaskIndex(tasks, item?.task);
    if (index >= 0 && !byIndex.has(index)) byIndex.set(index, item);
  }

  const rows = tasks.map((task, index) => {
    const item = byIndex.get(index);
    const result = item?.result || null;
    let status = "疑似漏定";
    if (result?.skippedCompleted) status = "之前已完成";
    else if (result?.skipped) status = "已跳过";
    else if (result?.ok) status = result.immediate ? "已创建-立即执行" : "已创建";
    else if (result) status = "失败";
    return {
      index,
      task,
      result,
      status,
      message: result?.message || ""
    };
  });

  const successRows = rows.filter((row) => row.status === "已创建" || row.status === "已创建-立即执行" || row.status === "之前已完成");
  const skippedRows = rows.filter((row) => row.status === "已跳过");
  const missingRows = rows.filter((row) => row.status === "疑似漏定" || row.status === "失败");
  const immediateRows = rows.filter((row) => row.status === "已创建-立即执行");
  const missingDoumaRows = missingRows.filter((row) => row.task?.role === "douma");

  const lines = [];
  lines.push("运行复查");
  lines.push(`生成时间：${new Date().toLocaleString()}`);
  if (options.error) lines.push(`本轮状态：中途失败 - ${options.error.message || options.error}`);
  else lines.push("本轮状态：已跑完");
  lines.push("");
  lines.push(`飞书预览任务：${tasks.length} 条`);
  lines.push(`已创建/之前已完成：${successRows.length} 条`);
  lines.push(`已跳过：${skippedRows.length} 条`);
  lines.push(`疑似漏定/失败：${missingRows.length} 条`);
  lines.push(`立即执行风险：${immediateRows.length} 条`);
  lines.push("");

  if (missingRows.length) {
    lines.push("需要你重点检查：");
    for (const row of missingRows) lines.push(`- ${formatAuditTask(row)}${row.message ? ` / ${row.message}` : ""}`);
    lines.push("");
  }
  if (missingDoumaRows.length) {
    lines.push("豆妈疑似漏定：");
    for (const row of missingDoumaRows) lines.push(`- ${formatAuditTask(row)}`);
    lines.push("");
  }
  if (immediateRows.length) {
    lines.push("被云中客改成立即执行的任务：");
    for (const row of immediateRows) lines.push(`- ${formatAuditTask(row)}`);
    lines.push("");
  }
  if (!missingRows.length && !immediateRows.length) {
    lines.push("复查结果：没有发现漏定或立即执行风险。");
    lines.push("");
  }

  lines.push("全部明细：");
  for (const row of rows) lines.push(`- ${row.status}：${formatAuditTask(row)}${row.message ? ` / ${row.message}` : ""}`);

  const csvRows = [
    ["序号", "状态", "角色", "说话人", "日期", "时间", "类型", "内容摘要", "结果信息"],
    ...rows.map((row) => [
      String(row.index + 1),
      row.status,
      row.task?.role || "",
      row.task?.speaker || "",
      row.task?.scheduleDateLabel || row.task?.scheduleDateKey || "今天",
      row.task?.time || "",
      row.task?.type || "",
      taskAuditSummary(row.task),
      row.message
    ])
  ];

  return {
    text: `${lines.join("\n")}\n`,
    csv: `${csvRows.map((row) => row.map(csvCell).join(",")).join("\n")}\n`,
    missingRows,
    missingDoumaRows,
    immediateRows,
    successRows,
    skippedRows
  };
}

function printRunAuditSummary(audit, textPath) {
  console.log(`\n运行复查已保存：${textPath}`);
  if (audit.missingRows.length || audit.immediateRows.length) {
    console.log(`复查提醒：疑似漏定/失败 ${audit.missingRows.length} 条，立即执行风险 ${audit.immediateRows.length} 条。`);
    if (audit.missingDoumaRows.length) console.log(`其中豆妈疑似漏定 ${audit.missingDoumaRows.length} 条。`);
  } else {
    console.log("复查通过：没有发现漏定或立即执行风险。");
  }
}

function findResultTaskIndex(tasks, resultTask) {
  if (!resultTask) return -1;
  return tasks.findIndex((task) =>
    task.role === resultTask.role &&
    task.speaker === resultTask.speaker &&
    task.time === resultTask.time &&
    task.type === resultTask.type &&
    (task.scheduleDateKey || "") === (resultTask.scheduleDateKey || "")
  );
}

function formatAuditTask(row) {
  const task = row.task || {};
  const date = task.scheduleDateLabel || task.scheduleDateKey || "今天";
  return `${row.index + 1}. ${task.role || ""} / ${task.speaker || ""} / ${date} ${task.time || ""} / ${task.type || ""} / ${taskAuditSummary(task)}`;
}

function taskAuditSummary(task) {
  if (!task) return "";
  if (task.text) return String(task.text).replace(/\s+/g, " ").trim().slice(0, 80);
  if (task.type === "sticker") return "表情包";
  if (task.type === "image") return "图片";
  if (task.type === "video") return "视频";
  return task.imagePath || task.assetUrl || "";
}

function csvCell(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

import fs from "node:fs/promises";
import http from "node:http";
import path from "node:path";

export async function reviewPreviewInBrowser(context, tasks, options = {}) {
  if (!Array.isArray(tasks) || !tasks.length) return { action: "continue", tasks };
  const rangeStartOmittedMedia = (options.rangeStartOmittedMedia || tasks.__rangeStartOmittedMedia || [])
    .map((item) => normalizeRangeStartOmittedMedia(item))
    .filter(Boolean);

  const state = {
    tasks: tasks.map((task, index) => ({
      ...task,
      __uiIndex: index + 1,
      __dateOffset: dateOffsetForTask(task),
      __initialDateOffset: dateOffsetForTask(task),
      __initialTime: normalizeTime(task.time),
      __selected: true,
      __skip: Boolean(task.__skip)
    })),
    rangeStartOmittedMedia,
    title: options.title || "发单预览确认",
    phase: options.phase || "预览",
    runDir: options.runDir || ""
  };

  let finish;
  const finished = new Promise((resolve) => {
    finish = resolve;
  });

  const server = http.createServer(async (req, res) => {
    try {
      if (req.method === "GET" && req.url === "/") {
        sendHtml(res, renderPage(state));
        return;
      }
      if (req.method === "GET" && req.url?.startsWith("/asset?")) {
        await sendAsset(req, res);
        return;
      }
      if (req.method === "POST" && req.url === "/finish") {
        const body = await readBody(req);
        const payload = JSON.parse(body || "{}");
        finish({
          action: payload.action || "continue",
          tasks: await normalizeEditedTasks(payload.tasks || [], state.runDir)
        });
        sendJson(res, { ok: true });
        return;
      }
      if (req.method === "POST" && req.url === "/draft") {
        const body = await readBody(req);
        const payload = JSON.parse(body || "{}");
        if (Array.isArray(payload.tasks)) {
          state.tasks = payload.tasks;
        }
        sendJson(res, { ok: true });
        return;
      }
      res.writeHead(404);
      res.end("Not found");
    } catch (error) {
      res.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
      res.end(error.message || String(error));
    }
  });

  await listen(server);
  const address = server.address();
  const url = `http://127.0.0.1:${address.port}/`;
  console.log(`\n已打开可视化预览页：${url}`);
  console.log("可以在页面里改时间、改文字、勾选不发；点“确认无误，开始发单”后才会继续创建任务。");

  let page = null;
  if (context?.newPage) {
    page = await context.newPage();
    await page.goto(url, { waitUntil: "domcontentloaded" });
  }

  const result = options.externalActionPromise
    ? await Promise.race([finished, options.externalActionPromise])
    : await finished;
  const keepPageOpen = result.action === "continue" && options.keepPageOpenAfterContinue === true;
  if (page && !page.isClosed() && !keepPageOpen) await page.close().catch(() => {});
  await closeServer(server);
  return result;
}

async function normalizeEditedTasks(tasks, runDir) {
  const output = [];
  for (const task of tasks.filter((item) => !item.__skip)) {
      const clean = { ...task };
      delete clean.__uiIndex;
      delete clean.__skip;
      delete clean.__selected;
      delete clean.__initialDateOffset;
      delete clean.__initialTime;
      delete clean.__manualAdded;
      delete clean.__rangeIncluded;
      applyScheduleDate(clean, clean.__dateOffset);
      delete clean.__dateOffset;
      clean.time = normalizeTime(clean.time);
      if (typeof clean.text === "string") clean.text = clean.text.trimEnd();
      await saveReplacementMedia(clean, runDir);
      delete clean.__replacementMediaDataUrl;
      delete clean.__replacementMediaName;
      output.push(clean);
  }
  return output;
}

function normalizeRangeStartOmittedMedia(item) {
  const task = item?.task || item;
  if (!task || !["image", "sticker", "video"].includes(task.type)) return null;
  return {
    reason: item.reason || "读取范围开始位置前有同说话人的图片/素材，可能属于当前第一条附近内容。",
    firstTask: item.firstTask || null,
    task: {
      ...task,
      __dateOffset: dateOffsetForTask(task),
      __initialDateOffset: dateOffsetForTask(task),
      __initialTime: normalizeTime(task.time),
      __selected: true,
      __skip: false
    }
  };
}

async function saveReplacementMedia(task, runDir) {
  if (!task?.__replacementMediaDataUrl) return;
  const match = String(task.__replacementMediaDataUrl).match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return;
  const ext = mediaExt(match[1], task.__replacementMediaName);
  const imagesDir = path.join(resolveRunDir(runDir, task), "images");
  await fs.mkdir(imagesDir, { recursive: true });
  const safeIndex = String(task.__uiIndex || Date.now()).replace(/\D+/g, "") || "media";
  const file = path.join(imagesDir, `manual_${Date.now()}_${safeIndex}${ext}`);
  await fs.writeFile(file, Buffer.from(match[2], "base64"));
  task.imagePath = file;
  task.assetUrl = "";
}

function mediaExt(mime, name = "") {
  const ext = path.extname(String(name || "")).toLowerCase();
  if ([".jpg", ".jpeg", ".png", ".gif", ".webp"].includes(ext)) return ext;
  if (mime === "image/jpeg") return ".jpg";
  if (mime === "image/gif") return ".gif";
  if (mime === "image/webp") return ".webp";
  return ".png";
}

function resolveRunDir(runDir, task) {
  if (runDir && path.isAbsolute(runDir)) return runDir;
  if (task?.imagePath && path.isAbsolute(task.imagePath)) {
    const dir = path.dirname(task.imagePath);
    return path.basename(dir).toLowerCase() === "images" ? path.dirname(dir) : dir;
  }
  return process.cwd();
}

function normalizeTime(value) {
  const raw = String(value || "").trim();
  const match = raw.match(/^(\d{1,2})[:：](\d{1,2})(?:[:：](\d{1,2}))?$/);
  if (!match) return raw;
  return `${match[1].padStart(2, "0")}:${match[2].padStart(2, "0")}:${(match[3] || "00").padStart(2, "0")}`;
}

function dateOffsetForTask(task) {
  if (Number.isFinite(Number(task?.scheduleDateOffset))) return Number(task.scheduleDateOffset);
  const key = String(task?.scheduleDateKey || "").trim();
  if (!key || key === "today") return 0;
  const match = key.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return 0;
  const today = new Date();
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const targetStart = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3])).getTime();
  return Math.round((targetStart - todayStart) / 86400000);
}

function applyScheduleDate(task, offsetValue) {
  const offset = Number.isFinite(Number(offsetValue)) ? Number(offsetValue) : 0;
  task.scheduleDateOffset = offset;
  if (offset === 0) {
    task.scheduleDateKey = "today";
    task.scheduleDateLabel = "";
    return;
  }
  const date = new Date();
  date.setDate(date.getDate() + offset);
  task.scheduleDateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  task.scheduleDateLabel = `${date.getMonth() + 1}/${date.getDate()}`;
}

function dateSelectHtml(selectedOffset) {
  const selected = Number.isFinite(Number(selectedOffset)) ? Number(selectedOffset) : 0;
  const offsets = new Set([0, 1, 2, 3, 4, 5, 6, 7, selected]);
  return [...offsets]
    .sort((a, b) => a - b)
    .map((offset) => `<option value="${offset}"${offset === selected ? " selected" : ""}>${escapeHtml(dateOptionLabel(offset))}</option>`)
    .join("");
}

function dateOptionLabel(offset) {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  const day = date.getDate();
  if (offset === 0) return `今天(${day}号)`;
  if (offset === 1) return `明天(${day}号)`;
  if (offset === 2) return `后天(${day}号)`;
  if (offset > 0) return `+${offset}天(${day}号)`;
  return `${offset}天(${day}号)`;
}

function renderPage(state) {
  const json = escapeScriptJson(JSON.stringify(state.tasks));
  const rangeWarningJson = escapeScriptJson(JSON.stringify(state.rangeStartOmittedMedia || []));
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${escapeHtml(state.title)}</title>
  <style>
    body { margin: 0; font-family: "Microsoft YaHei", Arial, sans-serif; color: #172033; background: #f5f7fb; }
    header { position: sticky; top: 0; z-index: 5; padding: 14px 18px; background: #fff; border-bottom: 1px solid #dde3ee; display: flex; gap: 12px; align-items: center; }
    h1 { margin: 0; font-size: 18px; }
    .summary { color: #5b667a; font-size: 13px; }
    .actions { margin-left: auto; display: flex; gap: 8px; }
    button { border: 1px solid #2f7df6; background: #2f7df6; color: #fff; border-radius: 6px; padding: 8px 12px; cursor: pointer; font-size: 14px; }
    button.secondary { background: #fff; color: #2f7df6; }
    button.danger { border-color: #e35252; background: #fff; color: #d72f2f; }
    main { padding: 14px 18px 26px; }
    .bulkbar { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-bottom: 10px; padding: 10px; background: #fff; border: 1px solid #dde3ee; border-radius: 8px; }
    .bulkbar .label { color: #4b5870; font-size: 13px; }
    .bulkbar button, .bulkbar select, .bulkbar input { width: auto; }
    .bulkbar input.small { width: 74px; }
    table { width: 100%; border-collapse: collapse; background: #fff; table-layout: fixed; }
    th, td { border-bottom: 1px solid #e8edf5; padding: 8px; vertical-align: top; font-size: 13px; }
    th { position: sticky; top: 61px; z-index: 4; background: #f8faff; color: #4b5870; text-align: left; }
    .select { width: 48px; text-align: center; }
    .idx { width: 44px; color: #6a7280; }
    .role { width: 86px; }
    .speaker { width: 130px; }
    .date { width: 120px; }
    .time { width: 118px; }
    .type { width: 78px; }
    .skip { width: 74px; text-align: center; }
    input, select, textarea { width: 100%; box-sizing: border-box; border: 1px solid #ccd6e5; border-radius: 5px; padding: 6px; font: inherit; background: #fff; }
    textarea { min-height: 54px; resize: vertical; line-height: 1.45; }
    .muted { color: #8792a5; font-size: 12px; margin-top: 4px; word-break: break-all; }
    .media { display: flex; gap: 10px; align-items: flex-start; }
    .media img { max-width: 110px; max-height: 140px; object-fit: contain; border: 1px solid #e2e8f0; border-radius: 4px; background: #fafafa; }
    .media-body { flex: 1; min-width: 0; }
    .media-tools { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin: 6px 0; }
    .range-warning { margin-bottom: 10px; padding: 12px; border: 1px solid #f7c56b; border-radius: 8px; background: #fffaf0; color: #7a4600; line-height: 1.6; }
    .range-warning .warning-actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 8px; }
    button.small { padding: 5px 8px; font-size: 12px; }
    .pill { display: inline-block; padding: 2px 7px; border-radius: 999px; background: #eef4ff; color: #2459b2; }
    tr.skipped { opacity: 0.45; background: #fff7f7; }
    .dialog-backdrop { position: fixed; inset: 0; z-index: 20; background: rgba(15, 23, 42, 0.32); display: flex; align-items: center; justify-content: center; padding: 18px; }
    .dialog-card { width: min(560px, 100%); max-height: calc(100vh - 36px); overflow: auto; background: #fff; border-radius: 8px; box-shadow: 0 18px 48px rgba(15, 23, 42, 0.22); border: 1px solid #dbe4f0; }
    .dialog-head { padding: 14px 16px; border-bottom: 1px solid #e6ecf5; font-weight: 700; }
    .dialog-body { padding: 14px 16px; display: grid; gap: 10px; line-height: 1.6; }
    .dialog-body label { display: grid; gap: 5px; color: #344256; font-size: 13px; }
    .dialog-body .dialog-media { max-width: 160px; max-height: 180px; object-fit: contain; border: 1px solid #e2e8f0; border-radius: 4px; background: #fafafa; }
    .dialog-error { color: #d72f2f; min-height: 18px; font-size: 13px; }
    .dialog-actions { padding: 12px 16px; border-top: 1px solid #e6ecf5; display: flex; justify-content: flex-end; gap: 8px; }
    .jump-actions { position: fixed; right: 18px; bottom: 18px; z-index: 10; display: grid; gap: 8px; opacity: 0.25; transition: opacity 0.16s ease; }
    .jump-actions:hover { opacity: 1; }
    .jump-actions button { width: 34px; height: 34px; padding: 0; border-radius: 999px; border-color: #b8c8e6; background: rgba(255, 255, 255, 0.88); color: #2f5fbd; box-shadow: 0 8px 20px rgba(15, 23, 42, 0.12); font-size: 18px; line-height: 1; }
    .jump-actions button:hover { background: #2f7df6; border-color: #2f7df6; color: #fff; }
    .toast { position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); z-index: 25; max-width: min(560px, calc(100vw - 36px)); padding: 10px 14px; border-radius: 8px; background: #172033; color: #fff; box-shadow: 0 12px 32px rgba(15, 23, 42, 0.22); }
    .hidden { display: none !important; }
  </style>
</head>
<body>
  <header>
    <div>
      <h1>${escapeHtml(state.title)}</h1>
      <div class="summary">${escapeHtml(state.phase)} · 共 <span id="total"></span> 条，已勾选不发 <span id="skip-count"></span> 条</div>
    </div>
    <div class="actions">
      <button class="secondary" id="insert-task-top">手动补一条</button>
      <button class="secondary" id="refresh">重新生成预览</button>
      <button class="secondary" id="settings">返回修改设置</button>
      <button class="danger" id="cancel">暂不发，回到监控</button>
      <button id="save">确认无误，开始发单</button>
    </div>
  </header>
  <main>
    <div class="range-warning hidden" id="range-warning">
      <strong>预览自检提醒</strong>
      <div id="range-warning-text"></div>
      <div class="warning-actions">
        <button class="secondary" id="include-range-media">带入这张图片</button>
        <button class="secondary" id="ignore-range-media">忽略，继续检查当前预览</button>
      </div>
    </div>
    <div class="bulkbar">
      <span class="label">批量修改：已选 <b id="selected-count"></b> 条</span>
      <button class="secondary" id="select-all">全选</button>
      <button class="secondary" id="select-none">全不选</button>
      <span class="label">日期</span>
      <select id="bulk-date"></select>
      <button class="secondary" id="apply-date">应用日期</button>
      <span class="label">时间</span>
      <select id="bulk-time-mode">
        <option value="delay">整体延后</option>
        <option value="advance">整体提前</option>
        <option value="set">统一设为</option>
      </select>
      <input class="small" id="bulk-time-value" value="5" />
      <select id="bulk-time-unit">
        <option value="minute">分钟</option>
        <option value="second">秒</option>
        <option value="hour">小时</option>
      </select>
      <button class="secondary" id="apply-time">应用时间</button>
      <button class="secondary" id="restore-time">恢复选中行时间</button>
      <span class="label">查看方式</span>
      <select id="view-mode">
        <option value="safe">文档顺序</option>
        <option value="time">时间顺序检查</option>
      </select>
      <span class="muted" id="view-mode-tip"></span>
    </div>
    <table>
      <thead>
        <tr>
          <th class="select">批量</th>
          <th class="idx">序号</th>
          <th class="role">角色</th>
          <th class="speaker">说话人</th>
          <th class="date">日期</th>
          <th class="time">时间</th>
          <th class="type">类型</th>
          <th>内容/素材</th>
          <th class="skip">不发</th>
        </tr>
      </thead>
      <tbody id="rows"></tbody>
    </table>
    <div class="dialog-backdrop hidden" id="preview-dialog">
      <div class="dialog-card" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
        <div class="dialog-head" id="dialog-title"></div>
        <div class="dialog-body" id="dialog-body"></div>
        <div class="dialog-actions">
          <button class="secondary" id="dialog-cancel" type="button">取消</button>
          <button id="dialog-confirm" type="button">确定</button>
        </div>
      </div>
    </div>
    <div class="jump-actions">
      <button class="secondary" id="jump-top" type="button" title="到顶部" aria-label="到顶部">↑</button>
      <button class="secondary" id="jump-bottom" type="button" title="到底部" aria-label="到底部">↓</button>
    </div>
    <div class="toast hidden" id="toast"></div>
  </main>
  <script id="task-data" type="application/json">${json}</script>
  <script id="range-warning-data" type="application/json">${rangeWarningJson}</script>
  <script>
    const tasks = JSON.parse(document.getElementById("task-data").textContent);
    const rangeStartOmittedMedia = JSON.parse(document.getElementById("range-warning-data").textContent);
    const rows = document.getElementById("rows");
    const total = document.getElementById("total");
    const skipCount = document.getElementById("skip-count");
    const selectedCount = document.getElementById("selected-count");
    const bulkDate = document.getElementById("bulk-date");
    const bulkTimeMode = document.getElementById("bulk-time-mode");
    const bulkTimeValue = document.getElementById("bulk-time-value");
    const bulkTimeUnit = document.getElementById("bulk-time-unit");
    const viewMode = document.getElementById("view-mode");
    const viewModeTip = document.getElementById("view-mode-tip");
    const rangeWarning = document.getElementById("range-warning");
    const rangeWarningText = document.getElementById("range-warning-text");
    const previewDialog = document.getElementById("preview-dialog");
    const dialogTitle = document.getElementById("dialog-title");
    const dialogBody = document.getElementById("dialog-body");
    const dialogCancel = document.getElementById("dialog-cancel");
    const dialogConfirm = document.getElementById("dialog-confirm");
    const toast = document.getElementById("toast");
    let activeDialogConfirm = null;
    let toastTimer = null;
    let dirty = false;
    let draftTimer = null;

    function normalizeRole(role) {
      return role === "douma" ? "douma" : "tuo";
    }

    function labelRole(role) {
      return normalizeRole(role) === "douma" ? "豆妈" : "托";
    }

    function roleSelectHtml(role) {
      const selected = normalizeRole(role);
      return [
        ["douma", "豆妈"],
        ["tuo", "托"]
      ].map(([value, label]) => (
        '<option value="' + value + '"' + (value === selected ? " selected" : "") + '>' + label + '</option>'
      )).join("");
    }

    function defaultSpeakerForRole(role) {
      return normalizeRole(role) === "douma" ? "豆妈" : "托";
    }

    function showToast(message) {
      toast.textContent = message;
      toast.classList.remove("hidden");
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        toast.classList.add("hidden");
      }, 2600);
    }

    function markDirty() {
      dirty = true;
      scheduleDraftSave();
    }

    function scheduleDraftSave() {
      clearTimeout(draftTimer);
      draftTimer = setTimeout(saveDraft, 350);
    }

    async function saveDraft() {
      try {
        await fetch("/draft", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ tasks: safeOrderTasks() })
        });
      } catch (_) {}
    }

    function showDialogError(message) {
      const error = document.getElementById("dialog-error");
      if (error) error.textContent = message || "";
    }

    function closeDialog() {
      activeDialogConfirm = null;
      previewDialog.classList.add("hidden");
      dialogBody.innerHTML = "";
      dialogTitle.textContent = "";
    }

    function openDialog({ title, bodyHtml, confirmText = "确定", cancelText = "取消", onConfirm }) {
      dialogTitle.textContent = title || "确认操作";
      dialogBody.innerHTML = bodyHtml + '<div class="dialog-error" id="dialog-error"></div>';
      dialogCancel.textContent = cancelText;
      dialogConfirm.textContent = confirmText;
      activeDialogConfirm = typeof onConfirm === "function" ? onConfirm : null;
      previewDialog.classList.remove("hidden");
      const firstInput = dialogBody.querySelector("input, textarea, select, button");
      if (firstInput) setTimeout(() => firstInput.focus(), 0);
    }

    function bindClick(id, handler) {
      const element = document.getElementById(id);
      if (!element) return;
      element.onclick = (event) => {
        event.preventDefault();
        handler(event);
      };
    }

    function shouldResetSpeakerForRole(task, previousRole, nextRole) {
      const speaker = String(task.speaker || "").trim();
      if (!speaker) return true;
      if (previousRole === "douma" && nextRole === "tuo") return speaker.includes("豆妈");
      if (previousRole === "tuo" && nextRole === "douma") return /^托\\d*$/.test(speaker) || speaker === "托";
      return false;
    }

    function typeLabel(type) {
      if (type === "image") return "图片";
      if (type === "sticker") return "表情包";
      if (type === "video") return "视频";
      return "文字";
    }

    function mediaLabel(type) {
      if (type === "sticker") return "表情包";
      if (type === "video") return "视频";
      return "图片";
    }

    function typeSelectHtml(selectedType) {
      const selected = selectedType || "text";
      return [
        ["text", "文字"],
        ["image", "图片"],
        ["sticker", "表情包"],
        ["video", "视频"]
      ].map(([value, label]) => (
        '<option value="' + value + '"' + (value === selected ? " selected" : "") + '>' + label + '</option>'
      )).join("");
    }

    function assetUrl(path) {
      return "/asset?path=" + encodeURIComponent(path);
    }

    function dateSelectHtml(selectedOffset) {
      const selected = Number.isFinite(Number(selectedOffset)) ? Number(selectedOffset) : 0;
      const offsets = Array.from(new Set([0, 1, 2, 3, 4, 5, 6, 7, selected])).sort((a, b) => a - b);
      return offsets.map((offset) => (
        '<option value="' + offset + '"' + (offset === selected ? " selected" : "") + '>' + escapeHtml(dateOptionLabel(offset)) + '</option>'
      )).join("");
    }

    function dateOptionLabel(offset) {
      const date = new Date();
      date.setDate(date.getDate() + offset);
      const day = date.getDate();
      if (offset === 0) return '今天(' + day + '号)';
      if (offset === 1) return '明天(' + day + '号)';
      if (offset === 2) return '后天(' + day + '号)';
      if (offset > 0) return '+' + offset + '天(' + day + '号)';
      return offset + '天(' + day + '号)';
    }

    function selectedTasks() {
      return tasks.filter((task) => task.__selected && !task.__skip);
    }

    function renumberTasks() {
      tasks.forEach((task, index) => {
        task.__uiIndex = index + 1;
      });
    }

    function safeOrderTasks() {
      return groupInteractiveTuoTasksForSafeOrder([...tasks].sort((a, b) => Number(a.__uiIndex || 0) - Number(b.__uiIndex || 0)));
    }

    function interactiveTuoKey(task) {
      if (normalizeRole(task.role) !== "tuo") return "";
      if (task.interactiveTuo !== true && task.continueSpeaker !== true) return "";
      if (task.robotGroup !== undefined && task.robotGroup !== null && String(task.robotGroup).trim()) {
        return "robot:" + String(task.robotGroup).trim();
      }
      if (task.interactionGroup !== undefined && task.interactionGroup !== null && String(task.interactionGroup).trim()) {
        return "interaction:" + String(task.interactionGroup).trim();
      }
      const speaker = String(task.speaker || "").replace(/\\s+/g, "").trim();
      return speaker ? "speaker:" + speaker : "";
    }

    function groupInteractiveTuoTasksForSafeOrder(items) {
      const used = new Set();
      const grouped = [];
      for (let index = 0; index < items.length; index += 1) {
        if (used.has(index)) continue;
        const task = items[index];
        grouped.push(task);
        used.add(index);
        const key = interactiveTuoKey(task);
        if (!key) continue;
        for (let nextIndex = index + 1; nextIndex < items.length; nextIndex += 1) {
          if (used.has(nextIndex)) continue;
          if (interactiveTuoKey(items[nextIndex]) !== key) continue;
          grouped.push(items[nextIndex]);
          used.add(nextIndex);
        }
      }
      return grouped;
    }

    function timeToSeconds(value) {
      const match = String(value || "").trim().match(/^(\\d{1,2})[:：](\\d{1,2})(?:[:：](\\d{1,2}))?$/);
      if (!match) return null;
      return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0);
    }

    function secondsToTime(value) {
      const seconds = Math.max(0, Math.floor(value));
      const hour = Math.floor(seconds / 3600) % 24;
      const minute = Math.floor((seconds % 3600) / 60);
      const second = seconds % 60;
      return String(hour).padStart(2, "0") + ":" + String(minute).padStart(2, "0") + ":" + String(second).padStart(2, "0");
    }

    function normalizeTimeClient(value) {
      const seconds = timeToSeconds(value);
      return seconds == null ? null : secondsToTime(seconds);
    }

    function absoluteSeconds(task) {
      const seconds = timeToSeconds(task.time);
      if (seconds == null) return null;
      const day = Number.isFinite(Number(task.__dateOffset)) ? Number(task.__dateOffset) : 0;
      return day * 86400 + seconds;
    }

    function sortSeconds(task) {
      const seconds = absoluteSeconds(task);
      return seconds == null ? Number.MAX_SAFE_INTEGER : seconds;
    }

    function displayedTasks() {
      const safe = safeOrderTasks();
      if (viewMode.value !== "time") return safe;
      return [...safe].sort((a, b) => {
        const byTime = sortSeconds(a) - sortSeconds(b);
        if (byTime !== 0) return byTime;
        return Number(a.__uiIndex || 0) - Number(b.__uiIndex || 0);
      });
    }

    function updateViewModeTip() {
      viewModeTip.textContent = viewMode.value === "time"
        ? "时间顺序仅用于检查，可直接修改；开始发单时会自动按安全创建顺序提交。"
        : "当前按安全创建顺序显示；同编号托会放在一起，时间不变。";
    }

    function setAbsoluteSeconds(task, value) {
      const next = Math.max(0, Math.floor(value));
      task.__dateOffset = Math.floor(next / 86400);
      task.time = secondsToTime(next % 86400);
    }

    function isRoleSwitch(previous, current) {
      return normalizeRole(previous.role) !== normalizeRole(current.role);
    }

    function compactTextLength(task) {
      return String(task.text || "").replace(/\\s+/g, "").length;
    }

    function defaultGapSeconds(previous, current) {
      if (previous && current && isRoleSwitch(previous, current)) return 120;
      if (current && (current.type === "image" || current.type === "sticker" || current.type === "video")) return 30;
      const length = compactTextLength(current || {});
      if (length > 60) return 45;
      if (length > 20) return 30;
      return 20;
    }

    function selectedRowIndexes() {
      const indexes = [];
      tasks.forEach((task, index) => {
        if (task.__selected && !task.__skip) indexes.push(index);
      });
      return indexes;
    }

    function defaultInsertAfterIndex() {
      const picked = selectedRowIndexes();
      if (picked.length === 1) return picked[0] + 1;
      return tasks.length;
    }

    function askInsertIndex() {
      const defaultAfter = defaultInsertAfterIndex();
      const value = prompt("要插在哪一条后面？输入序号，填 0 表示插到最前面。", String(defaultAfter));
      if (value == null) return null;
      const after = Number(String(value).trim());
      if (!Number.isInteger(after) || after < 0 || after > tasks.length) {
        alert("插入位置要填 0 到 " + tasks.length + " 之间的数字。");
        return null;
      }
      return after;
    }

    function copyTaskForDraft(task) {
      return { ...task };
    }

    function buildManualTask(insertIndex, text, time) {
      const previous = tasks[insertIndex - 1] || {};
      const next = tasks[insertIndex] || {};
      const role = normalizeRole(previous.role || next.role || "tuo");
      const speaker = String(previous.speaker || next.speaker || defaultSpeakerForRole(role)).trim() || defaultSpeakerForRole(role);
      const dateOffset = Number.isFinite(Number(previous.__dateOffset))
        ? Number(previous.__dateOffset)
        : (Number.isFinite(Number(next.__dateOffset)) ? Number(next.__dateOffset) : 0);
      const base = {
        role,
        speaker,
        type: "text",
        text,
        time,
        originalTime: "手动补入",
        __dateOffset: dateOffset,
        __initialDateOffset: dateOffset,
        __initialTime: time,
        __selected: true,
        __skip: false,
        __manualAdded: true
      };
      if (previous.robotGroup) base.robotGroup = previous.robotGroup;
      if (previous.interactionGroup) base.interactionGroup = previous.interactionGroup;
      return base;
    }

    function defaultManualTime(insertIndex, draftText) {
      const previous = tasks[insertIndex - 1];
      const next = tasks[insertIndex];
      if (previous) {
        const base = absoluteSeconds(previous);
        if (base != null) {
          return secondsToTime((base + defaultGapSeconds(previous, { role: previous.role, type: "text", text: draftText })) % 86400);
        }
      }
      return normalizeTimeClient(next && next.time) || "09:00:00";
    }

    function shiftDraftAfterInsert(draft, insertIndex) {
      const changes = [];
      const inserted = draft[insertIndex];
      const insertedAbs = absoluteSeconds(inserted);
      const shiftSeconds = defaultGapSeconds(inserted, draft[insertIndex + 1] || inserted);
      for (let index = insertIndex + 1; index < draft.length; index += 1) {
        const previous = draft[index - 1];
        const current = draft[index];
        const previousAbs = absoluteSeconds(previous);
        const currentAbs = absoluteSeconds(current);
        if (previousAbs == null || currentAbs == null) continue;
        let nextAbs = currentAbs;
        if (insertedAbs != null && shiftSeconds > 0) {
          nextAbs += shiftSeconds;
        }
        const minimum = previousAbs + defaultGapSeconds(previous, current);
        nextAbs = Math.max(nextAbs, minimum);
        if (nextAbs !== currentAbs) {
          const before = current.time;
          setAbsoluteSeconds(current, nextAbs);
          changes.push({
            index: index + 1,
            before,
            after: current.time
          });
        }
      }
      return changes;
    }

    function confirmInsert(insertIndex, task, changes) {
      const lines = [
        "将补入 1 条：第 " + (insertIndex + 1) + " 条，" + labelRole(task.role) + "「" + task.speaker + "」，时间 " + task.time + "。",
        "会按默认间隔顺延后面 " + changes.length + " 条。"
      ];
      if (changes.length) {
        lines.push("");
        lines.push("示例变化：");
        changes.slice(0, 6).forEach((change) => {
          lines.push("第 " + change.index + " 条：" + change.before + " -> " + change.after);
        });
        if (changes.length > 6) lines.push("还有 " + (changes.length - 6) + " 条也会顺延。");
      }
      lines.push("");
      lines.push("点确定才修改；点取消不会动当前预览。");
      return confirm(lines.join("\\n"));
    }

    function insertSummaryHtml(insertIndex, task, changes) {
      const items = changes.slice(0, 6).map((change) =>
        '<div>第 ' + change.index + ' 条：' + escapeHtml(change.before) + ' -&gt; ' + escapeHtml(change.after) + '</div>'
      ).join("");
      return [
        '<div>将补入 1 条：第 ' + (insertIndex + 1) + ' 条，' + escapeHtml(labelRole(task.role)) + '「' + escapeHtml(task.speaker) + '」，时间 ' + escapeHtml(task.time) + '。</div>',
        '<div>会按默认间隔顺延后面 ' + changes.length + ' 条。</div>',
        changes.length ? '<div><strong>示例变化：</strong>' + items + (changes.length > 6 ? '<div>还有 ' + (changes.length - 6) + ' 条也会顺延。</div>' : '') + '</div>' : '',
        '<div class="muted">点确定才修改；点取消不会动当前预览。</div>'
      ].join("");
    }

    function insertManualTask() {
      const defaultAfter = defaultInsertAfterIndex();
      openDialog({
        title: "手动补一条",
        confirmText: "下一步",
        bodyHtml:
          '<label>插入位置<input id="manual-insert-index" value="' + defaultAfter + '" /></label>' +
          '<div class="muted">填 0 表示插到最前面；当前最多可填 ' + tasks.length + '。</div>' +
          '<label>补入内容<textarea id="manual-insert-text" rows="4" placeholder="请输入要补的文字内容"></textarea></label>' +
          '<label>这条时间<input id="manual-insert-time" value="' + escapeAttr(defaultManualTime(defaultAfter, "")) + '" placeholder="例如 10:01 或 10:01:30" /></label>',
        onConfirm: () => {
          const insertIndex = Number(String(document.getElementById("manual-insert-index").value || "").trim());
          if (!Number.isInteger(insertIndex) || insertIndex < 0 || insertIndex > tasks.length) {
            showDialogError("插入位置要填 0 到 " + tasks.length + " 之间的数字。");
            return false;
          }
          const cleanText = String(document.getElementById("manual-insert-text").value || "").trimEnd();
          if (!cleanText.trim()) {
            showDialogError("补入内容不能为空。");
            return false;
          }
          const time = normalizeTimeClient(document.getElementById("manual-insert-time").value);
          if (!time) {
            showDialogError("时间格式不对，请按 10:01 或 10:01:30 这样填写。");
            return false;
          }
          const task = buildManualTask(insertIndex, cleanText, time);
          const draft = tasks.map(copyTaskForDraft);
          draft.splice(insertIndex, 0, task);
          const changes = shiftDraftAfterInsert(draft, insertIndex);
          openDialog({
            title: "确认补入",
            confirmText: "确定补入",
            bodyHtml: insertSummaryHtml(insertIndex, task, changes),
            onConfirm: () => {
              tasks.splice(0, tasks.length, ...draft);
              markDirty();
              render();
              showToast("已补入 1 条，并按默认间隔处理后面时间。");
            }
          });
          return false;
        }
      });
    }

    function initBulkDate() {
      const first = tasks.find((task) => !task.__skip) || tasks[0] || {};
      bulkDate.innerHTML = dateSelectHtml(first.__dateOffset || 0);
    }

    function render() {
      renumberTasks();
      updateViewModeTip();
      renderRangeWarning();
      rows.innerHTML = "";
      for (const task of displayedTasks()) {
        const tr = document.createElement("tr");
        if (task.__skip) tr.classList.add("skipped");
        const isMedia = task.type === "image" || task.type === "sticker" || task.type === "video";
        const mediaPreview = task.__replacementMediaDataUrl
          ? '<img src="' + task.__replacementMediaDataUrl + '" />'
          : (task.imagePath ? '<img src="' + assetUrl(task.imagePath) + '" />' : '');
        const contentHtml = isMedia
          ? '<div class="media">' +
              mediaPreview +
              '<div class="media-body"><span class="pill">' + typeLabel(task.type) + '</span>' +
              '<div class="media-tools">' +
                '<button type="button" class="secondary small" data-action="pick-media">更换素材</button>' +
                '<input type="file" class="media-input" accept="image/*" hidden>' +
                '<span class="muted">可换图片/表情包素材</span>' +
              '</div>' +
              '<div class="muted">' + escapeHtml(task.__replacementMediaName ? ("已换：" + task.__replacementMediaName) : (task.imagePath || task.assetUrl || "没有本地素材")) + '</div>' +
              (task.text ? '<textarea data-field="text">' + escapeHtml(task.text) + '</textarea>' : '') +
              '</div></div>'
          : '<textarea data-field="text">' + escapeHtml(task.text || "") + '</textarea>';
        tr.innerHTML =
          '<td class="select"><input type="checkbox" data-field="__selected" ' + (task.__selected ? "checked" : "") + '></td>' +
          '<td class="idx">' + task.__uiIndex + '</td>' +
          '<td class="role"><select data-field="role">' + roleSelectHtml(task.role) + '</select></td>' +
          '<td class="speaker"><input data-field="speaker" value="' + escapeAttr(task.speaker || "") + '"></td>' +
          '<td class="date"><select data-field="__dateOffset">' + dateSelectHtml(task.__dateOffset) + '</select><div class="muted">原日期：' + escapeHtml(task.originalScheduleDateLabel || task.scheduleDateLabel || task.scheduleDateKey || "今天") + '</div></td>' +
          '<td class="time"><input data-field="time" value="' + escapeAttr(task.time || "") + '"><div class="muted">原时间：' + escapeHtml(task.originalTime || "-") + '</div></td>' +
          '<td class="type"><select data-field="type">' + typeSelectHtml(task.type) + '</select></td>' +
          '<td>' + contentHtml + '</td>' +
          '<td class="skip"><input type="checkbox" data-field="__skip" ' + (task.__skip ? "checked" : "") + '></td>';
        tr.querySelectorAll("[data-field]").forEach((el) => {
          el.addEventListener("input", () => {
            const field = el.dataset.field;
            if (field === "role") return;
            task[field] = el.type === "checkbox" ? el.checked : el.value;
            tr.classList.toggle("skipped", Boolean(task.__skip));
            markDirty();
            updateSummary();
          });
          el.addEventListener("change", () => {
            const field = el.dataset.field;
            if (field === "role") {
              const previousRole = normalizeRole(task.role);
              const nextRole = normalizeRole(el.value);
              task.role = nextRole;
              if (previousRole !== nextRole && shouldResetSpeakerForRole(task, previousRole, nextRole)) {
                task.speaker = defaultSpeakerForRole(nextRole);
              }
              markDirty();
              render();
              return;
            }
            task[field] = el.type === "checkbox" ? el.checked : el.value;
            tr.classList.toggle("skipped", Boolean(task.__skip));
            markDirty();
            if (field === "type") render();
            else if (viewMode.value === "time" && (field === "time" || field === "__dateOffset")) render();
            updateSummary();
          });
        });
        const pickButton = tr.querySelector('[data-action="pick-media"]');
        const mediaInput = tr.querySelector(".media-input");
        if (pickButton && mediaInput) {
          pickButton.addEventListener("click", () => mediaInput.click());
          mediaInput.addEventListener("change", () => {
            const file = mediaInput.files && mediaInput.files[0];
            if (!file) return;
            if (!file.type.startsWith("image/")) {
              alert("目前只支持替换图片/表情包素材。");
              mediaInput.value = "";
              return;
            }
            const reader = new FileReader();
            reader.onload = () => {
              task.__replacementMediaDataUrl = String(reader.result || "");
              task.__replacementMediaName = file.name || "素材";
              if (task.type !== "sticker") task.type = "image";
              markDirty();
              render();
            };
            reader.readAsDataURL(file);
          });
        }
        rows.appendChild(tr);
      }
      updateSummary();
    }

    function updateSummary() {
      total.textContent = tasks.length;
      skipCount.textContent = tasks.filter((t) => t.__skip).length;
      selectedCount.textContent = selectedTasks().length;
    }

    function pendingRangeWarnings() {
      return rangeStartOmittedMedia.filter((item) => !item.__included && !item.__ignored);
    }

    function renderRangeWarning() {
      const item = pendingRangeWarnings()[0];
      rangeWarning.classList.toggle("hidden", !item);
      if (!item) return;
      const task = item.task || {};
      const first = item.firstTask || {};
      const firstText = first.text ? " " + String(first.text).slice(0, 28) : "";
      rangeWarningText.textContent =
        "检测到读取范围开始位置前，有 1 个同说话人的" + mediaLabel(task.type) + "没有带入。可能属于：" +
        (task.speaker || "-") + " " + (task.time || "-") +
        "；当前第一条：" + (first.speaker || "-") + " " + (first.time || "-") + firstText;
    }

    function prepareIncludedRangeTask(task) {
      const next = {
        ...task,
        __selected: true,
        __skip: false,
        __rangeIncluded: true,
        __dateOffset: Number.isFinite(Number(task.__dateOffset)) ? Number(task.__dateOffset) : 0,
        __initialDateOffset: Number.isFinite(Number(task.__initialDateOffset)) ? Number(task.__initialDateOffset) : 0,
        __initialTime: task.__initialTime || task.time || ""
      };
      return next;
    }

    function includeRangeMedia() {
      const item = pendingRangeWarnings()[0];
      if (!item) return;
      const candidate = item.task || {};
      const duplicate = tasks.some((task) =>
        task.type === candidate.type &&
        task.speaker === candidate.speaker &&
        task.time === candidate.time &&
        ((candidate.imagePath && task.imagePath === candidate.imagePath) || (candidate.assetUrl && task.assetUrl === candidate.assetUrl))
      );
      if (duplicate) {
        item.__included = true;
        render();
        showToast("这张素材已经在当前预览里了。");
        return;
      }
      const previewHtml = candidate.imagePath
        ? '<img class="dialog-media" src="' + assetUrl(candidate.imagePath) + '" />'
        : '';
      openDialog({
        title: "带入这张" + mediaLabel(candidate.type),
        confirmText: "带入当前预览",
        bodyHtml: [
          previewHtml,
          '<div>将把范围开始位置前的这张' + mediaLabel(candidate.type) + '放到当前预览最前面。</div>',
          '<div>说话人：' + escapeHtml(candidate.speaker || "-") + '</div>',
          '<div>时间：' + escapeHtml(candidate.time || "-") + '</div>',
          '<div class="muted">带入后仍可在表格里修改时间，或勾选“不发”。</div>'
        ].join(""),
        onConfirm: () => {
          tasks.unshift(prepareIncludedRangeTask(candidate));
          item.__included = true;
          markDirty();
          render();
          showToast("已带入这张" + mediaLabel(candidate.type) + "。");
        }
      });
    }

    function ignoreRangeMedia() {
      const item = pendingRangeWarnings()[0];
      if (!item) return;
      item.__ignored = true;
      markDirty();
      renderRangeWarning();
      showToast("已忽略这条自检提醒。");
    }

    async function finish(action) {
      if (action === "refresh" && dirty && !confirm("当前预览有手动修改，重新生成会覆盖这些修改。确定重新生成吗？")) return;
      renumberTasks();
      await saveDraft();
      await fetch("/finish", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action, tasks: safeOrderTasks() })
      });
      const message = action === "settings"
        ? "正在返回上一页修改设置，请稍等。"
        : "已保存，可以回到黑色窗口查看后续进度。";
      document.body.innerHTML = '<main><h1>' + message + '</h1></main>';
    }

    bindClick("save", () => finish("continue"));
    bindClick("refresh", () => finish("refresh"));
    bindClick("settings", () => finish("settings"));
    bindClick("cancel", () => finish("monitor"));
    bindClick("select-all", () => {
      tasks.forEach((task) => {
        if (!task.__skip) task.__selected = true;
      });
      markDirty();
      render();
    });
    bindClick("select-none", () => {
      tasks.forEach((task) => {
        task.__selected = false;
      });
      markDirty();
      render();
    });
    bindClick("apply-date", () => {
      const offset = Number(bulkDate.value || 0);
      selectedTasks().forEach((task) => {
        task.__dateOffset = offset;
      });
      markDirty();
      render();
    });
    bindClick("apply-time", () => {
      const picked = selectedTasks();
      const mode = bulkTimeMode.value;
      const raw = String(bulkTimeValue.value || "").trim();
      if (!picked.length) {
        alert("请先勾选要批量修改的行。");
        return;
      }
      if (mode === "set") {
        const fixed = normalizeTimeClient(raw);
        if (!fixed) {
          alert("统一设为需要输入时间，比如 14:30:00。");
          return;
        }
        picked.forEach((task) => {
          task.time = fixed;
        });
        markDirty();
        render();
        return;
      }
      const amount = Number(raw);
      if (!Number.isFinite(amount)) {
        alert("请输入要调整的数字。");
        return;
      }
      const unitSeconds = bulkTimeUnit.value === "second" ? 1 : (bulkTimeUnit.value === "hour" ? 3600 : 60);
      const delta = amount * unitSeconds * (mode === "advance" ? -1 : 1);
      picked.forEach((task) => {
        const baseSeconds = timeToSeconds(task.time);
        if (baseSeconds == null) return;
        const baseDay = Number.isFinite(Number(task.__dateOffset)) ? Number(task.__dateOffset) : 0;
        const next = Math.max(0, baseDay * 86400 + baseSeconds + delta);
        task.__dateOffset = Math.floor(next / 86400);
        task.time = secondsToTime(next % 86400);
      });
      markDirty();
      render();
    });
    bindClick("restore-time", () => {
      const picked = selectedTasks();
      if (!picked.length) {
        alert("请先勾选要恢复的行。");
        return;
      }
      picked.forEach((task) => {
        if (task.__initialTime) task.time = task.__initialTime;
        if (Number.isFinite(Number(task.__initialDateOffset))) task.__dateOffset = Number(task.__initialDateOffset);
      });
      markDirty();
      render();
    });
    bindClick("insert-task-top", insertManualTask);
    bindClick("jump-top", () => window.scrollTo({ top: 0, behavior: "smooth" }));
    bindClick("jump-bottom", () => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "smooth" }));
    bindClick("include-range-media", includeRangeMedia);
    bindClick("ignore-range-media", ignoreRangeMedia);
    bindClick("dialog-cancel", closeDialog);
    bindClick("dialog-confirm", () => {
      if (!activeDialogConfirm || activeDialogConfirm() !== false) closeDialog();
    });
    previewDialog.addEventListener("click", (event) => {
      if (event.target === previewDialog) closeDialog();
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !previewDialog.classList.contains("hidden")) closeDialog();
    });
    viewMode.onchange = render;
    initBulkDate();
    render();

    function escapeHtml(value) {
      return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
    }
    function escapeAttr(value) {
      return escapeHtml(value);
    }
  </script>
</body>
</html>`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[ch]));
}

function escapeAttr(value) {
  return escapeHtml(value);
}

function escapeScriptJson(value) {
  return String(value).replace(/</g, "\\u003c").replace(/>/g, "\\u003e").replace(/&/g, "\\u0026");
}

function sendHtml(res, html) {
  res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  res.end(html);
}

function sendJson(res, payload) {
  res.writeHead(200, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

async function sendAsset(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  const file = url.searchParams.get("path");
  if (!file || !path.isAbsolute(file)) {
    res.writeHead(404);
    res.end();
    return;
  }
  const data = await fs.readFile(file);
  res.writeHead(200, { "content-type": contentType(file), "cache-control": "no-store" });
  res.end(data);
}

function contentType(file) {
  const ext = path.extname(file).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".gif") return "image/gif";
  if (ext === ".webp") return "image/webp";
  if (ext === ".mp4") return "video/mp4";
  return "image/png";
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.setEncoding("utf8");
    req.on("data", (chunk) => {
      body += chunk;
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

function listen(server) {
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", resolve);
  });
}

function closeServer(server) {
  return new Promise((resolve) => {
    server.close(() => resolve());
  });
}

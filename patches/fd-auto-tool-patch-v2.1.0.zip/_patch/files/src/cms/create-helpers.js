import fs from "node:fs/promises";

export function isMediaTask(task) {
  return task.type === "image" || task.type === "sticker" || task.type === "video";
}

export async function validatePreviewPayloadForCreate(task, index) {
  const label = `第 ${index + 1} 条 / ${task.role || ""} / ${task.speaker || ""} / ${task.time || ""} / ${task.type || ""}`;
  if (task.type === "text") {
    const text = String(task.text || "");
    if (!normalizePayloadText(text)) {
      throw new Error(`${label} 创建前校验失败：预览文字为空，已停止，避免创建空任务。`);
    }
    return;
  }
  if (isMediaTask(task)) {
    const filePath = String(task.imagePath || "").trim();
    if (!filePath) {
      throw new Error(`${label} 创建前校验失败：预览素材路径为空，已停止，避免漏发。`);
    }
    try {
      await fs.access(filePath);
    } catch {
      throw new Error(`${label} 创建前校验失败：素材文件不存在：${filePath}`);
    }
  }
}

export function previewPayloadSummary(task) {
  if (task.type === "text") return `文字 ${normalizePayloadText(task.text).length} 字：${compactSummary(task.text)}`;
  if (task.type === "image") return `图片：${task.imagePath || ""}`;
  if (task.type === "sticker") return `表情包：${task.imagePath || ""}`;
  if (task.type === "video") return `视频：${task.imagePath || ""}`;
  return `类型：${task.type || ""}`;
}

export function textMatchesExpected(actualText, expectedText) {
  const actual = normalizePayloadText(actualText);
  const expected = normalizePayloadText(expectedText);
  if (actual === expected) return true;
  const actualCompact = compactText(actual);
  const expectedCompact = compactText(expected);
  return Boolean(expectedCompact && actualCompact.includes(expectedCompact));
}

export function tuoRobotKey(task) {
  if (task.robotGroup !== undefined && task.robotGroup !== null) return `robot:${task.robotGroup}`;
  if (task.interactionGroup !== undefined && task.interactionGroup !== null) return `interaction:${task.interactionGroup}`;
  return `speaker:${task.speaker}`;
}

export function buildRoleUsageRank(rows, currentRoleName = "") {
  const rank = {};
  for (const [index, row] of rows.entries()) {
    if (!row.roleName) continue;
    rank[row.roleName] = index + 1;
  }
  if (currentRoleName) rank[currentRoleName] = Number.MAX_SAFE_INTEGER;
  return rank;
}

export function roleUsageRow(task, index) {
  return {
    createdAt: new Date().toISOString(),
    roleName: task.fixedRoleName || "",
    taskIndex: String(index + 1),
    speaker: task.speaker || "",
    robotGroup: task.robotGroup === undefined || task.robotGroup === null ? "" : String(task.robotGroup),
    time: task.time || "",
    originalTime: task.originalTime || "",
    type: task.type || "",
    kind: classifyUsageKind(task),
    summary: task.text ? compactSummary(task.text) : task.imagePath || task.assetUrl || ""
  };
}

export function compactSummary(text) {
  return String(text || "").replace(/\s+/g, " ").trim().slice(0, 120);
}

export async function loadRoleUsage(config) {
  try {
    const text = await fs.readFile(roleUsageFile(config), "utf8");
    const lines = text.split(/\r?\n/).filter(Boolean);
    if (lines.length <= 1) return [];
    const headers = parseCsvLine(lines[0]);
    return lines.slice(1).map((line) => {
      const values = parseCsvLine(line);
      return Object.fromEntries(headers.map((key, index) => [key, values[index] || ""]));
    });
  } catch {
    return [];
  }
}

export async function appendRoleUsage(config, row) {
  const file = roleUsageFile(config);
  const headers = ["createdAt", "roleName", "taskIndex", "speaker", "robotGroup", "time", "originalTime", "type", "kind", "summary"];
  let exists = true;
  try {
    await fs.access(file);
  } catch {
    exists = false;
  }
  const line = headers.map((key) => csvEscape(row[key] || "")).join(",") + "\n";
  if (!exists) {
    await fs.writeFile(file, headers.join(",") + "\n" + line, "utf8");
  } else {
    await fs.appendFile(file, line, "utf8");
  }
}

export function csvEscape(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export async function loadProgress(config) {
  if (config.resumeOnRun === false) return { completed: [] };
  try {
    return JSON.parse(await fs.readFile(progressFile(config), "utf8"));
  } catch {
    return { completed: [] };
  }
}

export async function saveProgress(config, progress) {
  if (config.resumeOnRun === false) return;
  await fs.writeFile(progressFile(config), JSON.stringify(progress, null, 2), "utf8");
}

export async function clearProgress(config) {
  if (config.resumeOnRun === false) return;
  await fs.rm(progressFile(config), { force: true });
}

export function taskKey(task, index) {
  return [index, task.role, task.scheduleDateKey || "today", task.time, task.type].join("|");
}

export async function checkpointControl(control, label = "") {
  if (!control?.checkpoint) return;
  await control.checkpoint(String(label || "").replace(/^：/, ""));
}

export async function waitWithControl(page, ms, control = null, label = "") {
  const total = Math.max(0, Number(ms) || 0);
  if (!control?.checkpoint || total <= 0) {
    await page.waitForTimeout(total);
    return;
  }
  const endAt = Date.now() + total;
  while (Date.now() < endAt) {
    await checkpointControl(control, label);
    await page.waitForTimeout(Math.min(250, Math.max(0, endAt - Date.now())));
  }
  await checkpointControl(control, label);
}

function normalizePayloadText(text) {
  return String(text || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n").trim();
}

function classifyUsageKind(task) {
  if (task.type === "sticker") return "表情包";
  if (task.type === "video") return "视频";
  if (task.type === "image") return "图片";
  const text = task.text || "";
  if (/吗|么|嘛|怎么样|好不好|适合|可以|能不能|有没有|问下|请问/.test(text)) return "疑问";
  if (/买了|拍了|下单|订单|付款|入手/.test(text)) return "订单/购买";
  if (/实拍|晒|到了|收到|反馈|好用|不错|喝了|用了/.test(text)) return "反馈";
  return "文字";
}

function roleUsageFile(config) {
  return config.roleUsageFile || "./role-usage-log.csv";
}

function progressFile(config) {
  return config.progressFile || "./last-progress.json";
}

function parseCsvLine(line) {
  const result = [];
  let value = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (ch === '"' && inQuotes && line[i + 1] === '"') {
      value += '"';
      i += 1;
    } else if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === "," && !inQuotes) {
      result.push(value);
      value = "";
    } else {
      value += ch;
    }
  }
  result.push(value);
  return result;
}

function compactText(text) {
  return String(text || "").replace(/\s+/g, "");
}

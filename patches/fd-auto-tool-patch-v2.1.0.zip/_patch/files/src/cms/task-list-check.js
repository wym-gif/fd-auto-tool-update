export function createCmsTaskListChecker({
  installVirtualMouse,
  taskScheduleDateFixed,
  csvEscape,
  compact
}) {
  async function checkCmsTaskList(context, config, tasks, results = []) {
    const page = await context.newPage();
    await installVirtualMouse(page);
    const url = cmsTaskListUrl(config);
    await page.goto(url, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(Number(config.taskListCheckInitialWaitMs || 2500));
    await page.bringToFront().catch(() => {});
  
    const rows = await collectTaskListRows(page);
    const checks = buildTaskListChecks(tasks, results, rows, config);
    return buildTaskListReport(url, rows, checks);
  }
  
  function cmsTaskListUrl(config) {
    const configured = String(config.cmsJobListUrl || config.taskListUrl || "").trim();
    if (configured) return configured;
    const base = String(config.cmsUrl || "https://cms.iyunzk.com/wx/FenWei_rw").trim();
    if (/\/joblist(?:$|\?)/.test(base)) return base;
    return `${base.replace(/\/$/, "")}/joblist`;
  }
  
  async function collectTaskListRows(page) {
    const byText = new Map();
    for (let i = 0; i < 5; i += 1) {
      const batch = await page.evaluate(() => {
        const visible = (el) => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
        };
        const rowSelectors = [
          ".el-table__body-wrapper tbody tr",
          ".el-table__row",
          "tbody tr"
        ];
        const found = [];
        for (const selector of rowSelectors) {
          for (const row of Array.from(document.querySelectorAll(selector))) {
            if (!visible(row)) continue;
            const cells = Array.from(row.querySelectorAll("td")).map((td) => String(td.innerText || td.textContent || "").trim());
            const text = String(row.innerText || row.textContent || "").trim();
            if (!text || !cells.length) continue;
            found.push({ text, cells });
          }
          if (found.length) break;
        }
        return found;
      }).catch(() => []);
      for (const row of batch) {
        const key = compact(row.text);
        if (key && !byText.has(key)) byText.set(key, row);
      }
      await page.mouse.wheel(0, 900).catch(() => {});
      await page.waitForTimeout(400);
    }
    return Array.from(byText.values()).map((row, index) => ({ index, ...row }));
  }
  
  function buildTaskListChecks(tasks, results, rows, config) {
    const expected = expectedTaskIndexes(tasks, results);
    return tasks
      .map((task, index) => ({ task, index }))
      .filter(({ index }) => expected.has(index))
      .map(({ task, index }) => checkOneTaskInList(task, index, rows, config));
  }
  
  function expectedTaskIndexes(tasks, results) {
    const indexes = new Set();
    for (const item of results || []) {
      const result = item?.result;
      if (!result?.ok || result?.skipped) continue;
      const index = Number.isInteger(item.index) ? item.index : findTaskIndexForCheck(tasks, item.task);
      if (index >= 0) indexes.add(index);
    }
    if (!indexes.size) {
      for (let index = 0; index < tasks.length; index += 1) indexes.add(index);
    }
    return indexes;
  }
  
  function findTaskIndexForCheck(tasks, resultTask) {
    if (!resultTask) return -1;
    return tasks.findIndex((task) =>
      task.role === resultTask.role &&
      task.speaker === resultTask.speaker &&
      task.time === resultTask.time &&
      task.type === resultTask.type &&
      (task.scheduleDateKey || "") === (resultTask.scheduleDateKey || "")
    );
  }
  
  function checkOneTaskInList(task, index, rows, config) {
    const label = taskListLabel(task, index);
    const exactRows = rows.filter((row) => rowMatchesTaskListTask(row, task, config, { requireDate: true, requireTime: true }));
    if (exactRows.length) {
      return {
        index,
        task,
        label,
        status: "已匹配",
        matchedRows: exactRows,
        message: exactRows.length > 1 ? `找到 ${exactRows.length} 行，可能是多群正常拆分` : ""
      };
    }
  
    const contentRows = rows.filter((row) => rowMatchesTaskListContent(row, task));
    if (contentRows.length) {
      return {
        index,
        task,
        label,
        status: "疑似错定",
        matchedRows: contentRows,
        message: "找到相似内容，但日期或时间没有对上"
      };
    }
  
    const timeRows = rows.filter((row) => rowHasTaskDate(row, task, config) && rowHasTaskTime(row, task));
    if (timeRows.length) {
      return {
        index,
        task,
        label,
        status: "需要人工确认",
        matchedRows: timeRows,
        message: "日期时间对上，但内容摘要没明显对上"
      };
    }
  
    return {
      index,
      task,
      label,
      status: "疑似漏定",
      matchedRows: [],
      message: "任务列表里没有找到对应日期时间和内容"
    };
  }
  
  function rowMatchesTaskListTask(row, task, config, options = {}) {
    if (options.requireDate && !rowHasTaskDate(row, task, config)) return false;
    if (options.requireTime && !rowHasTaskTime(row, task)) return false;
    return rowMatchesTaskListContent(row, task);
  }
  
  function rowMatchesTaskListContent(row, task) {
    const text = compact(row.text);
    if (!text) return false;
    if (task.type === "image") return text.includes("图片") || text.includes("图");
    if (task.type === "sticker") return text.includes("动态表情") || text.includes("表情");
    if (task.type === "video") return text.includes("视频");
    const needle = compact(task.text || "").slice(0, 18);
    if (needle.length >= 6 && text.includes(needle)) return true;
    const shortNeedle = compact(task.text || "").slice(0, 10);
    return shortNeedle.length >= 6 && text.includes(shortNeedle);
  }
  
  function rowHasTaskTime(row, task) {
    const time = String(task.time || "");
    const hm = time.match(/^(\d{1,2}):(\d{2})/);
    if (!hm) return false;
    const text = row.text || "";
    return text.includes(time) || text.includes(`${hm[1].padStart(2, "0")}:${hm[2]}`) || text.includes(`${Number(hm[1])}:${hm[2]}`);
  }
  
  function rowHasTaskDate(row, task, config) {
    const date = taskListDateStrings(task, config);
    if (!date.length) return true;
    const text = row.text || "";
    return date.some((item) => text.includes(item));
  }
  
  function taskListDateStrings(task, config) {
    const schedule = taskScheduleDateFixed(task, config || {});
    const date = new Date();
    date.setDate(date.getDate() + Number(schedule.offset || 0));
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    return [
      `${yyyy}-${mm}-${dd}`,
      `${Number(mm)}/${Number(dd)}`,
      `${Number(mm)}月${Number(dd)}日`
    ];
  }
  
  function taskListLabel(task, index) {
    const date = task.scheduleDateLabel || task.scheduleDateKey || "今天";
    return `${index + 1}. ${task.role || ""} / ${task.speaker || ""} / ${date} ${task.time || ""} / ${task.type || ""} / ${taskListSummary(task)}`;
  }
  
  function taskListSummary(task) {
    if (task.text) return String(task.text).replace(/\s+/g, " ").trim().slice(0, 60);
    if (task.type === "sticker") return "表情包";
    if (task.type === "image") return "图片";
    if (task.type === "video") return "视频";
    return "";
  }
  
  function buildTaskListReport(url, rows, checks) {
    const matchedRows = checks.filter((row) => row.status === "已匹配");
    const missingRows = checks.filter((row) => row.status === "疑似漏定");
    const wrongRows = checks.filter((row) => row.status === "疑似错定");
    const uncertainRows = checks.filter((row) => row.status === "需要人工确认");
    const problemRows = [...missingRows, ...wrongRows, ...uncertainRows];
  
    const lines = [];
    lines.push("任务列表检查");
    lines.push(`生成时间：${new Date().toLocaleString()}`);
    lines.push(`任务列表：${url}`);
    lines.push(`读取到任务列表可见行：${rows.length} 行`);
    lines.push("");
    lines.push(`已匹配：${matchedRows.length} 条`);
    lines.push(`疑似漏定：${missingRows.length} 条`);
    lines.push(`疑似错定：${wrongRows.length} 条`);
    lines.push(`需要人工确认：${uncertainRows.length} 条`);
    lines.push("");
  
    if (problemRows.length) {
      lines.push("需要重点检查：");
      for (const row of problemRows) {
        lines.push(`- ${row.status}：${row.label}${row.message ? ` / ${row.message}` : ""}`);
        for (const matched of row.matchedRows.slice(0, 2)) lines.push(`  匹配行：${compactTaskListRow(matched.text)}`);
      }
      lines.push("");
    } else {
      lines.push("检查结果：没有发现明显漏定或错定。");
      lines.push("");
    }
  
    lines.push("全部检查明细：");
    for (const row of checks) {
      lines.push(`- ${row.status}：${row.label}${row.message ? ` / ${row.message}` : ""}`);
    }
  
    const csvRows = [
      ["序号", "状态", "角色", "说话人", "日期", "时间", "类型", "内容摘要", "说明", "匹配行数量"],
      ...checks.map((row) => [
        String(row.index + 1),
        row.status,
        row.task.role || "",
        row.task.speaker || "",
        row.task.scheduleDateLabel || row.task.scheduleDateKey || "今天",
        row.task.time || "",
        row.task.type || "",
        taskListSummary(row.task),
        row.message || "",
        String(row.matchedRows.length)
      ])
    ];
  
    return {
      text: `${lines.join("\n")}\n`,
      csv: `${csvRows.map((row) => row.map(csvEscape).join(",")).join("\n")}\n`,
      matchedRows,
      missingRows,
      wrongRows,
      uncertainRows,
      problemRows
    };
  }
  
  function compactTaskListRow(text) {
    return String(text || "").replace(/\s+/g, " ").trim().slice(0, 180);
  }

  return { checkCmsTaskList };
}

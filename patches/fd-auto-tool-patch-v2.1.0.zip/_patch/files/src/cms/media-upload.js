export function createCmsMediaUpload(deps) {
  const {
    T,
    waitWithControl,
    checkpointControl,
    closePopups,
    clickMessageTab,
    clickText,
    clickLocator,
    findAnyTextLocator,
    findDialogButtonLocator,
    setStep
  } = deps;

  function mediaReadyOptions(config, control = null, progressLabel = "") {
    return {
      retryWhenNotReady: true,
      requireReadyText: true,
      timeoutMs: mediaReadyTimeoutMs(config),
      control,
      progressLabel
    };
  }

  function mediaReadyTimeoutMs(config) {
    return Math.max(45000, Number(config.mediaReadyTimeoutMs || 90000));
  }

  async function fillMediaMessage(page, filePath, tabName, options = {}) {
    await checkpointControl(options.control, `${options.progressLabel || ""}：准备上传素材`);
    await closePopups(page);
    await clickMessageTab(page, tabName);
    await waitWithControl(page, 900, options.control, `${options.progressLabel || ""}：打开素材面板`);
    if (!(await waitForMediaPanel(page, tabName))) {
      await checkpointControl(options.control, `${options.progressLabel || ""}：重新打开素材面板`);
      await clickMessageTab(page, tabName);
      await waitWithControl(page, 900, options.control, `${options.progressLabel || ""}：等待素材面板`);
      await waitForMediaPanel(page, tabName);
    }

    await checkpointControl(options.control, `${options.progressLabel || ""}：上传素材`);
    await uploadFile(page, filePath, tabName);

    await checkpointControl(options.control, `${options.progressLabel || ""}：等待素材就绪`);
    await waitForUploadReady(page, options.timeoutMs || 45000, options);
  }

  async function waitForMediaPanel(page, tabName) {
    return page.waitForFunction(({ T, tabName }) => {
      const body = document.body.innerText || "";
      if (tabName === T.image) return body.includes(T.upload) || body.includes(T.pasteImage) || body.includes("\u5c06\u56fe\u7247\u62d6\u5230\u6b64\u5904");
      if (tabName === T.sticker) return body.includes(T.customSticker) || body.includes(T.upload);
      if (tabName === T.video) return body.includes(T.upload);
      return true;
    }, { T, tabName }, { timeout: 5000 }).then(() => true).catch(() => false);
  }


  async function uploadFile(page, filePath, tabName) {
    const chooserPromise = page.waitForEvent("filechooser", { timeout: 6000 }).catch(() => null);
    await clickUploadBox(page, tabName);

    const chooser = await chooserPromise;
    if (chooser) {
      await chooser.setFiles(filePath);
      await confirmCompressedUpload(page);
      await waitForUploadStarted(page);
      return;
    }

    if (await setFileInput(page, filePath, { optional: true })) {
      await confirmCompressedUpload(page);
      await waitForUploadStarted(page);
      return;
    }
    await printUploadDebug(page);
    throw new Error("Cannot find upload input");
  }

  async function waitForUploadStarted(page) {
    const started = await page.waitForFunction((T) => {
      const body = document.body.innerText || "";
      return body.includes("KB") || body.includes("MB") || body.includes(T.ready) || body.includes(T.preparing) || body.includes(T.notReady);
    }, T, { timeout: 5000 }).then(() => true).catch(() => false);
    if (!started) console.log("Upload warning: file was selected, but CMS did not show upload status yet");
  }

  async function confirmCompressedUpload(page) {
    const hasDialog = await page.waitForFunction((T) => {
      const body = document.body.innerText || "";
      return body.includes(T.confirmUpload) || body.includes("\u538b\u7f29\u540e\u4e0a\u4f20");
    }, T, { timeout: 3000 }).then(() => true).catch(() => false);
    if (!hasDialog) return false;

    const button = await findDialogButtonLocator(page, T.confirmUpload);
    if (button) {
      await clickLocator(page, button, "confirm upload");
      await page.waitForTimeout(800);
      return true;
    }
    await clickText(page, T.confirmUpload, "confirm upload", { optional: true });
    await page.waitForTimeout(800);
    return true;
  }

  async function setFileInput(page, filePath) {
    for (const frame of page.frames()) {
      const inputs = frame.locator('input[type="file"]');
      const count = await inputs.count().catch(() => 0);
      for (let i = count - 1; i >= 0; i -= 1) {
        const input = inputs.nth(i);
        try {
          await input.setInputFiles(filePath, { timeout: 2000 });
          return true;
        } catch {
          // Try the next file input.
        }
      }
    }
    return false;
  }

  async function clickUploadBox(page, tabName) {
    const labels = tabName === T.sticker
      ? [T.upload, "\u7528\u4f01\u4e1a\u53f7\u62d6\u52a8\u52a8\u6001\u8868\u60c5\u5230\u6b64\u5904"]
      : tabName === T.video
        ? [T.upload, "\u5c06\u89c6\u9891\u62d6\u5230\u6b64\u5904", "\u89c6\u9891\u4e0a\u4f20"]
        : [T.upload, "\u5c06\u56fe\u7247\u62d6\u5230\u6b64\u5904", T.customSticker];
    for (const frame of page.frames()) {
      const locator = await findSmallTextLocatorInFrame(frame, labels);
      if (locator) {
        await clickLocator(page, locator, "open upload box");
        return true;
      }
    }

    for (const frame of page.frames()) {
      const boxes = [
        frame.locator(".el-upload").last(),
        frame.locator(".el-upload-dragger").last(),
        frame.locator("[class*='upload']").last()
      ];
      for (const box of boxes) {
        if (await box.count().catch(() => 0)) {
          await clickLocator(page, box, "open upload box");
          return true;
        }
      }
    }
    await printUploadDebug(page);
    throw new Error("Cannot find upload input");
  }

  async function printUploadDebug(page) {
    const info = await page.evaluate((T) => {
      const body = document.body.innerText || "";
      const words = [T.text, T.image, T.video, T.sticker, T.upload, T.pasteImage, T.customSticker, T.execute, T.anyTime];
      return words
        .filter((word) => body.includes(word))
        .join(" / ");
    }, T).catch(() => "");
    console.log(`Upload debug visible words: ${info || "(none)"}`);
  }

  async function findSmallTextLocatorInFrame(frame, labels) {
    const handle = await frame.evaluateHandle((labels) => {
      const visible = (el) => {
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const score = (el) => {
        const r = el.getBoundingClientRect();
        return r.width * r.height;
      };
      const els = Array.from(document.querySelectorAll("a,button,span,div,label,p"));
      return els
        .filter((el) => visible(el) && labels.some((label) => (el.innerText || el.textContent || "").includes(label)))
        .sort((a, b) => score(a) - score(b))[0] || null;
    }, labels).catch(() => null);
    const element = handle?.asElement();
    return element || null;
  }

  async function waitForUploadReady(page, timeoutMs = 45000, options = {}) {
    const start = Date.now();
    let clickedNotReadyAt = 0;

    while (Date.now() - start < timeoutMs) {
      await checkpointControl(options.control, `${options.progressLabel || ""}：等待素材就绪`);
      const state = await uploadStateStrict(page, options);
      if (state.ready) {
        await waitWithControl(page, 300, options.control, `${options.progressLabel || ""}：素材已就绪`);
        return;
      }

      const canRetryClick = options.retryWhenNotReady && (state.notReady || state.hasMedia) && Date.now() - clickedNotReadyAt > 9000;
      if (canRetryClick) {
        clickedNotReadyAt = Date.now();
        await setStep(page, "click media once");
        await checkpointControl(options.control, `${options.progressLabel || ""}：点击素材检查就绪`);
        await clickNotReadyMaterialStrict(page);
        await setStep(page, "waiting media ready");
        await waitUntilReadyAfterClick(page, Math.min(10000, timeoutMs - (Date.now() - start)), options);
        continue;
      }

      await waitWithControl(page, 500, options.control, `${options.progressLabel || ""}：等待素材就绪`);
    }

    if (options.requireReadyText) {
      throw new Error("Media is not showing green ready text, so send was not executed");
    }
  }

  async function waitUntilReadyAfterClick(page, timeoutMs, options = {}) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      await waitWithControl(page, 500, options.control, `${options.progressLabel || ""}：等待素材就绪`);
      const state = await uploadStateStrict(page, options);
      if (state.ready) return true;
    }
    return false;
  }

  async function uploadStateStrict(page, options = {}) {
    return page.evaluate(({ T, requireReadyText }) => {
      const body = document.body.innerText || "";
      const ready = body.includes(T.ready);
      const notReady = [T.preparing, T.notReady, T.notPrepared, T.loading, T.processing]
        .some((text) => body.includes(text));
      const hasMedia = body.includes(T.preview) || body.includes("KB") || body.includes("MB");
      return {
        ready: requireReadyText ? ready : ready || hasMedia,
        notReady,
        hasMedia
      };
    }, { T, requireReadyText: Boolean(options.requireReadyText) }).catch(() => ({ ready: false, notReady: false, hasMedia: false }));
  }

  async function clickNotReadyMaterialStrict(page) {
    const label = await findAnyTextLocator(page, [T.preparing, T.notReady, T.notPrepared, T.loading, T.processing]);
    if (label) {
      await clickLocator(page, label, "click not-ready media");
      await page.waitForTimeout(500);
      return;
    }

    const point = await page.evaluate(() => {
      const visible = (el) => {
        if (!el) return false;
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
      };
      const nodes = Array.from(document.querySelectorAll("div,span,p,a"))
        .filter((el) => visible(el) && /(?:KB|MB|预览|就绪|准备|棰勮|灏辩华|鍑嗗)/.test(el.innerText || el.textContent || ""));
      const node = nodes[nodes.length - 1];
      if (!node) return null;
      const rect = node.getBoundingClientRect();
      return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    }).catch(() => null);
    if (point) {
      await page.mouse.click(point.x, point.y);
      await page.waitForTimeout(500);
    }
  }

  return {
    fillMediaMessage,
    mediaReadyOptions,
    mediaReadyTimeoutMs,
    waitForUploadReady
  };
}

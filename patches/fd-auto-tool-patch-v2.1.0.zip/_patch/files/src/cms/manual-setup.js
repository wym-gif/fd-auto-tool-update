import { askChoice } from "../utils.js";

export async function askCmsSetupAction(config) {
  if (config.__runControl?.waitForCmsSetupAction) {
    console.log("请在妙券自动发单🚀控制台确认云中客页面准备情况。");
    return await config.__runControl.waitForCmsSetupAction();
  }
  return await askChoice(
    "发单页面准备好后，请选择下一步",
    [
      { key: "1", label: "我已手动选好，开始创建", value: "continue" },
      { key: "2", label: "重新按当前时间生成预览再执行", value: "refresh" },
      { key: "3", label: "回到监控，不执行", value: "monitor" }
    ],
    "1"
  );
}

export function createCmsTimeSetting(deps) {
  const {
    T,
    closePopups,
    moveToLocator,
    setStep
  } = deps;

  async function setTimeFast(page, time, scheduleDate, currentDateKey) {
    await closePopups(page);

    if (scheduleDate.key !== currentDateKey) {
      await selectScheduleDate(page, scheduleDate);
      await closePopups(page);
    }

    const timeInput = await findTimeInput(page);
    await moveToLocator(page, timeInput, `time ${time}`);
    await fillScheduleTime(page, timeInput, time);
    await page.keyboard.press("Tab").catch(() => {});
    await closePopups(page);

    const value = await timeInput.inputValue().catch(() => "");
    if (value !== time) throw new Error(`定时时间没有设置成功：应该是 ${time}，当前是 ${value || "空"}`);
    console.log(`设置时间：${time}`);
  }

  async function fillScheduleTime(page, locator, value) {
    await locator.scrollIntoViewIfNeeded({ timeout: 5000 }).catch(() => {});
    await locator.click({ timeout: 3000, force: true }).catch(() => {});
    await page.waitForTimeout(180);
    await page.keyboard.press(process.platform === "darwin" ? "Meta+A" : "Control+A").catch(() => {});
    await page.keyboard.press("Backspace").catch(() => {});
    await page.keyboard.type(value, { delay: 12 }).catch(async () => {
      await setNativeInputValue(locator, value);
    });
    await page.keyboard.press("Enter").catch(() => {});
    await clickTimePickerOk(page);
    await page.waitForTimeout(500);

    let current = await locator.inputValue().catch(() => "");
    if (current !== value) {
      await setNativeInputValue(locator, value);
      await page.keyboard.press("Enter").catch(() => {});
      await clickTimePickerOk(page);
      await page.waitForTimeout(250);
      current = await locator.inputValue().catch(() => "");
    }
    if (current !== value) throw new Error(`无法填写定时时间：应该是 ${value}，当前是 ${current || "空"}`);
  }

  async function setNativeInputValue(locator, value) {
    await locator.evaluate((el, nextValue) => {
      el.removeAttribute("readonly");
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (!setter) return false;
      el.focus();
      setter.call(el, nextValue);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.blur?.();
      return true;
    }, value);
  }

  async function clickTimePickerOk(page) {
    const point = await page.evaluate((T) => {
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const panels = Array.from(document.querySelectorAll(".el-time-panel, .el-picker-panel, .el-date-picker"))
        .filter(visible);
      for (const panel of panels) {
        const buttons = Array.from(panel.querySelectorAll("button,span,a"))
          .filter((el) => visible(el) && normalize(el.innerText || el.textContent) === normalize(T.ok));
        const button = buttons[buttons.length - 1];
        if (button) {
          const r = button.getBoundingClientRect();
          return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
        }
      }
      return null;
    }, T).catch(() => null);
    if (!point) return false;
    await page.mouse.click(point.x, point.y);
    return true;
  }

  function taskScheduleDate(task, config) {
    if (task.scheduleDateKey) {
      return {
        key: task.scheduleDateKey,
        offset: Number(task.scheduleDateOffset || 0),
        label: task.scheduleDateLabel || ""
      };
    }
    if (config.dateMode === "tomorrow") return { key: "tomorrow", offset: 1, label: "鏄庡ぉ" };
    return { key: "today", offset: 0, label: "" };
  }

  async function selectScheduleDate(page, scheduleDate) {
    const label = scheduleDateOptionText(scheduleDate.offset);
    if (!label) throw new Error(`Schedule date is outside supported CMS range: ${scheduleDate.label || scheduleDate.offset}`);
    const day = scheduleDateDay(scheduleDate);
    if (!day) throw new Error(`Cannot calculate schedule day: ${scheduleDate.label || scheduleDate.key || scheduleDate.offset}`);
    const timeInput = await findTimeInput(page);
    await moveToLocator(page, timeInput, `date ${day}`);
    const opened = await openScheduleDateDropdownFixed(page, label);
    if (!opened) throw new Error("Cannot open schedule date dropdown");
    await page.waitForTimeout(400);
    const selected = await clickScheduleDateOptionByDaySafe(page, day);
    if (!selected) throw new Error(`Cannot select schedule date: ${day}`);
    await page.waitForTimeout(250);
    const verified = await verifySelectedScheduleDate(page, label);
    if (!verified) throw new Error(`Schedule date selected wrong option, expected label: ${label}`);
    await setStep(page, `select date ${day}`);
  }

  async function openScheduleDateDropdown(page, label) {
    const point = await page.evaluate((T) => {
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const labels = Array.from(document.querySelectorAll("span,div,label"))
        .filter((el) => visible(el) && normalize(el.innerText || el.textContent).includes(normalize("\u5b9a\u65f6\u53d1\u9001")));
      const labelEl = labels.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top)[0];
      if (!labelEl) return null;
      const rowTop = labelEl.getBoundingClientRect().top - 18;
      const rowBottom = labelEl.getBoundingClientRect().bottom + 22;
      const rowLeft = labelEl.getBoundingClientRect().right;
      const candidates = Array.from(document.querySelectorAll("input,button,.el-select,.el-input,[class*='select']"))
        .filter((el) => visible(el))
        .map((el) => ({ el, r: el.getBoundingClientRect(), text: normalize(el.innerText || el.textContent || el.value || el.placeholder || "") }))
        .filter((item) => item.r.top >= rowTop && item.r.bottom <= rowBottom && item.r.left > rowLeft)
        .filter((item) => [T.today, T.tomorrow, T.dayAfterTomorrow, T.plus3, T.plus4].some((word) => item.text.includes(normalize(word))) || item.r.width >= 60);
      candidates.sort((a, b) => a.r.left - b.r.left);
      const target = candidates[0];
      if (!target) return null;
      return { x: target.r.left + target.r.width / 2, y: target.r.top + target.r.height / 2 };
    }, T).catch(() => null);
    if (!point) return false;
    await setStep(page, `open date ${label}`);
    await page.mouse.click(point.x, point.y);
    return true;
  }

  async function clickScheduleDateOption(page, label) {
    const point = await page.evaluate((label) => {
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const target = normalize(label);
      const visible = (el) => {
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const els = Array.from(document.querySelectorAll(".el-select-dropdown span,.el-select-dropdown li,li,span,div"))
        .filter((el) => visible(el) && normalize(el.innerText || el.textContent).includes(target));
      els.sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return ar.top - br.top || ar.left - br.left;
      });
      const el = els[0];
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    }, label).catch(() => null);
    if (!point) return false;
    await setStep(page, `select date ${label}`);
    await page.mouse.click(point.x, point.y);
    return true;
  }

  async function clickScheduleDateOptionByOffset(page, offset, label) {
    const point = await page.evaluate(({ T, offset }) => {
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const words = [T.today, T.tomorrow, T.dayAfterTomorrow, T.plus3, T.plus4].map(normalize);
      const dropdowns = Array.from(document.querySelectorAll(".el-select-dropdown, .el-popper, [x-placement]"))
        .filter(visible)
        .map((root) => {
          const options = Array.from(root.querySelectorAll(".el-select-dropdown__item, li"))
            .filter(visible)
            .map((el) => {
              const r = el.getBoundingClientRect();
              const text = normalize(el.innerText || el.textContent || "");
              return { el, r, text };
            })
            .filter((item) => item.r.width > 20 && item.r.height > 10);
          const score = options.filter((item) => words.some((word) => item.text.includes(word))).length;
          return { root, options, score };
        })
        .filter((item) => item.options.length >= 5 && item.score >= 3)
        .sort((a, b) => b.score - a.score);
      const dropdown = dropdowns[0];
      if (!dropdown) return null;

      const dateOptions = dropdown.options
        .filter((item) => words.some((word) => item.text.includes(word)))
        .sort((a, b) => a.r.top - b.r.top || a.r.left - b.r.left);
      const target = dateOptions[offset];
      if (!target) return null;
      return { x: target.r.left + target.r.width / 2, y: target.r.top + target.r.height / 2 };
    }, { T, offset }).catch(() => null);
    if (!point) return false;
    await setStep(page, `select date ${label}`);
    await page.mouse.click(point.x, point.y);
    return true;
  }

  async function verifySelectedScheduleDate(page, label) {
    return page.evaluate(({ T, label }) => {
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const overlapY = (a, b) => Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
      const timeInput = Array.from(document.querySelectorAll("input"))
        .filter(visible)
        .find((el) => normalize(el.placeholder).includes(normalize(T.anyTime)) || /^\d{2}:\d{2}:\d{2}$/.test(el.value || ""));
      if (!timeInput) return false;
      const timeRect = timeInput.getBoundingClientRect();
      const expected = normalize(label);
      const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,span"))
        .filter(visible)
        .filter((el) => !el.closest(".el-select-dropdown,.el-popper,[x-placement]"))
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = normalize(el.innerText || el.textContent || el.value || "");
          return { r, text };
        })
        .filter((item) => {
          if (item.r.right > timeRect.left + 8) return false;
          if (item.r.left < timeRect.left - 260) return false;
          return overlapY(item.r, timeRect) >= Math.min(item.r.height, timeRect.height) * 0.45;
        });
      return candidates.some((item) => item.text.includes(expected));
    }, { T, label }).catch(() => false);
  }

  function scheduleDateDay(scheduleDate) {
    const keyMatch = String(scheduleDate?.key || "").match(/\d{4}-\d{2}-(\d{2})/);
    if (keyMatch) return Number(keyMatch[1]);
    const labelMatch = String(scheduleDate?.label || "").match(/\/(\d{1,2})$/);
    if (labelMatch) return Number(labelMatch[1]);
    const offset = Number(scheduleDate?.offset || 0);
    const date = new Date();
    date.setDate(date.getDate() + offset);
    return date.getDate();
  }

  async function clickScheduleDateOptionByDay(page, day) {
    const point = await page.evaluate(({ day }) => {
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const target = `${Number(day)}`;
      const dropdowns = Array.from(document.querySelectorAll(".el-select-dropdown, .el-popper, [x-placement]"))
        .filter(visible)
        .map((root) => {
          const options = Array.from(root.querySelectorAll(".el-select-dropdown__item, li, [role='option']"))
            .filter(visible)
            .map((el) => {
              const r = el.getBoundingClientRect();
              const text = normalize(el.innerText || el.textContent || "");
              return { el, r, text };
            })
            .filter((item) => item.r.width > 20 && item.r.height > 10 && item.text.length <= 16);
          const score = options.filter((item) => /(?:浠婂ぉ|鏄庡ぉ|鍚庡ぉ|\+\d+澶?\(\d{1,2}鍙穃)/.test(item.text)).length;
          return { options, score };
        })
        .filter((item) => item.score >= 2)
        .sort((a, b) => b.score - a.score);
      const dropdown = dropdowns[0];
      if (!dropdown) return null;
      const targetOption = dropdown.options
        .filter((item) => item.text.includes(target))
        .sort((a, b) => a.r.top - b.r.top || a.r.left - b.r.left)[0];
      if (!targetOption) return null;
      return {
        x: targetOption.r.left + targetOption.r.width / 2,
        y: targetOption.r.top + targetOption.r.height / 2,
        text: targetOption.text
      };
    }, { day }).catch(() => null);
    if (!point) return false;
    await setStep(page, `select date ${day}`);
    await page.mouse.click(point.x, point.y);
    return true;
  }

  async function verifySelectedScheduleDateDay(page, day) {
    return page.evaluate(({ T, day }) => {
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const overlapY = (a, b) => Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
      const timeInput = Array.from(document.querySelectorAll("input"))
        .filter(visible)
        .find((el) => normalize(el.placeholder).includes(normalize(T.anyTime)) || /^\d{2}:\d{2}:\d{2}$/.test(el.value || ""));
      if (!timeInput) return false;
      const timeRect = timeInput.getBoundingClientRect();
      const target = `${Number(day)}`;
      const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,span"))
        .filter(visible)
        .filter((el) => !el.closest(".el-select-dropdown,.el-popper,[x-placement]"))
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = normalize(el.innerText || el.textContent || el.value || "");
          return { r, text };
        })
        .filter((item) => {
          if (item.r.right > timeRect.left + 8) return false;
          if (item.r.left < timeRect.left - 260) return false;
          return overlapY(item.r, timeRect) >= Math.min(item.r.height, timeRect.height) * 0.45;
        });
      return candidates.some((item) => item.text.includes(target));
    }, { T, day }).catch(() => false);
  }

  async function clickScheduleDateOptionByDaySafe(page, day) {
    const point = await page.evaluate(({ day }) => {
      const expectedDay = Number(day);
      const dayToken = `${expectedDay}\u53f7`;
      const wrappedDayToken = `(${dayToken})`;
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const roots = Array.from(document.querySelectorAll(".el-select-dropdown, .el-popper, [x-placement]"))
        .filter(visible)
        .filter((root) => {
          const text = normalize(root.innerText || root.textContent || "");
          return text.includes("\u4eca\u5929") || text.includes("\u660e\u5929") || text.includes("\u540e\u5929") || text.includes(dayToken);
        });
      const searchRoots = roots;
      const candidates = searchRoots.flatMap((root) =>
        Array.from(root.querySelectorAll(".el-select-dropdown__item, li, [role='option'], span"))
          .filter(visible)
          .map((el) => {
            const r = el.getBoundingClientRect();
            const text = normalize(el.innerText || el.textContent || "");
            return { el, r, text };
          })
      )
        .filter((item) => item.r.width > 20 && item.r.height > 10)
        .filter((item) => item.text.length <= 20)
        .filter((item) => item.text.includes(wrappedDayToken) || item.text === dayToken)
        .sort((a, b) => a.r.top - b.r.top || a.r.left - b.r.left);
      const target = candidates[0];
      if (!target) return null;
      const clickable = target.el.closest(".el-select-dropdown__item, li, [role='option']") || target.el;
      const r = clickable.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2, text: target.text };
    }, { day }).catch(() => null);
    if (!point) return false;
    await setStep(page, `select date ${day}`);
    await page.mouse.click(point.x, point.y);
    console.log(`Click date option: ${point.text}`);
    return true;
  }

  function taskScheduleDateFixed(task, config) {
    if (task.scheduleDateKey) {
      return {
        key: task.scheduleDateKey,
        offset: Number(task.scheduleDateOffset || 0),
        label: task.scheduleDateLabel || ""
      };
    }
    if (config.dateMode === "tomorrow") return { key: "tomorrow", offset: 1, label: T.tomorrow };
    return { key: "today", offset: 0, label: "" };
  }

  async function openScheduleDateDropdownFixed(page, label) {
    const point = await page.evaluate((T) => {
      const normalize = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const overlapY = (a, b) => Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
      const timeInput = Array.from(document.querySelectorAll("input"))
        .filter(visible)
        .find((el) => normalize(el.placeholder).includes(normalize(T.anyTime)) || /^\d{2}:\d{2}:\d{2}$/.test(el.value || ""));
      if (!timeInput) return null;

      const timeRect = timeInput.getBoundingClientRect();
      const dateWords = [
        T.today,
        T.tomorrow,
        T.dayAfterTomorrow,
        T.plus3,
        T.plus4,
        "+5\u5929",
        "+6\u5929",
        "+7\u5929"
      ].map(normalize);
      const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,div"))
        .filter(visible)
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = normalize(el.innerText || el.textContent || el.value || el.placeholder || "");
          return { el, r, text };
        })
        .filter((item) => {
          if (item.r.right > timeRect.left + 8) return false;
          if (item.r.left < timeRect.left - 260) return false;
          if (overlapY(item.r, timeRect) < Math.min(item.r.height, timeRect.height) * 0.45) return false;
          return dateWords.some((word) => item.text.includes(word));
        })
        .sort((a, b) => b.r.right - a.r.right);
      const target = candidates[0];
      if (!target) return null;
      return { x: target.r.left + target.r.width / 2, y: target.r.top + target.r.height / 2 };
    }, T).catch(() => null);
    if (!point) return false;
    await setStep(page, `open date ${label}`);
    await page.mouse.click(point.x, point.y);
    return true;
  }

  function scheduleDateOptionText(offset) {
    if (offset === 0) return T.today;
    if (offset === 1) return T.tomorrow;
    if (offset === 2) return T.dayAfterTomorrow;
    if (offset >= 3 && offset <= 7) return `+${offset}\u5929`;
    return "";
  }

  async function findTimeInput(page) {
    const byPlaceholder = page.locator(`input[placeholder="${T.anyTime}"]:visible`).first();
    if (await byPlaceholder.count().catch(() => 0)) return byPlaceholder;

    const inputs = await page.locator("input").evaluateAll((els) =>
      els.map((el, index) => ({ index, value: el.value, placeholder: el.placeholder }))
    );
    const found = inputs.find((item) => /^\d{2}:\d{2}:\d{2}$/.test(item.value));
    if (!found) throw new Error("Cannot find schedule time input");
    return page.locator("input").nth(found.index);
  }

  return {
    setTimeFast,
    taskScheduleDateFixed
  };
}

const progressPrintState = new Map();

export function printProgressStep(title, detail = "") {
  clearProgressLine();
  console.log(detail ? `[${new Date().toLocaleTimeString()}] ${title} ${detail}` : `[${new Date().toLocaleTimeString()}] ${title}`);
}

export function writeProgressBar(title, current, total, detail = "") {
  const safeTotal = Math.max(1, Number(total) || 1);
  const safeCurrent = Math.min(safeTotal, Math.max(0, Number(current) || 0));
  const percent = Math.round((safeCurrent / safeTotal) * 100);
  const text = `${title}: ${percent}% (${safeCurrent}/${safeTotal}) ${detail}`;
  if (process.stdout?.isTTY) {
    process.stdout.write(`\r${text.slice(0, 140).padEnd(140, " ")}`);
  } else if (shouldPrintProgressLine(title, safeCurrent, safeTotal, percent)) {
    console.log(text);
  }
}

export function reportControlProgress(control, title, current, total, detail = "") {
  if (!control?.setProgress) return;
  void control.setProgress(title, current, total, detail).catch(() => {});
}

export function shouldPrintProgressLine(title, current, total, percent) {
  const key = `${title}:${total}`;
  const previous = progressPrintState.get(key) || { percent: -1, current: 0 };
  const step = title.includes("素材") ? 20 : 10;
  const crossedStep = Math.floor(percent / step) > Math.floor(previous.percent / step);
  const finished = current >= total && previous.current < total;
  if (crossedStep || finished || previous.percent < 0) {
    progressPrintState.set(key, { percent, current });
    return true;
  }
  return false;
}

export function clearProgressLine() {
  if (!process.stdout?.isTTY) return;
  process.stdout.write(`\r${" ".repeat(180)}\r`);
}

export function isControlStopped(error) {
  return String(error?.message || error || "").includes("已通过控制台停止");
}

export function isBrowserTargetClosed(error) {
  const message = String(error?.message || error || "");
  return /Target page, context or browser has been closed|Target closed|Browser has been closed|Page closed/i.test(message);
}

export function isWatchMode(value) {
  return value === "watch-preview" || value === "watch" || value === "monitor";
}

export class UserCanceledPreview extends Error {
  constructor(message) {
    super(message);
    this.userCanceledPreview = true;
  }
}

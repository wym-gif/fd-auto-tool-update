import { spawn } from "node:child_process";
import path from "node:path";

export function launchRunBat(rootDir, spawnFn = spawn) {
  const runBat = path.join(rootDir, "run.bat");
  spawnFn("cmd.exe", ["/c", "start", "\"\"", runBat], {
    cwd: rootDir,
    detached: true,
    stdio: "ignore"
  }).unref();
}

export function launchRunInSameWindow(rootDir, spawnFn = spawn) {
  return launchModeInSameWindow(rootDir, "run", {}, spawnFn);
}

export function launchWatchPreviewInSameWindow(rootDir, spawnFn = spawn) {
  return launchModeInSameWindow(rootDir, "watch-preview", { FD_REUSE_LATEST_SETTINGS: "1" }, spawnFn);
}

function launchModeInSameWindow(rootDir, mode, envOverrides, spawnFn) {
  return new Promise((resolve, reject) => {
    const child = spawnFn(process.execPath, [path.join(rootDir, "src", "run-with-log.cjs"), mode], {
      cwd: rootDir,
      env: {
        ...process.env,
        ...envOverrides
      },
      stdio: "inherit"
    });
    child.on("error", reject);
    child.on("close", (code) => resolve(code || 0));
  });
}

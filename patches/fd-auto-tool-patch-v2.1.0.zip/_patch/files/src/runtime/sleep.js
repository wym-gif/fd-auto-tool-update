export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function controlledSleep(control, ms, label = "等待下一步") {
  if (!control) {
    await sleep(ms);
    return;
  }
  const endAt = Date.now() + ms;
  await control.startWaitProgress?.(label, ms);
  try {
    while (Date.now() < endAt) {
      await control.checkpoint();
      await sleep(Math.min(1000, Math.max(0, endAt - Date.now())));
    }
  } finally {
    await control.clearWaitProgress?.(label);
  }
}

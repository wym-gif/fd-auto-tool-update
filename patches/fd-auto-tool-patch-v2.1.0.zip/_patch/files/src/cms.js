import { askCmsSetupAction } from "./cms/manual-setup.js";
import { createCmsTaskListChecker } from "./cms/task-list-check.js";
import { createCmsTimeSetting } from "./cms/time-setting.js";
import { createCmsMediaUpload } from "./cms/media-upload.js";
import {
  appendRoleUsage,
  buildRoleUsageRank,
  checkpointControl,
  clearProgress,
  compactSummary,
  csvEscape,
  isMediaTask,
  loadProgress,
  loadRoleUsage,
  previewPayloadSummary,
  roleUsageRow,
  saveProgress,
  taskKey,
  textMatchesExpected,
  tuoRobotKey,
  validatePreviewPayloadForCreate,
  waitWithControl
} from "./cms/create-helpers.js";
import { secondsToClock as secondsToTimeShared, timeToSeconds as timeToSecondsShared } from "./schedule/time-utils.js";

const T = {
  today: "\u4eca\u5929",
  tomorrow: "\u660e\u5929",
  dayAfterTomorrow: "\u540e\u5929",
  plus3: "+3\u5929",
  plus4: "+4\u5929",
  useRole: "\u4f7f\u7528\u89d2\u8272",
  selectRole: "\u8bf7\u9009\u62e9\u89d2\u8272",
  changeRobot: "\u66f4\u6362\u673a\u5668\u4eba",
  sendTime: "\u53d1\u9001\u65f6\u95f4",
  anyTime: "\u4efb\u610f\u65f6\u95f4\u70b9",
  ok: "\u786e\u5b9a",
  text: "\u6587\u672c",
  image: "\u56fe\u7247",
  video: "\u89c6\u9891",
  sticker: "\u52a8\u6001\u8868\u60c5",
  scheduleSend: "\u5b9a\u65f6\u53d1\u9001",
  switchEditor: "\u5207\u6362\u4e3a\u65b0\u7248\u7f16\u8f91\u5668",
  textPlaceholder: "\u8bf7\u8f93\u5165\u6587\u5b57",
  upload: "\u70b9\u51fb\u4e0a\u4f20",
  customSticker: "\u81ea\u5b9a\u4e49\u8868\u60c5\u5305",
  pasteImage: "\u7c98\u8d34\u56fe\u7247",
  execute: "\u6267\u884c\u53d1\u9001",
  confirmCreate: "\u786e\u8ba4\u521b\u5efa",
  cancel: "\u53d6\u6d88",
  confirmUpload: "\u786e\u8ba4\u4e0a\u4f20",
  yes: "\u662f",
  noContent: "\u8bf7\u81f3\u5c11\u8f93\u5165\u4e00\u6761\u6d88\u606f\u5185\u5bb9",
  taskCreated: "\u4efb\u52a1\u521b\u5efa\u6210\u529f",
  created: "\u521b\u5efa\u6210\u529f",
  expiredTime: "\u5df2\u7ecf\u8fc7\u4e86",
  switchImmediate: "\u662f\u5426\u5207\u6362\u4e3a\u7acb\u5373\u6267\u884c",
  ready: "\u6781\u901f\u5c31\u7eea",
  preparing: "\u6781\u901f\u51c6\u5907\u4e2d",
  notReady: "\u672a\u5c31\u7eea",
  notPrepared: "\u672a\u51c6\u5907",
  loading: "\u52a0\u8f7d\u4e2d",
  processing: "\u5904\u7406\u4e2d",
  preview: "\u9884\u89c8",
  choose: "\u8bf7\u9009\u62e9",
  empty: "\u4e0d\u80fd\u4e3a\u7a7a"
};

let showVisualHelper = false;

const { setTimeFast, taskScheduleDateFixed } = createCmsTimeSetting({
  T,
  closePopups,
  moveToLocator,
  setStep
});

const { checkCmsTaskList } = createCmsTaskListChecker({
  installVirtualMouse,
  taskScheduleDateFixed,
  csvEscape,
  compact
});

export { checkCmsTaskList };

const {
  fillMediaMessage,
  mediaReadyOptions,
  mediaReadyTimeoutMs,
  waitForUploadReady
} = createCmsMediaUpload({
  T,
  waitWithControl,
  checkpointControl,
  closePopups,
  clickMessageTab,
  clickText,
  clickLocator,
  findAnyTextLocator,
  findDialogButtonLocator,
  setStep
});

export async function prepareCmsPages(context, config) {
  showVisualHelper = Boolean(config.showVisualHelper);
  const pages = context.pages();
  const cmsPages = pages.filter((page) => page.url().includes("cms.iyunzk.com/wx/FenWei_rw"));
  while (cmsPages.length < 2) {
    const page = await context.newPage();
    await page.goto(config.cmsUrl, { waitUntil: "domcontentloaded" });
    cmsPages.push(page);
  }

  for (const page of cmsPages) await installVirtualMouse(page);

  if (config.waitForManualSetup) {
    console.log("云中客页面设置记忆恢复功能已关闭；本次不会自动点击群、机器人、角色、任务备注或多快捷。");

    console.log("\n请在打开的两个云中客页面里手动确认：");
    console.log("1. 第一个页面选好【托】的群和机器人");
    console.log("2. 第二个页面选好【豆妈】的群和机器人");
    console.log("3. 两个页面都停留在创建任务页面");
    config.__cmsSetupAction = await askCmsSetupAction(config);
  }

  return { tuo: cmsPages[0], douma: cmsPages[1] };
}

export async function createCmsTasks(pages, tasks, config, control) {
  let lastTuoKey = "";
  let currentFixedRoleName = "";
  const fixedRoleUsage = await loadRoleUsage(config);
  const results = [];
  config.__latestTaskResults = results;
  const progress = await loadProgress(config);
  const completed = new Set(progress.completed || []);
  const selectedDateByRole = { tuo: null, douma: null };
  const confirmNotInGroupRobotGroups = new Set();
  const allowRuntimeTimeAdjust = config.scheduleMode === "realtime" || config.scheduleMode === "catchup";
  let runtimeBaseAbs = null;
  let foregroundPage = null;

  for (const [index, task] of tasks.entries()) {
    const key = taskKey(task, index);
    await checkpointControl(control, `${index + 1}/${tasks.length}：准备`);
    if (completed.has(key)) {
      if (task.role === "tuo") lastTuoKey = tuoRobotKey(task);
      results.push({ index, task, result: { ok: true, skippedCompleted: true, message: "Already completed in previous run" } });
      console.log(`已跳过已完成任务：${task.role} / ${task.speaker} / ${task.time} / ${task.type}`);
      continue;
    }

    const page = task.role === "douma" ? pages.douma : pages.tuo;
    await checkpointControl(control, `${index + 1}/${tasks.length}：切换页面`);
    if (foregroundPage !== page) {
      await page.bringToFront().catch(() => {});
      foregroundPage = page;
    }
    await installVirtualMouse(page);
    const title = `${index + 1}/${tasks.length}：${task.role} / ${task.speaker} / ${task.time} / ${task.type}`;
    await control?.checkpoint(title);
    await setStep(page, title);
    console.log(`\n创建任务：${task.role} / ${task.speaker} / ${task.time} / ${task.type}`);

    const currentTuoKey = tuoRobotKey(task);
    if (task.role === "tuo" && config.roles?.tuo?.changeRobotOnSpeakerChange) {
      const needsRobotChange = !lastTuoKey || currentTuoKey !== lastTuoKey;
      if (needsRobotChange && config.tuoMode === "fixed") {
        console.log(`选择固定托角色后更换机器人：${currentTuoKey}`);
        currentFixedRoleName = await selectFixedTuoRoleFromHistory(page, config, fixedRoleUsage, currentFixedRoleName);
        await clickChangeRobot(page);
        lastTuoKey = currentTuoKey;
      } else if (!lastTuoKey) {
        lastTuoKey = currentTuoKey;
      } else if (currentTuoKey !== lastTuoKey) {
        console.log(`更换机器人：${lastTuoKey} -> ${currentTuoKey}`);
        await clickChangeRobot(page);
        lastTuoKey = currentTuoKey;
      }
      if (config.tuoMode === "fixed" && currentFixedRoleName) task.fixedRoleName = currentFixedRoleName;
    }

    await checkpointControl(control, `${index + 1}/${tasks.length}：设置时间`);
    await setStep(page, "设置定时时间");
    if (allowRuntimeTimeAdjust && runtimeBaseAbs !== null) {
      const nextAbs = runtimeBaseAbs + runtimeGapSeconds(tasks[index - 1], task, config);
      if (taskAbsoluteSeconds(task) <= nextAbs) {
        task.originalTime = task.originalTime || task.time;
        applyRuntimeSchedule(task, nextAbs);
        console.log(`运行中修正时间：${task.originalTime} -> ${task.time}`);
      }
    }
    const rolePageKey = task.role === "douma" ? "douma" : "tuo";
    const scheduleDate = taskScheduleDateFixed(task, config);
    await checkpointControl(control, `${index + 1}/${tasks.length}：写入时间`);
    await setTimeFast(page, task.time, scheduleDate, selectedDateByRole[rolePageKey]);
    selectedDateByRole[rolePageKey] = scheduleDate.key;
    await waitWithControl(page, 700, control, `${index + 1}/${tasks.length}：时间已设置`);
    await closePopups(page);

    await checkpointControl(control, `${index + 1}/${tasks.length}：填写内容`);
    await validatePreviewPayloadForCreate(task, index);
    console.log(`创建前校验：第 ${index + 1} 条 / ${task.type} / ${previewPayloadSummary(task)}`);
    if (task.type === "text") {
      await fillTextMessage(page, task.text, config, { index });
    } else if (task.type === "image") {
      if (!task.imagePath) throw new Error(`图片文件缺失：${task.speaker} ${task.time}`);
      await fillMediaMessage(page, task.imagePath, T.image, mediaReadyOptions(config, control, `${index + 1}/${tasks.length}`));
    } else if (task.type === "sticker") {
      if (!task.imagePath) throw new Error(`表情包文件缺失：${task.speaker} ${task.time}`);
      await fillMediaMessage(page, task.imagePath, T.sticker, mediaReadyOptions(config, control, `${index + 1}/${tasks.length}`));
    } else if (task.type === "video") {
      if (!task.imagePath) throw new Error(`视频文件缺失：${task.speaker} ${task.time}`);
      await fillMediaMessage(page, task.imagePath, T.video, mediaReadyOptions(config, control, `${index + 1}/${tasks.length}`));
    }

    await checkpointControl(control, `${index + 1}/${tasks.length}：执行创建`);
    if (isMediaTask(task)) {
      await setStep(page, "等待素材就绪");
      await waitForUploadReady(page, mediaReadyTimeoutMs(config), mediaReadyOptions(config, control, `${index + 1}/${tasks.length}`));
    }
    await checkpointControl(control, `${index + 1}/${tasks.length}：准备执行发送`);
    await setStep(page, "执行发送");
    let result = await executeAndConfirm(page, configForTask(config, task, confirmNotInGroupRobotGroups), control, `${index + 1}/${tasks.length}`);
    if (result.retryWithNewFixedRole && task.role === "tuo" && config.tuoMode === "fixed") {
      console.log("固定托机器人不在群，正在换角色后重试。");
      await checkpointControl(control, `${index + 1}/${tasks.length}：换固定托角色`);
      currentFixedRoleName = await selectFixedTuoRoleFromHistory(page, config, fixedRoleUsage, currentFixedRoleName);
      await clickChangeRobot(page);
      if (currentFixedRoleName) task.fixedRoleName = currentFixedRoleName;
      await checkpointControl(control, `${index + 1}/${tasks.length}：重试执行创建`);
      result = await executeAndConfirm(page, config, control, `${index + 1}/${tasks.length}`);
    }
    const extraFixedRoleRetryLimit = Number(config.fixedRoleRetryLimit ?? 3) - 1;
    for (
      let retryIndex = 0;
      result.retryWithNewFixedRole && task.role === "tuo" && config.tuoMode === "fixed" && retryIndex < extraFixedRoleRetryLimit;
      retryIndex += 1
    ) {
      console.log(`固定托机器人不在群，正在换角色后重试（${retryIndex + 2}/${extraFixedRoleRetryLimit + 1}）。`);
      await checkpointControl(control, `${index + 1}/${tasks.length}：换固定托角色`);
      currentFixedRoleName = await selectFixedTuoRoleFromHistory(page, config, fixedRoleUsage, currentFixedRoleName);
      await clickChangeRobot(page);
      if (currentFixedRoleName) task.fixedRoleName = currentFixedRoleName;
      await checkpointControl(control, `${index + 1}/${tasks.length}：重试执行创建`);
      result = await executeAndConfirm(page, config, control, `${index + 1}/${tasks.length}`);
    }
    if (result.retryWithNewFixedRole) {
      throw new Error("固定托已达到重试次数，机器人仍不在群。");
    }
    const randomRobotRetryLimit = Number(config.randomRobotNotInGroupRetryLimit ?? 3);
    for (
      let retryIndex = 0;
      result.retryWithNewRandomRobot && task.role === "tuo" && config.tuoMode === "random" && retryIndex < randomRobotRetryLimit;
      retryIndex += 1
    ) {
      console.log(`随机托机器人不在群，正在更换机器人后重试（${retryIndex + 1}/${randomRobotRetryLimit}）。`);
      await checkpointControl(control, `${index + 1}/${tasks.length}：更换机器人`);
      await clickChangeRobot(page);
      await checkpointControl(control, `${index + 1}/${tasks.length}：重试执行创建`);
      result = await executeAndConfirm(page, configForTask(config, task, confirmNotInGroupRobotGroups), control, `${index + 1}/${tasks.length}`);
    }
    if (result.retryWithNewRandomRobot) {
      result = await handleRandomRobotRetryLimit(page, config, task, confirmNotInGroupRobotGroups, control, `${index + 1}/${tasks.length}`);
      if (result.retryWithNewRandomRobot) {
          throw new Error("随机托已达到重试次数，机器人仍不在群。");
      }
    }
    if (result.skipped) {
      results.push({ index, task, result });
      console.log(`已跳过：${task.role} / ${task.speaker} / ${task.time} / ${task.type} / ${result.message || ""}`);
      completed.add(key);
      await saveProgress(config, {
        updatedAt: new Date().toISOString(),
        completed: Array.from(completed)
      });
      await control?.checkpoint(`${index + 1}/${tasks.length}：已跳过`);
      continue;
    }
    results.push({ index, task, result });
    if (allowRuntimeTimeAdjust) {
      if (result.immediate) runtimeBaseAbs = currentRuntimeAbsoluteSeconds();
      else if (runtimeBaseAbs !== null) runtimeBaseAbs = taskAbsoluteSeconds(task);
    }
    console.log(`创建成功：${task.role} / ${task.speaker} / ${task.time} / ${task.type}`);
    if (config.tuoMode === "fixed" && task.role === "tuo") {
      const usage = roleUsageRow(task, index);
      await appendRoleUsage(config, usage);
      fixedRoleUsage.push(usage);
    }

    completed.add(key);
    await saveProgress(config, {
      updatedAt: new Date().toISOString(),
      completed: Array.from(completed)
    });
    await control?.checkpoint(`${index + 1}/${tasks.length}: done`);
  }

  await clearProgress(config);
  return results;
}

function runtimeCustomIntervalsEnabled(config = {}) {
  const mode = config.scheduleMode || "doc";
  return mode === "realtime" || mode === "catchup";
}

function runtimeIntervalNumberOrNull(value) {
  if (value === "" || value === undefined || value === null) return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function runtimeCustomIntervalSeconds(config = {}, key, minimum = 0) {
  if (!runtimeCustomIntervalsEnabled(config)) return null;
  const item = config.customIntervals?.[key];
  if (!item || typeof item !== "object") return null;
  let min = runtimeIntervalNumberOrNull(item.min);
  let max = runtimeIntervalNumberOrNull(item.max);
  if (min === null && max === null) return null;
  if (min === null) min = max;
  if (max === null) max = min;
  min = Math.max(minimum, Math.max(0, Math.round(min)));
  max = Math.max(minimum, Math.max(0, Math.round(max)));
  if (max < min) [min, max] = [max, min];
  return Math.round((min + max) / 2);
}

function runtimeRoleSwitchGapSeconds(config = {}) {
  const configured = Number(config.realtimeRoleSwitchGapSeconds ?? 120);
  const base = Math.max(120, Number.isFinite(configured) ? configured : 120);
  return runtimeCustomIntervalSeconds(config, "roleSwitch", 120) ?? base;
}

function runtimeGapKey(prev, next) {
  if (!prev || !next) return "";
  if (prev.role !== next.role) return "roleSwitch";
  if (prev.role === "douma" && next.role === "douma") return "doumaSame";
  if (prev.role === "tuo" && next.role === "tuo") {
    return prev.speaker === next.speaker ? "sameTuo" : "differentTuo";
  }
  return prev.speaker === next.speaker ? "sameTuo" : "differentTuo";
}

function withCustomRuntimeGap(defaultGap, prev, next, config = {}) {
  const key = runtimeGapKey(prev, next);
  if (!key) return defaultGap;
  const custom = runtimeCustomIntervalSeconds(config, key, key === "roleSwitch" ? 120 : 0);
  return custom === null ? defaultGap : custom;
}

function runtimeGapSeconds(prev, next, config) {
  if (!prev || !next) return 0;
  if (prev.role !== next.role) return runtimeRoleSwitchGapSeconds(config);
  let gap;
  if (isMediaTask(prev) || isMediaTask(next)) {
    gap = prev.speaker === next.speaker ? 50 : 45;
  } else if (prev.speaker === next.speaker) {
    gap = normalSpacingSeconds(next);
  } else {
    gap = Math.max(15, Number(config.minOtherSpeakerGapSeconds ?? 15));
  }
  return withCustomRuntimeGap(gap, prev, next, config);
}

function normalSpacingSeconds(task) {
  if (task.type === "image" || task.type === "sticker" || task.type === "video") return 30;
  const len = String(task.text || "").replace(/\s+/g, "").length;
  if (len <= 20) return 20;
  if (len <= 60) return 30;
  return 45;
}

function currentRuntimeAbsoluteSeconds() {
  const now = new Date();
  return now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
}

function taskAbsoluteSeconds(task) {
  return Number(task.scheduleDateOffset || 0) * 86400 + timeToSeconds(task.time);
}

function timeToSeconds(time) {
  const seconds = timeToSecondsShared(time || "00:00:00");
  return seconds === null ? 0 : seconds;
}

function secondsToTime(total) {
  return secondsToTimeShared(total);
}

function applyRuntimeSchedule(task, absoluteSeconds) {
  const dayOffset = Math.floor(absoluteSeconds / 86400);
  task.time = secondsToTime(absoluteSeconds);
  task.scheduleDateOffset = dayOffset;
  if (dayOffset === 0) {
    task.scheduleDateKey = "today";
    task.scheduleDateLabel = "";
    return;
  }
  const date = new Date();
  date.setDate(date.getDate() + dayOffset);
  task.scheduleDateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  task.scheduleDateLabel = `${date.getMonth() + 1}/${date.getDate()}`;
}

async function closePopups(page) {
  await page.keyboard.press("Escape").catch(() => {});
  await page.keyboard.press("Escape").catch(() => {});
}

async function fillTextMessage(page, text, config, options = {}) {
  await clickMessageTab(page, T.text);
  await page.waitForTimeout(150);

  if (config.textInput?.preferNewEditor) {
    await clickText(page, T.switchEditor, "new editor", { optional: true });
    const editor = page.locator(".ql-editor:visible").first();
    if (await editor.count().catch(() => 0)) {
      await moveToLocator(page, editor, "fill text");
      await editor.click();
      await clearFocusedInput(page);
      await page.keyboard.insertText(text);
      await page.waitForTimeout(100);
      await verifyFilledText(page, editor, text, options);
      return;
    }
  }

  const textarea = page.locator(`textarea[placeholder*="${T.textPlaceholder}"]:visible`).first();
  await moveToLocator(page, textarea, "fill text");
  await textarea.click();
  await clearFocusedInput(page);
  await page.keyboard.insertText(text);
  await verifyFilledText(page, textarea, text, options);
}

async function clearFocusedInput(page) {
  await page.keyboard.press(process.platform === "darwin" ? "Meta+A" : "Control+A");
  await page.keyboard.press("Backspace");
}

async function verifyFilledText(page, locator, expectedText, options = {}) {
  const actual = await readFilledText(locator);
  if (textMatchesExpected(actual, expectedText)) return;

  const indexLabel = Number.isInteger(options.index) ? `第 ${options.index + 1} 条` : "当前文字任务";
  console.log(`${indexLabel}文字填入不完整，正在重新填入。`);
  await locator.click();
  await clearFocusedInput(page);
  await page.keyboard.insertText(expectedText);
  await page.waitForTimeout(150);
  const retryActual = await readFilledText(locator);
  if (textMatchesExpected(retryActual, expectedText)) return;

  console.log(`${indexLabel}普通输入仍不完整，正在使用剪贴板粘贴兜底。`);
  await pasteTextFallback(page, locator, expectedText);
  const pasteActual = await readFilledText(locator);
  if (textMatchesExpected(pasteActual, expectedText)) return;

  throw new Error(
    `${indexLabel}创建前填入校验失败：云中客输入框里的文字和预览不一致，已停止，避免漏发。` +
      ` 预览=${compactSummary(expectedText)}；页面=${compactSummary(pasteActual || retryActual)}`
  );
}

async function pasteTextFallback(page, locator, text) {
  await locator.click();
  await clearFocusedInput(page);
  try {
    await page.evaluate(async (value) => {
      await navigator.clipboard.writeText(value);
    }, text);
    await page.keyboard.press(process.platform === "darwin" ? "Meta+V" : "Control+V");
  } catch {
    await locator.evaluate((el, value) => {
      if ("value" in el) {
        el.value = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        el.textContent = value;
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
      }
    }, text);
  }
  await page.waitForTimeout(150);
}

async function readFilledText(locator) {
  try {
    const value = await locator.inputValue({ timeout: 500 });
    if (value !== undefined && value !== null) return value;
  } catch {}
  try {
    return await locator.innerText({ timeout: 500 });
  } catch {
    return "";
  }
}

async function clickMessageTab(page, tabName) {
  const loc = await findExactSmallTextLocator(page, tabName);
  if (loc) {
    await clickLocator(page, loc, `${tabName} tab`);
    return;
  }
  await clickText(page, tabName, `${tabName} tab`);
}

async function executeAndConfirm(page, config, control = null, progressLabel = "") {
  await checkpointControl(control, `${progressLabel}：点击执行发送前`);
  await clickExecuteButton(page);
  const confirmDialogWaitMs = Math.max(1000, Number(config.confirmDialogWaitMs || 3000));
  let state = await waitForPostExecuteState(page, confirmDialogWaitMs);
  let immediate = state === "expiredTime";
  state = await handleExpiredTimeIfNeeded(page, state);

  for (let attempt = 0; state === "none" && attempt < 3; attempt += 1) {
    await waitWithControl(page, Math.min(1500, confirmDialogWaitMs), control, `${progressLabel}：等待确认弹窗`);
    await closePopups(page);
    await checkpointControl(control, `${progressLabel}：重试点击执行发送前`);
    await clickExecuteButton(page);
    state = await waitForPostExecuteState(page, Math.max(confirmDialogWaitMs, 5000));
    if (state === "expiredTime") immediate = true;
    state = await handleExpiredTimeIfNeeded(page, state);
  }

  const body = await page.locator("body").innerText();
  const hasConfirmCreate = body.includes(T.confirmCreate);
  if (body.includes(T.noContent)) throw new Error("CMS did not detect message content");
  if (body.includes(T.choose) || body.includes(T.empty)) throw new Error("CMS says a required option is missing");
  if ((body.includes(T.taskCreated) || body.includes(T.created)) && !hasConfirmCreate) return { ok: true, message: "Task created", immediate };
  if (!hasConfirmCreate) throw new Error("Confirm-create dialog did not appear");
  if (!config.ignoreRobotNotInGroup && config.tuoMode === "fixed" && hasRobotNotInGroupWarning(body)) {
    console.log("Fixed role robot not in group. Cancel and retry with another role.");
    await clickCancelCreateButton(page);
    return { ok: false, retryWithNewFixedRole: true, message: "Robot not in group" };
  }
  if (!config.ignoreRobotNotInGroup && config.tuoMode === "random" && hasRobotNotInGroupWarning(body)) {
    console.log("随机托机器人不在群，将更换机器人后重试。");
    await clickCancelCreateButton(page);
    return { ok: false, retryWithNewRandomRobot: true, message: "机器人不在群" };
  }

  if (!config.autoConfirmCreate) {
    console.log("请检查确认弹窗，并手动点击“确认创建”。");
    await waitForManualConfirmDone(page, config.manualConfirmTimeoutMs || 10 * 60 * 1000);
    return { ok: true, message: "已检测到手动确认", immediate };
  }

  await checkpointControl(control, `${progressLabel}：点击确认创建前`);
  await clickConfirmCreateButton(page);
  let created = await waitForCreateSuccess(page, 6000);
  if (!created) {
    await waitWithControl(page, 800, control, `${progressLabel}：等待创建结果`);
    await checkpointControl(control, `${progressLabel}：再次点击确认创建前`);
    await clickConfirmCreateButton(page);
    created = await waitForCreateSuccess(page, 10000);
  }
  if (!created) throw new Error("已点击确认创建，但没有检测到创建成功。");
  return { ok: true, message: "任务已创建", immediate };
}

function configForTask(config, task, confirmNotInGroupRobotGroups) {
  if (config.ignoreRobotNotInGroup) return config;
  if (
    config.tuoMode === "random" &&
    task?.role === "tuo" &&
    task.robotGroup !== undefined &&
    task.robotGroup !== null &&
    confirmNotInGroupRobotGroups.has(String(task.robotGroup))
  ) {
    return { ...config, ignoreRobotNotInGroup: true };
  }
  return config;
}

function shouldRememberConfirmForRobotGroup(task) {
  return (
    task?.role === "tuo" &&
    task.robotGroup !== undefined &&
    task.robotGroup !== null
  );
}

async function handleRandomRobotRetryLimit(page, config, task, confirmNotInGroupRobotGroups, control = null, progressLabel = "") {
  while (true) {
    await checkpointControl(control, `${progressLabel}：等待机器人不在群处理`);
    const action = await askChoice(
      "粗略版已自动更换机器人重试 3 次，还是显示不在群。请选择下一步：",
      [
        { key: "1", label: "继续更换机器人再试一次", value: "retry" },
        { key: "2", label: "不管不在群提示，直接确认创建", value: "confirm" },
        { key: "3", label: "跳过这条，继续下一条", value: "skip" },
        { key: "q", label: "停止运行", value: "stop" }
      ],
      "1"
    );

    if (action === "retry") {
      await checkpointControl(control, `${progressLabel}：更换机器人`);
      await clickChangeRobot(page);
      const result = await executeAndConfirm(page, config, control, progressLabel);
      if (!result.retryWithNewRandomRobot) return result;
      continue;
    }

    if (action === "confirm") {
      if (shouldRememberConfirmForRobotGroup(task)) {
        confirmNotInGroupRobotGroups.add(String(task.robotGroup));
        console.log("This robot group will keep using the current robot even if it shows not in group.");
      }
      return executeAndConfirm(page, { ...config, ignoreRobotNotInGroup: true }, control, progressLabel);
    }

    if (action === "skip") {
      return { ok: false, skipped: true, message: "Robot not in group, skipped by user" };
    }

    throw new Error("用户选择停止运行：机器人不在群");
  }
}

async function handleExpiredTimeIfNeeded(page, state) {
  if (state !== "expiredTime") return state;

  console.log("Schedule time is already past; clicking yes to run immediately");
  const clicked = await clickVisibleDialogButton(page, T.yes, "expired time: yes");
  if (!clicked) await clickText(page, T.yes, "expired time: yes");

  const nextState = await waitForPostExecuteState(page, 10000);
  if (nextState === "expiredTime") return "none";
  return nextState;
}

async function clickExecuteButton(page) {
  const button = await findExactButtonLocator(page, T.execute);
  if (button) {
    await moveToLocator(page, button, "execute send");
    const box = await button.boundingBox().catch(() => null);
    if (box) {
      await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
      return;
    }
    await button.click({ timeout: 8000, force: true });
    return;
  }
  await clickText(page, T.execute, "execute send");
}

async function selectFixedTuoRole(page, config) {
  const prefix = getFixedRolePrefix(config);
  await setStep(page, `select role: ${prefix}`);
  await openUseRoleDropdown(page);

  const point = await findRoleOptionPoint(page, prefix);
  if (!point) throw new Error(`Cannot find role option prefix: ${prefix}`);

  await moveToPoint(page, point.x, point.y, `role ${prefix}`);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(700);
  await ensureFixedRoleSelected(page, point.text || prefix);
}

async function selectFixedTuoRoleFromHistory(page, config, usageRows = [], currentRoleName = "") {
  const prefix = getFixedRolePrefix(config);
  await setStep(page, `select role: ${prefix}`);
  await openUseRoleDropdown(page);

  const point = await findRoleOptionPointFromHistory(page, prefix, usageRows, currentRoleName);
  if (!point) throw new Error(`Cannot find role option prefix: ${prefix}`);

  await moveToPoint(page, point.x, point.y, `role ${point.text || prefix}`);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(700);
  await ensureFixedRoleSelected(page, point.text || prefix);
  console.log(`Fixed role selected: ${point.text || prefix}`);
  return point.text || prefix;
}

async function ensureFixedRoleSelected(page, expectedRoleText) {
  const expected = normalizeCompact(expectedRoleText);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const selected = await getSelectedUseRoleText(page);
    if (selected && normalizeCompact(selected).includes(expected)) return;
    await page.waitForTimeout(500);
  }
  const selected = await getSelectedUseRoleText(page);
  throw new Error(`Fixed role was not selected. expected: ${expectedRoleText}, current: ${selected || "empty"}`);
}

async function getSelectedUseRoleText(page) {
  return page.evaluate((T) => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const inputs = Array.from(document.querySelectorAll("input"))
      .filter((el) => visible(el) && String(el.placeholder || "").includes(T.selectRole));
    if (inputs.length) return inputs[0].value || "";

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (!String(node.nodeValue || "").includes(T.useRole) || !visible(node.parentElement)) continue;
      const row = node.parentElement.closest("div,section,form") || node.parentElement;
      const candidates = Array.from(row.querySelectorAll("input,.el-select,.el-input,[class*='select']"))
        .filter(visible);
      for (const candidate of candidates.reverse()) {
        const input = candidate.matches?.("input") ? candidate : candidate.querySelector?.("input");
        if (input && visible(input)) return input.value || "";
        const text = String(candidate.innerText || candidate.textContent || "").trim();
        if (text && !text.includes(T.useRole)) return text;
      }
    }
    return "";
  }, T).catch(() => "");
}

function normalizeCompact(value) {
  return String(value || "").replace(/\s+/g, "");
}

function getFixedRolePrefix(config) {
  const prefix = String(config.roles?.tuo?.fixedRolePrefix || config.fixedRolePrefix || "").trim();
  if (!prefix) throw new Error("Fixed mode requires a role prefix/range. Restart and enter it.");
  return prefix;
}

async function openUseRoleDropdown(page) {
  const point = await findUseRoleDropdownPoint(page);
  if (point) {
    await moveToPoint(page, point.x, point.y, "open role dropdown");
    await page.mouse.click(point.x, point.y);
    await page.waitForTimeout(500);
    return;
  }

  const input = page.locator(`input[placeholder*="${T.selectRole}"]`).first();
  if (await input.count().catch(() => 0)) {
    await clickLocator(page, input, "open role dropdown");
    await page.waitForTimeout(500);
    return;
  }

  await clickText(page, T.useRole, "open role dropdown");
  await page.waitForTimeout(500);
}

async function findUseRoleDropdownPoint(page) {
  return page.evaluate((T) => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const inputs = Array.from(document.querySelectorAll("input"))
      .filter((el) => visible(el) && String(el.placeholder || "").includes(T.selectRole));
    if (inputs.length) {
      const r = inputs[0].getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    }

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (!String(node.nodeValue || "").includes(T.useRole) || !visible(node.parentElement)) continue;
      const row = node.parentElement.closest("div,section,form") || node.parentElement;
      const candidates = Array.from(row.querySelectorAll("input,.el-select,.el-input,[class*='select']"))
        .filter(visible);
      if (candidates.length) {
        const r = candidates[candidates.length - 1].getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      }
      const r = node.parentElement.getBoundingClientRect();
      return { x: r.right + 120, y: r.top + r.height / 2 };
    }
    return null;
  }, T).catch(() => null);
}

async function findRoleOptionPoint(page, prefix) {
  return page.evaluate((prefix) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(prefix);
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const selectors = ".el-select-dropdown__item, .el-select-dropdown li, [class*='select-dropdown'] li";
    const options = Array.from(document.querySelectorAll(selectors))
      .map((el) => el.closest(".el-select-dropdown__item, li") || el)
      .filter((el, index, arr) => arr.indexOf(el) === index)
      .filter((el) => visible(el) && !el.classList.contains("is-disabled") && normalize(el.innerText || el.textContent).startsWith(target))
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = String(el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
        return { x: r.left + r.width / 2, y: r.top + r.height / 2, top: r.top, left: r.left, area: r.width * r.height, text };
      })
      .filter((item) => item.area > 20);
    options.sort((a, b) => a.top - b.top || a.left - b.left);
    return options[0] || null;
  }, prefix).catch(() => null);
}

async function findRoleOptionPointFromHistory(page, prefix, usageRows = [], currentRoleName = "") {
  const usageRank = buildRoleUsageRank(usageRows, currentRoleName);
  return page.evaluate(({ prefix, usageRank }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(prefix);
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const selectors = ".el-select-dropdown__item, .el-select-dropdown li, [class*='select-dropdown'] li";
    const options = Array.from(document.querySelectorAll(selectors))
      .map((el) => el.closest(".el-select-dropdown__item, li") || el)
      .filter((el, index, arr) => arr.indexOf(el) === index)
      .filter((el) => visible(el) && !el.classList.contains("is-disabled") && normalize(el.innerText || el.textContent).startsWith(target))
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = String(el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
        const rank = usageRank[text] ?? 0;
        return { x: r.left + r.width / 2, y: r.top + r.height / 2, top: r.top, left: r.left, area: r.width * r.height, text, rank };
      })
      .filter((item) => item.area > 20);
    options.sort((a, b) => a.rank - b.rank || a.top - b.top || a.left - b.left);
    return options[0] || null;
  }, { prefix, usageRank }).catch(() => null);
}

async function clickChangeRobot(page) {
  const before = await selectedRobotSnapshot(page);
  let lastError = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await clickChangeRobotOnce(page);
      const changed = await waitForRobotSnapshotChange(page, before, 3500);
      if (!before || changed) return;
      lastError = new Error("Robot selection did not change after clicking change robot");
    } catch (error) {
      lastError = error;
    }
    await page.waitForTimeout(800);
  }
  throw lastError || new Error("Change robot failed");
}

async function clickChangeRobotOnce(page) {
  const point = await findChangeRobotPoint(page);
  if (point) {
    await moveToPoint(page, point.x, point.y, "change robot");
    await page.waitForTimeout(1200);
    await page.mouse.click(point.x, point.y);
    await page.waitForTimeout(1800);
    return;
  }

  const loc = await findExactSmallTextLocator(page, T.changeRobot);
  if (!loc) throw new Error(`Cannot find button or text: ${T.changeRobot}`);
  await moveToLocator(page, loc, "change robot");
  await page.waitForTimeout(1200);
  const box = await loc.boundingBox().catch(() => null);
  if (box) {
    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  } else {
    await loc.click({ timeout: 8000, force: true });
  }
  await page.waitForTimeout(1800);
}

async function waitForRobotSnapshotChange(page, before, timeoutMs = 3500) {
  if (!before) return true;
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const after = await selectedRobotSnapshot(page);
    if (after && after !== before) return true;
    await page.waitForTimeout(500);
  }
  return false;
}

async function selectedRobotSnapshot(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const normalize = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const checkedRows = [];
    const rows = Array.from(document.querySelectorAll("tr,.el-table__row,[class*='table-row']"))
      .filter((row) => visible(row));
    for (const row of rows) {
      const text = normalize(row.innerText || row.textContent);
      if (!text || !/(在线|wxid_|群#|群：|群:|宝妈|年轻|成熟|早期|机器人)/.test(text)) continue;
      const checked = Array.from(row.querySelectorAll("input[type='checkbox'],.el-checkbox,.ant-checkbox"))
        .some((el) =>
          el.checked ||
          el.getAttribute("aria-checked") === "true" ||
          String(el.className || "").includes("is-checked") ||
          Boolean(el.querySelector?.(".is-checked,input:checked,[aria-checked='true']"))
        );
      if (checked) checkedRows.push(text);
    }
    if (checkedRows.length) return checkedRows.join(" | ").slice(0, 1000);

    const body = normalize(document.body.innerText || "");
    const marker = body.indexOf("机器人");
    if (marker < 0) return "";
    return body.slice(marker, marker + 500);
  }).catch(() => "");
}

async function findChangeRobotPoint(page) {
  return page.evaluate((target) => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const candidates = [];
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const text = node.nodeValue || "";
      let index = text.indexOf(target);
      while (index >= 0) {
        const before = text.slice(Math.max(0, index - 2), index);
        if (!before.includes("闅忔満") && visible(node.parentElement)) {
          const range = document.createRange();
          range.setStart(node, index);
          range.setEnd(node, index + target.length);
          const rect = Array.from(range.getClientRects()).find((r) => r.width > 0 && r.height > 0);
          range.detach();
          if (rect) {
            candidates.push({
              x: rect.left + rect.width / 2,
              y: rect.top + rect.height / 2,
              top: rect.top,
              left: rect.left
            });
          }
        }
        index = text.indexOf(target, index + target.length);
      }
    }
    candidates.sort((a, b) => a.top - b.top || a.left - b.left);
    return candidates[0] || null;
  }, T.changeRobot).catch(() => null);
}

async function waitForPostExecuteState(page, timeoutMs = 12000) {
  return page.waitForFunction((T) => {
    const body = document.body.innerText || "";
    return (
      body.includes(T.confirmCreate) ||
      body.includes(T.noContent) ||
      body.includes(T.choose) ||
      body.includes(T.empty) ||
      body.includes(T.taskCreated) ||
      body.includes(T.created) ||
      body.includes(T.expiredTime) ||
      body.includes(T.switchImmediate)
    );
  }, T, { timeout: timeoutMs }).then(async () => {
    const body = await page.locator("body").innerText();
    if (body.includes(T.noContent) || body.includes(T.choose) || body.includes(T.empty)) return "error";
    if (body.includes(T.expiredTime) || body.includes(T.switchImmediate)) return "expiredTime";
    if (body.includes(T.confirmCreate)) return "confirmCreate";
    if (body.includes(T.taskCreated) || body.includes(T.created)) return "created";
    return "none";
  }).catch(() => "none");
}

async function clickConfirmCreateButton(page) {
  if (await clickDialogPrimaryButton(page, T.confirmCreate, "confirm create")) return;
  if (await clickVisibleDialogButton(page, T.confirmCreate, "confirm create")) return;
  const button = await findDialogButtonLocator(page, T.confirmCreate);
  if (button) {
    await moveToLocator(page, button, "confirm create");
    const box = await button.boundingBox().catch(() => null);
    if (box) {
      await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
      return;
    }
    await button.click({ timeout: 8000, force: true });
    return;
  }
  throw new Error("Cannot click visible confirm-create button");
}

async function clickCancelCreateButton(page) {
  if (await clickDialogPrimaryButton(page, T.cancel, "cancel create")) return;
  if (await clickVisibleDialogButton(page, T.cancel, "cancel create")) return;
  await page.keyboard.press("Escape").catch(() => {});
  await page.waitForTimeout(500);
}

function hasRobotNotInGroupWarning(body) {
  const text = String(body || "").replace(/\s+/g, "");
  return (
    text.includes("机器人不在群") ||
    text.includes("个机器人不在群") ||
    text.includes("不在群") ||
    text.includes("鏈哄櫒浜轰笉鍦ㄧ兢") ||
    /检测到[\s\S]*机器人不在群/.test(text) ||
    /妫€娴嬪埌[\s\S]*鏈哄櫒浜轰笉鍦ㄧ兢/.test(text)
  );
}

async function clickDialogPrimaryButton(page, text, label) {
  const point = await page.evaluate((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0
        && rect.height > 0
        && rect.bottom > 0
        && rect.right > 0
        && rect.top < window.innerHeight
        && rect.left < window.innerWidth
        && style.visibility !== "hidden"
        && style.display !== "none"
        && style.opacity !== "0";
    };
    const disabled = (el) => el.disabled || el.getAttribute("aria-disabled") === "true" || el.className.includes("is-disabled");
    const primary = (el) => {
      const cls = String(el.className || "");
      return cls.includes("primary") || cls.includes("el-button--primary") || cls.includes("ant-btn-primary");
    };
    const inFooter = (el) => Boolean(el.closest(".el-dialog__footer, .el-message-box__btns, .ant-modal-footer, .modal-footer"));
    const roots = Array.from(document.querySelectorAll(".el-dialog, .el-message-box, [role='dialog'], .ant-modal, .modal"))
      .filter(visible);
    if (!roots.length) roots.push(document.body);

    const candidates = [];
    for (const root of roots.slice().reverse()) {
      const buttons = Array.from(root.querySelectorAll("button,a,[role='button'],.el-button"))
        .filter((el) => visible(el) && !disabled(el));
      for (const button of buttons) {
        const content = normalize(button.innerText || button.textContent);
        if (!content.includes(target)) continue;
        let score = 0;
        if (content === target) score += 100;
        if (primary(button)) score += 30;
        if (inFooter(button)) score += 20;
        candidates.push({ button, score });
      }
    }

    candidates.sort((a, b) => a.score - b.score);
    const picked = candidates[candidates.length - 1]?.button;
    if (!picked) return null;
    const rect = picked.getBoundingClientRect();
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  }, text).catch(() => null);
  if (!point) return false;
  await moveToPoint(page, point.x, point.y, label);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(500);
  return true;
}

async function clickVisibleDialogButton(page, text, label) {
  const point = await page.evaluate((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0
        && rect.height > 0
        && rect.bottom > 0
        && rect.right > 0
        && rect.top < window.innerHeight
        && rect.left < window.innerWidth
        && style.visibility !== "hidden"
        && style.display !== "none"
        && style.opacity !== "0"
        && style.pointerEvents !== "none";
    };
    const roots = Array.from(document.querySelectorAll(".el-dialog, .el-message-box, [role='dialog'], .ant-modal, .modal"))
      .filter(visible);
    if (!roots.length) roots.push(document.body);
    for (const root of roots.slice().reverse()) {
      const buttons = Array.from(root.querySelectorAll("button,a,[role='button'],.el-button"))
        .filter((el) => visible(el) && normalize(el.innerText || el.textContent) === target);
      const button = buttons[buttons.length - 1];
      if (button) {
        const rect = button.getBoundingClientRect();
        return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
      }
    }
    return null;
  }, text).catch(() => null);
  if (!point) return false;
  await moveToPoint(page, point.x, point.y, label);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(400);
  return true;
}

async function waitForManualConfirmDone(page, timeoutMs) {
  await page.waitForFunction((T) => {
    const body = document.body.innerText || "";
    return !body.includes(T.confirmCreate) || body.includes(T.taskCreated) || body.includes(T.created);
  }, T, { timeout: timeoutMs });
  await page.waitForTimeout(200);
}

async function waitForCreateSuccess(page, timeoutMs = 10000) {
  return page.waitForFunction((T) => {
    const body = document.body.innerText || "";
    return (body.includes(T.taskCreated) || body.includes(T.created)) && !body.includes(T.confirmCreate);
  }, T, { timeout: timeoutMs }).then(() => true).catch(() => false);
}

async function installVirtualMouse(page) {
  if (!showVisualHelper) return;
  await page.evaluate(() => {
    document.getElementById("fd-mouse-label")?.remove();
    document.getElementById("fd-step-status")?.remove();
    if (document.getElementById("fd-mouse")) return;

    const cursor = document.createElement("div");
    cursor.id = "fd-mouse";
    cursor.style.cssText = [
      "position:fixed",
      "left:24px",
      "top:24px",
      "width:18px",
      "height:18px",
      "border-radius:50%",
      "background:#ef4444",
      "border:3px solid #fff",
      "box-shadow:0 0 0 3px rgba(239,68,68,.35),0 6px 18px rgba(0,0,0,.25)",
      "z-index:2147483647",
      "pointer-events:none",
      "transition:left .18s ease,top .18s ease"
    ].join(";");

    document.body.append(cursor);
  }).catch(() => {});
}

async function setStep(page, text) {
  if (!showVisualHelper) return;
  await installVirtualMouse(page);
}

async function moveToLocator(page, locator, label) {
  await locator.scrollIntoViewIfNeeded({ timeout: 5000 }).catch(() => {});
  if (!showVisualHelper) return;
  await installVirtualMouse(page);
  const box = await locator.boundingBox({ timeout: 5000 }).catch(() => null);
  if (!box) {
    await setStep(page, label);
    return;
  }

  const x = Math.max(8, box.x + box.width / 2);
  const y = Math.max(8, box.y + box.height / 2);
  await page.mouse.move(x, y, { steps: 10 }).catch(() => {});
  await page.evaluate(({ x, y, label }) => {
    const cursor = document.getElementById("fd-mouse");
    if (cursor) {
      cursor.style.left = `${x - 9}px`;
      cursor.style.top = `${y - 9}px`;
    }
  }, { x, y, label }).catch(() => {});
  await page.waitForTimeout(80);
}

async function moveToPoint(page, x, y, label) {
  if (!showVisualHelper) return;
  await installVirtualMouse(page);
  await page.mouse.move(x, y, { steps: 10 }).catch(() => {});
  await page.evaluate(({ x, y, label }) => {
    const cursor = document.getElementById("fd-mouse");
    if (cursor) {
      cursor.style.left = `${x - 9}px`;
      cursor.style.top = `${y - 9}px`;
    }
  }, { x, y, label }).catch(() => {});
  await page.waitForTimeout(80);
}

async function clickLocator(page, locator, label) {
  await moveToLocator(page, locator, label);
  await locator.click({ timeout: 8000 });
}

async function clickText(page, text, label, options = {}) {
  const loc = await findTextLocator(page, text, options);
  if (!loc) {
    if (options.optional) return false;
    throw new Error(`Cannot find button or text: ${text}`);
  }
  await clickLocator(page, loc, label || text);
  return true;
}

async function findAnyTextLocator(page, texts) {
  for (const text of texts) {
    const loc = await findTextLocator(page, text, { optional: true });
    if (loc) return loc;
  }
  return null;
}

async function findExactSmallTextLocator(page, text) {
  const handle = await page.evaluateHandle((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const score = (el) => {
      const r = el.getBoundingClientRect();
      const cls = String(el.className || "");
      const tabBonus = /tab|tabs|item|active/.test(cls) ? -100000 : 0;
      return r.width * r.height + tabBonus;
    };
    const els = Array.from(document.querySelectorAll("button,a,span,div,label,li"));
    return els
      .filter((el) => visible(el) && normalize(el.innerText || el.textContent) === target)
      .sort((a, b) => score(a) - score(b))[0] || null;
  }, text).catch(() => null);
  return handle?.asElement() || null;
}

async function findExactButtonLocator(page, text) {
  const roleButton = page.getByRole("button", { name: text, exact: true }).first();
  if (await roleButton.count().catch(() => 0)) return roleButton;

  const handle = await page.evaluateHandle((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const els = Array.from(document.querySelectorAll("button,a,[role='button']"));
    return els.find((el) => visible(el) && normalize(el.innerText || el.textContent) === target) || null;
  }, text).catch(() => null);
  return handle?.asElement() || null;
}

async function findDialogButtonLocator(page, text) {
  const handle = await page.evaluateHandle((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0
        && r.height > 0
        && r.bottom > 0
        && r.right > 0
        && r.top < window.innerHeight
        && r.left < window.innerWidth
        && s.visibility !== "hidden"
        && s.display !== "none"
        && s.opacity !== "0"
        && s.pointerEvents !== "none";
    };
    const dialogs = Array.from(document.querySelectorAll(".el-dialog, .el-message-box, [role='dialog'], .ant-modal, .modal"))
      .filter(visible);
    const roots = dialogs.length ? dialogs : [document.body];
    for (const root of roots.slice().reverse()) {
      const buttons = Array.from(root.querySelectorAll("button,a,[role='button'],.el-button"))
        .filter((el) => visible(el) && normalize(el.innerText || el.textContent) === target);
      if (buttons.length) return buttons[buttons.length - 1];
    }
    return null;
  }, text).catch(() => null);
  return handle?.asElement() || null;
}

async function findTextLocator(page, text, options = {}) {
  const compactText = compact(text);
  const handle = await page.evaluateHandle(({ compactText }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const tags = "button,a,span,div,label,li";
    const els = Array.from(document.querySelectorAll(tags));
    return els.find((el) => visible(el) && normalize(el.innerText || el.textContent).includes(compactText)) || null;
  }, { compactText });
  const element = handle.asElement();
  if (element) return element;

  const candidates = [
    page.getByRole("button", { name: new RegExp(spacedRegex(text)) }).first(),
    page.getByText(new RegExp(spacedRegex(text))).first()
  ];
  for (const loc of candidates) {
    if (await loc.count().catch(() => 0)) return loc;
  }

  if (options.optional) return null;
  return null;
}

function compact(text) {
  return String(text || "").replace(/\s+/g, "");
}

function spacedRegex(text) {
  return compact(text).split("").map(escapeRegex).join("\\s*");
}

function escapeRegex(char) {
  return char.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}


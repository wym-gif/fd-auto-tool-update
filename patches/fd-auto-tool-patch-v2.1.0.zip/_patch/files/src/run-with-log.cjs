const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

const mode = process.argv[2] || "run";
const logName =
  mode === "preview"
    ? "preview-last.log"
    : mode === "watch-preview"
      ? "watch-preview-last.log"
      : "run-last.log";
const root = path.resolve(__dirname, "..");
const logPath = path.join(root, logName);
const nodeExe = process.execPath;

const log = fs.createWriteStream(logPath, { flags: "w", encoding: "utf8" });

function write(chunk) {
  process.stdout.write(chunk);
  log.write(chunk);
}

write(`正在启动妙券自动发单🚀：${mode}\n`);
write(`本次日志：${logPath}\n`);

const child = spawn(nodeExe, [path.join(root, "src", "main.js"), mode], {
  cwd: root,
  env: {
    ...process.env,
    FORCE_COLOR: "0"
  },
  stdio: ["inherit", "pipe", "pipe"]
});

child.stdout.on("data", write);
child.stderr.on("data", write);

child.on("close", (code) => {
  write(`\n程序已结束或已停止。退出码：${code ?? ""}\n`);
  log.end(() => process.exit(code || 0));
});

child.on("error", (error) => {
  write(`\n启动失败：${error.message}\n`);
  log.end(() => process.exit(1));
});

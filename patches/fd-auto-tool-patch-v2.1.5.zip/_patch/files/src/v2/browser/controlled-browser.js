import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import { chromium } from "playwright";

export const DEFAULT_CONTROLLED_BROWSER_PORT = 9333;
export const CONTROLLED_BROWSER_STATE_FILE = "v2-controlled-cms-browser.json";
export const DEFAULT_CONTROLLED_PROFILE_DIR = "./browser-profile";
export const CONTROLLED_CONSOLE_TITLE = "2.0 可视化控制台";

export function controlledBrowserStatePath(projectRoot) {
  return path.join(projectRoot, "runs", CONTROLLED_BROWSER_STATE_FILE);
}

export async function ensureV2ControlledBrowser(options = {}) {
  const projectRoot = options.projectRoot || process.cwd();
  const config = options.config || {};
  const port = Number(options.port || config.cmsDebugPort || DEFAULT_CONTROLLED_BROWSER_PORT);
  const cdpUrl = options.cdpUrl || `http://127.0.0.1:${port}`;
  const profileDir = path.resolve(projectRoot, options.profileDir || config.profileDir || DEFAULT_CONTROLLED_PROFILE_DIR);
  const statePath = controlledBrowserStatePath(projectRoot);
  const targetUrl = String(options.url || "").trim();
  let launchedWithTargetUrl = false;

  await fs.mkdir(path.dirname(statePath), { recursive: true });
  if (!await canReachCdp(cdpUrl)) {
    await fs.mkdir(profileDir, { recursive: true });
    const chromePath = options.chromePath || await findChromePath(projectRoot);
    const args = [
      `--remote-debugging-port=${port}`,
      "--remote-debugging-address=127.0.0.1",
      `--user-data-dir=${profileDir}`,
      "--no-first-run",
      "--no-default-browser-check",
      "--no-sandbox"
    ];
    if (targetUrl) {
      args.push(targetUrl);
      launchedWithTargetUrl = true;
    }
    const child = spawn(chromePath, args, {
      detached: true,
      stdio: "ignore",
      windowsHide: false
    });
    child.unref();
    await waitForCdp(cdpUrl, options.timeoutMs || 15000);
  }

  const state = {
    cdpUrl,
    port,
    profileDir,
    openedAt: new Date().toISOString()
  };
  await fs.writeFile(statePath, JSON.stringify(state, null, 2), "utf8");
  if (targetUrl && options.openUrl !== false && !launchedWithTargetUrl) {
    await openControlledTargetPage(cdpUrl, targetUrl, options).catch(() => {});
  }
  return state;
}

export async function loadV2ControlledBrowserState(projectRoot, config = {}) {
  const state = await readJsonIfExists(controlledBrowserStatePath(projectRoot));
  if (!state) return {};
  const port = Number(state.port || config.cmsDebugPort || DEFAULT_CONTROLLED_BROWSER_PORT);
  const cdpUrl = state.cdpUrl || `http://127.0.0.1:${port}`;
  if (await canReachCdp(cdpUrl)) {
    return {
      cdpUrl,
      port,
      profileDir: state.profileDir || path.resolve(projectRoot, config.profileDir || DEFAULT_CONTROLLED_PROFILE_DIR)
    };
  }
  return {};
}

export async function openOrFocusControlledPage(cdpUrl, url, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  try {
    const context = browser.contexts()[0] || await browser.newContext();
    const page = await reuseOrOpenControlledPageInContext(context, url, {
      reuseSameTarget: true,
      navigateExisting: false,
      ...options
    });
    return page.url?.() || url;
  } finally {
    await disconnectControlledBrowser(browser);
  }
}

export async function openOrFocusConsolePage(cdpUrl, url, options = {}) {
  return openOrReplaceControlledPage(cdpUrl, url, {
    titleIncludes: CONTROLLED_CONSOLE_TITLE,
    onlyLocalhost: true,
    closeExtra: true,
    preferLatest: true,
    ...options
  });
}

export async function openOrReplaceControlledPage(cdpUrl, url, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  try {
    const context = browser.contexts()[0] || await browser.newContext();
    const page = await reuseOrOpenControlledPageInContext(context, url, {
      ...options,
      reuseSameTarget: true,
      navigateExisting: true
    });
    return page.url?.() || url;
  } finally {
    await disconnectControlledBrowser(browser);
  }
}

export async function inspectControlledPages(cdpUrl, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  try {
    const context = browser.contexts()[0] || await browser.newContext();
    return collectControlledPageInfos(context, options);
  } finally {
    await disconnectControlledBrowser(browser);
  }
}

export async function closeMatchingControlledPages(cdpUrl, options = {}) {
  const browser = await chromium.connectOverCDP(cdpUrl);
  let closed = 0;
  try {
    const context = browser.contexts()[0] || await browser.newContext();
    for (const page of context.pages?.() || []) {
      if (page.isClosed?.()) continue;
      const info = await pageInfo(page, options);
      if (!matchesPageInfoOptions(info, options)) continue;
      try {
        await page.close?.();
        closed += 1;
      } catch {}
    }
    return { closed };
  } finally {
    await disconnectControlledBrowser(browser);
  }
}

export async function closeV2ControlledBrowser(projectRoot, config = {}, options = {}) {
  const statePath = controlledBrowserStatePath(projectRoot);
  const state = await readJsonIfExists(statePath);
  if (!state?.cdpUrl && !state?.port && options.allowPortFallback !== true) return { closed: false };
  const port = Number(state?.port || config.cmsDebugPort || DEFAULT_CONTROLLED_BROWSER_PORT);
  const cdpUrl = state?.cdpUrl || `http://127.0.0.1:${port}`;
  let closed = false;
  if (await canReachCdp(cdpUrl)) {
    const browser = await chromium.connectOverCDP(cdpUrl);
    try {
      if (!state?.cdpUrl && !state?.port && !await browserHasV2ControlledPage(browser)) {
        await disconnectControlledBrowser(browser);
        return { closed: false };
      }
      closed = await requestBrowserProcessClose(browser);
      if (!closed) {
        const pageCloseResult = await closeV2ControlledPagesInBrowser(browser);
        await browser.close().catch(() => {});
        closed = pageCloseResult.closed > 0;
      }
    } catch {
      await disconnectControlledBrowser(browser);
    }
  }
  await fs.unlink(statePath).catch((error) => {
    if (error?.code !== "ENOENT") throw error;
  });
  return { closed };
}

async function requestBrowserProcessClose(browser) {
  if (typeof browser?.newBrowserCDPSession !== "function") return false;
  try {
    const session = await browser.newBrowserCDPSession();
    await session.send("Browser.close");
    return true;
  } catch (error) {
    return isBrowserClosingError(error);
  }
}

function isBrowserClosingError(error) {
  const message = String(error?.message || error || "");
  return /Target closed|Browser has been closed|Connection closed|WebSocket is not open|closed/i.test(message);
}

async function closeV2ControlledPagesInBrowser(browser) {
  let closed = 0;
  for (const context of browser.contexts?.() || []) {
    for (const page of context.pages?.() || []) {
      if (page.isClosed?.()) continue;
      const title = await page.title?.().catch(() => "") || "";
      const url = page.url?.() || "";
      const isV2Page = String(title).includes(CONTROLLED_CONSOLE_TITLE)
        || String(title).includes("妙券自动发单 - 预览确认")
        || (isLocalhostUrl(url) && /[?&]controlled=1\b/.test(url));
      if (!isV2Page) continue;
      await page.close?.().then(() => { closed += 1; }).catch(() => {});
    }
  }
  return { closed };
}

async function browserHasV2ControlledPage(browser) {
  for (const context of browser.contexts?.() || []) {
    for (const page of context.pages?.() || []) {
      if (page.isClosed?.()) continue;
      const title = await page.title?.().catch(() => "") || "";
      const url = page.url?.() || "";
      if (String(title).includes(CONTROLLED_CONSOLE_TITLE)) return true;
      if (String(title).includes("妙券自动发单 - 预览确认")) return true;
      if (isLocalhostUrl(url) && /[?&]controlled=1\b/.test(url)) return true;
    }
  }
  return false;
}

export async function reuseOrOpenControlledPageInContext(context, url, options = {}) {
  const pages = (context.pages?.() || []).filter((page) => !page.isClosed?.());
  const matches = [];
  for (let index = 0; index < pages.length; index++) {
    const page = pages[index];
    const info = await pageInfo(page, options);
    const score = reusablePageScore(info, url, options);
    if (score > 0) matches.push({ page, score, index });
  }
  if (matches.length) {
    matches.sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      if (options.preferLatest) return right.index - left.index;
      return left.index - right.index;
    });
    const page = matches[0].page;
    for (const extra of matches.slice(1)) {
      if (options.closeExtra) await extra.page.close?.().catch(() => {});
    }
    if (options.navigateExisting && !sameExactUrl(page.url?.() || "", url)) {
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: options.timeoutMs || 30000 });
    }
    if (options.closeOtherPages) await closeOtherPagesInContext(context, page);
    if (options.bringToFront !== false) await page.bringToFront?.().catch(() => {});
    return page;
  }
  const blank = pages.find((page) => page.url?.() === "about:blank");
  const page = blank || await context.newPage();
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: options.timeoutMs || 30000 });
  if (options.closeOtherPages) await closeOtherPagesInContext(context, page);
  if (options.bringToFront !== false) await page.bringToFront?.().catch(() => {});
  return page;
}

async function closeOtherPagesInContext(context, keepPage) {
  for (const page of context.pages?.() || []) {
    if (!page || page === keepPage || page.isClosed?.()) continue;
    await page.close?.().catch(() => {});
  }
}

export async function collectControlledPageInfos(context, options = {}) {
  const infos = [];
  for (const page of (context.pages?.() || [])) {
    if (page.isClosed?.()) continue;
    infos.push(await pageInfo(page, options));
  }
  return infos.filter((info) => matchesPageInfoOptions(info, options));
}

async function openControlledTargetPage(cdpUrl, url, options = {}) {
  if (options.pageKind === "console" || options.consolePage === true) {
    return openOrFocusConsolePage(cdpUrl, url);
  }
  return openOrFocusControlledPage(cdpUrl, url);
}

export async function canReachCdp(cdpUrl) {
  try {
    const response = await fetch(`${String(cdpUrl).replace(/\/$/, "")}/json/version`, { signal: AbortSignal.timeout(1500) });
    return response.ok;
  } catch {
    return false;
  }
}

async function waitForCdp(cdpUrl, timeoutMs) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await canReachCdp(cdpUrl)) return true;
    await new Promise((resolve) => setTimeout(resolve, 400));
  }
  throw new Error(`2.0 可控浏览器启动失败：无法连接 ${cdpUrl}`);
}

async function findChromePath(projectRoot = process.cwd()) {
  const candidates = [
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    ...await localPlaywrightChromeCandidates(projectRoot),
    chromium.executablePath()
  ];
  for (const candidate of candidates) {
    try {
      await fs.access(candidate);
      return candidate;
    } catch {}
  }
  return chromium.executablePath();
}

async function localPlaywrightChromeCandidates(projectRoot) {
  const root = path.join(projectRoot, "ms-playwright");
  try {
    const entries = await fs.readdir(root, { withFileTypes: true });
    return entries
      .filter((entry) => entry.isDirectory() && /^chromium-\d+$/i.test(entry.name))
      .map((entry) => path.join(root, entry.name, "chrome-win64", "chrome.exe"));
  } catch {
    return [];
  }
}

function sameBrowserTarget(current, target) {
  try {
    const currentUrl = new URL(current);
    const targetUrl = new URL(target);
    return currentUrl.origin === targetUrl.origin && currentUrl.pathname === targetUrl.pathname;
  } catch {
    return current === target;
  }
}

function sameExactUrl(current, target) {
  try {
    return new URL(current).href === new URL(target).href;
  } catch {
    return current === target;
  }
}

async function pageInfo(page, options = {}) {
  const url = page.url?.() || "";
  const title = await page.title?.().catch(() => "") || "";
  const previewDirty = options.includeDirty
    ? await page.evaluate?.(() => Boolean(window.__v2PreviewDirty)).catch(() => false)
    : false;
  return { page, url, title, previewDirty };
}

function reusablePageScore(info, targetUrl, options = {}) {
  if (options.reuseSameTarget !== false && sameExactUrl(info.url, targetUrl)) return 4;
  if (options.reuseSameTarget !== false && sameBrowserTarget(info.url, targetUrl)) return 3;
  return matchesPageInfoOptions(info, options) ? 1 : 0;
}

function matchesPageInfoOptions(info, options = {}) {
  const hasIdentityMatcher = Boolean(options.titleIncludes || options.urlIncludes);
  if (!hasIdentityMatcher) return false;
  if (options.onlyLocalhost && !isLocalhostUrl(info.url)) return false;
  if (options.titleIncludes && !String(info.title || "").includes(options.titleIncludes)) return false;
  if (options.urlIncludes && !String(info.url || "").includes(options.urlIncludes)) return false;
  return true;
}

function isLocalhostUrl(value) {
  try {
    const url = new URL(value);
    return ["127.0.0.1", "localhost"].includes(url.hostname);
  } catch {
    return false;
  }
}

async function disconnectControlledBrowser(browser) {
  if (typeof browser?.disconnect === "function") {
    browser.disconnect();
    return;
  }
  await browser?.close?.().catch(() => {});
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return null;
  }
}

import { inferTuoIntent } from "./tuo-intent.js";
import { normalizeRosterKey } from "./tuo-roster.js";

const DEFAULT_COOLDOWN = 5;
const DEFAULT_CANDIDATE_COUNT = 4;
const GENERIC_PERSONA_TAGS = new Set(["female", "male"]);

export function assignPreciseTuoSpeakers(tasks = [], roster = [], options = {}) {
  const cooldown = Number.isFinite(Number(options.cooldown)) ? Number(options.cooldown) : DEFAULT_COOLDOWN;
  const candidateCount = Math.max(1, Number(options.candidateCount || DEFAULT_CANDIDATE_COUNT));
  const recentByPersona = new Map();
  const usedCounts = new Map();
  const groupAssignments = new Map();
  const assignments = [];
  const nextTasks = tasks.map((task, index) => {
    if (task?.role !== "tuo") return task;
    const intent = inferTuoIntent(task);
    const groupKey = preciseTuoGroupKey(task);
    const existing = groupKey ? groupAssignments.get(groupKey) : null;
    if (existing?.item) {
      assignments.push({
        index: task.index || index + 1,
        sourceId: task.sourceId || "",
        previousSpeaker: task.speaker || "",
        assignedSpeaker: existing.item.nickname,
        remark: existing.item.remark,
        reason: existing.groupReason,
        fallback: existing.fallback,
        backup: existing.item.backup,
        tags: intent.tags,
        candidateSpeakers: existing.candidates.map((item) => item.nickname),
        groupKey
      });
      return applyTuoAssignment(task, existing.item, existing.candidates, intent, {
        reason: existing.groupReason,
        fallback: existing.fallback,
        cooldown,
        cooldownKey: existing.cooldownKey,
        groupKey
      });
    }
    const decision = chooseRosterItem(roster, intent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster
    });
    if (!decision.item) {
      assignments.push({
        index: task.index || index + 1,
        sourceId: task.sourceId || "",
        previousSpeaker: task.speaker || "",
        assignedSpeaker: "",
        reason: "没有可用托名单候选",
        fallback: true,
        backup: false,
        tags: intent.tags
      });
      return task;
    }
    const candidates = chooseRosterCandidates(roster, intent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster,
      limit: candidateCount,
      primaryNickname: decision.item.nickname
    });
    const cooldownKey = rememberUse(decision.item, intent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster
    });
    assignments.push({
      index: task.index || index + 1,
      sourceId: task.sourceId || "",
      previousSpeaker: task.speaker || "",
      assignedSpeaker: decision.item.nickname,
      remark: decision.item.remark,
      reason: decision.reason,
      fallback: decision.fallback,
      backup: decision.item.backup,
      tags: intent.tags,
      candidateSpeakers: candidates.map((item) => item.nickname),
      cooldownKey,
      groupKey
    });
    if (groupKey) {
      groupAssignments.set(groupKey, {
        item: decision.item,
        candidates,
        fallback: decision.fallback,
        cooldownKey,
        groupReason: groupKey.startsWith("interaction:")
          ? `复用同一互动托分配：${decision.reason}`
          : `复用同一原始托分配：${decision.reason}`
      });
    }
    return applyTuoAssignment(task, decision.item, candidates, intent, {
      reason: decision.reason,
      fallback: decision.fallback,
      cooldown,
      cooldownKey,
      groupKey
    });
  });

  return {
    tasks: nextTasks,
    report: buildAssignmentReport(assignments, roster)
  };
}

function applyTuoAssignment(task, item, candidates, intent, options = {}) {
  return {
    ...task,
    speaker: item.nickname,
    cleanSpeaker: item.nickname,
    tuoAssignment: buildTuoAssignment(item, candidates, intent, {
      reason: options.reason,
      fallback: options.fallback,
      cooldown: options.cooldown,
      cooldownKey: options.cooldownKey,
      groupKey: options.groupKey
    })
  };
}

function preciseTuoGroupKey(task = {}) {
  const interactionGroup = String(task.interactionGroup || "").trim();
  if (interactionGroup) return `interaction:${normalizeRosterKey(interactionGroup)}`;
  const speaker = originalTuoSpeakerKey(task);
  return speaker ? `speaker:${speaker}` : "";
}

function originalTuoSpeakerKey(task = {}) {
  const speaker = normalizeRosterKey(task.cleanSpeaker || task.speaker || "");
  if (!speaker || isGenericTuoSpeakerKey(speaker)) return "";
  return speaker;
}

function isGenericTuoSpeakerKey(key) {
  return ["托", "托号", "托儿", "水军", "互动托"].includes(key);
}

export function chooseRosterItem(roster = [], intent = {}, context = {}) {
  const candidates = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!candidates.length) return { item: null, reason: "名单为空", fallback: true };
  const explicitKey = normalizeRosterKey(intent.explicitNickname);
  if (explicitKey) {
    const exact = pickBest(candidates.filter((item) => normalizeRosterKey(item.nickname) === explicitKey), intent, context, { allowBackup: true });
    if (exact) return { item: exact.item, reason: "按文案指定托分配", fallback: false };
  }

  const primary = pickBest(candidates.filter((item) => !item.backup), intent, context, { allowBackup: false });
  if (primary && primary.score > 0) return { item: primary.item, reason: primary.reason, fallback: false };

  const anyPrimary = pickBest(candidates.filter((item) => !item.backup), intent, context, { allowBackup: false, ignoreTags: true });
  if (anyPrimary) return { item: anyPrimary.item, reason: "没有明显身份命中，按最少使用托兜底", fallback: true };

  const backup = pickBest(candidates, intent, context, { allowBackup: true, ignoreTags: true });
  if (backup) return { item: backup.item, reason: "主名单不可用，使用备用托兜底", fallback: true };
  return { item: null, reason: "没有可用候选", fallback: true };
}

export function chooseRosterCandidates(roster = [], intent = {}, context = {}) {
  const limit = Math.max(1, Number(context.limit || DEFAULT_CANDIDATE_COUNT));
  const candidates = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!candidates.length) return [];
  const primaryKey = normalizeRosterKey(context.primaryNickname);
  const exact = primaryKey ? candidates.find((item) => normalizeRosterKey(item.nickname) === primaryKey) : null;
  const scored = rankRosterCandidates(candidates, intent, context, { allowBackup: true })
    .filter((entry) => normalizeRosterKey(entry.item.nickname) !== primaryKey)
    .map((entry) => entry.item);
  const ordered = exact ? [exact, ...scored] : scored;
  const seen = new Set();
  const result = [];
  for (const item of ordered) {
    const key = normalizeRosterKey(item.nickname);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    result.push(item);
    if (result.length >= limit) break;
  }
  return result;
}

function pickBest(candidates, intent, context, options = {}) {
  return rankRosterCandidates(candidates, intent, context, options)[0] || null;
}

function rankRosterCandidates(candidates, intent, context, options = {}) {
  return candidates
    .filter((item) => options.allowBackup || !item.backup)
    .map((item) => scoreCandidate(item, intent, context, options))
    .filter((item) => item.score > -1000)
    .sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      if (left.used !== right.used) return left.used - right.used;
      return left.item.order - right.item.order;
    });
}

function scoreCandidate(item, intent, context, options = {}) {
  const used = context.usedCounts?.get(item.nickname) || 0;
  const recent = recentNicknamesForCandidate(item, intent, context).includes(item.nickname);
  const wantedTags = options.ignoreTags ? [] : intent.tags || [];
  let score = options.ignoreTags ? 1 : 0;
  const matched = [];
  for (const tag of wantedTags) {
    if (item.tags?.includes(tag)) {
      score += tag === "female" || tag === "male" ? 1 : 4;
      matched.push(tag);
    }
  }
  if (!options.ignoreTags && wantedTags.length && !matched.length) score -= 2;
  if (recent) score -= 100;
  if (item.backup) score -= 20;
  score -= used;
  return {
    item,
    score,
    used,
    reason: matched.length ? `身份命中：${matched.join("/")}` : "按最少使用托兜底"
  };
}

function rememberUse(item, intent, context) {
  const nickname = item?.nickname || "";
  if (!nickname) return "";
  const key = cooldownKeyForCandidate(item, intent);
  const recentByPersona = context.recentByPersona;
  const recent = recentByPersona?.get(key) || [];
  const limit = cooldownLimitForKey(context.roster, key, context.cooldown);
  context.usedCounts.set(nickname, (context.usedCounts.get(nickname) || 0) + 1);
  recent.push(nickname);
  while (recent.length > limit) recent.shift();
  recentByPersona?.set(key, recent);
  return key;
}

function recentNicknamesForCandidate(item, intent, context = {}) {
  if (context.recentByPersona) {
    return context.recentByPersona.get(cooldownKeyForCandidate(item, intent)) || [];
  }
  return context.recentNicknames || [];
}

function cooldownLimitForKey(roster = [], key, fallback) {
  const explicit = Number(fallback);
  if (Number.isFinite(explicit) && explicit > 0 && explicit !== DEFAULT_COOLDOWN) return Math.max(1, explicit);
  const count = roster.filter((item) => item?.nickname && candidateMatchesCooldownKey(item, key)).length;
  return Math.max(1, count || DEFAULT_COOLDOWN);
}

function cooldownKeyForCandidate(item = {}, intent = {}) {
  const wanted = (intent.tags || []).filter((tag) => !GENERIC_PERSONA_TAGS.has(tag));
  const matchedSpecific = wanted.find((tag) => item.tags?.includes(tag));
  if (matchedSpecific) return `tag:${matchedSpecific}`;
  const matchedAny = (intent.tags || []).find((tag) => item.tags?.includes(tag));
  if (matchedAny) return `tag:${matchedAny}`;
  const firstSpecific = (item.tags || []).find((tag) => !GENERIC_PERSONA_TAGS.has(tag));
  if (firstSpecific) return `tag:${firstSpecific}`;
  const persona = Array.isArray(item.personas) ? item.personas.find(Boolean) : "";
  if (persona) return `persona:${normalizeRosterKey(persona)}`;
  const firstTag = (item.tags || []).find(Boolean);
  return firstTag ? `tag:${firstTag}` : "all";
}

function candidateMatchesCooldownKey(item = {}, key = "") {
  if (key === "all") return true;
  if (key.startsWith("tag:")) return item.tags?.includes(key.slice(4));
  if (key.startsWith("persona:")) {
    const target = key.slice(8);
    return (item.personas || []).some((label) => normalizeRosterKey(label) === target);
  }
  return false;
}

function buildAssignmentReport(assignments, roster) {
  const assigned = assignments.filter((item) => item.assignedSpeaker);
  return {
    ok: true,
    rosterCount: roster.length,
    rosterOptions: serializeRosterOptions(roster),
    tuoTaskCount: assignments.length,
    assignedCount: assigned.length,
    fallbackCount: assignments.filter((item) => item.fallback).length,
    backupCount: assignments.filter((item) => item.backup).length,
    assignments
  };
}

function serializeRosterOptions(roster = []) {
  const seen = new Set();
  const options = [];
  for (const item of roster) {
    const key = normalizeRosterKey(item.nickname);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    options.push(serializeCandidate(item));
  }
  return options;
}

function buildTuoAssignment(primary, candidates, intent, options = {}) {
  return {
    mode: "precise_roster",
    cooldown: options.cooldown || DEFAULT_COOLDOWN,
    cooldownMode: "persona_rotation",
    cooldownKey: options.cooldownKey || "",
    groupKey: options.groupKey || "",
    reason: options.reason || "",
    fallback: Boolean(options.fallback),
    intentTags: intent.tags || [],
    intentReasons: intent.reasons || [],
    primary: serializeCandidate(primary),
    candidates: candidates.map(serializeCandidate)
  };
}

function serializeCandidate(item = {}) {
  return {
    nickname: item.nickname || "",
    remark: item.remark || "",
    tags: item.tags || [],
    personas: item.personas || [],
    auxTags: item.auxTags || [],
    backup: Boolean(item.backup),
    order: item.order ?? 0
  };
}

import fs from "node:fs/promises";
import path from "node:path";
import { inflateRawSync } from "node:zlib";
import iconv from "iconv-lite";

export async function loadTuoRoster(filePath, options = {}) {
  const resolvedPath = resolveRosterPath(filePath, options.projectRoot);
  if (!resolvedPath) throw new Error("精准托模式需要填写托名单文件路径。");
  const buffer = await fs.readFile(resolvedPath);
  const ext = path.extname(resolvedPath).toLowerCase();
  const rows = ext === ".xlsx"
    ? parseRosterXlsxBuffer(buffer)
    : parseRosterText(decodeRosterBuffer(buffer), ext);
  const roster = normalizeTuoRosterRows(rows);
  if (!roster.length) throw new Error("托名单没有读取到可用的昵称和备注。");
  return { roster, filePath: resolvedPath };
}

export function parseRosterText(text, ext = "") {
  const content = stripBom(String(text || ""));
  if (ext === ".json" || looksLikeJson(content)) {
    const parsed = JSON.parse(content);
    if (Array.isArray(parsed)) return parsed;
    if (Array.isArray(parsed.rows)) return parsed.rows;
    if (Array.isArray(parsed.items)) return parsed.items;
    throw new Error("托名单 JSON 需要是数组，或包含 rows/items 数组。");
  }
  return parseCsv(content);
}

export function parseRosterXlsxBuffer(buffer) {
  const files = readZipFiles(buffer);
  const workbook = xmlText(files, "xl/workbook.xml");
  const rels = xmlText(files, "xl/_rels/workbook.xml.rels");
  const sheetPath = resolveFirstSheetPath(workbook, rels);
  const sharedStrings = parseSharedStrings(xmlText(files, "xl/sharedStrings.xml", false));
  const rows = parseSheetRows(xmlText(files, sheetPath), sharedStrings);
  return rowsToObjectsByHeader(rows);
}

export function normalizeTuoRosterRows(rows = []) {
  const normalized = [];
  const seenKeys = new Set();
  let order = 0;
  for (const row of rows) {
    const nickname = pickCell(row, ["昵称", "nick", "nickname", "name"]).trim();
    if (!nickname) continue;
    const remark = pickCell(row, ["备注", "remark", "note", "persona"]).trim();
    const persona = parseRosterRemark(remark);
    const item = {
      id: `${normalizeRosterKey(nickname)}:${order}`,
      nickname,
      remark,
      backup: persona.backup,
      tags: persona.tags,
      personas: persona.personas,
      auxTags: persona.auxTags,
      age: persona.age,
      city: persona.city,
      order
    };
    const key = `${normalizeRosterKey(nickname)}|${normalizeRosterKey(remark)}`;
    if (seenKeys.has(key)) continue;
    seenKeys.add(key);
    normalized.push(item);
    order += 1;
  }
  return normalized;
}

export function parseRosterRemark(remark) {
  const text = String(remark || "").trim();
  const tags = new Set();
  if (/备用/.test(text)) tags.add("backup");
  if (/宝妈|可宝妈|妈妈|带娃|母婴/.test(text)) tags.add("mom");
  if (/成熟女性|成熟|中年|45\+|40\+|50\+|[4-7]\d岁/.test(text)) tags.add("mature");
  if (/年轻女性|年轻|少女|学生|25\+|28\+|30\+/.test(text)) tags.add("young");
  if (/工作|上班|职场|办公室/.test(text)) tags.add("work");
  if (/男性|男/.test(text)) tags.add("male");
  if (/女性|女|宝妈|妈妈/.test(text)) tags.add("female");
  const age = extractAge(text);
  const city = extractCity(text);
  const parsedLabels = parseRosterPersonaLabels(text, { city });
  return {
    tags: [...tags].filter((tag) => tag !== "backup"),
    personas: parsedLabels.personas,
    auxTags: parsedLabels.auxTags,
    backup: tags.has("backup"),
    age,
    city
  };
}

export function normalizeRosterKey(value) {
  return String(value || "")
    .replace(/\s+/g, "")
    .replace(/[【】\[\]（）()<>《》]/g, "")
    .toLowerCase();
}

function resolveRosterPath(filePath, projectRoot = "") {
  const raw = String(filePath || "").trim().replace(/^["']|["']$/g, "");
  if (!raw) return "";
  if (path.isAbsolute(raw)) return raw;
  return path.resolve(projectRoot || process.cwd(), raw);
}

function stripBom(value) {
  return value.charCodeAt(0) === 0xfeff ? value.slice(1) : value;
}

function decodeRosterBuffer(buffer) {
  if (buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) return buffer.toString("utf8");
  const utf8 = buffer.toString("utf8");
  if (!utf8.includes("\ufffd")) return utf8;
  return iconv.decode(buffer, "gb18030");
}

function looksLikeJson(content) {
  const trimmed = content.trim();
  return trimmed.startsWith("[") || trimmed.startsWith("{");
}

function pickCell(row, names) {
  if (!row || typeof row !== "object") return "";
  for (const name of names) {
    if (row[name] !== undefined && row[name] !== null) return String(row[name]);
  }
  const entries = Object.entries(row);
  for (const [key, value] of entries) {
    const normalizedKey = normalizeRosterKey(key);
    if (names.some((name) => normalizeRosterKey(name) === normalizedKey)) return String(value ?? "");
  }
  return "";
}

function parseCsv(content) {
  const rows = splitCsvRows(content);
  if (!rows.length) return [];
  const headers = rows[0].map((cell) => cell.trim());
  return rows.slice(1)
    .filter((row) => row.some((cell) => String(cell || "").trim()))
    .map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index] ?? ""])));
}

function rowsToObjectsByHeader(rows) {
  const headerIndex = rows.findIndex((row) => {
    const headers = row.map((cell) => normalizeRosterKey(cell));
    return headers.includes(normalizeRosterKey("昵称")) && headers.includes(normalizeRosterKey("备注"));
  });
  if (headerIndex < 0) return [];
  const headers = rows[headerIndex].map((cell) => String(cell || "").trim());
  return rows.slice(headerIndex + 1)
    .filter((row) => row.some((cell) => String(cell || "").trim()))
    .map((row) => Object.fromEntries(Array.from({ length: headers.length }, (_, index) => [headers[index] || `__empty_${index}`, row[index] ?? ""])));
}

function readZipFiles(buffer) {
  const data = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  const eocdOffset = findEndOfCentralDirectory(data);
  const entryCount = data.readUInt16LE(eocdOffset + 10);
  const centralOffset = data.readUInt32LE(eocdOffset + 16);
  const files = new Map();
  let offset = centralOffset;
  for (let index = 0; index < entryCount; index += 1) {
    if (data.readUInt32LE(offset) !== 0x02014b50) throw new Error("XLSX 文件目录结构无效。");
    const method = data.readUInt16LE(offset + 10);
    const compressedSize = data.readUInt32LE(offset + 20);
    const fileNameLength = data.readUInt16LE(offset + 28);
    const extraLength = data.readUInt16LE(offset + 30);
    const commentLength = data.readUInt16LE(offset + 32);
    const localOffset = data.readUInt32LE(offset + 42);
    const fileName = data.slice(offset + 46, offset + 46 + fileNameLength).toString("utf8").replace(/\\/g, "/");
    files.set(fileName, extractZipEntry(data, localOffset, compressedSize, method));
    offset += 46 + fileNameLength + extraLength + commentLength;
  }
  return files;
}

function findEndOfCentralDirectory(buffer) {
  const minOffset = Math.max(0, buffer.length - 65557);
  for (let offset = buffer.length - 22; offset >= minOffset; offset -= 1) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) return offset;
  }
  throw new Error("无法识别 XLSX 文件。");
}

function extractZipEntry(buffer, localOffset, compressedSize, method) {
  if (buffer.readUInt32LE(localOffset) !== 0x04034b50) throw new Error("XLSX 文件条目结构无效。");
  const fileNameLength = buffer.readUInt16LE(localOffset + 26);
  const extraLength = buffer.readUInt16LE(localOffset + 28);
  const dataStart = localOffset + 30 + fileNameLength + extraLength;
  const compressed = buffer.slice(dataStart, dataStart + compressedSize);
  if (method === 0) return compressed;
  if (method === 8) return inflateRawSync(compressed);
  throw new Error(`XLSX 压缩格式暂不支持：${method}`);
}

function xmlText(files, filePath, required = true) {
  const value = files.get(filePath);
  if (value) return value.toString("utf8");
  if (required) throw new Error(`XLSX 缺少必要文件：${filePath}`);
  return "";
}

function resolveFirstSheetPath(workbookXml, relsXml) {
  const sheetMatch = workbookXml.match(/<sheet\b[^>]*\br:id="([^"]+)"/);
  const firstRid = sheetMatch?.[1] || "";
  if (!firstRid) return "xl/worksheets/sheet1.xml";
  const relPattern = new RegExp(`<Relationship\\b[^>]*\\bId="${escapeRegExp(firstRid)}"[^>]*\\bTarget="([^"]+)"`, "i");
  const relMatch = relsXml.match(relPattern);
  const target = decodeXml(relMatch?.[1] || "worksheets/sheet1.xml").replace(/\\/g, "/").replace(/^\//, "");
  return target.startsWith("xl/") ? target : `xl/${target}`;
}

function parseSharedStrings(xml) {
  if (!xml) return [];
  const strings = [];
  for (const match of xml.matchAll(/<si\b[^>]*>([\s\S]*?)<\/si>/g)) {
    strings.push(extractTextNodes(match[1]));
  }
  return strings;
}

function parseSheetRows(xml, sharedStrings) {
  const rows = [];
  for (const rowMatch of xml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)) {
    const row = [];
    for (const cellMatch of rowMatch[1].matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>|<c\b([^>]*)\/>/g)) {
      const attrs = cellMatch[1] || cellMatch[3] || "";
      const body = cellMatch[2] || "";
      const columnIndex = columnIndexFromCellRef(attributeValue(attrs, "r")) ?? row.length;
      row[columnIndex] = readCellValue(attrs, body, sharedStrings);
    }
    rows.push(row.map((cell) => cell ?? ""));
  }
  return rows;
}

function readCellValue(attrs, body, sharedStrings) {
  const type = attributeValue(attrs, "t");
  if (type === "inlineStr") return extractTextNodes(body);
  const rawValue = decodeXml(body.match(/<v>([\s\S]*?)<\/v>/)?.[1] || "");
  if (type === "s") return sharedStrings[Number(rawValue)] || "";
  if (type === "str") return rawValue;
  return rawValue;
}

function attributeValue(attrs, name) {
  const match = String(attrs || "").match(new RegExp(`\\b${escapeRegExp(name)}="([^"]*)"`));
  return match ? decodeXml(match[1]) : "";
}

function columnIndexFromCellRef(ref) {
  const letters = String(ref || "").match(/^[A-Z]+/i)?.[0];
  if (!letters) return null;
  let index = 0;
  for (const char of letters.toUpperCase()) index = index * 26 + char.charCodeAt(0) - 64;
  return index - 1;
}

function extractTextNodes(xml) {
  return [...String(xml || "").matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)]
    .map((match) => decodeXml(match[1]))
    .join("");
}

function decodeXml(value) {
  return String(value || "")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&");
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function splitCsvRows(content) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < content.length; index += 1) {
    const char = content[index];
    const next = content[index + 1];
    if (quoted && char === "\"" && next === "\"") {
      cell += "\"";
      index += 1;
      continue;
    }
    if (char === "\"") {
      quoted = !quoted;
      continue;
    }
    if (!quoted && char === ",") {
      row.push(cell);
      cell = "";
      continue;
    }
    if (!quoted && (char === "\n" || char === "\r")) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    cell += char;
  }
  row.push(cell);
  if (row.some((item) => item !== "")) rows.push(row);
  return rows;
}

function extractAge(text) {
  const direct = String(text || "").match(/(\d{2})\s*岁/);
  if (direct) return Number(direct[1]);
  const plus = String(text || "").match(/(\d{2})\s*\+/);
  if (plus) return Number(plus[1]);
  return null;
}

function parseRosterPersonaLabels(text, context = {}) {
  const personas = [];
  const auxTags = [];
  const seenPersonas = new Set();
  const seenAux = new Set();
  for (const rawToken of splitRemarkTokens(text)) {
    const token = normalizePersonaToken(rawToken);
    if (!token) continue;
    if (isAuxPersonaToken(token)) {
      pushUnique(auxTags, seenAux, token);
      continue;
    }
    if (isNonPersonaToken(token, context)) continue;
    pushUnique(personas, seenPersonas, token);
  }
  return { personas, auxTags };
}

function splitRemarkTokens(text) {
  return String(text || "")
    .replace(/[()（）【】\[\]<>《》]/g, " ")
    .split(/[|｜/、，,;；\s]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function normalizePersonaToken(value) {
  return String(value || "")
    .trim()
    .replace(/^备用/, "")
    .replace(/备用$/, "")
    .trim();
}

function isAuxPersonaToken(token) {
  return /^(无头像|没头像|无头象|动物头|风景图|风景头像|真人头像|头像)$/i.test(token);
}

function isNonPersonaToken(token, context = {}) {
  if (!token || token === "备用") return true;
  if (isBusinessPersonaToken(token)) return false;
  if (/^T\d+$/i.test(token)) return true;
  if (/^\d+岁$/.test(token)) return true;
  if (/^\d+\+$/.test(token)) return true;
  if (/^\d{1,2}-\d{1,2}$/.test(token)) return true;
  if (/^wxid_/i.test(token)) return true;
  if (context.city && token === context.city) return true;
  if (/^[\u4e00-\u9fa5]{2,4}$/.test(token) && token === extractCity(token)) return true;
  return false;
}

function isBusinessPersonaToken(token) {
  return /^可/.test(token) || /宝妈|妈妈|工作|学生|女性|男性|成熟|年轻|退休|上班|职场|大学生/.test(token);
}

function pushUnique(target, seen, value) {
  const key = normalizeRosterKey(value);
  if (!key || seen.has(key)) return;
  seen.add(key);
  target.push(value);
}

function extractCity(text) {
  const chunks = String(text || "").split(/[|｜/、，,\s]+/).map((item) => item.trim()).filter(Boolean);
  for (const chunk of chunks) {
    if (/^T\d+$/i.test(chunk)) continue;
    if (/^\d+岁$/.test(chunk)) continue;
    if (/^\d+\+$/.test(chunk)) continue;
    if (/备用|女性|男性|宝妈|工作|成熟|年轻|无头像/.test(chunk)) continue;
    if (/^[\u4e00-\u9fa5]{2,4}$/.test(chunk)) return chunk;
  }
  return "";
}

#!/usr/bin/env python3
import argparse
import base64
import datetime as dt
import hashlib
import hmac
import html
import ipaddress
import json
import os
import re
import secrets
import shutil
import socket
import tempfile
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ACTIONS = {"launch", "generate-preview", "prepare-cms", "start-cms", "cli-start-cms"}
REQUEST_ACTION = "request-access"
HEARTBEAT_ACTION = "heartbeat"
USAGE_REPORT_ACTION = "usage-report"
SHARED_LIBRARY_ACTIONS = {"shared-library-list", "shared-library-upload", "shared-library-download", "shared-library-delete"}
LIMITS = {"companyId": 64, "deviceId": 128, "appVersion": 32, "action": 32}
MAX_BODY = 4096
MAX_SHARED_BODY = 250 * 1024 * 1024
INTERNAL_NETS = [ipaddress.ip_network("10.0.0.0/8")]
REPORT_TZ = dt.timezone(dt.timedelta(hours=8))
DEFAULT_LATEST_CLIENT_VERSION = "2.1.6"
ADMIN_SESSION_COOKIE = "mq_admin"
ADMIN_SESSION_TTL_SECONDS = 12 * 60 * 60
PASSWORD_HASH_ITERATIONS = 180000
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")


def now_iso():
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def result(allowed, code, message):
    return {"allowed": allowed, "code": code, "message": message}


def parse_iso(value):
    try:
        parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt.timezone.utc)
    except (ValueError, TypeError):
        return None


def version_parts(value):
    parts = []
    for item in str(value or "").lstrip("v").split("."):
        try:
            parts.append(int("".join(ch for ch in item if ch.isdigit()) or "0"))
        except ValueError:
            parts.append(0)
    return parts[:4]


def compare_versions(left, right):
    a = version_parts(left)
    b = version_parts(right)
    size = max(len(a), len(b), 1)
    a += [0] * (size - len(a))
    b += [0] * (size - len(b))
    return (a > b) - (a < b)


def load_json(path, fallback):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return fallback


def atomic_write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def device_ref(device_id):
    return hashlib.sha256(str(device_id).encode()).hexdigest()[:12]


def read_policy(server):
    if server.policy_path.stat().st_size > 65536:
        raise RuntimeError("policy too large")
    return json.loads(server.policy_path.read_text(encoding="utf-8"))


def write_policy(server, policy):
    backup = server.policy_path.with_name(f"policy.json.bak-{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}")
    try:
        backup.write_text(server.policy_path.read_text(encoding="utf-8"), encoding="utf-8")
    except FileNotFoundError:
        pass
    atomic_write_json(server.policy_path, policy)


def check(payload, policy, now=None):
    if not isinstance(payload, dict) or set(payload) != set(LIMITS):
        return 400, result(False, "INVALID_REQUEST", "授权请求格式错误。")
    if any(not isinstance(payload[k], str) or not payload[k].strip() or len(payload[k]) > size for k, size in LIMITS.items()):
        return 400, result(False, "INVALID_REQUEST", "授权请求格式错误。")
    if payload["action"] not in ACTIONS:
        return 400, result(False, "INVALID_ACTION", "该操作不在授权范围内。")
    if not isinstance(policy, dict) or policy.get("enabled") is not True or payload["companyId"] != policy.get("companyId"):
        return 403, result(False, "COMPANY_DENIED", "公司授权未配置。")
    device = policy.get("devices", {}).get(payload["deviceId"])
    if not isinstance(device, dict) or device.get("enabled") is not True:
        return 403, result(False, "DEVICE_DENIED", "设备未授权，请点击申请授权。")
    if payload["appVersion"] in policy.get("blockedVersions", []):
        return 403, result(False, "VERSION_BLOCKED", "当前版本已停用，请更新后再使用。")
    if payload["action"] not in device.get("actions", []):
        return 403, result(False, "ACTION_DENIED", "该设备未授权执行此操作。")
    expiry = device.get("expiresAt")
    if expiry is not None:
        try:
            end = dt.datetime.fromisoformat(expiry.replace("Z", "+00:00"))
            if end.tzinfo is None:
                raise ValueError("timezone required")
            expired = end <= (now or dt.datetime.now(dt.timezone.utc))
        except (ValueError, TypeError, AttributeError):
            return 403, result(False, "EXPIRY_INVALID", "授权有效期配置错误，请联系管理员。")
        if expired:
            return 403, result(False, "EXPIRED", "设备授权已过期。")
    response = result(True, "ALLOWED", "授权通过。")
    response["company"] = str(policy.get("company", ""))[:64]
    return 200, response


def validate_request_payload(payload, policy):
    if not isinstance(payload, dict):
        return "授权申请格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action"}
    if not required.issubset(set(payload)) or payload.get("action") != REQUEST_ACTION:
        return "授权申请格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        if key == "action":
            continue
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "授权申请格式错误。"
    computer = payload.get("computerName", "")
    if computer is not None and (not isinstance(computer, str) or len(computer) > 80):
        return "电脑名称格式错误。"
    return ""


def record_request(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_request_payload(payload, policy)
    if reason:
        return 400, {"allowed": False, "code": "INVALID_REQUEST", "message": reason}
    device_id = payload["deviceId"]
    device = policy.get("devices", {}).get(device_id)
    if isinstance(device, dict) and device.get("enabled") is True:
        return 200, {"allowed": True, "code": "ALREADY_ALLOWED", "message": "这台电脑已授权。"}
    requests = load_json(server.requests_path, {"requests": {}})
    items = requests.setdefault("requests", {})
    previous = items.get(device_id, {}) if isinstance(items.get(device_id), dict) else {}
    ts = now_iso()
    items[device_id] = {
        "deviceId": device_id,
        "deviceRef": device_ref(device_id),
        "computerName": str(payload.get("computerName") or "")[:80],
        "appVersion": str(payload.get("appVersion") or "")[:32],
        "sourceIp": source_ip,
        "status": "pending",
        "requestedAt": previous.get("requestedAt") or ts,
        "updatedAt": ts,
    }
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "request", "deviceRef": device_ref(device_id), "computerName": items[device_id]["computerName"], "sourceIp": source_ip})
    return 200, {"allowed": False, "code": "REQUEST_RECORDED", "message": "授权申请已提交，请等待管理员审批。"}


def validate_heartbeat_payload(payload, policy):
    if not isinstance(payload, dict):
        return "心跳格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action"}
    if not required.issubset(set(payload)) or payload.get("action") != HEARTBEAT_ACTION:
        return "心跳格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "心跳格式错误。"
    computer = payload.get("computerName", "")
    if computer is not None and (not isinstance(computer, str) or len(computer) > 80):
        return "电脑名称格式错误。"
    update = payload.get("update", {})
    if update is not None and not isinstance(update, dict):
        return "更新状态格式错误。"
    return ""


def record_heartbeat(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_heartbeat_payload(payload, policy)
    if reason:
        return 400, {"allowed": False, "code": "INVALID_HEARTBEAT", "message": reason}
    device_id = payload["deviceId"]
    device = policy.get("devices", {}).get(device_id)
    authorized = isinstance(device, dict) and device.get("enabled") is True
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {
        "deviceId": device_id,
        "deviceRef": device_ref(device_id),
        "requestedAt": now_iso(),
        "status": "approved" if authorized else "pending",
    })
    update = payload.get("update") if isinstance(payload.get("update"), dict) else {}
    ts = now_iso()
    item["deviceId"] = device_id
    item["deviceRef"] = device_ref(device_id)
    item["computerName"] = str(payload.get("computerName") or item.get("computerName") or "")[:80]
    item["appVersion"] = str(payload.get("appVersion") or "")[:32]
    item["sourceIp"] = source_ip
    item["lastHeartbeatAt"] = ts
    item["lastSeenAt"] = ts
    item["updatedAt"] = ts
    item["status"] = "approved" if authorized else item.get("status") or "pending"
    item["updateStatus"] = {
        "currentVersion": str(update.get("currentVersion") or payload.get("appVersion") or "")[:32],
        "latestVersion": str(update.get("latestVersion") or "")[:32],
        "updateAvailable": update.get("updateAvailable") is True,
        "pendingUpdateReady": update.get("pendingUpdateReady") is True,
        "updateMode": str(update.get("updateMode") or "")[:16],
        "status": str(update.get("status") or "")[:32],
    }
    atomic_write_json(server.requests_path, requests)
    return 200 if authorized else 403, {
        "allowed": authorized,
        "code": "HEARTBEAT_RECORDED" if authorized else "DEVICE_DENIED",
        "message": "心跳已记录。" if authorized else "设备未授权，请点击申请授权。"
    }


def validate_usage_report_payload(payload, policy):
    if not isinstance(payload, dict):
        return "使用记录格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action", "usage"}
    if not required.issubset(set(payload)) or payload.get("action") != USAGE_REPORT_ACTION:
        return "使用记录格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "使用记录格式错误。"
    computer = payload.get("computerName", "")
    if computer is not None and (not isinstance(computer, str) or len(computer) > 80):
        return "电脑名称格式错误。"
    usage = payload.get("usage")
    if not isinstance(usage, dict):
        return "使用记录格式错误。"
    if usage.get("event") not in {"start", "finish"}:
        return "使用记录事件错误。"
    if usage.get("status") not in {"running", "completed", "failed", "stopped"}:
        return "使用记录状态错误。"
    if len(str(usage.get("runId") or "")) > 96:
        return "使用记录 runId 过长。"
    return ""


def clean_usage_report(payload, source_ip):
    usage = payload.get("usage") if isinstance(payload.get("usage"), dict) else {}
    def text(key, limit=80):
        return str(usage.get(key) or "")[:limit]
    def nonnegative_int(key, limit=1000000):
        try:
            value = int(float(usage.get(key) or 0))
        except (TypeError, ValueError):
            value = 0
        return max(0, min(limit, value))
    ts = now_iso()
    return {
        "id": f"{int(time.time() * 1000)}-{secrets.token_hex(3)}",
        "recordedAt": ts,
        "companyId": str(payload.get("companyId") or "")[:64],
        "deviceId": payload["deviceId"],
        "deviceRef": device_ref(payload["deviceId"]),
        "computerName": str(payload.get("computerName") or "")[:80],
        "appVersion": str(payload.get("appVersion") or "")[:32],
        "sourceIp": source_ip,
        "event": text("event", 16),
        "source": text("source", 32),
        "runId": text("runId", 96),
        "status": text("status", 16),
        "startedAt": text("startedAt", 40),
        "finishedAt": text("finishedAt", 40),
        "durationMs": nonnegative_int("durationMs", 7 * 24 * 60 * 60 * 1000),
        "plannedCount": nonnegative_int("plannedCount"),
        "successCount": nonnegative_int("successCount"),
        "failureCount": nonnegative_int("failureCount"),
        "stopped": usage.get("stopped") is True,
        "stage": text("stage", 80),
        "reason": text("reason", 240),
        "action": text("action", 80),
        "taskIndex": nonnegative_int("taskIndex"),
        "totalCount": nonnegative_int("totalCount"),
        "taskRole": text("taskRole", 24),
        "taskType": text("taskType", 24),
        "taskDate": text("taskDate", 24),
        "taskTime": text("taskTime", 24),
    }


def record_usage_report(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_usage_report_payload(payload, policy)
    if reason:
        return 400, {"allowed": False, "code": "INVALID_USAGE", "message": reason}
    device_id = payload["deviceId"]
    device = policy.get("devices", {}).get(device_id)
    authorized = isinstance(device, dict) and device.get("enabled") is True
    if not authorized:
        return 403, {"allowed": False, "code": "DEVICE_DENIED", "message": "设备未授权，请点击申请授权。"}
    store = load_json(server.usage_events_path, {"events": []})
    events = store.get("events", [])
    if not isinstance(events, list):
        events = []
    event = clean_usage_report(payload, source_ip)
    events.append(event)
    store["events"] = events[-50000:]
    atomic_write_json(server.usage_events_path, store)
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {
        "deviceId": device_id,
        "deviceRef": device_ref(device_id),
        "requestedAt": now_iso(),
        "status": "approved",
    })
    item["computerName"] = event["computerName"] or item.get("computerName", "")
    item["appVersion"] = event["appVersion"]
    item["sourceIp"] = source_ip
    item["lastUsageAt"] = event["recordedAt"]
    item["updatedAt"] = event["recordedAt"]
    item["status"] = "approved"
    atomic_write_json(server.requests_path, requests)
    return 200, {"allowed": True, "code": "USAGE_RECORDED", "message": "使用记录已记录。"}


def validate_shared_payload(payload, policy):
    if not isinstance(payload, dict):
        return "共享文案请求格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action"}
    if not required.issubset(set(payload)) or payload.get("action") not in SHARED_LIBRARY_ACTIONS:
        return "共享文案请求格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "共享文案请求格式错误。"
    return ""


def shared_device(policy, device_id):
    device = policy.get("devices", {}).get(device_id)
    return device if isinstance(device, dict) and device.get("enabled") is True else None


def can_upload_shared_library(policy, device_id, device):
    shared = policy.get("sharedLibrary", {})
    if isinstance(shared, dict):
        upload_ids = shared.get("uploadDeviceIds", [])
        if isinstance(upload_ids, list) and device_id in upload_ids:
            return True
        if shared.get("allowAllUploads") is True:
            return True
    return device.get("sharedLibraryUpload") is True or "shared-library-upload" in device.get("actions", [])


def shared_library_root(server):
    root = getattr(server, "shared_library_root", None) or server.policy_path.with_name("shared-preview-library")
    root.mkdir(parents=True, exist_ok=True)
    return root


def shared_library_index_path(server):
    return shared_library_root(server) / "index.json"


def load_shared_library_index(server):
    data = load_json(shared_library_index_path(server), {"items": []})
    items = data.get("items", [])
    return {"items": items if isinstance(items, list) else []}


def write_shared_library_index(server, index):
    atomic_write_json(shared_library_index_path(server), {"items": index.get("items", [])})


def safe_cloud_id(value):
    text = str(value or "").strip()
    return text if re.match(r"^[A-Za-z0-9_.-]{1,80}$", text) else ""


def clean_shared_name(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()[:80] or "未命名文案"


def shared_package_hash(package):
    return hashlib.sha256(json.dumps(package, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def shared_library_list(server):
    index = load_shared_library_index(server)
    items = sorted(index["items"], key=lambda item: str(item.get("updatedAt") or item.get("uploadedAt") or ""), reverse=True)
    return [{
        "cloudId": item.get("cloudId", ""),
        "name": item.get("name", ""),
        "taskCount": item.get("taskCount", 0),
        "cloudVersion": item.get("cloudVersion", 0),
        "updatedAt": item.get("updatedAt", ""),
        "uploadedAt": item.get("uploadedAt", ""),
        "packageHash": item.get("packageHash", ""),
        "packageBytes": item.get("packageBytes", 0),
        "uploadedByDeviceRef": item.get("uploadedByDeviceRef", ""),
        "sourceIp": item.get("sourceIp", "")
    } for item in items]


def shared_item_dir(server, cloud_id):
    root = shared_library_root(server)
    item_dir = root / cloud_id
    resolved = item_dir.resolve()
    if not str(resolved).startswith(str(root.resolve()) + os.sep):
        raise ValueError("bad path")
    return item_dir


def upload_shared_library(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_shared_payload(payload, policy)
    if reason:
        return 400, {"ok": False, "message": reason}
    device_id = payload["deviceId"]
    device = shared_device(policy, device_id)
    if not device:
        return 403, {"ok": False, "message": "设备未授权，不能使用共享文案。"}
    if not can_upload_shared_library(policy, device_id, device):
        return 403, {"ok": False, "message": "本设备没有上传共享文案权限。"}
    package = payload.get("library")
    if not isinstance(package, dict) or int(package.get("schemaVersion") or 0) != 1:
        return 400, {"ok": False, "message": "共享文案包格式错误。"}
    if not isinstance(package.get("mediaFiles", []), list):
        return 400, {"ok": False, "message": "共享文案素材格式错误。"}
    package_json = json.dumps(package, ensure_ascii=False, separators=(",", ":"))
    package_bytes = len(package_json.encode("utf-8"))
    if package_bytes > MAX_SHARED_BODY:
        return 413, {"ok": False, "message": "共享文案包太大，超过服务器限制。请改用“导出共享包”手动发送。"}
    cloud_id = safe_cloud_id(package.get("cloudId")) or f"shared_{int(time.time() * 1000)}_{secrets.token_hex(4)}"
    index = load_shared_library_index(server)
    existing = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    ts = now_iso()
    item = {
        "cloudId": cloud_id,
        "name": clean_shared_name(package.get("name")),
        "taskCount": max(0, min(100000, int(package.get("taskCount") or 0))),
        "cloudVersion": int((existing or {}).get("cloudVersion") or 0) + 1,
        "updatedAt": str(package.get("updatedAt") or ts)[:40],
        "uploadedAt": ts,
        "uploadedByDeviceRef": device_ref(device_id),
        "packageHash": shared_package_hash(package),
        "packageBytes": package_bytes,
        "sourceIp": source_ip,
    }
    item_dir = shared_item_dir(server, cloud_id)
    item_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(item_dir / "package.json", package)
    index["items"] = [item] + [old for old in index["items"] if old.get("cloudId") != cloud_id]
    write_shared_library_index(server, index)
    append_audit(server, {"event": "shared-library-upload", "cloudId": cloud_id, "deviceRef": device_ref(device_id), "sourceIp": source_ip})
    return 200, {"ok": True, "item": item, "message": "共享文案已上传。"}


def download_shared_library(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_shared_payload(payload, policy)
    if reason:
        return 400, {"ok": False, "message": reason}
    device_id = payload["deviceId"]
    if not shared_device(policy, device_id):
        return 403, {"ok": False, "message": "设备未授权，不能使用共享文案。"}
    cloud_id = safe_cloud_id(payload.get("cloudId"))
    if not cloud_id:
        return 400, {"ok": False, "message": "没有指定云端文案。"}
    index = load_shared_library_index(server)
    item = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    if not item:
        return 404, {"ok": False, "message": "云端文案不存在。"}
    package = load_json(shared_item_dir(server, cloud_id) / "package.json", None)
    if not isinstance(package, dict):
        return 404, {"ok": False, "message": "云端文案包缺失。"}
    append_audit(server, {"event": "shared-library-download", "cloudId": cloud_id, "deviceRef": device_ref(device_id), "sourceIp": source_ip})
    return 200, {"ok": True, "item": item, "package": package}


def delete_shared_library(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_shared_payload(payload, policy)
    if reason:
        return 400, {"ok": False, "message": reason}
    device_id = payload["deviceId"]
    if not shared_device(policy, device_id):
        return 403, {"ok": False, "message": "设备未授权，不能管理共享文案。"}
    cloud_id = safe_cloud_id(payload.get("cloudId"))
    if not cloud_id:
        return 400, {"ok": False, "message": "没有指定云端文案。"}
    index = load_shared_library_index(server)
    item = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    if not item:
        return 404, {"ok": False, "message": "云端文案不存在或已经删除。"}
    index["items"] = [old for old in index["items"] if old.get("cloudId") != cloud_id]
    write_shared_library_index(server, index)
    shutil.rmtree(shared_item_dir(server, cloud_id), ignore_errors=True)
    append_audit(server, {"event": "shared-library-delete", "cloudId": cloud_id, "deviceRef": device_ref(device_id), "sourceIp": source_ip})
    return 200, {"ok": True, "deleted": item, "message": "云端文案已删除。"}


def handle_shared_library_action(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_shared_payload(payload, policy)
    if reason:
        return 400, {"ok": False, "message": reason}
    if not shared_device(policy, payload["deviceId"]):
        return 403, {"ok": False, "message": "设备未授权，不能使用共享文案。"}
    if payload["action"] == "shared-library-list":
        return 200, {"ok": True, "items": shared_library_list(server)}
    if payload["action"] == "shared-library-upload":
        return upload_shared_library(server, payload, source_ip)
    if payload["action"] == "shared-library-download":
        return download_shared_library(server, payload, source_ip)
    if payload["action"] == "shared-library-delete":
        return delete_shared_library(server, payload, source_ip)
    return 400, {"ok": False, "message": "共享文案操作不支持。"}


def admin_delete_shared_library(server, cloud_id, admin="web"):
    cloud_id = safe_cloud_id(cloud_id)
    if not cloud_id:
        return False, "没有指定云端文案。"
    index = load_shared_library_index(server)
    item = next((item for item in index["items"] if item.get("cloudId") == cloud_id), None)
    if not item:
        return False, "云端文案不存在或已经删除。"
    index["items"] = [old for old in index["items"] if old.get("cloudId") != cloud_id]
    write_shared_library_index(server, index)
    shutil.rmtree(shared_item_dir(server, cloud_id), ignore_errors=True)
    append_audit(server, {"event": "admin-shared-library-delete", "cloudId": cloud_id, "admin": admin})
    return True, "云端文案已删除。"


def append_audit(server, event):
    event = {"time": now_iso(), **event}
    with server.audit_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")


def b64url(data):
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(value):
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def hash_admin_password(password, salt=None):
    password = str(password or "")
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_HASH_ITERATIONS)
    return f"pbkdf2_sha256${PASSWORD_HASH_ITERATIONS}${b64url(salt)}${b64url(digest)}"


def verify_admin_password(password, encoded):
    parts = str(encoded or "").split("$")
    if len(parts) != 4 or parts[0] != "pbkdf2_sha256":
        return False
    try:
        iterations = int(parts[1])
        salt = b64url_decode(parts[2])
        expected = b64url_decode(parts[3])
    except (ValueError, TypeError):
        return False
    digest = hashlib.pbkdf2_hmac("sha256", str(password or "").encode("utf-8"), salt, iterations)
    return secrets.compare_digest(digest, expected)


def valid_admin_username(username):
    return bool(USERNAME_RE.fullmatch(str(username or "")))


def load_admin_users(server):
    users = load_json(server.admin_users_path, {"users": {}})
    return users if isinstance(users, dict) and isinstance(users.get("users"), dict) else {"users": {}}


def write_admin_users(server, users):
    atomic_write_json(server.admin_users_path, users)
    try:
        os.chmod(server.admin_users_path, 0o640)
    except OSError:
        pass


def admin_public_user(username, user):
    return {
        "username": username,
        "displayName": str(user.get("displayName") or "")[:80],
        "role": "owner" if user.get("role") == "owner" else "manager",
        "enabled": user.get("enabled") is True,
        "createdAt": user.get("createdAt", ""),
        "updatedAt": user.get("updatedAt", ""),
        "lastLoginAt": user.get("lastLoginAt", ""),
        "lastLoginIp": user.get("lastLoginIp", ""),
        "lastLoginAgent": str(user.get("lastLoginAgent") or "")[:160],
    }


def list_admin_users(server):
    users = load_admin_users(server).get("users", {})
    items = [admin_public_user(name, user) for name, user in users.items() if isinstance(user, dict)]
    return sorted(items, key=lambda item: (item["role"] != "owner", item["username"]))


def admin_user_by_name(server, username):
    users = load_admin_users(server).get("users", {})
    user = users.get(str(username or ""))
    return user if isinstance(user, dict) else None


def set_admin_user(server, username, password="", display_name="", role="manager", enabled=True, actor="system"):
    username = str(username or "").strip()
    if not valid_admin_username(username):
        return False, "账号只能使用 3-32 位英文、数字、点、横线或下划线。"
    if password is not None and password != "" and len(str(password)) < 8:
        return False, "密码至少 8 位。"
    users = load_admin_users(server)
    item = users.setdefault("users", {}).setdefault(username, {})
    now = now_iso()
    item.setdefault("createdAt", now)
    item["displayName"] = str(display_name or item.get("displayName") or username)[:80]
    item["role"] = "owner" if role == "owner" else "manager"
    item["enabled"] = enabled is True
    item["updatedAt"] = now
    item["updatedBy"] = actor
    if password:
        item["passwordHash"] = hash_admin_password(password)
        item["passwordChangedAt"] = now
    write_admin_users(server, users)
    append_audit(server, {"event": "admin-user-set", "username": username, "role": item["role"], "enabled": item["enabled"], "admin": actor})
    return True, "管理员账号已保存。"


def update_admin_user_enabled(server, username, enabled, actor="system"):
    users = load_admin_users(server)
    item = users.get("users", {}).get(str(username or ""))
    if not isinstance(item, dict):
        return False, "管理员账号不存在。"
    if item.get("role") == "owner" and enabled is False:
        owners = [user for user in users.get("users", {}).values() if isinstance(user, dict) and user.get("role") == "owner" and user.get("enabled") is True]
        if len(owners) <= 1:
            return False, "至少保留一个启用的总管理员账号。"
    item["enabled"] = enabled is True
    item["updatedAt"] = now_iso()
    item["updatedBy"] = actor
    write_admin_users(server, users)
    append_audit(server, {"event": "admin-user-enabled", "username": username, "enabled": item["enabled"], "admin": actor})
    return True, "管理员账号状态已更新。"


def reset_admin_password(server, username, password, actor="system"):
    if len(str(password or "")) < 8:
        return False, "密码至少 8 位。"
    users = load_admin_users(server)
    item = users.get("users", {}).get(str(username or ""))
    if not isinstance(item, dict):
        return False, "管理员账号不存在。"
    item["passwordHash"] = hash_admin_password(password)
    item["passwordChangedAt"] = now_iso()
    item["updatedAt"] = item["passwordChangedAt"]
    item["updatedBy"] = actor
    write_admin_users(server, users)
    append_audit(server, {"event": "admin-user-password-reset", "username": username, "admin": actor})
    return True, "密码已重置。"


def session_signature(server, username, expires, password_hash):
    message = f"{username}|{expires}|{password_hash}".encode("utf-8")
    return hmac.new(server.admin_token.encode("utf-8"), message, hashlib.sha256).hexdigest()


def make_admin_session_cookie(server, username, user):
    expires = int(time.time()) + ADMIN_SESSION_TTL_SECONDS
    sig = session_signature(server, username, expires, user.get("passwordHash", ""))
    value = f"{username}.{expires}.{sig}"
    return f"{ADMIN_SESSION_COOKIE}={value}; Path=/admin; HttpOnly; SameSite=Lax; Max-Age={ADMIN_SESSION_TTL_SECONDS}"


def expire_admin_session_cookie():
    return f"{ADMIN_SESSION_COOKIE}=; Path=/admin; HttpOnly; SameSite=Lax; Max-Age=0"


def cookie_value(handler, name):
    header = handler.headers.get("Cookie", "")
    for part in header.split(";"):
        if "=" not in part:
            continue
        key, value = part.strip().split("=", 1)
        if key == name:
            return value
    return ""


def admin_from_session(server, handler):
    value = cookie_value(handler, ADMIN_SESSION_COOKIE)
    parts = value.split(".")
    if len(parts) != 3:
        return None
    username, expires, sig = parts
    if not valid_admin_username(username):
        return None
    try:
        expires_int = int(expires)
    except ValueError:
        return None
    if expires_int < int(time.time()):
        return None
    user = admin_user_by_name(server, username)
    if not user or user.get("enabled") is not True:
        return None
    expected = session_signature(server, username, expires_int, user.get("passwordHash", ""))
    if not secrets.compare_digest(sig, expected):
        return None
    return admin_public_user(username, user)


def admin_source_allowed(handler):
    try:
        ip = ipaddress.ip_address(handler.client_address[0])
        return any(ip in net for net in INTERNAL_NETS)
    except ValueError:
        return False


def authorized_admin(server, handler, query=None):
    query = query or parse_qs(urlparse(handler.path).query)
    token = (query.get("token") or [""])[0]
    if not token or not secrets.compare_digest(token, server.admin_token):
        return False
    return admin_source_allowed(handler)


def current_admin(server, handler, query=None):
    if not admin_source_allowed(handler):
        return None
    if authorized_admin(server, handler, query):
        return {"username": "token-admin", "displayName": "Token 管理员", "role": "owner", "enabled": True, "token": True}
    return admin_from_session(server, handler)


def require_admin(server, handler, query=None):
    admin = current_admin(server, handler, query)
    return admin if admin and admin.get("enabled") is True else None


def login_admin(server, username, password, source_ip="", user_agent=""):
    username = str(username or "").strip()
    user = admin_user_by_name(server, username)
    if not user or user.get("enabled") is not True or not verify_admin_password(password, user.get("passwordHash")):
        return False, "账号或密码错误，或账号已停用。", None
    users = load_admin_users(server)
    item = users.get("users", {}).get(username)
    if isinstance(item, dict):
        item["lastLoginAt"] = now_iso()
        item["lastLoginIp"] = source_ip
        item["lastLoginAgent"] = str(user_agent or "")[:160]
        write_admin_users(server, users)
    append_audit(server, {"event": "admin-login", "username": username, "sourceIp": source_ip})
    return True, "登录成功。", admin_public_user(username, user)


def pending_items(server):
    requests = load_json(server.requests_path, {"requests": {}}).get("requests", {})
    if not isinstance(requests, dict):
        return []
    now = dt.datetime.now(dt.timezone.utc)
    latest_client_version = configured_latest_client_version(server)
    policy = read_policy(server)
    enriched = []
    for item in requests.values():
        if not isinstance(item, dict):
            continue
        enriched.append(enrich_admin_item(item, now, latest_client_version, policy))
    return sorted(enriched, key=lambda item: item.get("updatedAt", ""), reverse=True)


def usage_report(server, period="week"):
    start, end, label = report_period(period)
    requests = load_json(server.requests_path, {"requests": {}}).get("requests", {})
    store = load_json(server.usage_events_path, {"events": []})
    rows = {}
    for event in store.get("events", []):
      if not isinstance(event, dict) or event.get("event") != "finish":
          continue
      finished = parse_iso(event.get("finishedAt")) or parse_iso(event.get("recordedAt"))
      if not finished or finished < start or finished >= end:
          continue
      device_id = event.get("deviceId") or ""
      if not device_id:
          continue
      device_item = requests.get(device_id, {}) if isinstance(requests, dict) else {}
      row = rows.setdefault(device_id, {
          "deviceId": device_id,
          "deviceRef": event.get("deviceRef") or device_ref(device_id),
          "computerName": event.get("computerName") or device_item.get("computerName") or "",
          "appVersion": event.get("appVersion") or device_item.get("appVersion") or "",
          "sourceIp": event.get("sourceIp") or device_item.get("sourceIp") or "",
          "runCount": 0,
          "completedCount": 0,
          "failedCount": 0,
          "stoppedCount": 0,
          "durationMs": 0,
          "plannedCount": 0,
          "successCount": 0,
          "failureCount": 0,
          "lastUsageAt": "",
      })
      row["computerName"] = event.get("computerName") or row["computerName"]
      row["appVersion"] = event.get("appVersion") or row["appVersion"]
      row["sourceIp"] = event.get("sourceIp") or row["sourceIp"]
      row["runCount"] += 1
      status = event.get("status")
      if status == "completed":
          row["completedCount"] += 1
      elif status == "stopped":
          row["stoppedCount"] += 1
      else:
          row["failedCount"] += 1
      row["durationMs"] += int(event.get("durationMs") or 0)
      row["plannedCount"] += int(event.get("plannedCount") or 0)
      row["successCount"] += int(event.get("successCount") or 0)
      row["failureCount"] += int(event.get("failureCount") or 0)
      row["lastUsageAt"] = max(row["lastUsageAt"], event.get("finishedAt") or event.get("recordedAt") or "")
    items = sorted(rows.values(), key=lambda item: (item.get("lastUsageAt", ""), item.get("computerName", "")), reverse=True)
    return {
        "period": period if period in {"today", "week", "last_week"} else "week",
        "label": label,
        "start": start.isoformat().replace("+00:00", "Z"),
        "end": end.isoformat().replace("+00:00", "Z"),
        "items": items,
    }


def usage_detail(server, period="week", device_id=""):
    start, end, label = report_period(period)
    device_id = str(device_id or "")[:128]
    store = load_json(server.usage_events_path, {"events": []})
    records = []
    for event in store.get("events", []):
      if not isinstance(event, dict) or event.get("event") != "finish":
          continue
      if device_id and event.get("deviceId") != device_id:
          continue
      finished = parse_iso(event.get("finishedAt")) or parse_iso(event.get("recordedAt"))
      if not finished or finished < start or finished >= end:
          continue
      records.append({
          "id": event.get("id", ""),
          "computerName": event.get("computerName", ""),
          "appVersion": event.get("appVersion", ""),
          "sourceIp": event.get("sourceIp", ""),
          "runId": event.get("runId", ""),
          "status": event.get("status", ""),
          "startedAt": event.get("startedAt", ""),
          "finishedAt": event.get("finishedAt") or event.get("recordedAt", ""),
          "durationMs": int(event.get("durationMs") or 0),
          "plannedCount": int(event.get("plannedCount") or 0),
          "successCount": int(event.get("successCount") or 0),
          "failureCount": int(event.get("failureCount") or 0),
          "stage": event.get("stage", ""),
          "reason": event.get("reason", ""),
          "action": event.get("action", ""),
          "taskIndex": int(event.get("taskIndex") or 0),
          "totalCount": int(event.get("totalCount") or 0),
          "taskRole": event.get("taskRole", ""),
          "taskType": event.get("taskType", ""),
          "taskDate": event.get("taskDate", ""),
          "taskTime": event.get("taskTime", ""),
      })
    records.sort(key=lambda item: item.get("finishedAt", ""), reverse=True)
    return {
        "period": period if period in {"today", "week", "last_week"} else "week",
        "label": label,
        "start": start.isoformat().replace("+00:00", "Z"),
        "end": end.isoformat().replace("+00:00", "Z"),
        "deviceId": device_id,
        "items": records[:100],
    }


def report_period(period):
    now = dt.datetime.now(REPORT_TZ)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_start = today - dt.timedelta(days=today.weekday())
    if period == "today":
        start = today
        end = today + dt.timedelta(days=1)
        label = "今日"
    elif period == "last_week":
        start = week_start - dt.timedelta(days=7)
        end = week_start
        label = "上周"
    else:
        start = week_start
        end = week_start + dt.timedelta(days=7)
        label = "本周"
    return start.astimezone(dt.timezone.utc), end.astimezone(dt.timezone.utc), label


def configured_latest_client_version(server):
    try:
        policy = read_policy(server)
        value = str(policy.get("latestClientVersion") or "").strip()
        return value[:32] or DEFAULT_LATEST_CLIENT_VERSION
    except Exception:
        return DEFAULT_LATEST_CLIENT_VERSION


def newer_version(left, right):
    if not left:
        return right or ""
    if not right:
        return left or ""
    return left if compare_versions(left, right) >= 0 else right


def enrich_admin_item(item, now, latest_client_version="", policy=None):
    next_item = dict(item)
    device = (policy or {}).get("devices", {}).get(item.get("deviceId") or "")
    heartbeat = parse_iso(item.get("lastHeartbeatAt"))
    age = (now - heartbeat).total_seconds() if heartbeat else None
    if age is None:
        online = {"state": "unknown", "label": "未上报", "ageSeconds": None}
    elif age <= 60:
        online = {"state": "online", "label": "在线", "ageSeconds": int(age)}
    elif age <= 300:
        online = {"state": "stale", "label": "可能离线", "ageSeconds": int(age)}
    else:
        online = {"state": "offline", "label": "离线", "ageSeconds": int(age)}
    update = item.get("updateStatus") if isinstance(item.get("updateStatus"), dict) else {}
    current = update.get("currentVersion") or item.get("appVersion") or ""
    latest = newer_version(update.get("latestVersion") or "", latest_client_version or "")
    if update.get("pendingUpdateReady") is True:
        downloaded = update.get("latestVersion") or latest
        latest_label = f"下次启动更新到 {downloaded or '新版本'}"
        latest_state = "ready"
        update_action = {"state": "ready", "label": "已下载待重启"}
    elif update.get("status") == "failed":
        latest_label = "检查失败"
        latest_state = "failed"
        update_action = {"state": "failed", "label": "检查失败"}
    elif latest and compare_versions(latest, current) > 0:
        latest_label = f"待更新到 {latest}"
        latest_state = "outdated"
        update_action = {"state": "outdated", "label": f"待更新到 {latest}"}
    elif current:
        latest_label = "最新"
        latest_state = "latest"
        update_action = {"state": "latest", "label": "已是最新"}
    else:
        latest_label = "未知"
        latest_state = "unknown"
        update_action = {"state": "unknown", "label": "-"}
    next_item["online"] = online
    next_item["latestState"] = {"state": latest_state, "label": latest_label}
    next_item["updateAction"] = update_action
    next_item["sharedLibraryUpload"] = isinstance(device, dict) and can_upload_shared_library(policy or {}, item.get("deviceId") or "", device)
    return next_item


def approve_device(server, device_id, admin="web"):
    if not isinstance(device_id, str) or len(device_id) > 128:
        return False, "设备号格式错误。"
    policy = read_policy(server)
    devices = policy.setdefault("devices", {})
    previous_device = devices.get(device_id) if isinstance(devices, dict) else {}
    devices[device_id] = {
        "enabled": True,
        "actions": sorted(ACTIONS),
        "expiresAt": None,
        "sharedLibraryUpload": isinstance(previous_device, dict) and previous_device.get("sharedLibraryUpload") is True,
    }
    write_policy(server, policy)
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {"deviceId": device_id, "deviceRef": device_ref(device_id)})
    item["status"] = "approved"
    item["approvedAt"] = now_iso()
    item["updatedAt"] = item["approvedAt"]
    item["approvedBy"] = admin
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "approve", "deviceRef": device_ref(device_id), "admin": admin})
    return True, "已通过授权。"


def reject_device(server, device_id, admin="web"):
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {"deviceId": device_id, "deviceRef": device_ref(device_id)})
    item["status"] = "rejected"
    item["rejectedAt"] = now_iso()
    item["updatedAt"] = item["rejectedAt"]
    item["rejectedBy"] = admin
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "reject", "deviceRef": device_ref(device_id), "admin": admin})
    return True, "已拒绝申请。"


def update_shared_library_upload_permission(server, device_id, enabled, admin="web"):
    if not isinstance(device_id, str) or len(device_id) > 128:
        return False, "设备号格式错误。"
    policy = read_policy(server)
    device = policy.setdefault("devices", {}).setdefault(device_id, {
        "enabled": False,
        "actions": sorted(ACTIONS),
        "expiresAt": None,
    })
    if not isinstance(device, dict):
        return False, "设备号格式错误。"
    device["sharedLibraryUpload"] = enabled is True
    write_policy(server, policy)
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {"deviceId": device_id, "deviceRef": device_ref(device_id)})
    item["updatedAt"] = now_iso()
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "shared-library-upload-permission", "deviceRef": device_ref(device_id), "enabled": enabled is True, "admin": admin})
    return True, "已允许上传共享文案。" if enabled is True else "已禁止上传共享文案。"


class Handler(BaseHTTPRequestHandler):
    server_version = "License"
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(1.0)

    def log_message(self, *_):
        pass

    def reply(self, status, body, content_type="application/json; charset=utf-8", headers=None):
        raw = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(raw)
        self.close_connection = True

    def read_json(self, max_body=MAX_BODY, timeout_seconds=0.8):
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            raise ValueError("content-type")
        length_header = self.headers.get_all("Content-Length", [])
        if len(length_header) != 1 or self.headers.get("Transfer-Encoding"):
            raise ValueError("length")
        length = int(length_header[0])
        if length <= 0 or length > max_body:
            raise OverflowError()
        deadline = time.monotonic() + timeout_seconds
        data = bytearray()
        while len(data) < length:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError()
            self.connection.settimeout(remaining)
            part = self.rfile.read1(length - len(data))
            if not part:
                raise ValueError("incomplete")
            data.extend(part)
        return json.loads(data)

    def source_ip(self):
        forwarded = self.headers.get("X-Forwarded-For", "").split(",", 1)[0].strip()
        return forwarded or self.client_address[0]

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/admin/api/requests":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "requests": pending_items(self.server)})
            return
        if parsed.path == "/admin/api/usage-report":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "report": usage_report(self.server, (query.get("range") or ["week"])[0])})
            return
        if parsed.path == "/admin/api/usage-detail":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "detail": usage_detail(self.server, (query.get("range") or ["week"])[0], (query.get("deviceId") or [""])[0])})
            return
        if parsed.path == "/admin/api/me":
            admin = require_admin(self.server, self, parse_qs(parsed.query))
            if not admin:
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "admin": admin})
            return
        if parsed.path == "/admin/api/admin-users":
            admin = require_admin(self.server, self, parse_qs(parsed.query))
            if not admin or admin.get("role") != "owner":
                self.reply(403, result(False, "ADMIN_DENIED", "只有总管理员可以管理后台账号。"))
                return
            self.reply(200, {"ok": True, "users": list_admin_users(self.server)})
            return
        if parsed.path == "/admin/api/shared-library":
            admin = require_admin(self.server, self, parse_qs(parsed.query))
            if not admin:
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "items": shared_library_list(self.server)})
            return
        if parsed.path == "/admin":
            query = parse_qs(parsed.query)
            if not require_admin(self.server, self, query):
                self.reply(200, LOGIN_PAGE.encode("utf-8"), "text/html; charset=utf-8")
                return
            token = html.escape((query.get("token") or [""])[0], quote=True)
            page = ADMIN_PAGE.replace("__TOKEN__", token).encode("utf-8")
            self.reply(200, page, "text/html; charset=utf-8")
            return
        self.reply(404, result(False, "NOT_FOUND", "授权接口不存在。"))

    do_HEAD = do_GET
    do_PUT = do_GET
    do_DELETE = do_GET
    do_OPTIONS = do_GET

    def do_POST(self):
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/admin/login":
                if not admin_source_allowed(self):
                    self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                    return
                payload = self.read_json()
                ok, message, admin = login_admin(self.server, payload.get("username", ""), payload.get("password", ""), self.source_ip(), self.headers.get("User-Agent", ""))
                headers = {"Set-Cookie": make_admin_session_cookie(self.server, admin["username"], admin_user_by_name(self.server, admin["username"]))} if ok else None
                self.reply(200 if ok else 403, {"ok": ok, "message": message, "admin": admin}, headers=headers)
                return
            if parsed.path == "/admin/logout":
                self.reply(200, {"ok": True, "message": "已退出。"}, headers={"Set-Cookie": expire_admin_session_cookie()})
                return
            if parsed.path.startswith("/admin/api/"):
                payload = self.read_json()
                query = {"token": [payload.get("token", "")]}
                admin = require_admin(self.server, self, query)
                if not admin:
                    self.reply(403, result(False, "ADMIN_DENIED", "无权操作授权总控。"))
                    return
                device_id = payload.get("deviceId", "")
                if parsed.path == "/admin/api/approve":
                    ok, message = approve_device(self.server, device_id, admin.get("username", "web"))
                elif parsed.path == "/admin/api/reject":
                    ok, message = reject_device(self.server, device_id, admin.get("username", "web"))
                elif parsed.path == "/admin/api/shared-upload":
                    ok, message = update_shared_library_upload_permission(self.server, device_id, payload.get("enabled") is True, admin.get("username", "web"))
                elif parsed.path == "/admin/api/shared-library/delete":
                    ok, message = admin_delete_shared_library(self.server, payload.get("cloudId", ""), admin.get("username", "web"))
                elif parsed.path == "/admin/api/admin-users/save":
                    if admin.get("role") != "owner":
                        self.reply(403, result(False, "ADMIN_DENIED", "只有总管理员可以管理后台账号。"))
                        return
                    ok, message = set_admin_user(self.server, payload.get("username", ""), payload.get("password", ""), payload.get("displayName", ""), payload.get("role", "manager"), payload.get("enabled", True), admin.get("username", "web"))
                elif parsed.path == "/admin/api/admin-users/enabled":
                    if admin.get("role") != "owner":
                        self.reply(403, result(False, "ADMIN_DENIED", "只有总管理员可以管理后台账号。"))
                        return
                    ok, message = update_admin_user_enabled(self.server, payload.get("username", ""), payload.get("enabled") is True, admin.get("username", "web"))
                elif parsed.path == "/admin/api/admin-users/reset-password":
                    if admin.get("role") != "owner":
                        self.reply(403, result(False, "ADMIN_DENIED", "只有总管理员可以管理后台账号。"))
                        return
                    ok, message = reset_admin_password(self.server, payload.get("username", ""), payload.get("password", ""), admin.get("username", "web"))
                else:
                    self.reply(404, result(False, "NOT_FOUND", "授权接口不存在。"))
                    return
                self.reply(200 if ok else 400, {"ok": ok, "message": message})
                return
            if parsed.path != "/license/check":
                self.do_GET()
                return
            if ipaddress.ip_address(self.client_address[0]) not in self.server.gateway_ips:
                self.reply(403, result(False, "SOURCE_DENIED", "请通过公司授权网关访问。"))
                return
            payload = self.read_json(max_body=MAX_SHARED_BODY, timeout_seconds=60)
            if isinstance(payload, dict) and payload.get("action") == REQUEST_ACTION:
                status, body = record_request(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            if isinstance(payload, dict) and payload.get("action") == HEARTBEAT_ACTION:
                status, body = record_heartbeat(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            if isinstance(payload, dict) and payload.get("action") == USAGE_REPORT_ACTION:
                status, body = record_usage_report(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            if isinstance(payload, dict) and payload.get("action") in SHARED_LIBRARY_ACTIONS:
                status, body = handle_shared_library_action(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            policy = read_policy(self.server)
            status, body = check(payload, policy)
            self.reply(status, body)
            record = {
                "action": payload.get("action") if isinstance(payload, dict) and payload.get("action") in ACTIONS else "invalid",
                "version": payload.get("appVersion") if isinstance(payload, dict) and isinstance(payload.get("appVersion"), str) else "invalid",
                "allowed": body["allowed"],
                "code": body["code"],
            }
            if isinstance(payload, dict) and isinstance(payload.get("deviceId"), str):
                record["deviceRef"] = device_ref(payload["deviceId"])
            print(json.dumps(record, ensure_ascii=False), flush=True)
        except OverflowError:
            self.reply(413, result(False, "BODY_SIZE", "请求内容太大。若是在上传共享文案，请改用“导出共享包”手动发送。"))
        except (socket.timeout, TimeoutError):
            self.reply(408, result(False, "REQUEST_TIMEOUT", "授权请求超时。"))
        except (ValueError, UnicodeError, json.JSONDecodeError):
            self.reply(400, result(False, "INVALID_REQUEST", "授权请求格式错误。"))
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            self.reply(503, result(False, "SERVICE_UNAVAILABLE", "授权服务暂不可用。"))


LOGIN_PAGE = """<!doctype html><meta charset="utf-8"><title>授权总控登录</title>
<style>
*{box-sizing:border-box}body{font-family:Arial,"Microsoft YaHei",sans-serif;margin:0;min-height:100vh;display:grid;place-items:center;background:#f3f6fb;color:#122033}.box{width:min(420px,calc(100vw - 32px));background:#fff;border:1px solid #d8e2f0;border-radius:10px;padding:26px;box-shadow:0 18px 45px rgba(15,23,42,.12)}h1{font-size:24px;margin:0 0 6px}p{margin:0 0 20px;color:#64748b}label{display:grid;gap:6px;margin:12px 0;font-weight:700}input{min-height:40px;border:1px solid #cbd5e1;border-radius:7px;padding:8px 10px;font-size:15px}button{width:100%;min-height:42px;margin-top:12px;border:1px solid #2563eb;background:#2563eb;color:#fff;border-radius:7px;font-weight:700}.msg{min-height:20px;color:#b91c1c;margin-top:12px}
</style>
<div class="box"><h1>妙券授权总控</h1><p>请输入管理员账号密码。</p><label>账号<input id="username" autocomplete="username"></label><label>密码<input id="password" type="password" autocomplete="current-password"></label><button onclick="login()">登录</button><div id="msg" class="msg"></div></div>
<script>
async function login(){const r=await fetch("/admin/login",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({username:username.value.trim(),password:password.value})});const data=await r.json().catch(()=>({message:"登录失败。"}));if(data.ok){location.href="/admin";return;}msg.textContent=data.message||"登录失败。";}
password.addEventListener("keydown",e=>{if(e.key==="Enter")login();});
</script>"""


ADMIN_PAGE = """<!doctype html><meta charset="utf-8"><title>授权总控</title>
<style>
*{box-sizing:border-box}body{font-family:Arial,"Microsoft YaHei",sans-serif;margin:0;background:#f3f6fb;color:#122033}.layout{display:flex;min-height:100vh}.side{width:208px;background:#0f172a;color:#dbe7ff;padding:18px 14px;position:sticky;top:0;height:100vh}.brand{font-size:19px;font-weight:700;margin:0 0 6px}.hint{color:#94a3b8;font-size:12px;line-height:1.6;margin:0 0 18px}.nav{display:block;width:100%;border:0;background:transparent;color:#cbd5e1;text-align:left;padding:11px 12px;border-radius:8px;margin:5px 0;cursor:pointer}.nav:hover{background:#1e293b}.nav.active{background:#2563eb;color:#fff}.badge{float:right;background:#ef4444;color:#fff;border-radius:999px;min-width:22px;text-align:center;padding:1px 6px;font-size:12px}.main{flex:1;padding:22px 26px 40px;min-width:0}.top{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin-bottom:16px}.top h1{font-size:24px;margin:0 0 6px}.top p{margin:0;color:#64748b}.refresh{min-height:36px;padding:0 14px;border:1px solid #93c5fd;background:#fff;color:#1d4ed8;border-radius:7px}.cards{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:12px;margin:14px 0 18px}.card{background:#fff;border:1px solid #d8e2f0;border-radius:8px;padding:13px}.card strong{display:block;font-size:26px;margin-top:6px}.warn{border-color:#f59e0b;background:#fff7ed}.panel{background:#fff;border:1px solid #d8e2f0;border-radius:8px;padding:14px;margin:14px 0 18px}.panel h2{font-size:18px;margin:0 0 10px}.section[hidden]{display:none}table{border-collapse:collapse;width:100%;background:#fff;margin-bottom:18px}td,th{border:1px solid #d8e2f0;padding:8px;text-align:left;vertical-align:top}th{background:#eef4fb;white-space:nowrap}button,select,input{min-height:32px;margin-right:8px}input,select{border:1px solid #cbd5e1;border-radius:6px;padding:5px 8px}label{font-weight:700;color:#334155}.primary{background:#2563eb;color:#fff;border:1px solid #2563eb;border-radius:6px;padding:0 12px}.danger{background:#fff;color:#b91c1c;border:1px solid #fca5a5;border-radius:6px;padding:0 12px}.muted{color:#64748b}.pending{color:#b45309;font-weight:700}.approved{color:#166534;font-weight:700}.rejected{color:#b91c1c;font-weight:700}.online{color:#166534;font-weight:700}.stale{color:#b45309;font-weight:700}.offline,.failed{color:#b91c1c;font-weight:700}.latest{color:#166534;font-weight:700}.outdated{color:#1d4ed8;font-weight:700}.ready{color:#7c3aed;font-weight:700}.unknown{color:#64748b;font-weight:700}.sub{display:block;color:#64748b;font-size:12px;margin-top:3px}.num{text-align:right;font-variant-numeric:tabular-nums}.mini{min-height:26px;padding:2px 8px;margin-left:8px}.device{font-family:monospace;max-width:260px;word-break:break-all}.empty{padding:24px;color:#64748b;text-align:center}.modal{position:fixed;inset:0;background:rgba(15,23,42,.35);display:flex;align-items:flex-start;justify-content:center;padding:48px 24px;z-index:10}.modal[hidden]{display:none}.modal-box{background:#fff;border:1px solid #cbd5e1;max-width:1280px;width:100%;max-height:82vh;overflow:auto;padding:16px;box-shadow:0 18px 45px rgba(15,23,42,.22)}.modal-head{display:flex;align-items:center;justify-content:space-between;gap:12px}.scene{min-width:260px}.reason{max-width:360px;word-break:break-word}@media(max-width:980px){.layout{display:block}.side{position:static;width:auto;height:auto}.cards{grid-template-columns:repeat(2,minmax(140px,1fr))}.main{padding:16px;overflow:auto}}
</style>
<div class="layout"><aside class="side"><div class="brand">妙券授权总控</div><p class="hint">只处理设备授权，不启动发单流程。页面每 30 秒自动刷新。</p><button class="nav active" data-tab="pending" onclick="setTab('pending')">待授权 <span id="pendingBadge" class="badge">0</span></button><button class="nav" data-tab="approved" onclick="setTab('approved')">已授权 <span id="approvedBadge" class="badge">0</span></button><button class="nav" data-tab="sharedLibrary" onclick="setTab('sharedLibrary')">共享文案</button><button class="nav" data-tab="usage" onclick="setTab('usage')">使用报表</button><button id="adminUsersNav" class="nav" data-tab="adminUsers" onclick="setTab('adminUsers')" hidden>管理员账号</button></aside><main class="main"><div class="top"><div><h1 id="pageTitle">待授权</h1><p id="pageDesc">优先处理新设备授权申请。</p><span id="currentAdmin" class="sub"></span></div><button class="refresh" onclick="load()">刷新</button></div><div class="cards"><div class="card warn"><span>待授权</span><strong id="pendingCount">0</strong></div><div class="card"><span>已授权</span><strong id="approvedCount">0</strong></div><div class="card"><span>离线/未上报</span><strong id="offlineCount">0</strong></div><div class="card"><span>待更新</span><strong id="outdatedCount">0</strong></div></div>
<section id="pendingSection" class="section"><div class="panel"><h2>待授权设备</h2><span id="pendingTip" class="sub"></span></div><table><thead><tr><th>状态</th><th>电脑名</th><th>版本</th><th>是否最新</th><th>在线状态</th><th>来源</th><th>申请时间</th><th>设备号</th><th>操作</th></tr></thead><tbody id="pendingRows"></tbody></table></section>
<section id="approvedSection" class="section" hidden><div class="panel"><h2>已授权设备</h2><span class="sub">已通过的设备可单独开关“上传共享文案”资格；下载/使用云端文案仍只要求设备已授权。</span></div><table><thead><tr><th>电脑名</th><th>版本</th><th>是否最新</th><th>在线状态</th><th>更新状态</th><th>共享上传</th><th>来源</th><th>申请时间</th><th>设备号</th></tr></thead><tbody id="approvedRows"></tbody></table></section>
<section id="sharedLibrarySection" class="section" hidden><div class="panel"><h2>共享文案</h2><span class="sub">这里显示所有已上传到云端的共享文案。删除只删除云端共享副本，不影响别人已经下载到本机的文案。</span></div><table><thead><tr><th>文案名称</th><th>条数</th><th>大小</th><th>云端版本</th><th>上传时间</th><th>上传设备</th><th>来源</th><th>操作</th></tr></thead><tbody id="sharedLibraryRows"></tbody></table></section>
<section id="usageSection" class="section" hidden><div class="panel"><h2>使用报表</h2><label>范围 <select id="usageRange" onchange="loadUsage()"><option value="today">今日</option><option value="week" selected>本周</option><option value="last_week">上周</option></select></label><span id="usageTitle" class="sub"></span></div><table><thead><tr><th>电脑名</th><th>版本</th><th>使用次数</th><th>总时长</th><th>平均时长</th><th>任务数</th><th>成功</th><th>失败</th><th>完成/失败/中止</th><th>最后使用</th><th>来源</th></tr></thead><tbody id="usageRows"></tbody></table></section>
<section id="adminUsersSection" class="section" hidden><div class="panel"><h2>管理员账号</h2><span class="sub">每个管理者单独账号。停用后，这个账号即使知道密码也不能登录。</span><div style="display:grid;grid-template-columns:140px 180px 180px 120px 100px auto;gap:8px;margin-top:12px;align-items:end"><label>账号<input id="newAdminUsername" placeholder="manager01"></label><label>显示名称/电脑备注<input id="newAdminDisplay" placeholder="张三-电脑"></label><label>密码<input id="newAdminPassword" placeholder="至少 8 位"></label><label>角色<select id="newAdminRole"><option value="manager">管理者</option><option value="owner">总管理员</option></select></label><label>启用<select id="newAdminEnabled"><option value="true">启用</option><option value="false">停用</option></select></label><button class="primary" onclick="saveAdminUser()">保存账号</button></div><span id="adminUserTip" class="sub"></span></div><table><thead><tr><th>账号</th><th>显示名称/电脑备注</th><th>角色</th><th>状态</th><th>最后登录</th><th>登录来源</th><th>浏览器标识</th><th>操作</th></tr></thead><tbody id="adminUserRows"></tbody></table></section>
<div id="usageDetailModal" class="modal" hidden><div class="modal-box"><div class="modal-head"><div><h2 id="usageDetailTitle">使用详情</h2><span id="usageDetailRange" class="sub"></span></div><button onclick="closeUsageDetail()">关闭</button></div><table><thead><tr><th>时间</th><th>状态</th><th>任务进度</th><th>场景</th><th>原因/最后动作</th><th>版本</th><th>来源</th></tr></thead><tbody id="usageDetailRows"></tbody></table></div></div></main></div>
<script>
const token="__TOKEN__";
const state={tab:"pending",requests:[],admin:null,adminUsers:[],sharedLibraryItems:[]};
function el(id){return document.getElementById(id);}
async function api(path,body){const opt=body?{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({...body,token})}:{};const sep=path.includes("?")?"&":"?";const r=await fetch(path+(body?"":sep+"token="+encodeURIComponent(token)),opt);return r.json();}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>{if(c==="&")return"&amp;";if(c==="<")return"&lt;";if(c===">")return"&gt;";if(c==='"')return"&quot;";return"&#39;";});}
function ago(sec){if(sec==null)return"未收到心跳";if(sec<60)return Math.max(0,sec)+" 秒前";if(sec<3600)return Math.floor(sec/60)+" 分钟前";return Math.floor(sec/3600)+" 小时前";}
function fmtDuration(ms){const sec=Math.round(Number(ms||0)/1000);const h=Math.floor(sec/3600);const m=Math.floor((sec%3600)/60);const s=sec%60;return h?`${h}小时${m}分`:(m?`${m}分${s}秒`:`${s}秒`);}
function setTab(tab){state.tab=tab;document.querySelectorAll("[data-tab]").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));el("pendingSection").hidden=tab!=="pending";el("approvedSection").hidden=tab!=="approved";el("sharedLibrarySection").hidden=tab!=="sharedLibrary";el("usageSection").hidden=tab!=="usage";el("adminUsersSection").hidden=tab!=="adminUsers";el("pageTitle").textContent=tab==="approved"?"已授权":tab==="sharedLibrary"?"共享文案":tab==="usage"?"使用报表":tab==="adminUsers"?"管理员账号":"待授权";el("pageDesc").textContent=tab==="approved"?"查看已通过设备的在线和更新状态。":tab==="sharedLibrary"?"查看和管理已上传到云端的共享文案。":tab==="usage"?"查看设备使用次数、任务数和失败详情。":tab==="adminUsers"?"管理可登录总控的后台账号。":"优先处理新设备授权申请。";if(tab==="sharedLibrary")loadSharedLibraryAdmin();if(tab==="usage")loadUsage();if(tab==="adminUsers")loadAdminUsers();}
function statusLabel(v){if(v==="completed")return"完成";if(v==="failed")return"失败";if(v==="stopped")return"中止";if(v==="pending")return"待授权";if(v==="approved")return"已授权";if(v==="rejected")return"已拒绝";return v||"-";}
function renderDeviceId(id){const value=String(id||"");return value.length>28?`${esc(value.slice(0,12))}...${esc(value.slice(-10))}<span class="sub">${esc(value)}</span>`:esc(value);}
function renderStats(pending,approved,all){const offline=approved.filter(x=>["offline","unknown"].includes(x.online?.state||"unknown")).length;const outdated=approved.filter(x=>["outdated","ready"].includes(x.latestState?.state||"unknown")).length;el("pendingCount").textContent=pending.length;el("approvedCount").textContent=approved.length;el("offlineCount").textContent=offline;el("outdatedCount").textContent=outdated;el("pendingBadge").textContent=pending.length;el("approvedBadge").textContent=approved.length;el("pendingTip").textContent=pending.length?`当前有 ${pending.length} 台设备等待处理。`:"当前没有待授权设备。";}
function pendingRow(x){const online=x.online||{};const latest=x.latestState||{};const canUpload=x.sharedLibraryUpload===true;return `<tr><td class="${esc(x.status)}">${esc(statusLabel(x.status))}</td><td>${esc(x.computerName||"")}</td><td>${esc(x.appVersion||"")}</td><td class="${esc(latest.state||"unknown")}">${esc(latest.label||"未知")}</td><td class="${esc(online.state||"unknown")}">${esc(online.label||"未上报")}<span class="sub">${esc(ago(online.ageSeconds))}</span></td><td>${esc(x.sourceIp||"")}</td><td>${esc(x.requestedAt||"")}</td><td class="device">${renderDeviceId(x.deviceId)}</td><td><button class="primary" onclick="approve('${esc(x.deviceId)}')">通过</button><button class="danger" onclick="rejectReq('${esc(x.deviceId)}')">拒绝</button><button class="${canUpload?"danger":"primary"}" onclick="setSharedUpload('${esc(x.deviceId)}',${canUpload?"false":"true"})">${canUpload?"禁止上传":"允许上传"}</button></td></tr>`;}
function approvedRow(x){const online=x.online||{};const latest=x.latestState||{};const action=x.updateAction||{};const canUpload=x.sharedLibraryUpload===true;return `<tr><td>${esc(x.computerName||"")}</td><td>${esc(x.appVersion||"")}</td><td class="${esc(latest.state||"unknown")}">${esc(latest.label||"未知")}</td><td class="${esc(online.state||"unknown")}">${esc(online.label||"未上报")}<span class="sub">${esc(ago(online.ageSeconds))}</span></td><td class="${esc(action.state||"unknown")}">${esc(action.label||"-")}</td><td><span class="${canUpload?"approved":"muted"}">${canUpload?"允许":"禁止"}</span><button class="${canUpload?"danger":"primary"}" onclick="setSharedUpload('${esc(x.deviceId)}',${canUpload?"false":"true"})">${canUpload?"禁止上传":"允许上传"}</button></td><td>${esc(x.sourceIp||"")}</td><td>${esc(x.requestedAt||"")}</td><td class="device">${renderDeviceId(x.deviceId)}</td></tr>`;}
function renderDevices(){const pending=state.requests.filter(x=>(x.status||"pending")==="pending");const approved=state.requests.filter(x=>x.status==="approved");renderStats(pending,approved,state.requests);el("pendingRows").innerHTML=pending.map(pendingRow).join("")||"<tr><td class='empty' colspan='9'>当前没有待授权设备。</td></tr>";el("approvedRows").innerHTML=approved.map(approvedRow).join("")||"<tr><td class='empty' colspan='9'>当前没有已授权设备。</td></tr>";}
function fmtBytes(bytes){const n=Number(bytes||0);if(n>=1024*1024)return Math.ceil(n/1024/1024)+"MB";if(n>=1024)return Math.ceil(n/1024)+"KB";return n+"B";}
function sharedLibraryRow(x){return `<tr><td>${esc(x.name||"未命名文案")}<span class="sub">${esc(x.cloudId||"")}</span></td><td class="num">${esc(x.taskCount||0)}</td><td>${esc(fmtBytes(x.packageBytes))}</td><td class="num">${esc(x.cloudVersion||0)}</td><td>${esc(x.uploadedAt||"")}</td><td class="device">${esc(x.uploadedByDeviceRef||"")}</td><td>${esc(x.sourceIp||"")}</td><td><button class="danger" onclick="deleteSharedLibrary('${esc(x.cloudId||"")}')">删除</button></td></tr>`;}
function renderSharedLibraryAdmin(){el("sharedLibraryRows").innerHTML=state.sharedLibraryItems.map(sharedLibraryRow).join("")||"<tr><td class='empty' colspan='8'>暂无云端共享文案。</td></tr>";}
async function loadSharedLibraryAdmin(){const data=await api("/admin/api/shared-library");if(data.ok){state.sharedLibraryItems=data.items||[];renderSharedLibraryAdmin();}else{el("sharedLibraryRows").innerHTML="<tr><td class='empty' colspan='8'>读取共享文案失败："+esc(data.message||"未知原因")+"</td></tr>";}}
async function deleteSharedLibrary(cloudId){if(!cloudId)return;if(!confirm("确认删除这份云端共享文案？只删除云端副本，不影响已经下载到本机的文案。"))return;const data=await api("/admin/api/shared-library/delete",{cloudId});if(!data.ok)alert(data.message||"删除失败。");await loadSharedLibraryAdmin();}
async function loadUsage(){const range=el("usageRange").value;const data=await api("/admin/api/usage-report?range="+encodeURIComponent(range));const report=data.report||{};el("usageTitle").textContent=`${report.label||""} ${report.start||""} - ${report.end||""}`;el("usageRows").innerHTML=(report.items||[]).map(x=>{const avg=x.runCount?Math.round(Number(x.durationMs||0)/x.runCount):0;return `<tr><td>${esc(x.computerName||"")}<button class="mini" onclick="openUsageDetail('${esc(x.deviceId||"")}')">详情</button></td><td>${esc(x.appVersion||"")}</td><td class="num">${esc(x.runCount||0)}</td><td class="num">${esc(fmtDuration(x.durationMs))}</td><td class="num">${esc(fmtDuration(avg))}</td><td class="num">${esc(x.plannedCount||0)}</td><td class="num">${esc(x.successCount||0)}</td><td class="num">${esc(x.failureCount||0)}</td><td>${esc(x.completedCount||0)} / ${esc(x.failedCount||0)} / ${esc(x.stoppedCount||0)}</td><td>${esc(x.lastUsageAt||"")}</td><td>${esc(x.sourceIp||"")}</td></tr>`}).join("")||"<tr><td class='empty' colspan='11'>这个范围内没有报表记录。</td></tr>";}
function runStatusLabel(v){if(v==="completed")return"完成";if(v==="failed")return"失败";if(v==="stopped")return"中止";return v||"-";}
function sceneText(x){const parts=[];if(x.stage)parts.push("阶段="+x.stage);if(x.taskRole)parts.push("角色="+x.taskRole);if(x.taskType)parts.push("类型="+x.taskType);if(x.taskDate)parts.push("日期="+x.taskDate);if(x.taskTime)parts.push("时间="+x.taskTime);return parts.join("；")||"-";}
async function openUsageDetail(deviceId){const range=el("usageRange").value;const data=await api("/admin/api/usage-detail?range="+encodeURIComponent(range)+"&deviceId="+encodeURIComponent(deviceId));const detail=data.detail||{};el("usageDetailTitle").textContent="使用详情："+((detail.items||[])[0]?.computerName||deviceId||"未知电脑");el("usageDetailRange").textContent=`${detail.label||""} ${detail.start||""} - ${detail.end||""}`;el("usageDetailRows").innerHTML=(detail.items||[]).map(x=>`<tr><td>${esc(x.startedAt||"")}<span class="sub">结束：${esc(x.finishedAt||"")}</span><span class="sub">用时：${esc(fmtDuration(x.durationMs))}</span></td><td class="${esc(x.status==="completed"?"latest":x.status==="stopped"?"stale":"failed")}">${esc(runStatusLabel(x.status))}</td><td>${esc(x.taskIndex||0)} / ${esc(x.totalCount||x.plannedCount||0)}<span class="sub">计划 ${esc(x.plannedCount||0)}，成功 ${esc(x.successCount||0)}，失败 ${esc(x.failureCount||0)}</span></td><td class="scene">${esc(sceneText(x))}</td><td class="reason">${esc(x.reason||x.action||"-")}</td><td>${esc(x.appVersion||"")}</td><td>${esc(x.sourceIp||"")}</td></tr>`).join("")||"<tr><td colspan='7'>这个范围内没有明细记录。</td></tr>";el("usageDetailModal").hidden=false;}
function closeUsageDetail(){el("usageDetailModal").hidden=true;}
function roleLabel(v){return v==="owner"?"总管理员":"管理者";}
function adminUserRow(x){const status=x.enabled?"启用":"停用";const toggle=x.enabled?"停用":"启用";return `<tr><td>${esc(x.username)}</td><td>${esc(x.displayName||"")}</td><td>${esc(roleLabel(x.role))}</td><td class="${x.enabled?"approved":"rejected"}">${status}</td><td>${esc(x.lastLoginAt||"-")}</td><td>${esc(x.lastLoginIp||"-")}</td><td class="reason">${esc(x.lastLoginAgent||"-")}</td><td><button class="${x.enabled?"danger":"primary"}" onclick="toggleAdminUser('${esc(x.username)}',${x.enabled?"false":"true"})">${toggle}</button><button onclick="resetAdminPass('${esc(x.username)}')">重置密码</button></td></tr>`;}
function renderAdminUsers(){el("adminUserRows").innerHTML=state.adminUsers.map(adminUserRow).join("")||"<tr><td class='empty' colspan='8'>暂无管理员账号。</td></tr>";}
async function loadAdminUsers(){const data=await api("/admin/api/admin-users");if(data.ok){state.adminUsers=data.users||[];renderAdminUsers();}else{el("adminUserRows").innerHTML="<tr><td class='empty' colspan='8'>只有总管理员可以查看。</td></tr>";}}
async function saveAdminUser(){const payload={username:el("newAdminUsername").value.trim(),displayName:el("newAdminDisplay").value.trim(),password:el("newAdminPassword").value,role:el("newAdminRole").value,enabled:el("newAdminEnabled").value==="true"};const data=await api("/admin/api/admin-users/save",payload);el("adminUserTip").textContent=data.message||"";if(data.ok){el("newAdminPassword").value="";await loadAdminUsers();}}
async function toggleAdminUser(username,enabled){const data=await api("/admin/api/admin-users/enabled",{username,enabled});el("adminUserTip").textContent=data.message||"";await loadAdminUsers();}
async function resetAdminPass(username){const password=prompt("请输入新密码，至少 8 位");if(!password)return;const data=await api("/admin/api/admin-users/reset-password",{username,password});el("adminUserTip").textContent=data.message||"";}
async function loadMe(){const data=await api("/admin/api/me");if(!data.ok){location.href="/admin";return;}state.admin=data.admin;el("currentAdmin").textContent=`当前登录：${data.admin.displayName||data.admin.username}（${roleLabel(data.admin.role)}）`;el("adminUsersNav").hidden=data.admin.role!=="owner";if(data.admin.role!=="owner"&&state.tab==="adminUsers")setTab("pending");}
async function logout(){await fetch("/admin/logout",{method:"POST",headers:{"content-type":"application/json"},body:"{}"});location.href="/admin";}
async function load(){const data=await api("/admin/api/requests");state.requests=data.requests||[];renderDevices();if(state.tab==="sharedLibrary")await loadSharedLibraryAdmin();if(state.tab==="usage")await loadUsage();}
async function approve(id){await api("/admin/api/approve",{deviceId:id});load();}
async function rejectReq(id){await api("/admin/api/reject",{deviceId:id});load();}
async function setSharedUpload(id,enabled){await api("/admin/api/shared-upload",{deviceId:id,enabled});load();}
async function init(){await loadMe();await load();}
init();
setInterval(load,30000);
</script>"""


def ensure_admin_token(path):
    path = Path(path)
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    token = secrets.token_urlsafe(24)
    path.write_text(token + "\n", encoding="utf-8")
    os.chmod(path, 0o640)
    return token


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bind", required=True)
    parser.add_argument("--port", type=int, default=8093)
    parser.add_argument("--policy", required=True)
    parser.add_argument("--gateway", action="append", required=True)
    args = parser.parse_args()
    policy_path = Path(args.policy)
    server = ThreadingHTTPServer((args.bind, args.port), Handler)
    server.daemon_threads = True
    server.policy_path = policy_path
    server.requests_path = policy_path.with_name("requests.json")
    server.usage_events_path = policy_path.with_name("usage-events.json")
    server.audit_path = policy_path.with_name("audit.log")
    server.admin_token_path = policy_path.with_name("admin-token")
    server.admin_users_path = policy_path.with_name("admin-users.json")
    server.admin_token = ensure_admin_token(server.admin_token_path)
    server.gateway_ips = {ipaddress.ip_address(v) for v in args.gateway}
    server.serve_forever()


if __name__ == "__main__":
    main()

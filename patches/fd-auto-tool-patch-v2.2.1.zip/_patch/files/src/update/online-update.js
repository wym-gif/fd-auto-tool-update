import childProcess from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const DEFAULT_UPDATE_CHECK_TIMEOUT_MS = 8000;
const DEFAULT_UPDATE_DOWNLOAD_TIMEOUT_MS = 60000;
const OFFICIAL_RAW_PREFIX = "https://raw.githubusercontent.com/wym-gif/fd-auto-tool-update/refs/heads/main/";
const OFFICIAL_RAW_LEGACY_PREFIX = "https://raw.githubusercontent.com/wym-gif/fd-auto-tool-update/main/";
const OFFICIAL_CDN_PREFIX = "https://cdn.jsdelivr.net/gh/wym-gif/fd-auto-tool-update@main/";

export async function checkOnlineUpdate(config = {}) {
  const updateSourceUrls = getUpdateSourceUrls(config);
  console.log("正在检查在线更新...");
  if (!updateSourceUrls.length) {
    return { ok: false, error: "还没有配置更新地址。等更新源接好后，这里就可以一键检查更新。" };
  }
  const currentVersion = await readCurrentVersion();
  let latest;
  let updateSourceUrl = "";
  const updateSourceErrors = [];
  for (const sourceUrl of updateSourceUrls) {
    try {
      latest = await fetchUpdateManifest(sourceUrl, {
        timeoutMs: updateCheckTimeoutMs(config)
      });
      updateSourceUrl = sourceUrl;
      break;
    } catch (error) {
      updateSourceErrors.push({
        updateSourceUrl: sourceUrl,
        error: error?.message || String(error)
      });
    }
  }
  if (!latest) {
    return {
      ok: false,
      error: formatSourceFailure(updateSourceErrors),
      currentVersion,
      updateSourceErrors,
      attemptedUpdateSourceUrls: updateSourceUrls
    };
  }
  const latestVersion = String(latest.latestVersion || latest.version || "").trim();
  const patchUrls = getPatchUrls(latest, updateSourceUrl);
  if (!latestVersion || !patchUrls.length) return { ok: false, error: "更新源格式不完整，缺少版本号或补丁地址。" };
  const minVersion = String(latest.minVersion || "").trim();
  if (minVersion && compareVersions(currentVersion, minVersion) < 0) {
    return { ok: false, error: "当前版本太旧，不能直接在线更新，请先使用新版完整运行包。" };
  }
  return {
    ok: true,
    currentVersion,
    latestVersion,
    hasUpdate: compareVersions(latestVersion, currentVersion) > 0,
    notes: Array.isArray(latest.notes) ? latest.notes.map((item) => String(item)).filter(Boolean) : [],
    patchUrl: patchUrls[0],
    patchUrls,
    updateSourceUrl,
    attemptedUpdateSourceUrls: updateSourceUrls,
    updateSourceErrors,
    fallbackUsed: updateSourceErrors.length > 0
  };
}

export async function installOnlineUpdate(config = {}) {
  console.log("开始在线更新...");
  const status = await checkOnlineUpdate(config);
  if (!status.ok) return status;
  if (!status.hasUpdate) {
    console.log("当前已经是最新版本：" + (status.currentVersion || "-"));
    return { ok: true, alreadyLatest: true, currentVersion: status.currentVersion, latestVersion: status.latestVersion };
  }

  const rootDir = process.cwd();
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "fd-auto-update-"));
  const zipPath = path.join(tempRoot, "patch.zip");
  const extractDir = path.join(tempRoot, "extract");
  try {
    console.log("正在下载补丁：" + status.patchUrl);
    const downloaded = await downloadUpdatePatch(status, zipPath, {
      timeoutMs: updateDownloadTimeoutMs(config)
    });
    if (downloaded.url !== status.patchUrl) console.log("已切换备用补丁地址：" + downloaded.url);
    console.log("补丁下载完成，正在解压...");
    await fs.mkdir(extractDir, { recursive: true });
    await extractZip(zipPath, extractDir);
    const patchRoot = await findExtractedPatchRoot(extractDir);
    if (!patchRoot) throw new Error("补丁包里没有找到 _patch\\patch-manifest.json。");
    const targetPatchRoot = path.join(rootDir, "_patch");
    console.log("正在安装补丁...");
    await fs.rm(targetPatchRoot, { recursive: true, force: true });
    await fs.cp(patchRoot, targetPatchRoot, { recursive: true });
    const result = childProcess.spawnSync(process.execPath, [path.join(rootDir, "tools", "apply-patch.cjs")], {
      cwd: rootDir,
      encoding: "utf8"
    });
    if (result.status !== 0) {
      const detail = (result.stderr || result.stdout || "").trim();
      throw new Error(detail || "补丁安装失败。");
    }
    console.log("在线更新成功：" + status.currentVersion + " -> " + status.latestVersion);
    return {
      ok: true,
      currentVersion: status.currentVersion,
      latestVersion: status.latestVersion,
      message: result.stdout || ""
    };
  } catch (error) {
    console.log("在线更新失败：" + (error?.message || String(error)));
    return { ok: false, error: error?.message || String(error) };
  } finally {
    await fs.rm(tempRoot, { recursive: true, force: true }).catch(() => {});
  }
}

export async function prepareOnlineUpdate(config = {}, options = {}) {
  console.log("正在后台准备在线更新...");
  const status = await checkOnlineUpdate(config);
  if (!status.ok) return status;
  if (!status.hasUpdate) {
    await removePreparedOnlineUpdate(options.projectRoot || process.cwd());
    return { ok: true, alreadyLatest: true, currentVersion: status.currentVersion, latestVersion: status.latestVersion };
  }

  const rootDir = path.resolve(options.projectRoot || process.cwd());
  const pendingRoot = preparedUpdateRoot(rootDir);
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "fd-auto-update-prepare-"));
  const zipPath = path.join(tempRoot, "patch.zip");
  const extractDir = path.join(tempRoot, "extract");
  try {
    console.log("正在后台下载补丁：" + status.patchUrl);
    const downloaded = await downloadUpdatePatch(status, zipPath, {
      timeoutMs: updateDownloadTimeoutMs(config)
    });
    if (downloaded.url !== status.patchUrl) console.log("已切换备用补丁地址：" + downloaded.url);
    await fs.mkdir(extractDir, { recursive: true });
    await extractZip(zipPath, extractDir);
    const patchRoot = await findExtractedPatchRoot(extractDir);
    if (!patchRoot) throw new Error("补丁包里没有找到 _patch\\patch-manifest.json。");
    const targetPatchRoot = safeResolveInside(pendingRoot, "_patch");
    await fs.rm(pendingRoot, { recursive: true, force: true });
    await fs.mkdir(pendingRoot, { recursive: true });
    await fs.cp(patchRoot, targetPatchRoot, { recursive: true });
    const manifest = await readJsonIfExists(path.join(targetPatchRoot, "patch-manifest.json"));
    const prepared = {
      ready: true,
      currentVersion: status.currentVersion,
      latestVersion: status.latestVersion,
      targetVersion: String(manifest.targetVersion || status.latestVersion || "").trim(),
      patchUrl: downloaded.url || status.patchUrl,
      notes: status.notes || [],
      preparedAt: new Date().toISOString()
    };
    await fs.writeFile(path.join(pendingRoot, "pending-update.json"), JSON.stringify(prepared, null, 2), "utf8");
    console.log("新版本已下载好，下次启动会自动更新：" + status.latestVersion);
    return { ok: true, prepared: true, ...prepared };
  } catch (error) {
    console.log("后台准备更新失败：" + (error?.message || String(error)));
    return { ok: false, error: error?.message || String(error) };
  } finally {
    await fs.rm(tempRoot, { recursive: true, force: true }).catch(() => {});
  }
}

export async function getPreparedOnlineUpdate(projectRoot = process.cwd()) {
  const rootDir = path.resolve(projectRoot);
  const pendingRoot = preparedUpdateRoot(rootDir);
  const metadata = await readJsonIfExists(path.join(pendingRoot, "pending-update.json"));
  const manifestPath = path.join(pendingRoot, "_patch", "patch-manifest.json");
  if (!metadata.ready || !await pathExists(manifestPath)) {
    return { ready: false };
  }
  const currentVersion = await readCurrentVersion(rootDir);
  if (metadata.latestVersion && compareVersions(currentVersion, metadata.latestVersion) >= 0) {
    await removePreparedOnlineUpdate(rootDir);
    return { ready: false, alreadyApplied: true, currentVersion };
  }
  return {
    ready: true,
    currentVersion,
    latestVersion: String(metadata.latestVersion || metadata.targetVersion || "").trim(),
    targetVersion: String(metadata.targetVersion || metadata.latestVersion || "").trim(),
    preparedAt: String(metadata.preparedAt || "").trim(),
    notes: Array.isArray(metadata.notes) ? metadata.notes : [],
    path: pendingRoot
  };
}

export async function installPreparedOnlineUpdate(projectRoot = process.cwd(), options = {}) {
  const rootDir = path.resolve(projectRoot);
  const prepared = await getPreparedOnlineUpdate(rootDir);
  if (!prepared.ready) return { ok: true, applied: false, ...prepared };

  const sourcePatchRoot = safeResolveInside(preparedUpdateRoot(rootDir), "_patch");
  const targetPatchRoot = safeResolveInside(rootDir, "_patch");
  try {
    await fs.rm(targetPatchRoot, { recursive: true, force: true });
    await fs.cp(sourcePatchRoot, targetPatchRoot, { recursive: true });
    const result = childProcess.spawnSync(process.execPath, [path.join(rootDir, "tools", "apply-patch.cjs")], {
      cwd: rootDir,
      encoding: "utf8",
      windowsHide: true
    });
    if (result.status !== 0) {
      const detail = (result.stderr || result.stdout || "").trim();
      throw new Error(detail || "补丁安装失败。");
    }
    await removePreparedOnlineUpdate(rootDir);
    return {
      ok: true,
      applied: true,
      currentVersion: prepared.currentVersion,
      latestVersion: prepared.latestVersion,
      message: result.stdout || ""
    };
  } catch (error) {
    if (!options.keepBrokenPatch) await fs.rm(targetPatchRoot, { recursive: true, force: true }).catch(() => {});
    return { ok: false, applied: false, error: error?.message || String(error), prepared };
  }
}

export async function removePreparedOnlineUpdate(projectRoot = process.cwd()) {
  await fs.rm(preparedUpdateRoot(path.resolve(projectRoot)), { recursive: true, force: true }).catch(() => {});
}

export function getUpdateSourceUrls(config = {}) {
  const configured = [];
  addSourceValues(config.updateSourceUrls, configured);
  addSourceValues(config.updateSourceUrl, configured);
  addSourceValues(process.env.FD_AUTO_TOOL_UPDATE_URLS, configured);
  addSourceValues(process.env.FD_AUTO_TOOL_UPDATE_URL, configured);

  const urls = [];
  for (const sourceUrl of configured) {
    addUnique(urls, sourceUrl);
    for (const fallbackUrl of officialFallbackUrls(sourceUrl)) addUnique(urls, fallbackUrl);
  }
  return urls;
}

function getUpdateSourceUrl(config = {}) {
  return getUpdateSourceUrls(config)[0] || "";
}

function addSourceValues(value, target) {
  if (Array.isArray(value)) {
    for (const item of value) addSourceValues(item, target);
    return;
  }
  for (const item of String(value || "").split(/[\r\n,;]+/)) {
    const text = item.trim();
    if (text) target.push(text);
  }
}

function addUnique(target, value) {
  const text = String(value || "").trim();
  if (text && !target.includes(text)) target.push(text);
}

function updateCheckTimeoutMs(config = {}) {
  return positiveNumber(config.updateCheckTimeoutMs, positiveNumber(config.updateTimeoutMs, DEFAULT_UPDATE_CHECK_TIMEOUT_MS));
}

function updateDownloadTimeoutMs(config = {}) {
  return positiveNumber(config.updateDownloadTimeoutMs, positiveNumber(config.updateTimeoutMs, DEFAULT_UPDATE_DOWNLOAD_TIMEOUT_MS));
}

function positiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function readCurrentVersion(rootDir = process.cwd()) {
  try {
    const packageJson = JSON.parse(await fs.readFile(path.resolve(rootDir, "package.json"), "utf8"));
    return String(packageJson.version || "").trim() || "0.0.0";
  } catch {
    return "0.0.0";
  }
}

async function fetchUpdateManifest(updateSourceUrl, options = {}) {
  const normalizedUrl = normalizeOfficialRawUrl(updateSourceUrl);
  const url = new URL(normalizedUrl);
  url.searchParams.set("_t", String(Date.now()));
  const response = await fetchWithTimeout(url, { cache: "no-store" }, {
    timeoutMs: options.timeoutMs,
    label: "更新源读取"
  });
  if (!response.ok) throw new Error("更新源读取失败：" + response.status);
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("更新源返回的不是 JSON，可能访问到了错误页或登录页。");
  }
}

async function downloadUpdatePatch(status, targetPath, options = {}) {
  const patchUrls = [];
  addSourceValues(status.patchUrls || status.patchUrl, patchUrls);
  const uniqueUrls = [];
  for (const patchUrl of patchUrls) addUnique(uniqueUrls, patchUrl);
  const errors = [];
  for (const patchUrl of uniqueUrls) {
    try {
      await downloadFile(patchUrl, targetPath, options);
      return { url: patchUrl };
    } catch (error) {
      errors.push({ patchUrl, error: error?.message || String(error) });
    }
  }
  throw new Error(formatPatchFailure(errors));
}

async function downloadFile(url, targetPath, options = {}) {
  const response = await fetchWithTimeout(url, { cache: "no-store" }, {
    timeoutMs: options.timeoutMs,
    label: "补丁下载"
  });
  if (!response.ok) throw new Error("补丁下载失败：" + response.status);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (!buffer.length) throw new Error("下载到的补丁文件为空。");
  await fs.writeFile(targetPath, buffer);
}

function getPatchUrls(manifest, sourceUrl) {
  const configured = [];
  addSourceValues(manifest.patchUrls, configured);
  addSourceValues(manifest.patchUrl || manifest.url, configured);
  const urls = [];
  for (const patchUrl of configured) {
    const resolvedUrl = resolveUrl(patchUrl, sourceUrl);
    const preferredUrl = preferredPatchUrlForSource(resolvedUrl, sourceUrl);
    addUnique(urls, preferredUrl);
    addUnique(urls, resolvedUrl);
    for (const fallbackUrl of officialFallbackUrls(resolvedUrl)) addUnique(urls, fallbackUrl);
  }
  return urls;
}

function resolveUrl(value, baseUrl) {
  const text = String(value || "").trim();
  if (!text) return "";
  try {
    return new URL(text, baseUrl).toString();
  } catch {
    return text;
  }
}

function preferredPatchUrlForSource(patchUrl, sourceUrl) {
  if (String(sourceUrl || "").startsWith(OFFICIAL_CDN_PREFIX)) {
    return toOfficialCdnUrl(patchUrl) || patchUrl;
  }
  if (isOfficialRawUrl(sourceUrl)) {
    return normalizeOfficialRawUrl(patchUrl);
  }
  return patchUrl;
}

function officialFallbackUrls(url) {
  const cdnUrl = toOfficialCdnUrl(url);
  if (cdnUrl) return [cdnUrl];
  const rawUrl = toOfficialRawUrl(url);
  if (rawUrl) return [rawUrl];
  return [];
}

function normalizeOfficialRawUrl(url) {
  return String(url || "").replace(OFFICIAL_RAW_LEGACY_PREFIX, OFFICIAL_RAW_PREFIX);
}

function isOfficialRawUrl(url) {
  const normalized = normalizeOfficialRawUrl(url);
  return normalized.startsWith(OFFICIAL_RAW_PREFIX);
}

function toOfficialCdnUrl(url) {
  const normalized = normalizeOfficialRawUrl(url);
  if (!normalized.startsWith(OFFICIAL_RAW_PREFIX)) return "";
  return OFFICIAL_CDN_PREFIX + normalized.slice(OFFICIAL_RAW_PREFIX.length);
}

function toOfficialRawUrl(url) {
  const text = String(url || "").trim();
  if (!text.startsWith(OFFICIAL_CDN_PREFIX)) return "";
  return OFFICIAL_RAW_PREFIX + text.slice(OFFICIAL_CDN_PREFIX.length);
}

function formatSourceFailure(errors) {
  const count = errors.length;
  const last = errors[count - 1]?.error || "未知原因";
  if (count <= 1) return "更新源检查未完成：" + last;
  return `更新源检查未完成：已尝试 ${count} 个更新地址都失败。最后原因：${last}`;
}

function formatPatchFailure(errors) {
  const count = errors.length;
  const last = errors[count - 1]?.error || "未知原因";
  if (count <= 1) return "补丁下载失败：" + last;
  return `补丁下载失败：已尝试 ${count} 个补丁地址都失败。最后原因：${last}`;
}

async function fetchWithTimeout(url, init = {}, options = {}) {
  const timeoutMs = positiveNumber(options.timeoutMs, DEFAULT_UPDATE_CHECK_TIMEOUT_MS);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal
    });
  } catch (error) {
    if (error?.name === "AbortError") {
      throw new Error(`${options.label || "网络请求"}超时（${Math.round(timeoutMs / 1000)} 秒），不影响当前使用。`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function extractZip(zipPath, destination) {
  const result = childProcess.spawnSync("tar", ["-xf", zipPath, "-C", destination], {
    cwd: process.cwd(),
    encoding: "utf8"
  });
  if (result.status !== 0) {
    const detail = (result.stderr || result.stdout || "").trim();
    throw new Error("补丁解压失败。" + (detail ? "\n" + detail : ""));
  }
}

async function findExtractedPatchRoot(baseDir) {
  const direct = path.join(baseDir, "_patch");
  if (await pathExists(path.join(direct, "patch-manifest.json"))) return direct;
  const entries = await fs.readdir(baseDir, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const candidate = path.join(baseDir, entry.name, "_patch");
    if (await pathExists(path.join(candidate, "patch-manifest.json"))) return candidate;
  }
  return "";
}

async function pathExists(file) {
  try {
    await fs.access(file);
    return true;
  } catch {
    return false;
  }
}

async function readJsonIfExists(file) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch {
    return {};
  }
}

function preparedUpdateRoot(rootDir) {
  return safeResolveInside(rootDir, "_pending-update");
}

function safeResolveInside(base, rel) {
  const resolved = path.resolve(base, rel);
  const root = path.resolve(base);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) {
    throw new Error("更新路径不安全：" + rel);
  }
  return resolved;
}

export function compareVersions(left, right) {
  const a = String(left || "0").split(".").map((item) => Number.parseInt(item, 10) || 0);
  const b = String(right || "0").split(".").map((item) => Number.parseInt(item, 10) || 0);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index += 1) {
    const diff = (a[index] || 0) - (b[index] || 0);
    if (diff !== 0) return diff > 0 ? 1 : -1;
  }
  return 0;
}

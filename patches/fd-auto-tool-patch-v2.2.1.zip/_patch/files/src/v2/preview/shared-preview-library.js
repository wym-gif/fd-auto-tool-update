import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { postLicenseServicePayload } from "../license/license-manager.js";
import { finalPreviewPath, previewTasksPath, readPreviewTasks, saveFinalPreview } from "./preview-store.js";
import { listPreviewLibrary, previewLibraryRoot, resolvePreviewLibraryItem } from "./preview-library.js";

const META_FILE = "library-meta.json";
const MAX_PACKAGE_BYTES = 250 * 1024 * 1024;

export async function uploadSharedPreviewLibraryItem(projectRoot, id, options = {}) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const pack = await buildSharedPackage(item);
  const body = await postSharedLibraryPayload(projectRoot, {
    action: "shared-library-upload",
    library: pack
  }, { ...options, timeoutMs: options.timeoutMs ?? 60000 }, "上传共享文案失败。");
  await updateLocalSharedMeta(item, body.item || {}, pack.packageHash);
  return {
    ok: true,
    item: await resolvePreviewLibraryItem(projectRoot, id),
    shared: body.item,
    items: await listPreviewLibrary(projectRoot)
  };
}

export async function listSharedPreviewLibrary(projectRoot, options = {}) {
  const localItems = await listPreviewLibrary(projectRoot);
  const body = await postSharedLibraryPayload(projectRoot, {
    action: "shared-library-list"
  }, { ...options, timeoutMs: options.timeoutMs ?? 30000 }, "读取云端文案失败。");
  const localByCloudId = new Map(localItems
    .filter((item) => item.shared?.cloudId)
    .map((item) => [item.shared.cloudId, item]));
  const items = (Array.isArray(body.items) ? body.items : []).map((cloud) => {
    const local = localByCloudId.get(cloud.cloudId);
    const localVersion = Number(local?.shared?.cloudVersion || 0);
    const cloudVersion = Number(cloud.cloudVersion || 0);
    return {
      ...cloud,
      localId: local?.id || "",
      localVersion,
      localStatus: local
        ? (cloudVersion > localVersion ? "update_available" : "current")
        : "not_downloaded"
    };
  });
  return { ok: true, items };
}

export async function downloadSharedPreviewLibraryItem(projectRoot, cloudId, options = {}) {
  const body = await postSharedLibraryPayload(projectRoot, {
    action: "shared-library-download",
    cloudId
  }, { ...options, timeoutMs: options.timeoutMs ?? 60000, maxResponseBytes: MAX_PACKAGE_BYTES + 1024 * 1024 }, "下载云端文案失败。");
  const item = await importSharedPackage(projectRoot, body.item, body.package);
  return { ok: true, item, items: await listPreviewLibrary(projectRoot) };
}

export async function deleteSharedPreviewLibraryItem(projectRoot, cloudId, options = {}) {
  const body = await postSharedLibraryPayload(projectRoot, {
    action: "shared-library-delete",
    cloudId
  }, { ...options, timeoutMs: options.timeoutMs ?? 30000 }, "删除云端文案失败。");
  return { ok: true, deleted: body.deleted || {}, items: await listSharedPreviewLibrary(projectRoot, options).then((result) => result.items) };
}

export async function exportSharedPreviewLibraryItem(projectRoot, id, options = {}) {
  const item = await resolvePreviewLibraryItem(projectRoot, id);
  const pack = await buildSharedPackage(item);
  const outputDir = path.resolve(options.outputDir || path.join(projectRoot, "manual-shared-packages"));
  await fs.mkdir(outputDir, { recursive: true });
  const fileName = `${timestampForFile()}-${safeFileName(pack.name || item.name || "shared-copywriting")}.mq-shared-preview.json`;
  const filePath = path.join(outputDir, fileName);
  await fs.writeFile(filePath, JSON.stringify(pack, null, 2), "utf8");
  return {
    ok: true,
    item,
    fileName,
    filePath,
    packageBytes: pack.packageBytes,
    message: "共享包已导出。"
  };
}

export async function importSharedPreviewLibraryPackage(projectRoot, input = {}) {
  const fileName = String(input.fileName || "").trim();
  const contentBase64 = String(input.contentBase64 || "").replace(/^data:[^,]+,/, "");
  if (!contentBase64) throw new Error("导入失败：共享包文件为空。");
  if (fileName && !/\.json$/i.test(fileName)) throw new Error("导入失败：共享包只支持 .json 文件。");
  const buffer = Buffer.from(contentBase64, "base64");
  if (!buffer.length) throw new Error("导入失败：共享包文件为空。");
  if (buffer.length > MAX_PACKAGE_BYTES) {
    throw new Error(`导入失败：共享包太大，当前约 ${formatBytes(buffer.length)}，上限 ${formatBytes(MAX_PACKAGE_BYTES)}。`);
  }
  let pack;
  try {
    pack = JSON.parse(buffer.toString("utf8"));
  } catch {
    throw new Error("导入失败：共享包不是有效 JSON 文件。");
  }
  const item = await importSharedPackage(projectRoot, {
    cloudId: pack.cloudId || "",
    name: pack.name || "",
    taskCount: pack.taskCount || 0,
    cloudVersion: Number(pack.baseCloudVersion || 0),
    updatedAt: pack.updatedAt || "",
    packageHash: pack.packageHash || ""
  }, pack, { forceNew: true });
  return { ok: true, item, items: await listPreviewLibrary(projectRoot) };
}

export async function buildSharedPackage(item) {
  const tasks = await readPreviewTasks(finalPreviewPath(item.runDir));
  const { rewrittenTasks, mediaFiles } = await collectMediaFiles(item.runDir, tasks);
  const rawEvents = await readJsonIfExists(path.join(item.runDir, "raw-events.json"));
  const meta = await readJsonIfExists(path.join(item.runDir, META_FILE));
  const pack = {
    schemaVersion: 1,
    sourceLocalId: item.id,
    cloudId: meta.shared?.cloudId || "",
    baseCloudVersion: Number(meta.shared?.cloudVersion || 0),
    name: item.name || "未命名文案",
    taskCount: rewrittenTasks.length,
    updatedAt: item.updatedAt || meta.updatedAt || "",
    tasks: rewrittenTasks,
    rawEvents: Array.isArray(rawEvents) ? rawEvents : [],
    mediaFiles
  };
  const packageHash = sha256(JSON.stringify(pack));
  const packageBytes = Buffer.byteLength(JSON.stringify(pack), "utf8");
  if (packageBytes > MAX_PACKAGE_BYTES) {
    throw new Error(`共享文案包太大：当前约 ${formatBytes(packageBytes)}，云端上传上限 ${formatBytes(MAX_PACKAGE_BYTES)}。可以改用“导出共享包”手动发送给别人导入。`);
  }
  return { ...pack, packageHash, packageBytes };
}

async function collectMediaFiles(runDir, tasks) {
  const mediaFiles = [];
  const rewrittenTasks = [];
  const seen = new Set();
  for (const task of Array.isArray(tasks) ? tasks : []) {
    const next = { ...task };
    const mediaPath = String(next.mediaPath || "").trim();
    const rel = mediaPath ? mediaRelativePath(runDir, mediaPath) : "";
    if (rel) {
      const packageRel = rel.replace(/\\/g, "/");
      next.mediaPath = packageRel;
      if (!seen.has(packageRel)) {
        seen.add(packageRel);
        const filePath = path.join(runDir, rel);
        const buffer = await fs.readFile(filePath);
        mediaFiles.push({
          path: packageRel,
          size: buffer.length,
          sha256: sha256(buffer),
          contentBase64: buffer.toString("base64")
        });
      }
    }
    rewrittenTasks.push(next);
  }
  return { rewrittenTasks, mediaFiles };
}

function mediaRelativePath(runDir, mediaPath) {
  if (/^(sample|data|https?|blob|image-blob):/i.test(mediaPath)) return "";
  const resolved = path.resolve(mediaPath);
  const mediaRoot = path.resolve(runDir, "media-cache");
  if (!resolved.startsWith(mediaRoot + path.sep)) return "";
  return path.join("media-cache", path.relative(mediaRoot, resolved));
}

async function importSharedPackage(projectRoot, cloudItem = {}, pack = {}, options = {}) {
  if (!pack || pack.schemaVersion !== 1) throw new Error("云端文案包格式不支持。");
  const root = previewLibraryRoot(projectRoot);
  await fs.mkdir(root, { recursive: true });
  const existing = options.forceNew ? null : await localItemByCloudId(projectRoot, cloudItem.cloudId);
  const preferredId = safeLocalId(pack.sourceLocalId) || `shared_${safeLocalId(cloudItem.cloudId) || Date.now()}`;
  const id = existing?.id || await uniqueLocalId(root, preferredId);
  const itemDir = path.join(root, id);
  await fs.mkdir(path.join(itemDir, "media-cache"), { recursive: true });
  for (const file of Array.isArray(pack.mediaFiles) ? pack.mediaFiles : []) {
    const rel = safePackagePath(file.path);
    if (!rel.startsWith("media-cache/")) throw new Error("云端素材路径不安全。");
    const buffer = Buffer.from(String(file.contentBase64 || ""), "base64");
    if (file.sha256 && sha256(buffer) !== file.sha256) throw new Error("云端素材校验失败。");
    const dest = path.join(itemDir, ...rel.split("/"));
    await fs.mkdir(path.dirname(dest), { recursive: true });
    await fs.writeFile(dest, buffer);
  }
  const tasks = (Array.isArray(pack.tasks) ? pack.tasks : []).map((task) => {
    const next = { ...task };
    const rel = safePackagePath(next.mediaPath || "");
    if (rel.startsWith("media-cache/")) next.mediaPath = path.join(itemDir, ...rel.split("/"));
    return next;
  });
  await saveFinalPreview(itemDir, tasks, { requireComplete: true });
  await fs.writeFile(previewTasksPath(itemDir), JSON.stringify(tasks, null, 2), "utf8");
  await fs.writeFile(path.join(itemDir, "raw-events.json"), JSON.stringify(Array.isArray(pack.rawEvents) ? pack.rawEvents : [], null, 2), "utf8");
  const now = new Date().toISOString();
  const meta = {
    id,
    name: cleanName(cloudItem.name || pack.name) || "云端文案",
    createdAt: existing?.createdAt || now,
    updatedAt: cloudItem.updatedAt || pack.updatedAt || now,
    sourceRunDir: "",
    runDir: itemDir,
    previewPath: finalPreviewPath(itemDir),
    taskCount: tasks.length,
    shared: {
      cloudId: cloudItem.cloudId || pack.cloudId || "",
      cloudVersion: Number(cloudItem.cloudVersion || 0),
      uploadedAt: cloudItem.uploadedAt || "",
      packageHash: cloudItem.packageHash || pack.packageHash || "",
      downloadedAt: now
    }
  };
  await fs.writeFile(path.join(itemDir, META_FILE), JSON.stringify(meta, null, 2), "utf8");
  await listPreviewLibrary(projectRoot);
  return resolvePreviewLibraryItem(projectRoot, id);
}

async function postSharedLibraryPayload(projectRoot, payload, options, fallback) {
  let body;
  try {
    body = await postLicenseServicePayload(projectRoot, payload, options);
  } catch (error) {
    throw new Error(normalizeSharedErrorMessage(error?.message || String(error), fallback));
  }
  if (!body?.ok) throw new Error(normalizeSharedErrorMessage(body?.message || body?.error || fallback, fallback));
  return body;
}

async function updateLocalSharedMeta(item, cloudItem, packageHash) {
  const metaPath = path.join(item.runDir, META_FILE);
  const meta = await readJsonIfExists(metaPath);
  const next = {
    ...meta,
    shared: {
      ...(meta.shared || {}),
      cloudId: cloudItem.cloudId || meta.shared?.cloudId || "",
      cloudVersion: Number(cloudItem.cloudVersion || 0),
      uploadedAt: cloudItem.uploadedAt || new Date().toISOString(),
      packageHash: cloudItem.packageHash || packageHash,
      downloadedAt: meta.shared?.downloadedAt || ""
    }
  };
  await fs.writeFile(metaPath, JSON.stringify(next, null, 2), "utf8");
}

async function localItemByCloudId(projectRoot, cloudId) {
  const wanted = String(cloudId || "");
  if (!wanted) return null;
  const items = await listPreviewLibrary(projectRoot);
  return items.find((item) => item.shared?.cloudId === wanted) || null;
}

async function uniqueLocalId(root, preferred) {
  const base = safeLocalId(preferred) || `shared_${Date.now()}`;
  let candidate = base;
  for (let index = 2; index < 1000; index += 1) {
    if (!await pathExists(path.join(root, candidate))) return candidate;
    candidate = `${base}_${index}`;
  }
  return `${base}_${Date.now()}`;
}

function safePackagePath(value) {
  const normalized = String(value || "").replace(/\\/g, "/");
  if (!normalized || normalized.startsWith("/") || /^[a-zA-Z]:/.test(normalized) || normalized.includes("..")) return "";
  return normalized;
}

function safeLocalId(value) {
  const id = String(value || "").trim();
  return /^[a-zA-Z0-9_.-]+$/.test(id) ? id : "";
}

function cleanName(value) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 80);
}

function safeFileName(value) {
  return cleanName(value).replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/\s+/g, "_").slice(0, 60) || "shared-copywriting";
}

function timestampForFile() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

function formatBytes(value) {
  const bytes = Number(value) || 0;
  if (bytes >= 1024 * 1024) return `${Math.ceil(bytes / 1024 / 1024)}MB`;
  if (bytes >= 1024) return `${Math.ceil(bytes / 1024)}KB`;
  return `${bytes}B`;
}

function normalizeSharedErrorMessage(message, fallback) {
  const text = String(message || "").trim();
  if (!text) return fallback;
  if (/JSON|Unexpected token|not valid JSON|HTML|DOCTYPE|不是 JSON/i.test(text)) {
    return "授权总控返回了网页或非 JSON 内容，通常是服务地址、网关或后台服务异常。";
  }
  if (/body|size|too large|413|超过|过大|too big/i.test(text)) {
    return "共享包太大或超过服务器限制。可以改用“导出共享包”手动发送给别人导入。";
  }
  if (/timeout|超时|aborted|AbortError/i.test(text)) {
    return "连接授权总控超时，请检查公司网络或稍后重试。";
  }
  if (/fetch failed|ECONN|ENOTFOUND|EAI_AGAIN|network|网络/i.test(text)) {
    return "连接授权总控失败，请检查公司网络或 VPN。";
  }
  return text;
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

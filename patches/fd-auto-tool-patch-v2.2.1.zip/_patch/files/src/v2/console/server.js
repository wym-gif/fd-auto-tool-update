import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";
import {
  deleteIntervalPreset,
  loadConsoleSettings,
  loadIntervalPresets,
  saveConsoleSettings,
  saveIntervalPreset
} from "./settings.js";
import { createConsoleState } from "./state.js";
import { createConsoleWorkflow } from "./workflow.js";
import {
  assertCompanyAccessAllowed,
  getLicenseDiagnostics,
  getLicenseStatus,
  submitLicenseHeartbeat,
  submitLicenseRequest
} from "../license/license-manager.js";
import {
  createStableBackup,
  getVersionStatus,
  openBackupDir,
  prepareLatestVersionUpdate,
  rollbackToPreviousStableVersion,
  updateToLatestVersion
} from "../version/version-manager.js";
import {
  ensureV2ControlledBrowser,
  loadV2ControlledBrowserState
} from "../browser/controlled-browser.js";
import {
  deleteTuoRosterLibraryItem,
  listTuoRosterLibrary,
  renameTuoRosterLibraryItem,
  resolveTuoRosterLibraryItem,
  saveTuoRosterToLibrary
} from "../tuo/tuo-roster-library.js";
import {
  deleteCmsConfigLibraryItem,
  listCmsConfigLibrary,
  renameCmsConfigLibraryItem,
  resolveCmsConfigLibraryItem,
  saveCmsConfigToLibrary
} from "../cms/cms-config-library.js";
import { createCmsConfigFormSnapshot } from "../cms/cms-config-form.js";
import { buildCmsConfigSnapshot } from "../cms/cms-config-snapshot.js";

export async function createConsoleServer(projectRoot, options = {}) {
  const licenseOptions = pickLicenseOptions(options);
  const state = createConsoleState();
  const workflow = createConsoleWorkflow({ projectRoot, state, licenseOptions });
  const serviceInfo = await buildConsoleServiceInfo(projectRoot);
  let lastResult = null;
  let ignoredRestoreRunId = "";
  let previousCompletedRunSnapshot = null;
  let closing = false;
  let backgroundUpdatePreparePromise = null;
  let stopLicenseHeartbeat = () => {};
  const removeProcessGuards = installConsoleProcessGuards({
    state,
    setLastResult(result) {
      lastResult = result;
    }
  });

  const server = http.createServer((req, res) => {
    handleRequest(req, res).catch((error) => {
      sendJson(res, error?.statusCode || 500, {
        ok: false,
        error: error?.message || String(error),
        license: error?.license
      });
    });
  });

  async function handleRequest(req, res) {
    const url = new URL(req.url || "/", "http://127.0.0.1");
    if (req.method === "GET" && url.pathname === "/") {
      const reset = url.searchParams.get("startup") === "1"
        ? resetStartupConsoleStateOnOpen(state, workflow)
        : resetTerminalConsoleStateOnOpen(state);
      if (reset) lastResult = null;
      sendHtml(res, renderConsolePage());
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/settings") {
      sendJson(res, 200, { ok: true, settings: await loadConsoleSettings(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/settings") {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, settings: await saveConsoleSettings(projectRoot, body.settings || body) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster/upload") {
      const body = await readJsonBody(req);
      const result = await saveUploadedTuoRoster(projectRoot, body);
      sendJson(res, 200, { ok: true, ...result });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/tuo-roster-library") {
      sendJson(res, 200, { ok: true, items: await listTuoRosterLibrary(projectRoot) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/cms-config-library") {
      sendJson(res, 200, { ok: true, items: await listCmsConfigLibrary(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/cms-config-library/save") {
      const body = await readJsonBody(req);
      const settings = await saveConsoleSettings(projectRoot, body.settings || {});
      const targetRunDir = body.runDir || state.snapshot().runDir;
      const snapshot = body.form
        ? createCmsConfigFormSnapshot({
            name: body.name,
            settings,
            form: body.form,
            sourceRunId: runIdFromRunDir(targetRunDir)
          })
        : await buildCmsConfigSnapshotAfterRefresh({
            workflow,
            state,
            runDir: targetRunDir,
            settings,
            name: body.name
          });
      const item = await saveCmsConfigToLibrary(projectRoot, snapshot, { name: body.name });
      const nextSettings = await saveConsoleSettings(projectRoot, { ...(await loadConsoleSettings(projectRoot)), cmsConfigId: item.id });
      sendJson(res, 200, { ok: true, item, items: await listCmsConfigLibrary(projectRoot), settings: nextSettings });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/cms-config-library/use") {
      const body = await readJsonBody(req);
      const item = await resolveCmsConfigLibraryItem(projectRoot, body.id);
      const nextSettings = await saveConsoleSettings(projectRoot, { ...(await loadConsoleSettings(projectRoot)), cmsConfigId: item.id });
      sendJson(res, 200, { ok: true, item, settings: nextSettings });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/cms-config-library/rename") {
      const body = await readJsonBody(req);
      const item = await renameCmsConfigLibraryItem(projectRoot, body.id, body.name);
      sendJson(res, 200, { ok: true, item, items: await listCmsConfigLibrary(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/cms-config-library/delete") {
      const body = await readJsonBody(req);
      const deleted = await deleteCmsConfigLibraryItem(projectRoot, body.id);
      const current = await loadConsoleSettings(projectRoot);
      const settings = current.cmsConfigId === deleted.id
        ? await saveConsoleSettings(projectRoot, { ...current, cmsConfigId: "" })
        : current;
      sendJson(res, 200, { ok: true, deleted, items: await listCmsConfigLibrary(projectRoot), settings });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster-library/save") {
      const body = await readJsonBody(req);
      const item = await saveTuoRosterToLibrary(projectRoot, body);
      sendJson(res, 200, { ok: true, item, items: await listTuoRosterLibrary(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster-library/use") {
      const body = await readJsonBody(req);
      const item = await resolveTuoRosterLibraryItem(projectRoot, body.id);
      const settings = await saveConsoleSettings(projectRoot, {
        ...(await loadConsoleSettings(projectRoot)),
        tuoRosterPath: item.filePath,
        robotStrategy: "precise"
      });
      sendJson(res, 200, { ok: true, item, settings });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster-library/rename") {
      const body = await readJsonBody(req);
      const item = await renameTuoRosterLibraryItem(projectRoot, body.id, body.name);
      sendJson(res, 200, { ok: true, item, items: await listTuoRosterLibrary(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/tuo-roster-library/delete") {
      const body = await readJsonBody(req);
      const deleted = await deleteTuoRosterLibraryItem(projectRoot, body.id);
      sendJson(res, 200, { ok: true, deleted, items: await listTuoRosterLibrary(projectRoot) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/interval-presets") {
      sendJson(res, 200, { ok: true, presets: await loadIntervalPresets(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/interval-presets/save") {
      const body = await readJsonBody(req);
      const result = await saveIntervalPreset(projectRoot, body.preset || body);
      sendJson(res, 200, { ok: true, ...result });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/interval-presets/delete") {
      const body = await readJsonBody(req);
      const result = await deleteIntervalPreset(projectRoot, body.id);
      sendJson(res, 200, { ok: true, ...result });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/status") {
      const runId = url.searchParams.get("runId") || "";
      const snapshot = state.snapshot();
      if (runId && runId === ignoredRestoreRunId && snapshot.status === "ready" && !snapshot.runDir) {
        lastResult = null;
      } else if (runId && !workflow.isRunning?.() && snapshot.status === "ready" && !snapshot.runDir) {
        const settings = await loadConsoleSettings(projectRoot);
        const restored = await workflow.restorePreviewRunState?.(runId, settings).catch((error) => ({
          ok: false,
          error: error?.message || String(error)
        }));
        if (restored?.ok) lastResult = restored;
      }
      sendJson(res, 200, { ok: true, state: state.snapshot(), lastResult });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/status/clear-stale") {
      if (workflow.isRunning?.()) {
        sendJson(res, 200, { ok: true, cleared: false, state: state.snapshot(), reason: "当前后台流程仍在运行，不能清理状态。" });
        return;
      }
      const before = state.snapshot();
      if (!isClearableStaleConsoleState(before)) {
        sendJson(res, 200, { ok: true, cleared: false, state: before, reason: "当前没有需要清理的旧状态。" });
        return;
      }
      lastResult = null;
      sendJson(res, 200, {
        ok: true,
        cleared: true,
        state: state.resetForStartup?.("刷新运行状态：已清理旧状态，预览文件仍可恢复") || state.snapshot()
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/next-run") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const beforeNextRun = state.snapshot();
      if (beforeNextRun.runDir && (beforeNextRun.lastCompletedIndex || beforeNextRun.successCount || beforeNextRun.status === "completed")) {
        previousCompletedRunSnapshot = {
          runDir: beforeNextRun.runDir,
          previewPath: beforeNextRun.previewPath,
          lastCompletedIndex: beforeNextRun.lastCompletedIndex,
          logs: beforeNextRun.logs,
          status: beforeNextRun.status
        };
      }
      ignoredRestoreRunId = runIdFromRunDir(beforeNextRun.runDir);
      lastResult = null;
      sendJson(res, 200, { ok: true, state: state.resetForNextRun?.() || state.snapshot(), clearedRunId: ignoredRestoreRunId });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/preview/restore-candidate") {
      sendJson(res, 200, { ok: true, candidate: await workflow.getRestorablePreview() });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/preview-library") {
      sendJson(res, 200, { ok: true, items: await workflow.getPreviewLibrary() });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/preview-library/shared") {
      const result = await workflow.getSharedPreviewLibrary();
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/open") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const body = await readJsonBody(req);
      const settings = await saveConsoleSettings(projectRoot, body.settings || {});
      const result = await workflow.openLibraryPreview(body.id, {
        ...settings,
        reassignPreciseTuo: body.reassignPreciseTuo === true
      });
      sendJson(res, result.ok ? 200 : 404, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/rename") {
      const body = await readJsonBody(req);
      const result = await workflow.renameLibraryPreview(body.id, body.name);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/move") {
      const body = await readJsonBody(req);
      const result = await workflow.moveLibraryPreview(body.id, body.direction);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/upload-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.uploadSharedLibraryPreview(body.id);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/export-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.exportSharedLibraryPreview(body.id);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/import-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.importSharedLibraryPreviewPackage(body);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/download-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.downloadSharedLibraryPreview(body.cloudId);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/delete-shared") {
      const body = await readJsonBody(req);
      const result = await workflow.deleteSharedLibraryPreview(body.cloudId);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview-library/delete") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const body = await readJsonBody(req);
      const result = await workflow.deleteLibraryPreview(body.id);
      sendJson(res, result.ok ? 200 : 400, result);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/continue-candidate") {
      const candidate = await buildContinueCandidate(state.snapshot());
      sendJson(res, candidate.ok ? 200 : 404, candidate);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/previous-success-tuo-cooldown") {
      const snapshot = state.snapshot();
      const candidateSource = snapshot.runDir || snapshot.lastCompletedIndex ? snapshot : (previousCompletedRunSnapshot || snapshot);
      sendJson(res, 200, { ok: true, candidate: await buildPreviousSuccessTuoCooldownCandidate(candidateSource) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/preview/restore") {
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const body = await readJsonBody(req);
      const settings = await saveConsoleSettings(projectRoot, body.settings || body);
      const result = await workflow.restoreLatestPreview(settings);
      sendJson(res, result.ok ? 200 : 404, result);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/service-info") {
      sendJson(res, 200, { ok: true, service: serviceInfo });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/license/status") {
      sendJson(res, 200, { ok: true, license: await getLicenseStatus(projectRoot, licenseOptions) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/license/diagnostics") {
      sendJson(res, 200, { ok: true, diagnostics: await getLicenseDiagnostics(projectRoot, licenseOptions) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/license/request") {
      sendJson(res, 200, { ok: true, request: await submitLicenseRequest(projectRoot, licenseOptions) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/version/status") {
      sendJson(res, 200, { ok: true, version: await getVersionStatus(projectRoot) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/backup") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能创建版本备份。" });
        return;
      }
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, result: await createStableBackup(projectRoot, backupOptions(body)) });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/update") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能更新版本。" });
        return;
      }
      const body = await readJsonBody(req);
      const result = await updateToLatestVersion(projectRoot, versionActionOptions(body));
      state.log("版本管理：已更新到最新版本，正在重启控制台服务。");
      sendJson(res, 200, { ok: true, result, message: "已更新，控制台服务将重启。" });
      scheduleConsoleRestart(projectRoot, closeServer);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/prepare-update") {
      await readJsonBody(req);
      if (backgroundUpdatePreparePromise) {
        sendJson(res, 202, { ok: true, preparing: true, message: "后台正在下载新版本。" });
        return;
      }
      backgroundUpdatePreparePromise = prepareLatestVersionUpdate(projectRoot, versionActionOptions({}))
        .then((result) => {
          if (result.ok && result.prepared) state.log(`版本管理：新版本 ${result.latestVersion || ""} 已下载好，下次启动会自动更新。`);
          else if (result.ok && result.alreadyLatest) state.log("版本管理：后台检查完成，当前已是最新版本。");
          else state.log("版本管理：后台下载更新失败：" + (result.error || "未知错误"));
          return result;
        })
        .catch((error) => {
          const result = { ok: false, error: error?.message || String(error) };
          state.log("版本管理：后台下载更新失败：" + result.error);
          return result;
        })
        .finally(() => {
          backgroundUpdatePreparePromise = null;
        });
      sendJson(res, 202, { ok: true, preparing: true, message: "已开始后台下载新版本，不影响当前操作。" });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/rollback") {
      if (isWorkflowBusy(state)) {
        sendJson(res, 409, { ok: false, error: "当前正在生成预览或正式创建，不能回退版本。" });
        return;
      }
      const body = await readJsonBody(req);
      const result = await rollbackToPreviousStableVersion(projectRoot, versionActionOptions(body));
      state.log(`版本管理：已回退到 ${result.rolledBackTo}，正在重启控制台服务。`);
      sendJson(res, 200, { ok: true, result, message: `已回退到 ${result.rolledBackTo}，控制台服务将重启。` });
      scheduleConsoleRestart(projectRoot, closeServer);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/version/open-backup-dir") {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, result: await openBackupDir(projectRoot, backupOptions(body)) });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/browser-state") {
      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const browserState = await loadV2ControlledBrowserState(projectRoot, config);
      sendJson(res, 200, {
        ok: true,
        controlled: Boolean(browserState.cdpUrl),
        cdpUrl: browserState.cdpUrl || "",
        profileDir: browserState.profileDir || ""
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/feishu-title") {
      const body = await readJsonBody(req);
      const result = await workflow.readFeishuTitle(body.feishuUrl);
      sendJson(res, result.statusCode || (result.ok ? 200 : 500), result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/heading-structure") {
      const body = await readJsonBody(req);
      const result = await workflow.readHeadingStructure(body.feishuUrl);
      sendJson(res, result.statusCode || (result.ok ? 200 : 500), result);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/control") {
      const body = await readJsonBody(req);
      const action = String(body.action || "").trim();
      if (action === "pause") sendJson(res, 200, { ok: true, state: state.pause() });
      else if (action === "resume") sendJson(res, 200, { ok: true, state: state.resume() });
      else if (action === "resume_from_index") sendJson(res, 200, { ok: true, state: state.resumeFromIndex(Number(body.targetIndex || 0)) });
      else if (action === "retry_current") sendJson(res, 200, { ok: true, state: state.retryCurrentTask("人工选择重试当前失败条") });
      else if (action === "skip_current") sendJson(res, 200, { ok: true, state: state.skipCurrentTask("人工选择跳过当前失败条") });
      else if (action === "stop") sendJson(res, 200, { ok: true, state: state.stop() });
      else sendJson(res, 400, { ok: false, error: "unknown control action" });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/generate-preview") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      if (!body.forceRegeneratePreview && await workflow.previewHasUnsavedChanges?.()) {
        sendJson(res, 409, {
          ok: false,
          code: "preview_dirty",
          error: "已有预览页有未保存修改。确认放弃这些修改并重新生成预览？"
        });
        return;
      }
      const previousSettings = await loadConsoleSettings(projectRoot);
      const settings = await saveConsoleSettings(projectRoot, body.settings || body);
      lastResult = null;
      state.log("页面请求：保存设置，生成预览");
      workflow.generatePreview({
        ...settings,
        previousFeishuUrl: previousSettings.feishuUrl || "",
        previousSuccessTuoCooldown: body.previousSuccessTuoCooldown === true,
        previousSuccessTuoNicknames: Array.isArray(body.previousSuccessTuoNicknames)
          ? body.previousSuccessTuoNicknames
          : []
      }).then((result) => {
        lastResult = result;
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("生成预览", lastResult.error);
      });
      sendJson(res, 202, { ok: true, state: state.snapshot() });
      return;
    }
    if (req.method === "POST" && (url.pathname === "/api/abandon-current-run" || url.pathname === "/api/abandon-and-regenerate")) {
      await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "generate-preview", licenseOptions);
      if (workflow.isRunning?.()) {
        state.stop("放弃本轮：正在停止当前流程，准备回到设置");
        await waitForWorkflowIdle(workflow, 8000);
      }
      if (workflow.isRunning?.()) {
        sendJson(res, 409, {
          ok: false,
          error: "当前流程还没有停下来，请稍后再点一次放弃本轮。",
          state: state.snapshot()
        });
        return;
      }
      lastResult = null;
      const abandonResult = await workflow.abandonCurrentRun?.();
      const nextState = state.resetForNextRun?.(
        "放弃本轮：已清空当前预览状态，等待重新设置",
        "本轮已放弃，请重新设置文档、时间和读取范围，然后点击“保存设置，生成预览”。"
      ) || state.snapshot();
      state.log("页面请求：放弃本轮，已回到设置阶段");
      sendJson(res, 200, { ok: true, state: nextState, closedPreviewPages: abandonResult?.closedPreviewPages || 0 });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/prepare-cms") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "prepare-cms", licenseOptions);
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const settings = await saveConsoleSettings(projectRoot, body.settings || body);
      lastResult = null;
      state.log("页面请求：进入云中客设置");
      workflow.prepareCms({ ...settings, runDir: state.snapshot().runDir }).then((result) => {
        lastResult = result;
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("CMS 准备", lastResult.error);
      });
      sendJson(res, 202, { ok: true, state: state.snapshot() });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/start-cms") {
      const body = await readJsonBody(req);
      await assertCompanyAccessAllowed(projectRoot, "start-cms", licenseOptions);
      const snapshot = state.snapshot();
      if (snapshot.status === "paused" || snapshot.control === "paused") {
        state.log("页面请求：开始创建时检测到当前已暂停，已转为继续");
        sendJson(res, 200, { ok: true, resumed: true, state: state.resume() });
        return;
      }
      if (workflow.isRunning?.()) {
        sendWorkflowBusy(res, state);
        return;
      }
      const savedSettings = await saveConsoleSettings(projectRoot, body.settings || body);
      const settings = body.temporarySettings && typeof body.temporarySettings === "object"
        ? { ...savedSettings, ...body.temporarySettings }
        : savedSettings;
      lastResult = null;
      state.log("页面请求：我已设置好，开始创建");
      workflow.startCms({ ...settings, runDir: state.snapshot().runDir, runId: body.runId }).then((result) => {
        lastResult = result;
      }).catch((error) => {
        lastResult = { ok: false, error: error?.message || String(error) };
        state.fail("正式创建 CMS", lastResult.error);
      });
      sendJson(res, 202, { ok: true, state: state.snapshot() });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/shutdown") {
      state.log("页面请求：退出程序");
      lastResult = null;
      if (workflow.isRunning?.()) {
        state.stop("退出程序：用户主动结束当前流程，不记录失败");
        await waitForWorkflowIdle(workflow, 8000);
      }
      await workflow.exitProgramSession?.();
      const nextState = state.resetForStartup?.("退出程序：已清理上次运行状态，预览文件仍可恢复") || state.snapshot();
      sendJson(res, 200, { ok: true, message: "控制台服务正在关闭", state: nextState });
      setTimeout(() => {
        closeServer().catch(() => {});
      }, 50);
      return;
    }
    sendJson(res, 404, { ok: false, error: "Not found" });
  }

  async function closeServer() {
    if (closing) return;
    closing = true;
    removeProcessGuards();
    stopLicenseHeartbeat();
    await workflow.close();
    await new Promise((resolve) => server.close(resolve));
  }

  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port || 0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });

  const address = server.address();
  const consoleUrl = `http://127.0.0.1:${address.port}/`;
  const controlledUrl = withControlledFlag(consoleUrl);
  workflow.setConsoleUrl?.(controlledUrl);
  stopLicenseHeartbeat = startLicenseHeartbeat(projectRoot, {
    licenseOptions,
    intervalMs: options.licenseHeartbeatIntervalMs,
    initialDelayMs: options.licenseHeartbeatInitialDelayMs,
    versionStatusProvider: options.versionStatusProvider
  });
  return {
    server,
    state,
    workflow,
    url: consoleUrl,
    controlledUrl,
    open: () => openControlledConsole(projectRoot, controlledUrl),
    close: closeServer
  };
}

function renderConsolePage() {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>2.0 可视化控制台</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, "Microsoft YaHei", sans-serif; background: #f3f6fb; color: #102033; }
    .topbar { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 24px 32px 18px; background: #fff; border-bottom: 1px solid #d9e2f1; }
    .title h1 { margin: 0; font-size: 21px; }
    .title p { margin: 6px 0 0; color: #53657d; font-size: 14px; }
    .top-actions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; justify-content: flex-end; }
    main { max-width: 980px; margin: 20px auto 112px; padding: 0 16px; }
    section { background: #fff; border: 1px solid #cfe0f8; border-radius: 8px; padding: 16px; margin-bottom: 12px; }
    h2 { margin: 0 0 14px; font-size: 17px; }
    .panel-note { color: #53657d; font-size: 13px; margin-top: -6px; margin-bottom: 12px; }
    .grid { display: grid; grid-template-columns: 128px 1fr; gap: 10px 12px; align-items: center; }
    .grid.compact { grid-template-columns: 120px 1fr 120px 1fr; }
    label { color: #40536b; font-size: 13px; }
    input, select, textarea { width: 100%; min-height: 38px; border: 1px solid #c9d6e8; border-radius: 6px; padding: 7px 10px; font: inherit; background: #fff; }
    textarea { min-height: 70px; resize: vertical; }
    button { min-height: 38px; border: 1px solid #9fb4d1; background: #fff; border-radius: 6px; padding: 0 14px; cursor: pointer; font-weight: 600; color: #17345c; }
    button.primary { background: #4f8ff7; border-color: #4f8ff7; color: white; }
    button.danger { background: #e11d48; border-color: #e11d48; color: white; }
    button.warn { background: #f59e0b; border-color: #f59e0b; color: white; }
    button.good { background: #59c485; border-color: #59c485; color: white; }
    button.outline-danger { border-color: #ef4444; color: #dc2626; }
    button:disabled { opacity: .55; cursor: not-allowed; }
    .check-btn { min-width: 90px; border-color: #2f73ff; color: #2f73ff; }
    .run-box { border: 1px solid #d6e2f4; border-radius: 8px; padding: 12px; background: #fbfdff; }
    .browser-warning { display: none; border-color: #fecaca; background: #fff1f2; color: #b91c1c; font-weight: 700; line-height: 1.55; }
    .version-notice { display: none; align-items: center; gap: 10px; border-color: #bfdbfe; background: #eff6ff; color: #1d4ed8; font-weight: 700; }
    .version-notice.is-open { display: flex; flex-wrap: wrap; }
    .license-panel { display: none; border-color: #fecaca; background: #fff7f7; }
    .license-panel.is-open { display: block; }
    .license-panel.authorized { border-color: #bbf7d0; background: #f0fdf4; }
    .license-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .license-head strong { font-size: 18px; color: #b91c1c; }
    .license-panel.authorized .license-head strong { color: #166534; }
    .license-diagnostics { display: grid; grid-template-columns: 150px minmax(0, 1fr); gap: 8px 12px; margin-top: 12px; font-size: 13px; }
    .license-diagnostics span:nth-child(odd) { color: #63758c; }
    .license-diagnostics strong { word-break: break-word; }
    .license-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 12px; }
    .version-panel { display: none; }
    .version-panel.is-open { display: block; }
    .version-summary { display: grid; gap: 8px; max-width: 620px; }
    .version-line { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .version-line span { color: #63758c; font-size: 14px; }
    .version-line strong { font-size: 18px; }
    .version-main-state { font-size: 18px; font-weight: 800; color: #166534; }
    .version-main-state.has-update { color: #1d4ed8; }
    .version-main-state.failed { color: #b91c1c; }
    .version-update-hint { color: #53657d; font-size: 14px; line-height: 1.5; }
    .version-grid { display: grid; grid-template-columns: 150px minmax(0, 1fr) 150px minmax(0, 1fr); gap: 10px 12px; align-items: start; }
    .version-grid span:nth-child(odd) { color: #63758c; font-size: 13px; }
    .version-grid strong { word-break: break-word; font-size: 13px; }
    .version-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }
    .version-state { margin-top: 10px; color: #53657d; font-size: 13px; line-height: 1.5; }
    details.version-advanced { margin-top: 14px; border-top: 1px solid #e3ebf6; padding-top: 12px; }
    details.version-advanced summary { cursor: pointer; color: #40536b; font-weight: 700; }
    .run-row { display: grid; grid-template-columns: 110px 1fr; gap: 10px; min-height: 30px; align-items: center; }
    .run-row span:first-child { color: #63758c; }
    .run-row strong { font-size: 16px; word-break: break-word; }
    .actions { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
    .hint { margin-top: 10px; font-size: 13px; color: #5b6f87; line-height: 1.5; }
    .choice-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .choice-grid.three { grid-template-columns: repeat(3, 1fr); }
    .choice { display: block; border: 1px solid #c9d6e8; border-radius: 8px; padding: 14px; cursor: pointer; min-height: 72px; background: #fff; }
    .choice:has(input:checked) { border-color: #2f73ff; background: #eef5ff; box-shadow: inset 0 0 0 1px #2f73ff; }
    .choice input { width: auto; min-height: auto; margin-right: 8px; }
    .choice b { font-size: 14px; }
    .choice p { margin: 6px 0 0 26px; color: #53657d; font-size: 13px; line-height: 1.45; }
    .choice-alert { margin: 6px 0 0 18px; color: #c2410c; font-size: 12px; font-weight: 700; line-height: 1.45; }
    .choice-grid > .choice { height: 100%; }
    .choice-grid .choice-grid-alert { min-width: 0; }
    .time-field-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 14px; }
    #dateField input { width: 190px; max-width: 100%; }
    .field { display: grid; gap: 6px; color: #40536b; font-size: 13px; }
    .inline-field { display: flex; gap: 8px; align-items: center; }
    .inline-field input { flex: 1; }
    .field-badge { display: inline-flex; min-height: 26px; align-items: center; border-radius: 999px; padding: 0 10px; background: #eef2ff; color: #3156a3; font-size: 12px; font-weight: 700; }
    .field-badge.warn { background: #fff7ed; color: #b45309; }
    .field-badge.bad { background: #fff1f2; color: #be123c; }
    .field-badge.good { background: #ecfdf5; color: #166534; }
    .link-feedback { grid-column: 2; color: #53657d; font-size: 13px; line-height: 1.5; }
    .link-feedback.good { color: #166534; }
    .link-feedback.warn { color: #b45309; }
    .link-feedback.bad { color: #be123c; font-weight: 700; }
    .interval-panel { margin-top: 12px; border: 1px solid #d8e5f8; border-radius: 8px; padding: 12px; background: #f8fbff; }
    .interval-panel h3 { margin: 0 0 6px; font-size: 16px; }
    .interval-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }
    .interval-tools { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; min-width: 360px; }
    .interval-tools select { width: 180px; }
    .interval-tools button { padding: 0 12px; }
    .interval-preset-panel { display: none; margin-top: 10px; border: 1px solid #cfe0f8; border-radius: 8px; padding: 10px; background: #fff; }
    .interval-preset-panel.is-open { display: block; }
    .interval-preset-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 8px; }
    .interval-preset-head strong { color: #17345c; }
    .interval-preset-list { display: grid; gap: 8px; }
    .interval-preset-empty { color: #63758c; font-size: 13px; padding: 8px 0; }
    .interval-preset-row { display: grid; grid-template-columns: minmax(160px, 1fr) minmax(180px, 1fr) auto; gap: 8px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 8px; }
    .interval-preset-summary { color: #53657d; font-size: 13px; line-height: 1.4; }
    .interval-preset-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
    .interval-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; }
    .interval-item { display: grid; grid-template-columns: 1fr 82px 14px 82px 24px; gap: 8px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 10px; background: #fff; }
    .interval-item span:first-child { color: #24425f; font-size: 14px; }
    .status-grid { display: grid; grid-template-columns: repeat(2, minmax(160px, 1fr)); gap: 10px; margin-top: 12px; }
    .stat { border: 1px solid #e1e8f2; border-radius: 6px; padding: 10px; background: #fbfcfe; min-height: 62px; }
    .stat .k { color: #6b7f98; font-size: 12px; }
    .stat .v { margin-top: 6px; font-weight: 700; word-break: break-word; }
    .recovery-panel { display: none; margin-top: 12px; border: 1px solid #fed7aa; border-radius: 8px; padding: 12px; background: #fff7ed; }
    .recovery-panel.is-open { display: block; }
    .recovery-panel h3 { margin: 0 0 6px; font-size: 15px; color: #9a3412; }
    .recovery-panel p { margin: 0; color: #7c2d12; font-size: 13px; line-height: 1.5; }
    .recovery-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
    .preview-restore-panel { display: none; margin-top: 12px; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px; background: #eff6ff; }
    .preview-restore-panel.is-open { display: block; }
    .preview-restore-panel h3 { margin: 0 0 6px; font-size: 15px; color: #1d4ed8; }
    .preview-restore-panel p { margin: 0; color: #1e3a8a; font-size: 13px; line-height: 1.5; }
    .preview-restore-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
    .source-layout { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 12px; }
    .source-card { border: 1px solid #d8e5f8; border-radius: 8px; padding: 14px; background: #fbfdff; min-height: 100%; }
    .source-card h3 { margin: 0 0 6px; font-size: 16px; color: #17345c; }
    .source-card .panel-note { margin: 0 0 12px; }
    .source-card.library-source > .library-head > div > .panel-note { margin-top: 8px; }
    .source-card.primary-source { display: flex; flex-direction: column; border-color: #bfdbfe; background: #eff6ff; }
    .source-card.primary-source .source-form { flex: 1; align-content: space-evenly; row-gap: 14px; min-height: 0; }
    .source-card.primary-source > .hint { margin-top: 12px; }
    .source-card.library-source { border-color: #fed7aa; background: #fff7ed; }
    .source-warning { margin: -4px 0 12px; color: #c2410c; font-size: 12px; font-weight: 700; line-height: 1.5; }
    .source-warning-title { display: inline-block; margin-right: 6px; font-size: 13px; }
    .source-warning-line { margin-right: 14px; }
    .library-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; flex-wrap: nowrap; }
    .library-title-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .library-search { position: relative; width: min(190px, 100%); }
    .library-search::before { content: "🔍"; position: absolute; left: 10px; top: 50%; transform: translateY(-50%); font-size: 13px; opacity: .7; pointer-events: none; }
    .library-search input { min-height: 34px; padding: 6px 10px 6px 32px; border-radius: 999px; background: #fff; }
    .library-tools { display: flex; gap: 8px; flex: 0 0 auto; align-items: center; }
    .library-tools button { padding: 0 10px; }
    .library-list { display: grid; gap: 8px; margin-top: 10px; max-height: 236px; overflow-y: auto; padding-right: 2px; }
    .library-list.compact { max-height: 160px; }
    .cms-config-panel { margin-top: 14px; border: 1px solid #c7d9f5; border-radius: 8px; background: #fff; overflow: hidden; box-shadow: 0 6px 18px rgba(37, 99, 235, .06); }
    .cms-config-statusbar { position: relative; display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; padding: 14px 16px 14px 20px; background: linear-gradient(135deg, #f1f7ff 0%, #f5f9ff 44%, #fff8ed 56%, #fff3df 100%); border-bottom: 1px solid #d7e6fb; overflow: hidden; }
    .cms-config-statusbar::before { content: ""; position: absolute; inset: 0 auto 0 0; width: 5px; background: linear-gradient(180deg, #2f73ff 0%, #7aa7ff 58%, #f6b253 100%); }
    .cms-config-statusbar::after { content: ""; position: absolute; inset: 0; pointer-events: none; background-image: repeating-linear-gradient(135deg, rgba(47, 115, 255, .055) 0 1px, transparent 1px 14px); opacity: .35; }
    .cms-config-statusbar > * { position: relative; z-index: 1; }
    .cms-config-title { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .cms-config-title h3 { position: relative; margin: 0; padding-left: 14px; color: #0f2f57; font-size: 18px; }
    .cms-config-title h3::before { content: ""; position: absolute; left: 0; top: 50%; width: 8px; height: 8px; border-radius: 999px; transform: translateY(-50%); background: #2f73ff; box-shadow: 0 0 0 4px rgba(47, 115, 255, .14); }
    .cms-config-badge { display: inline-flex; align-items: center; min-height: 24px; border-radius: 999px; padding: 0 10px; background: #e2e8f0; color: #475569; font-size: 12px; font-weight: 800; }
    .cms-config-badge.is-active { background: #dff7e9; color: #166534; box-shadow: inset 0 0 0 1px rgba(34, 197, 94, .18); }
    .cms-config-panel .panel-note { margin: 6px 0 0; color: #24425f; }
    .cms-config-body { display: grid; gap: 8px; max-height: none; overflow: visible; margin-top: 0; padding: 12px 14px 14px; background: #fff; }
    .cms-config-body.library-list.compact { max-height: 260px; overflow-y: auto; overflow-x: hidden; padding-right: 8px; scrollbar-gutter: stable; }
    .cms-config-inline-form { padding: 14px; border-bottom: 1px solid #dbe8fb; background: #fff; }
    .cms-config-inline-form.is-hidden { display: none; }
    .cms-config-empty { border: 1px dashed #9fc3ff; border-radius: 8px; padding: 14px; background: #fff; color: #40536b; line-height: 1.55; }
    .cms-config-empty strong { display: block; margin-bottom: 4px; color: #17345c; font-size: 15px; }
    .cms-config-card { border: 1px solid #bfd5ff; border-radius: 8px; padding: 12px; background: #fff; }
    .cms-config-card-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 8px; }
    .cms-config-card-title { min-width: 0; color: #17345c; font-weight: 800; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .cms-config-card-time { color: #63758c; font-size: 12px; }
    .cms-config-roles { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .cms-config-role { border: 1px solid #e0e8f4; border-radius: 6px; padding: 8px 10px; background: #f8fbff; color: #40536b; font-size: 13px; line-height: 1.45; }
    .cms-config-role b { display: block; color: #17345c; margin-bottom: 2px; }
    .cms-config-role ul { margin: 4px 0 0; padding: 0; list-style: none; display: grid; gap: 3px; }
    .cms-config-role li { color: #40536b; word-break: break-word; }
    .cms-config-role li strong { display: inline; margin: 0 4px 0 0; color: #17345c; }
    .cms-config-warning { margin-top: 6px; color: #64748b; font-size: 12px; font-weight: 600; line-height: 1.45; }
    .cms-config-wizard { width: min(920px, 100%); }
    .cms-wizard-heading { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 4px 18px 12px; border-bottom: 1px solid #edf3fb; }
    .cms-wizard-heading strong { color: #17345c; font-size: 16px; }
    .cms-wizard-heading span { color: #63758c; font-size: 12px; }
    .cms-wizard-pages { overflow: hidden; }
    .cms-wizard-page-track { display: flex; width: 200%; transform: translateX(0); transition: transform .22s ease; }
    .cms-config-wizard.is-douma .cms-wizard-page-track { transform: translateX(-50%); }
    .cms-wizard-page { flex: 0 0 50%; padding: 14px 18px; box-sizing: border-box; }
    .cms-wizard-grid { display: grid; grid-template-columns: 160px minmax(0, 1fr); gap: 10px 12px; align-items: center; }
    .cms-wizard-grid label { color: #17345c; font-weight: 700; }
    .cms-wizard-readonly { min-height: 38px; display: flex; align-items: center; padding: 0 12px; border: 1px solid #e0e8f4; border-radius: 6px; background: #f8fbff; color: #40536b; font-weight: 700; }
    .cms-wizard-radio { display: flex; gap: 22px; flex-wrap: nowrap; align-items: center; }
    .cms-wizard-radio label { display: inline-flex; align-items: center; gap: 6px; min-width: max-content; white-space: nowrap; font-weight: 500; color: #40536b; }
    .cms-wizard-radio input { width: auto; min-width: 16px; }
    .cms-wizard-error { min-height: 22px; padding: 0 18px; color: #b91c1c; font-size: 13px; }
    .library-empty { color: #63758c; font-size: 13px; padding: 8px 0; }
    .library-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 12px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 10px; background: #fbfdff; }
    .library-row.is-active, .library-manager-row.is-active { border-color: #f59e0b; background: #fffaf0; }
    .library-item-title { display: flex; align-items: center; gap: 6px; min-width: 0; }
    .library-row strong { display: block; min-width: 0; color: #17345c; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .library-row span { display: block; margin-top: 4px; color: #63758c; font-size: 12px; }
    .library-row .library-active-label, .library-manager-row .library-active-label { display: inline-flex; align-items: center; min-height: 22px; margin: 0 0 0 6px; padding: 0 8px; border-radius: 999px; background: #ffedd5; color: #c2410c; font-size: 12px; font-weight: 700; vertical-align: middle; }
    .cms-config-body .library-row { background: #fff; border-color: #d8e2f0; }
    .cms-config-body .library-row.is-active { border-color: #9fc3ff; background: #f3f8ff; box-shadow: 0 3px 10px rgba(47, 115, 255, .08); }
    .cms-config-body .library-active-label { background: #dcfce7; color: #166534; }
    .cms-config-body .library-actions button:disabled { background: #e8eef7; border-color: #d8e2f0; color: #64748b; opacity: 1; }
    .library-actions { display: flex; gap: 8px; justify-content: flex-end; align-items: center; }
    .library-actions button { padding: 0 14px; min-height: 34px; }
    .library-more { position: relative; }
    .library-more summary { list-style: none; display: inline-flex; align-items: center; min-height: 34px; padding: 0 12px; border: 1px solid #b8c7da; border-radius: 6px; background: #fff; color: #40536b; font-size: 14px; cursor: pointer; user-select: none; }
    .library-more summary::-webkit-details-marker { display: none; }
    .library-more-menu { position: absolute; right: 0; top: calc(100% + 6px); z-index: 4; display: grid; gap: 6px; min-width: 86px; padding: 8px; border: 1px solid #d8e2f0; border-radius: 8px; background: #fff; box-shadow: 0 8px 22px rgba(15, 23, 42, .16); }
    .library-more-menu .library-sort-actions { display: grid; gap: 6px; }
    .library-more-menu .library-sort-actions button { width: 100%; min-height: 30px; padding: 0 10px; }
    .library-sort-actions { display: flex; gap: 4px; }
    .library-sort-actions button { min-height: 30px; padding: 0 8px; color: #40536b; background: #fff; }
    .library-sort-actions button:disabled { opacity: .45; cursor: not-allowed; }
    .library-manager-backdrop { position: fixed; inset: 0; z-index: 30; display: none; align-items: center; justify-content: center; padding: 24px; background: rgba(15, 23, 42, .42); }
    .library-manager-backdrop.is-open { display: flex; }
    .library-manager-modal { width: min(760px, 100%); max-height: calc(100vh - 48px); overflow: auto; border: 1px solid #d8e2f0; border-radius: 10px; background: #fff; box-shadow: 0 24px 70px rgba(15, 23, 42, .24); }
    .library-manager-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; padding: 16px 18px 12px; border-bottom: 1px solid #e2e8f0; }
    .library-manager-head h3 { margin: 0; font-size: 18px; line-height: 34px; }
    .library-manager-head .panel-note { margin: 8px 0 0; line-height: 1.45; }
    .library-manager-body { padding: 14px 18px; display: grid; gap: 8px; max-height: min(58vh, 520px); overflow-y: auto; }
    .library-manager-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 12px; align-items: center; border: 1px solid #e0e8f4; border-radius: 8px; padding: 10px; background: #fbfdff; }
    .library-manager-row strong { display: block; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #17345c; }
    .library-manager-row span { display: block; margin-top: 4px; color: #63758c; font-size: 12px; }
    .library-manager-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
    .library-share-status { grid-column: 1 / -1; margin-top: -4px; color: #2563eb; font-size: 12px; line-height: 1.45; }
    .library-share-status.error { color: #b91c1c; font-weight: 700; }
    .library-share-status.success { color: #047857; font-weight: 700; }
    .library-confirm-body { padding: 18px; color: #17345c; line-height: 1.6; }
    .library-confirm-body p { margin: 0 0 12px; }
    .library-confirm-body ul { margin: 8px 0 0 20px; padding: 0; }
    .library-confirm-body li { margin: 3px 0; }
    .library-confirm-name { font-weight: 800; color: #0f2f57; word-break: break-word; }
    .library-confirm-actions { display: flex; justify-content: flex-end; gap: 10px; padding: 14px 18px 18px; border-top: 1px solid #e2e8f0; }
    #consoleActionMessage { white-space: pre-line; }
    .console-action-input { display: block; width: 100%; margin-top: 10px; }
    .console-action-error { min-height: 20px; margin-top: 8px; color: #b91c1c; font-size: 13px; }
    .precise-tuo-option { display: flex; align-items: flex-start; gap: 10px; padding: 10px 0 6px; }
    .precise-tuo-option input { width: auto; margin-top: 3px; }
    .precise-tuo-option strong { display: block; color: #17345c; }
    .precise-tuo-option p { margin: 4px 0 0; color: #4b607a; font-size: 13px; line-height: 1.35; }
    .roster-upload { margin-top: 10px; border: 1px dashed #93b4e8; border-radius: 8px; background: #f8fbff; padding: 14px; cursor: pointer; transition: border-color .15s, background .15s; }
    .roster-upload.is-dragging { border-color: #2563eb; background: #eff6ff; }
    .roster-upload-title { color: #17345c; font-weight: 700; }
    .roster-upload-note { margin-top: 4px; color: #63758c; font-size: 13px; }
    .roster-upload-status { margin-top: 8px; color: #166534; font-size: 13px; word-break: break-all; white-space: pre-line; }
    .roster-upload-error { color: #b91c1c; }
    .roster-tools { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
    .roster-tools button { min-height: 34px; padding: 0 12px; }
    .failed { color: #b91c1c; }
    .waiting { color: #92400e; }
    .done { color: #166534; }
    .links { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
    .links a { color: #2563eb; text-decoration: none; font-weight: 700; }
    pre { height: 260px; overflow: auto; white-space: pre-wrap; word-break: break-word; background: #0b1020; color: #e5e7eb; padding: 12px; border-radius: 6px; font-size: 12px; line-height: 1.45; }
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .bottom-actions { position: fixed; left: 0; right: 0; bottom: 0; background: rgba(255,255,255,.94); border-top: 1px solid #d8e2f0; padding: 14px 24px; backdrop-filter: blur(8px); }
    .bottom-inner { max-width: 980px; margin: 0 auto; display: flex; justify-content: flex-end; gap: 10px; align-items: center; }
    .save-state { margin-right: auto; color: #b45309; font-size: 13px; }
    .save-state.is-error { color: #dc2626; font-weight: 800; }
    .hidden-native { display: none; }
    @media (max-width: 780px) {
      .grid, .grid.compact { grid-template-columns: 1fr; }
      .choice-grid, .choice-grid.three { grid-template-columns: 1fr; }
      .time-field-grid, .interval-grid { grid-template-columns: 1fr; }
      .interval-item { grid-template-columns: 1fr 76px 14px 76px 22px; }
      .interval-head { display: grid; }
      .interval-tools { min-width: 0; justify-content: flex-start; }
      .interval-tools select { width: 100%; }
      .interval-preset-row { grid-template-columns: 1fr; }
      .interval-preset-actions { justify-content: flex-start; }
      .status-grid { grid-template-columns: 1fr; }
      .version-grid { grid-template-columns: 1fr; }
      .source-layout { grid-template-columns: 1fr; }
      .library-head { flex-wrap: wrap; }
      .library-row { grid-template-columns: 1fr; }
      .library-actions { grid-template-columns: repeat(3, minmax(0, 1fr)); }
      .library-actions .open-library-btn { grid-column: auto; }
      .topbar { padding: 18px; align-items: flex-start; }
      .bottom-inner { flex-wrap: wrap; justify-content: flex-start; }
      .save-state { width: 100%; }
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="title">
      <h1>妙券自动发单 2.0</h1>
      <p>这一页负责完整流程：配置参数、生成预览、人工校对、保存后正式创建 CMS 任务。</p>
    </div>
    <div class="top-actions">
      <button id="versionBtn">隐藏版本更新</button>
      <button class="check-btn" id="refreshBtn">刷新运行状态</button>
    </div>
  </header>
  <main>
    <section class="browser-warning" id="browserWarning">
      当前不是 2.0 专用可控浏览器。请从“2.0可视化控制台”正式入口启动；不要手动用普通浏览器打开控制台，否则飞书、预览页、云中客页面无法复用同一个 CDP 浏览器。
    </section>
    <section class="version-notice" id="versionNotice">
      <span id="versionNoticeText">发现新版本，可前往版本更新。</span>
      <button class="check-btn" id="versionNoticeOpenBtn">前往版本更新</button>
      <button id="versionNoticeDismissBtn">暂不更新</button>
    </section>
    <section class="license-panel" id="licensePanel">
      <div class="license-head">
        <div>
          <h2 style="margin-bottom:6px">授权检查</h2>
          <strong id="licenseMainText">正在检查授权...</strong>
        </div>
        <button class="check-btn" id="licenseRefreshBtn" type="button">重新检查</button>
      </div>
      <div class="license-diagnostics">
        <span>DNS</span><strong id="licenseDns">-</strong>
        <span>授权服务</span><strong id="licenseService">-</strong>
        <span>本机设备号</span><strong id="licenseDevice">-</strong>
        <span>处理建议</span><strong id="licenseAdvice">-</strong>
      </div>
      <div class="license-actions">
        <button class="primary" id="licenseRequestBtn" type="button">申请授权</button>
        <button id="licenseCopyDeviceBtn" type="button">复制设备号</button>
        <span class="hint" id="licenseRequestState" style="margin-top:0">未授权时可以提交申请，由管理员在总控页面审批。</span>
      </div>
    </section>
    <section class="version-panel is-open" id="versionPanel">
      <h2>版本更新</h2>
      <div class="version-summary">
        <div class="version-line"><span>当前版本：</span><strong id="versionNumber">-</strong></div>
        <div class="version-main-state" id="versionMainState">正在检查更新...</div>
        <div class="version-update-hint" id="versionUpdateHint">启动控制台时会自动检查一次，有新版本只提示，不会强制更新。</div>
      </div>
      <div class="version-actions">
        <button class="check-btn" id="versionRefreshBtn">检查更新</button>
        <button class="primary" id="versionUpdateBtn" disabled>立即更新</button>
        <button id="versionRollbackBtn">回退到上一版本</button>
      </div>
      <div class="version-state" id="versionState">版本状态未刷新。</div>
      <details class="version-advanced">
        <summary>高级信息 / 开发信息</summary>
        <div class="version-grid" style="margin-top:12px">
          <span>当前 commit</span><strong id="versionCommit">-</strong>
          <span>GitHub 远程地址</span><strong id="versionRemote">-</strong>
          <span>当前项目目录</span><strong id="versionProjectDir">-</strong>
          <span>本地修改状态</span><strong id="versionLocalChanges">-</strong>
          <span>最近本地备份</span><strong id="versionLatestBackup">-</strong>
          <span>最近 stable tag</span><strong id="versionStableTag">-</strong>
          <span>授权状态</span><strong id="licenseStatus">-</strong>
        </div>
        <div class="version-actions">
          <button id="versionBackupBtn">创建当前稳定备份</button>
          <button id="versionOpenBackupBtn">打开备份目录</button>
        </div>
      </details>
    </section>
    <section>
      <h2>运行控制</h2>
      <div class="run-box">
        <div class="run-row"><span>状态</span><strong id="status">-</strong></div>
        <div class="run-row"><span>当前</span><strong id="step">-</strong></div>
        <div class="run-row"><span>处理进度</span><strong id="current">-</strong></div>
        <div class="run-row"><span>等待原因</span><strong id="waiting">-</strong></div>
      </div>
      <div class="actions">
        <button class="warn" id="pauseBtn">暂停</button>
        <button class="good" id="resumeBtn">继续</button>
        <button class="danger" id="stopBtn">停止</button>
      </div>
      <div class="recovery-panel" id="taskErrorDecisionPanel">
        <h3>当前条创建失败，等待人工处理</h3>
        <p id="taskErrorDecisionText">请处理页面现场后选择下一步。</p>
        <div class="recovery-actions">
          <button class="primary" id="retryCurrentTaskBtn" type="button">重试这一条</button>
          <button id="skipCurrentTaskBtn" type="button">跳过这一条</button>
          <button class="danger" id="stopCurrentRunBtn" type="button">停止本轮</button>
        </div>
      </div>
      <div class="recovery-panel" id="continueDecisionPanel">
        <h3 id="continueDecisionTitle">是否继续创建？</h3>
        <p id="continueDecisionText">请确认从哪一条开始。</p>
        <div class="recovery-actions">
          <button class="primary" id="continueFromCurrentBtn" type="button">是</button>
          <button id="continueFromNextBtn" type="button">从下一条开始</button>
          <button id="continueOpenPreviewBtn" type="button">打开预览页面</button>
        </div>
      </div>
      <div class="hint">暂停/继续/停止会在后台流程检查点生效。正式创建时仍然按已保存的预览内容执行。</div>
    </section>

    <section>
      <h2>1. 选择文档/文案来源</h2>
      <div class="panel-note">先选这次要用哪份内容：填写新的飞书文档重新生成预览，或直接打开文案库里保存好的成品。</div>
      <div class="source-warning">
        <span class="source-warning-title">注意：</span>
        <span class="source-warning-line">①如果视频太大，需要提前准备视频号代码块</span>
        <span class="source-warning-line">②文案需要标明清楚每句话的说话人，不然没办法识别。有互动托需要在说话人旁边标注：（下面还说话）</span>
      </div>
      <div class="source-layout">
        <div class="source-card primary-source">
          <h3>上传新的飞书文档</h3>
          <div class="panel-note">适合这次要从飞书链接重新读取、重新生成预览。</div>
          <div class="grid source-form">
            <label>当前文档标题</label>
            <div class="inline-field"><input id="feishuTitle"><span class="field-badge" id="feishuTitleBadge">已保存</span></div>
            <label>主飞书文档链接</label>
            <div>
              <textarea id="feishuUrl"></textarea>
              <div class="actions" style="margin-top:8px"><button id="readFeishuTitleBtn" type="button">读取标题</button></div>
            </div>
            <div></div><div class="link-feedback" id="feishuLinkFeedback">链接状态：已保存</div>
          </div>
          <div class="hint">标题来自上次成功读取记录，也可以在这里手动改，用来确认你选的是哪份文档。</div>
        </div>
        <div class="source-card library-source">
          <div class="library-head">
            <div>
              <div class="library-title-row">
                <h3>使用文案库</h3>
                <div class="library-search"><input id="librarySearchInput" placeholder="搜索文案名称"></div>
              </div>
              <div class="panel-note">适合直接使用已经改好的预览成品，打开后可检查、改时间，再进入云中客设置或开始创建。</div>
            </div>
            <div class="library-tools">
              <button id="openLibraryManagerBtn" type="button">管理文案库</button>
              <button id="openSharedLibraryBtn" type="button">云端文案</button>
              <button id="refreshLibraryBtn" type="button">刷新</button>
            </div>
          </div>
          <div class="library-list" id="previewLibraryList">
            <div class="library-empty">正在读取文案库...</div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <h2>2. 发单版本</h2>
      <select class="hidden-native" id="robotStrategy"><option value="random">按页面/随机托</option><option value="fixed">固定角色前缀</option><option value="precise">精准托名单</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="robotStrategyChoice" value="random"><b>粗略版：随机托</b><p>使用当前随机托流程，同一个互动托仍会绑定同一个机器人。</p></label>
        <label class="choice"><input type="radio" name="robotStrategyChoice" value="fixed"><b>精细版：指定托</b><p>选择角色范围后再更换机器人，新增精准托玩法也放在下方配置里。</p></label>
        <div class="choice-grid-alert"><div class="choice-alert">粗略版：随机托需先在云中客页面打开【多快捷模式】</div></div>
        <div class="choice-grid-alert"><div class="choice-alert">精准版：目前只支持单组托形式</div></div>
      </div>
      <div id="preciseTuoConfig" style="margin-top:12px; display:none">
        <label class="precise-tuo-option">
          <input type="checkbox" id="preciseTuoRosterEnabled">
          <span><strong>按名单分配</strong><p>读取托名单的昵称和备注，生成预览前自动给托词分配具体说话人。</p></span>
        </label>
        <div id="preciseTuoRosterConfig" style="display:none">
          <input class="hidden-native" id="tuoRosterPath">
          <input class="hidden-native" id="tuoRosterFileInput" type="file" accept=".xlsx,.csv,.json">
          <div class="roster-upload" id="tuoRosterDropZone" role="button" tabindex="0">
            <div class="roster-upload-title">拖动托名单到这里，或点击上传</div>
            <div class="roster-upload-note">支持 XLSX/CSV/JSON，只读取“昵称”和“备注”。备注里带“备用”的托只做兜底。</div>
            <div class="roster-upload-status" id="tuoRosterUploadStatus">尚未上传名单。</div>
          </div>
          <div class="roster-tools">
            <button id="saveTuoRosterLibraryBtn" type="button">保存托人设</button>
            <button id="openTuoRosterManagerBtn" type="button">管理托人设</button>
            <button class="outline-danger" id="clearTuoRosterBtn" type="button">清空</button>
          </div>
        </div>
      </div>
    </section>

    <section>
      <h2>3. 云中客配置</h2>
      <div class="panel-note">选择本轮要套用的云中客页面设置；进入云中客后会自动按配置设置，完成后仍需你检查确认。</div>
      <div class="cms-config-panel">
        <input class="hidden-native" id="cmsConfigId">
        <div class="cms-config-statusbar">
          <div>
            <div class="cms-config-title">
              <h3>配置库</h3>
              <span class="cms-config-badge" id="cmsConfigStatusBadge">未选择配置</span>
            </div>
            <div class="panel-note" id="cmsConfigActiveText">进入云中客设置后，需要手动检查确认。</div>
          </div>
          <div class="library-tools">
            <button id="saveCmsConfigLibraryBtn" type="button">新增配置</button>
            <button id="openCmsConfigManagerBtn" type="button">管理配置</button>
            <button id="refreshCmsConfigLibraryBtn" type="button">刷新</button>
          </div>
        </div>
        <div class="cms-config-inline-form cms-config-wizard is-hidden" id="cmsConfigWizardForm">
          <div class="cms-wizard-heading">
            <strong id="cmsWizardPageTitle">托页面设置</strong>
            <span id="cmsWizardPageHint">第 1 步，共 2 步</span>
          </div>
          <div class="cms-wizard-pages">
            <div class="cms-wizard-page-track" id="cmsWizardPageTrack">
              <div class="cms-wizard-page is-active" id="cmsWizardTuoPage">
                <div class="cms-wizard-grid">
                  <label>托版本</label><input id="cmsWizardTuoModeDisplay" value="跟随上方发单版本：粗略托" disabled>
                </div>
                <div class="cms-wizard-grid" id="cmsWizardRoughFields" style="margin-top:12px">
                  <label>多快捷模式</label><div class="cms-wizard-readonly">默认开</div>
                  <label>群聊选择个数</label><div class="cms-wizard-readonly">默认全选</div>
                  <label>管理分组</label><input id="cmsRoughManagementGroup" name="cmsRoughManagementGroup" autocomplete="on" list="cmsHistoryRoughManagementGroup" data-cms-history-key="rough-management-group" placeholder="例如：137、AI测试-自动发单">
                  <label>机器人更换方式</label>
                  <select id="cmsRoughRobotSwitchMode">
                    <option value="random">随机更换机器人</option>
                    <option value="sequence">顺序更换机器人</option>
                    <option value="group_sequence">分组内顺序发送</option>
                    <option value="preset_sequence">预设顺序发送</option>
                  </select>
                  <label>任务备注</label><input id="cmsRoughTaskRemark" name="cmsRoughTaskRemark" autocomplete="on" list="cmsHistoryTaskRemark" data-cms-history-key="task-remark" placeholder="例如：测试88">
                </div>
                <div class="cms-wizard-grid" id="cmsWizardPreciseFields" style="display:none; margin-top:12px">
                  <label>群包含分组</label><input id="cmsPreciseGroupFilter" name="cmsPreciseGroupFilter" autocomplete="on" list="cmsHistoryPreciseGroupFilter" data-cms-history-key="precise-group-filter" placeholder="例如：1069、AI测试--自动发单">
                  <label>群聊选择个数</label><input id="cmsPreciseGroupSelectCount" placeholder="默认全选">
                  <label>机器人分组</label><input id="cmsPreciseRobotGroup" name="cmsPreciseRobotGroup" autocomplete="on" list="cmsHistoryPreciseRobotGroup" data-cms-history-key="precise-robot-group" placeholder="例如：23、AI测试-自动发单托号">
                  <label>任务备注</label><input id="cmsPreciseTaskRemark" name="cmsPreciseTaskRemark" autocomplete="on" list="cmsHistoryTaskRemark" data-cms-history-key="task-remark" placeholder="例如：测试88">
                </div>
              </div>
              <div class="cms-wizard-page" id="cmsWizardDoumaPage">
                <div class="cms-wizard-grid">
                  <label>是否使用群分组</label>
                  <div class="cms-wizard-radio">
                    <label><input type="radio" name="cmsDoumaGroupSearchMode" value="group" checked> 是</label>
                    <label><input type="radio" name="cmsDoumaGroupSearchMode" value="keyword"> 否</label>
                  </div>
                  <label>群聊选择个数</label><div class="cms-wizard-readonly" id="cmsDoumaGroupSelectDefault">默认全选</div>
                  <label id="cmsDoumaGroupValueLabel">群分组名称</label><input id="cmsDoumaGroupValue" name="cmsDoumaGroupValue" autocomplete="on" list="cmsHistoryDoumaGroupValue" data-cms-history-key="douma-group-value" placeholder="填写分组名字">
                  <label>是否使用机器人分组</label>
                  <div class="cms-wizard-radio">
                    <label><input type="radio" name="cmsDoumaRobotSearchMode" value="group" checked> 是</label>
                    <label><input type="radio" name="cmsDoumaRobotSearchMode" value="keyword"> 否</label>
                  </div>
                  <label>机器人选择个数</label><div class="cms-wizard-readonly" id="cmsDoumaRobotSelectDefault">默认 1</div>
                  <label id="cmsDoumaRobotValueLabel">机器人分组名称</label><input id="cmsDoumaRobotValue" name="cmsDoumaRobotValue" autocomplete="on" list="cmsHistoryDoumaRobotValue" data-cms-history-key="douma-robot-value" placeholder="填写分组名字">
                  <label>任务备注</label><input id="cmsDoumaTaskRemark" name="cmsDoumaTaskRemark" autocomplete="on" list="cmsHistoryTaskRemark" data-cms-history-key="task-remark" placeholder="例如：测试88">
                </div>
              </div>
            </div>
          </div>
          <datalist id="cmsHistoryRoughManagementGroup"></datalist>
          <datalist id="cmsHistoryPreciseGroupFilter"></datalist>
          <datalist id="cmsHistoryPreciseRobotGroup"></datalist>
          <datalist id="cmsHistoryDoumaGroupValue"></datalist>
          <datalist id="cmsHistoryDoumaRobotValue"></datalist>
          <datalist id="cmsHistoryTaskRemark"></datalist>
          <div class="cms-wizard-error" id="cmsConfigWizardError"></div>
          <div class="library-confirm-actions">
            <button id="cmsWizardBackBtn" type="button">上一步</button>
            <button class="primary" id="cmsWizardNextBtn" type="button">下一页：设置豆妈页面</button>
            <button class="primary" id="cmsWizardSaveBtn" type="button" style="display:none">保存配置</button>
          </div>
        </div>
        <div class="cms-config-body library-list compact" id="cmsConfigLibraryList">
          <div class="library-empty">正在读取云中客配置...</div>
        </div>
      </div>
    </section>

    <section>
      <h2>4. 机器人不在群</h2>
      <select class="hidden-native" id="robotNotInGroupPolicy"><option value="ignore">不用管，直接创建</option><option value="switch_robot">自动更换机器人后再创建</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="robotNotInGroupPolicyChoice" value="ignore"><b>不用管，直接创建</b><p>确认弹窗提示机器人不在群时，仍然点击确认创建。</p></label>
        <label class="choice"><input type="radio" name="robotNotInGroupPolicyChoice" value="switch_robot"><b>自动更换机器人后再创建</b><p>取消弹窗，点击当前页面更换机器人，再重新执行发送检查。</p></label>
      </div>
      <div class="grid" id="robotNotInGroupRetryConfig" style="margin-top:12px">
        <label>最多重试次数</label><input id="robotNotInGroupMaxRetries" type="number" min="1" value="5">
      </div>
      <div class="hint" id="robotNotInGroupHint">连续 5 次仍不在群，就停止当前批次并提示人工处理。</div>
    </section>

    <section>
      <h2>5. 读取范围</h2>
      <select class="hidden-native" id="rangeMode"><option value="range">指定开始结束位置</option><option value="full">全文读取</option><option value="heading">按节奏/天数选择</option></select>
      <div class="choice-grid three">
        <label class="choice"><input type="radio" name="rangeModeChoice" value="full"><b>全文读取</b><p>适合文档不变或只发本次内容。</p></label>
        <label class="choice"><input type="radio" name="rangeModeChoice" value="range"><b>指定开始/结束位置</b><p>从开始位置读到结束那条为止。</p></label>
        <label class="choice"><input type="radio" name="rangeModeChoice" value="heading"><b>按节奏/天数选择</b><p>从飞书左侧目录读取标题结构后选择范围。</p></label>
      </div>
      <div class="grid" id="rangeInputs" style="margin-top:12px">
        <label>开始位置</label><input id="startKeyword">
        <label>结束位置</label><input id="endKeyword" placeholder="空=到文档末尾">
      </div>
      <div class="grid" id="headingRangeInputs" style="margin-top:12px; display:none">
        <label>标题结构</label><div class="inline-field"><button id="readHeadingStructureBtn" type="button">读取/刷新标题结构</button><span class="field-badge warn" id="headingStructureBadge">待读取</span></div>
        <label>选择方式</label><div><select class="hidden-native" id="headingSelectionMode"><option value="single">单天</option><option value="range">范围</option></select><div class="choice-grid"><label class="choice"><input type="radio" name="headingSelectionModeChoice" value="single"><b>单天</b><p>选择某一天的整天或单独节奏/阶段。</p></label><label class="choice"><input type="radio" name="headingSelectionModeChoice" value="range"><b>范围</b><p>选择开始天和结束天，读取中间整天内容。</p></label></div></div>
        <label class="heading-single-field">第几天</label><select class="heading-single-field" id="headingDay"><option value="">请先读取标题结构</option></select>
        <label class="heading-single-field">节奏/阶段</label><select class="heading-single-field" id="headingRhythm"><option value="">整天</option></select>
        <label class="heading-range-field">开始第几天</label><select class="heading-range-field" id="headingStartDay"><option value="">请先读取标题结构</option></select>
        <label class="heading-range-field">结束第几天</label><select class="heading-range-field" id="headingEndDay"><option value="">请先读取标题结构</option></select>
        <label>自动范围</label><div class="hint" id="headingRangeHint">从选中标题下方开始，到下一个同级标题前；朋友圈默认跳过。</div>
      </div>
      <div class="hint" id="rangeHint"></div>
    </section>

    <section>
      <h2>6. 时间模式</h2>
      <select class="hidden-native" id="scheduleMode"><option value="doc">文档时间</option><option value="realtime">实时跟发</option><option value="catchup">补发到文档时间</option></select>
      <div class="choice-grid">
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="doc"><b>文档时间</b><p>按飞书上写的时间定。适用：文案时间已经排好。</p></label>
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="realtime"><b>实时跟发</b><p>按输入的开始时间重新生成发送时间。结束时间可留空。</p></label>
        <label class="choice"><input type="radio" name="scheduleModeChoice" value="catchup"><b>补发到文档时间</b><p>过期内容先补发，后面衔接回文档时间。</p></label>
      </div>
      <div class="hint" id="timeModeHint"></div>
      <div class="time-field-grid" id="timeFields">
        <div class="field" id="dateField"><label>第一天发单日期</label><input id="date" type="date" title="不填默认今天；第二天自动顺延"></div>
        <div class="field" id="realtimeStartField"><label>开始时间</label><input id="realtimeStartTime" placeholder="不填默认 1 分钟后开始"></div>
        <div class="field" id="catchupStartField"><label>开始时间</label><input id="currentTime" placeholder="不填默认 1 分钟后开始"></div>
        <div class="field" id="realtimeEndField"><label>结束时间</label><input id="realtimeEndTime" placeholder="可留空"></div>
      </div>
      <div class="interval-panel" id="customIntervals">
        <div class="interval-head">
          <div>
            <h3>自定义间隔范围（可选）</h3>
            <div class="panel-note">不填就使用默认规则；只影响实时跟发和补发到文档时间。</div>
          </div>
          <div class="interval-tools">
            <select id="intervalPresetSelect"><option value="">选择已保存方案</option></select>
            <button id="saveIntervalPresetBtn" type="button">保存当前为方案</button>
            <button id="manageIntervalPresetBtn" type="button">方案设置</button>
            <button id="clearIntervalsBtn" type="button">清空自定义间隔</button>
          </div>
        </div>
        <div class="interval-preset-panel" id="intervalPresetPanel">
          <div class="interval-preset-head">
            <strong>方案设置</strong>
            <button id="closeIntervalPresetPanelBtn" type="button">关闭</button>
          </div>
          <div class="interval-preset-list" id="intervalPresetList"></div>
        </div>
        <div class="interval-grid">
          <div class="interval-item"><span>不同托之间（非互动）</span><input id="differentTuoMin" type="number" min="1" placeholder="最短"><span>-</span><input id="differentTuoMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>同一个托连续说话</span><input id="sameTuoMin" type="number" min="1" placeholder="最短"><span>-</span><input id="sameTuoMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>豆妈连续内容</span><input id="doumaSameMin" type="number" min="1" placeholder="最短"><span>-</span><input id="doumaSameMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
          <div class="interval-item"><span>豆妈/托切换</span><input id="roleSwitchMin" type="number" min="1" placeholder="最短"><span>-</span><input id="roleSwitchMax" type="number" min="1" placeholder="最长"><span>秒</span></div>
        </div>
      </div>
      <div class="hint" id="intervalDefaultHint">不填时使用默认规则：同一个托连续文字约 20-45 秒；豆妈连续内容约 45 秒；图片/表情包/视频附近约 30-50 秒；不同托非互动约 15 秒；豆妈/托切换至少 120 秒。填写自定义后，图片/表情包/视频附近会跟随对应的豆妈连续、同托、不同托或豆妈/托切换规则。</div>
      <input class="hidden-native" id="mediaMin">
      <input class="hidden-native" id="mediaMax">
    </section>

    <section>
      <h2>7. 结果和日志</h2>
      <div class="status-grid">
        <div class="stat"><div class="k">成功/失败</div><div class="v" id="counts">-</div></div>
        <div class="stat"><div class="k">缺失文件</div><div class="v" id="missing">-</div></div>
        <div class="stat"><div class="k">run 目录</div><div class="v" id="runDir">-</div></div>
        <div class="stat"><div class="k">预览内容文件</div><div class="v" id="previewPath">-</div></div>
        <div class="stat"><div class="k">失败原因</div><div class="v failed" id="failure">-</div></div>
      </div>
      <div class="recovery-panel" id="robotRecoveryPanel">
        <h3>机器人不在群，已达到自动重试上限</h3>
        <p>可以直接按当前弹窗继续创建，也可以继续尝试更换机器人。本操作会复用本轮记录和已保存的预览内容。</p>
        <div class="recovery-actions">
          <button class="primary" id="robotDirectCreateBtn" type="button">直接创建</button>
          <select id="robotDirectCreateMode" style="width:auto; min-width:138px">
            <option value="once">只允许这次</option>
            <option value="always">以后一直</option>
          </select>
          <button id="robotRetryMoreBtn" type="button">继续更换机器人重试</button>
        </div>
      </div>
      <div class="links">
        <a id="previewLink" href="#" target="_blank" style="display:none">打开预览页</a>
      </div>
      <div class="preview-restore-panel" id="previewRestorePanel">
        <h3>检测到上次预览</h3>
        <p id="previewRestoreText">是否恢复上次预览页？</p>
        <div class="preview-restore-actions">
          <button class="primary" id="previewRestoreBtn" type="button">恢复</button>
          <button id="previewRestoreCancelBtn" type="button">取消</button>
        </div>
      </div>
      <pre id="logs"></pre>
    </section>
  </main>
  <input class="hidden-native" id="cmsUrl">
  <input class="hidden-native" id="cdpUrl">
  <input class="hidden-native" id="feishuTitleUrl">
  <select class="hidden-native" id="restoreSelection"><option value="true">是</option><option value="false">否</option></select>
  <div class="bottom-actions">
    <div class="bottom-inner">
      <span class="save-state" id="saveState">页面已就绪。</span>
      <button id="discardBtn">放弃本轮，重新设置</button>
      <button class="outline-danger" id="exitBtn">退出</button>
      <button class="primary" id="generateBtn">保存设置，生成预览</button>
      <button class="primary" id="startCmsBtn" style="display:none">我已设置好，开始创建任务</button>
      <button class="primary" id="nextRunBtn" style="display:none">开始下一轮发单</button>
    </div>
  </div>
  <div class="library-manager-backdrop" id="libraryManagerModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="libraryManagerTitle">
      <div class="library-manager-head">
        <div>
          <div class="library-title-row">
            <h3 id="libraryManagerTitle">管理文案库</h3>
            <div class="library-search"><input id="libraryManagerSearchInput" placeholder="搜索文案名称"></div>
          </div>
          <div class="panel-note">这里可以使用、改名或删除已保存的文案。删除只影响文案库，不删除原始 run。</div>
        </div>
        <div class="library-tools">
          <button id="refreshLibraryManagerBtn" type="button">刷新</button>
          <button id="closeLibraryManagerBtn" type="button">关闭</button>
        </div>
      </div>
      <div class="library-manager-body" id="libraryManagerList">
        <div class="library-empty">正在读取文案库...</div>
      </div>
    </div>
  </div>
  <div class="library-manager-backdrop" id="sharedLibraryModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="sharedLibraryTitle">
      <div class="library-manager-head">
        <div>
          <div class="library-title-row">
            <h3 id="sharedLibraryTitle">云端文案</h3>
          </div>
          <div class="panel-note">这里只显示已上传共享的文案。下载后会保存到本机文案库，素材路径会自动改成本机可用路径。</div>
        </div>
        <div class="library-tools">
          <button id="importSharedPackageBtn" type="button">导入共享包</button>
          <button id="refreshSharedLibraryBtn" type="button">刷新</button>
          <button id="closeSharedLibraryBtn" type="button">关闭</button>
        </div>
      </div>
      <input id="sharedPackageFileInput" type="file" accept=".json,application/json" hidden>
      <div class="library-manager-body" id="sharedLibraryList">
        <div class="library-empty">正在读取云端文案...</div>
      </div>
    </div>
  </div>
  <div class="library-manager-backdrop" id="cmsConfigManagerModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="cmsConfigManagerTitle">
      <div class="library-manager-head">
        <div>
          <div class="library-title-row">
            <h3 id="cmsConfigManagerTitle">管理云中客配置</h3>
            <div class="library-search"><input id="cmsConfigManagerSearchInput" placeholder="搜索配置名称"></div>
          </div>
          <div class="panel-note">这里可以使用、改名或删除已保存的云中客配置。恢复后仍需要人工确认一次。</div>
        </div>
        <div class="library-tools">
          <button id="refreshCmsConfigManagerBtn" type="button">刷新</button>
          <button id="closeCmsConfigManagerBtn" type="button">关闭</button>
        </div>
      </div>
      <div class="library-manager-body" id="cmsConfigManagerList">
        <div class="library-empty">正在读取云中客配置...</div>
      </div>
    </div>
  </div>
  <div class="library-manager-backdrop" id="consoleActionModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="consoleActionTitle">
      <div class="library-manager-head">
        <div>
          <h3 id="consoleActionTitle">确认操作</h3>
          <div class="panel-note" id="consoleActionNote">请确认后继续。</div>
        </div>
      </div>
      <div class="library-confirm-body">
        <p id="consoleActionMessage"></p>
        <input class="console-action-input" id="consoleActionInput" placeholder="">
        <div class="console-action-error" id="consoleActionError"></div>
      </div>
      <div class="library-confirm-actions">
        <button id="consoleActionCancelBtn" type="button">取消</button>
        <button class="primary" id="consoleActionConfirmBtn" type="button">确定</button>
      </div>
    </div>
  </div>
  <div class="library-manager-backdrop" id="tuoRosterManagerModal" aria-hidden="true">
    <div class="library-manager-modal" role="dialog" aria-modal="true" aria-labelledby="tuoRosterManagerTitle">
      <div class="library-manager-head">
        <div>
          <div class="library-title-row">
            <h3 id="tuoRosterManagerTitle">管理托人设</h3>
            <div class="library-search"><input id="tuoRosterManagerSearchInput" placeholder="搜索托人设名称"></div>
          </div>
          <div class="panel-note">这里可以使用、改名或删除已保存的托名单。清空当前选择不会删除这里的条目。</div>
        </div>
        <div class="library-tools">
          <button id="refreshTuoRosterManagerBtn" type="button">刷新</button>
          <button id="closeTuoRosterManagerBtn" type="button">关闭</button>
        </div>
      </div>
      <div class="library-manager-body" id="tuoRosterManagerList">
        <div class="library-empty">正在读取托人设...</div>
      </div>
    </div>
  </div>
  <script>
    const ids = ["feishuUrl","feishuTitle","feishuTitleUrl","rangeMode","startKeyword","endKeyword","headingSelectionMode","headingDay","headingRhythm","headingStartDay","headingEndDay","scheduleMode","realtimeStartTime","realtimeEndTime","currentTime","date","sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax","cmsUrl","cdpUrl","cmsConfigId","robotStrategy","tuoRosterPath","robotNotInGroupPolicy","robotNotInGroupMaxRetries","restoreSelection"];
    const $ = (id) => document.getElementById(id);
    let controlledBrowserReady = false;
    let manualStatusFeedbackUntil = 0;
    let versionNoticeDismissed = false;
    let savedFeishuUrl = "";
    let titleReadForFeishuUrl = "";
    let latestStatus = null;
    let latestVersionInfo = null;
    let versionAutoPrepareStarted = false;
    let versionPreparePollTimer = null;
    let headingStructure = null;
    let backendDisconnected = false;
    let latestLicenseDiagnostics = null;
    let licenseAllowed = false;
    let licenseCheckInFlight = false;
    let licenseAutoRefreshTimer = null;
    let previewRestoreDismissed = false;
    let previewLibraryItems = [];
    let sharedLibraryItems = [];
    let activeLibraryItemId = "";
    let consoleActionResolver = null;
    let consoleActionOptions = null;
    let tuoRosterLibraryItems = [];
    let activeTuoRosterPath = "";
    let cmsConfigLibraryItems = [];
    let activeCmsConfigId = "";
    let cmsConfigWizardPage = "tuo";
    let cmsConfigWizardOpen = false;
    let lastCmsAutoSetupFailureReason = "";
    let intervalPresets = [];
    let initialRunId = new URLSearchParams(location.search).get("runId") || "";

    checkControlledBrowser().then(loadSettings);
    loadIntervalPresets().catch(() => {});
    refreshLicenseDiagnostics({ auto: true });
    refreshVersionStatus({ startup: true });
    checkPreviewRestoreCandidate();
    loadPreviewLibrary().catch(() => {});
    loadTuoRosterLibrary().catch(() => {});
    loadCmsConfigLibrary().catch(() => {});
    bindCardGroup("robotStrategyChoice", "robotStrategy");
    bindCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
    bindCardGroup("rangeModeChoice", "rangeMode");
    bindCardGroup("headingSelectionModeChoice", "headingSelectionMode");
    bindCardGroup("scheduleModeChoice", "scheduleMode");
    updateRangeVisibility();
    updateRobotStrategyVisibility();
    updateRobotNotInGroupVisibility();
    updateScheduleModeVisibility();
    setInterval(() => refreshStatus().catch(() => {}), 1200);
    refreshStatus().catch(() => {});

    $("refreshBtn").addEventListener("click", refreshStatusManually);
    $("versionBtn").addEventListener("click", async () => {
      $("versionPanel").classList.toggle("is-open");
      const isOpen = $("versionPanel").classList.contains("is-open");
      $("versionBtn").textContent = isOpen ? "隐藏版本更新" : "版本更新";
      if (isOpen) await refreshVersionStatus();
    });
    $("versionNoticeOpenBtn").addEventListener("click", async () => {
      $("versionPanel").classList.add("is-open");
      $("versionBtn").textContent = "隐藏版本更新";
      $("versionPanel").scrollIntoView({ behavior: "smooth", block: "start" });
      await refreshVersionStatus();
    });
    $("versionNoticeDismissBtn").addEventListener("click", () => {
      versionNoticeDismissed = true;
      $("versionNotice").classList.remove("is-open");
    });
    $("versionRefreshBtn").addEventListener("click", refreshVersionStatus);
    $("licenseRefreshBtn").addEventListener("click", () => refreshLicenseDiagnostics({ manual: true }));
    $("licenseRequestBtn").addEventListener("click", requestLicenseAccess);
    $("licenseCopyDeviceBtn").addEventListener("click", copyLicenseDeviceId);
    $("versionBackupBtn").addEventListener("click", () => runVersionAction("backup"));
    $("versionUpdateBtn").addEventListener("click", () => runVersionAction("update"));
    $("versionRollbackBtn").addEventListener("click", () => runVersionAction("rollback"));
    $("versionOpenBackupBtn").addEventListener("click", () => runVersionAction("open-backup-dir"));
    $("previewRestoreBtn").addEventListener("click", restorePreviousPreview);
    $("previewRestoreCancelBtn").addEventListener("click", cancelPreviewRestore);
    $("refreshLibraryBtn").addEventListener("click", () => loadPreviewLibrary({ manual: true }));
    $("openLibraryManagerBtn").addEventListener("click", openLibraryManager);
    $("openSharedLibraryBtn").addEventListener("click", openSharedLibraryManager);
    $("closeLibraryManagerBtn").addEventListener("click", closeLibraryManager);
    $("closeSharedLibraryBtn").addEventListener("click", closeSharedLibraryManager);
    $("importSharedPackageBtn").addEventListener("click", () => $("sharedPackageFileInput").click());
    $("sharedPackageFileInput").addEventListener("change", async (event) => {
      const file = event.target.files && event.target.files[0];
      if (file) await importSharedPackageFile(file);
      event.target.value = "";
    });
    $("refreshLibraryManagerBtn").addEventListener("click", () => loadPreviewLibrary({ manual: true }));
    $("refreshSharedLibraryBtn").addEventListener("click", () => loadSharedLibrary({ manual: true }));
    $("librarySearchInput").addEventListener("input", renderPreviewLibrary);
    $("libraryManagerSearchInput").addEventListener("input", renderLibraryManager);
    $("libraryManagerModal").addEventListener("click", (event) => {
      if (event.target === $("libraryManagerModal")) closeLibraryManager();
    });
    $("sharedLibraryModal").addEventListener("click", (event) => {
      if (event.target === $("sharedLibraryModal")) closeSharedLibraryManager();
    });
    $("consoleActionModal").addEventListener("click", (event) => {
      if (event.target === $("consoleActionModal")) closeConsoleAction(false);
    });
    $("consoleActionCancelBtn").addEventListener("click", () => closeConsoleAction(false));
    $("consoleActionConfirmBtn").addEventListener("click", submitConsoleAction);
    $("consoleActionInput").addEventListener("keydown", (event) => {
      if (event.key === "Enter") submitConsoleAction();
      if (event.key === "Escape") closeConsoleAction(false);
    });
    $("saveTuoRosterLibraryBtn").addEventListener("click", saveCurrentTuoRosterToLibrary);
    $("openTuoRosterManagerBtn").addEventListener("click", openTuoRosterManager);
    $("closeTuoRosterManagerBtn").addEventListener("click", closeTuoRosterManager);
    $("refreshTuoRosterManagerBtn").addEventListener("click", () => loadTuoRosterLibrary({ manual: true }));
    $("tuoRosterManagerSearchInput").addEventListener("input", renderTuoRosterManager);
    $("tuoRosterManagerModal").addEventListener("click", (event) => {
      if (event.target === $("tuoRosterManagerModal")) closeTuoRosterManager();
    });
    $("saveCmsConfigLibraryBtn").addEventListener("click", toggleCmsConfigWizard);
    $("openCmsConfigManagerBtn").addEventListener("click", openCmsConfigManager);
    $("closeCmsConfigManagerBtn").addEventListener("click", closeCmsConfigManager);
    $("refreshCmsConfigLibraryBtn").addEventListener("click", () => loadCmsConfigLibrary({ manual: true }));
    $("refreshCmsConfigManagerBtn").addEventListener("click", () => loadCmsConfigLibrary({ manual: true }));
    $("cmsConfigManagerSearchInput").addEventListener("input", renderCmsConfigManager);
    $("cmsConfigManagerModal").addEventListener("click", (event) => {
      if (event.target === $("cmsConfigManagerModal")) closeCmsConfigManager();
    });
    $("cmsWizardBackBtn").addEventListener("click", () => setCmsConfigWizardPage("tuo"));
    $("cmsWizardNextBtn").addEventListener("click", () => {
      if (validateCmsWizardTuoPage()) setCmsConfigWizardPage("douma");
    });
    $("cmsWizardSaveBtn").addEventListener("click", submitCmsConfigWizard);
    document.querySelectorAll('input[name="cmsDoumaGroupSearchMode"], input[name="cmsDoumaRobotSearchMode"]').forEach((input) => {
      input.addEventListener("change", updateCmsWizardDoumaLabels);
    });
    setCmsConfigWizardPage("tuo");
    setCmsConfigWizardOpen(false, { resetPage: false, silent: true });
    updateCmsWizardTuoMode();
    updateCmsWizardDoumaLabels();
    initCmsWizardInputHistory();
    $("feishuUrl").addEventListener("input", handleFeishuUrlChanged);
    $("feishuUrl").addEventListener("paste", () => setTimeout(handleFeishuUrlChanged, 0));
    $("feishuTitle").addEventListener("input", handleFeishuTitleEdited);
    $("readFeishuTitleBtn").addEventListener("click", readFeishuTitle);
    $("readHeadingStructureBtn").addEventListener("click", readHeadingStructure);
    $("headingDay").addEventListener("change", updateHeadingRhythmOptions);
    $("headingRhythm").addEventListener("change", updateHeadingRangeHint);
    $("headingStartDay").addEventListener("change", updateHeadingEndDayOptions);
    $("headingEndDay").addEventListener("change", updateHeadingRangeHint);
    $("pauseBtn").addEventListener("click", () => sendControl("pause"));
    $("resumeBtn").addEventListener("click", handleResumeClick);
    $("stopBtn").addEventListener("click", () => sendControl("stop"));
    $("retryCurrentTaskBtn").addEventListener("click", () => sendControl("retry_current"));
    $("skipCurrentTaskBtn").addEventListener("click", () => {
      if (!confirm("确认跳过当前失败条，继续创建下一条？")) return;
      sendControl("skip_current");
    });
    $("stopCurrentRunBtn").addEventListener("click", () => sendControl("stop"));
    $("continueFromCurrentBtn").addEventListener("click", () => continueFromSelected("current"));
    $("continueFromNextBtn").addEventListener("click", () => continueFromSelected("next"));
    $("continueOpenPreviewBtn").addEventListener("click", openPreviewFromContinuePanel);
    $("robotNotInGroupMaxRetries").addEventListener("input", updateRobotNotInGroupVisibility);
    $("preciseTuoRosterEnabled").addEventListener("change", () => {
      $("robotStrategy").value = $("preciseTuoRosterEnabled").checked ? "precise" : "fixed";
      syncRobotStrategyGroup();
    });
    $("tuoRosterDropZone").addEventListener("click", () => $("tuoRosterFileInput").click());
    $("tuoRosterDropZone").addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        $("tuoRosterFileInput").click();
      }
    });
    $("tuoRosterFileInput").addEventListener("change", () => {
      const file = $("tuoRosterFileInput").files?.[0];
      if (file) uploadTuoRosterFile(file);
    });
    $("tuoRosterDropZone").addEventListener("dragover", (event) => {
      event.preventDefault();
      $("tuoRosterDropZone").classList.add("is-dragging");
    });
    $("tuoRosterDropZone").addEventListener("dragleave", () => $("tuoRosterDropZone").classList.remove("is-dragging"));
    $("tuoRosterDropZone").addEventListener("drop", (event) => {
      event.preventDefault();
      $("tuoRosterDropZone").classList.remove("is-dragging");
      const file = event.dataTransfer?.files?.[0];
      if (file) uploadTuoRosterFile(file);
    });
    $("clearTuoRosterBtn").addEventListener("click", clearCurrentTuoRoster);
    $("clearIntervalsBtn").addEventListener("click", clearCustomIntervals);
    $("intervalPresetSelect").addEventListener("change", applySelectedIntervalPreset);
    $("saveIntervalPresetBtn").addEventListener("click", saveCurrentIntervalPreset);
    $("manageIntervalPresetBtn").addEventListener("click", toggleIntervalPresetPanel);
    $("closeIntervalPresetPanelBtn").addEventListener("click", () => $("intervalPresetPanel").classList.remove("is-open"));
    $("discardBtn").addEventListener("click", async () => {
      const confirmed = await askConsoleConfirm({
        title: "放弃本轮，重新设置",
        note: "主动放弃，不记录失败。",
        message: [
          "确认放弃当前 run？",
          "",
          "会执行：",
          "1. 停止当前流程",
          "2. 清空本轮运行记录",
          "3. 关闭当前预览页",
          "",
          "不会删除：",
          "- 文案库内容",
          "- 已保存的预览内容",
          "",
          "下一步：重新设置后，再生成预览。"
        ].join("\\n"),
        confirmText: "放弃本轮",
        danger: true
      });
      if (!confirmed) return;
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再操作。";
        return;
      }
      setButtons("running");
      $("discardBtn").disabled = true;
      $("saveState").textContent = "正在放弃本轮，清空预览状态并关闭预览页。";
      let result;
      try {
        result = await submitAbandonCurrentRun();
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，放弃本轮未完成。请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (!result.ok) {
        setButtons(latestStatus?.status || "ready");
        $("saveState").textContent = result.error || "放弃本轮失败。";
        await refreshStatus({ manual: true }).catch(() => {});
        return;
      }
      $("saveState").textContent = "本轮已放弃，请重新设置文档、时间和读取范围，然后点击“保存设置，生成预览”。";
      await refreshStatus({ manual: true });
    });
    $("exitBtn").addEventListener("click", async () => {
      const confirmed = await askConsoleConfirm({
        title: "退出 2.0 程序",
        note: "主动退出，不记录失败。",
        message: [
          "确认退出 2.0 程序？",
          "",
          "会执行：",
          "1. 停止当前流程",
          "2. 关闭控制台和预览页",
          "3. 关闭后台服务",
          "",
          "不会删除：",
          "- 已保存的预览内容",
          "",
          "下次启动：可恢复上次预览。"
        ].join("\\n"),
        confirmText: "退出程序",
        danger: true
      });
      if (!confirmed) return;
      $("exitBtn").disabled = true;
      $("exitBtn").textContent = "正在退出...";
      $("saveState").textContent = "正在退出 2.0 程序；本次不记录失败，已保存的预览内容不会删除。";
      try {
        await postJson("/api/shutdown", {});
        try { window.close(); } catch {}
        setTimeout(() => {
          document.body.innerHTML = "<main><section><h2>已退出 2.0 程序</h2><p class='hint'>本次主动退出不记录失败。已保存的预览内容不会删除；如果当前标签页未自动关闭，可以直接关闭它；下次使用请重新双击 2.0 可视化控制台入口，并按需恢复上次预览。</p></section></main>";
        }, 300);
      } catch (error) {
        $("saveState").textContent = "退出程序请求失败：" + (error?.message || error) + "。如果页面已断开，可以直接关闭标签页后重新双击启动。";
        $("exitBtn").disabled = false;
        $("exitBtn").textContent = "退出";
      }
    });
    $("generateBtn").addEventListener("click", async () => {
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再生成预览。";
        return;
      }
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      setButtons("running");
      $("saveState").textContent = "已保存设置，正在生成预览。";
      if (isFeishuUrlDirty()) {
        $("saveState").textContent = "文档链接已更新，将重新读取标题和内容。";
        $("feishuLinkFeedback").textContent = "链接状态：已修改，正在生成预览";
        $("feishuLinkFeedback").className = "link-feedback warn";
      }
      let result;
      try {
        result = await submitGeneratePreview();
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，生成预览不会继续。请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (result.code === "preview_dirty") return;
      if (!result.ok) $("saveState").textContent = result.error || "保存设置失败。";
      else {
        savedFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
        titleReadForFeishuUrl = savedFeishuUrl;
        $("feishuTitleUrl").value = savedFeishuUrl;
        $("feishuTitleBadge").textContent = "已更新";
        $("feishuTitleBadge").className = "field-badge good";
        $("feishuLinkFeedback").textContent = "链接状态：已保存，已生成预览";
        $("feishuLinkFeedback").className = "link-feedback good";
      }
      await refreshStatus();
    });

    async function submitGeneratePreview(options = {}) {
      const cooldownChoice = options.previousSuccessTuoChoice || await askPreviousSuccessTuoCooldown();
      const result = await postJson("/api/generate-preview", {
        settings: readSettings(),
        forceRegeneratePreview: options.forceRegeneratePreview === true,
        previousSuccessTuoCooldown: cooldownChoice.enabled === true,
        previousSuccessTuoNicknames: cooldownChoice.nicknames || []
      });
      if (result.code !== "preview_dirty") return result;
      setButtons("ready");
      const confirmed = confirm(result.error || "已有预览页有未保存修改。确认放弃这些修改并重新生成预览？");
      if (!confirmed) {
        $("saveState").textContent = "已取消重新生成，当前预览页未保存修改仍保留。";
        await refreshStatus({ manual: true });
        return result;
      }
      setButtons("running");
      $("saveState").textContent = "已确认放弃旧预览未保存修改，正在重新生成预览。";
      return submitGeneratePreview({
        forceRegeneratePreview: true,
        previousSuccessTuoChoice: cooldownChoice
      });
    }

    async function askPreviousSuccessTuoCooldown() {
      if ($("robotStrategy")?.value !== "precise") return { enabled: false, nicknames: [] };
      let result;
      try {
        result = await fetchJson("/api/previous-success-tuo-cooldown");
      } catch {
        return { enabled: false, nicknames: [] };
      }
      const candidate = result?.candidate || {};
      const nicknames = Array.isArray(candidate.nicknames) ? candidate.nicknames.filter(Boolean) : [];
      if (!candidate.available || !nicknames.length) return { enabled: false, nicknames: [] };
      const preview = nicknames.slice(0, 8).join("、") + (nicknames.length > 8 ? " 等" : "");
      const confirmed = await askConsoleConfirm({
        title: "上一轮成功托冷却",
        note: "只影响本次精准托预览分配。",
        message: [
          "检测到上一轮已成功创建的托：" + preview,
          "",
          "是否把这些托加入本轮冷却池？",
          "选择“是”后，短时间内会优先避开这些托；候选不够时才会兜底使用。"
        ].join("\\n"),
        confirmText: "是，加入冷却",
        cancelText: "否，正常生成"
      });
      return confirmed ? { enabled: true, nicknames } : { enabled: false, nicknames: [] };
    }

    async function submitAbandonCurrentRun() {
      return postJsonResult("/api/abandon-current-run", {});
    }
    $("startCmsBtn").addEventListener("click", async () => {
      if (latestStatus?.status === "paused" || latestStatus?.control === "paused") {
        await startCmsWithSettings(readSettings(), "当前创建已暂停，正在继续。");
        return;
      }
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再开始创建。";
        return;
      }
      await startCmsWithSettings(readSettings(), "已确认云中客设置，正在开始正式创建。");
    });
    $("nextRunBtn").addEventListener("click", async () => {
      if (latestStatus && (latestStatus.status === "running" || latestStatus.status === "paused")) {
        $("saveState").textContent = "当前流程还在运行，不能开始下一轮。";
        return;
      }
      setButtons("running");
      $("saveState").textContent = "正在准备下一轮，保留当前配置。";
      let result;
      try {
        result = await postJson("/api/next-run", {});
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (!result.ok) {
        $("saveState").textContent = result.error || "开始下一轮失败。";
        await refreshStatus({ manual: true });
        return;
      }
      clearCurrentRunId();
      manualStatusFeedbackUntil = Date.now() + 5000;
      $("saveState").textContent = "已进入下一轮，可以修改飞书链接、时间模式，或直接生成新预览。";
      await refreshStatus({ manual: true });
    });
    $("robotDirectCreateBtn").addEventListener("click", async () => {
      const mode = $("robotDirectCreateMode").value === "always" ? "always" : "once";
      if (mode === "always") {
        if (!confirm("确认以后一直直接创建？这会把“机器人不在群”设置保存为“不用管，直接创建”。")) return;
        $("robotNotInGroupPolicy").value = "ignore";
        syncCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
        updateRobotNotInGroupVisibility();
        await startCmsWithSettings(readSettings(), "已保存为以后一直直接创建，正在用当前 run 重新开始正式创建。");
        return;
      }
      if (!confirm("确认只允许这次直接创建？本次会忽略机器人不在群提示，但不会修改以后默认设置。")) return;
      await startCmsWithSettings(readSettings(), "已选择本次直接创建，正在用当前 run 重新开始正式创建。", {
        robotNotInGroupPolicy: "ignore"
      });
    });
    $("robotRetryMoreBtn").addEventListener("click", async () => {
      const settings = {
        ...readSettings(),
        robotNotInGroupPolicy: "switch_robot",
        robotNotInGroupMaxRetries: Math.max(1, Number($("robotNotInGroupMaxRetries").value || 5))
      };
      await startCmsWithSettings(settings, "已选择继续更换机器人重试，正在用当前 run 重新开始正式创建。");
    });

    async function startCmsWithSettings(settings, message, temporarySettings = null) {
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再开始创建。";
        return;
      }
      setButtons("running");
      updateRobotRecoveryActions(null);
      $("saveState").textContent = message || "正在开始正式创建。";
      let result;
      try {
        result = await postJson("/api/start-cms", { settings, temporarySettings, runId: currentRunId() });
      } catch (error) {
        markBackendDisconnected(error, { saveMessage: "控制台后台服务已断开，正式创建不会继续。请重新双击 2.0 可视化控制台正式入口。" });
        return;
      }
      if (!result.ok) {
        $("saveState").textContent = result.error || "开始创建失败。";
        await refreshStatus({ manual: true });
        return;
      }
      await refreshStatus({ manual: true });
    }

    async function checkControlledBrowser(attempt = 0) {
      const hasControlledFlag = new URLSearchParams(location.search).get("controlled") === "1";
      try {
        const result = await fetchJson("/api/browser-state");
        controlledBrowserReady = Boolean(result.ok && result.controlled && hasControlledFlag);
        if (!controlledBrowserReady && hasControlledFlag && attempt < 6) {
          setTimeout(() => checkControlledBrowser(attempt + 1), 500);
        }
        if ($("cdpUrl") && result.cdpUrl) $("cdpUrl").value = result.cdpUrl;
        $("browserWarning").style.display = controlledBrowserReady ? "none" : "block";
        if (controlledBrowserReady) {
          $("saveState").textContent = "已连接 2.0 专用可控浏览器。";
        } else {
          $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从“2.0可视化控制台”正式入口启动。";
        }
      } catch (error) {
        controlledBrowserReady = false;
        $("browserWarning").style.display = "block";
        $("saveState").textContent = "无法确认可控浏览器状态：" + (error?.message || error);
      }
      setButtons("idle");
    }

    async function loadSettings() {
      const result = await fetchJson("/api/settings");
      if (!result.ok) return;
      if (result.settings.headingDay) setSelectOptions($("headingDay"), [{ value: result.settings.headingDay, label: result.settings.headingDay }]);
      if (result.settings.headingRhythm) setSelectOptions($("headingRhythm"), [{ value: "", label: "整天" }, { value: result.settings.headingRhythm, label: result.settings.headingRhythm }]);
      if (result.settings.headingStartDay) setSelectOptions($("headingStartDay"), [{ value: result.settings.headingStartDay, label: result.settings.headingStartDay }]);
      if (result.settings.headingEndDay) setSelectOptions($("headingEndDay"), [{ value: result.settings.headingEndDay, label: result.settings.headingEndDay }]);
      for (const id of ids) if ($(id) && result.settings[id] !== undefined) $(id).value = String(result.settings[id]);
      if ($("date")) $("date").value = toDateInputValue(result.settings.date || "");
      savedFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      titleReadForFeishuUrl = normalizeFeishuUrlInput($("feishuTitleUrl").value);
      clearStaleFeishuTitleIfNeeded();
      updateFeishuLinkFeedback();
      syncFeishuTitleFromStatus(latestStatus);
      syncCardGroups();
      updateHeadingSelectionVisibility();
      updateTuoRosterUploadDisplay();
      activeCmsConfigId = $("cmsConfigId")?.value || "";
      renderCmsConfigLibrary();
    }

    function readSettings() {
      const data = {};
      for (const id of ids) data[id] = $(id)?.value || "";
      data.date = fromDateInputValue(data.date);
      data.restoreSelection = data.restoreSelection !== "false";
      data.robotNotInGroupMaxRetries = Number(data.robotNotInGroupMaxRetries || 5);
      for (const key of ["sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"]) {
        if (String(data[key] || "").trim() !== "") data[key] = Number(data[key]);
      }
      return data;
    }

    function toDateInputValue(value) {
      const text = String(value || "").trim();
      const iso = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
      if (iso) return iso[1] + "-" + String(Number(iso[2])).padStart(2, "0") + "-" + String(Number(iso[3])).padStart(2, "0");
      const md = text.match(/^(\d{1,2})\s*[\/月-]\s*(\d{1,2})(?:日|号)?$/);
      if (!md) return "";
      return new Date().getFullYear() + "-" + String(Number(md[1])).padStart(2, "0") + "-" + String(Number(md[2])).padStart(2, "0");
    }

    function fromDateInputValue(value) {
      const text = String(value || "").trim();
      const iso = text.match(/^\d{4}-(\d{1,2})-(\d{1,2})$/);
      if (iso) return Number(iso[1]) + "/" + Number(iso[2]);
      return text;
    }

    function handleFeishuUrlChanged() {
      headingStructure = null;
      resetHeadingStructureOptions("请先读取标题结构");
      clearStaleFeishuTitleIfNeeded();
      updateFeishuLinkFeedback();
    }

    function handleFeishuTitleEdited() {
      const title = $("feishuTitle").value.trim();
      if (!title || isPlaceholderFeishuTitle(title)) {
        titleReadForFeishuUrl = "";
        $("feishuTitleUrl").value = "";
        return;
      }
      titleReadForFeishuUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      $("feishuTitleUrl").value = titleReadForFeishuUrl;
    }

    function clearStaleFeishuTitleIfNeeded() {
      const currentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      const titleUrl = normalizeFeishuUrlInput($("feishuTitleUrl").value || titleReadForFeishuUrl);
      const currentTitle = $("feishuTitle").value.trim();
      if (!currentTitle || isPlaceholderFeishuTitle(currentTitle)) return false;
      if (currentUrl && titleUrl && sameFeishuDocument(currentUrl, titleUrl)) return false;
      $("feishuTitle").value = "待读取";
      titleReadForFeishuUrl = "";
      $("feishuTitleUrl").value = "";
      return true;
    }

    function updateFeishuLinkFeedback() {
      const input = $("feishuUrl").value;
      const normalized = normalizeFeishuUrlInput(input);
      const dirty = isFeishuUrlDirty();
      $("readFeishuTitleBtn").disabled = !normalized || !controlledBrowserReady;
      $("readHeadingStructureBtn").disabled = !normalized || !controlledBrowserReady;
      if (!String(input || "").trim()) {
        $("feishuTitleBadge").textContent = "待读取";
        $("feishuTitleBadge").className = "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接状态：请粘贴飞书文档链接";
        $("feishuLinkFeedback").className = "link-feedback warn";
        return;
      }
      if (!normalized) {
        $("feishuTitleBadge").textContent = "待更新";
        $("feishuTitleBadge").className = "field-badge bad";
        $("feishuLinkFeedback").textContent = "链接格式可能不正确，请检查";
        $("feishuLinkFeedback").className = "link-feedback bad";
        return;
      }
      if (dirty) {
        clearStaleFeishuTitleIfNeeded();
        $("feishuTitleBadge").textContent = "待更新";
        $("feishuTitleBadge").className = "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接已识别。检测到新的文档链接，尚未保存；链接状态：已修改，未生成预览。";
        $("feishuLinkFeedback").className = "link-feedback warn";
        $("generateBtn").classList.add("primary");
        if (controlledBrowserReady) $("generateBtn").disabled = false;
      } else {
        $("feishuTitleBadge").textContent = $("feishuTitle").value.trim() ? "已保存" : "待读取";
        $("feishuTitleBadge").className = $("feishuTitle").value.trim() ? "field-badge good" : "field-badge warn";
        $("feishuLinkFeedback").textContent = "链接已识别。链接状态：已保存";
        $("feishuLinkFeedback").className = "link-feedback good";
      }
    }

    function isFeishuUrlDirty() {
      return normalizeFeishuUrlInput($("feishuUrl").value) !== savedFeishuUrl;
    }

    function normalizeFeishuUrlInput(value) {
      const text = String(value || "")
        .replace(/[<>]/g, " ")
        .replace(/[“”]/g, '"')
        .replace(/[‘’]/g, "'")
        .trim();
      if (!text) return "";
      const markdown = text.match(/\\((https?:\\/\\/[^)]+)\\)/);
      const source = markdown?.[1] || text;
      const compactSource = source.replace(/\\s+/g, "");
      const match = compactSource.match(/https:\\/\\/\\S*feishu\\.cn\\/(?:docx|docs|wiki|sheets)\\/\\S+/i);
      const url = (match?.[0] || "").replace(/[)\\]};,，。；]+$/g, "");
      return /^https:\\/\\/[^/]*feishu\\.cn\\/(?:docx|docs|wiki|sheets)\\//i.test(url) ? url : "";
    }

    async function readFeishuTitle() {
      const feishuUrl = $("feishuUrl").value;
      if (!normalizeFeishuUrlInput(feishuUrl)) {
        $("feishuLinkFeedback").textContent = "链接格式可能不正确，请检查";
        $("feishuLinkFeedback").className = "link-feedback bad";
        return;
      }
      $("readFeishuTitleBtn").disabled = true;
      $("feishuTitleBadge").textContent = "读取中";
      $("feishuTitleBadge").className = "field-badge warn";
      $("feishuLinkFeedback").textContent = "正在读取飞书文档标题...";
      $("feishuLinkFeedback").className = "link-feedback warn";
      try {
        const result = await postJson("/api/feishu-title", { feishuUrl });
        if (!result.ok) throw new Error(result.error || "读取标题失败。");
        $("feishuTitle").value = result.title || "未读取到标题";
        titleReadForFeishuUrl = normalizeFeishuUrlInput(result.feishuUrl || feishuUrl);
        $("feishuTitleUrl").value = titleReadForFeishuUrl;
        $("feishuTitleBadge").textContent = "待更新";
        $("feishuTitleBadge").className = "field-badge warn";
        $("feishuLinkFeedback").textContent = "标题已读取，检测到新的文档链接，尚未保存；点击保存设置，生成预览后生效。";
        $("feishuLinkFeedback").className = "link-feedback good";
      } catch (error) {
        $("feishuTitle").value = $("feishuTitle").value.trim() || "待读取";
        $("feishuTitleBadge").textContent = "待读取";
        $("feishuTitleBadge").className = "field-badge bad";
        $("feishuLinkFeedback").textContent = "读取标题失败：" + (error?.message || error);
        $("feishuLinkFeedback").className = "link-feedback bad";
      } finally {
        updateFeishuLinkFeedback();
      }
    }

    async function readHeadingStructure() {
      const feishuUrl = $("feishuUrl").value;
      if (!normalizeFeishuUrlInput(feishuUrl)) {
        $("headingStructureBadge").textContent = "链接无效";
        $("headingStructureBadge").className = "field-badge bad";
        $("headingRangeHint").textContent = "链接格式可能不正确，请检查。";
        return;
      }
      $("readHeadingStructureBtn").disabled = true;
      $("headingStructureBadge").textContent = "读取中";
      $("headingStructureBadge").className = "field-badge warn";
      $("headingRangeHint").textContent = "正在读取飞书左侧目录，不会采集正文和素材。";
      try {
        const result = await postJson("/api/heading-structure", { feishuUrl });
        if (!result.ok) throw new Error(result.error || "识别标题结构失败。");
        headingStructure = result.structure || null;
        if (result.title) {
          $("feishuTitle").value = result.title;
          syncFeishuTitleFromStatus({ feishuTitle: result.title, feishuUrl: result.feishuUrl || feishuUrl });
        }
        fillHeadingOptions(headingStructure);
        $("headingStructureBadge").textContent = "已读取";
        $("headingStructureBadge").className = "field-badge good";
        updateHeadingRangeHint();
      } catch (error) {
        $("headingStructureBadge").textContent = "读取失败";
        $("headingStructureBadge").className = "field-badge bad";
        $("headingRangeHint").textContent = "识别标题结构失败：" + (error?.message || error);
      } finally {
        $("readHeadingStructureBtn").disabled = false;
      }
    }

    function fillHeadingOptions(structure) {
      const days = Array.isArray(structure?.days) ? structure.days : [];
      const previousDay = $("headingDay").value;
      const previousStartDay = $("headingStartDay").value;
      const previousEndDay = $("headingEndDay").value;
      setSelectOptions($("headingDay"), days.length ? days : [{ value: "", label: "未识别到天数" }]);
      if (days.some((item) => item.value === previousDay)) $("headingDay").value = previousDay;
      else if (days[0]) $("headingDay").value = days[0].value;
      setSelectOptions($("headingStartDay"), days.length ? days : [{ value: "", label: "未识别到天数" }]);
      if (days.some((item) => item.value === previousStartDay)) $("headingStartDay").value = previousStartDay;
      else if (days[0]) $("headingStartDay").value = days[0].value;
      updateHeadingEndDayOptions(previousEndDay);
      updateHeadingRhythmOptions();
    }

    function updateHeadingRhythmOptions() {
      const day = $("headingDay").value;
      const choices = Array.isArray(headingStructure?.choices) ? headingStructure.choices : [];
      const rhythms = [];
      for (const choice of choices) {
        if (choice.day !== day || !choice.rhythm) continue;
        if (!rhythms.some((item) => item.value === choice.rhythm)) rhythms.push({ value: choice.rhythm, label: choice.rhythm });
      }
      setSelectOptions($("headingRhythm"), [{ value: "", label: "整天" }, ...rhythms]);
      updateHeadingRangeHint();
    }

    function updateHeadingEndDayOptions(preferredValue) {
      const days = Array.isArray(headingStructure?.days) ? headingStructure.days : [];
      const startDay = $("headingStartDay").value;
      const startIndex = days.findIndex((item) => item.value === startDay);
      const candidates = startIndex >= 0 ? days.slice(startIndex) : days;
      const previousEndDay = preferredValue !== undefined ? preferredValue : $("headingEndDay").value;
      setSelectOptions($("headingEndDay"), candidates.length ? candidates : [{ value: "", label: "未识别到天数" }]);
      if (candidates.some((item) => item.value === previousEndDay)) $("headingEndDay").value = previousEndDay;
      else if (candidates[0]) $("headingEndDay").value = candidates[0].value;
      updateHeadingRangeHint();
    }

    function updateHeadingRangeHint() {
      const selectionMode = $("headingSelectionMode").value || "single";
      if (selectionMode === "range") {
        const startDay = $("headingStartDay").value || "未选择";
        const endDay = $("headingEndDay").value || "未选择";
        if (!headingStructure) {
          $("headingRangeHint").textContent = "范围模式：选择开始第几天和结束第几天，读取中间整天内容；朋友圈默认跳过。";
          return;
        }
        $("headingRangeHint").textContent = "自动范围：" + startDay + " 到 " + endDay + "；读取中间整天内容；朋友圈默认跳过。";
        return;
      }
      const day = $("headingDay").value || "未选择";
      const rhythm = $("headingRhythm").value || "整天";
      if (!headingStructure) {
        $("headingRangeHint").textContent = "从选中标题下方开始，到下一个同级标题前；朋友圈默认跳过。";
        return;
      }
      $("headingRangeHint").textContent = "自动范围：" + day + " / " + rhythm + "；从对应标题下方开始，到下一个同级标题前；朋友圈默认跳过。";
    }

    function resetHeadingStructureOptions(message) {
      if (!$("headingDay") || !$("headingRhythm") || !$("headingStartDay") || !$("headingEndDay")) return;
      setSelectOptions($("headingDay"), [{ value: "", label: message || "请先读取标题结构" }]);
      setSelectOptions($("headingRhythm"), [{ value: "", label: "整天" }]);
      setSelectOptions($("headingStartDay"), [{ value: "", label: message || "请先读取标题结构" }]);
      setSelectOptions($("headingEndDay"), [{ value: "", label: message || "请先读取标题结构" }]);
      if ($("headingStructureBadge")) {
        $("headingStructureBadge").textContent = "待读取";
        $("headingStructureBadge").className = "field-badge warn";
      }
      if ($("headingRangeHint")) updateHeadingRangeHint();
    }

    function setSelectOptions(select, options) {
      const previous = select.value;
      select.innerHTML = "";
      for (const option of options) {
        const item = document.createElement("option");
        item.value = option.value || "";
        item.textContent = option.label || option.value || "";
        select.appendChild(item);
      }
      if (options.some((option) => option.value === previous)) select.value = previous;
    }

    async function checkPreviewRestoreCandidate() {
      if (previewRestoreDismissed) return;
      try {
        const result = await fetchJson("/api/preview/restore-candidate");
        const candidate = result.candidate || {};
        if (!result.ok || !candidate.available) {
          $("previewRestorePanel").classList.remove("is-open");
          return;
        }
        $("previewRestoreText").textContent = "上次预览：" + (candidate.runName || "未命名") + "，共 " + (candidate.taskCount || 0) + " 条。是否恢复这个预览页？";
        $("previewRestorePanel").classList.add("is-open");
      } catch {
        $("previewRestorePanel").classList.remove("is-open");
      }
    }

    async function restorePreviousPreview() {
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再恢复预览。";
        return;
      }
      $("previewRestoreBtn").disabled = true;
      $("previewRestoreCancelBtn").disabled = true;
      $("saveState").textContent = "正在恢复上次预览。";
      try {
        const result = await postJson("/api/preview/restore", { settings: readSettings() });
        if (!result.ok) throw new Error(result.error || "恢复上次预览失败。");
        previewRestoreDismissed = true;
        $("previewRestorePanel").classList.remove("is-open");
        $("saveState").textContent = "已恢复上次预览，请检查预览页。";
        await refreshStatus({ manual: true });
      } catch (error) {
        $("saveState").textContent = "恢复上次预览失败：" + (error?.message || error);
        $("previewRestoreBtn").disabled = false;
        $("previewRestoreCancelBtn").disabled = false;
      }
    }

    async function loadPreviewLibrary(options = {}) {
      const list = $("previewLibraryList");
      if (options.manual) {
        list.innerHTML = "<div class='library-empty'>正在刷新文案库...</div>";
        $("saveState").textContent = "正在刷新文案库。";
      }
      try {
        const result = await fetchJson("/api/preview-library");
        previewLibraryItems = Array.isArray(result.items) ? result.items : [];
        renderPreviewLibrary();
        if (options.manual) $("saveState").textContent = "文案库已刷新。";
      } catch (error) {
        list.innerHTML = "<div class='library-empty'>读取文案库失败：" + escapeText(error?.message || error) + "</div>";
      }
    }

    function renderPreviewLibrary() {
      const list = $("previewLibraryList");
      const query = normalizeSearchQuery($("librarySearchInput")?.value || "");
      list.innerHTML = "";
      if (!previewLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无已保存文案。先在预览页点击“存入文案库”。</div>";
        renderLibraryManager();
        return;
      }
      const visibleItems = previewLibraryItems.filter((item) => matchesLibrarySearch(item, query));
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的文案。</div>";
        renderLibraryManager();
        return;
      }
      visibleItems.forEach((item) => {
        const isActive = item.id && item.id === activeLibraryItemId;
        const row = document.createElement("div");
        row.className = "library-row" + (isActive ? " is-active" : "");
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名文案") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + (item.taskCount || 0) + " 条 · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-actions'>" +
          sharedLibraryButton(item) +
          "<button class='primary' data-library-open='" + escapeAttr(item.id || "") + "' type='button'>使用</button>" +
          libraryMoreMenu(item) +
          "</div>" +
          "<div class='library-share-status' data-library-share-status='" + escapeAttr(item.id || "") + "'></div>";
        list.appendChild(row);
      });
      renderLibraryManager();
    }

    function renderLibraryManager() {
      const list = $("libraryManagerList");
      if (!list) return;
      const query = normalizeSearchQuery($("libraryManagerSearchInput")?.value || "");
      list.innerHTML = "";
      if (!previewLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无已保存文案。先在预览页点击“存入文案库”。</div>";
        return;
      }
      const visibleItems = previewLibraryItems.filter((item) => matchesLibrarySearch(item, query));
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的文案。</div>";
        return;
      }
      visibleItems.forEach((item) => {
        const isActive = item.id && item.id === activeLibraryItemId;
        const row = document.createElement("div");
        row.className = "library-manager-row" + (isActive ? " is-active" : "");
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名文案") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + (item.taskCount || 0) + " 条 · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-manager-actions'>" +
          librarySortButtons(item) +
          sharedLibraryButton(item) +
          "<button data-library-export-shared='" + escapeAttr(item.id || "") + "' type='button'>导出共享包</button>" +
          "<button class='primary' data-library-open='" + escapeAttr(item.id || "") + "' type='button'>使用</button>" +
          "<button data-library-rename='" + escapeAttr(item.id || "") + "' type='button'>改名</button>" +
          "<button class='outline-danger' data-library-delete='" + escapeAttr(item.id || "") + "' type='button'>删除</button>" +
          "</div>" +
          "<div class='library-share-status' data-library-share-status='" + escapeAttr(item.id || "") + "'></div>";
        list.appendChild(row);
      });
    }

    function sharedLibraryButton(item) {
      const shared = item.shared || {};
      const label = sharedLibraryButtonLabel(item);
      const cls = shared.cloudId && label === "已共享" ? "" : "primary";
      return "<button class='" + cls + "' data-library-share='" + escapeAttr(item.id || "") + "' type='button' data-default-label='" + escapeAttr(label) + "'>" + label + "</button>";
    }

    function sharedLibraryButtonLabel(item) {
      const shared = item?.shared || {};
      if (!shared.cloudId) return "上传共享";
      return sharedLibraryNeedsUpload(item) ? "更新上传" : "已共享";
    }

    function sharedLibraryNeedsUpload(item) {
      const updatedAt = Date.parse(item?.updatedAt || "");
      const uploadedAt = Date.parse(item?.shared?.uploadedAt || "");
      if (!Number.isFinite(updatedAt) || !Number.isFinite(uploadedAt)) return false;
      return updatedAt - uploadedAt > 1000;
    }

    function librarySortButtons(item) {
      const id = item.id || "";
      const index = previewLibraryItems.findIndex((entry) => entry.id === id);
      const upDisabled = index <= 0 ? " disabled" : "";
      const downDisabled = index < 0 || index >= previewLibraryItems.length - 1 ? " disabled" : "";
      return "<span class='library-sort-actions'>" +
        "<button data-library-move='" + escapeAttr(id) + "' data-library-move-direction='up' type='button'" + upDisabled + ">上移</button>" +
        "<button data-library-move='" + escapeAttr(id) + "' data-library-move-direction='down' type='button'" + downDisabled + ">下移</button>" +
        "</span>";
    }

    function libraryMoreMenu(item) {
      return "<details class='library-more'><summary>更多</summary><div class='library-more-menu'>" +
        librarySortButtons(item) +
        "<button data-library-export-shared='" + escapeAttr(item.id || "") + "' type='button'>导出共享包</button>" +
        "</div></details>";
    }

    function normalizeSearchQuery(value) {
      return String(value || "").trim().toLowerCase();
    }

    function matchesLibrarySearch(item, query) {
      if (!query) return true;
      return String(item.name || "未命名文案").toLowerCase().includes(query);
    }

    function openLibraryManager() {
      renderLibraryManager();
      $("libraryManagerModal").classList.add("is-open");
      $("libraryManagerModal").setAttribute("aria-hidden", "false");
    }

    function closeLibraryManager() {
      $("libraryManagerModal").classList.remove("is-open");
      $("libraryManagerModal").setAttribute("aria-hidden", "true");
    }

    async function openSharedLibraryManager() {
      $("sharedLibraryModal").classList.add("is-open");
      $("sharedLibraryModal").setAttribute("aria-hidden", "false");
      await loadSharedLibrary({ manual: false });
    }

    function closeSharedLibraryManager() {
      $("sharedLibraryModal").classList.remove("is-open");
      $("sharedLibraryModal").setAttribute("aria-hidden", "true");
    }

    async function loadSharedLibrary(options = {}) {
      const list = $("sharedLibraryList");
      list.innerHTML = "<div class='library-empty'>正在读取云端文案...</div>";
      if (options.manual) $("saveState").textContent = "正在刷新云端文案。";
      try {
        const result = await fetchJson("/api/preview-library/shared");
        if (!result.ok) throw new Error(result.error || "读取云端文案失败。");
        sharedLibraryItems = Array.isArray(result.items) ? result.items : [];
        renderSharedLibrary();
        if (options.manual) $("saveState").textContent = "云端文案已刷新。";
      } catch (error) {
        const message = error?.message || error;
        list.innerHTML = "<div class='library-empty'>读取云端文案失败：" + escapeText(message) + "</div>";
        $("saveState").textContent = "读取云端文案失败：" + message;
      }
    }

    function renderSharedLibrary() {
      const list = $("sharedLibraryList");
      list.innerHTML = "";
      if (!sharedLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无云端共享文案。需要共享时，先在本机文案库点“上传共享”。</div>";
        return;
      }
      sharedLibraryItems.forEach((item) => {
        const row = document.createElement("div");
        row.className = "library-manager-row";
        const statusLabel = item.localStatus === "update_available"
          ? "有更新"
          : item.localStatus === "current"
            ? "已是最新"
            : "未下载";
        const buttonLabel = item.localStatus === "update_available" ? "更新到本机" : (item.localStatus === "current" ? "已下载" : "下载使用");
        const disabled = item.localStatus === "current" ? " disabled" : "";
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名文案") + "</strong>" +
          "<span class='library-active-label'>" + statusLabel + "</span></div>" +
          "<span>" + (item.taskCount || 0) + " 条 · 云端版本 " + (item.cloudVersion || 0) + " · " + formatLibraryTime(item.updatedAt || item.uploadedAt) + "</span></div>" +
          "<div class='library-manager-actions'>" +
          "<button class='primary' data-library-cloud-download='" + escapeAttr(item.cloudId || "") + "' type='button'" + disabled + ">" + buttonLabel + "</button>" +
          "<button class='outline-danger' data-library-cloud-delete='" + escapeAttr(item.cloudId || "") + "' type='button'>删除</button>" +
          "</div>";
        list.appendChild(row);
      });
    }

    document.addEventListener("click", async (event) => {
      const openButton = event.target.closest && event.target.closest("button[data-library-open]");
      if (openButton) {
        await openPreviewLibraryItem(openButton.dataset.libraryOpen);
        return;
      }
      const renameButton = event.target.closest && event.target.closest("button[data-library-rename]");
      if (renameButton) {
        await renamePreviewLibraryItem(renameButton.dataset.libraryRename);
        return;
      }
      const shareButton = event.target.closest && event.target.closest("button[data-library-share]");
      if (shareButton) {
        await uploadSharedPreviewLibraryItem(shareButton.dataset.libraryShare);
        return;
      }
      const exportSharedButton = event.target.closest && event.target.closest("button[data-library-export-shared]");
      if (exportSharedButton) {
        await exportSharedPreviewLibraryItem(exportSharedButton.dataset.libraryExportShared);
        return;
      }
      const cloudDownloadButton = event.target.closest && event.target.closest("button[data-library-cloud-download]");
      if (cloudDownloadButton) {
        await downloadSharedPreviewLibraryItem(cloudDownloadButton.dataset.libraryCloudDownload);
        return;
      }
      const cloudDeleteButton = event.target.closest && event.target.closest("button[data-library-cloud-delete]");
      if (cloudDeleteButton) {
        await deleteSharedPreviewLibraryItem(cloudDeleteButton.dataset.libraryCloudDelete);
        return;
      }
      const moveButton = event.target.closest && event.target.closest("button[data-library-move]");
      if (moveButton) {
        await movePreviewLibraryItem(moveButton.dataset.libraryMove, moveButton.dataset.libraryMoveDirection);
        return;
      }
      const deleteButton = event.target.closest && event.target.closest("button[data-library-delete]");
      if (deleteButton) {
        await deletePreviewLibraryItem(deleteButton.dataset.libraryDelete);
        return;
      }
      const tuoUseButton = event.target.closest && event.target.closest("button[data-tuo-roster-use]");
      if (tuoUseButton) {
        await useTuoRosterLibraryItem(tuoUseButton.dataset.tuoRosterUse);
        return;
      }
      const tuoRenameButton = event.target.closest && event.target.closest("button[data-tuo-roster-rename]");
      if (tuoRenameButton) {
        await renameTuoRosterLibraryItem(tuoRenameButton.dataset.tuoRosterRename);
        return;
      }
      const tuoDeleteButton = event.target.closest && event.target.closest("button[data-tuo-roster-delete]");
      if (tuoDeleteButton) {
        await deleteTuoRosterLibraryItem(tuoDeleteButton.dataset.tuoRosterDelete);
        return;
      }
      const cmsUseButton = event.target.closest && event.target.closest("button[data-cms-config-use]");
      if (cmsUseButton) {
        await useCmsConfigLibraryItem(cmsUseButton.dataset.cmsConfigUse);
        return;
      }
      const cmsRenameButton = event.target.closest && event.target.closest("button[data-cms-config-rename]");
      if (cmsRenameButton) {
        await renameCmsConfigLibraryItem(cmsRenameButton.dataset.cmsConfigRename);
        return;
      }
      const cmsDeleteButton = event.target.closest && event.target.closest("button[data-cms-config-delete]");
      if (cmsDeleteButton) {
        await deleteCmsConfigLibraryItem(cmsDeleteButton.dataset.cmsConfigDelete);
      }
    });

    async function openPreviewLibraryItem(id) {
      if (!id) return;
      if (!controlledBrowserReady) {
        $("saveState").textContent = "当前不是 2.0 专用可控浏览器，请从正式入口启动后再打开文案库预览。";
        return;
      }
      setButtons("running");
      $("saveState").textContent = "正在打开文案库预览页，请稍等...";
      try {
        const settings = readSettings();
        const reassignPreciseTuo = await confirmLibraryPreciseTuoReassign(settings);
        const result = await postJson("/api/preview-library/open", { id, settings, reassignPreciseTuo });
        if (!result.ok) throw new Error(result.error || "打开文案库预览失败。");
        activeLibraryItemId = result.item?.id || id;
        renderPreviewLibrary();
        $("saveState").textContent = "已打开文案库预览：" + (result.item?.name || "未命名文案") + (reassignPreciseTuo ? "，已按当前托名单重新分配。" : "") + "。如果没有自动切换，请点浏览器里的“妙券自动发单 - 预览确认”标签页。";
        await refreshStatus({ manual: true });
      } catch (error) {
        setButtons(latestStatus?.status || "ready");
        $("saveState").textContent = "打开文案库预览失败：" + (error?.message || error);
      }
    }

    async function confirmLibraryPreciseTuoReassign(settings) {
      if (settings.robotStrategy !== "precise" || !settings.tuoRosterPath) return false;
      return askConsoleConfirm({
        title: "文案库托名单",
        note: "只会修改本次打开的预览工作副本，不会覆盖文案库原件。",
        message: "当前已选择精准托名单。是否用当前托名单重新分配这份文案里的托？选择取消则沿用文案库保存时的托。",
        confirmText: "重新分配",
        cancelText: "沿用原托"
      });
    }

    function openConsoleAction(options = {}) {
      if (consoleActionResolver) consoleActionResolver({ confirmed: false, value: "" });
      consoleActionOptions = options;
      $("consoleActionTitle").textContent = options.title || "确认操作";
      $("consoleActionNote").textContent = options.note || "";
      $("consoleActionMessage").textContent = options.message || "";
      $("consoleActionError").textContent = "";
      $("consoleActionInput").style.display = options.input ? "block" : "none";
      $("consoleActionInput").value = options.defaultValue || "";
      $("consoleActionInput").placeholder = options.placeholder || "";
      $("consoleActionCancelBtn").textContent = options.cancelText || "取消";
      $("consoleActionConfirmBtn").textContent = options.confirmText || "确定";
      $("consoleActionConfirmBtn").className = options.danger ? "outline-danger" : "primary";
      $("consoleActionModal").classList.add("is-open");
      $("consoleActionModal").setAttribute("aria-hidden", "false");
      return new Promise((resolve) => {
        consoleActionResolver = resolve;
        setTimeout(() => {
          if (options.input) {
            $("consoleActionInput").focus();
            $("consoleActionInput").select();
          } else {
            $("consoleActionConfirmBtn").focus();
          }
        }, 0);
      });
    }

    function submitConsoleAction() {
      if (!consoleActionResolver) return;
      const value = $("consoleActionInput").value;
      const error = consoleActionOptions?.validate?.(value);
      if (error) {
        $("consoleActionError").textContent = error;
        return;
      }
      closeConsoleAction(true);
    }

    function closeConsoleAction(confirmed) {
      $("consoleActionModal").classList.remove("is-open");
      $("consoleActionModal").setAttribute("aria-hidden", "true");
      $("consoleActionCancelBtn").textContent = "取消";
      if (consoleActionResolver) {
        const resolve = consoleActionResolver;
        const value = $("consoleActionInput").value;
        consoleActionResolver = null;
        consoleActionOptions = null;
        resolve({ confirmed: Boolean(confirmed), value });
      }
    }

    async function askConsoleConfirm(options = {}) {
      const result = await openConsoleAction({ ...options, input: false });
      return Boolean(result.confirmed);
    }

    async function askConsoleText(options = {}) {
      const result = await openConsoleAction({
        ...options,
        input: true,
        validate: (value) => {
          if (!String(value || "").trim()) return options.emptyMessage || "名称不能为空。";
          return "";
        }
      });
      return result.confirmed ? String(result.value || "").trim() : null;
    }

    async function renamePreviewLibraryItem(id) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const name = await askConsoleText({
        title: "修改文案名称",
        note: "只修改文案库里保存的名称，不会重新生成预览。",
        message: "请输入新的文案名称。",
        defaultValue: item.name || "未命名文案",
        confirmText: "保存名称",
        emptyMessage: "文案名称不能为空。"
      });
      if (name === null) return;
      $("saveState").textContent = "正在修改文案名称。";
      try {
        const result = await postJson("/api/preview-library/rename", { id, name });
        if (!result.ok) throw new Error(result.error || "修改文案名称失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = "已修改文案名称：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "修改文案名称失败：" + (error?.message || error);
      }
    }

    async function uploadSharedPreviewLibraryItem(id) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const confirmed = await askConsoleConfirm({
        title: item.shared?.cloudId ? "更新共享文案" : "上传共享文案",
        note: "只上传这一份文案。其他本机文案不会自动同步。",
        message: "确认把“" + (item.name || "未命名文案") + "”上传到云端共享？素材也会一起上传。",
        confirmText: item.shared?.cloudId ? "更新上传" : "上传共享"
      });
      if (!confirmed) return;
      const pendingMessage = "正在上传共享文案，素材较多时会慢一些。";
      $("saveState").textContent = pendingMessage;
      setSharedUploadState(id, { busy: true, label: "上传中...", message: pendingMessage });
      try {
        const result = await postJson("/api/preview-library/upload-shared", { id });
        if (!result.ok) throw new Error(result.error || "上传共享文案失败。");
        const successMessage = "共享文案已上传：" + (result.item?.name || item.name || "未命名文案") + "。";
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = successMessage;
        setSharedUploadState(id, { busy: false, label: "已共享", message: successMessage, tone: "success" });
      } catch (error) {
        const message = "上传共享文案失败：" + (error?.message || error);
        $("saveState").textContent = message;
        setSharedUploadState(id, { busy: false, message, tone: "error" });
      }
    }

    async function exportSharedPreviewLibraryItem(id) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      $("saveState").textContent = "正在导出共享包。";
      try {
        const result = await postJson("/api/preview-library/export-shared", { id });
        if (!result.ok) throw new Error(result.error || "导出共享包失败。");
        $("saveState").textContent = "共享包已导出：" + (result.filePath || result.fileName || "已保存") + "。可以把这个文件手动发给别人导入。";
      } catch (error) {
        $("saveState").textContent = "导出共享包失败：" + (error?.message || error);
      }
    }

    function setSharedUploadState(id, options = {}) {
      document.querySelectorAll("button[data-library-share]").forEach((button) => {
        if (button.dataset.libraryShare !== id) return;
        if (!button.dataset.defaultLabel) button.dataset.defaultLabel = button.textContent || "上传共享";
        button.disabled = options.busy === true;
        if (options.label) button.textContent = options.label;
        else button.textContent = button.dataset.defaultLabel || "上传共享";
      });
      document.querySelectorAll("[data-library-share-status]").forEach((node) => {
        if (node.dataset.libraryShareStatus !== id) return;
        node.textContent = options.message || "";
        node.className = "library-share-status" + (options.tone ? " " + options.tone : "");
      });
    }

    async function downloadSharedPreviewLibraryItem(cloudId) {
      if (!cloudId) return;
      $("saveState").textContent = "正在下载云端文案。";
      try {
        const result = await postJson("/api/preview-library/download-shared", { cloudId });
        if (!result.ok) throw new Error(result.error || "下载云端文案失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        await loadSharedLibrary();
        $("saveState").textContent = "云端文案已保存到本机文案库：" + (result.item?.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = "下载云端文案失败：" + (error?.message || error);
      }
    }

    async function deleteSharedPreviewLibraryItem(cloudId) {
      if (!cloudId) return;
      const item = sharedLibraryItems.find((entry) => entry.cloudId === cloudId);
      const confirmed = await askConsoleConfirm({
        title: "删除云端文案",
        note: "只删除云端共享副本，不影响别人已经下载到本机的文案。",
        message: "确认删除云端文案“" + (item?.name || "未命名文案") + "”？",
        confirmText: "删除",
        danger: true
      });
      if (!confirmed) return;
      $("saveState").textContent = "正在删除云端文案。";
      try {
        const result = await postJson("/api/preview-library/delete-shared", { cloudId });
        if (!result.ok) throw new Error(result.error || "删除云端文案失败。");
        sharedLibraryItems = Array.isArray(result.items) ? result.items : sharedLibraryItems.filter((entry) => entry.cloudId !== cloudId);
        renderSharedLibrary();
        $("saveState").textContent = "云端文案已删除：" + (result.deleted?.name || item?.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = "删除云端文案失败：" + (error?.message || error);
      }
    }

    async function importSharedPackageFile(file) {
      if (!/\.json$/i.test(file.name || "")) {
        $("saveState").textContent = "导入共享包失败：请选择 .json 共享包文件。";
        return;
      }
      $("saveState").textContent = "正在导入共享包：" + file.name + "。";
      try {
        const result = await postJson("/api/preview-library/import-shared", {
          fileName: file.name,
          contentBase64: await fileToBase64(file)
        });
        if (!result.ok) throw new Error(result.error || "导入共享包失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = "共享包已导入本机文案库：" + (result.item?.name || file.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = "导入共享包失败：" + (error?.message || error);
      }
    }

    async function movePreviewLibraryItem(id, direction) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      $("saveState").textContent = "正在调整文案库顺序。";
      try {
        const result = await postJson("/api/preview-library/move", { id, direction });
        if (!result.ok) throw new Error(result.error || "调整文案库顺序失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems;
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = "已调整文案顺序：" + (result.item?.name || item.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = "调整文案库顺序失败：" + (error?.message || error);
      }
    }

    async function deletePreviewLibraryItem(id) {
      const item = previewLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const confirmed = await askConsoleConfirm({
        title: "删除文案",
        note: "只删除文案库里的副本，不删除原始 run。",
        message: "确认删除文案库里的“" + (item.name || "未命名文案") + "”？这会删除这份文案和它在文案库里的素材。",
        confirmText: "删除",
        danger: true
      });
      if (!confirmed) return;
      $("saveState").textContent = "正在删除文案库条目。";
      try {
        const result = await postJson("/api/preview-library/delete", { id });
        if (!result.ok) throw new Error(result.error || "删除文案失败。");
        previewLibraryItems = Array.isArray(result.items) ? result.items : previewLibraryItems.filter((entry) => entry.id !== id);
        if (activeLibraryItemId === id) activeLibraryItemId = "";
        renderPreviewLibrary();
        renderLibraryManager();
        $("saveState").textContent = "已删除文案：" + (result.deleted?.name || item.name || "未命名文案") + "。";
      } catch (error) {
        $("saveState").textContent = "删除文案失败：" + (error?.message || error);
      }
    }

    async function loadTuoRosterLibrary(options = {}) {
      const list = $("tuoRosterManagerList");
      if (options.manual) {
        if (list) list.innerHTML = "<div class='library-empty'>正在刷新托人设...</div>";
        $("saveState").textContent = "正在刷新托人设。";
      }
      try {
        const result = await fetchJson("/api/tuo-roster-library");
        tuoRosterLibraryItems = Array.isArray(result.items) ? result.items : [];
        updateTuoRosterUploadDisplay();
        renderTuoRosterManager();
        if (options.manual) $("saveState").textContent = "托人设已刷新。";
      } catch (error) {
        if (list) list.innerHTML = "<div class='library-empty'>读取托人设失败：" + escapeText(error?.message || error) + "</div>";
      }
    }

    function renderTuoRosterManager() {
      const list = $("tuoRosterManagerList");
      if (!list) return;
      const query = normalizeSearchQuery($("tuoRosterManagerSearchInput")?.value || "");
      list.innerHTML = "";
      if (!tuoRosterLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无已保存托人设。先上传托名单，再点击“保存托人设”。</div>";
        return;
      }
      const visibleItems = tuoRosterLibraryItems.filter((item) => matchesLibrarySearch(item, query));
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的托人设。</div>";
        return;
      }
      visibleItems.forEach((item) => {
        const isActive = sameLocalPath(item.filePath, activeTuoRosterPath || $("tuoRosterPath")?.value || "");
        const row = document.createElement("div");
        row.className = "library-manager-row" + (isActive ? " is-active" : "");
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名托人设") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + (item.rosterCount || 0) + " 个托 · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-manager-actions'>" +
          "<button class='primary' data-tuo-roster-use='" + escapeAttr(item.id || "") + "' type='button'>使用</button>" +
          "<button data-tuo-roster-rename='" + escapeAttr(item.id || "") + "' type='button'>改名</button>" +
          "<button class='outline-danger' data-tuo-roster-delete='" + escapeAttr(item.id || "") + "' type='button'>删除</button>" +
          "</div>";
        list.appendChild(row);
      });
    }

    function openTuoRosterManager() {
      renderTuoRosterManager();
      $("tuoRosterManagerModal").classList.add("is-open");
      $("tuoRosterManagerModal").setAttribute("aria-hidden", "false");
    }

    function closeTuoRosterManager() {
      $("tuoRosterManagerModal").classList.remove("is-open");
      $("tuoRosterManagerModal").setAttribute("aria-hidden", "true");
    }

    async function saveCurrentTuoRosterToLibrary() {
      const sourcePath = $("tuoRosterPath")?.value || "";
      if (!sourcePath) {
        setTuoRosterUploadStatus("请先上传或从托人设库选择名单。", true);
        return;
      }
      const defaultName = rosterNameFromPath(sourcePath);
      const name = await askConsoleText({
        title: "保存托人设名称",
        note: "保存到托人设库后，后续可以直接选择这套名单。",
        message: "请输入这套托人设的名称。",
        defaultValue: defaultName,
        confirmText: "保存",
        emptyMessage: "托人设名称不能为空。"
      });
      if (name === null) return;
      if (!String(name || "").trim()) {
        $("saveState").textContent = "托人设名称不能为空。";
        return;
      }
      $("saveState").textContent = "正在保存托人设。";
      try {
        const result = await postJson("/api/tuo-roster-library/save", { sourcePath, name });
        if (!result.ok) throw new Error(result.error || "保存托人设失败。");
        tuoRosterLibraryItems = Array.isArray(result.items) ? result.items : tuoRosterLibraryItems;
        activeTuoRosterPath = sourcePath;
        renderTuoRosterManager();
        $("saveState").textContent = "已保存托人设：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "保存托人设失败：" + (error?.message || error);
      }
    }

    async function useTuoRosterLibraryItem(id) {
      if (!id) return;
      $("saveState").textContent = "正在使用托人设。";
      try {
        const result = await postJson("/api/tuo-roster-library/use", { id });
        if (!result.ok) throw new Error(result.error || "使用托人设失败。");
        $("tuoRosterPath").value = result.item?.filePath || "";
        $("robotStrategy").value = "precise";
        $("preciseTuoRosterEnabled").checked = true;
        activeTuoRosterPath = $("tuoRosterPath").value;
        syncRobotStrategyGroup();
        updateTuoRosterUploadDisplay();
        renderTuoRosterManager();
        $("saveState").textContent = "已使用托人设：" + (result.item?.name || "未命名托人设") + "。";
      } catch (error) {
        $("saveState").textContent = "使用托人设失败：" + (error?.message || error);
      }
    }

    async function renameTuoRosterLibraryItem(id) {
      const item = tuoRosterLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const name = await askConsoleText({
        title: "修改托人设名称",
        note: "只修改托人设库里显示的名称，不会改原始名单文件。",
        message: "请输入新的托人设名称。",
        defaultValue: item.name || "未命名托人设",
        confirmText: "保存名称",
        emptyMessage: "托人设名称不能为空。"
      });
      if (name === null) return;
      if (!String(name || "").trim()) {
        $("saveState").textContent = "托人设名称不能为空。";
        return;
      }
      $("saveState").textContent = "正在修改托人设名称。";
      try {
        const result = await postJson("/api/tuo-roster-library/rename", { id, name });
        if (!result.ok) throw new Error(result.error || "修改托人设名称失败。");
        tuoRosterLibraryItems = Array.isArray(result.items) ? result.items : tuoRosterLibraryItems;
        renderTuoRosterManager();
        $("saveState").textContent = "已修改托人设名称：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "修改托人设名称失败：" + (error?.message || error);
      }
    }

    async function deleteTuoRosterLibraryItem(id) {
      const item = tuoRosterLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      if (!confirm("确认删除托人设“" + (item.name || "未命名托人设") + "”？这只删除托人设库里的副本，不会删除你原始名单文件。")) return;
      $("saveState").textContent = "正在删除托人设。";
      try {
        const result = await postJson("/api/tuo-roster-library/delete", { id });
        if (!result.ok) throw new Error(result.error || "删除托人设失败。");
        tuoRosterLibraryItems = Array.isArray(result.items) ? result.items : tuoRosterLibraryItems.filter((entry) => entry.id !== id);
        if (sameLocalPath(item.filePath, activeTuoRosterPath)) activeTuoRosterPath = "";
        renderTuoRosterManager();
        $("saveState").textContent = "已删除托人设：" + (result.deleted?.name || item.name || "未命名托人设") + "。";
      } catch (error) {
        $("saveState").textContent = "删除托人设失败：" + (error?.message || error);
      }
    }

    async function clearCurrentTuoRoster() {
      $("tuoRosterPath").value = "";
      activeTuoRosterPath = "";
      updateTuoRosterUploadDisplay();
      renderTuoRosterManager();
      try {
        await postJson("/api/settings", { settings: readSettings() });
        $("saveState").textContent = "已清空当前托名单。";
      } catch (error) {
        $("saveState").textContent = "已清空当前托名单，但保存设置失败：" + (error?.message || error);
      }
    }

    async function loadCmsConfigLibrary(options = {}) {
      const list = $("cmsConfigLibraryList");
      if (options.manual) {
        if (list) list.innerHTML = "<div class='library-empty'>正在刷新云中客配置...</div>";
        $("saveState").textContent = "正在刷新云中客配置。";
      }
      try {
        const result = await fetchJson("/api/cms-config-library");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : [];
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        if (options.manual) $("saveState").textContent = "云中客配置已刷新。";
      } catch (error) {
        if (list) list.innerHTML = "<div class='library-empty'>读取云中客配置失败：" + escapeText(error?.message || error) + "</div>";
      }
    }

    function renderCmsConfigLibrary() {
      const list = $("cmsConfigLibraryList");
      if (!list) return;
      activeCmsConfigId = $("cmsConfigId")?.value || activeCmsConfigId || "";
      const activeItem = cmsConfigLibraryItems.find((item) => item.id === activeCmsConfigId);
      const badge = $("cmsConfigStatusBadge");
      badge.textContent = activeItem ? "已选择配置" : "未选择配置";
      badge.className = "cms-config-badge" + (activeItem ? " is-active" : "");
      $("cmsConfigActiveText").textContent = activeItem
        ? "当前使用：" + (activeItem.name || "未命名配置") + "。恢复后会停在云中客页面等待你确认。"
        : "进入云中客设置后，需要手动检查确认。";
      list.innerHTML = "";
      if (!cmsConfigLibraryItems.length) {
        list.innerHTML =
          "<div class='cms-config-empty'>" +
          "<strong>暂无已保存配置</strong>" +
          "<div>点击右上角“新增配置”，填写托页面和豆妈页面后保存，以后可直接选用这套设置。</div>" +
          "</div>" +
          "<div class='cms-config-warning'>使用配置后会按记录自动设置云中客页面，并停在页面等待你检查确认；不会自动开始创建。</div>";
        renderCmsConfigManager();
        return;
      }
      const visibleItems = cmsConfigLibraryItems;
      visibleItems.forEach((item) => {
        const isActive = item.id && item.id === activeCmsConfigId;
        const row = document.createElement("div");
        row.className = "library-row" + (isActive ? " is-active" : "");
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名云中客配置") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + cmsConfigSummary(item) + " · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-actions'>" +
          (isActive
            ? "<button class='primary' data-cms-config-use='" + escapeAttr(item.id || "") + "' type='button' disabled>已使用</button>"
            : "<button class='primary' data-cms-config-use='" + escapeAttr(item.id || "") + "' type='button'>使用</button>") +
          "</div>";
        list.appendChild(row);
      });
      const warning = document.createElement("div");
      warning.className = "cms-config-warning";
      warning.textContent = "进入云中客设置后会自动套用已选配置，完成后仍需你检查确认；不会自动开始创建。";
      list.appendChild(warning);
      renderCmsConfigManager();
    }

    function renderCmsConfigManager() {
      const list = $("cmsConfigManagerList");
      if (!list) return;
      const query = normalizeSearchQuery($("cmsConfigManagerSearchInput")?.value || "");
      list.innerHTML = "";
      if (!cmsConfigLibraryItems.length) {
        list.innerHTML = "<div class='library-empty'>暂无已保存云中客配置。</div>";
        return;
      }
      const visibleItems = cmsConfigLibraryItems.filter((item) => matchesLibrarySearch(item, query));
      if (!visibleItems.length) {
        list.innerHTML = "<div class='library-empty'>没有匹配的云中客配置。</div>";
        return;
      }
      visibleItems.forEach((item) => {
        const isActive = item.id && item.id === activeCmsConfigId;
        const row = document.createElement("div");
        row.className = "library-manager-row" + (isActive ? " is-active" : "");
        row.innerHTML =
          "<div><div class='library-item-title'><strong title='" + escapeAttr(item.name || "") + "'>" + escapeText(item.name || "未命名云中客配置") + "</strong>" +
          (isActive ? "<span class='library-active-label'>当前使用</span>" : "") +
          "</div>" +
          "<span>" + cmsConfigSummary(item) + " · " + formatLibraryTime(item.updatedAt || item.createdAt) + "</span></div>" +
          "<div class='library-manager-actions'>" +
          "<button class='primary' data-cms-config-use='" + escapeAttr(item.id || "") + "' type='button'>使用</button>" +
          "<button data-cms-config-rename='" + escapeAttr(item.id || "") + "' type='button'>改名</button>" +
          "<button class='outline-danger' data-cms-config-delete='" + escapeAttr(item.id || "") + "' type='button'>删除</button>" +
          "</div>";
        list.appendChild(row);
      });
    }

    function openCmsConfigManager() {
      renderCmsConfigManager();
      $("cmsConfigManagerModal").classList.add("is-open");
      $("cmsConfigManagerModal").setAttribute("aria-hidden", "false");
    }

    function closeCmsConfigManager() {
      $("cmsConfigManagerModal").classList.remove("is-open");
      $("cmsConfigManagerModal").setAttribute("aria-hidden", "true");
    }

    function setCmsConfigWizardOpen(open, options = {}) {
      cmsConfigWizardOpen = Boolean(open);
      const form = $("cmsConfigWizardForm");
      const button = $("saveCmsConfigLibraryBtn");
      if (form) form.classList.toggle("is-hidden", !cmsConfigWizardOpen);
      if (button) button.textContent = cmsConfigWizardOpen ? "收起表单" : "新增配置";
      if (cmsConfigWizardOpen && options.resetPage !== false) setCmsConfigWizardPage("tuo");
      if (!options.silent) {
        $("saveState").textContent = cmsConfigWizardOpen
          ? "正在新增云中客配置，请填写托页面和豆妈页面设置。"
          : "已收起云中客配置表单。";
      }
    }

    function toggleCmsConfigWizard() {
      setCmsConfigWizardOpen(!cmsConfigWizardOpen);
    }

    function setCmsConfigWizardPage(page) {
      cmsConfigWizardPage = page === "douma" ? "douma" : "tuo";
      $("cmsConfigWizardForm").classList.toggle("is-douma", cmsConfigWizardPage === "douma");
      $("cmsWizardTuoPage").classList.toggle("is-active", cmsConfigWizardPage === "tuo");
      $("cmsWizardDoumaPage").classList.toggle("is-active", cmsConfigWizardPage === "douma");
      $("cmsWizardPageTitle").textContent = cmsConfigWizardPage === "douma" ? "豆妈页面设置" : "托页面设置";
      $("cmsWizardPageHint").textContent = cmsConfigWizardPage === "douma" ? "第 2 步，共 2 步" : "第 1 步，共 2 步";
      $("cmsWizardBackBtn").style.display = cmsConfigWizardPage === "douma" ? "" : "none";
      $("cmsWizardNextBtn").style.display = cmsConfigWizardPage === "tuo" ? "" : "none";
      $("cmsWizardSaveBtn").style.display = cmsConfigWizardPage === "douma" ? "" : "none";
      $("cmsConfigWizardError").textContent = "";
    }

    function updateCmsWizardTuoMode() {
      const mode = selectedCmsWizardTuoMode();
      $("cmsWizardTuoModeDisplay").value = mode === "precise" ? "跟随上方发单版本：精准托" : "跟随上方发单版本：粗略托";
      $("cmsWizardRoughFields").style.display = mode === "rough" ? "" : "none";
      $("cmsWizardPreciseFields").style.display = mode === "precise" ? "" : "none";
    }

    function cmsWizardRadioValue(name, fallback) {
      return document.querySelector('input[name="' + name + '"]:checked')?.value || fallback;
    }

    function updateCmsWizardDoumaLabels() {
      const groupMode = cmsWizardRadioValue("cmsDoumaGroupSearchMode", "group");
      const robotMode = cmsWizardRadioValue("cmsDoumaRobotSearchMode", "group");
      $("cmsDoumaGroupValueLabel").textContent = groupMode === "keyword" ? "群关键词" : "群分组名称";
      $("cmsDoumaGroupValue").placeholder = groupMode === "keyword" ? "填写关键词，默认选择第一个" : "填写分组名字";
      $("cmsDoumaGroupSelectDefault").textContent = groupMode === "keyword" ? "默认选择第一个" : "默认全选";
      $("cmsDoumaRobotValueLabel").textContent = robotMode === "keyword" ? "机器人关键词" : "机器人分组名称";
      $("cmsDoumaRobotValue").placeholder = robotMode === "keyword" ? "填写关键词，默认选择第一个" : "填写分组名字";
      $("cmsDoumaRobotSelectDefault").textContent = robotMode === "keyword" ? "默认选择第一个" : "默认 1";
    }

    const cmsWizardHistoryPrefix = "fd-auto-tool.cms-config-form-history.";

    function readCmsWizardHistory(key) {
      try {
        const raw = localStorage.getItem(cmsWizardHistoryPrefix + key);
        const values = JSON.parse(raw || "[]");
        return Array.isArray(values) ? values.filter(Boolean).map(String) : [];
      } catch {
        return [];
      }
    }

    function writeCmsWizardHistory(key, values) {
      try {
        localStorage.setItem(cmsWizardHistoryPrefix + key, JSON.stringify(values.slice(0, 12)));
      } catch {}
    }

    function renderCmsWizardHistoryList(input) {
      const listId = input.getAttribute("list");
      const key = input.dataset.cmsHistoryKey;
      const list = listId ? $(listId) : null;
      if (!list || !key) return;
      list.innerHTML = "";
      readCmsWizardHistory(key).forEach((value) => {
        const option = document.createElement("option");
        option.value = value;
        list.appendChild(option);
      });
    }

    function rememberCmsWizardInput(input) {
      const key = input.dataset.cmsHistoryKey;
      const value = String(input.value || "").trim();
      if (!key || !value) return;
      const values = readCmsWizardHistory(key).filter((item) => item !== value);
      values.unshift(value);
      writeCmsWizardHistory(key, values);
      renderCmsWizardHistoryList(input);
    }

    function rememberCmsWizardInputHistory() {
      document.querySelectorAll("[data-cms-history-key]").forEach((input) => rememberCmsWizardInput(input));
    }

    function initCmsWizardInputHistory() {
      document.querySelectorAll("[data-cms-history-key]").forEach((input) => {
        if (input.dataset.cmsHistoryReady === "1") return;
        input.dataset.cmsHistoryReady = "1";
        renderCmsWizardHistoryList(input);
        input.addEventListener("focus", () => renderCmsWizardHistoryList(input));
        input.addEventListener("blur", () => rememberCmsWizardInput(input));
        input.addEventListener("change", () => rememberCmsWizardInput(input));
      });
    }

    function selectedCmsWizardTuoMode() {
      return $("robotStrategy")?.value === "random" ? "rough" : "precise";
    }

    function readCmsConfigWizardForm() {
      const countValue = (id, fallback) => {
        const value = String($(id)?.value || "").trim();
        return value || fallback;
      };
      return {
        tuo: {
          mode: selectedCmsWizardTuoMode(),
          rough: {
            managementGroup: $("cmsRoughManagementGroup").value,
            robotSwitchMode: $("cmsRoughRobotSwitchMode").value,
            groupSelectCount: countValue("cmsRoughGroupSelectCount", "all"),
            taskRemark: $("cmsRoughTaskRemark").value
          },
          precise: {
            groupFilter: $("cmsPreciseGroupFilter").value,
            groupSelectCount: countValue("cmsPreciseGroupSelectCount", "all"),
            robotGroup: $("cmsPreciseRobotGroup").value,
            taskRemark: $("cmsPreciseTaskRemark").value
          }
        },
        douma: {
          groupSearchMode: cmsWizardRadioValue("cmsDoumaGroupSearchMode", "group"),
          groupValue: $("cmsDoumaGroupValue").value,
          groupSelectCount: cmsWizardRadioValue("cmsDoumaGroupSearchMode", "group") === "keyword" ? "1" : countValue("cmsDoumaGroupSelectCount", "all"),
          robotSearchMode: cmsWizardRadioValue("cmsDoumaRobotSearchMode", "group"),
          robotValue: $("cmsDoumaRobotValue").value,
          robotSelectCount: countValue("cmsDoumaRobotSelectCount", "1"),
          taskRemark: $("cmsDoumaTaskRemark").value
        }
      };
    }

    function validateCmsWizardTuoPage() {
      const form = readCmsConfigWizardForm();
      const errors = [];
      if (form.tuo.mode === "rough") {
        if (!String(form.tuo.rough.managementGroup || "").trim()) errors.push("请填写粗略托页面的管理分组。");
        if (!String(form.tuo.rough.taskRemark || "").trim()) errors.push("请填写粗略托页面的任务备注。");
      } else {
        if (!String(form.tuo.precise.groupFilter || "").trim()) errors.push("请填写精准托页面的群包含分组。");
        if (!String(form.tuo.precise.robotGroup || "").trim()) errors.push("请填写精准托页面的机器人分组。");
        if (!String(form.tuo.precise.taskRemark || "").trim()) errors.push("请填写精准托页面的任务备注。");
      }
      $("cmsConfigWizardError").textContent = errors[0] || "";
      return errors.length === 0;
    }

    function validateCmsWizardDoumaPage() {
      const form = readCmsConfigWizardForm();
      const errors = [];
      if (!String(form.douma.groupValue || "").trim()) errors.push("请填写豆妈页面的群输入内容。");
      if (!String(form.douma.robotValue || "").trim()) errors.push("请填写豆妈页面的机器人输入内容。");
      if (!String(form.douma.taskRemark || "").trim()) errors.push("请填写豆妈页面的任务备注。");
      $("cmsConfigWizardError").textContent = errors[0] || "";
      return errors.length === 0;
    }

    async function submitCmsConfigWizard() {
      if (!validateCmsWizardTuoPage() || !validateCmsWizardDoumaPage()) return;
      const name = await askConsoleText({
        title: "保存云中客配置",
        note: "给这份托页面和豆妈页面设置起一个名称，后续可以在“管理配置”里复用。",
        message: "请输入这份云中客配置名称。",
        defaultValue: defaultCmsConfigName(),
        confirmText: "保存配置",
        emptyMessage: "云中客配置名称不能为空。"
      });
      if (name === null) return;
      if (!String(name || "").trim()) {
        $("saveState").textContent = "云中客配置名称不能为空。";
        return;
      }
      rememberCmsWizardInputHistory();
      $("saveState").textContent = "正在保存云中客配置。";
      $("cmsWizardSaveBtn").disabled = true;
      try {
        const result = await postJson("/api/cms-config-library/save", {
          name,
          form: readCmsConfigWizardForm(),
          settings: readSettings(),
          runDir: latestStatus?.runDir || ""
        });
        if (!result.ok) throw new Error(result.error || "保存云中客配置失败。");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : cmsConfigLibraryItems;
        $("cmsConfigId").value = result.item?.id || "";
        activeCmsConfigId = $("cmsConfigId").value;
        setCmsConfigWizardOpen(false, { resetPage: false, silent: true });
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已保存云中客配置：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("cmsConfigWizardError").textContent = error?.message || String(error);
        $("saveState").textContent = "保存云中客配置失败：" + (error?.message || error);
      } finally {
        $("cmsWizardSaveBtn").disabled = false;
      }
    }

    async function saveCurrentCmsConfigToLibraryFromPageBinding() {
      const name = defaultCmsConfigName();
      if (!String(name || "").trim()) {
        $("saveState").textContent = "云中客配置名称不能为空。";
        return;
      }
      $("saveState").textContent = "正在保存云中客配置。";
      try {
        const result = await postJson("/api/cms-config-library/save", { name, settings: readSettings(), runDir: latestStatus?.runDir || "" });
        if (!result.ok) throw new Error(result.error || "保存云中客配置失败。");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : cmsConfigLibraryItems;
        $("cmsConfigId").value = result.item?.id || "";
        activeCmsConfigId = $("cmsConfigId").value;
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已保存云中客配置：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "保存云中客配置失败：" + (error?.message || error);
      }
    }

    async function useCmsConfigLibraryItem(id) {
      if (!id) return;
      $("saveState").textContent = "正在使用云中客配置。";
      try {
        const result = await postJson("/api/cms-config-library/use", { id });
        if (!result.ok) throw new Error(result.error || "使用云中客配置失败。");
        $("cmsConfigId").value = result.item?.id || id;
        activeCmsConfigId = $("cmsConfigId").value;
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已选择云中客配置：" + (result.item?.name || "未命名配置") + "。进入云中客设置后会按配置自动设置页面，并等待你检查确认。";
      } catch (error) {
        $("saveState").textContent = "使用云中客配置失败：" + (error?.message || error);
      }
    }

    async function renameCmsConfigLibraryItem(id) {
      const item = cmsConfigLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      const name = await askConsoleText({
        title: "修改云中客配置名称",
        note: "只修改配置库里的显示名称。",
        message: "请输入新的云中客配置名称。",
        defaultValue: item.name || "未命名云中客配置",
        confirmText: "保存名称",
        emptyMessage: "云中客配置名称不能为空。"
      });
      if (name === null) return;
      if (!String(name || "").trim()) {
        $("saveState").textContent = "云中客配置名称不能为空。";
        return;
      }
      $("saveState").textContent = "正在修改云中客配置名称。";
      try {
        const result = await postJson("/api/cms-config-library/rename", { id, name });
        if (!result.ok) throw new Error(result.error || "修改云中客配置名称失败。");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : cmsConfigLibraryItems;
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已修改云中客配置名称：" + (result.item?.name || name) + "。";
      } catch (error) {
        $("saveState").textContent = "修改云中客配置名称失败：" + (error?.message || error);
      }
    }

    async function deleteCmsConfigLibraryItem(id) {
      const item = cmsConfigLibraryItems.find((entry) => entry.id === id);
      if (!item) return;
      if (!confirm("确认删除云中客配置“" + (item.name || "未命名配置") + "”？这只删除配置库记录，不会删除 run。")) return;
      $("saveState").textContent = "正在删除云中客配置。";
      try {
        const result = await postJson("/api/cms-config-library/delete", { id });
        if (!result.ok) throw new Error(result.error || "删除云中客配置失败。");
        cmsConfigLibraryItems = Array.isArray(result.items) ? result.items : cmsConfigLibraryItems.filter((entry) => entry.id !== id);
        if ($("cmsConfigId").value === id) $("cmsConfigId").value = result.settings?.cmsConfigId || "";
        activeCmsConfigId = $("cmsConfigId").value;
        renderCmsConfigLibrary();
        renderCmsConfigManager();
        $("saveState").textContent = "已删除云中客配置：" + (result.deleted?.name || item.name || "未命名配置") + "。";
      } catch (error) {
        $("saveState").textContent = "删除云中客配置失败：" + (error?.message || error);
      }
    }

    function cmsConfigSummary(item = {}) {
      const count = item.summary?.roleCount || item.roleCount || 0;
      const roles = Array.isArray(item.summary?.roles) ? item.summary.roles : [];
      const roleText = roles.map((role) => {
        const label = role.label || role.role || "";
        const mode = role.modeLabel ? "（" + role.modeLabel + "）" : "";
        return label ? label + mode : "";
      }).filter(Boolean).join(" / ");
      return (count ? count + " 个页面" : "未记录页面") + (roleText ? " · " + roleText : "");
    }

    function cmsConfigRoleCards(item = {}) {
      const roleMap = new Map((Array.isArray(item.summary?.roles) ? item.summary.roles : []).map((role) => [role.role, role]));
      return ["tuo", "douma"].map((role) => {
        const data = roleMap.get(role) || {};
        const label = role === "tuo" ? "托页面" : "豆妈页面";
        const group = data.group || "未记录群";
        const robot = data.robot || "未记录机器人";
        const quick = role === "tuo" && typeof data.multiQuickMode === "boolean"
          ? " / 多快捷：" + (data.multiQuickMode ? "已开" : "未开")
          : "";
        const fields = Array.isArray(data.fields) ? data.fields : [];
        if (fields.length) {
          return "<div class='cms-config-role'><b>" + label + "</b><ul>" +
            fields.map((field) => "<li><strong>" + escapeText(field[0] || "") + "：</strong>" + escapeText(field[1] || "") + "</li>").join("") +
            "</ul></div>";
        }
        return "<div class='cms-config-role'><b>" + label + "</b><span>" + escapeText(group) + " / " + escapeText(robot) + escapeText(quick) + "</span></div>";
      });
    }

    function defaultCmsConfigName() {
      const now = new Date();
      const pad = (value) => String(value).padStart(2, "0");
      return "云中客配置 " + pad(now.getMonth() + 1) + "-" + pad(now.getDate()) + " " + pad(now.getHours()) + ":" + pad(now.getMinutes());
    }

    function rosterNameFromPath(filePath) {
      const fileName = String(filePath || "").split(/[\\\\/]/).filter(Boolean).pop() || "托人设";
      return fileName.replace(/\.(xlsx|csv|json)$/i, "").replace(/^\\d{8}-\\d{6}-/, "") || "托人设";
    }

    function fileNameFromPath(filePath) {
      return String(filePath || "").split(/[\\\\/]/).filter(Boolean).pop() || String(filePath || "");
    }

    function currentTuoRosterLibraryItem(filePath) {
      const target = filePath || activeTuoRosterPath || $("tuoRosterPath")?.value || "";
      return tuoRosterLibraryItems.find((item) => sameLocalPath(item.filePath, target)) || null;
    }

    function sameLocalPath(a, b) {
      return String(a || "").replace(/\\\\/g, "/").toLowerCase() === String(b || "").replace(/\\\\/g, "/").toLowerCase();
    }

    function formatLibraryTime(value) {
      if (!value) return "未记录时间";
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return value;
      const pad = (number) => String(number).padStart(2, "0");
      return pad(date.getMonth() + 1) + "/" + pad(date.getDate()) + " " + pad(date.getHours()) + ":" + pad(date.getMinutes());
    }

    function escapeText(value) {
      return String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    function escapeAttr(value) {
      return escapeText(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }


    function cancelPreviewRestore() {
      previewRestoreDismissed = true;
      $("previewRestorePanel").classList.remove("is-open");
      $("saveState").textContent = "已取消恢复上次预览。";
    }

    async function refreshStatusManually() {
      $("refreshBtn").disabled = true;
      $("saveState").textContent = "正在刷新运行状态...";
      try {
        const status = await refreshStatus({ manual: true });
        manualStatusFeedbackUntil = Date.now() + 5000;
        if (shouldClearStaleStatus(status)) {
          const cleared = await postJson("/api/status/clear-stale", {});
          if (cleared.ok && cleared.cleared) {
            await refreshStatus({ manual: true });
            await checkPreviewRestoreCandidate();
            $("saveState").textContent = "已清理旧状态，可继续操作；预览可从恢复入口打开。";
            return;
          }
        }
        $("saveState").textContent = "运行状态已刷新：" + currentClockText() + "，当前状态：" + labelStatus(status?.status);
      } catch (error) {
        manualStatusFeedbackUntil = Date.now() + 5000;
        $("saveState").textContent = "刷新运行状态失败：" + (error?.message || error);
      } finally {
        $("refreshBtn").disabled = false;
      }
    }

    function shouldClearStaleStatus(status) {
      if (!status) return false;
      if (status.status === "running" || status.control === "running") return false;
      if (status.status === "completed") return false;
      return ["failed", "stopped", "paused", "waiting"].includes(status.status)
        || ["awaiting_error_action", "paused", "stopped"].includes(status.control)
        || Boolean(status.failureReason);
    }

    async function refreshStatus(options = {}) {
      let result;
      try {
        const runId = currentRunId();
        result = await fetchJson(runId ? "/api/status?runId=" + encodeURIComponent(runId) : "/api/status");
      } catch (error) {
        markBackendDisconnected(error);
        if (options.manual) throw error;
        return null;
      }
      if (!result.ok) {
        if (options.manual) throw new Error(result.error || "状态接口返回失败。");
        return null;
      }
      if (backendDisconnected) {
        backendDisconnected = false;
        await checkControlledBrowser();
      }
      const s = result.state;
      latestStatus = s;
      syncActiveLibraryItemFromStatus(s);
      syncFeishuTitleFromStatus(s);
      $("step").textContent = s.step || "-";
      $("status").textContent = labelStatus(s.status);
      $("status").className = "v " + (s.status === "failed" ? "failed" : s.status === "waiting" ? "waiting" : s.status === "completed" ? "done" : "");
      $("current").textContent = s.currentIndex ? "第 " + s.currentIndex + " 条 / 共 " + (s.totalCount || "?") + " 条" : "-";
      $("counts").textContent = (s.successCount || 0) + " / " + (s.failureCount || 0);
      $("waiting").textContent = s.waitingReason || "-";
      $("missing").textContent = (s.missingFiles || []).join("、") || "-";
      $("runDir").textContent = s.runDir || "-";
      $("previewPath").textContent = s.previewPath || "-";
      $("failure").textContent = s.failureReason || "-";
      maybeShowCmsAutoSetupFailure(s);
      updateRobotRecoveryActions(s);
      const link = $("previewLink");
      if (s.previewUrl) {
        link.href = s.previewUrl;
        link.style.display = "";
      } else {
        link.style.display = "none";
      }
      $("logs").textContent = (s.logs || []).map((item) => "[" + item.time.replace("T", " ").slice(0, 19) + "] " + item.message).join("\\n");
      updateMainActionButtons(s);
      updateTaskErrorDecisionPanel(s);
      if (s.status !== "paused" || s.control !== "paused") $("continueDecisionPanel")?.classList.remove("is-open");
      if (!options.manual && Date.now() >= manualStatusFeedbackUntil) {
        if (s.status === "failed") $("saveState").textContent = "流程失败，请看失败原因和 run 目录。";
        else if (s.status === "waiting") $("saveState").textContent = s.waitingReason || "预览已生成，请打开预览页检查并保存预览内容。";
        else if (s.status === "completed") $("saveState").textContent = "本轮已创建完成，可以核对任务列表，或开始下一轮发单。";
      }
      setButtons(s.status);
      return s;
    }

    function maybeShowCmsAutoSetupFailure(state) {
      const reason = String(state?.failureReason || "");
      const shouldShow = state?.status === "waiting" && reason.includes("云中客配置自动设置失败");
      if (!shouldShow) {
        if (!reason.includes("云中客配置自动设置失败")) lastCmsAutoSetupFailureReason = "";
        $("saveState").classList.remove("is-error");
        return;
      }
      $("saveState").textContent = "自动设置失败，请人工设置后继续。";
      $("saveState").classList.add("is-error");
      if (reason === lastCmsAutoSetupFailureReason || consoleActionResolver) return;
      lastCmsAutoSetupFailureReason = reason;
      manualStatusFeedbackUntil = Date.now() + 15000;
      openConsoleAction({
        title: "云中客配置自动设置失败",
        note: "请在云中客页面人工补好失败项，补好后直接点击“我已设置好，开始创建任务”。",
        message: reason,
        cancelText: "关闭",
        confirmText: "知道了",
        danger: true
      });
    }

    function syncActiveLibraryItemFromStatus(status) {
      const nextId = String(status?.activeLibraryItemId || "");
      if (nextId === activeLibraryItemId) return;
      activeLibraryItemId = nextId;
      renderPreviewLibrary();
    }

    function currentRunId() {
      if (initialRunId) return initialRunId;
      const runDir = latestStatus?.runDir || "";
      const match = String(runDir).match(/(?:^|[\\\\/])(v2_(?:real_flow|library_work)_\\d{8}_\\d{6}[A-Za-z0-9_-]*)$/);
      return match ? match[1] : "";
    }

    function clearCurrentRunId() {
      initialRunId = "";
      const url = new URL(location.href);
      if (!url.searchParams.has("runId")) return;
      url.searchParams.delete("runId");
      history.replaceState(null, "", url.pathname + url.search + url.hash);
    }

    function updateMainActionButtons(s) {
      const completed = s.status === "completed";
      const cmsReady = s.step === "CMS 准备";
      const paused = s.status === "paused" || s.control === "paused";
      $("generateBtn").style.display = cmsReady ? "none" : "";
      $("startCmsBtn").style.display = cmsReady || completed ? "" : "none";
      $("startCmsBtn").textContent = completed
        ? "本轮已创建完成"
        : (paused ? "当前已暂停，请点继续" : "我已设置好，开始创建任务");
      $("nextRunBtn").style.display = completed ? "" : "none";
    }

    function updateRobotRecoveryActions(state) {
      const panel = $("robotRecoveryPanel");
      if (!panel) return;
      const show = Boolean(state && state.status === "failed" && isRobotNotInGroupRetryFailure(state.failureReason));
      panel.classList.toggle("is-open", show);
      $("robotDirectCreateBtn").disabled = !show || !controlledBrowserReady || !licenseAllowed;
      $("robotDirectCreateMode").disabled = !show || !controlledBrowserReady || !licenseAllowed;
      $("robotRetryMoreBtn").disabled = !show || !controlledBrowserReady || !licenseAllowed;
    }

    function updateTaskErrorDecisionPanel(state) {
      const panel = $("taskErrorDecisionPanel");
      if (!panel) return;
      const manual = state?.manualAction?.type === "task_error" && state.control === "awaiting_error_action";
      panel.classList.toggle("is-open", manual);
      if (manual) {
        const action = state.manualAction || {};
        const title = "第 " + (action.taskIndex || state.currentIndex || "?") + " / " + (action.totalCount || state.totalCount || "?") + " 条创建失败";
        const detail = [
          action.role ? "角色：" + (action.role === "douma" ? "豆妈" : "托") : "",
          action.speaker ? "说话人：" + action.speaker : "",
          action.taskType ? "类型：" + action.taskType : ""
        ].filter(Boolean).join("；");
        $("taskErrorDecisionText").textContent = title + (detail ? "；" + detail : "") + "。原因：" + (action.reason || state.failureReason || "-");
      }
      const disabled = !manual || !controlledBrowserReady || !licenseAllowed;
      $("retryCurrentTaskBtn").disabled = disabled;
      $("skipCurrentTaskBtn").disabled = disabled;
      $("stopCurrentRunBtn").disabled = !manual;
    }

    async function handleResumeClick() {
      if (latestStatus?.status === "paused" && latestStatus?.control === "paused") {
        await showContinueDecisionPanel();
        return;
      }
      await sendControl("resume");
    }

    async function showContinueDecisionPanel() {
      const panel = $("continueDecisionPanel");
      panel.classList.add("is-open");
      $("continueDecisionTitle").textContent = "正在判断从哪一条继续...";
      $("continueDecisionText").textContent = "正在读取本轮预览和创建日志。";
      $("continueFromCurrentBtn").disabled = true;
      $("continueFromNextBtn").disabled = true;
      await updateContinuePreviewButton();
      try {
        const result = await fetchJson("/api/continue-candidate");
        if (!result.ok || !result.current) throw new Error(result.error || "没有找到可继续的条目。");
        const current = result.current;
        const next = result.next || null;
        panel.dataset.currentIndex = String(current.index || "");
        panel.dataset.nextIndex = next?.index ? String(next.index) : "";
        $("continueDecisionTitle").textContent = "是否从第 " + current.index + " 条开始创建？";
        $("continueDecisionText").textContent = "当前条：" + formatContinueTask(current) + (next ? "。下一条：" + formatContinueTask(next) : "。后面没有下一条。");
        $("continueFromCurrentBtn").disabled = !current.index || !controlledBrowserReady || !licenseAllowed;
        $("continueFromNextBtn").disabled = !next?.index || !controlledBrowserReady || !licenseAllowed;
      } catch (error) {
        $("continueDecisionTitle").textContent = "无法判断续跑条目";
        $("continueDecisionText").textContent = (error?.message || error) + "；可以打开预览页面重新确认。";
        panel.dataset.currentIndex = "";
        panel.dataset.nextIndex = "";
      }
    }

    async function updateContinuePreviewButton() {
      const button = $("continueOpenPreviewBtn");
      button.disabled = true;
      button.textContent = "正在检查预览...";
      try {
        const result = await fetchJson("/api/preview/restore-candidate");
        const candidate = result.candidate || {};
        if (result.ok && candidate.available) {
          button.disabled = false;
          button.textContent = "打开预览页面";
          button.title = "打开已保存的上次预览；如果预览服务已关闭，会自动重新恢复。";
          return true;
        }
      } catch {}
      button.disabled = true;
      button.textContent = "暂无可恢复预览";
      button.title = "当前没有找到已保存的预览内容。";
      return false;
    }

    function formatContinueTask(task) {
      return [
        "第 " + (task.index || "?") + " 条",
        task.date || task.time ? "时间：" + [task.date, task.time].filter(Boolean).join(" ") : "",
        task.roleLabel || task.speaker ? "角色：" + [task.roleLabel, task.speaker].filter(Boolean).join(" / ") : "",
        task.type ? "类型：" + task.type : "",
        task.summary ? "内容：" + task.summary : ""
      ].filter(Boolean).join("；");
    }

    async function continueFromSelected(which) {
      const panel = $("continueDecisionPanel");
      const targetIndex = Number(which === "next" ? panel.dataset.nextIndex : panel.dataset.currentIndex);
      if (!targetIndex) {
        $("saveState").textContent = "没有可继续的条目，请打开预览页面重新确认。";
        return;
      }
      $("continueFromCurrentBtn").disabled = true;
      $("continueFromNextBtn").disabled = true;
      $("continueOpenPreviewBtn").disabled = true;
      try {
        await postJson("/api/control", { action: "resume_from_index", targetIndex });
        panel.classList.remove("is-open");
        $("saveState").textContent = "已选择从第 " + targetIndex + " 条开始继续创建。";
        await refreshStatus({ manual: true });
      } catch (error) {
        $("saveState").textContent = "继续创建失败：" + (error?.message || error);
        $("continueFromCurrentBtn").disabled = false;
        $("continueFromNextBtn").disabled = !panel.dataset.nextIndex;
        $("continueOpenPreviewBtn").disabled = false;
      }
    }

    async function openPreviewFromContinuePanel() {
      if ($("continueOpenPreviewBtn").disabled) {
        $("saveState").textContent = "暂无可恢复预览。";
        return;
      }
      $("continueFromCurrentBtn").disabled = true;
      $("continueFromNextBtn").disabled = true;
      $("continueOpenPreviewBtn").disabled = true;
      $("continueOpenPreviewBtn").textContent = "正在打开预览...";
      $("saveState").textContent = "正在打开已保存的预览页面。";
      try {
        await postJson("/api/control", { action: "stop" });
        await waitUntilWorkflowIdle();
        const result = await postJson("/api/preview/restore", { settings: readSettings() });
        if (!result.ok) throw new Error(result.error || "打开预览页面失败。");
        $("continueDecisionPanel").classList.remove("is-open");
        $("saveState").textContent = "已打开上次预览页面，请确认后再创建。";
        await refreshStatus({ manual: true });
      } catch (error) {
        $("saveState").textContent = "打开预览页面失败：" + (error?.message || error);
        await updateContinuePreviewButton();
      }
    }

    async function waitUntilWorkflowIdle(timeoutMs = 5000) {
      const deadline = Date.now() + timeoutMs;
      while (Date.now() < deadline) {
        const state = await refreshStatus({ manual: true });
        if (!state || (state.status !== "running" && state.status !== "paused")) return;
        await new Promise((resolve) => setTimeout(resolve, 250));
      }
    }

    function isRobotNotInGroupRetryFailure(reason) {
      const text = String(reason || "");
      return text.includes("机器人不在群") && (
        text.includes("已尝试更换机器人") ||
        text.includes("更换机器人后仍检测到机器人不在群")
      );
    }

    function markBackendDisconnected(error, options = {}) {
      backendDisconnected = true;
      controlledBrowserReady = false;
      const reason = error?.message || String(error || "无法连接后台服务");
      const saveMessage = options.saveMessage || "控制台后台服务已断开，请重新双击 2.0 可视化控制台正式入口。当前操作不会继续生成预览。";
      latestStatus = {
        ...(latestStatus || {}),
        step: "后台断开",
        status: "disconnected",
        waitingReason: "后台服务已断开，请重新打开正式入口。",
        failureReason: reason
      };
      $("step").textContent = "后台断开";
      $("status").textContent = "后台断开";
      $("status").className = "v failed";
      $("waiting").textContent = "后台服务已断开，请重新打开正式入口。";
      $("failure").textContent = reason;
      $("saveState").textContent = saveMessage;
      $("previewLink").style.display = "none";
      updateRobotRecoveryActions(null);
      updateTaskErrorDecisionPanel(null);
      $("continueDecisionPanel")?.classList.remove("is-open");
      setButtons("ready");
    }

    function syncFeishuTitleFromStatus(state) {
      const title = String(state?.feishuTitle || "").trim();
      if (!title || isPlaceholderFeishuTitle(title)) return;
      const statusUrl = normalizeFeishuUrlInput(state?.feishuUrl || "");
      const currentUrl = normalizeFeishuUrlInput($("feishuUrl").value);
      if (statusUrl && currentUrl && !sameFeishuDocument(statusUrl, currentUrl)) return;
      const currentTitle = $("feishuTitle").value.trim();
      if (currentTitle === title) return;
      if (currentTitle && !isPlaceholderFeishuTitle(currentTitle)) return;
      $("feishuTitle").value = title;
      titleReadForFeishuUrl = statusUrl || currentUrl || titleReadForFeishuUrl;
      $("feishuTitleUrl").value = titleReadForFeishuUrl;
      $("feishuTitleBadge").textContent = "已读取";
      $("feishuTitleBadge").className = "field-badge good";
    }

    function isPlaceholderFeishuTitle(value) {
      return ["待读取", "未读取到标题"].includes(String(value || "").trim());
    }

    function sameFeishuDocument(left, right) {
      const leftKey = feishuDocumentKey(left);
      const rightKey = feishuDocumentKey(right);
      return Boolean(leftKey && rightKey && leftKey === rightKey);
    }

    function feishuDocumentKey(value) {
      const url = normalizeFeishuUrlInput(value);
      if (!url) return "";
      const match = url.match(/^https:\\/\\/([^/]*feishu\\.cn)\\/(docx|docs|wiki|sheets)\\/([^?#]+)/i);
      return match ? (match[1].toLowerCase() + "/" + match[2].toLowerCase() + "/" + match[3]) : "";
    }

    async function refreshLicenseDiagnostics(options = {}) {
      if (licenseCheckInFlight) return;
      licenseCheckInFlight = true;
      if (licenseAutoRefreshTimer) {
        clearTimeout(licenseAutoRefreshTimer);
        licenseAutoRefreshTimer = null;
      }
      $("licenseRefreshBtn").disabled = true;
      if (!options.auto) $("licenseRequestState").textContent = "正在检查授权和公司网络...";
      try {
        const result = await fetchJson("/api/license/diagnostics");
        if (!result.ok) throw new Error(result.error || "授权检查失败。");
        latestLicenseDiagnostics = result.diagnostics || null;
        renderLicenseDiagnostics(latestLicenseDiagnostics);
      } catch (error) {
        licenseAllowed = false;
        $("licensePanel").className = "license-panel is-open";
        $("licenseMainText").textContent = "授权检查失败";
        $("licenseDns").textContent = "-";
        $("licenseService").textContent = error?.message || String(error);
        $("licenseDevice").textContent = "-";
        $("licenseAdvice").textContent = "请确认已连接公司网络后重新检查。";
        $("licenseRequestBtn").disabled = true;
        $("licenseCopyDeviceBtn").disabled = true;
      } finally {
        licenseCheckInFlight = false;
        $("licenseRefreshBtn").disabled = false;
        setButtons(latestStatus?.status || "ready");
        scheduleLicenseAutoRefresh();
      }
    }

    function scheduleLicenseAutoRefresh() {
      if (licenseAllowed || licenseAutoRefreshTimer) return;
      licenseAutoRefreshTimer = setTimeout(() => {
        licenseAutoRefreshTimer = null;
        refreshLicenseDiagnostics({ auto: true }).catch(() => {});
      }, 5000);
    }

    function renderLicenseDiagnostics(diagnostics) {
      const license = diagnostics?.license || {};
      licenseAllowed = license.allowed === true;
      $("licensePanel").className = licenseAllowed ? "license-panel is-open authorized" : "license-panel is-open";
      $("licenseMainText").textContent = licenseAllowed ? "授权通过" : (license.message || "当前设备未授权");
      $("licenseDns").textContent = diagnostics?.dns?.message || "-";
      $("licenseService").textContent = diagnostics?.service?.message || "-";
      $("licenseDevice").textContent = diagnostics?.deviceId || "-";
      const canRequest = Boolean(diagnostics?.deviceId && diagnostics?.dns?.ok && diagnostics?.service?.ok && !licenseAllowed);
      $("licenseRequestBtn").disabled = !canRequest;
      $("licenseCopyDeviceBtn").disabled = !diagnostics?.deviceId;
      $("licenseAdvice").textContent = licenseAllowed
        ? "可以正常使用。"
        : canRequest
          ? "点击申请授权，管理员在总控页面通过后，再点重新检查。"
          : "请先处理 DNS、公司网络或设备号读取问题。";
      $("licenseRequestState").textContent = licenseAllowed ? "这台电脑已在授权名单中。" : "未授权时可以提交申请，由管理员在总控页面审批。";
    }

    async function requestLicenseAccess() {
      $("licenseRequestBtn").disabled = true;
      $("licenseRequestState").textContent = "正在提交授权申请...";
      try {
        const result = await postJson("/api/license/request", {});
        if (!result.ok || !result.request?.ok) throw new Error(result.request?.message || result.error || "申请提交失败。");
        $("licenseRequestState").textContent = result.request.message || "申请已提交，请等待管理员审批。";
        if (result.request.deviceId) {
          latestLicenseDiagnostics = { ...(latestLicenseDiagnostics || {}), deviceId: result.request.deviceId };
          $("licenseDevice").textContent = result.request.deviceId;
        }
      } catch (error) {
        $("licenseRequestState").textContent = "申请失败：" + (error?.message || error);
      } finally {
        await refreshLicenseDiagnostics();
      }
    }

    async function copyLicenseDeviceId() {
      const deviceId = latestLicenseDiagnostics?.deviceId || $("licenseDevice").textContent;
      if (!deviceId || deviceId === "-") return;
      try {
        await navigator.clipboard.writeText(deviceId);
        $("licenseRequestState").textContent = "设备号已复制。";
      } catch {
        $("licenseRequestState").textContent = "复制失败，可以手动选中设备号复制。";
      }
    }

    async function refreshVersionStatus(options = {}) {
      $("versionState").textContent = options.startup ? "正在自动检查更新..." : "正在检查更新...";
      $("versionRefreshBtn").disabled = true;
      try {
        const [versionResult, licenseResult] = await Promise.all([
          fetchJson("/api/version/status"),
          fetchJson("/api/license/status")
        ]);
        if (!versionResult.ok) {
          throw new Error(versionResult.error || "检查失败，可稍后重试。");
        }
        const v = versionResult.version || {};
        const license = licenseResult.license || {};
        renderVersionStatus(v, license, options);
      } catch (error) {
        $("versionMainState").textContent = "检查失败，可稍后重试";
        $("versionMainState").className = "version-main-state failed";
        $("versionUpdateHint").textContent = "没有完成更新检查，不会影响当前使用。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
        $("versionState").textContent = "检查失败，可稍后重试：" + (error?.message || error);
      } finally {
        $("versionRefreshBtn").disabled = false;
      }
    }

    function renderVersionStatus(v, license, options = {}) {
      latestVersionInfo = v || {};
      licenseAllowed = license.allowed === true;
      const current = v.currentDisplayVersion || v.currentVersion || "-";
      const latest = v.latestRemoteDisplayVersion || v.latestRemoteVersion || "";
      const updateCheckError = v.updateCheckError || "";
      $("versionNumber").textContent = current;
      if (v.pendingUpdateReady) {
        $("versionMainState").textContent = "新版本已准备好：" + latest;
        $("versionMainState").className = "version-main-state has-update";
        $("versionUpdateHint").textContent = "新版本已下载好。本次可以继续使用当前版本，下次双击启动会自动更新。";
        $("versionUpdateBtn").dataset.updateAvailable = "1";
        $("versionUpdateBtn").disabled = false;
        if (!versionNoticeDismissed) {
          $("versionNoticeText").textContent = "新版本 " + latest + " 已下载好，下次启动会自动更新。";
          $("versionNotice").classList.add("is-open");
        }
      } else if (v.updateAvailable) {
        $("versionMainState").textContent = "发现新版本：" + latest;
        $("versionMainState").className = "version-main-state has-update";
        $("versionUpdateHint").textContent = options.startup && v.updateMode === "patch"
          ? "正在后台下载新版本，不影响当前操作；下载好后会提示下次启动自动更新。"
          : "发现新版本 " + latest + "，可以立即更新，也可以等待后台准备后下次启动自动更新。";
        $("versionUpdateBtn").dataset.updateAvailable = "1";
        $("versionUpdateBtn").disabled = false;
        if (!options.startup && !versionNoticeDismissed) {
          $("versionNoticeText").textContent = "发现新版本 " + latest + "，可前往版本更新。";
          $("versionNotice").classList.add("is-open");
        }
        maybePrepareUpdateInBackground(v, options);
      } else if (updateCheckError) {
        $("versionMainState").textContent = "更新检查未完成";
        $("versionMainState").className = "version-main-state failed";
        $("versionUpdateHint").textContent = "检查更新超时或失败，不影响当前使用。可稍后手动重试。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
      } else {
        $("versionMainState").textContent = "已是最新版本";
        $("versionMainState").className = "version-main-state";
        $("versionUpdateHint").textContent = "当前已是最新版本。";
        $("versionUpdateBtn").dataset.updateAvailable = "0";
        $("versionUpdateBtn").disabled = true;
        $("versionNotice").classList.remove("is-open");
      }
      $("versionCommit").textContent = v.currentCommit || "-";
      $("versionProjectDir").textContent = v.projectDir || "-";
      const sourceCount = Array.isArray(v.updateSourceUrls) ? v.updateSourceUrls.length : 0;
      $("versionRemote").textContent = v.hasUpdateSource
        ? ("补丁源：" + (v.updateSourceUrl || "已配置") + (sourceCount > 1 ? "（含备用源）" : ""))
        : (v.hasGitRemote ? (v.remoteUrl || "已连接") : "未连接");
      $("versionLocalChanges").textContent = v.hasLocalChanges ? "有本地修改" : "干净";
      $("versionLatestBackup").textContent = v.latestBackup ? v.latestBackup.path : "-";
      $("versionStableTag").textContent = v.latestStableTag || "-";
      $("licenseStatus").textContent = license.message || "-";
      $("versionState").textContent = updateCheckError
        ? "检查更新未完成：" + updateCheckError
        : (v.updateFallbackUsed ? "检查更新完成，已自动切换备用更新源。" : (options.startup ? "已自动检查更新。" : "检查更新完成。"));
      setButtons(latestStatus?.status || "ready");
    }

    function maybePrepareUpdateInBackground(v, options = {}) {
      if (!options.startup && !options.autoPreparePoll) return;
      if (v.updateMode !== "patch" || !v.updateAvailable || v.pendingUpdateReady || versionAutoPrepareStarted) return;
      versionAutoPrepareStarted = true;
      $("versionState").textContent = "发现新版本，正在后台下载；不影响当前操作。";
      postJson("/api/version/prepare-update", {}).catch((error) => {
        $("versionState").textContent = "后台自动下载更新失败，可手动检查更新：" + (error?.message || error);
      });
      scheduleVersionPreparePoll(1);
    }

    function scheduleVersionPreparePoll(attempt) {
      if (versionPreparePollTimer) clearTimeout(versionPreparePollTimer);
      if (attempt > 90) return;
      versionPreparePollTimer = setTimeout(async () => {
        await refreshVersionStatus({ autoPreparePoll: true }).catch(() => {});
        if (latestVersionInfo?.pendingUpdateReady || !latestVersionInfo?.updateAvailable) return;
        scheduleVersionPreparePoll(attempt + 1);
      }, 4000);
    }

    async function runVersionAction(action) {
      const prompts = {
        backup: "确认创建当前稳定备份？",
        update: "更新前会自动备份当前版本，是否继续？",
        rollback: "回退前会自动备份当前版本，是否继续？",
        "open-backup-dir": ""
      };
      const endpoints = {
        backup: "/api/version/backup",
        update: "/api/version/update",
        rollback: "/api/version/rollback",
        "open-backup-dir": "/api/version/open-backup-dir"
      };
      if (prompts[action] && !confirm(prompts[action])) return;
      setVersionButtons(true);
      $("versionState").textContent = action === "open-backup-dir" ? "正在打开备份目录。" : "正在执行版本操作，请等待。";
      try {
        const result = await postJson(endpoints[action], {});
        if (!result.ok) throw new Error(result.error || "版本操作失败。");
        $("versionState").textContent = result.message || result.result?.backupPath || "版本操作完成。";
        await refreshVersionStatus();
      } catch (error) {
        $("versionState").textContent = "版本操作失败：" + (error?.message || error);
      } finally {
        setVersionButtons(false);
      }
    }

    function setVersionButtons(disabled) {
      for (const id of ["versionRefreshBtn","versionBackupBtn","versionUpdateBtn","versionRollbackBtn","versionOpenBackupBtn"]) {
        if (id === "versionUpdateBtn" && !disabled) {
          $(id).disabled = $(id).dataset.updateAvailable !== "1";
        } else {
          $(id).disabled = disabled;
        }
      }
    }

    function currentClockText() {
      return new Date().toLocaleTimeString("zh-CN", { hour12: false });
    }

    function labelStatus(status) {
      if (status === "running") return "运行中";
      if (status === "paused") return "已暂停";
      if (status === "stopped") return "已停止";
      if (status === "waiting") return "等待人工确认";
      if (status === "completed") return "完成";
      if (status === "failed") return "失败";
      if (status === "disconnected") return "后台断开";
      return "就绪";
    }

    function setButtons(status) {
      const awaitingErrorAction = latestStatus?.control === "awaiting_error_action";
      const busy = status === "running" || status === "paused";
      const paused = status === "paused" || latestStatus?.control === "paused";
      $("generateBtn").disabled = busy || !controlledBrowserReady || !licenseAllowed;
      const completed = latestStatus && latestStatus.status === "completed";
      $("startCmsBtn").disabled = completed || (busy && !paused) || !controlledBrowserReady || !licenseAllowed;
      $("nextRunBtn").disabled = busy || !controlledBrowserReady;
      $("discardBtn").disabled = !controlledBrowserReady;
      $("exitBtn").disabled = !controlledBrowserReady;
      if ($("robotRecoveryPanel")?.classList.contains("is-open")) {
        $("robotDirectCreateBtn").disabled = busy || !controlledBrowserReady || !licenseAllowed;
        $("robotDirectCreateMode").disabled = busy || !controlledBrowserReady || !licenseAllowed;
        $("robotRetryMoreBtn").disabled = busy || !controlledBrowserReady || !licenseAllowed;
      }
      $("pauseBtn").disabled = status !== "running";
      $("resumeBtn").disabled = status !== "paused" || awaitingErrorAction;
      $("stopBtn").disabled = !busy;
      if ($("taskErrorDecisionPanel")?.classList.contains("is-open")) {
        $("retryCurrentTaskBtn").disabled = !awaitingErrorAction || !controlledBrowserReady || !licenseAllowed;
        $("skipCurrentTaskBtn").disabled = !awaitingErrorAction || !controlledBrowserReady || !licenseAllowed;
        $("stopCurrentRunBtn").disabled = !awaitingErrorAction;
      }
      if ($("continueDecisionPanel")?.classList.contains("is-open")) {
        $("continueFromCurrentBtn").disabled = status !== "paused" || !controlledBrowserReady || !licenseAllowed || !$("continueDecisionPanel").dataset.currentIndex;
        $("continueFromNextBtn").disabled = status !== "paused" || !controlledBrowserReady || !licenseAllowed || !$("continueDecisionPanel").dataset.nextIndex;
      }
    }

    function bindCardGroup(name, selectId) {
      for (const radio of document.querySelectorAll("input[name='" + name + "']")) {
        radio.addEventListener("change", () => {
          if (radio.checked) $(selectId).value = radio.value;
          if (selectId === "rangeMode") isolateRangeModeFields(radio.value);
          if (selectId === "rangeMode") updateRangeVisibility();
          if (selectId === "headingSelectionMode") isolateHeadingSelectionModeFields(radio.value);
          if (selectId === "headingSelectionMode") updateHeadingSelectionVisibility();
          if (selectId === "robotStrategy") syncRobotStrategyGroup();
          if (selectId === "robotNotInGroupPolicy") updateRobotNotInGroupVisibility();
          if (selectId === "scheduleMode") updateScheduleModeVisibility();
        });
      }
    }

    function syncCardGroups() {
      syncRobotStrategyGroup();
      syncCardGroup("robotNotInGroupPolicyChoice", "robotNotInGroupPolicy");
      syncCardGroup("rangeModeChoice", "rangeMode");
      syncCardGroup("headingSelectionModeChoice", "headingSelectionMode");
      syncCardGroup("scheduleModeChoice", "scheduleMode");
      updateRangeVisibility();
      updateHeadingSelectionVisibility();
      updateRobotNotInGroupVisibility();
      updateScheduleModeVisibility();
    }

    function syncCardGroup(name, selectId) {
      const value = $(selectId)?.value || "";
      const radio = document.querySelector("input[name='" + name + "'][value='" + value + "']");
      if (radio) radio.checked = true;
    }

    function updateRangeVisibility() {
      const mode = $("rangeMode").value;
      const full = mode === "full";
      const heading = mode === "heading";
      $("rangeInputs").style.display = mode === "range" ? "grid" : "none";
      $("headingRangeInputs").style.display = heading ? "grid" : "none";
      const libraryNote = "直接使用文案库保存的预览时，一般不用改这里。";
      $("rangeHint").textContent = full
        ? "本次读取：全文。不会显示开始位置/结束位置，也不会使用节奏标题。" + libraryNote
        : heading
          ? "本次读取：按节奏/天数选择。识别标题结构时只读取左侧目录；生成预览时才读取正文和素材。" + libraryNote
          : "本次选择指定范围：按当前填写的开始位置和结束位置读取；结束位置为空表示读到文档末尾。" + libraryNote;
      if (heading) updateHeadingSelectionVisibility();
    }

    function isolateRangeModeFields(mode) {
      if (mode === "full") {
        $("startKeyword").value = "";
        $("endKeyword").value = "";
        headingStructure = null;
        resetHeadingStructureOptions("请先读取标题结构");
      } else if (mode === "range") {
        headingStructure = null;
        resetHeadingStructureOptions("请先读取标题结构");
      } else if (mode === "heading") {
        $("startKeyword").value = "";
        $("endKeyword").value = "";
      }
    }

    function isolateHeadingSelectionModeFields(mode) {
      if (mode === "range") {
        $("headingRhythm").value = "";
      } else {
        $("headingStartDay").value = "";
        $("headingEndDay").value = "";
      }
      updateHeadingRangeHint();
    }

    function updateHeadingSelectionVisibility() {
      const range = $("headingSelectionMode").value === "range";
      for (const el of document.querySelectorAll(".heading-single-field")) {
        el.style.display = range ? "none" : "";
      }
      for (const el of document.querySelectorAll(".heading-range-field")) {
        el.style.display = range ? "" : "none";
      }
      syncCardGroup("headingSelectionModeChoice", "headingSelectionMode");
      updateHeadingRangeHint();
    }

    function updateRobotNotInGroupVisibility() {
      const switchRobot = $("robotNotInGroupPolicy").value === "switch_robot";
      $("robotNotInGroupRetryConfig").style.display = switchRobot ? "grid" : "none";
      $("robotNotInGroupHint").style.display = switchRobot ? "block" : "none";
      $("robotNotInGroupHint").textContent = "连续 " + ($("robotNotInGroupMaxRetries").value || "5") + " 次仍不在群，就停止当前批次并提示人工处理。";
    }

    function updateRobotStrategyVisibility() {
      const strategy = $("robotStrategy").value;
      const preciseTopSelected = strategy === "fixed" || strategy === "precise";
      $("preciseTuoConfig").style.display = preciseTopSelected ? "block" : "none";
      $("preciseTuoRosterConfig").style.display = strategy === "precise" ? "block" : "none";
      $("preciseTuoRosterEnabled").checked = strategy === "precise";
      updateTuoRosterUploadDisplay();
      updateCmsWizardTuoMode();
    }

    function syncRobotStrategyGroup() {
      const strategy = $("robotStrategy").value;
      const topValue = strategy === "random" ? "random" : "fixed";
      const radio = document.querySelector("input[name='robotStrategyChoice'][value='" + topValue + "']");
      if (radio) radio.checked = true;
      updateRobotStrategyVisibility();
    }

    function updateScheduleModeVisibility() {
      const mode = $("scheduleMode").value;
      const isDoc = mode === "doc";
      const isRealtime = mode === "realtime";
      const isCatchup = mode === "catchup";
      const libraryNote = "直接使用文案库保存的预览时，不会按这里重新排时间；需要改时间请在预览页里调整，或重新读取飞书生成预览。";
      $("timeFields").style.display = "grid";
      $("customIntervals").style.display = isDoc ? "none" : "block";
      $("intervalDefaultHint").style.display = isDoc ? "none" : "block";
      $("realtimeStartField").style.display = isRealtime ? "grid" : "none";
      $("realtimeEndField").style.display = isRealtime ? "grid" : "none";
      $("catchupStartField").style.display = isCatchup ? "grid" : "none";
      $("dateField").style.display = "grid";
      if (isDoc) {
        $("timeModeHint").textContent = "文档时间：只取文档里的时分秒；日期使用第一天发单日期，遇到第一天/第二天或换天标题会自动顺延。预览顺序可以按互动逻辑调整，但每条时间不能改。" + libraryNote;
      } else if (isRealtime) {
        $("timeModeHint").textContent = "实时跟发：按开始时间重新生成发送时间；结束时间可留空。设置结束时间后，生成时间不能超过结束时间，超过会停止生成预览。" + libraryNote;
      } else {
        $("timeModeHint").textContent = "补发到文档时间：过期内容从开始时间补发，后面能接回文档原时间时就回到文档时间，不会把后面所有时间重新顺一遍。" + libraryNote;
      }
    }

    const visibleIntervalFields = ["differentTuoMin","differentTuoMax","sameTuoMin","sameTuoMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"];
    const intervalPresetGroups = [
      ["不同托", "differentTuoMin", "differentTuoMax"],
      ["同托", "sameTuoMin", "sameTuoMax"],
      ["豆妈连续", "doumaSameMin", "doumaSameMax"],
      ["豆妈托切换", "roleSwitchMin", "roleSwitchMax"]
    ];

    async function loadIntervalPresets(selectedId = "") {
      const result = await fetchJson("/api/interval-presets");
      intervalPresets = Array.isArray(result.presets) ? result.presets : [];
      renderIntervalPresetOptions(selectedId);
    }

    function renderIntervalPresetOptions(selectedId = "") {
      const select = $("intervalPresetSelect");
      if (!select) return;
      select.innerHTML = "";
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = intervalPresets.length ? "选择已保存方案" : "暂无已保存方案";
      select.appendChild(placeholder);
      for (const preset of intervalPresets) {
        const option = document.createElement("option");
        option.value = preset.id;
        option.textContent = preset.name || "未命名方案";
        select.appendChild(option);
      }
      select.value = selectedId && intervalPresets.some((item) => item.id === selectedId) ? selectedId : "";
      renderIntervalPresetList();
    }

    function renderIntervalPresetList() {
      const list = $("intervalPresetList");
      if (!list) return;
      list.innerHTML = "";
      if (!intervalPresets.length) {
        const empty = document.createElement("div");
        empty.className = "interval-preset-empty";
        empty.textContent = "暂无已保存方案。先填写上面的间隔，再点“保存当前为方案”。";
        list.appendChild(empty);
        return;
      }
      for (const preset of intervalPresets) {
        const row = document.createElement("div");
        row.className = "interval-preset-row";

        const nameInput = document.createElement("input");
        nameInput.value = preset.name || "";
        nameInput.placeholder = "方案名称";
        nameInput.dataset.presetId = preset.id;

        const summary = document.createElement("div");
        summary.className = "interval-preset-summary";
        summary.textContent = intervalPresetSummary(preset.intervals || {});

        const actions = document.createElement("div");
        actions.className = "interval-preset-actions";

        const renameBtn = document.createElement("button");
        renameBtn.type = "button";
        renameBtn.textContent = "保存名称";
        renameBtn.addEventListener("click", () => renameIntervalPreset(preset.id, nameInput.value));

        const updateBtn = document.createElement("button");
        updateBtn.type = "button";
        updateBtn.textContent = "更新为当前填写";
        updateBtn.addEventListener("click", () => updateIntervalPresetFromCurrent(preset.id, nameInput.value));

        const deleteBtn = document.createElement("button");
        deleteBtn.type = "button";
        deleteBtn.className = "outline-danger";
        deleteBtn.textContent = "删除";
        deleteBtn.addEventListener("click", () => deleteIntervalPresetById(preset.id));

        actions.append(renameBtn, updateBtn, deleteBtn);
        row.append(nameInput, summary, actions);
        list.appendChild(row);
      }
    }

    function intervalPresetSummary(intervals) {
      return intervalPresetGroups
        .map(([label, minKey, maxKey]) => {
          const min = intervals[minKey];
          const max = intervals[maxKey];
          return String(min ?? "").trim() && String(max ?? "").trim() ? label + " " + min + "-" + max + "秒" : "";
        })
        .filter(Boolean)
        .join("；") || "未填写间隔";
    }

    function toggleIntervalPresetPanel() {
      const panel = $("intervalPresetPanel");
      panel.classList.toggle("is-open");
      if (panel.classList.contains("is-open")) renderIntervalPresetList();
    }

    function readVisibleIntervalValues() {
      const values = {};
      for (const key of visibleIntervalFields) values[key] = $(key)?.value || "";
      values.mediaMin = "";
      values.mediaMax = "";
      return values;
    }

    function hasVisibleIntervalValues(values) {
      return visibleIntervalFields.some((key) => String(values[key] || "").trim() !== "");
    }

    function defaultIntervalPresetName(values) {
      const filled = intervalPresetGroups
        .map(([label, minKey, maxKey]) => ({ label, min: values[minKey], max: values[maxKey] }))
        .filter((item) => String(item.min || "").trim() && String(item.max || "").trim());
      if (filled.length === 1) return filled[0].label + " " + filled[0].min + "-" + filled[0].max + "秒";
      if (filled.length > 1 && filled.every((item) => item.min === filled[0].min && item.max === filled[0].max)) {
        return "统一间隔 " + filled[0].min + "-" + filled[0].max + "秒";
      }
      const now = new Date();
      const pad = (value) => String(value).padStart(2, "0");
      return "间隔方案 " + pad(now.getMonth() + 1) + "-" + pad(now.getDate()) + " " + pad(now.getHours()) + ":" + pad(now.getMinutes());
    }

    async function uploadTuoRosterFile(file) {
      const allowed = /\\.(xlsx|csv|json)$/i.test(file.name || "");
      if (!allowed) {
        setTuoRosterUploadStatus("只支持 XLSX、CSV、JSON 名单文件。", true);
        return;
      }
      setTuoRosterUploadStatus("正在上传：" + file.name + "。", false);
      try {
        const result = await postJson("/api/tuo-roster/upload", {
          fileName: file.name,
          contentBase64: await fileToBase64(file)
        });
        if (!result.ok) throw new Error(result.error || "上传失败。");
        $("tuoRosterPath").value = result.filePath || "";
        activeTuoRosterPath = $("tuoRosterPath").value;
        setTuoRosterUploadStatus("已上传：" + (result.fileName || file.name) + "。", false);
        $("saveState").textContent = "已上传托名单：" + (result.fileName || file.name) + "。";
        renderTuoRosterManager();
        await postJson("/api/settings", { settings: readSettings() }).catch(() => null);
      } catch (error) {
        setTuoRosterUploadStatus("上传托名单失败：" + (error?.message || error), true);
      } finally {
        $("tuoRosterFileInput").value = "";
      }
    }

    function fileToBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const bytes = new Uint8Array(reader.result || new ArrayBuffer(0));
          let binary = "";
          const chunkSize = 0x8000;
          for (let index = 0; index < bytes.length; index += chunkSize) {
            binary += String.fromCharCode(...bytes.slice(index, index + chunkSize));
          }
          resolve(btoa(binary));
        };
        reader.onerror = () => reject(reader.error || new Error("读取文件失败。"));
        reader.readAsArrayBuffer(file);
      });
    }

    function updateTuoRosterUploadDisplay() {
      const filePath = $("tuoRosterPath")?.value || "";
      if (!filePath) {
        activeTuoRosterPath = "";
        setTuoRosterUploadStatus("尚未上传名单。", false);
        return;
      }
      activeTuoRosterPath = filePath;
      const fileName = fileNameFromPath(filePath);
      const libraryItem = currentTuoRosterLibraryItem(filePath);
      if (libraryItem?.name) {
        setTuoRosterUploadStatus("已选择：" + libraryItem.name + "\\n文件：" + fileName, false);
      } else {
        setTuoRosterUploadStatus("已选择：" + fileName + "。", false);
      }
      renderTuoRosterManager();
    }

    function setTuoRosterUploadStatus(message, error) {
      $("tuoRosterUploadStatus").textContent = message;
      $("tuoRosterUploadStatus").classList.toggle("roster-upload-error", Boolean(error));
    }

    function applySelectedIntervalPreset() {
      const id = $("intervalPresetSelect").value;
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "请先选择一个已保存的间隔方案。";
        return;
      }
      const intervals = preset.intervals || {};
      for (const key of visibleIntervalFields) {
        if ($(key)) $(key).value = intervals[key] === undefined ? "" : String(intervals[key] || "");
      }
      if ($("mediaMin")) $("mediaMin").value = "";
      if ($("mediaMax")) $("mediaMax").value = "";
      $("saveState").textContent = "已应用间隔方案：" + (preset.name || "未命名方案") + "。";
    }

    async function saveCurrentIntervalPreset() {
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      const intervals = readVisibleIntervalValues();
      if (!hasVisibleIntervalValues(intervals)) {
        $("saveState").textContent = "请先填写至少一组自定义间隔，再保存为方案。";
        return;
      }
      const defaultName = defaultIntervalPresetName(intervals);
      const name = prompt("方案名称", defaultName);
      if (name === null) return;
      try {
        const result = await postJson("/api/interval-presets/save", { preset: { name, intervals } });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(result.preset?.id || "");
        $("saveState").textContent = "已保存间隔方案：" + (result.preset?.name || name || defaultName) + "。";
      } catch (error) {
        $("saveState").textContent = "保存间隔方案失败：" + (error?.message || error);
      }
    }

    async function renameIntervalPreset(id, name) {
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "没有找到这个间隔方案。";
        return;
      }
      try {
        const result = await postJson("/api/interval-presets/save", {
          preset: { id, name, intervals: preset.intervals || {} }
        });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(id);
        $("saveState").textContent = "已保存方案名称。";
      } catch (error) {
        $("saveState").textContent = "保存方案名称失败：" + (error?.message || error);
      }
    }

    async function updateIntervalPresetFromCurrent(id, name) {
      const error = validateIntervalInputs();
      if (error) {
        $("saveState").textContent = error;
        return;
      }
      const intervals = readVisibleIntervalValues();
      if (!hasVisibleIntervalValues(intervals)) {
        $("saveState").textContent = "请先填写至少一组自定义间隔，再更新方案。";
        return;
      }
      try {
        const result = await postJson("/api/interval-presets/save", {
          preset: { id, name, intervals }
        });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions(id);
        $("saveState").textContent = "已用当前填写更新方案：" + (result.preset?.name || name || "未命名方案") + "。";
      } catch (error) {
        $("saveState").textContent = "更新间隔方案失败：" + (error?.message || error);
      }
    }

    async function deleteIntervalPresetById(id) {
      const preset = intervalPresets.find((item) => item.id === id);
      if (!preset) {
        $("saveState").textContent = "没有找到这个间隔方案。";
        return;
      }
      if (!confirm("确认删除间隔方案“" + (preset.name || "未命名方案") + "”？当前输入框内容不会被清空。")) return;
      try {
        const result = await postJson("/api/interval-presets/delete", { id });
        intervalPresets = Array.isArray(result.presets) ? result.presets : [];
        renderIntervalPresetOptions();
        $("saveState").textContent = "已删除间隔方案。";
      } catch (error) {
        $("saveState").textContent = "删除间隔方案失败：" + (error?.message || error);
      }
    }

    function clearCustomIntervals() {
      for (const key of ["sameTuoMin","sameTuoMax","differentTuoMin","differentTuoMax","mediaMin","mediaMax","doumaSameMin","doumaSameMax","roleSwitchMin","roleSwitchMax"]) {
        if ($(key)) $(key).value = "";
      }
      $("saveState").textContent = "已清空，将使用默认间隔规则";
    }

    function validateIntervalInputs() {
      if ($("scheduleMode").value === "doc") return "";
      const groups = [
        ["differentTuoMin", "differentTuoMax"],
        ["sameTuoMin", "sameTuoMax"],
        ["doumaSameMin", "doumaSameMax"],
        ["roleSwitchMin", "roleSwitchMax"]
      ];
      for (const [minId, maxId] of groups) {
        const min = String($(minId)?.value || "").trim();
        const max = String($(maxId)?.value || "").trim();
        if (!min && !max) continue;
        if (!min || !max) return "自定义间隔的最短和最长要么都填，要么都不填。";
        if (!/^\\d+$/.test(min) || !/^\\d+$/.test(max) || Number(min) <= 0 || Number(max) <= 0) return "自定义间隔只能填写正整数秒数。";
        if (Number(min) > Number(max)) return "自定义间隔的最短不能大于最长。";
      }
      return "";
    }

    async function sendControl(action) {
      await postJson("/api/control", { action });
      await refreshStatus();
    }

    async function fetchJson(url) {
      const response = await fetchWithTimeout(url, {}, 15000);
      const data = await response.json().catch(() => ({ ok: false, error: "后台接口返回内容不是 JSON。" }));
      if (!response.ok || data?.ok === false) throw new Error(data?.error || data?.message || ("后台接口返回失败：" + response.status));
      return data;
    }

    async function fetchWithTimeout(url, options, timeoutMs) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        return await fetch(url, { ...options, signal: controller.signal });
      } catch (error) {
        if (error?.name === "AbortError") throw new Error("后台接口响应超时，不影响当前使用。");
        throw error;
      } finally {
        clearTimeout(timer);
      }
    }

    async function postJson(url, body) {
      const response = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await response.json().catch(() => ({ ok: false, error: "后台接口返回内容不是 JSON。" }));
      if (!response.ok || data?.ok === false) throw new Error(data?.error || data?.message || ("后台接口返回失败：" + response.status));
      return data;
    }

    async function postJsonResult(url, body) {
      const response = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await response.json().catch(() => ({ ok: false, error: "后台接口返回内容不是 JSON。" }));
      if (!response.ok) return { ok: false, status: response.status, ...data };
      return data;
    }
  </script>
</body>
</html>`;
}

async function readJsonBody(req) {
  let body = "";
  for await (const chunk of req) body += chunk;
  if (!body.trim()) return {};
  return JSON.parse(body);
}

async function saveUploadedTuoRoster(projectRoot, body = {}) {
  const originalName = String(body.fileName || "").trim();
  const ext = path.extname(originalName).toLowerCase();
  if (![".xlsx", ".csv", ".json"].includes(ext)) {
    throw new Error("托名单只支持 XLSX、CSV、JSON 文件。");
  }
  const contentBase64 = String(body.contentBase64 || "").replace(/^data:[^,]+,/, "");
  if (!contentBase64) throw new Error("上传的托名单内容为空。");
  const buffer = Buffer.from(contentBase64, "base64");
  if (!buffer.length) throw new Error("上传的托名单内容为空。");
  if (buffer.length > 20 * 1024 * 1024) throw new Error("托名单文件不能超过 20MB。");
  const uploadDir = path.join(projectRoot, "data", "tuo-rosters");
  await fs.mkdir(uploadDir, { recursive: true });
  const baseName = sanitizeUploadFileBase(path.basename(originalName, ext)) || "tuo-roster";
  const fileName = `${timestampForFile()}-${baseName}${ext}`;
  const filePath = path.join(uploadDir, fileName);
  await fs.writeFile(filePath, buffer);
  return {
    fileName,
    originalName,
    filePath,
    size: buffer.length
  };
}

function sanitizeUploadFileBase(value) {
  return String(value || "")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
    .replace(/\s+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 80);
}

function timestampForFile() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate()),
    "-",
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

function isWorkflowBusy(state) {
  const status = state.snapshot().status;
  return status === "running" || status === "paused";
}

function isClearableStaleConsoleState(snapshot = {}) {
  if (snapshot.status === "running" || snapshot.control === "running") return false;
  if (snapshot.status === "completed") return false;
  return ["failed", "stopped", "paused", "waiting"].includes(snapshot.status)
    || ["awaiting_error_action", "paused", "stopped"].includes(snapshot.control)
    || Boolean(snapshot.failureReason);
}

function resetTerminalConsoleStateOnOpen(state) {
  const status = state.snapshot().status;
  if (!["failed", "stopped", "disconnected"].includes(status)) return false;
  state.resetTerminalState?.("重新打开控制台：已清理上次失败/停止状态");
  return true;
}

function resetStartupConsoleStateOnOpen(state, workflow) {
  if (workflow?.isRunning?.()) return false;
  const snapshot = state.snapshot();
  if (snapshot.status === "ready" && snapshot.step === "idle" && !snapshot.failureReason && !snapshot.runDir) return false;
  state.resetForStartup?.("正式入口重新打开：已清理上次运行状态，预览文件仍可恢复");
  return true;
}

function runIdFromRunDir(runDir = "") {
  const match = String(runDir || "").match(/(?:^|[\\/])(v2_(?:real_flow|library_work)_\d{8}_\d{6}[A-Za-z0-9_-]*)$/);
  return match ? match[1] : "";
}

async function buildCmsConfigSnapshotAfterRefresh({ workflow, state, runDir, settings, name }) {
  await workflow.refreshCurrentCmsPageBindings?.({ runDir }).catch((error) => {
    state.log("云中客配置：保存前刷新当前页面选择失败，改用已有绑定记录。" + (error?.message ? ` 原因：${error.message}` : ""));
  });
  return buildCmsConfigSnapshot({ runDir, settings, name });
}

function sendWorkflowBusy(res, state) {
  sendJson(res, 409, {
    ok: false,
    error: "已有流程正在运行，请等当前流程结束。",
    state: state.snapshot()
  });
}

async function waitForWorkflowIdle(workflow, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  while (workflow?.isRunning?.() && Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
}

async function buildContinueCandidate(snapshot = {}) {
  const previewPath = snapshot.previewPath || (snapshot.runDir ? path.join(snapshot.runDir, "preview.json") : "");
  if (!previewPath) return { ok: false, error: "没有找到当前预览文件，不能判断从哪一条继续。" };
  const preview = await readJsonIfExists(previewPath);
  const tasks = normalizePreviewTasks(preview).map((task, index) => ({
    ...task,
    index: Number(task.index || index + 1)
  }));
  if (!tasks.length) return { ok: false, error: "预览文件里没有可创建任务。" };
  const lastCompletedIndex = deriveLastCompletedIndex(snapshot);
  const expectedIndex = Math.max(1, lastCompletedIndex + 1);
  const activeTasks = tasks
    .filter((task) => !task.skip)
    .sort((a, b) => Number(a.index || a.order || 0) - Number(b.index || b.order || 0));
  const current = activeTasks.find((task) => Number(task.index || 0) >= expectedIndex) || activeTasks[0];
  if (!current) return { ok: false, error: "预览文件里没有待创建任务。" };
  const currentPosition = activeTasks.findIndex((task) => Number(task.index || 0) === Number(current.index || 0));
  const next = currentPosition >= 0 ? activeTasks[currentPosition + 1] : null;
  return {
    ok: true,
    lastCompletedIndex,
    current: summarizeContinueTask(current),
    next: next ? summarizeContinueTask(next) : null
  };
}

async function buildPreviousSuccessTuoCooldownCandidate(snapshot = {}) {
  const previewPath = snapshot.previewPath || (snapshot.runDir ? path.join(snapshot.runDir, "preview.json") : "");
  const lastCompletedIndex = deriveLastCompletedIndex(snapshot);
  if (!previewPath || !lastCompletedIndex) {
    return { available: false, nicknames: [], lastCompletedIndex: 0 };
  }
  const preview = await readJsonIfExists(previewPath);
  const tasks = normalizePreviewTasks(preview).map((task, index) => ({
    ...task,
    index: Number(task.index || index + 1)
  }));
  const seen = new Set();
  const nicknames = [];
  for (const task of tasks) {
    if (task.skip || task.role !== "tuo" || Number(task.index || 0) > lastCompletedIndex) continue;
    const name = String(task?.tuoAssignment?.primary?.nickname || task.speaker || task.cleanSpeaker || "").trim();
    const key = name.replace(/\s+/g, "");
    if (!name || seen.has(key)) continue;
    seen.add(key);
    nicknames.push(name);
  }
  return {
    available: nicknames.length > 0,
    nicknames,
    lastCompletedIndex,
    runName: snapshot.runDir ? path.basename(snapshot.runDir) : "",
    previewPath
  };
}

function normalizePreviewTasks(preview) {
  if (Array.isArray(preview)) return preview;
  if (Array.isArray(preview?.tasks)) return preview.tasks;
  if (Array.isArray(preview?.preview)) return preview.preview;
  return [];
}

function deriveLastCompletedIndex(snapshot = {}) {
  const direct = Number(snapshot.lastCompletedIndex || 0);
  if (direct > 0) return direct;
  const logs = Array.isArray(snapshot.logs) ? snapshot.logs : [];
  for (let i = logs.length - 1; i >= 0; i -= 1) {
    const message = String(logs[i]?.message || "");
    const byPreviewIndex = message.match(/第\s*(\d+)\s*条创建成功/);
    if (byPreviewIndex) return Number(byPreviewIndex[1]);
    const byOldPlanIndex = message.match(/创建成功：\s*(\d+)\s*\//);
    if (byOldPlanIndex) return Number(byOldPlanIndex[1]);
  }
  return 0;
}

function summarizeContinueTask(task = {}) {
  return {
    index: Number(task.index || 0),
    date: task.date || "",
    time: task.time || "",
    role: task.role || "",
    roleLabel: task.role === "douma" ? "豆妈" : task.role === "tuo" ? "托" : task.role || "",
    speaker: task.speaker || task.cleanSpeaker || "",
    type: task.type || "",
    summary: summarizeTaskContent(task)
  };
}

function summarizeTaskContent(task = {}) {
  if (task.type === "text" || task.type === "finder") return compactText(task.text || task.sourceText || "");
  const media = task.mediaPath || task.materialPath || task.localPath || task.path || "";
  return media ? path.basename(String(media)) : compactText(task.text || task.sourceText || "");
}

function compactText(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (text.length <= 80) return text;
  return `${text.slice(0, 80)}...`;
}

function backupOptions(body = {}) {
  return {
    name: body.name,
    backupRoot: body.backupRoot
  };
}

function versionActionOptions(body = {}) {
  return {
    ...backupOptions(body),
    backupName: body.backupName,
    installCommand: body.installCommand,
    installArgs: body.installArgs,
    checkCommand: body.checkCommand,
    checkArgs: body.checkArgs
  };
}

function pickLicenseOptions(options = {}) {
  return {
    fetch: options.licenseFetch,
    licenseConfig: options.licenseConfig,
    appVersion: options.appVersion
  };
}

function startLicenseHeartbeat(projectRoot, options = {}) {
  const intervalMs = Number.isFinite(Number(options.intervalMs)) ? Math.max(5000, Number(options.intervalMs)) : 60000;
  const initialDelayMs = Number.isFinite(Number(options.initialDelayMs)) ? Math.max(0, Number(options.initialDelayMs)) : 2000;
  let stopped = false;
  let inFlight = false;
  let timer = null;
  const beat = async () => {
    if (stopped || inFlight) return;
    inFlight = true;
    try {
      const version = options.versionStatusProvider
        ? await options.versionStatusProvider()
        : await getVersionStatus(projectRoot).catch((error) => ({ status: "failed", error: error?.message || String(error) }));
      await submitLicenseHeartbeat(projectRoot, {
        ...options.licenseOptions,
        updateStatus: summarizeHeartbeatVersion(version)
      }).catch(() => {});
    } finally {
      inFlight = false;
      if (!stopped) timer = setTimeout(beat, intervalMs);
    }
  };
  timer = setTimeout(beat, initialDelayMs);
  return () => {
    stopped = true;
    if (timer) clearTimeout(timer);
  };
}

function summarizeHeartbeatVersion(version = {}) {
  return {
    currentVersion: version.currentVersion || "",
    latestVersion: version.latestRemoteVersion || "",
    updateAvailable: version.updateAvailable === true,
    pendingUpdateReady: version.pendingUpdateReady === true,
    updateMode: version.updateMode || "",
    status: version.error ? "failed" : "ok"
  };
}

function installConsoleProcessGuards({ state, setLastResult } = {}) {
  const recordRecoverable = (error, source) => {
    const message = [
      "浏览器弹窗处理异常已忽略，后台服务已保持运行。",
      "原因：弹窗出现后又被页面关闭，Playwright 收到 No dialog is showing。",
      "如果当前条随后失败，可在控制台选择重试或跳过。"
    ].join(" ");
    setLastResult?.({ ok: false, error: message, source });
    state?.log?.(`后台保护：${message}`, {
      source,
      rawError: error?.message || String(error || "")
    });
    const snapshot = state?.snapshot?.() || {};
    if (["running", "paused", "waiting"].includes(snapshot.status)) {
      state.update({
        waitingReason: snapshot.waitingReason || "后台已忽略一次浏览器弹窗异常，流程仍在继续。"
      });
    }
  };

  const onUnhandledRejection = (reason) => {
    if (isRecoverableBrowserDialogError(reason)) {
      recordRecoverable(reason, "unhandledRejection");
      return;
    }
    process.removeListener("unhandledRejection", onUnhandledRejection);
    setImmediate(() => {
      throw reason instanceof Error ? reason : new Error(String(reason));
    });
  };

  const onUncaughtException = (error) => {
    if (isRecoverableBrowserDialogError(error)) {
      recordRecoverable(error, "uncaughtException");
      return;
    }
    process.removeListener("uncaughtException", onUncaughtException);
    throw error;
  };

  process.on("unhandledRejection", onUnhandledRejection);
  process.on("uncaughtException", onUncaughtException);
  return () => {
    process.removeListener("unhandledRejection", onUnhandledRejection);
    process.removeListener("uncaughtException", onUncaughtException);
  };
}

export function isRecoverableBrowserDialogError(error) {
  const message = error?.message || String(error || "");
  return /Page\.handleJavaScriptDialog/i.test(message) && /No dialog is showing/i.test(message);
}

function scheduleConsoleRestart(projectRoot, closeServer) {
  setTimeout(() => {
    const scriptPath = path.join(projectRoot, "src", "v2", "tools", "launch-console-hidden.ps1");
    const child = spawn("powershell.exe", [
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      scriptPath,
      "-ProjectRoot",
      projectRoot,
      "-WaitForPortClosed"
    ], {
      cwd: projectRoot,
      detached: true,
      stdio: "ignore",
      windowsHide: true
    });
    child.unref();
    closeServer().catch(() => {});
  }, 500);
}

function sendJson(res, status, data) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function sendHtml(res, html) {
  res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  res.end(html);
}

async function openControlledConsole(projectRoot, url) {
  const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
  await ensureV2ControlledBrowser({ projectRoot, config, url });
}

function withControlledFlag(url) {
  const parsed = new URL(url);
  parsed.searchParams.set("controlled", "1");
  return parsed.toString();
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function buildConsoleServiceInfo(projectRoot) {
  return {
    protocol: "v2-console-service-v2-license",
    projectRoot: path.resolve(projectRoot),
    codeRevision: await readGitRevision(projectRoot),
    startedAt: new Date().toISOString()
  };
}

async function readGitRevision(projectRoot) {
  try {
    const gitDir = path.join(projectRoot, ".git");
    const head = String(await fs.readFile(path.join(gitDir, "HEAD"), "utf8")).trim();
    if (head.startsWith("ref:")) {
      const refPath = head.slice(5).trim().replace(/\//g, path.sep);
      return String(await fs.readFile(path.join(gitDir, refPath), "utf8")).trim();
    }
    return head;
  } catch {
    return "";
  }
}

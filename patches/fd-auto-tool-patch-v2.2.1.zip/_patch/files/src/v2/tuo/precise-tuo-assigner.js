import { inferTuoIntent } from "./tuo-intent.js";
import { normalizeRosterKey } from "./tuo-roster.js";

const DEFAULT_COOLDOWN = 5;
const DEFAULT_CANDIDATE_COUNT = 4;
const GENERIC_PERSONA_TAGS = new Set(["female", "male"]);
const HARD_SWITCH_PERSONA_TAGS = new Set(["work", "young"]);

export function assignPreciseTuoSpeakers(tasks = [], roster = [], options = {}) {
  const cooldown = Number.isFinite(Number(options.cooldown)) ? Number(options.cooldown) : DEFAULT_COOLDOWN;
  const candidateCount = Math.max(1, Number(options.candidateCount || DEFAULT_CANDIDATE_COUNT));
  const rotationOffset = rosterRotationOffset(roster, options.rotationSeed);
  const previousCooldownKeys = new Set((options.previousCooldownNicknames || [])
    .map((name) => normalizeRosterKey(name))
    .filter(Boolean));
  const recentByPersona = new Map();
  const usedCounts = new Map();
  const backupRotation = new Map();
  const groupAssignments = new Map();
  const groupIntentHints = buildGroupIntentHints(tasks);
  const assignments = [];
  const nextTasks = tasks.map((task, index) => {
    if (task?.role !== "tuo") return task;
    const groupKey = preciseTuoGroupKey(task);
    const ownIntent = inferTuoIntent(task);
    const hint = groupKey ? groupIntentHints.get(groupKey) : null;
    const intent = shouldUseGroupIntentHint(task, ownIntent, hint) ? hint.intent : ownIntent;
    const existing = groupKey ? groupAssignments.get(groupKey) : null;
    const shouldReuseExisting = existing?.item && shouldReusePreciseGroup(existing, intent, groupKey);
    if (shouldReuseExisting) {
      assignments.push({
        index: task.index || index + 1,
        sourceId: task.sourceId || "",
        previousSpeaker: task.speaker || "",
        assignedSpeaker: existing.item.nickname,
        remark: existing.item.remark,
        reason: existing.groupReason,
        fallback: existing.fallback,
        backup: existing.item.backup,
        tags: intent.tags,
        candidateSpeakers: existing.candidates.map((item) => item.nickname),
        groupKey
      });
      return applyTuoAssignment(task, existing.item, existing.candidates, intent, {
        reason: existing.groupReason,
        fallback: existing.fallback,
        cooldown,
        cooldownKey: existing.cooldownKey,
        groupKey
      });
    }
    const decision = chooseRosterItem(roster, intent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster,
      rotationOffset,
      previousCooldownKeys,
      backupRotation
    });
    if (!decision.item) {
      assignments.push({
        index: task.index || index + 1,
        sourceId: task.sourceId || "",
        previousSpeaker: task.speaker || "",
        assignedSpeaker: "",
        reason: "没有可用托名单候选",
        fallback: true,
        backup: false,
        tags: intent.tags
      });
      return task;
    }
    const candidates = chooseRosterCandidates(roster, intent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster,
      rotationOffset,
      previousCooldownKeys,
      backupRotation,
      limit: candidateCount,
      primaryNickname: decision.item.nickname
    });
    const cooldownKey = rememberUse(decision.item, intent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster,
      rotationOffset,
      previousCooldownKeys,
      backupRotation
    });
    rememberCandidateReservations(candidates, intent, {
      recentByPersona,
      cooldown,
      roster
    });
    const regroupedReason = existing?.item && groupKey && !shouldReuseExisting
      ? `同一原始托出现更明确人设，重新分配：${decision.reason}`
      : decision.reason;
    assignments.push({
      index: task.index || index + 1,
      sourceId: task.sourceId || "",
      previousSpeaker: task.speaker || "",
      assignedSpeaker: decision.item.nickname,
      remark: decision.item.remark,
      reason: regroupedReason,
      fallback: decision.fallback,
      backup: decision.item.backup,
      tags: intent.tags,
      candidateSpeakers: candidates.map((item) => item.nickname),
      cooldownKey,
      groupKey
    });
    if (groupKey) {
      groupAssignments.set(groupKey, {
        item: decision.item,
        candidates,
        fallback: decision.fallback,
        cooldownKey,
        intent,
        groupReason: groupKey.startsWith("interaction:")
          ? `复用同一互动托分配：${decision.reason}`
          : `复用同一原始托分配：${decision.reason}`
      });
    }
    return applyTuoAssignment(task, decision.item, candidates, intent, {
      reason: regroupedReason,
      fallback: decision.fallback,
      cooldown,
      cooldownKey,
      groupKey
    });
  });

  return {
    tasks: nextTasks,
    report: buildAssignmentReport(assignments, roster, {
      previousCooldownCount: previousCooldownKeys.size,
      rotationOffset
    })
  };
}

function buildGroupIntentHints(tasks = []) {
  const hints = new Map();
  for (const task of tasks) {
    if (task?.role !== "tuo") continue;
    const groupKey = preciseTuoGroupKey(task);
    if (!groupKey || hints.has(groupKey) || !hasAssignableTuoText(task)) continue;
    const intent = inferTuoIntent(task);
    if (!specificIntentTags(intent).length) continue;
    hints.set(groupKey, { intent, sourceId: task.sourceId || "" });
  }
  return hints;
}

function shouldUseGroupIntentHint(task, ownIntent, hint) {
  if (!hint?.intent) return false;
  if (hasAssignableTuoText(task)) return false;
  return !specificIntentTags(ownIntent).length;
}

function hasAssignableTuoText(task = {}) {
  if (task.type !== "text") return false;
  return Boolean(String(task.text || task.sourceText || "").trim());
}

function applyTuoAssignment(task, item, candidates, intent, options = {}) {
  return {
    ...task,
    speaker: item.nickname,
    cleanSpeaker: item.nickname,
    tuoAssignment: buildTuoAssignment(item, candidates, intent, {
      reason: options.reason,
      fallback: options.fallback,
      cooldown: options.cooldown,
      cooldownKey: options.cooldownKey,
      groupKey: options.groupKey
    })
  };
}

function preciseTuoGroupKey(task = {}) {
  const interactionGroup = String(task.interactionGroup || "").trim();
  if (interactionGroup) return `interaction:${normalizeRosterKey(interactionGroup)}`;
  const speaker = originalTuoSpeakerKey(task);
  return speaker ? `speaker:${speaker}` : "";
}

function originalTuoSpeakerKey(task = {}) {
  const speaker = normalizeRosterKey(task.cleanSpeaker || task.speaker || "");
  if (!speaker || isGenericTuoSpeakerKey(speaker)) return "";
  return speaker;
}

function isGenericTuoSpeakerKey(key) {
  return ["托", "托号", "托儿", "水军", "互动托"].includes(key);
}

function shouldReusePreciseGroup(existing, intent, groupKey) {
  if (String(groupKey || "").startsWith("interaction:")) return true;
  const wanted = specificIntentTags(intent).filter((tag) => HARD_SWITCH_PERSONA_TAGS.has(tag));
  if (!wanted.length) return true;
  return wanted.some((tag) => existing?.item?.tags?.includes(tag));
}

function specificIntentTags(intent = {}) {
  return (intent.tags || []).filter((tag) => !GENERIC_PERSONA_TAGS.has(tag));
}

export function chooseRosterItem(roster = [], intent = {}, context = {}) {
  const candidates = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!candidates.length) return { item: null, reason: "名单为空", fallback: true };
  const explicitKey = normalizeRosterKey(intent.explicitNickname);
  if (explicitKey) {
    const exact = pickBest(candidates.filter((item) => normalizeRosterKey(item.nickname) === explicitKey), intent, context, { allowBackup: true });
    if (exact) return { item: exact.item, reason: "按文案指定托分配", fallback: false };
  }

  const primary = pickBest(candidates.filter((item) => !item.backup), intent, context, { allowBackup: false });
  if (primary && primary.score > 0) return { item: primary.item, reason: primary.reason, fallback: false };

  const specificFallback = pickBestSpecificCandidate(candidates.filter((item) => !item.backup), intent, context);
  if (specificFallback) {
    return {
      item: specificFallback.item,
      reason: `${specificFallback.reason}，同人设候选在冷却池内回退复用`,
      fallback: true
    };
  }

  const anyPrimary = pickBest(candidates.filter((item) => !item.backup), intent, context, { allowBackup: false, ignoreTags: true });
  if (anyPrimary) return { item: anyPrimary.item, reason: "没有明显身份命中，按最少使用托兜底", fallback: true };

  const backup = pickBackupCandidate(candidates, intent, context);
  if (backup) return { item: backup.item, reason: backup.reason, fallback: true };
  return { item: null, reason: "没有可用候选", fallback: true };
}

export function chooseRosterCandidates(roster = [], intent = {}, context = {}) {
  const limit = Math.max(1, Number(context.limit || DEFAULT_CANDIDATE_COUNT));
  const candidates = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!candidates.length) return [];
  const primaryKey = normalizeRosterKey(context.primaryNickname);
  const exact = primaryKey ? candidates.find((item) => normalizeRosterKey(item.nickname) === primaryKey) : null;
  const scored = rankRosterCandidates(candidates, intent, context, { allowBackup: true })
    .filter((entry) => normalizeRosterKey(entry.item.nickname) !== primaryKey)
    .map((entry) => entry.item);
  const ordered = exact ? [exact, ...scored] : scored;
  const seen = new Set();
  const result = [];
  for (const item of ordered) {
    const key = normalizeRosterKey(item.nickname);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    result.push(item);
    if (result.length >= limit) break;
  }
  return result;
}

function pickBest(candidates, intent, context, options = {}) {
  return rankRosterCandidates(candidates, intent, context, options)[0] || null;
}

function pickBestSpecificCandidate(candidates, intent, context) {
  const wanted = specificIntentTags(intent);
  if (!wanted.length) return null;
  return rankRosterCandidates(
    candidates.filter((item) => wanted.some((tag) => item.tags?.includes(tag))),
    intent,
    context,
    { allowBackup: false }
  )[0] || null;
}

function pickBackupCandidate(candidates, intent, context = {}) {
  const backups = candidates.filter((item) => item.backup && item.nickname);
  if (!backups.length) return null;
  const wanted = specificIntentTags(intent);
  const pools = [];
  for (const tag of wanted) {
    pools.push({
      key: `tag:${tag}`,
      label: `备用托人设命中：${tag}`,
      items: backups.filter((item) => item.tags?.includes(tag))
    });
  }
  pools.push({ key: "backup:all", label: "主名单不可用，使用备用托兜底", items: backups });
  for (const pool of pools) {
    const picked = pickUnusedBackupFromPool(pool.items, intent, context, pool.key, { allowReset: false });
    if (picked) return { item: picked, reason: pool.label };
  }
  for (const pool of pools) {
    const picked = pickUnusedBackupFromPool(pool.items, intent, context, pool.key, { allowReset: true });
    if (picked) return { item: picked, reason: `${pool.label}，备用池已用完后进入新一轮` };
  }
  return null;
}

function pickUnusedBackupFromPool(items, intent, context = {}, poolKey, options = {}) {
  const candidates = rankRosterCandidates(items, intent, context, { allowBackup: true, allowBackupPenalty: false });
  if (!candidates.length) return null;
  const state = backupPoolState(context.backupRotation, poolKey);
  const globalState = backupPoolState(context.backupRotation, "backup:all");
  const validKeys = new Set(candidates.map((entry) => normalizeRosterKey(entry.item.nickname)).filter(Boolean));
  for (const key of [...state.used]) {
    if (!validKeys.has(key)) state.used.delete(key);
  }
  let fresh = candidates.filter((entry) => {
    const key = normalizeRosterKey(entry.item.nickname);
    return !state.used.has(key) && !globalState.used.has(key);
  });
  if (!fresh.length) {
    if (!options.allowReset) return null;
    state.used.clear();
    if (poolKey === "backup:all") globalState.used.clear();
    fresh = candidates;
  }
  const picked = fresh[0]?.item || null;
  const pickedKey = normalizeRosterKey(picked?.nickname);
  if (pickedKey) {
    state.used.add(pickedKey);
    globalState.used.add(pickedKey);
  }
  return picked;
}

function backupPoolState(rotation, key) {
  if (!rotation || typeof rotation.get !== "function") return { used: new Set() };
  const normalized = key || "backup:all";
  if (!rotation.has(normalized)) rotation.set(normalized, { used: new Set() });
  return rotation.get(normalized);
}

function rankRosterCandidates(candidates, intent, context, options = {}) {
  const total = Math.max(1, Number(context.roster?.length || candidates.length || 1));
  const offset = Number(context.rotationOffset || 0);
  return candidates
    .filter((item) => options.allowBackup || !item.backup)
    .map((item) => scoreCandidate(item, intent, context, options))
    .filter((item) => item.score > -1000)
    .sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      if (left.used !== right.used) return left.used - right.used;
      return rotatedOrder(left.item.order, offset, total) - rotatedOrder(right.item.order, offset, total);
    });
}

function scoreCandidate(item, intent, context, options = {}) {
  const used = context.usedCounts?.get(item.nickname) || 0;
  const previousCooldown = context.previousCooldownKeys?.has(normalizeRosterKey(item.nickname));
  const recent = recentNicknamesForCandidate(item, intent, context).includes(item.nickname);
  const wantedTags = options.ignoreTags ? [] : intent.tags || [];
  let score = options.ignoreTags ? 1 : 0;
  const matched = [];
  for (const tag of wantedTags) {
    if (item.tags?.includes(tag)) {
      score += tag === "female" || tag === "male" ? 1 : 4;
      matched.push(tag);
    }
  }
  if (!options.ignoreTags && wantedTags.includes("young") && item.tags?.includes("mature") && !item.tags?.includes("young")) {
    score -= 6;
  }
  if (!options.ignoreTags && wantedTags.length && !matched.length) score -= 2;
  if (recent) score -= 100;
  if (previousCooldown) score -= 100;
  if (item.backup && options.allowBackupPenalty !== false) score -= 20;
  score -= used;
  return {
    item,
    score,
    used,
    reason: matched.length ? `身份命中：${matched.join("/")}` : "按最少使用托兜底"
  };
}

function rotatedOrder(order = 0, offset = 0, total = 1) {
  const base = Math.max(0, Number(order || 0));
  const count = Math.max(1, Number(total || 1));
  return (base - Number(offset || 0) + count) % count;
}

function rosterRotationOffset(roster = [], seed = "") {
  const count = Array.isArray(roster) ? roster.filter((item) => item?.nickname).length : 0;
  if (!count) return 0;
  const text = String(seed || "");
  if (!text) return 0;
  let hash = 0;
  for (let index = 0; index < text.length; index += 1) {
    hash = ((hash * 31) + text.charCodeAt(index)) >>> 0;
  }
  return hash % count;
}

function rememberUse(item, intent, context) {
  const nickname = item?.nickname || "";
  if (!nickname) return "";
  const key = cooldownKeyForCandidate(item, intent);
  const recentByPersona = context.recentByPersona;
  const recent = recentByPersona?.get(key) || [];
  const limit = cooldownLimitForKey(context.roster, key, context.cooldown);
  context.usedCounts.set(nickname, (context.usedCounts.get(nickname) || 0) + 1);
  recent.push(nickname);
  while (recent.length > limit) recent.shift();
  recentByPersona?.set(key, recent);
  return key;
}

function rememberCandidateReservations(candidates = [], intent = {}, context = {}) {
  for (const item of candidates) {
    const nickname = item?.nickname || "";
    if (!nickname) continue;
    const key = cooldownKeyForCandidate(item, intent);
    const recentByPersona = context.recentByPersona;
    const recent = recentByPersona?.get(key) || [];
    const limit = cooldownLimitForKey(context.roster, key, context.cooldown);
    const existingIndex = recent.indexOf(nickname);
    if (existingIndex >= 0) recent.splice(existingIndex, 1);
    recent.push(nickname);
    while (recent.length > limit) recent.shift();
    recentByPersona?.set(key, recent);
  }
}

function recentNicknamesForCandidate(item, intent, context = {}) {
  if (context.recentByPersona) {
    return context.recentByPersona.get(cooldownKeyForCandidate(item, intent)) || [];
  }
  return context.recentNicknames || [];
}

function cooldownLimitForKey(roster = [], key, fallback) {
  const explicit = Number(fallback);
  if (Number.isFinite(explicit) && explicit > 0 && explicit !== DEFAULT_COOLDOWN) return Math.max(1, explicit);
  const count = roster.filter((item) => item?.nickname && candidateMatchesCooldownKey(item, key)).length;
  return Math.max(1, count || DEFAULT_COOLDOWN);
}

function cooldownKeyForCandidate(item = {}, intent = {}) {
  const wanted = specificIntentTags(intent);
  const matchedSpecific = wanted.find((tag) => item.tags?.includes(tag));
  if (matchedSpecific) return `tag:${matchedSpecific}`;
  const matchedAny = (intent.tags || []).find((tag) => item.tags?.includes(tag));
  if (matchedAny) return `tag:${matchedAny}`;
  const firstSpecific = (item.tags || []).find((tag) => !GENERIC_PERSONA_TAGS.has(tag));
  if (firstSpecific) return `tag:${firstSpecific}`;
  const persona = Array.isArray(item.personas) ? item.personas.find(Boolean) : "";
  if (persona) return `persona:${normalizeRosterKey(persona)}`;
  const firstTag = (item.tags || []).find(Boolean);
  return firstTag ? `tag:${firstTag}` : "all";
}

function candidateMatchesCooldownKey(item = {}, key = "") {
  if (key === "all") return true;
  if (key.startsWith("tag:")) return item.tags?.includes(key.slice(4));
  if (key.startsWith("persona:")) {
    const target = key.slice(8);
    return (item.personas || []).some((label) => normalizeRosterKey(label) === target);
  }
  return false;
}

function buildAssignmentReport(assignments, roster, meta = {}) {
  const assigned = assignments.filter((item) => item.assignedSpeaker);
  return {
    ok: true,
    rosterCount: roster.length,
    previousCooldownCount: meta.previousCooldownCount || 0,
    rotationOffset: meta.rotationOffset || 0,
    rosterOptions: serializeRosterOptions(roster),
    tuoTaskCount: assignments.length,
    assignedCount: assigned.length,
    fallbackCount: assignments.filter((item) => item.fallback).length,
    backupCount: assignments.filter((item) => item.backup).length,
    assignments
  };
}

function serializeRosterOptions(roster = []) {
  const seen = new Set();
  const options = [];
  for (const item of roster) {
    const key = normalizeRosterKey(item.nickname);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    options.push(serializeCandidate(item));
  }
  return options;
}

function buildTuoAssignment(primary, candidates, intent, options = {}) {
  return {
    mode: "precise_roster",
    cooldown: options.cooldown || DEFAULT_COOLDOWN,
    cooldownMode: "persona_rotation",
    cooldownKey: options.cooldownKey || "",
    groupKey: options.groupKey || "",
    reason: options.reason || "",
    fallback: Boolean(options.fallback),
    intentTags: intent.tags || [],
    intentReasons: intent.reasons || [],
    primary: serializeCandidate(primary),
    candidates: candidates.map(serializeCandidate)
  };
}

function serializeCandidate(item = {}) {
  return {
    nickname: item.nickname || "",
    remark: item.remark || "",
    tags: item.tags || [],
    personas: item.personas || [],
    auxTags: item.auxTags || [],
    backup: Boolean(item.backup),
    order: item.order ?? 0
  };
}

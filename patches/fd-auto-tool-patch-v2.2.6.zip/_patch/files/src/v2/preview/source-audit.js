import { detectRoleHeader, isNonSendableRemark, parseExplicitTimedRoleHeaderLine } from "../parser/role-header.js";
import { sourceOccurrenceIdsFrom } from "../feishu-api/source-identity.js";
import { normalizeMessageText } from "../parser/message-text.js";

const EXPLICIT_NON_SEND_DIAGNOSTICS = new Set([
  "change_day_marker",
  "ignored_day_marker",
  "dropped_collected_date_heading_residue",
  "dropped_finder_code_block_chrome"
]);
const SPEAKER_WARNING = "预览说话人归属与原文位置不一致，请核对本行说话人。";

export function buildPreviewSourceAudit(events = [], tasks = [], diagnostics = []) {
  const sourceEvents = Array.isArray(events) ? events : [];
  const previewTasks = Array.isArray(tasks) ? tasks : [];
  const accounted = new Map();
  for (const [taskIndex, task] of previewTasks.entries()) {
    if (/^restored-/.test(String(task?.sourceId || "")) && !sourceOccurrenceIdsFrom(task).length) continue;
    for (const ref of sourceRefsForTask(task)) {
      if (!accounted.has(ref)) accounted.set(ref, []);
      accounted.get(ref).push({ taskIndex, submitIdentity: String(task?.submitIdentity || "") });
    }
  }

  const diagnosticBySource = new Map();
  for (const diagnostic of Array.isArray(diagnostics) ? diagnostics : []) {
    for (const sourceId of splitSourceIds(diagnostic?.sourceId)) {
      if (!diagnosticBySource.has(sourceId)) diagnosticBySource.set(sourceId, []);
      diagnosticBySource.get(sourceId).push(diagnostic);
    }
  }

  const rawRefCounts = new Map();
  for (const event of sourceEvents) {
    for (const ref of sourceRefsForEvent(event)) rawRefCounts.set(ref, Number(rawRefCounts.get(ref) || 0) + 1);
  }
  const duplicateInputRefs = [...rawRefCounts.entries()].filter(([, count]) => count > 1).map(([sourceOccurrenceId, count]) => ({ sourceOccurrenceId, count }));
  const duplicateInputSet = new Set(duplicateInputRefs.map((item) => item.sourceOccurrenceId));

  const outcomes = sourceEvents.map((event, eventIndex) => {
    const refs = sourceRefsForEvent(event);
    const emittedRefs = refs.filter((ref) => accounted.has(ref));
    const missingRefs = refs.filter((ref) => !accounted.has(ref));
    const duplicateRefs = refs.filter((ref) => duplicateInputSet.has(ref));
    const sourceIntegrityError = String(event?.previewError || "").trim();
    if (sourceIntegrityError) {
      return sourceOutcome(event, eventIndex, refs, "unresolved", sourceIntegrityError, emittedRefs, refs);
    }
    if (!missingRefs.length && !duplicateRefs.length) {
      return sourceOutcome(event, eventIndex, refs, "emitted", "已进入预览", emittedRefs);
    }
    if (duplicateRefs.length) {
      return sourceOutcome(event, eventIndex, refs, "unresolved", "同一原文位置被重复读取，需核对出现次数", emittedRefs, duplicateRefs);
    }
    const excluded = explicitNonSendReason(event, diagnosticBySource.get(String(event?.sourceId || "")) || []);
    if (excluded) return sourceOutcome(event, eventIndex, refs, "excluded", excluded, emittedRefs);
    return sourceOutcome(event, eventIndex, refs, "unresolved", "原文位置未进入预览，也没有明确的不发送依据", emittedRefs, missingRefs);
  });

  const unresolved = outcomes.filter((item) => item.status === "unresolved");
  const generatedIssues = auditGeneratedTasks(sourceEvents, previewTasks, accounted);
  return {
    schemaVersion: 1,
    complete: unresolved.length === 0 && generatedIssues.length === 0,
    coverageComplete: unresolved.length === 0,
    generatedIssueCount: generatedIssues.length,
    generatedIssues,
    sourceEventCount: sourceEvents.length,
    sourceOccurrenceCount: outcomes.reduce((sum, item) => sum + item.sourceOccurrenceIds.length, 0),
    emittedCount: outcomes.filter((item) => item.status === "emitted").length,
    excludedCount: outcomes.filter((item) => item.status === "excluded").length,
    unresolvedCount: unresolved.length,
    duplicateInputRefs,
    unresolved,
    outcomes
  };
}

// Generation-only comparisons. These are review warnings, never deduplication
// or a reason to regenerate a final preview that the user has already edited.
function auditGeneratedTasks(events, tasks, accounted) {
  const issues = [];
  const expected = [];
  let speaker = "";
  let role = "";
  for (const [eventIndex, event] of events.entries()) {
    const refs = sourceRefsForEvent(event);
    const header = detectRoleHeader(event, { currentRole: role, allowBareNameHeaders: !role, allowHighlightedDouma: !role });
    if (event.kind === "title") { speaker = ""; role = ""; }
    if (header) { speaker = header.speaker; role = header.role; }
    const body = header ? (header.inlineBodyText || (header.useLineAsContent ? event.text : "")) : event.text;
    expected.push({
      event, refs, speaker: header?.speaker || collectedSpeakerName(event) || speaker || "",
      body: event.kind === "line" && !isNonSendableRemark(String(body || ""), { insideRoleSegment: true }) ? String(body || "") : ""
    });
    // Parent block refs may legitimately span distinct logical children.
    const leaves = refs.filter((ref) => !refs.some((other) => other.startsWith(ref + "#")));
    for (const ref of leaves) {
      const indexes = [...new Set((accounted.get(ref) || []).map((entry) => entry.taskIndex))]
        .filter((index) => !isManualReview(tasks[index]));
      if (indexes.length > 1) issues.push({ code: "duplicate_generated_source", eventIndex,
        sourceOccurrenceIds: [ref], taskIndexes: indexes, message: "同一原文位置生成了多条预览，请核对是否重复；系统未自动删除。" });
    }
  }
  for (const [taskIndex, task] of tasks.entries()) {
    if (isManualReview(task) || /^restored-/.test(String(task.sourceId || ""))) continue;
    const refs = sourceRefsForTask(task);
    const linked = expected.filter((entry) => entry.refs.some((ref) => refs.includes(ref)));
    if (!linked.length) continue;
    const speakers = [...new Set(linked.map((entry) => entry.speaker.replace(/\s+/g, "")).filter(Boolean))];
    const actualSpeaker = String((task.tuoAssignment?.mode === "precise_roster" ? task.sourceSpeaker : task.speaker)
      || task.sourceSpeaker || "").replace(/\s+/g, "");
    if (speakers.length && (speakers.length > 1 || speakers[0].replace(/\s+/g, "") !== actualSpeaker)) {
      issues.push({ code: "generated_speaker_mismatch", taskIndexes: [taskIndex], sourceOccurrenceIds: refs,
        message: SPEAKER_WARNING });
    }
    if (["text", "finder"].includes(task.type) && linked.every((entry) => entry.event.kind === "line")) {
      const expectedText = normalizeAuditText(linked.map((entry) => entry.body).join("\n"));
      if (expectedText && normalizeAuditText(task.text) !== expectedText) issues.push({
        code: "generated_content_mismatch", taskIndexes: [taskIndex], sourceOccurrenceIds: refs,
        message: "生成正文与对应原文片段不一致，请核对是否漏字或多出内容。"
      });
    }
    if (["image", "sticker", "video"].includes(task.type)) {
      const media = linked.filter((entry) => ["image", "sticker", "video"].includes(entry.event.kind));
      if (media.some(({ event }) => event.mediaPath && task.mediaPath
        && String(event.mediaPath).replace(/\\/g, "/") !== String(task.mediaPath).replace(/\\/g, "/"))) {
        issues.push({ code: "generated_media_mismatch", taskIndexes: [taskIndex], sourceOccurrenceIds: refs,
          message: "预览素材与对应原文位置的素材不一致，请核对本行素材。" });
      }
    }
  }
  return issues;
}

function collectedSpeakerName(event) {
  const collected = String(event?.collectSpeaker || "").trim();
  if (!collected) return "";
  // Feishu collection can retain "转发 · 昵称 · 日期" here, while the
  // parser stores only the nickname. Use the same explicit header grammar;
  // never strip arbitrary punctuation or dates from a nickname heuristically.
  return parseExplicitTimedRoleHeaderLine(`${collected} ${event.collectTime || ""}`.trim())?.speaker || collected;
}

// Remove only the old forwarded-header false positive, using the immutable
// generated task as evidence. Never compare or rewrite the user's edited text,
// speaker, clock, media or skip decisions while opening an existing preview.
export function clearLegacyCollectedSpeakerWarnings(tasks, events, generatedTasks, options = {}) {
  const stillMismatched = new Set(buildPreviewSourceAudit(events, generatedTasks).generatedIssues
    .filter((issue) => issue.code === "generated_speaker_mismatch").flatMap((issue) => issue.taskIndexes));
  const sourceKey = (task) => JSON.stringify([...sourceRefsForTask(task)].sort());
  const generatedBySource = new Map();
  for (const [index, task] of generatedTasks.entries()) {
    const key = sourceKey(task);
    if (key === "[]") continue;
    // Submission IDs are first assigned when preview.json is saved, so legacy
    // preview-tasks.json may have none. Require a unique provenance match.
    generatedBySource.set(key, generatedBySource.has(key) ? null : { task, index });
  }
  return tasks.map((task) => {
    if (Number(task.sourceAuditVersion || 0) >= 2 || !task.sourceAuditIssues?.includes("generated_speaker_mismatch")) return task;
    const match = generatedBySource.get(sourceKey(task));
    const unverified = () => options.markUnverified
      ? { ...withoutLegacySpeakerWarning(task), legacySpeakerAudit: "unverified" }
      : task;
    if (!match || isManualReview(match.task)) return unverified();
    if (stillMismatched.has(match.index)) {
      if (!options.markUnverified) return task;
      const next = { ...task, sourceAuditVersion: 2 };
      delete next.legacySpeakerAudit;
      if (!String(next.previewWarning || "").includes(SPEAKER_WARNING)) {
        next.previewWarning = [next.previewWarning, SPEAKER_WARNING].filter(Boolean).join("；");
      }
      return next;
    }
    const original = match.task;
    const refs = sourceRefsForTask(original);
    const linked = events.filter((event) => sourceRefsForEvent(event).some((ref) => refs.includes(ref)));
    if (!linked.length || linked.some((event) => !event.collectSpeaker)) return unverified();
    const actual = String((original.tuoAssignment?.mode === "precise_roster" ? original.sourceSpeaker : original.speaker) || "").replace(/\s+/g, "");
    const wrapped = linked.some((event) => collectedSpeakerName(event).replace(/\s+/g, "") !== String(event.collectSpeaker).replace(/\s+/g, ""));
    if (!wrapped || !actual || linked.some((event) => collectedSpeakerName(event).replace(/\s+/g, "") !== actual)) return unverified();
    const next = { ...withoutLegacySpeakerWarning(task), sourceAuditVersion: 2,
      sourceAuditIssues: task.sourceAuditIssues.filter((code) => code !== "generated_speaker_mismatch") };
    delete next.legacySpeakerAudit;
    return next;
  });
}

function withoutLegacySpeakerWarning(task) {
  const next = { ...task };
  next.previewWarning = String(task.previewWarning || "").replace(SPEAKER_WARNING, "").replace(/^；+|；+$/g, "").replace(/；{2,}/g, "；");
  if (!next.previewWarning) delete next.previewWarning;
  return next;
}

function isManualReview(task) {
  return /^manual-/i.test(String(task?.sourceId || "")) || task?.importResolutionConfirmed === true;
}

function normalizeAuditText(value) {
  return normalizeMessageText(String(value || "")
    .replace(/（[^）]*下面还说话[^）]*）|\([^)]*下面还说话[^)]*\)|【[^】]*下面还说话[^】]*】|\[[^\]]*下面还说话[^\]]*\]/g, "")
    .replace(/下面还说话/g, "").split("\n").map((line) => line.trim()).join("\n"));
}

export function sourceRefsForEvent(event = {}) {
  const refs = sourceOccurrenceIdsFrom(event);
  return refs.length ? refs : legacySourceRefs(event?.sourceId);
}

export function sourceRefsForTask(task = {}) {
  const refs = sourceOccurrenceIdsFrom(task);
  return refs.length ? refs : legacySourceRefs(task?.sourceId);
}

function sourceOutcome(event, eventIndex, refs, status, reason, emittedRefs = [], issueRefs = []) {
  return {
    eventIndex,
    sourceId: String(event?.sourceId || ""),
    sourceOccurrenceIds: refs,
    kind: String(event?.kind || ""),
    blockId: String(event?.blockId || ""),
    blockOrder: Number(event?.feishuBlockOrder || event?.order || 0),
    status,
    reason,
    emittedRefs,
    issueRefs
  };
}

function explicitNonSendReason(event, diagnostics) {
  if (String(event?.previewError || "").trim()) return "";
  if (event?.kind === "divider" || event?.kind === "title") return "结构标题或分隔线不发送";
  if (event?.kind === "line") {
    const text = String(event?.text || event?.sourceText || "");
    if (!text.trim()) return "空段落仅保留结构，不单独发送";
    const header = detectRoleHeader(event, {});
    if (header && !String(header.inlineBodyText || "").trim()) return "角色时间标题仅用于确定内容边界";
    if (isNonSendableRemark(text, { insideRoleSegment: true })) return "依据明确备注规则不发送";
  }
  const diagnostic = diagnostics.find((item) => EXPLICIT_NON_SEND_DIAGNOSTICS.has(String(item?.code || "")));
  return diagnostic ? String(diagnostic.message || diagnostic.code) : "";
}

function legacySourceRefs(value) {
  return splitSourceIds(value).map((sourceId) => `source-id:${sourceId}`);
}

function splitSourceIds(value) {
  return String(value || "").split(",").map((item) => item.trim()).filter(Boolean);
}

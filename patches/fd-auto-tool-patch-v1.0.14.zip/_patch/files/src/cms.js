﻿import fs from "node:fs/promises";
import path from "node:path";
import { askChoice } from "./utils.js";

const T = {
  today: "\u4eca\u5929",
  tomorrow: "\u660e\u5929",
  dayAfterTomorrow: "\u540e\u5929",
  plus3: "+3\u5929",
  plus4: "+4\u5929",
  useRole: "\u4f7f\u7528\u89d2\u8272",
  selectRole: "\u8bf7\u9009\u62e9\u89d2\u8272",
  changeRobot: "\u66f4\u6362\u673a\u5668\u4eba",
  sendTime: "\u53d1\u9001\u65f6\u95f4",
  anyTime: "\u4efb\u610f\u65f6\u95f4\u70b9",
  ok: "\u786e\u5b9a",
  text: "\u6587\u672c",
  image: "\u56fe\u7247",
  video: "\u89c6\u9891",
  sticker: "\u52a8\u6001\u8868\u60c5",
  scheduleSend: "\u5b9a\u65f6\u53d1\u9001",
  switchEditor: "\u5207\u6362\u4e3a\u65b0\u7248\u7f16\u8f91\u5668",
  textPlaceholder: "\u8bf7\u8f93\u5165\u6587\u5b57",
  upload: "\u70b9\u51fb\u4e0a\u4f20",
  customSticker: "\u81ea\u5b9a\u4e49\u8868\u60c5\u5305",
  pasteImage: "\u7c98\u8d34\u56fe\u7247",
  execute: "\u6267\u884c\u53d1\u9001",
  confirmCreate: "\u786e\u8ba4\u521b\u5efa",
  cancel: "\u53d6\u6d88",
  confirmUpload: "\u786e\u8ba4\u4e0a\u4f20",
  yes: "\u662f",
  noContent: "\u8bf7\u81f3\u5c11\u8f93\u5165\u4e00\u6761\u6d88\u606f\u5185\u5bb9",
  taskCreated: "\u4efb\u52a1\u521b\u5efa\u6210\u529f",
  created: "\u521b\u5efa\u6210\u529f",
  expiredTime: "\u5df2\u7ecf\u8fc7\u4e86",
  switchImmediate: "\u662f\u5426\u5207\u6362\u4e3a\u7acb\u5373\u6267\u884c",
  ready: "\u6781\u901f\u5c31\u7eea",
  preparing: "\u6781\u901f\u51c6\u5907\u4e2d",
  notReady: "\u672a\u5c31\u7eea",
  notPrepared: "\u672a\u51c6\u5907",
  loading: "\u52a0\u8f7d\u4e2d",
  processing: "\u5904\u7406\u4e2d",
  preview: "\u9884\u89c8",
  choose: "\u8bf7\u9009\u62e9",
  empty: "\u4e0d\u80fd\u4e3a\u7a7a"
};

let showVisualHelper = false;

export async function prepareCmsPages(context, config) {
  showVisualHelper = Boolean(config.showVisualHelper);
  const pages = context.pages();
  const cmsPages = pages.filter((page) => page.url().includes("cms.iyunzk.com/wx/FenWei_rw"));
  while (cmsPages.length < 2) {
    const page = await context.newPage();
    await page.goto(config.cmsUrl, { waitUntil: "domcontentloaded" });
    cmsPages.push(page);
  }

  for (const page of cmsPages) await installVirtualMouse(page);

  if (config.waitForManualSetup) {
    let didRestoreCmsPageMemory = false;
    const memory = await loadCmsPageMemory(config);
    if (hasCmsPageMemory(memory) && config.promptRestoreCmsPageMemory !== false) {
      const restoreAction = await askCmsRestoreChoice(config);
      if (restoreAction === "back") {
        config.__cmsSetupAction = "monitor";
        return { tuo: cmsPages[0], douma: cmsPages[1] };
      }
      let restoreSummaries = [];
      if (restoreAction === "restore") {
        didRestoreCmsPageMemory = true;
        console.log("\n正在恢复上次云中客页面选择...");
        restoreSummaries = [
          await restoreCmsPageMemory(cmsPages[0], memory.tuo, "托页面"),
          await restoreCmsPageMemory(cmsPages[1], memory.douma, "豆妈页面")
        ];
        const missingTotal = restoreSummaries.reduce((sum, item) => sum + (item?.missing?.length || 0), 0);
        if (missingTotal) {
          console.log(`恢复上次选择不完整：还有 ${missingTotal} 项没找到。请先检查页面，必要时手动补选。`);
        } else {
          console.log("上次云中客页面选择已恢复，请再看一眼页面。");
        }
      } else {
        console.log("本次选择不恢复上次设置，程序不会自动点击群、机器人、角色或多快捷；请你手动选好。");
      }
    } else {
      console.log("还没有保存过上次云中客页面选择，本次请手动选好。");
    }

    console.log("\n请在打开的两个云中客页面里手动确认：");
    console.log("1. 第一个页面选好【托】的群和机器人");
    console.log("2. 第二个页面选好【豆妈】的群和机器人");
    console.log("3. 两个页面都停留在创建任务页面");
    config.__cmsSetupAction = await askCmsSetupAction(config);
    if (didRestoreCmsPageMemory && config.__cmsSetupAction !== "monitor") {
      await saveCmsPageMemory(cmsPages, config);
    }
  }

  return { tuo: cmsPages[0], douma: cmsPages[1] };
}

async function askCmsRestoreChoice(config) {
  if (config.__runControl?.waitForCmsRestoreChoice) {
    console.log("请在妙券自动发单🚀控制台选择是否恢复上次云中客页面选择。");
    return await config.__runControl.waitForCmsRestoreChoice();
  }
  return await askChoice(
    "检测到上次云中客页面选择，是否恢复？",
    [
      { key: "1", label: "恢复上次托/豆妈勾选和任务备注", value: "restore" },
      { key: "2", label: "不恢复，我这次手动选", value: "manual" },
      { key: "0", label: "返回上一步", value: "back" }
    ],
    "1"
  );
}

async function askCmsSetupAction(config) {
  if (config.__runControl?.waitForCmsSetupAction) {
    console.log("请在妙券自动发单🚀控制台确认云中客页面准备情况。");
    return await config.__runControl.waitForCmsSetupAction();
  }
  return await askChoice(
    "发单页面准备好后，请选择下一步",
    [
      { key: "1", label: "继续执行当前预览", value: "continue" },
      { key: "2", label: "重新按当前时间生成预览再执行", value: "refresh" },
      { key: "3", label: "回到监控，不执行", value: "monitor" }
    ],
    "1"
  );
}

export async function createCmsTasks(pages, tasks, config, control) {
  let lastTuoKey = "";
  let currentFixedRoleName = "";
  const fixedRoleUsage = await loadRoleUsage(config);
  const results = [];
  config.__latestTaskResults = results;
  const progress = await loadProgress(config);
  const completed = new Set(progress.completed || []);
  const selectedDateByRole = { tuo: null, douma: null };
  const confirmNotInGroupRobotGroups = new Set();
  const allowRuntimeTimeAdjust = config.scheduleMode === "realtime" || config.scheduleMode === "catchup";
  let runtimeBaseAbs = null;
  let foregroundPage = null;

  for (const [index, task] of tasks.entries()) {
    const key = taskKey(task, index);
    await checkpointControl(control, `${index + 1}/${tasks.length}：准备`);
    if (completed.has(key)) {
      if (task.role === "tuo") lastTuoKey = tuoRobotKey(task);
      results.push({ index, task, result: { ok: true, skippedCompleted: true, message: "Already completed in previous run" } });
      console.log(`已跳过已完成任务：${task.role} / ${task.speaker} / ${task.time} / ${task.type}`);
      continue;
    }

    const page = task.role === "douma" ? pages.douma : pages.tuo;
    await checkpointControl(control, `${index + 1}/${tasks.length}：切换页面`);
    if (foregroundPage !== page) {
      await page.bringToFront().catch(() => {});
      foregroundPage = page;
    }
    await installVirtualMouse(page);
    const title = `${index + 1}/${tasks.length}：${task.role} / ${task.speaker} / ${task.time} / ${task.type}`;
    await control?.checkpoint(title);
    await setStep(page, title);
    console.log(`\n创建任务：${task.role} / ${task.speaker} / ${task.time} / ${task.type}`);

    const currentTuoKey = tuoRobotKey(task);
    if (task.role === "tuo" && config.roles?.tuo?.changeRobotOnSpeakerChange) {
      const needsRobotChange = !lastTuoKey || currentTuoKey !== lastTuoKey;
      if (needsRobotChange && config.tuoMode === "fixed") {
        console.log(`选择固定托角色后更换机器人：${currentTuoKey}`);
        currentFixedRoleName = await selectFixedTuoRoleFromHistory(page, config, fixedRoleUsage, currentFixedRoleName);
        await clickChangeRobot(page);
        lastTuoKey = currentTuoKey;
      } else if (!lastTuoKey) {
        lastTuoKey = currentTuoKey;
      } else if (currentTuoKey !== lastTuoKey) {
        console.log(`更换机器人：${lastTuoKey} -> ${currentTuoKey}`);
        await clickChangeRobot(page);
        lastTuoKey = currentTuoKey;
      }
      if (config.tuoMode === "fixed" && currentFixedRoleName) task.fixedRoleName = currentFixedRoleName;
    }

    await checkpointControl(control, `${index + 1}/${tasks.length}：设置时间`);
    await setStep(page, "设置定时时间");
    if (allowRuntimeTimeAdjust && runtimeBaseAbs !== null) {
      const nextAbs = runtimeBaseAbs + runtimeGapSeconds(tasks[index - 1], task, config);
      if (taskAbsoluteSeconds(task) <= nextAbs) {
        task.originalTime = task.originalTime || task.time;
        applyRuntimeSchedule(task, nextAbs);
        console.log(`运行中修正时间：${task.originalTime} -> ${task.time}`);
      }
    }
    const rolePageKey = task.role === "douma" ? "douma" : "tuo";
    const scheduleDate = taskScheduleDateFixed(task, config);
    await checkpointControl(control, `${index + 1}/${tasks.length}：写入时间`);
    await setTimeFast(page, task.time, scheduleDate, selectedDateByRole[rolePageKey]);
    selectedDateByRole[rolePageKey] = scheduleDate.key;
    await waitWithControl(page, 700, control, `${index + 1}/${tasks.length}：时间已设置`);
    await closePopups(page);

    await checkpointControl(control, `${index + 1}/${tasks.length}：填写内容`);
    await validatePreviewPayloadForCreate(task, index);
    console.log(`创建前校验：第 ${index + 1} 条 / ${task.type} / ${previewPayloadSummary(task)}`);
    if (task.type === "text") {
      await fillTextMessage(page, task.text, config, { index });
    } else if (task.type === "image") {
      if (!task.imagePath) throw new Error(`图片文件缺失：${task.speaker} ${task.time}`);
      await fillMediaMessage(page, task.imagePath, T.image, mediaReadyOptions(config, control, `${index + 1}/${tasks.length}`));
    } else if (task.type === "sticker") {
      if (!task.imagePath) throw new Error(`表情包文件缺失：${task.speaker} ${task.time}`);
      await fillMediaMessage(page, task.imagePath, T.sticker, mediaReadyOptions(config, control, `${index + 1}/${tasks.length}`));
    } else if (task.type === "video") {
      if (!task.imagePath) throw new Error(`视频文件缺失：${task.speaker} ${task.time}`);
      await fillMediaMessage(page, task.imagePath, T.video, mediaReadyOptions(config, control, `${index + 1}/${tasks.length}`));
    }

    await checkpointControl(control, `${index + 1}/${tasks.length}：执行创建`);
    if (isMediaTask(task)) {
      await setStep(page, "等待素材就绪");
      await waitForUploadReady(page, mediaReadyTimeoutMs(config), mediaReadyOptions(config, control, `${index + 1}/${tasks.length}`));
    }
    await checkpointControl(control, `${index + 1}/${tasks.length}：准备执行发送`);
    await setStep(page, "执行发送");
    let result = await executeAndConfirm(page, configForTask(config, task, confirmNotInGroupRobotGroups), control, `${index + 1}/${tasks.length}`);
    if (result.retryWithNewFixedRole && task.role === "tuo" && config.tuoMode === "fixed") {
      console.log("固定托机器人不在群，正在换角色后重试。");
      await checkpointControl(control, `${index + 1}/${tasks.length}：换固定托角色`);
      currentFixedRoleName = await selectFixedTuoRoleFromHistory(page, config, fixedRoleUsage, currentFixedRoleName);
      await clickChangeRobot(page);
      if (currentFixedRoleName) task.fixedRoleName = currentFixedRoleName;
      await checkpointControl(control, `${index + 1}/${tasks.length}：重试执行创建`);
      result = await executeAndConfirm(page, config, control, `${index + 1}/${tasks.length}`);
    }
    const extraFixedRoleRetryLimit = Number(config.fixedRoleRetryLimit ?? 3) - 1;
    for (
      let retryIndex = 0;
      result.retryWithNewFixedRole && task.role === "tuo" && config.tuoMode === "fixed" && retryIndex < extraFixedRoleRetryLimit;
      retryIndex += 1
    ) {
      console.log(`固定托机器人不在群，正在换角色后重试（${retryIndex + 2}/${extraFixedRoleRetryLimit + 1}）。`);
      await checkpointControl(control, `${index + 1}/${tasks.length}：换固定托角色`);
      currentFixedRoleName = await selectFixedTuoRoleFromHistory(page, config, fixedRoleUsage, currentFixedRoleName);
      await clickChangeRobot(page);
      if (currentFixedRoleName) task.fixedRoleName = currentFixedRoleName;
      await checkpointControl(control, `${index + 1}/${tasks.length}：重试执行创建`);
      result = await executeAndConfirm(page, config, control, `${index + 1}/${tasks.length}`);
    }
    if (result.retryWithNewFixedRole) {
      throw new Error("固定托已达到重试次数，机器人仍不在群。");
    }
    const randomRobotRetryLimit = Number(config.randomRobotNotInGroupRetryLimit ?? 3);
    for (
      let retryIndex = 0;
      result.retryWithNewRandomRobot && task.role === "tuo" && config.tuoMode === "random" && retryIndex < randomRobotRetryLimit;
      retryIndex += 1
    ) {
      console.log(`随机托机器人不在群，正在更换机器人后重试（${retryIndex + 1}/${randomRobotRetryLimit}）。`);
      await checkpointControl(control, `${index + 1}/${tasks.length}：更换机器人`);
      await clickChangeRobot(page);
      await checkpointControl(control, `${index + 1}/${tasks.length}：重试执行创建`);
      result = await executeAndConfirm(page, configForTask(config, task, confirmNotInGroupRobotGroups), control, `${index + 1}/${tasks.length}`);
    }
    if (result.retryWithNewRandomRobot) {
      result = await handleRandomRobotRetryLimit(page, config, task, confirmNotInGroupRobotGroups, control, `${index + 1}/${tasks.length}`);
      if (result.retryWithNewRandomRobot) {
          throw new Error("随机托已达到重试次数，机器人仍不在群。");
      }
    }
    if (result.skipped) {
      results.push({ index, task, result });
      console.log(`已跳过：${task.role} / ${task.speaker} / ${task.time} / ${task.type} / ${result.message || ""}`);
      completed.add(key);
      await saveProgress(config, {
        updatedAt: new Date().toISOString(),
        completed: Array.from(completed)
      });
      await control?.checkpoint(`${index + 1}/${tasks.length}：已跳过`);
      continue;
    }
    results.push({ index, task, result });
    if (allowRuntimeTimeAdjust) {
      if (result.immediate) runtimeBaseAbs = currentRuntimeAbsoluteSeconds();
      else if (runtimeBaseAbs !== null) runtimeBaseAbs = taskAbsoluteSeconds(task);
    }
    console.log(`创建成功：${task.role} / ${task.speaker} / ${task.time} / ${task.type}`);
    if (config.tuoMode === "fixed" && task.role === "tuo") {
      const usage = roleUsageRow(task, index);
      await appendRoleUsage(config, usage);
      fixedRoleUsage.push(usage);
    }

    completed.add(key);
    await saveProgress(config, {
      updatedAt: new Date().toISOString(),
      completed: Array.from(completed)
    });
    await control?.checkpoint(`${index + 1}/${tasks.length}: done`);
  }

  await clearProgress(config);
  return results;
}

export async function checkCmsTaskList(context, config, tasks, results = []) {
  const page = await context.newPage();
  await installVirtualMouse(page);
  const url = cmsTaskListUrl(config);
  await page.goto(url, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(Number(config.taskListCheckInitialWaitMs || 2500));
  await page.bringToFront().catch(() => {});

  const rows = await collectTaskListRows(page);
  const checks = buildTaskListChecks(tasks, results, rows, config);
  return buildTaskListReport(url, rows, checks);
}

function cmsTaskListUrl(config) {
  const configured = String(config.cmsJobListUrl || config.taskListUrl || "").trim();
  if (configured) return configured;
  const base = String(config.cmsUrl || "https://cms.iyunzk.com/wx/FenWei_rw").trim();
  if (/\/joblist(?:$|\?)/.test(base)) return base;
  return `${base.replace(/\/$/, "")}/joblist`;
}

async function collectTaskListRows(page) {
  const byText = new Map();
  for (let i = 0; i < 5; i += 1) {
    const batch = await page.evaluate(() => {
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
      };
      const rowSelectors = [
        ".el-table__body-wrapper tbody tr",
        ".el-table__row",
        "tbody tr"
      ];
      const found = [];
      for (const selector of rowSelectors) {
        for (const row of Array.from(document.querySelectorAll(selector))) {
          if (!visible(row)) continue;
          const cells = Array.from(row.querySelectorAll("td")).map((td) => String(td.innerText || td.textContent || "").trim());
          const text = String(row.innerText || row.textContent || "").trim();
          if (!text || !cells.length) continue;
          found.push({ text, cells });
        }
        if (found.length) break;
      }
      return found;
    }).catch(() => []);
    for (const row of batch) {
      const key = compact(row.text);
      if (key && !byText.has(key)) byText.set(key, row);
    }
    await page.mouse.wheel(0, 900).catch(() => {});
    await page.waitForTimeout(400);
  }
  return Array.from(byText.values()).map((row, index) => ({ index, ...row }));
}

function buildTaskListChecks(tasks, results, rows, config) {
  const expected = expectedTaskIndexes(tasks, results);
  return tasks
    .map((task, index) => ({ task, index }))
    .filter(({ index }) => expected.has(index))
    .map(({ task, index }) => checkOneTaskInList(task, index, rows, config));
}

function expectedTaskIndexes(tasks, results) {
  const indexes = new Set();
  for (const item of results || []) {
    const result = item?.result;
    if (!result?.ok || result?.skipped) continue;
    const index = Number.isInteger(item.index) ? item.index : findTaskIndexForCheck(tasks, item.task);
    if (index >= 0) indexes.add(index);
  }
  if (!indexes.size) {
    for (let index = 0; index < tasks.length; index += 1) indexes.add(index);
  }
  return indexes;
}

function findTaskIndexForCheck(tasks, resultTask) {
  if (!resultTask) return -1;
  return tasks.findIndex((task) =>
    task.role === resultTask.role &&
    task.speaker === resultTask.speaker &&
    task.time === resultTask.time &&
    task.type === resultTask.type &&
    (task.scheduleDateKey || "") === (resultTask.scheduleDateKey || "")
  );
}

function checkOneTaskInList(task, index, rows, config) {
  const label = taskListLabel(task, index);
  const exactRows = rows.filter((row) => rowMatchesTaskListTask(row, task, config, { requireDate: true, requireTime: true }));
  if (exactRows.length) {
    return {
      index,
      task,
      label,
      status: "已匹配",
      matchedRows: exactRows,
      message: exactRows.length > 1 ? `找到 ${exactRows.length} 行，可能是多群正常拆分` : ""
    };
  }

  const contentRows = rows.filter((row) => rowMatchesTaskListContent(row, task));
  if (contentRows.length) {
    return {
      index,
      task,
      label,
      status: "疑似错定",
      matchedRows: contentRows,
      message: "找到相似内容，但日期或时间没有对上"
    };
  }

  const timeRows = rows.filter((row) => rowHasTaskDate(row, task, config) && rowHasTaskTime(row, task));
  if (timeRows.length) {
    return {
      index,
      task,
      label,
      status: "需要人工确认",
      matchedRows: timeRows,
      message: "日期时间对上，但内容摘要没明显对上"
    };
  }

  return {
    index,
    task,
    label,
    status: "疑似漏定",
    matchedRows: [],
    message: "任务列表里没有找到对应日期时间和内容"
  };
}

function rowMatchesTaskListTask(row, task, config, options = {}) {
  if (options.requireDate && !rowHasTaskDate(row, task, config)) return false;
  if (options.requireTime && !rowHasTaskTime(row, task)) return false;
  return rowMatchesTaskListContent(row, task);
}

function rowMatchesTaskListContent(row, task) {
  const text = compact(row.text);
  if (!text) return false;
  if (task.type === "image") return text.includes("图片") || text.includes("图");
  if (task.type === "sticker") return text.includes("动态表情") || text.includes("表情");
  if (task.type === "video") return text.includes("视频");
  const needle = compact(task.text || "").slice(0, 18);
  if (needle.length >= 6 && text.includes(needle)) return true;
  const shortNeedle = compact(task.text || "").slice(0, 10);
  return shortNeedle.length >= 6 && text.includes(shortNeedle);
}

function rowHasTaskTime(row, task) {
  const time = String(task.time || "");
  const hm = time.match(/^(\d{1,2}):(\d{2})/);
  if (!hm) return false;
  const text = row.text || "";
  return text.includes(time) || text.includes(`${hm[1].padStart(2, "0")}:${hm[2]}`) || text.includes(`${Number(hm[1])}:${hm[2]}`);
}

function rowHasTaskDate(row, task, config) {
  const date = taskListDateStrings(task, config);
  if (!date.length) return true;
  const text = row.text || "";
  return date.some((item) => text.includes(item));
}

function taskListDateStrings(task, config) {
  const schedule = taskScheduleDateFixed(task, config || {});
  const date = new Date();
  date.setDate(date.getDate() + Number(schedule.offset || 0));
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  return [
    `${yyyy}-${mm}-${dd}`,
    `${Number(mm)}/${Number(dd)}`,
    `${Number(mm)}月${Number(dd)}日`
  ];
}

function taskListLabel(task, index) {
  const date = task.scheduleDateLabel || task.scheduleDateKey || "今天";
  return `${index + 1}. ${task.role || ""} / ${task.speaker || ""} / ${date} ${task.time || ""} / ${task.type || ""} / ${taskListSummary(task)}`;
}

function taskListSummary(task) {
  if (task.text) return String(task.text).replace(/\s+/g, " ").trim().slice(0, 60);
  if (task.type === "sticker") return "表情包";
  if (task.type === "image") return "图片";
  if (task.type === "video") return "视频";
  return "";
}

function buildTaskListReport(url, rows, checks) {
  const matchedRows = checks.filter((row) => row.status === "已匹配");
  const missingRows = checks.filter((row) => row.status === "疑似漏定");
  const wrongRows = checks.filter((row) => row.status === "疑似错定");
  const uncertainRows = checks.filter((row) => row.status === "需要人工确认");
  const problemRows = [...missingRows, ...wrongRows, ...uncertainRows];

  const lines = [];
  lines.push("任务列表检查");
  lines.push(`生成时间：${new Date().toLocaleString()}`);
  lines.push(`任务列表：${url}`);
  lines.push(`读取到任务列表可见行：${rows.length} 行`);
  lines.push("");
  lines.push(`已匹配：${matchedRows.length} 条`);
  lines.push(`疑似漏定：${missingRows.length} 条`);
  lines.push(`疑似错定：${wrongRows.length} 条`);
  lines.push(`需要人工确认：${uncertainRows.length} 条`);
  lines.push("");

  if (problemRows.length) {
    lines.push("需要重点检查：");
    for (const row of problemRows) {
      lines.push(`- ${row.status}：${row.label}${row.message ? ` / ${row.message}` : ""}`);
      for (const matched of row.matchedRows.slice(0, 2)) lines.push(`  匹配行：${compactTaskListRow(matched.text)}`);
    }
    lines.push("");
  } else {
    lines.push("检查结果：没有发现明显漏定或错定。");
    lines.push("");
  }

  lines.push("全部检查明细：");
  for (const row of checks) {
    lines.push(`- ${row.status}：${row.label}${row.message ? ` / ${row.message}` : ""}`);
  }

  const csvRows = [
    ["序号", "状态", "角色", "说话人", "日期", "时间", "类型", "内容摘要", "说明", "匹配行数量"],
    ...checks.map((row) => [
      String(row.index + 1),
      row.status,
      row.task.role || "",
      row.task.speaker || "",
      row.task.scheduleDateLabel || row.task.scheduleDateKey || "今天",
      row.task.time || "",
      row.task.type || "",
      taskListSummary(row.task),
      row.message || "",
      String(row.matchedRows.length)
    ])
  ];

  return {
    text: `${lines.join("\n")}\n`,
    csv: `${csvRows.map((row) => row.map(csvEscape).join(",")).join("\n")}\n`,
    matchedRows,
    missingRows,
    wrongRows,
    uncertainRows,
    problemRows
  };
}

function compactTaskListRow(text) {
  return String(text || "").replace(/\s+/g, " ").trim().slice(0, 180);
}

function mediaReadyOptions(config, control = null, progressLabel = "") {
  return {
    retryWhenNotReady: true,
    requireReadyText: true,
    timeoutMs: mediaReadyTimeoutMs(config),
    control,
    progressLabel
  };
}

function mediaReadyTimeoutMs(config) {
  return Math.max(45000, Number(config.mediaReadyTimeoutMs || 90000));
}

function runtimeCustomIntervalsEnabled(config = {}) {
  const mode = config.scheduleMode || "doc";
  return mode === "realtime" || mode === "catchup";
}

function runtimeIntervalNumberOrNull(value) {
  if (value === "" || value === undefined || value === null) return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function runtimeCustomIntervalSeconds(config = {}, key, minimum = 0) {
  if (!runtimeCustomIntervalsEnabled(config)) return null;
  const item = config.customIntervals?.[key];
  if (!item || typeof item !== "object") return null;
  let min = runtimeIntervalNumberOrNull(item.min);
  let max = runtimeIntervalNumberOrNull(item.max);
  if (min === null && max === null) return null;
  if (min === null) min = max;
  if (max === null) max = min;
  min = Math.max(minimum, Math.max(0, Math.round(min)));
  max = Math.max(minimum, Math.max(0, Math.round(max)));
  if (max < min) [min, max] = [max, min];
  return Math.round((min + max) / 2);
}

function runtimeRoleSwitchGapSeconds(config = {}) {
  const configured = Number(config.realtimeRoleSwitchGapSeconds ?? 120);
  const base = Math.max(120, Number.isFinite(configured) ? configured : 120);
  return runtimeCustomIntervalSeconds(config, "roleSwitch", 120) ?? base;
}

function runtimeGapKey(prev, next) {
  if (!prev || !next) return "";
  if (prev.role !== next.role) return "roleSwitch";
  if (prev.role === "douma" && next.role === "douma") return "doumaSame";
  if (prev.role === "tuo" && next.role === "tuo") {
    return prev.speaker === next.speaker ? "sameTuo" : "differentTuo";
  }
  return prev.speaker === next.speaker ? "sameTuo" : "differentTuo";
}

function withCustomRuntimeGap(defaultGap, prev, next, config = {}) {
  const key = runtimeGapKey(prev, next);
  if (!key) return defaultGap;
  const custom = runtimeCustomIntervalSeconds(config, key, key === "roleSwitch" ? 120 : 0);
  return custom === null ? defaultGap : custom;
}

function runtimeGapSeconds(prev, next, config) {
  if (!prev || !next) return 0;
  if (prev.role !== next.role) return runtimeRoleSwitchGapSeconds(config);
  let gap;
  if (isMediaTask(prev) || isMediaTask(next)) {
    gap = prev.speaker === next.speaker ? 50 : 45;
  } else if (prev.speaker === next.speaker) {
    gap = normalSpacingSeconds(next);
  } else {
    gap = Math.max(15, Number(config.minOtherSpeakerGapSeconds ?? 15));
  }
  return withCustomRuntimeGap(gap, prev, next, config);
}

function normalSpacingSeconds(task) {
  if (task.type === "image" || task.type === "sticker" || task.type === "video") return 30;
  const len = String(task.text || "").replace(/\s+/g, "").length;
  if (len <= 20) return 20;
  if (len <= 60) return 30;
  return 45;
}

function currentRuntimeAbsoluteSeconds() {
  const now = new Date();
  return now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
}

function taskAbsoluteSeconds(task) {
  return Number(task.scheduleDateOffset || 0) * 86400 + timeToSeconds(task.time);
}

function timeToSeconds(time) {
  const [h, m, s] = String(time || "00:00:00").split(":").map(Number);
  return (h || 0) * 3600 + (m || 0) * 60 + (s || 0);
}

function secondsToTime(total) {
  const sec = ((Math.round(total) % 86400) + 86400) % 86400;
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(Math.floor(sec / 3600))}:${pad(Math.floor((sec % 3600) / 60))}:${pad(sec % 60)}`;
}

function applyRuntimeSchedule(task, absoluteSeconds) {
  const dayOffset = Math.floor(absoluteSeconds / 86400);
  task.time = secondsToTime(absoluteSeconds);
  task.scheduleDateOffset = dayOffset;
  if (dayOffset === 0) {
    task.scheduleDateKey = "today";
    task.scheduleDateLabel = "";
    return;
  }
  const date = new Date();
  date.setDate(date.getDate() + dayOffset);
  task.scheduleDateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  task.scheduleDateLabel = `${date.getMonth() + 1}/${date.getDate()}`;
}

async function setTimeFast(page, time, scheduleDate, currentDateKey) {
  await closePopups(page);

  if (scheduleDate.key !== currentDateKey) {
    await selectScheduleDate(page, scheduleDate);
    await closePopups(page);
  }

  const timeInput = await findTimeInput(page);
  await moveToLocator(page, timeInput, `time ${time}`);
  await fillScheduleTime(page, timeInput, time);
  await page.keyboard.press("Tab").catch(() => {});
  await closePopups(page);

  const value = await timeInput.inputValue().catch(() => "");
  if (value !== time) throw new Error(`定时时间没有设置成功：应该是 ${time}，当前是 ${value || "空"}`);
  console.log(`设置时间：${time}`);
}

async function fillScheduleTime(page, locator, value) {
  await locator.scrollIntoViewIfNeeded({ timeout: 5000 }).catch(() => {});
  await locator.click({ timeout: 3000, force: true }).catch(() => {});
  await page.waitForTimeout(180);
  await page.keyboard.press(process.platform === "darwin" ? "Meta+A" : "Control+A").catch(() => {});
  await page.keyboard.press("Backspace").catch(() => {});
  await page.keyboard.type(value, { delay: 12 }).catch(async () => {
    await setNativeInputValue(locator, value);
  });
  await page.keyboard.press("Enter").catch(() => {});
  await clickTimePickerOk(page);
  await page.waitForTimeout(500);

  let current = await locator.inputValue().catch(() => "");
  if (current !== value) {
    await setNativeInputValue(locator, value);
    await page.keyboard.press("Enter").catch(() => {});
    await clickTimePickerOk(page);
    await page.waitForTimeout(250);
    current = await locator.inputValue().catch(() => "");
  }
  if (current !== value) throw new Error(`无法填写定时时间：应该是 ${value}，当前是 ${current || "空"}`);
}

async function setNativeInputValue(locator, value) {
  await locator.evaluate((el, nextValue) => {
    el.removeAttribute("readonly");
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (!setter) return false;
    el.focus();
    setter.call(el, nextValue);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur?.();
    return true;
  }, value);
}

async function clickTimePickerOk(page) {
  const point = await page.evaluate((T) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const panels = Array.from(document.querySelectorAll(".el-time-panel, .el-picker-panel, .el-date-picker"))
      .filter(visible);
    for (const panel of panels) {
      const buttons = Array.from(panel.querySelectorAll("button,span,a"))
        .filter((el) => visible(el) && normalize(el.innerText || el.textContent) === normalize(T.ok));
      const button = buttons[buttons.length - 1];
      if (button) {
        const r = button.getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      }
    }
    return null;
  }, T).catch(() => null);
  if (!point) return false;
  await page.mouse.click(point.x, point.y);
  return true;
}

function taskScheduleDate(task, config) {
  if (task.scheduleDateKey) {
    return {
      key: task.scheduleDateKey,
      offset: Number(task.scheduleDateOffset || 0),
      label: task.scheduleDateLabel || ""
    };
  }
  if (config.dateMode === "tomorrow") return { key: "tomorrow", offset: 1, label: "鏄庡ぉ" };
  return { key: "today", offset: 0, label: "" };
}

async function selectScheduleDate(page, scheduleDate) {
  const label = scheduleDateOptionText(scheduleDate.offset);
  if (!label) throw new Error(`Schedule date is outside supported CMS range: ${scheduleDate.label || scheduleDate.offset}`);
  const day = scheduleDateDay(scheduleDate);
  if (!day) throw new Error(`Cannot calculate schedule day: ${scheduleDate.label || scheduleDate.key || scheduleDate.offset}`);
  const timeInput = await findTimeInput(page);
  await moveToLocator(page, timeInput, `date ${day}`);
  const opened = await openScheduleDateDropdownFixed(page, label);
  if (!opened) throw new Error("Cannot open schedule date dropdown");
  await page.waitForTimeout(400);
  const selected = await clickScheduleDateOptionByDaySafe(page, day);
  if (!selected) throw new Error(`Cannot select schedule date: ${day}`);
  await page.waitForTimeout(250);
  const verified = await verifySelectedScheduleDate(page, label);
  if (!verified) throw new Error(`Schedule date selected wrong option, expected label: ${label}`);
  await setStep(page, `select date ${day}`);
}

async function openScheduleDateDropdown(page, label) {
  const point = await page.evaluate((T) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const labels = Array.from(document.querySelectorAll("span,div,label"))
      .filter((el) => visible(el) && normalize(el.innerText || el.textContent).includes(normalize("\u5b9a\u65f6\u53d1\u9001")));
    const labelEl = labels.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top)[0];
    if (!labelEl) return null;
    const rowTop = labelEl.getBoundingClientRect().top - 18;
    const rowBottom = labelEl.getBoundingClientRect().bottom + 22;
    const rowLeft = labelEl.getBoundingClientRect().right;
    const candidates = Array.from(document.querySelectorAll("input,button,.el-select,.el-input,[class*='select']"))
      .filter((el) => visible(el))
      .map((el) => ({ el, r: el.getBoundingClientRect(), text: normalize(el.innerText || el.textContent || el.value || el.placeholder || "") }))
      .filter((item) => item.r.top >= rowTop && item.r.bottom <= rowBottom && item.r.left > rowLeft)
      .filter((item) => [T.today, T.tomorrow, T.dayAfterTomorrow, T.plus3, T.plus4].some((word) => item.text.includes(normalize(word))) || item.r.width >= 60);
    candidates.sort((a, b) => a.r.left - b.r.left);
    const target = candidates[0];
    if (!target) return null;
    return { x: target.r.left + target.r.width / 2, y: target.r.top + target.r.height / 2 };
  }, T).catch(() => null);
  if (!point) return false;
  await setStep(page, `open date ${label}`);
  await page.mouse.click(point.x, point.y);
  return true;
}

async function clickScheduleDateOption(page, label) {
  const point = await page.evaluate((label) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(label);
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const els = Array.from(document.querySelectorAll(".el-select-dropdown span,.el-select-dropdown li,li,span,div"))
      .filter((el) => visible(el) && normalize(el.innerText || el.textContent).includes(target));
    els.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      return ar.top - br.top || ar.left - br.left;
    });
    const el = els[0];
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }, label).catch(() => null);
  if (!point) return false;
  await setStep(page, `select date ${label}`);
  await page.mouse.click(point.x, point.y);
  return true;
}

async function clickScheduleDateOptionByOffset(page, offset, label) {
  const point = await page.evaluate(({ T, offset }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const words = [T.today, T.tomorrow, T.dayAfterTomorrow, T.plus3, T.plus4].map(normalize);
    const dropdowns = Array.from(document.querySelectorAll(".el-select-dropdown, .el-popper, [x-placement]"))
      .filter(visible)
      .map((root) => {
        const options = Array.from(root.querySelectorAll(".el-select-dropdown__item, li"))
          .filter(visible)
          .map((el) => {
            const r = el.getBoundingClientRect();
            const text = normalize(el.innerText || el.textContent || "");
            return { el, r, text };
          })
          .filter((item) => item.r.width > 20 && item.r.height > 10);
        const score = options.filter((item) => words.some((word) => item.text.includes(word))).length;
        return { root, options, score };
      })
      .filter((item) => item.options.length >= 5 && item.score >= 3)
      .sort((a, b) => b.score - a.score);
    const dropdown = dropdowns[0];
    if (!dropdown) return null;

    const dateOptions = dropdown.options
      .filter((item) => words.some((word) => item.text.includes(word)))
      .sort((a, b) => a.r.top - b.r.top || a.r.left - b.r.left);
    const target = dateOptions[offset];
    if (!target) return null;
    return { x: target.r.left + target.r.width / 2, y: target.r.top + target.r.height / 2 };
  }, { T, offset }).catch(() => null);
  if (!point) return false;
  await setStep(page, `select date ${label}`);
  await page.mouse.click(point.x, point.y);
  return true;
}

async function verifySelectedScheduleDate(page, label) {
  return page.evaluate(({ T, label }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const overlapY = (a, b) => Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const timeInput = Array.from(document.querySelectorAll("input"))
      .filter(visible)
      .find((el) => normalize(el.placeholder).includes(normalize(T.anyTime)) || /^\d{2}:\d{2}:\d{2}$/.test(el.value || ""));
    if (!timeInput) return false;
    const timeRect = timeInput.getBoundingClientRect();
    const expected = normalize(label);
    const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,span"))
      .filter(visible)
      .filter((el) => !el.closest(".el-select-dropdown,.el-popper,[x-placement]"))
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = normalize(el.innerText || el.textContent || el.value || "");
        return { r, text };
      })
      .filter((item) => {
        if (item.r.right > timeRect.left + 8) return false;
        if (item.r.left < timeRect.left - 260) return false;
        return overlapY(item.r, timeRect) >= Math.min(item.r.height, timeRect.height) * 0.45;
      });
    return candidates.some((item) => item.text.includes(expected));
  }, { T, label }).catch(() => false);
}

function scheduleDateDay(scheduleDate) {
  const keyMatch = String(scheduleDate?.key || "").match(/\d{4}-\d{2}-(\d{2})/);
  if (keyMatch) return Number(keyMatch[1]);
  const labelMatch = String(scheduleDate?.label || "").match(/\/(\d{1,2})$/);
  if (labelMatch) return Number(labelMatch[1]);
  const offset = Number(scheduleDate?.offset || 0);
  const date = new Date();
  date.setDate(date.getDate() + offset);
  return date.getDate();
}

async function clickScheduleDateOptionByDay(page, day) {
  const point = await page.evaluate(({ day }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const target = `${Number(day)}`;
    const dropdowns = Array.from(document.querySelectorAll(".el-select-dropdown, .el-popper, [x-placement]"))
      .filter(visible)
      .map((root) => {
        const options = Array.from(root.querySelectorAll(".el-select-dropdown__item, li, [role='option']"))
          .filter(visible)
          .map((el) => {
            const r = el.getBoundingClientRect();
            const text = normalize(el.innerText || el.textContent || "");
            return { el, r, text };
          })
          .filter((item) => item.r.width > 20 && item.r.height > 10 && item.text.length <= 16);
        const score = options.filter((item) => /(?:浠婂ぉ|鏄庡ぉ|鍚庡ぉ|\+\d+澶?\(\d{1,2}鍙穃)/.test(item.text)).length;
        return { options, score };
      })
      .filter((item) => item.score >= 2)
      .sort((a, b) => b.score - a.score);
    const dropdown = dropdowns[0];
    if (!dropdown) return null;
    const targetOption = dropdown.options
      .filter((item) => item.text.includes(target))
      .sort((a, b) => a.r.top - b.r.top || a.r.left - b.r.left)[0];
    if (!targetOption) return null;
    return {
      x: targetOption.r.left + targetOption.r.width / 2,
      y: targetOption.r.top + targetOption.r.height / 2,
      text: targetOption.text
    };
  }, { day }).catch(() => null);
  if (!point) return false;
  await setStep(page, `select date ${day}`);
  await page.mouse.click(point.x, point.y);
  return true;
}

async function verifySelectedScheduleDateDay(page, day) {
  return page.evaluate(({ T, day }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const overlapY = (a, b) => Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const timeInput = Array.from(document.querySelectorAll("input"))
      .filter(visible)
      .find((el) => normalize(el.placeholder).includes(normalize(T.anyTime)) || /^\d{2}:\d{2}:\d{2}$/.test(el.value || ""));
    if (!timeInput) return false;
    const timeRect = timeInput.getBoundingClientRect();
    const target = `${Number(day)}`;
    const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,span"))
      .filter(visible)
      .filter((el) => !el.closest(".el-select-dropdown,.el-popper,[x-placement]"))
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = normalize(el.innerText || el.textContent || el.value || "");
        return { r, text };
      })
      .filter((item) => {
        if (item.r.right > timeRect.left + 8) return false;
        if (item.r.left < timeRect.left - 260) return false;
        return overlapY(item.r, timeRect) >= Math.min(item.r.height, timeRect.height) * 0.45;
      });
    return candidates.some((item) => item.text.includes(target));
  }, { T, day }).catch(() => false);
}

async function clickScheduleDateOptionByDaySafe(page, day) {
  const point = await page.evaluate(({ day }) => {
    const expectedDay = Number(day);
    const dayToken = `${expectedDay}\u53f7`;
    const wrappedDayToken = `(${dayToken})`;
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const roots = Array.from(document.querySelectorAll(".el-select-dropdown, .el-popper, [x-placement]"))
      .filter(visible)
      .filter((root) => {
        const text = normalize(root.innerText || root.textContent || "");
        return text.includes("\u4eca\u5929") || text.includes("\u660e\u5929") || text.includes("\u540e\u5929") || text.includes(dayToken);
      });
    const searchRoots = roots;
    const candidates = searchRoots.flatMap((root) =>
      Array.from(root.querySelectorAll(".el-select-dropdown__item, li, [role='option'], span"))
        .filter(visible)
        .map((el) => {
          const r = el.getBoundingClientRect();
          const text = normalize(el.innerText || el.textContent || "");
          return { el, r, text };
        })
    )
      .filter((item) => item.r.width > 20 && item.r.height > 10)
      .filter((item) => item.text.length <= 20)
      .filter((item) => item.text.includes(wrappedDayToken) || item.text === dayToken)
      .sort((a, b) => a.r.top - b.r.top || a.r.left - b.r.left);
    const target = candidates[0];
    if (!target) return null;
    const clickable = target.el.closest(".el-select-dropdown__item, li, [role='option']") || target.el;
    const r = clickable.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2, text: target.text };
  }, { day }).catch(() => null);
  if (!point) return false;
  await setStep(page, `select date ${day}`);
  await page.mouse.click(point.x, point.y);
  console.log(`Click date option: ${point.text}`);
  return true;
}

function taskScheduleDateFixed(task, config) {
  if (task.scheduleDateKey) {
    return {
      key: task.scheduleDateKey,
      offset: Number(task.scheduleDateOffset || 0),
      label: task.scheduleDateLabel || ""
    };
  }
  if (config.dateMode === "tomorrow") return { key: "tomorrow", offset: 1, label: T.tomorrow };
  return { key: "today", offset: 0, label: "" };
}

async function openScheduleDateDropdownFixed(page, label) {
  const point = await page.evaluate((T) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const overlapY = (a, b) => Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const timeInput = Array.from(document.querySelectorAll("input"))
      .filter(visible)
      .find((el) => normalize(el.placeholder).includes(normalize(T.anyTime)) || /^\d{2}:\d{2}:\d{2}$/.test(el.value || ""));
    if (!timeInput) return null;

    const timeRect = timeInput.getBoundingClientRect();
    const dateWords = [
      T.today,
      T.tomorrow,
      T.dayAfterTomorrow,
      T.plus3,
      T.plus4,
      "+5\u5929",
      "+6\u5929",
      "+7\u5929"
    ].map(normalize);
    const candidates = Array.from(document.querySelectorAll(".el-select,.el-input,input,button,div"))
      .filter(visible)
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = normalize(el.innerText || el.textContent || el.value || el.placeholder || "");
        return { el, r, text };
      })
      .filter((item) => {
        if (item.r.right > timeRect.left + 8) return false;
        if (item.r.left < timeRect.left - 260) return false;
        if (overlapY(item.r, timeRect) < Math.min(item.r.height, timeRect.height) * 0.45) return false;
        return dateWords.some((word) => item.text.includes(word));
      })
      .sort((a, b) => b.r.right - a.r.right);
    const target = candidates[0];
    if (!target) return null;
    return { x: target.r.left + target.r.width / 2, y: target.r.top + target.r.height / 2 };
  }, T).catch(() => null);
  if (!point) return false;
  await setStep(page, `open date ${label}`);
  await page.mouse.click(point.x, point.y);
  return true;
}

function scheduleDateOptionText(offset) {
  if (offset === 0) return T.today;
  if (offset === 1) return T.tomorrow;
  if (offset === 2) return T.dayAfterTomorrow;
  if (offset >= 3 && offset <= 7) return `+${offset}\u5929`;
  return "";
}

async function findTimeInput(page) {
  const byPlaceholder = page.locator(`input[placeholder="${T.anyTime}"]:visible`).first();
  if (await byPlaceholder.count().catch(() => 0)) return byPlaceholder;

  const inputs = await page.locator("input").evaluateAll((els) =>
    els.map((el, index) => ({ index, value: el.value, placeholder: el.placeholder }))
  );
  const found = inputs.find((item) => /^\d{2}:\d{2}:\d{2}$/.test(item.value));
  if (!found) throw new Error("Cannot find schedule time input");
  return page.locator("input").nth(found.index);
}

async function closePopups(page) {
  await page.keyboard.press("Escape").catch(() => {});
  await page.keyboard.press("Escape").catch(() => {});
}

async function fillTextMessage(page, text, config, options = {}) {
  await clickMessageTab(page, T.text);
  await page.waitForTimeout(150);

  if (config.textInput?.preferNewEditor) {
    await clickText(page, T.switchEditor, "new editor", { optional: true });
    const editor = page.locator(".ql-editor:visible").first();
    if (await editor.count().catch(() => 0)) {
      await moveToLocator(page, editor, "fill text");
      await editor.click();
      await clearFocusedInput(page);
      await page.keyboard.insertText(text);
      await page.waitForTimeout(100);
      await verifyFilledText(page, editor, text, options);
      return;
    }
  }

  const textarea = page.locator(`textarea[placeholder*="${T.textPlaceholder}"]:visible`).first();
  await moveToLocator(page, textarea, "fill text");
  await textarea.click();
  await clearFocusedInput(page);
  await page.keyboard.insertText(text);
  await verifyFilledText(page, textarea, text, options);
}

async function clearFocusedInput(page) {
  await page.keyboard.press(process.platform === "darwin" ? "Meta+A" : "Control+A");
  await page.keyboard.press("Backspace");
}

async function verifyFilledText(page, locator, expectedText, options = {}) {
  const actual = await readFilledText(locator);
  if (textMatchesExpected(actual, expectedText)) return;

  const indexLabel = Number.isInteger(options.index) ? `第 ${options.index + 1} 条` : "当前文字任务";
  console.log(`${indexLabel}文字填入不完整，正在重新填入。`);
  await locator.click();
  await clearFocusedInput(page);
  await page.keyboard.insertText(expectedText);
  await page.waitForTimeout(150);
  const retryActual = await readFilledText(locator);
  if (textMatchesExpected(retryActual, expectedText)) return;

  console.log(`${indexLabel}普通输入仍不完整，正在使用剪贴板粘贴兜底。`);
  await pasteTextFallback(page, locator, expectedText);
  const pasteActual = await readFilledText(locator);
  if (textMatchesExpected(pasteActual, expectedText)) return;

  throw new Error(
    `${indexLabel}创建前填入校验失败：云中客输入框里的文字和预览不一致，已停止，避免漏发。` +
      ` 预览=${compactSummary(expectedText)}；页面=${compactSummary(pasteActual || retryActual)}`
  );
}

async function pasteTextFallback(page, locator, text) {
  await locator.click();
  await clearFocusedInput(page);
  try {
    await page.evaluate(async (value) => {
      await navigator.clipboard.writeText(value);
    }, text);
    await page.keyboard.press(process.platform === "darwin" ? "Meta+V" : "Control+V");
  } catch {
    await locator.evaluate((el, value) => {
      if ("value" in el) {
        el.value = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        el.textContent = value;
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
      }
    }, text);
  }
  await page.waitForTimeout(150);
}

async function readFilledText(locator) {
  try {
    const value = await locator.inputValue({ timeout: 500 });
    if (value !== undefined && value !== null) return value;
  } catch {}
  try {
    return await locator.innerText({ timeout: 500 });
  } catch {
    return "";
  }
}

async function fillMediaMessage(page, filePath, tabName, options = {}) {
  await checkpointControl(options.control, `${options.progressLabel || ""}：准备上传素材`);
  await closePopups(page);
  await clickMessageTab(page, tabName);
  await waitWithControl(page, 900, options.control, `${options.progressLabel || ""}：打开素材面板`);
  if (!(await waitForMediaPanel(page, tabName))) {
    await checkpointControl(options.control, `${options.progressLabel || ""}：重新打开素材面板`);
    await clickMessageTab(page, tabName);
    await waitWithControl(page, 900, options.control, `${options.progressLabel || ""}：等待素材面板`);
    await waitForMediaPanel(page, tabName);
  }

  await checkpointControl(options.control, `${options.progressLabel || ""}：上传素材`);
  await uploadFile(page, filePath, tabName);

  await checkpointControl(options.control, `${options.progressLabel || ""}：等待素材就绪`);
  await waitForUploadReady(page, options.timeoutMs || 45000, options);
}

async function waitForMediaPanel(page, tabName) {
  return page.waitForFunction(({ T, tabName }) => {
    const body = document.body.innerText || "";
    if (tabName === T.image) return body.includes(T.upload) || body.includes(T.pasteImage) || body.includes("\u5c06\u56fe\u7247\u62d6\u5230\u6b64\u5904");
    if (tabName === T.sticker) return body.includes(T.customSticker) || body.includes(T.upload);
    if (tabName === T.video) return body.includes(T.upload);
    return true;
  }, { T, tabName }, { timeout: 5000 }).then(() => true).catch(() => false);
}

async function clickMessageTab(page, tabName) {
  const loc = await findExactSmallTextLocator(page, tabName);
  if (loc) {
    await clickLocator(page, loc, `${tabName} tab`);
    return;
  }
  await clickText(page, tabName, `${tabName} tab`);
}

async function uploadFile(page, filePath, tabName) {
  const chooserPromise = page.waitForEvent("filechooser", { timeout: 6000 }).catch(() => null);
  await clickUploadBox(page, tabName);

  const chooser = await chooserPromise;
  if (chooser) {
    await chooser.setFiles(filePath);
    await confirmCompressedUpload(page);
    await waitForUploadStarted(page);
    return;
  }

  if (await setFileInput(page, filePath, { optional: true })) {
    await confirmCompressedUpload(page);
    await waitForUploadStarted(page);
    return;
  }
  await printUploadDebug(page);
  throw new Error("Cannot find upload input");
}

async function waitForUploadStarted(page) {
  const started = await page.waitForFunction((T) => {
    const body = document.body.innerText || "";
    return body.includes("KB") || body.includes("MB") || body.includes(T.ready) || body.includes(T.preparing) || body.includes(T.notReady);
  }, T, { timeout: 5000 }).then(() => true).catch(() => false);
  if (!started) console.log("Upload warning: file was selected, but CMS did not show upload status yet");
}

async function confirmCompressedUpload(page) {
  const hasDialog = await page.waitForFunction((T) => {
    const body = document.body.innerText || "";
    return body.includes(T.confirmUpload) || body.includes("\u538b\u7f29\u540e\u4e0a\u4f20");
  }, T, { timeout: 3000 }).then(() => true).catch(() => false);
  if (!hasDialog) return false;

  const button = await findDialogButtonLocator(page, T.confirmUpload);
  if (button) {
    await clickLocator(page, button, "confirm upload");
    await page.waitForTimeout(800);
    return true;
  }
  await clickText(page, T.confirmUpload, "confirm upload", { optional: true });
  await page.waitForTimeout(800);
  return true;
}

async function setFileInput(page, filePath) {
  for (const frame of page.frames()) {
    const inputs = frame.locator('input[type="file"]');
    const count = await inputs.count().catch(() => 0);
    for (let i = count - 1; i >= 0; i -= 1) {
      const input = inputs.nth(i);
      try {
        await input.setInputFiles(filePath, { timeout: 2000 });
        return true;
      } catch {
        // Try the next file input.
      }
    }
  }
  return false;
}

async function clickUploadBox(page, tabName) {
  const labels = tabName === T.sticker
    ? [T.upload, "\u7528\u4f01\u4e1a\u53f7\u62d6\u52a8\u52a8\u6001\u8868\u60c5\u5230\u6b64\u5904"]
    : tabName === T.video
      ? [T.upload, "\u5c06\u89c6\u9891\u62d6\u5230\u6b64\u5904", "\u89c6\u9891\u4e0a\u4f20"]
      : [T.upload, "\u5c06\u56fe\u7247\u62d6\u5230\u6b64\u5904", T.customSticker];
  for (const frame of page.frames()) {
    const locator = await findSmallTextLocatorInFrame(frame, labels);
    if (locator) {
      await clickLocator(page, locator, "open upload box");
      return true;
    }
  }

  for (const frame of page.frames()) {
    const boxes = [
      frame.locator(".el-upload").last(),
      frame.locator(".el-upload-dragger").last(),
      frame.locator("[class*='upload']").last()
    ];
    for (const box of boxes) {
      if (await box.count().catch(() => 0)) {
        await clickLocator(page, box, "open upload box");
        return true;
      }
    }
  }
  await printUploadDebug(page);
  throw new Error("Cannot find upload input");
}

async function printUploadDebug(page) {
  const info = await page.evaluate((T) => {
    const body = document.body.innerText || "";
    const words = [T.text, T.image, T.video, T.sticker, T.upload, T.pasteImage, T.customSticker, T.execute, T.anyTime];
    return words
      .filter((word) => body.includes(word))
      .join(" / ");
  }, T).catch(() => "");
  console.log(`Upload debug visible words: ${info || "(none)"}`);
}

async function findSmallTextLocatorInFrame(frame, labels) {
  const handle = await frame.evaluateHandle((labels) => {
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const score = (el) => {
      const r = el.getBoundingClientRect();
      return r.width * r.height;
    };
    const els = Array.from(document.querySelectorAll("a,button,span,div,label,p"));
    return els
      .filter((el) => visible(el) && labels.some((label) => (el.innerText || el.textContent || "").includes(label)))
      .sort((a, b) => score(a) - score(b))[0] || null;
  }, labels).catch(() => null);
  const element = handle?.asElement();
  return element || null;
}

async function waitForUploadReady(page, timeoutMs = 45000, options = {}) {
  const start = Date.now();
  let clickedNotReadyAt = 0;

  while (Date.now() - start < timeoutMs) {
    await checkpointControl(options.control, `${options.progressLabel || ""}：等待素材就绪`);
    const state = await uploadStateStrict(page, options);
    if (state.ready) {
      await waitWithControl(page, 300, options.control, `${options.progressLabel || ""}：素材已就绪`);
      return;
    }

    const canRetryClick = options.retryWhenNotReady && (state.notReady || state.hasMedia) && Date.now() - clickedNotReadyAt > 9000;
    if (canRetryClick) {
      clickedNotReadyAt = Date.now();
      await setStep(page, "click media once");
      await checkpointControl(options.control, `${options.progressLabel || ""}：点击素材检查就绪`);
      await clickNotReadyMaterialStrict(page);
      await setStep(page, "waiting media ready");
      await waitUntilReadyAfterClick(page, Math.min(10000, timeoutMs - (Date.now() - start)), options);
      continue;
    }

    await waitWithControl(page, 500, options.control, `${options.progressLabel || ""}：等待素材就绪`);
  }

  if (options.requireReadyText) {
    throw new Error("Media is not showing green ready text, so send was not executed");
  }
}

async function waitUntilReadyAfterClick(page, timeoutMs, options = {}) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    await waitWithControl(page, 500, options.control, `${options.progressLabel || ""}：等待素材就绪`);
    const state = await uploadStateStrict(page, options);
    if (state.ready) return true;
  }
  return false;
}

async function uploadStateStrict(page, options = {}) {
  return page.evaluate(({ T, requireReadyText }) => {
    const body = document.body.innerText || "";
    const ready = body.includes(T.ready);
    const notReady = [T.preparing, T.notReady, T.notPrepared, T.loading, T.processing]
      .some((text) => body.includes(text));
    const hasMedia = body.includes(T.preview) || body.includes("KB") || body.includes("MB");
    return {
      ready: requireReadyText ? ready : ready || hasMedia,
      notReady,
      hasMedia
    };
  }, { T, requireReadyText: Boolean(options.requireReadyText) }).catch(() => ({ ready: false, notReady: false, hasMedia: false }));
}

async function clickNotReadyMaterialStrict(page) {
  const label = await findAnyTextLocator(page, [T.preparing, T.notReady, T.notPrepared, T.loading, T.processing]);
  if (label) {
    await clickLocator(page, label, "click not-ready media");
    await page.waitForTimeout(500);
    return;
  }

  const point = await page.evaluate(() => {
    const visible = (el) => {
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const nodes = Array.from(document.querySelectorAll("div,span,p,a"))
      .filter((el) => visible(el) && /(?:KB|MB|预览|就绪|准备|棰勮|灏辩华|鍑嗗)/.test(el.innerText || el.textContent || ""));
    const node = nodes[nodes.length - 1];
    if (!node) return null;
    const rect = node.getBoundingClientRect();
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  }).catch(() => null);
  if (point) {
    await page.mouse.click(point.x, point.y);
    await page.waitForTimeout(500);
  }
}

async function executeAndConfirm(page, config, control = null, progressLabel = "") {
  await checkpointControl(control, `${progressLabel}：点击执行发送前`);
  await clickExecuteButton(page);
  const confirmDialogWaitMs = Math.max(1000, Number(config.confirmDialogWaitMs || 3000));
  let state = await waitForPostExecuteState(page, confirmDialogWaitMs);
  let immediate = state === "expiredTime";
  state = await handleExpiredTimeIfNeeded(page, state);

  for (let attempt = 0; state === "none" && attempt < 3; attempt += 1) {
    await waitWithControl(page, Math.min(1500, confirmDialogWaitMs), control, `${progressLabel}：等待确认弹窗`);
    await closePopups(page);
    await checkpointControl(control, `${progressLabel}：重试点击执行发送前`);
    await clickExecuteButton(page);
    state = await waitForPostExecuteState(page, Math.max(confirmDialogWaitMs, 5000));
    if (state === "expiredTime") immediate = true;
    state = await handleExpiredTimeIfNeeded(page, state);
  }

  const body = await page.locator("body").innerText();
  const hasConfirmCreate = body.includes(T.confirmCreate);
  if (body.includes(T.noContent)) throw new Error("CMS did not detect message content");
  if (body.includes(T.choose) || body.includes(T.empty)) throw new Error("CMS says a required option is missing");
  if ((body.includes(T.taskCreated) || body.includes(T.created)) && !hasConfirmCreate) return { ok: true, message: "Task created", immediate };
  if (!hasConfirmCreate) throw new Error("Confirm-create dialog did not appear");
  if (!config.ignoreRobotNotInGroup && config.tuoMode === "fixed" && hasRobotNotInGroupWarning(body)) {
    console.log("Fixed role robot not in group. Cancel and retry with another role.");
    await clickCancelCreateButton(page);
    return { ok: false, retryWithNewFixedRole: true, message: "Robot not in group" };
  }
  if (!config.ignoreRobotNotInGroup && config.tuoMode === "random" && hasRobotNotInGroupWarning(body)) {
    console.log("随机托机器人不在群，将更换机器人后重试。");
    await clickCancelCreateButton(page);
    return { ok: false, retryWithNewRandomRobot: true, message: "机器人不在群" };
  }

  if (!config.autoConfirmCreate) {
    console.log("请检查确认弹窗，并手动点击“确认创建”。");
    await waitForManualConfirmDone(page, config.manualConfirmTimeoutMs || 10 * 60 * 1000);
    return { ok: true, message: "已检测到手动确认", immediate };
  }

  await checkpointControl(control, `${progressLabel}：点击确认创建前`);
  await clickConfirmCreateButton(page);
  let created = await waitForCreateSuccess(page, 6000);
  if (!created) {
    await waitWithControl(page, 800, control, `${progressLabel}：等待创建结果`);
    await checkpointControl(control, `${progressLabel}：再次点击确认创建前`);
    await clickConfirmCreateButton(page);
    created = await waitForCreateSuccess(page, 10000);
  }
  if (!created) throw new Error("已点击确认创建，但没有检测到创建成功。");
  return { ok: true, message: "任务已创建", immediate };
}

function configForTask(config, task, confirmNotInGroupRobotGroups) {
  if (config.ignoreRobotNotInGroup) return config;
  if (
    config.tuoMode === "random" &&
    task?.role === "tuo" &&
    task.robotGroup !== undefined &&
    task.robotGroup !== null &&
    confirmNotInGroupRobotGroups.has(String(task.robotGroup))
  ) {
    return { ...config, ignoreRobotNotInGroup: true };
  }
  return config;
}

function shouldRememberConfirmForRobotGroup(task) {
  return (
    task?.role === "tuo" &&
    task.robotGroup !== undefined &&
    task.robotGroup !== null
  );
}

async function handleRandomRobotRetryLimit(page, config, task, confirmNotInGroupRobotGroups, control = null, progressLabel = "") {
  while (true) {
    await checkpointControl(control, `${progressLabel}：等待机器人不在群处理`);
    const action = await askChoice(
      "粗略版已自动更换机器人重试 3 次，还是显示不在群。请选择下一步：",
      [
        { key: "1", label: "继续更换机器人再试一次", value: "retry" },
        { key: "2", label: "不管不在群提示，直接确认创建", value: "confirm" },
        { key: "3", label: "跳过这条，继续下一条", value: "skip" },
        { key: "q", label: "停止运行", value: "stop" }
      ],
      "1"
    );

    if (action === "retry") {
      await checkpointControl(control, `${progressLabel}：更换机器人`);
      await clickChangeRobot(page);
      const result = await executeAndConfirm(page, config, control, progressLabel);
      if (!result.retryWithNewRandomRobot) return result;
      continue;
    }

    if (action === "confirm") {
      if (shouldRememberConfirmForRobotGroup(task)) {
        confirmNotInGroupRobotGroups.add(String(task.robotGroup));
        console.log("This robot group will keep using the current robot even if it shows not in group.");
      }
      return executeAndConfirm(page, { ...config, ignoreRobotNotInGroup: true }, control, progressLabel);
    }

    if (action === "skip") {
      return { ok: false, skipped: true, message: "Robot not in group, skipped by user" };
    }

    throw new Error("用户选择停止运行：机器人不在群");
  }
}

async function handleExpiredTimeIfNeeded(page, state) {
  if (state !== "expiredTime") return state;

  console.log("Schedule time is already past; clicking yes to run immediately");
  const clicked = await clickVisibleDialogButton(page, T.yes, "expired time: yes");
  if (!clicked) await clickText(page, T.yes, "expired time: yes");

  const nextState = await waitForPostExecuteState(page, 10000);
  if (nextState === "expiredTime") return "none";
  return nextState;
}

async function clickExecuteButton(page) {
  const button = await findExactButtonLocator(page, T.execute);
  if (button) {
    await moveToLocator(page, button, "execute send");
    const box = await button.boundingBox().catch(() => null);
    if (box) {
      await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
      return;
    }
    await button.click({ timeout: 8000, force: true });
    return;
  }
  await clickText(page, T.execute, "execute send");
}

async function selectFixedTuoRole(page, config) {
  const prefix = getFixedRolePrefix(config);
  await setStep(page, `select role: ${prefix}`);
  await openUseRoleDropdown(page);

  const point = await findRoleOptionPoint(page, prefix);
  if (!point) throw new Error(`Cannot find role option prefix: ${prefix}`);

  await moveToPoint(page, point.x, point.y, `role ${prefix}`);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(700);
  await ensureFixedRoleSelected(page, point.text || prefix);
}

async function selectFixedTuoRoleFromHistory(page, config, usageRows = [], currentRoleName = "") {
  const prefix = getFixedRolePrefix(config);
  await setStep(page, `select role: ${prefix}`);
  await openUseRoleDropdown(page);

  const point = await findRoleOptionPointFromHistory(page, prefix, usageRows, currentRoleName);
  if (!point) throw new Error(`Cannot find role option prefix: ${prefix}`);

  await moveToPoint(page, point.x, point.y, `role ${point.text || prefix}`);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(700);
  await ensureFixedRoleSelected(page, point.text || prefix);
  console.log(`Fixed role selected: ${point.text || prefix}`);
  return point.text || prefix;
}

async function ensureFixedRoleSelected(page, expectedRoleText) {
  const expected = normalizeCompact(expectedRoleText);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const selected = await getSelectedUseRoleText(page);
    if (selected && normalizeCompact(selected).includes(expected)) return;
    await page.waitForTimeout(500);
  }
  const selected = await getSelectedUseRoleText(page);
  throw new Error(`Fixed role was not selected. expected: ${expectedRoleText}, current: ${selected || "empty"}`);
}

async function getSelectedUseRoleText(page) {
  return page.evaluate((T) => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const inputs = Array.from(document.querySelectorAll("input"))
      .filter((el) => visible(el) && String(el.placeholder || "").includes(T.selectRole));
    if (inputs.length) return inputs[0].value || "";

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (!String(node.nodeValue || "").includes(T.useRole) || !visible(node.parentElement)) continue;
      const row = node.parentElement.closest("div,section,form") || node.parentElement;
      const candidates = Array.from(row.querySelectorAll("input,.el-select,.el-input,[class*='select']"))
        .filter(visible);
      for (const candidate of candidates.reverse()) {
        const input = candidate.matches?.("input") ? candidate : candidate.querySelector?.("input");
        if (input && visible(input)) return input.value || "";
        const text = String(candidate.innerText || candidate.textContent || "").trim();
        if (text && !text.includes(T.useRole)) return text;
      }
    }
    return "";
  }, T).catch(() => "");
}

function normalizeCompact(value) {
  return String(value || "").replace(/\s+/g, "");
}

function getFixedRolePrefix(config) {
  const prefix = String(config.roles?.tuo?.fixedRolePrefix || config.fixedRolePrefix || "").trim();
  if (!prefix) throw new Error("Fixed mode requires a role prefix/range. Restart and enter it.");
  return prefix;
}

async function openUseRoleDropdown(page) {
  const point = await findUseRoleDropdownPoint(page);
  if (point) {
    await moveToPoint(page, point.x, point.y, "open role dropdown");
    await page.mouse.click(point.x, point.y);
    await page.waitForTimeout(500);
    return;
  }

  const input = page.locator(`input[placeholder*="${T.selectRole}"]`).first();
  if (await input.count().catch(() => 0)) {
    await clickLocator(page, input, "open role dropdown");
    await page.waitForTimeout(500);
    return;
  }

  await clickText(page, T.useRole, "open role dropdown");
  await page.waitForTimeout(500);
}

async function findUseRoleDropdownPoint(page) {
  return page.evaluate((T) => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const inputs = Array.from(document.querySelectorAll("input"))
      .filter((el) => visible(el) && String(el.placeholder || "").includes(T.selectRole));
    if (inputs.length) {
      const r = inputs[0].getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    }

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (!String(node.nodeValue || "").includes(T.useRole) || !visible(node.parentElement)) continue;
      const row = node.parentElement.closest("div,section,form") || node.parentElement;
      const candidates = Array.from(row.querySelectorAll("input,.el-select,.el-input,[class*='select']"))
        .filter(visible);
      if (candidates.length) {
        const r = candidates[candidates.length - 1].getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      }
      const r = node.parentElement.getBoundingClientRect();
      return { x: r.right + 120, y: r.top + r.height / 2 };
    }
    return null;
  }, T).catch(() => null);
}

async function findRoleOptionPoint(page, prefix) {
  return page.evaluate((prefix) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(prefix);
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const selectors = ".el-select-dropdown__item, .el-select-dropdown li, [class*='select-dropdown'] li";
    const options = Array.from(document.querySelectorAll(selectors))
      .map((el) => el.closest(".el-select-dropdown__item, li") || el)
      .filter((el, index, arr) => arr.indexOf(el) === index)
      .filter((el) => visible(el) && !el.classList.contains("is-disabled") && normalize(el.innerText || el.textContent).startsWith(target))
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = String(el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
        return { x: r.left + r.width / 2, y: r.top + r.height / 2, top: r.top, left: r.left, area: r.width * r.height, text };
      })
      .filter((item) => item.area > 20);
    options.sort((a, b) => a.top - b.top || a.left - b.left);
    return options[0] || null;
  }, prefix).catch(() => null);
}

async function findRoleOptionPointFromHistory(page, prefix, usageRows = [], currentRoleName = "") {
  const usageRank = buildRoleUsageRank(usageRows, currentRoleName);
  return page.evaluate(({ prefix, usageRank }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(prefix);
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const selectors = ".el-select-dropdown__item, .el-select-dropdown li, [class*='select-dropdown'] li";
    const options = Array.from(document.querySelectorAll(selectors))
      .map((el) => el.closest(".el-select-dropdown__item, li") || el)
      .filter((el, index, arr) => arr.indexOf(el) === index)
      .filter((el) => visible(el) && !el.classList.contains("is-disabled") && normalize(el.innerText || el.textContent).startsWith(target))
      .map((el) => {
        const r = el.getBoundingClientRect();
        const text = String(el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
        const rank = usageRank[text] ?? 0;
        return { x: r.left + r.width / 2, y: r.top + r.height / 2, top: r.top, left: r.left, area: r.width * r.height, text, rank };
      })
      .filter((item) => item.area > 20);
    options.sort((a, b) => a.rank - b.rank || a.top - b.top || a.left - b.left);
    return options[0] || null;
  }, { prefix, usageRank }).catch(() => null);
}

async function clickChangeRobot(page) {
  const before = await selectedRobotSnapshot(page);
  let lastError = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await clickChangeRobotOnce(page);
      const changed = await waitForRobotSnapshotChange(page, before, 3500);
      if (!before || changed) return;
      lastError = new Error("Robot selection did not change after clicking change robot");
    } catch (error) {
      lastError = error;
    }
    await page.waitForTimeout(800);
  }
  throw lastError || new Error("Change robot failed");
}

async function clickChangeRobotOnce(page) {
  const point = await findChangeRobotPoint(page);
  if (point) {
    await moveToPoint(page, point.x, point.y, "change robot");
    await page.waitForTimeout(1200);
    await page.mouse.click(point.x, point.y);
    await page.waitForTimeout(1800);
    return;
  }

  const loc = await findExactSmallTextLocator(page, T.changeRobot);
  if (!loc) throw new Error(`Cannot find button or text: ${T.changeRobot}`);
  await moveToLocator(page, loc, "change robot");
  await page.waitForTimeout(1200);
  const box = await loc.boundingBox().catch(() => null);
  if (box) {
    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  } else {
    await loc.click({ timeout: 8000, force: true });
  }
  await page.waitForTimeout(1800);
}

async function waitForRobotSnapshotChange(page, before, timeoutMs = 3500) {
  if (!before) return true;
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const after = await selectedRobotSnapshot(page);
    if (after && after !== before) return true;
    await page.waitForTimeout(500);
  }
  return false;
}

async function selectedRobotSnapshot(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const normalize = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const checkedRows = [];
    const rows = Array.from(document.querySelectorAll("tr,.el-table__row,[class*='table-row']"))
      .filter((row) => visible(row));
    for (const row of rows) {
      const text = normalize(row.innerText || row.textContent);
      if (!text || !/(在线|wxid_|群#|群：|群:|宝妈|年轻|成熟|早期|机器人)/.test(text)) continue;
      const checked = Array.from(row.querySelectorAll("input[type='checkbox'],.el-checkbox,.ant-checkbox"))
        .some((el) =>
          el.checked ||
          el.getAttribute("aria-checked") === "true" ||
          String(el.className || "").includes("is-checked") ||
          Boolean(el.querySelector?.(".is-checked,input:checked,[aria-checked='true']"))
        );
      if (checked) checkedRows.push(text);
    }
    if (checkedRows.length) return checkedRows.join(" | ").slice(0, 1000);

    const body = normalize(document.body.innerText || "");
    const marker = body.indexOf("机器人");
    if (marker < 0) return "";
    return body.slice(marker, marker + 500);
  }).catch(() => "");
}

async function findChangeRobotPoint(page) {
  return page.evaluate((target) => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const candidates = [];
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const text = node.nodeValue || "";
      let index = text.indexOf(target);
      while (index >= 0) {
        const before = text.slice(Math.max(0, index - 2), index);
        if (!before.includes("闅忔満") && visible(node.parentElement)) {
          const range = document.createRange();
          range.setStart(node, index);
          range.setEnd(node, index + target.length);
          const rect = Array.from(range.getClientRects()).find((r) => r.width > 0 && r.height > 0);
          range.detach();
          if (rect) {
            candidates.push({
              x: rect.left + rect.width / 2,
              y: rect.top + rect.height / 2,
              top: rect.top,
              left: rect.left
            });
          }
        }
        index = text.indexOf(target, index + target.length);
      }
    }
    candidates.sort((a, b) => a.top - b.top || a.left - b.left);
    return candidates[0] || null;
  }, T.changeRobot).catch(() => null);
}

async function waitForPostExecuteState(page, timeoutMs = 12000) {
  return page.waitForFunction((T) => {
    const body = document.body.innerText || "";
    return (
      body.includes(T.confirmCreate) ||
      body.includes(T.noContent) ||
      body.includes(T.choose) ||
      body.includes(T.empty) ||
      body.includes(T.taskCreated) ||
      body.includes(T.created) ||
      body.includes(T.expiredTime) ||
      body.includes(T.switchImmediate)
    );
  }, T, { timeout: timeoutMs }).then(async () => {
    const body = await page.locator("body").innerText();
    if (body.includes(T.noContent) || body.includes(T.choose) || body.includes(T.empty)) return "error";
    if (body.includes(T.expiredTime) || body.includes(T.switchImmediate)) return "expiredTime";
    if (body.includes(T.confirmCreate)) return "confirmCreate";
    if (body.includes(T.taskCreated) || body.includes(T.created)) return "created";
    return "none";
  }).catch(() => "none");
}

async function clickConfirmCreateButton(page) {
  if (await clickDialogPrimaryButton(page, T.confirmCreate, "confirm create")) return;
  if (await clickVisibleDialogButton(page, T.confirmCreate, "confirm create")) return;
  const button = await findDialogButtonLocator(page, T.confirmCreate);
  if (button) {
    await moveToLocator(page, button, "confirm create");
    const box = await button.boundingBox().catch(() => null);
    if (box) {
      await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
      return;
    }
    await button.click({ timeout: 8000, force: true });
    return;
  }
  throw new Error("Cannot click visible confirm-create button");
}

async function clickCancelCreateButton(page) {
  if (await clickDialogPrimaryButton(page, T.cancel, "cancel create")) return;
  if (await clickVisibleDialogButton(page, T.cancel, "cancel create")) return;
  await page.keyboard.press("Escape").catch(() => {});
  await page.waitForTimeout(500);
}

function hasRobotNotInGroupWarning(body) {
  const text = String(body || "").replace(/\s+/g, "");
  return (
    text.includes("机器人不在群") ||
    text.includes("个机器人不在群") ||
    text.includes("不在群") ||
    text.includes("鏈哄櫒浜轰笉鍦ㄧ兢") ||
    /检测到[\s\S]*机器人不在群/.test(text) ||
    /妫€娴嬪埌[\s\S]*鏈哄櫒浜轰笉鍦ㄧ兢/.test(text)
  );
}

async function clickDialogPrimaryButton(page, text, label) {
  const point = await page.evaluate((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0
        && rect.height > 0
        && rect.bottom > 0
        && rect.right > 0
        && rect.top < window.innerHeight
        && rect.left < window.innerWidth
        && style.visibility !== "hidden"
        && style.display !== "none"
        && style.opacity !== "0";
    };
    const disabled = (el) => el.disabled || el.getAttribute("aria-disabled") === "true" || el.className.includes("is-disabled");
    const primary = (el) => {
      const cls = String(el.className || "");
      return cls.includes("primary") || cls.includes("el-button--primary") || cls.includes("ant-btn-primary");
    };
    const inFooter = (el) => Boolean(el.closest(".el-dialog__footer, .el-message-box__btns, .ant-modal-footer, .modal-footer"));
    const roots = Array.from(document.querySelectorAll(".el-dialog, .el-message-box, [role='dialog'], .ant-modal, .modal"))
      .filter(visible);
    if (!roots.length) roots.push(document.body);

    const candidates = [];
    for (const root of roots.slice().reverse()) {
      const buttons = Array.from(root.querySelectorAll("button,a,[role='button'],.el-button"))
        .filter((el) => visible(el) && !disabled(el));
      for (const button of buttons) {
        const content = normalize(button.innerText || button.textContent);
        if (!content.includes(target)) continue;
        let score = 0;
        if (content === target) score += 100;
        if (primary(button)) score += 30;
        if (inFooter(button)) score += 20;
        candidates.push({ button, score });
      }
    }

    candidates.sort((a, b) => a.score - b.score);
    const picked = candidates[candidates.length - 1]?.button;
    if (!picked) return null;
    const rect = picked.getBoundingClientRect();
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  }, text).catch(() => null);
  if (!point) return false;
  await moveToPoint(page, point.x, point.y, label);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(500);
  return true;
}

async function clickVisibleDialogButton(page, text, label) {
  const point = await page.evaluate((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0
        && rect.height > 0
        && rect.bottom > 0
        && rect.right > 0
        && rect.top < window.innerHeight
        && rect.left < window.innerWidth
        && style.visibility !== "hidden"
        && style.display !== "none"
        && style.opacity !== "0"
        && style.pointerEvents !== "none";
    };
    const roots = Array.from(document.querySelectorAll(".el-dialog, .el-message-box, [role='dialog'], .ant-modal, .modal"))
      .filter(visible);
    if (!roots.length) roots.push(document.body);
    for (const root of roots.slice().reverse()) {
      const buttons = Array.from(root.querySelectorAll("button,a,[role='button'],.el-button"))
        .filter((el) => visible(el) && normalize(el.innerText || el.textContent) === target);
      const button = buttons[buttons.length - 1];
      if (button) {
        const rect = button.getBoundingClientRect();
        return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
      }
    }
    return null;
  }, text).catch(() => null);
  if (!point) return false;
  await moveToPoint(page, point.x, point.y, label);
  await page.mouse.click(point.x, point.y);
  await page.waitForTimeout(400);
  return true;
}

async function waitForManualConfirmDone(page, timeoutMs) {
  await page.waitForFunction((T) => {
    const body = document.body.innerText || "";
    return !body.includes(T.confirmCreate) || body.includes(T.taskCreated) || body.includes(T.created);
  }, T, { timeout: timeoutMs });
  await page.waitForTimeout(200);
}

async function waitForCreateSuccess(page, timeoutMs = 10000) {
  return page.waitForFunction((T) => {
    const body = document.body.innerText || "";
    return (body.includes(T.taskCreated) || body.includes(T.created)) && !body.includes(T.confirmCreate);
  }, T, { timeout: timeoutMs }).then(() => true).catch(() => false);
}

async function installVirtualMouse(page) {
  if (!showVisualHelper) return;
  await page.evaluate(() => {
    document.getElementById("fd-mouse-label")?.remove();
    document.getElementById("fd-step-status")?.remove();
    if (document.getElementById("fd-mouse")) return;

    const cursor = document.createElement("div");
    cursor.id = "fd-mouse";
    cursor.style.cssText = [
      "position:fixed",
      "left:24px",
      "top:24px",
      "width:18px",
      "height:18px",
      "border-radius:50%",
      "background:#ef4444",
      "border:3px solid #fff",
      "box-shadow:0 0 0 3px rgba(239,68,68,.35),0 6px 18px rgba(0,0,0,.25)",
      "z-index:2147483647",
      "pointer-events:none",
      "transition:left .18s ease,top .18s ease"
    ].join(";");

    document.body.append(cursor);
  }).catch(() => {});
}

async function setStep(page, text) {
  if (!showVisualHelper) return;
  await installVirtualMouse(page);
}

function cmsPageMemoryFile(config) {
  const file = config.cmsPageMemoryFile || "cms-page-settings.json";
  return path.isAbsolute(file) ? file : path.resolve(process.cwd(), file);
}

async function loadCmsPageMemory(config) {
  try {
    return JSON.parse(await fs.readFile(cmsPageMemoryFile(config), "utf8"));
  } catch {
    return {};
  }
}

function hasCmsPageMemory(memory) {
  return Boolean(memory?.tuo || memory?.douma);
}

async function saveCmsPageMemory(cmsPages, config) {
  try {
    await revealCmsTopOptions(cmsPages[0], "托页面");
    await revealCmsTopOptions(cmsPages[1], "豆妈页面");
    await scrollCmsTopOptionsToRight(cmsPages[0], "托页面");
    await scrollCmsTopOptionsToRight(cmsPages[1], "豆妈页面");
    const memory = {
      updatedAt: new Date().toISOString(),
      tuo: await captureCmsPageState(cmsPages[0], "托页面"),
      douma: await captureCmsPageState(cmsPages[1], "豆妈页面")
    };
    await fs.writeFile(cmsPageMemoryFile(config), JSON.stringify(memory, null, 2), "utf8");
    console.log(`已记住本次云中客页面选择：托 ${memory.tuo.selectedRows.length} 项，豆妈 ${memory.douma.selectedRows.length} 项。`);
  } catch (error) {
    console.log(`保存云中客页面记忆失败：${error.message}`);
  }
}

async function restoreCmsPageMemory(page, state, label) {
  if (!state) {
    console.log(`${label}：没有上次记录，跳过恢复。`);
    return { total: 0, clicked: 0, missing: [] };
  }

  await revealCmsTopOptions(page, label);
  await setMultiQuickMode(page, inferSavedMultiQuickMode(state), label);
  await restoreTaskRemark(page, state.taskRemark, label);
  const summary = await restoreSelectedRows(page, state.selectedRows || [], label);
  const missingText = summary.missing.length ? `，未找到 ${summary.missing.length} 项：${summary.missing.slice(0, 3).join(" / ")}` : "";
  console.log(`${label}：已补选 ${summary.clicked} 项，上次记录 ${summary.total} 项${missingText}`);
  return summary;
}

function inferSavedMultiQuickMode(state) {
  if (typeof state?.multiQuickMode === "boolean") return state.multiQuickMode;
  const rows = Array.isArray(state?.selectedRows) ? state.selectedRows : [];
  const looksLikeMultiQuickRow = rows.some((row) => {
    const key = String(row?.key || "");
    const text = String(row?.text || "");
    return key.startsWith("id:")
      || (/^\s*\d{4,}\s+/.test(text) && /\(群[:：]\d+\/\d+\)/.test(text) && /在线[:：]/.test(text));
  });
  return looksLikeMultiQuickRow ? true : null;
}

async function captureCmsPageState(page, label) {
  return page.evaluate((label) => {
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const compact = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0
        && r.top < window.innerHeight && r.left < window.innerWidth
        && s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
    };
    const isChecked = (el) => {
      if (!el) return false;
      if (el.matches?.("input[type='checkbox'],input[type='radio']")) return Boolean(el.checked);
      const aria = el.getAttribute?.("aria-checked");
      if (aria === "true") return true;
      if (String(el.className || "").includes("is-checked")) return true;
      return Boolean(el.querySelector?.("input[type='checkbox']:checked,input[type='radio']:checked,.is-checked,[aria-checked='true']"));
    };
    const stableTokens = (text) => {
      const raw = clean(text);
      const textCompact = compact(raw);
      const tokens = [];
      const add = (value) => {
        const token = compact(value).replace(/[，,。；;：:]/g, "");
        if (!token || token.length < 2) return;
        if (/^(在线|配置|机器人|默认分组|群成员|备注|排序|发送|刷新|管理|显示选中项)$/.test(token)) return;
        if (/^\d+$/.test(token) && token.length < 4) return;
        tokens.push(token);
      };
      const groupLabel = raw.match(/^\d{4,}\s+(.+?)\s*\(群[:：]/);
      if (groupLabel) add(groupLabel[1]);
      for (const match of textCompact.matchAll(/[A-Za-z]+\d+(?:-[A-Za-z]?\d+)+|[LDWFCMJ]\d{1,4}(?:-[LDWFCMJ]?\d{1,4})?/g)) add(match[0]);
      for (const match of raw.matchAll(/([^\s()|（）]{2,24})[（(]群(\d+)[）)]/g)) {
        add(match[1]);
        add(`群${match[2]}`);
      }
      for (const part of raw.split(/\s+/)) {
        if (/[\u4e00-\u9fa5]/.test(part) && compact(part).length >= 4) add(part);
      }
      return Array.from(new Set(tokens)).slice(0, 12);
    };
    const rowKey = (text) => {
      const id = clean(text).match(/^(\d{4,})\b/);
      if (id) return `id:${id[1]}`;
      return `text:${compact(text).slice(0, 90)}`;
    };
    const findSwitch = (labelText) => {
      const labels = Array.from(document.querySelectorAll("span,div,label"))
        .filter((el) => visible(el) && clean(el.innerText || el.textContent).includes(labelText));
      if (!labels.length) return null;
      const labelBox = labels[0].getBoundingClientRect();
      const switches = Array.from(document.querySelectorAll(".el-switch,[role='switch'],input[type='checkbox']"))
        .filter((el) => {
          if (!visible(el)) return false;
          const r = el.getBoundingClientRect();
          const yNear = Math.abs((r.top + r.bottom) / 2 - (labelBox.top + labelBox.bottom) / 2) < 36;
          const xNear = r.left > labelBox.left - 60 && r.left < labelBox.right + 220;
          return yNear && xNear;
        })
        .sort((a, b) => Math.abs(a.getBoundingClientRect().left - labelBox.right) - Math.abs(b.getBoundingClientRect().left - labelBox.right));
      return switches[0] ? isChecked(switches[0]) : null;
    };
    const findTaskRemark = () => {
      const fields = Array.from(document.querySelectorAll("textarea,input"))
        .filter((el) => visible(el) && !el.disabled && !el.readOnly);
      const byPlaceholder = fields.find((el) => /任务|备注/.test(el.getAttribute("placeholder") || ""));
      if (byPlaceholder) return byPlaceholder.value || "";
      const textareas = fields.filter((el) => el.tagName === "TEXTAREA");
      const taskTextarea = textareas.find((el) => !/文字|微信|emjio|emoji|图片|视频|动态表情/.test(el.getAttribute("placeholder") || ""));
      return taskTextarea?.value || "";
    };
    const selectedRows = [];
    const roots = Array.from(document.querySelectorAll("tr,.el-table__row,[class*='table-row']"))
      .filter(visible);
    const seen = new Set();
    for (const row of roots) {
      if (!isChecked(row)) continue;
      const text = clean(row.innerText || row.textContent);
      if (!text || /快捷分组\s*备注\s*排序|机器人\s*[（(]\d+[）)]\s*配置|发送内容|任务信息|分组信息/.test(text)) continue;
      const key = rowKey(text);
      if (seen.has(key)) continue;
      seen.add(key);
      selectedRows.push({ key, text: text.slice(0, 500), tokens: stableTokens(text) });
    }
    return {
      label,
      url: location.href,
      multiQuickMode: findSwitch("多快捷模式"),
      taskRemark: findTaskRemark(),
      selectedRows,
      selectedCount: selectedRows.length
    };
  }, label);
}

async function setMultiQuickMode(page, desired, label) {
  if (typeof desired !== "boolean") return;
  let target = await findMultiQuickModeTarget(page);

  if (desired === false && !target.ok) {
    console.log(`${label}：上次多快捷模式未开启，本次不处理多快捷。`);
    return;
  }

  if (!target.ok) {
    const revealed = await revealCmsTopOptions(page, label);
    if (revealed) {
      await page.waitForTimeout(1000);
      target = await findMultiQuickModeTarget(page);
    }
  }

  if (!target.ok) {
    const scrolled = await scrollCmsTopOptionsToRight(page, label);
    if (scrolled) {
      await page.waitForTimeout(800);
      target = await findMultiQuickModeTarget(page);
    }
  }

  if (!target.ok) {
    console.log(`${label}：没有找到多快捷模式开关，跳过。`);
    return;
  }
  if (target.checked === desired) {
    console.log(`${label}：多快捷模式已是${desired ? "开启" : "关闭"}。`);
    return;
  }
  await moveToPoint(page, target.x, target.y, `${label} 多快捷模式`);
  await page.mouse.click(target.x, target.y).catch(() => {});
  await page.waitForTimeout(1500);
  console.log(`${label}：已${desired ? "开启" : "关闭"}多快捷模式。`);
}

async function findMultiQuickModeTarget(page) {
  return page.evaluate(() => {
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0
        && r.top < window.innerHeight && r.left < window.innerWidth
        && s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
    };
    const checked = (el) => {
      if (el.matches?.("input[type='checkbox']")) return Boolean(el.checked);
      if (el.getAttribute?.("aria-checked") === "true") return true;
      if (String(el.className || "").includes("is-checked")) return true;
      return Boolean(el.querySelector?.("input[type='checkbox']:checked,.is-checked,[aria-checked='true']"));
    };
    const labels = Array.from(document.querySelectorAll("span,div,label"))
      .filter((el) => visible(el) && clean(el.innerText || el.textContent).includes("多快捷模式"));
    if (!labels.length) return { ok: false };
    const labelBox = labels[0].getBoundingClientRect();
    const switches = Array.from(document.querySelectorAll(".el-switch,[role='switch'],input[type='checkbox']"))
      .filter((el) => {
        if (!visible(el)) return false;
        const r = el.getBoundingClientRect();
        const yNear = Math.abs((r.top + r.bottom) / 2 - (labelBox.top + labelBox.bottom) / 2) < 36;
        const xNear = r.left > labelBox.left - 60 && r.left < labelBox.right + 220;
        return yNear && xNear;
      })
      .sort((a, b) => Math.abs(a.getBoundingClientRect().left - labelBox.right) - Math.abs(b.getBoundingClientRect().left - labelBox.right));
    const sw = switches[0];
    if (!sw) return { ok: false };
    const r = sw.getBoundingClientRect();
    return { ok: true, checked: checked(sw), x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }).catch(() => ({ ok: false }));
}

async function scrollCmsTopOptionsToRight(page, label) {
  const result = await page.evaluate(() => {
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0
        && r.top < window.innerHeight && r.left < window.innerWidth
        && s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
    };
    const multiQuickVisible = Array.from(document.querySelectorAll("span,div,label"))
      .some((el) => visible(el) && clean(el.innerText || el.textContent).includes("多快捷模式"));
    if (multiQuickVisible) return { ok: false, alreadyVisible: true };

    const topWords = ["群分组关联排序", "超长表格", "多快捷模式", "模式说明", "管理分组", "新建分组", "克隆"];
    const scrollables = Array.from(document.querySelectorAll("div,section,main"))
      .filter((el) => {
        if (!visible(el)) return false;
        const r = el.getBoundingClientRect();
        if (r.top < 70 || r.top > 260 || r.height < 22 || r.height > 180 || r.width < 240) return false;
        if (el.scrollWidth <= el.clientWidth + 30) return false;
        const text = clean(el.innerText || el.textContent);
        return topWords.some((word) => text.includes(word));
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        const aScore = Math.abs(ar.top - 120) + (window.innerWidth - ar.right) * 0.01 - ar.width * 0.001;
        const bScore = Math.abs(br.top - 120) + (window.innerWidth - br.right) * 0.01 - br.width * 0.001;
        return aScore - bScore;
      });

    const changed = [];
    for (const el of scrollables.slice(0, 4)) {
      const before = el.scrollLeft;
      el.scrollLeft = el.scrollWidth;
      el.dispatchEvent(new Event("scroll", { bubbles: true }));
      if (Math.abs(el.scrollLeft - before) > 2) changed.push(el);
    }
    const target = changed[0] || scrollables[0];
    if (!target) return { ok: false };
    const r = target.getBoundingClientRect();
    return {
      ok: Boolean(changed.length),
      x: Math.min(window.innerWidth - 18, Math.max(18, r.right - 18)),
      y: Math.min(window.innerHeight - 18, Math.max(18, r.bottom - 8))
    };
  }).catch(() => ({ ok: false }));

  if (!result.ok) return false;
  await moveToPoint(page, result.x, result.y, `${label} 顶部横向滚动条`);
  await page.waitForTimeout(600);
  console.log(`${label}：页面太窄，已把顶部横向滚动条拖到右侧。`);
  return true;
}

async function revealCmsTopOptions(page, label) {
  const hoverPoint = await page.evaluate(() => {
    const y = Math.min(Math.max(window.innerHeight / 2, 260), window.innerHeight - 120);
    return { x: 235, y };
  }).catch(() => ({ x: 235, y: 420 }));
  await moveToPoint(page, hoverPoint.x, hoverPoint.y, `${label} 左侧菜单`);
  await page.mouse.move(hoverPoint.x, hoverPoint.y, { steps: 8 }).catch(() => {});
  await page.waitForTimeout(350);

  const target = await page.evaluate(() => {
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0
        && r.top < window.innerHeight && r.left < window.innerWidth
        && s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
    };
    const multiQuickVisible = Array.from(document.querySelectorAll("span,div,label"))
      .some((el) => visible(el) && clean(el.innerText || el.textContent).includes("多快捷模式"));
    const sidebarExpanded = Array.from(document.querySelectorAll("span,div,a,li"))
      .some((el) => {
        if (!visible(el)) return false;
        const r = el.getBoundingClientRect();
        if (r.left > 260 || r.width < 30) return false;
        const text = clean(el.innerText || el.textContent);
        return /群氛围|机器人管理|创建任务|任务列表|数据统计|脚本应答/.test(text);
      });
    if (multiQuickVisible && !sidebarExpanded) return { ok: false, alreadyVisible: true };

    const candidates = Array.from(document.querySelectorAll("button,span,div,i,[class*='collapse'],[class*='fold'],[class*='aside'],[class*='sidebar']"))
      .filter((el) => {
        if (!visible(el)) return false;
        const r = el.getBoundingClientRect();
        if (r.width < 8 || r.width > 45 || r.height < 18 || r.height > 90) return false;
        if (r.left < 180 || r.left > 360) return false;
        if (r.top < 120 || r.top > window.innerHeight - 35) return false;
        const text = clean(el.innerText || el.textContent);
        const cls = String(el.className || "");
        const aria = String(el.getAttribute("aria-label") || el.getAttribute("title") || "");
        const mark = `${text} ${cls} ${aria}`;
        if (!sidebarExpanded && /^[>›»]$/.test(text)) return false;
        return /^[<‹«]$/.test(text)
          || /collapse|fold|sidebar|aside|arrow|menu|收起/.test(mark)
          || (sidebarExpanded && /^[>›»]$/.test(text));
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        const as = Math.abs(ar.left - 245) + Math.abs(ar.top - window.innerHeight / 2) * 0.25;
        const bs = Math.abs(br.left - 245) + Math.abs(br.top - window.innerHeight / 2) * 0.25;
        return as - bs;
      });
    const el = candidates[0];
    if (!el) return { ok: false };
    const r = el.getBoundingClientRect();
    return { ok: true, x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }).catch(() => ({ ok: false }));

  if (!target.ok) return false;
  await moveToPoint(page, target.x, target.y, `${label} 收起侧栏`);
  await page.mouse.click(target.x, target.y).catch(() => {});
  await page.waitForTimeout(1000);
  console.log(`${label}：页面太窄，已尝试收起左侧菜单。`);
  return true;
}

async function restoreTaskRemark(page, value, label) {
  const remark = String(value || "").trim();
  if (!remark) return;
  const result = await page.evaluate((remark) => {
    const visible = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0
        && r.top < window.innerHeight && r.left < window.innerWidth
        && s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
    };
    const fields = Array.from(document.querySelectorAll("textarea,input"))
      .filter((el) => visible(el) && !el.disabled && !el.readOnly);
    const field = fields.find((el) => /任务|备注/.test(el.getAttribute("placeholder") || ""))
      || fields.filter((el) => el.tagName === "TEXTAREA")
        .find((el) => !/文字|微信|emjio|emoji|图片|视频|动态表情/.test(el.getAttribute("placeholder") || ""));
    if (!field) return false;
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(field), "value")?.set;
    setter ? setter.call(field, remark) : (field.value = remark);
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }, remark).catch(() => false);
  if (result) console.log(`${label}：已恢复任务备注。`);
  else console.log(`${label}：没有找到任务备注输入框，跳过。`);
}

async function restoreSelectedRows(page, savedRows, label) {
  let clicked = 0;
  const missing = [];
  for (const item of savedRows) {
    const target = await page.evaluate((item) => {
      const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
      const compact = (value) => String(value || "").replace(/\s+/g, "");
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0
          && r.top < window.innerHeight && r.left < window.innerWidth
          && s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
      };
      const isChecked = (el) => {
        if (!el) return false;
        if (el.matches?.("input[type='checkbox'],input[type='radio']")) return Boolean(el.checked);
        if (el.getAttribute?.("aria-checked") === "true") return true;
        if (String(el.className || "").includes("is-checked")) return true;
        return Boolean(el.querySelector?.("input[type='checkbox']:checked,input[type='radio']:checked,.is-checked,[aria-checked='true']"));
      };
      const stableTokens = (text) => {
        const raw = clean(text);
        const textCompact = compact(raw);
        const tokens = [];
        const add = (value) => {
          const token = compact(value).replace(/[，,。；;：:]/g, "");
          if (!token || token.length < 2) return;
          if (/^(在线|配置|机器人|默认分组|群成员|备注|排序|发送|刷新|管理|显示选中项)$/.test(token)) return;
          if (/^\d+$/.test(token) && token.length < 4) return;
          tokens.push(token);
        };
        const groupLabel = raw.match(/^\d{4,}\s+(.+?)\s*\(群[:：]/);
        if (groupLabel) add(groupLabel[1]);
        for (const match of textCompact.matchAll(/[A-Za-z]+\d+(?:-[A-Za-z]?\d+)+|[LDWFCMJ]\d{1,4}(?:-[LDWFCMJ]?\d{1,4})?/g)) add(match[0]);
        for (const match of raw.matchAll(/([^\s()|（）]{2,24})[（(]群(\d+)[）)]/g)) {
          add(match[1]);
          add(`群${match[2]}`);
        }
        for (const part of raw.split(/\s+/)) {
          if (/[\u4e00-\u9fa5]/.test(part) && compact(part).length >= 4) add(part);
        }
        return Array.from(new Set(tokens)).slice(0, 12);
      };
      const tokenHit = (rowClean, token) => {
        if (!token) return false;
        if (rowClean.includes(token)) return true;
        if (/^\d{4,}$/.test(token)) return rowClean.includes(token.slice(0, 5));
        return false;
      };
      const rowMatches = (rowText) => {
        const rowClean = compact(rowText);
        const key = item.key || "";
        if (key.startsWith("id:") && rowClean.includes(key.slice(3))) return true;
        const saved = compact(item.text || key.replace(/^text:/, ""));
        if (!saved) return false;
        const sig = saved.slice(0, Math.min(45, saved.length));
        if (sig && rowClean.includes(sig)) return true;
        const savedTokens = item.tokens?.length ? item.tokens : stableTokens(item.text || key);
        const useful = savedTokens.filter((token) => {
          if (!token) return false;
          if (/^(30\+宝妈|20\+宝妈|年轻女性|成熟女性|年轻|成熟)$/.test(token)) return false;
          return token.length >= 3 || /^L\d+$/.test(token);
        });
        if (!useful.length) return false;
        const hits = useful.filter((token) => tokenHit(rowClean, token));
        if (hits.some((token) => /^L\d+$|^[A-Za-z]+\d+(?:-[A-Za-z]?\d+)+|群\d+$/.test(token))) return true;
        return hits.length >= Math.min(2, useful.length);
      };
      const rows = Array.from(document.querySelectorAll("tr,.el-table__row,[class*='table-row']"))
        .filter(visible);
      const row = rows.find((candidate) => rowMatches(candidate.innerText || candidate.textContent));
      if (!row) return { ok: false, reason: "missing" };
      if (isChecked(row)) return { ok: true, checked: true };
      const checkbox = Array.from(row.querySelectorAll("input[type='checkbox'],input[type='radio'],.el-checkbox,.el-checkbox__input,[role='checkbox']"))
        .filter(visible)[0] || row;
      const r = checkbox.getBoundingClientRect();
      return { ok: true, checked: false, x: r.left + r.width / 2, y: r.top + r.height / 2 };
    }, item).catch(() => ({ ok: false, reason: "error" }));

    if (!target.ok) {
      missing.push(String(item.text || item.key || "").slice(0, 30));
      continue;
    }
    if (target.checked) continue;
    await moveToPoint(page, target.x, target.y, `${label} 勾选`);
    await page.mouse.click(target.x, target.y).catch(() => {});
    clicked += 1;
    await page.waitForTimeout(250);
  }
  return { total: savedRows.length, clicked, missing };
}

async function moveToLocator(page, locator, label) {
  await locator.scrollIntoViewIfNeeded({ timeout: 5000 }).catch(() => {});
  if (!showVisualHelper) return;
  await installVirtualMouse(page);
  const box = await locator.boundingBox({ timeout: 5000 }).catch(() => null);
  if (!box) {
    await setStep(page, label);
    return;
  }

  const x = Math.max(8, box.x + box.width / 2);
  const y = Math.max(8, box.y + box.height / 2);
  await page.mouse.move(x, y, { steps: 10 }).catch(() => {});
  await page.evaluate(({ x, y, label }) => {
    const cursor = document.getElementById("fd-mouse");
    if (cursor) {
      cursor.style.left = `${x - 9}px`;
      cursor.style.top = `${y - 9}px`;
    }
  }, { x, y, label }).catch(() => {});
  await page.waitForTimeout(80);
}

async function moveToPoint(page, x, y, label) {
  if (!showVisualHelper) return;
  await installVirtualMouse(page);
  await page.mouse.move(x, y, { steps: 10 }).catch(() => {});
  await page.evaluate(({ x, y, label }) => {
    const cursor = document.getElementById("fd-mouse");
    if (cursor) {
      cursor.style.left = `${x - 9}px`;
      cursor.style.top = `${y - 9}px`;
    }
  }, { x, y, label }).catch(() => {});
  await page.waitForTimeout(80);
}

async function clickLocator(page, locator, label) {
  await moveToLocator(page, locator, label);
  await locator.click({ timeout: 8000 });
}

async function clickText(page, text, label, options = {}) {
  const loc = await findTextLocator(page, text, options);
  if (!loc) {
    if (options.optional) return false;
    throw new Error(`Cannot find button or text: ${text}`);
  }
  await clickLocator(page, loc, label || text);
  return true;
}

async function findAnyTextLocator(page, texts) {
  for (const text of texts) {
    const loc = await findTextLocator(page, text, { optional: true });
    if (loc) return loc;
  }
  return null;
}

async function findExactSmallTextLocator(page, text) {
  const handle = await page.evaluateHandle((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const score = (el) => {
      const r = el.getBoundingClientRect();
      const cls = String(el.className || "");
      const tabBonus = /tab|tabs|item|active/.test(cls) ? -100000 : 0;
      return r.width * r.height + tabBonus;
    };
    const els = Array.from(document.querySelectorAll("button,a,span,div,label,li"));
    return els
      .filter((el) => visible(el) && normalize(el.innerText || el.textContent) === target)
      .sort((a, b) => score(a) - score(b))[0] || null;
  }, text).catch(() => null);
  return handle?.asElement() || null;
}

async function findExactButtonLocator(page, text) {
  const roleButton = page.getByRole("button", { name: text, exact: true }).first();
  if (await roleButton.count().catch(() => 0)) return roleButton;

  const handle = await page.evaluateHandle((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const els = Array.from(document.querySelectorAll("button,a,[role='button']"));
    return els.find((el) => visible(el) && normalize(el.innerText || el.textContent) === target) || null;
  }, text).catch(() => null);
  return handle?.asElement() || null;
}

async function findDialogButtonLocator(page, text) {
  const handle = await page.evaluateHandle((text) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const target = normalize(text);
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0
        && r.height > 0
        && r.bottom > 0
        && r.right > 0
        && r.top < window.innerHeight
        && r.left < window.innerWidth
        && s.visibility !== "hidden"
        && s.display !== "none"
        && s.opacity !== "0"
        && s.pointerEvents !== "none";
    };
    const dialogs = Array.from(document.querySelectorAll(".el-dialog, .el-message-box, [role='dialog'], .ant-modal, .modal"))
      .filter(visible);
    const roots = dialogs.length ? dialogs : [document.body];
    for (const root of roots.slice().reverse()) {
      const buttons = Array.from(root.querySelectorAll("button,a,[role='button'],.el-button"))
        .filter((el) => visible(el) && normalize(el.innerText || el.textContent) === target);
      if (buttons.length) return buttons[buttons.length - 1];
    }
    return null;
  }, text).catch(() => null);
  return handle?.asElement() || null;
}

async function findTextLocator(page, text, options = {}) {
  const compactText = compact(text);
  const handle = await page.evaluateHandle(({ compactText }) => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "");
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const tags = "button,a,span,div,label,li";
    const els = Array.from(document.querySelectorAll(tags));
    return els.find((el) => visible(el) && normalize(el.innerText || el.textContent).includes(compactText)) || null;
  }, { compactText });
  const element = handle.asElement();
  if (element) return element;

  const candidates = [
    page.getByRole("button", { name: new RegExp(spacedRegex(text)) }).first(),
    page.getByText(new RegExp(spacedRegex(text))).first()
  ];
  for (const loc of candidates) {
    if (await loc.count().catch(() => 0)) return loc;
  }

  if (options.optional) return null;
  return null;
}

function compact(text) {
  return String(text || "").replace(/\s+/g, "");
}

function spacedRegex(text) {
  return compact(text).split("").map(escapeRegex).join("\\s*");
}

function escapeRegex(char) {
  return char.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function isMediaTask(task) {
  return task.type === "image" || task.type === "sticker" || task.type === "video";
}

async function validatePreviewPayloadForCreate(task, index) {
  const label = `第 ${index + 1} 条 / ${task.role || ""} / ${task.speaker || ""} / ${task.time || ""} / ${task.type || ""}`;
  if (task.type === "text") {
    const text = String(task.text || "");
    if (!normalizePayloadText(text)) {
      throw new Error(`${label} 创建前校验失败：预览文字为空，已停止，避免创建空任务。`);
    }
    return;
  }
  if (isMediaTask(task)) {
    const filePath = String(task.imagePath || "").trim();
    if (!filePath) {
      throw new Error(`${label} 创建前校验失败：预览素材路径为空，已停止，避免漏发。`);
    }
    try {
      await fs.access(filePath);
    } catch {
      throw new Error(`${label} 创建前校验失败：素材文件不存在：${filePath}`);
    }
  }
}

function previewPayloadSummary(task) {
  if (task.type === "text") return `文字 ${normalizePayloadText(task.text).length} 字：${compactSummary(task.text)}`;
  if (task.type === "image") return `图片：${task.imagePath || ""}`;
  if (task.type === "sticker") return `表情包：${task.imagePath || ""}`;
  if (task.type === "video") return `视频：${task.imagePath || ""}`;
  return `类型：${task.type || ""}`;
}

function normalizePayloadText(text) {
  return String(text || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n").trim();
}

function textMatchesExpected(actualText, expectedText) {
  const actual = normalizePayloadText(actualText);
  const expected = normalizePayloadText(expectedText);
  if (actual === expected) return true;
  const actualCompact = compact(actual);
  const expectedCompact = compact(expected);
  return Boolean(expectedCompact && actualCompact.includes(expectedCompact));
}

function tuoRobotKey(task) {
  if (task.robotGroup !== undefined && task.robotGroup !== null) return `robot:${task.robotGroup}`;
  if (task.interactionGroup !== undefined && task.interactionGroup !== null) return `interaction:${task.interactionGroup}`;
  return `speaker:${task.speaker}`;
}

function buildRoleUsageRank(rows, currentRoleName = "") {
  const rank = {};
  for (const [index, row] of rows.entries()) {
    if (!row.roleName) continue;
    rank[row.roleName] = index + 1;
  }
  if (currentRoleName) rank[currentRoleName] = Number.MAX_SAFE_INTEGER;
  return rank;
}

function roleUsageRow(task, index) {
  return {
    createdAt: new Date().toISOString(),
    roleName: task.fixedRoleName || "",
    taskIndex: String(index + 1),
    speaker: task.speaker || "",
    robotGroup: task.robotGroup === undefined || task.robotGroup === null ? "" : String(task.robotGroup),
    time: task.time || "",
    originalTime: task.originalTime || "",
    type: task.type || "",
    kind: classifyUsageKind(task),
    summary: task.text ? compactSummary(task.text) : task.imagePath || task.assetUrl || ""
  };
}

function classifyUsageKind(task) {
  if (task.type === "sticker") return "表情包";
  if (task.type === "video") return "视频";
  if (task.type === "image") return "图片";
  const text = task.text || "";
  if (/吗|么|嘛|怎么样|好不好|适合|可以|能不能|有没有|问下|请问/.test(text)) return "疑问";
  if (/买了|拍了|下单|订单|付款|入手/.test(text)) return "订单/购买";
  if (/实拍|晒|到了|收到|反馈|好用|不错|喝了|用了/.test(text)) return "反馈";
  return "文字";
}

function compactSummary(text) {
  return String(text || "").replace(/\s+/g, " ").trim().slice(0, 120);
}

function roleUsageFile(config) {
  return config.roleUsageFile || "./role-usage-log.csv";
}

async function loadRoleUsage(config) {
  try {
    const text = await fs.readFile(roleUsageFile(config), "utf8");
    const lines = text.split(/\r?\n/).filter(Boolean);
    if (lines.length <= 1) return [];
    const headers = parseCsvLine(lines[0]);
    return lines.slice(1).map((line) => {
      const values = parseCsvLine(line);
      return Object.fromEntries(headers.map((key, index) => [key, values[index] || ""]));
    });
  } catch {
    return [];
  }
}

async function appendRoleUsage(config, row) {
  const file = roleUsageFile(config);
  const headers = ["createdAt", "roleName", "taskIndex", "speaker", "robotGroup", "time", "originalTime", "type", "kind", "summary"];
  let exists = true;
  try {
    await fs.access(file);
  } catch {
    exists = false;
  }
  const line = headers.map((key) => csvEscape(row[key] || "")).join(",") + "\n";
  if (!exists) {
    await fs.writeFile(file, headers.join(",") + "\n" + line, "utf8");
  } else {
    await fs.appendFile(file, line, "utf8");
  }
}

function csvEscape(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function parseCsvLine(line) {
  const result = [];
  let value = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (ch === '"' && inQuotes && line[i + 1] === '"') {
      value += '"';
      i += 1;
    } else if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === "," && !inQuotes) {
      result.push(value);
      value = "";
    } else {
      value += ch;
    }
  }
  result.push(value);
  return result;
}

function progressFile(config) {
  return config.progressFile || "./last-progress.json";
}

async function loadProgress(config) {
  if (config.resumeOnRun === false) return { completed: [] };
  try {
    return JSON.parse(await fs.readFile(progressFile(config), "utf8"));
  } catch {
    return { completed: [] };
  }
}

async function saveProgress(config, progress) {
  if (config.resumeOnRun === false) return;
  await fs.writeFile(progressFile(config), JSON.stringify(progress, null, 2), "utf8");
}

async function clearProgress(config) {
  if (config.resumeOnRun === false) return;
  await fs.rm(progressFile(config), { force: true });
}

function taskKey(task, index) {
  return [index, task.role, task.scheduleDateKey || "today", task.time, task.type].join("|");
}

async function checkpointControl(control, label = "") {
  if (!control?.checkpoint) return;
  await control.checkpoint(String(label || "").replace(/^：/, ""));
}

async function waitWithControl(page, ms, control = null, label = "") {
  const total = Math.max(0, Number(ms) || 0);
  if (!control?.checkpoint || total <= 0) {
    await page.waitForTimeout(total);
    return;
  }
  const endAt = Date.now() + total;
  while (Date.now() < endAt) {
    await checkpointControl(control, label);
    await page.waitForTimeout(Math.min(250, Math.max(0, endAt - Date.now())));
  }
  await checkpointControl(control, label);
}

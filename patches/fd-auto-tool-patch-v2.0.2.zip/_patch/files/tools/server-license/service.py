#!/usr/bin/env python3
import argparse
import datetime as dt
import hashlib
import html
import ipaddress
import json
import os
import secrets
import socket
import tempfile
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ACTIONS = {"launch", "generate-preview", "prepare-cms", "start-cms", "cli-start-cms"}
REQUEST_ACTION = "request-access"
LIMITS = {"companyId": 64, "deviceId": 128, "appVersion": 32, "action": 32}
MAX_BODY = 4096
INTERNAL_NETS = [ipaddress.ip_network("10.0.0.0/8")]


def now_iso():
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def result(allowed, code, message):
    return {"allowed": allowed, "code": code, "message": message}


def load_json(path, fallback):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return fallback


def atomic_write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def device_ref(device_id):
    return hashlib.sha256(str(device_id).encode()).hexdigest()[:12]


def read_policy(server):
    if server.policy_path.stat().st_size > 65536:
        raise RuntimeError("policy too large")
    return json.loads(server.policy_path.read_text(encoding="utf-8"))


def write_policy(server, policy):
    backup = server.policy_path.with_name(f"policy.json.bak-{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}")
    try:
        backup.write_text(server.policy_path.read_text(encoding="utf-8"), encoding="utf-8")
    except FileNotFoundError:
        pass
    atomic_write_json(server.policy_path, policy)


def check(payload, policy, now=None):
    if not isinstance(payload, dict) or set(payload) != set(LIMITS):
        return 400, result(False, "INVALID_REQUEST", "授权请求格式错误。")
    if any(not isinstance(payload[k], str) or not payload[k].strip() or len(payload[k]) > size for k, size in LIMITS.items()):
        return 400, result(False, "INVALID_REQUEST", "授权请求格式错误。")
    if payload["action"] not in ACTIONS:
        return 400, result(False, "INVALID_ACTION", "该操作不在授权范围内。")
    if not isinstance(policy, dict) or policy.get("enabled") is not True or payload["companyId"] != policy.get("companyId"):
        return 403, result(False, "COMPANY_DENIED", "公司授权未配置。")
    device = policy.get("devices", {}).get(payload["deviceId"])
    if not isinstance(device, dict) or device.get("enabled") is not True:
        return 403, result(False, "DEVICE_DENIED", "设备未授权，请点击申请授权。")
    if payload["appVersion"] in policy.get("blockedVersions", []):
        return 403, result(False, "VERSION_BLOCKED", "当前版本已停用，请更新后再使用。")
    if payload["action"] not in device.get("actions", []):
        return 403, result(False, "ACTION_DENIED", "该设备未授权执行此操作。")
    expiry = device.get("expiresAt")
    if expiry is not None:
        try:
            end = dt.datetime.fromisoformat(expiry.replace("Z", "+00:00"))
            if end.tzinfo is None:
                raise ValueError("timezone required")
            expired = end <= (now or dt.datetime.now(dt.timezone.utc))
        except (ValueError, TypeError, AttributeError):
            return 403, result(False, "EXPIRY_INVALID", "授权有效期配置错误，请联系管理员。")
        if expired:
            return 403, result(False, "EXPIRED", "设备授权已过期。")
    response = result(True, "ALLOWED", "授权通过。")
    response["company"] = str(policy.get("company", ""))[:64]
    return 200, response


def validate_request_payload(payload, policy):
    if not isinstance(payload, dict):
        return "授权申请格式错误。"
    required = {"companyId", "deviceId", "appVersion", "action"}
    if not required.issubset(set(payload)) or payload.get("action") != REQUEST_ACTION:
        return "授权申请格式错误。"
    if payload.get("companyId") != policy.get("companyId"):
        return "公司授权未配置。"
    for key, size in LIMITS.items():
        if key == "action":
            continue
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > size:
            return "授权申请格式错误。"
    computer = payload.get("computerName", "")
    if computer is not None and (not isinstance(computer, str) or len(computer) > 80):
        return "电脑名称格式错误。"
    return ""


def record_request(server, payload, source_ip):
    policy = read_policy(server)
    reason = validate_request_payload(payload, policy)
    if reason:
        return 400, {"allowed": False, "code": "INVALID_REQUEST", "message": reason}
    device_id = payload["deviceId"]
    device = policy.get("devices", {}).get(device_id)
    if isinstance(device, dict) and device.get("enabled") is True:
        return 200, {"allowed": True, "code": "ALREADY_ALLOWED", "message": "这台电脑已授权。"}
    requests = load_json(server.requests_path, {"requests": {}})
    items = requests.setdefault("requests", {})
    previous = items.get(device_id, {}) if isinstance(items.get(device_id), dict) else {}
    ts = now_iso()
    items[device_id] = {
        "deviceId": device_id,
        "deviceRef": device_ref(device_id),
        "computerName": str(payload.get("computerName") or "")[:80],
        "appVersion": str(payload.get("appVersion") or "")[:32],
        "sourceIp": source_ip,
        "status": "pending",
        "requestedAt": previous.get("requestedAt") or ts,
        "updatedAt": ts,
    }
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "request", "deviceRef": device_ref(device_id), "computerName": items[device_id]["computerName"], "sourceIp": source_ip})
    return 200, {"allowed": False, "code": "REQUEST_RECORDED", "message": "授权申请已提交，请等待管理员审批。"}


def append_audit(server, event):
    event = {"time": now_iso(), **event}
    with server.audit_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")


def authorized_admin(server, handler, query=None):
    query = query or parse_qs(urlparse(handler.path).query)
    token = (query.get("token") or [""])[0]
    if not token or not secrets.compare_digest(token, server.admin_token):
        return False
    try:
        ip = ipaddress.ip_address(handler.client_address[0])
        return any(ip in net for net in INTERNAL_NETS)
    except ValueError:
        return False


def pending_items(server):
    requests = load_json(server.requests_path, {"requests": {}}).get("requests", {})
    if not isinstance(requests, dict):
        return []
    return sorted(requests.values(), key=lambda item: item.get("updatedAt", ""), reverse=True)


def approve_device(server, device_id, admin="web"):
    if not isinstance(device_id, str) or len(device_id) > 128:
        return False, "设备号格式错误。"
    policy = read_policy(server)
    policy.setdefault("devices", {})[device_id] = {
        "enabled": True,
        "actions": sorted(ACTIONS),
        "expiresAt": None,
    }
    write_policy(server, policy)
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {"deviceId": device_id, "deviceRef": device_ref(device_id)})
    item["status"] = "approved"
    item["approvedAt"] = now_iso()
    item["updatedAt"] = item["approvedAt"]
    item["approvedBy"] = admin
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "approve", "deviceRef": device_ref(device_id), "admin": admin})
    return True, "已通过授权。"


def reject_device(server, device_id, admin="web"):
    requests = load_json(server.requests_path, {"requests": {}})
    item = requests.setdefault("requests", {}).setdefault(device_id, {"deviceId": device_id, "deviceRef": device_ref(device_id)})
    item["status"] = "rejected"
    item["rejectedAt"] = now_iso()
    item["updatedAt"] = item["rejectedAt"]
    item["rejectedBy"] = admin
    atomic_write_json(server.requests_path, requests)
    append_audit(server, {"event": "reject", "deviceRef": device_ref(device_id), "admin": admin})
    return True, "已拒绝申请。"


class Handler(BaseHTTPRequestHandler):
    server_version = "License"
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(1.0)

    def log_message(self, *_):
        pass

    def reply(self, status, body, content_type="application/json; charset=utf-8"):
        raw = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(raw)
        self.close_connection = True

    def read_json(self):
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            raise ValueError("content-type")
        length_header = self.headers.get_all("Content-Length", [])
        if len(length_header) != 1 or self.headers.get("Transfer-Encoding"):
            raise ValueError("length")
        length = int(length_header[0])
        if length <= 0 or length > MAX_BODY:
            raise OverflowError()
        deadline = time.monotonic() + 0.8
        data = bytearray()
        while len(data) < length:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError()
            self.connection.settimeout(remaining)
            part = self.rfile.read1(length - len(data))
            if not part:
                raise ValueError("incomplete")
            data.extend(part)
        return json.loads(data)

    def source_ip(self):
        forwarded = self.headers.get("X-Forwarded-For", "").split(",", 1)[0].strip()
        return forwarded or self.client_address[0]

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/admin/api/requests":
            query = parse_qs(parsed.query)
            if not authorized_admin(self.server, self, query):
                self.reply(403, result(False, "ADMIN_DENIED", "无权查看授权总控。"))
                return
            self.reply(200, {"ok": True, "requests": pending_items(self.server)})
            return
        if parsed.path == "/admin":
            query = parse_qs(parsed.query)
            if not authorized_admin(self.server, self, query):
                self.reply(403, b"Forbidden", "text/plain; charset=utf-8")
                return
            token = html.escape((query.get("token") or [""])[0], quote=True)
            page = ADMIN_PAGE.replace("__TOKEN__", token).encode("utf-8")
            self.reply(200, page, "text/html; charset=utf-8")
            return
        self.reply(404, result(False, "NOT_FOUND", "授权接口不存在。"))

    do_HEAD = do_GET
    do_PUT = do_GET
    do_DELETE = do_GET
    do_OPTIONS = do_GET

    def do_POST(self):
        try:
            parsed = urlparse(self.path)
            if parsed.path.startswith("/admin/api/"):
                payload = self.read_json()
                token = {"token": [payload.get("token", "")]}
                if not authorized_admin(self.server, self, token):
                    self.reply(403, result(False, "ADMIN_DENIED", "无权操作授权总控。"))
                    return
                device_id = payload.get("deviceId", "")
                if parsed.path == "/admin/api/approve":
                    ok, message = approve_device(self.server, device_id)
                elif parsed.path == "/admin/api/reject":
                    ok, message = reject_device(self.server, device_id)
                else:
                    self.reply(404, result(False, "NOT_FOUND", "授权接口不存在。"))
                    return
                self.reply(200 if ok else 400, {"ok": ok, "message": message})
                return
            if parsed.path != "/license/check":
                self.do_GET()
                return
            if ipaddress.ip_address(self.client_address[0]) not in self.server.gateway_ips:
                self.reply(403, result(False, "SOURCE_DENIED", "请通过公司授权网关访问。"))
                return
            payload = self.read_json()
            if isinstance(payload, dict) and payload.get("action") == REQUEST_ACTION:
                status, body = record_request(self.server, payload, self.source_ip())
                self.reply(status, body)
                return
            policy = read_policy(self.server)
            status, body = check(payload, policy)
            self.reply(status, body)
            record = {
                "action": payload.get("action") if isinstance(payload, dict) and payload.get("action") in ACTIONS else "invalid",
                "version": payload.get("appVersion") if isinstance(payload, dict) and isinstance(payload.get("appVersion"), str) else "invalid",
                "allowed": body["allowed"],
                "code": body["code"],
            }
            if isinstance(payload, dict) and isinstance(payload.get("deviceId"), str):
                record["deviceRef"] = device_ref(payload["deviceId"])
            print(json.dumps(record, ensure_ascii=False), flush=True)
        except OverflowError:
            self.reply(413, result(False, "BODY_SIZE", "授权请求大小不符合要求。"))
        except (socket.timeout, TimeoutError):
            self.reply(408, result(False, "REQUEST_TIMEOUT", "授权请求超时。"))
        except (ValueError, UnicodeError, json.JSONDecodeError):
            self.reply(400, result(False, "INVALID_REQUEST", "授权请求格式错误。"))
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            self.reply(503, result(False, "SERVICE_UNAVAILABLE", "授权服务暂不可用。"))


ADMIN_PAGE = """<!doctype html><meta charset="utf-8"><title>授权总控</title>
<style>body{font-family:Arial,"Microsoft YaHei",sans-serif;margin:24px;background:#f6f8fb;color:#122033}table{border-collapse:collapse;width:100%;background:#fff}td,th{border:1px solid #d8e2f0;padding:8px;text-align:left}button{min-height:32px;margin-right:8px}.pending{color:#b45309;font-weight:700}.approved{color:#166534;font-weight:700}.rejected{color:#b91c1c;font-weight:700}</style>
<h1>妙券授权总控</h1><p>只处理设备授权，不启动发单流程。</p><button onclick="load()">刷新</button>
<table><thead><tr><th>状态</th><th>电脑名</th><th>版本</th><th>来源</th><th>申请时间</th><th>设备号</th><th>操作</th></tr></thead><tbody id="rows"></tbody></table>
<script>
const token="__TOKEN__";
async function api(path,body){const opt=body?{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({...body,token})}:{};const r=await fetch(path+(body?"":"?token="+encodeURIComponent(token)),opt);return r.json();}
async function load(){const data=await api("/admin/api/requests");rows.innerHTML=(data.requests||[]).map(x=>`<tr><td class="${x.status}">${x.status||""}</td><td>${x.computerName||""}</td><td>${x.appVersion||""}</td><td>${x.sourceIp||""}</td><td>${x.requestedAt||""}</td><td style="font-family:monospace;word-break:break-all">${x.deviceId||""}</td><td><button onclick="approve('${x.deviceId}')">通过</button><button onclick="rejectReq('${x.deviceId}')">拒绝</button></td></tr>`).join("");}
async function approve(id){await api("/admin/api/approve",{deviceId:id});load();}
async function rejectReq(id){await api("/admin/api/reject",{deviceId:id});load();}
load();
</script>"""


def ensure_admin_token(path):
    path = Path(path)
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    token = secrets.token_urlsafe(24)
    path.write_text(token + "\n", encoding="utf-8")
    os.chmod(path, 0o640)
    return token


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bind", required=True)
    parser.add_argument("--port", type=int, default=8093)
    parser.add_argument("--policy", required=True)
    parser.add_argument("--gateway", action="append", required=True)
    args = parser.parse_args()
    policy_path = Path(args.policy)
    server = ThreadingHTTPServer((args.bind, args.port), Handler)
    server.daemon_threads = True
    server.policy_path = policy_path
    server.requests_path = policy_path.with_name("requests.json")
    server.audit_path = policy_path.with_name("audit.log")
    server.admin_token_path = policy_path.with_name("admin-token")
    server.admin_token = ensure_admin_token(server.admin_token_path)
    server.gateway_ips = {ipaddress.ip_address(v) for v in args.gateway}
    server.serve_forever()


if __name__ == "__main__":
    main()

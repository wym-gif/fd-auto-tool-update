import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import dns from "node:dns/promises";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { TRUSTED_LICENSE_SERVERS, LICENSE_COMPANY_ID } from "./license-policy.js";

const ACTION_LABELS = {
  launch: "启动程序",
  "generate-preview": "生成预览",
  "prepare-cms": "进入云中客设置",
  "start-cms": "正式发单",
  "cli-start-cms": "CLI 正式发单"
};
const MAX_BYTES = 4096;
const REQUEST_ACCESS_ACTION = "request-access";
const HEARTBEAT_ACTION = "heartbeat";

let deviceId;
export function getDeviceId() {
  if (deviceId) return deviceId;
  let identity = `${os.platform()}|${os.hostname().toLowerCase()}`;
  if (os.platform() === "win32") {
    identity = `windows|${readWindowsMachineGuid()}`;
  }
  deviceId = createHash("sha256").update(`miaoquan-device-v1|${identity}`).digest("hex");
  return deviceId;
}

function readWindowsMachineGuid() {
  const regArgs = ["query", "HKLM\\SOFTWARE\\Microsoft\\Cryptography", "/v", "MachineGuid"];
  for (const timeout of [3000, 8000]) {
    try {
      const output = execFileSync("reg.exe", regArgs, { encoding: "utf8", timeout, windowsHide: true });
      const match = output.match(/MachineGuid\s+REG_SZ\s+([0-9a-f-]+)/i);
      if (match) return match[1].toLowerCase();
    } catch {}
  }
  try {
    const ps = [
      "-NoProfile",
      "-ExecutionPolicy", "Bypass",
      "-Command",
      "(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Cryptography').MachineGuid"
    ];
    const output = execFileSync("powershell.exe", ps, { encoding: "utf8", timeout: 8000, windowsHide: true });
    const match = output.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    if (match) return match[0].toLowerCase();
  } catch {}
  throw new Error("无法读取本机设备标识，请联系管理员。");
}

function denied(message, state = "unauthorized") {
  return { enabled: true, allowed: false, state, company: "", expiresAt: "", message };
}
function safeMessage(body, fallback) {
  const value = body?.message || body?.reason;
  if (typeof value !== "string" || value.length > 160 || /[<>\r\n]/.test(value)) return fallback;
  return value.trim() || fallback;
}

export async function getLicenseStatus(projectRoot, options = {}) {
  const action = options.action || "launch";
  if (!Object.hasOwn(ACTION_LABELS, action)) return denied("授权操作不受支持。");
  let config, version;
  try {
    config = options.licenseConfig || JSON.parse(await fs.readFile(options.licensePath || path.join(projectRoot, "license.json"), "utf8"));
    version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  } catch {
    return denied("授权配置缺失或损坏，请联系管理员。", "not_configured");
  }
  if (!config || config.enabled !== true || config.mode !== "apisix-intranet" || config.companyId !== LICENSE_COMPANY_ID) {
    return denied("公司授权未正确配置，请联系管理员。", "not_configured");
  }
  let endpoint;
  try {
    endpoint = new URL(config.licenseServer);
    if (endpoint.protocol !== "https:" || endpoint.username || endpoint.password || endpoint.search || endpoint.hash
      || !TRUSTED_LICENSE_SERVERS.includes(endpoint.href)) throw new Error();
  } catch {
    return denied("授权服务地址未获批准，请联系管理员。", "not_configured");
  }
  if (typeof version !== "string" || !version.trim() || version.length > 32) return denied("程序版本信息无效。");
  const timeoutMs = Number(config.timeoutMs ?? 3000);
  if (!Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 3000) return denied("授权等待时间配置无效。");
  const controller = new AbortController();
  let timedOut = false;
  let timer;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(() => { timedOut = true; controller.abort(); reject(new Error("deadline")); }, timeoutMs);
  });
  const request = async () => {
    const response = await (options.fetch || globalThis.fetch)(endpoint, {
      method: "POST", redirect: "error", cache: "no-store", signal: controller.signal,
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({ companyId: LICENSE_COMPANY_ID, deviceId: getDeviceId(), appVersion: version, action })
    });
    if (Number(response.headers.get("content-length")) > MAX_BYTES) throw new Error("size");
    const reader = response.body?.getReader();
    if (!reader) throw new Error("empty");
    let size = 0;
    const chunks = [];
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > MAX_BYTES) throw new Error("size");
        chunks.push(Buffer.from(value));
      }
    } finally {
      void reader.cancel().catch(() => {});
    }
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("shape");
    if (response.status !== 200 || body.allowed !== true) return denied(safeMessage(body, "公司授权未通过，请联系管理员。"));
    return { enabled: true, allowed: true, state: "authorized", company: typeof body.company === "string" ? body.company.slice(0, 64) : "", expiresAt: "", message: "授权通过。" };
  };
  try {
    return await Promise.race([request(), deadline]);
  } catch {
    return denied(timedOut ? "授权检查超时，请连接公司网络或 VPN 后再试。" : "无法确认公司授权，请检查公司网络或 VPN。", "unavailable");
  } finally {
    clearTimeout(timer);
    controller.abort();
  }
}

export async function getLicenseDiagnostics(projectRoot, options = {}) {
  const diagnostics = {
    deviceId: "",
    computerName: os.hostname(),
    dns: { ok: false, expected: "10.6.1.250", addresses: [], message: "" },
    service: { ok: false, message: "" },
    license: null
  };
  try {
    diagnostics.deviceId = getDeviceId();
  } catch (error) {
    diagnostics.service.message = error?.message || "无法读取本机设备标识。";
    diagnostics.license = denied(diagnostics.service.message, "device_unavailable");
    return diagnostics;
  }
  try {
    const records = await dns.resolve4("api.qzmq.cn");
    diagnostics.dns.addresses = records;
    diagnostics.dns.ok = records.includes(diagnostics.dns.expected);
    diagnostics.dns.message = diagnostics.dns.ok
      ? "授权域名解析正常。"
      : `授权域名解析异常，当前返回：${records.join(", ") || "-"}`;
  } catch {
    diagnostics.dns.message = "授权域名无法解析，请检查公司网络或 DNS。";
  }
  diagnostics.license = await getLicenseStatus(projectRoot, options);
  diagnostics.service.ok = diagnostics.license.state !== "unavailable";
  diagnostics.service.message = diagnostics.service.ok ? "授权服务已响应。" : diagnostics.license.message;
  return diagnostics;
}

export async function submitLicenseRequest(projectRoot, options = {}) {
  const config = await readLicenseConfig(projectRoot, options);
  const endpoint = trustedEndpoint(config);
  const version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  const payload = {
    companyId: LICENSE_COMPANY_ID,
    deviceId: getDeviceId(),
    appVersion: version,
    action: REQUEST_ACCESS_ACTION,
    computerName: os.hostname()
  };
  const body = await postLicenseJson(endpoint, payload, Number(config.timeoutMs ?? 3000), options);
  return {
    ok: body.code === "REQUEST_RECORDED" || body.code === "ALREADY_ALLOWED",
    deviceId: payload.deviceId,
    message: safeMessage(body, "授权申请已提交。"),
    code: body.code || ""
  };
}

export async function submitLicenseHeartbeat(projectRoot, options = {}) {
  const config = await readLicenseConfig(projectRoot, options);
  const endpoint = trustedEndpoint(config);
  const version = options.appVersion || JSON.parse(await fs.readFile(path.join(projectRoot, "package.json"), "utf8")).version;
  const payload = {
    companyId: LICENSE_COMPANY_ID,
    deviceId: getDeviceId(),
    appVersion: String(version || "").slice(0, 32),
    action: HEARTBEAT_ACTION,
    computerName: os.hostname(),
    update: sanitizeHeartbeatUpdate(options.updateStatus || {})
  };
  const body = await postLicenseJson(endpoint, payload, Number(config.timeoutMs ?? 3000), options);
  return {
    ok: body.code === "HEARTBEAT_RECORDED" || body.allowed === true,
    deviceId: payload.deviceId,
    message: safeMessage(body, "心跳已上报。"),
    code: body.code || ""
  };
}

async function readLicenseConfig(projectRoot, options = {}) {
  try {
    const config = options.licenseConfig || JSON.parse(await fs.readFile(options.licensePath || path.join(projectRoot, "license.json"), "utf8"));
    if (!config || config.enabled !== true || config.mode !== "apisix-intranet" || config.companyId !== LICENSE_COMPANY_ID) {
      throw new Error("bad config");
    }
    return config;
  } catch {
    const error = new Error("授权配置缺失或损坏，请联系管理员。");
    error.statusCode = 400;
    throw error;
  }
}

function trustedEndpoint(config) {
  const endpoint = new URL(config.licenseServer);
  if (endpoint.protocol !== "https:" || endpoint.username || endpoint.password || endpoint.search || endpoint.hash
    || !TRUSTED_LICENSE_SERVERS.includes(endpoint.href)) {
    const error = new Error("授权服务地址未获批准，请联系管理员。");
    error.statusCode = 400;
    throw error;
  }
  return endpoint;
}

function sanitizeHeartbeatUpdate(update = {}) {
  return {
    currentVersion: typeof update.currentVersion === "string" ? update.currentVersion.slice(0, 32) : "",
    latestVersion: typeof update.latestVersion === "string" ? update.latestVersion.slice(0, 32) : "",
    updateAvailable: update.updateAvailable === true,
    pendingUpdateReady: update.pendingUpdateReady === true,
    updateMode: typeof update.updateMode === "string" ? update.updateMode.slice(0, 16) : "",
    status: typeof update.status === "string" ? update.status.slice(0, 32) : ""
  };
}

async function postLicenseJson(endpoint, payload, timeoutMs, options = {}) {
  if (!Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 3000) throw new Error("授权等待时间配置无效。");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await (options.fetch || globalThis.fetch)(endpoint, {
      method: "POST",
      redirect: "error",
      cache: "no-store",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    });
    const text = await response.text();
    return JSON.parse(text || "{}");
  } finally {
    clearTimeout(timer);
    controller.abort();
  }
}

export async function assertCompanyAccessAllowed(projectRoot, action, options = {}) {
  const status = await getLicenseStatus(projectRoot, { ...options, action });
  if (!status.allowed) {
    const error = new Error(`当前未授权，不能${ACTION_LABELS[action] || "使用核心功能"}：${status.message}`);
    error.code = "LICENSE_DENIED";
    error.statusCode = 403;
    error.license = status;
    throw error;
  }
  return status;
}

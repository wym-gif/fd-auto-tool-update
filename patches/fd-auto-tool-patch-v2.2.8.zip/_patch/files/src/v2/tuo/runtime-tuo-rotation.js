import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

const STATE_FILE = "precise-tuo-runtime.json";
const STATE_VERSION = 1;

export async function createPreciseTuoRuntimeRotation({ runDir, plan = [], submitSnapshot = null } = {}) {
  const preciseTasks = plan.filter(isPreciseTask);
  if (!preciseTasks.length) return emptyRuntime();
  const planFingerprint = fingerprintPlan(preciseTasks);
  const allCandidates = uniqueCandidates(preciseTasks.flatMap(rotationPoolForTask));
  const allKeys = new Set(allCandidates.map(candidateKey).filter(Boolean));
  const manualReservations = new Map();
  for (const task of preciseTasks) {
    if (!task.tuoAssignment?.manualLocked) continue;
    const key = candidateKey(task.tuoAssignment.primary);
    if (key) manualReservations.set(key, preciseGroupKey(task));
  }
  const statePath = path.join(runDir, STATE_FILE);
  let state = await loadState(statePath, planFingerprint);
  if (!state) state = emptyState(planFingerprint);

  const taskByIdentity = new Map();
  for (const task of preciseTasks) {
    taskByIdentity.set(taskIdentity(task), task);
    taskByIdentity.set(`index:${Number(task.index || 0)}`, task);
  }
  for (const record of Object.values(submitSnapshot?.tasks || {}).sort((a, b) => Number(a?.index || 0) - Number(b?.index || 0))) {
    if (record?.status !== "succeeded") continue;
    const task = taskByIdentity.get(record.taskKey) || taskByIdentity.get(`index:${Number(record.index || 0)}`);
    if (!isPreciseTask(task)) continue;
    rememberSuccess(state, task, candidateFromRecord(record, task), record.taskKey || taskIdentity(task), allKeys);
  }
  await saveState(statePath, state);

  return {
    prepareTask(task) {
      if (!isPreciseTask(task)) return { changed: false, round: state.round };
      const assignment = task.tuoAssignment;
      const groupKey = preciseGroupKey(task);
      const pool = uniqueCandidates(rotationPoolForTask(task)).filter((candidate) => {
        const reservedGroup = manualReservations.get(candidateKey(candidate));
        return !reservedGroup || reservedGroup === groupKey;
      });
      const binding = state.groupBindings[groupKey];
      if (assignment.manualLocked) {
        applyCandidateOrder(task, [assignment.primary].filter(Boolean));
        return { changed: false, round: state.round, bound: true, candidateCount: 1 };
      }

      if (!binding && allKeys.size && [...allKeys].every((key) => state.usedAccountKeys.includes(key))) {
        state.round += 1;
        state.usedAccountKeys = [];
      }

      const used = new Set(state.usedAccountKeys);
      const boundCandidate = binding ? findCandidate(pool, binding) || binding : null;
      const available = pool.filter((candidate) => !used.has(candidateKey(candidate)));
      const ordered = uniqueCandidates([
        ...(boundCandidate ? [boundCandidate] : []),
        ...preferCurrentOrder(task, available)
      ]);
      if (!ordered.length) throw roundExhaustedError(task, state.round);
      applyCandidateOrder(task, ordered);
      return {
        changed: candidateKey(ordered[0]) !== candidateKey(assignment.primary),
        round: state.round,
        bound: Boolean(boundCandidate),
        candidateCount: ordered.length
      };
    },

    async recordSuccess(task, selected, recordIdentity = "") {
      if (!isPreciseTask(task)) return null;
      const rawCandidate = selected || task.tuoAssignment.runtimeSelected || task.tuoAssignment.primary;
      const candidate = resolveCandidate(rotationPoolForTask(task), rawCandidate);
      const changed = rememberSuccess(state, task, candidate, recordIdentity || taskIdentity(task), allKeys);
      if (changed) await saveState(statePath, state);
      return candidate;
    },

    snapshot() {
      return structuredClone(state);
    }
  };
}

function emptyRuntime() {
  return {
    prepareTask() {
      return null;
    },
    async recordSuccess() {
      return null;
    },
    snapshot() {
      return null;
    }
  };
}

function rememberSuccess(state, task, selected, recordIdentity, allKeys) {
  const key = candidateKey(selected);
  if (!key || state.recordedTaskKeys.includes(recordIdentity)) return false;
  if (allKeys.size && [...allKeys].every((accountKey) => state.usedAccountKeys.includes(accountKey))) {
    state.round += 1;
    state.usedAccountKeys = [];
  }
  if (!state.usedAccountKeys.includes(key)) state.usedAccountKeys.push(key);
  state.groupBindings[preciseGroupKey(task)] = { ...selected };
  state.recordedTaskKeys.push(recordIdentity);
  state.updatedAt = new Date().toISOString();
  return true;
}

function applyCandidateOrder(task, ordered) {
  const primary = ordered[0];
  if (!primary) return;
  task.speaker = primary.nickname || task.speaker;
  task.cleanSpeaker = String(primary.nickname || task.cleanSpeaker || task.speaker || "").replace(/\s+/g, "");
  task.tuoAssignment = {
    ...task.tuoAssignment,
    primary: { ...primary },
    candidates: ordered.slice(1).map((candidate) => ({ ...candidate }))
  };
}

function preferCurrentOrder(task, pool) {
  const wanted = [task.tuoAssignment?.primary, ...(task.tuoAssignment?.candidates || []), ...pool];
  const poolKeys = new Set(pool.map(candidateKey));
  return uniqueCandidates(wanted).filter((candidate) => poolKeys.has(candidateKey(candidate)));
}

function rotationPoolForTask(task) {
  const assignment = task?.tuoAssignment || {};
  return Array.isArray(assignment.rotationCandidates) && assignment.rotationCandidates.length
    ? assignment.rotationCandidates
    : [assignment.primary, ...(assignment.candidates || [])].filter(Boolean);
}

function uniqueCandidates(candidates = []) {
  const seen = new Set();
  const result = [];
  for (const candidate of candidates) {
    const key = candidateKey(candidate);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    result.push({ ...candidate });
  }
  return result;
}

function findCandidate(candidates, wanted) {
  const key = candidateKey(wanted);
  return candidates.find((candidate) => candidateKey(candidate) === key);
}

function resolveCandidate(candidates, wanted) {
  return findCandidate(candidates, wanted)
    || candidates.find((candidate) => candidate.nickname && candidate.nickname === wanted?.nickname)
    || wanted;
}

function candidateFromRecord(record, task) {
  const pool = rotationPoolForTask(task);
  const key = String(record.accountId || record.externalAccountId || "");
  const matched = pool.find((candidate) => candidateKey(candidate) === key)
    || pool.find((candidate) => candidate.nickname === record.actualRobotNickname);
  return matched || {
    scopeId: record.scopeId || task.tuoAssignment.scopeId || "",
    accountId: record.accountId || "",
    externalAccountId: record.externalAccountId || "",
    cmsAccountIdentity: record.cmsAccountIdentity || "",
    nickname: record.actualRobotNickname || task.speaker || ""
  };
}

function candidateKey(candidate = {}) {
  return String(candidate.accountId || candidate.externalAccountId || candidate.cmsAccountIdentity || candidate.nickname || "").trim().toLowerCase();
}

function preciseGroupKey(task) {
  return String(task?.tuoAssignment?.groupKey || taskIdentity(task));
}

function taskIdentity(task) {
  return `${Number(task?.index || 0)}:${String(task?.sourceId || "")}`;
}

function isPreciseTask(task) {
  return task?.role === "tuo" && task?.tuoAssignment?.mode === "precise_roster";
}

function roundExhaustedError(task, round) {
  const error = new Error(`第 ${task?.index || "?"} 条当前人设可用托已在第 ${round} 轮实际使用完，但整轮尚未完成；已暂停，请人工选择符合人设且本轮未使用的托。`);
  error.code = "PRECISE_TUO_RUNTIME_ROUND_EXHAUSTED";
  return error;
}

function fingerprintPlan(tasks) {
  const summary = tasks.map((task) => ({
    identity: taskIdentity(task),
    groupKey: preciseGroupKey(task),
    candidates: rotationPoolForTask(task).map(candidateKey)
  }));
  return crypto.createHash("sha256").update(JSON.stringify(summary)).digest("hex");
}

function emptyState(planFingerprint) {
  return {
    version: STATE_VERSION,
    planFingerprint,
    round: 1,
    usedAccountKeys: [],
    groupBindings: {},
    recordedTaskKeys: [],
    updatedAt: new Date().toISOString()
  };
}

async function loadState(statePath, planFingerprint) {
  let parsed;
  try {
    parsed = JSON.parse(await fs.readFile(statePath, "utf8"));
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw corruptStateError("精准托运行时轮换记录已损坏，不能安全判断本轮已使用托号。", error);
  }
  if (parsed?.version !== STATE_VERSION || !Array.isArray(parsed.usedAccountKeys) || !Array.isArray(parsed.recordedTaskKeys) || !parsed.groupBindings) {
    throw corruptStateError("精准托运行时轮换记录格式无效，不能安全判断本轮已使用托号。");
  }
  if (parsed.planFingerprint !== planFingerprint) return null;
  return parsed;
}

function corruptStateError(message, cause) {
  const error = new Error(message, cause ? { cause } : undefined);
  error.code = "PRECISE_TUO_RUNTIME_STATE_CORRUPT";
  return error;
}

async function saveState(statePath, state) {
  await fs.mkdir(path.dirname(statePath), { recursive: true });
  const tempPath = `${statePath}.${process.pid}.tmp`;
  await fs.writeFile(tempPath, `${JSON.stringify(state, null, 2)}\n`, "utf8");
  try {
    await fs.rename(tempPath, statePath);
  } catch (error) {
    if (!["EEXIST", "EPERM"].includes(error?.code)) throw error;
    await fs.rm(statePath, { force: true });
    await fs.rename(tempPath, statePath);
  }
}

import { inferTuoIntent } from "./tuo-intent.js";
import { normalizeRosterKey } from "./tuo-roster.js";

const DEFAULT_COOLDOWN = 5;
const DEFAULT_MAIN_COOLDOWN = 0;
const DEFAULT_BACKUP_COOLDOWN = 0;
const DEFAULT_VISIBLE_BACKUP_COUNT = 2;
const DEFAULT_CANDIDATE_COUNT = 3;
const GENERIC_PERSONA_TAGS = new Set(["female", "male"]);
const STRICT_PERSONA_TAGS = new Set(["mom", "work", "student", "young", "mature", "married", "female", "male"]);
const AGE_STAGE_TAGS = new Set(["student", "young", "mature"]);
const GENDER_TAGS = new Set(["female", "male"]);

export function assignPreciseTuoSpeakers(tasks = [], roster = [], options = {}) {
  const cooldown = Number.isFinite(Number(options.cooldown)) ? Number(options.cooldown) : DEFAULT_COOLDOWN;
  const candidateCount = Math.max(1, Number(options.candidateCount || DEFAULT_CANDIDATE_COUNT));
  const rotationOffset = rosterRotationOffset(roster, options.rotationSeed);
  const previousCooldownKeys = new Set((options.previousCooldownNicknames || [])
    .map((name) => normalizeRosterKey(name))
    .filter(Boolean));
  const recentByPersona = new Map();
  const usedCounts = new Map();
  const backupRotation = new Map();
  const candidateDisplayCounts = new Map();
  const displayedCandidatePairs = new Set();
  const runtimeCooldown = createRuntimeCooldown(options);
  const usageHistory = options.usageHistory?.accounts || options.usageHistory || {};
  const groupAssignments = new Map();
  const assignments = [];
  const nextTasks = tasks.map((task, index) => {
    if (task?.role !== "tuo") return task;
    const groupKey = preciseTuoGroupKey(task);
    const intent = inferTuoIntent(task);
    const existing = groupKey ? groupAssignments.get(groupKey) : null;
    const shouldReuseExisting = existing?.item && shouldReusePreciseGroup(existing, intent, groupKey);
    if (shouldReuseExisting) {
      assignments.push({
        index: task.index || index + 1,
        sourceId: task.sourceId || "",
        previousSpeaker: task.speaker || "",
        assignedSpeaker: existing.item.nickname,
        remark: existing.item.remark,
        reason: existing.groupReason,
        fallback: existing.fallback,
        backup: existing.item.backup,
        tags: existing.intent?.tags || intent.tags,
        candidateSpeakers: existing.candidates.map((item) => item.nickname),
        groupKey
      });
      return applyTuoAssignment(task, existing.item, existing.candidates, existing.intent || intent, {
        reason: existing.groupReason,
        fallback: existing.fallback,
        cooldown,
        mainCooldown: runtimeCooldown.mainCooldown,
        backupCooldown: runtimeCooldown.backupCooldown,
        visibleBackupCount: runtimeCooldown.visibleBackupCount,
        cooldownKey: existing.cooldownKey,
        groupKey,
        candidateShortageReason: existing.candidateShortageReason,
        candidateRotationNote: existing.candidateRotationNote
      });
    }
    advanceRuntimeCooldown(runtimeCooldown);
    const decision = chooseRosterItem(roster, intent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster,
      rotationOffset,
      previousCooldownKeys,
      backupRotation,
      runtimeCooldown,
      usageHistory
    });
    if (!decision.item) {
      assignments.push({
        index: task.index || index + 1,
        sourceId: task.sourceId || "",
        previousSpeaker: task.speaker || "",
        assignedSpeaker: "",
        reason: "没有可用托名单候选",
        fallback: true,
        backup: false,
        tags: intent.tags
      });
      return task;
    }
    const candidateIntent = candidateIntentForPrimary(intent, decision.item);
    const candidates = chooseRosterCandidates(roster, candidateIntent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster,
      rotationOffset,
      previousCooldownKeys,
      backupRotation,
      runtimeCooldown,
      usageHistory,
      candidateDisplayCounts,
      displayedCandidatePairs,
      limit: candidateCount,
      visibleBackupCount: runtimeCooldown.visibleBackupCount,
      primaryNickname: decision.item.nickname,
      primaryAccountId: decision.item.accountId
    });
    const candidateShortageReason = describeCandidateShortage(roster, candidateIntent, decision.item, candidates, {
      runtimeCooldown,
      visibleBackupCount: runtimeCooldown.visibleBackupCount
    });
    const candidateRotationNote = displayedPairReuseNote(decision.item, candidates, {
      displayedCandidatePairs,
      visibleBackupCount: runtimeCooldown.visibleBackupCount
    });
    const cooldownKey = rememberUse(decision.item, intent, {
      recentByPersona,
      usedCounts,
      cooldown,
      roster,
      rotationOffset,
      previousCooldownKeys,
      backupRotation
    });
    rememberDisplayedCandidates(decision.item, candidates, {
      candidateDisplayCounts,
      displayedCandidatePairs,
      visibleBackupCount: runtimeCooldown.visibleBackupCount
    });
    rememberRuntimePreciseSelection(decision.item, candidates, {
      runtimeCooldown,
      visibleBackupCount: runtimeCooldown.visibleBackupCount
    });
    const regroupedReason = existing?.item && groupKey && !shouldReuseExisting
      ? `同一原始托出现更明确人设，重新分配：${decision.reason}`
      : decision.reason;
    assignments.push({
      index: task.index || index + 1,
      sourceId: task.sourceId || "",
      previousSpeaker: task.speaker || "",
      assignedSpeaker: decision.item.nickname,
      remark: decision.item.remark,
      reason: regroupedReason,
      fallback: decision.fallback,
      backup: decision.item.backup,
      tags: intent.tags,
      candidateSpeakers: candidates.map((item) => item.nickname),
      candidateShortageReason,
      candidateRotationNote,
      cooldownKey,
      groupKey
    });
    if (groupKey) {
      groupAssignments.set(groupKey, {
        item: decision.item,
        candidates,
        candidateShortageReason,
        candidateRotationNote,
        fallback: decision.fallback,
        cooldownKey,
        intent,
        groupReason: groupKey.startsWith("interaction:")
          ? `复用同一互动托分配：${decision.reason}`
          : `复用同一原始托分配：${decision.reason}`
      });
    }
    return applyTuoAssignment(task, decision.item, candidates, intent, {
      reason: regroupedReason,
      fallback: decision.fallback,
      cooldown,
      mainCooldown: runtimeCooldown.mainCooldown,
      backupCooldown: runtimeCooldown.backupCooldown,
      visibleBackupCount: runtimeCooldown.visibleBackupCount,
      cooldownKey,
      groupKey,
      candidateShortageReason,
      candidateRotationNote
    });
  });

  const globallyAllocated = allocatePreciseBackupCandidates(nextTasks, roster, assignments, {
    candidateCount,
    cooldown,
    rotationOffset,
    previousCooldownKeys,
    usageHistory,
    visibleBackupCount: runtimeCooldown.visibleBackupCount
  });

  return {
    tasks: attachRuntimeRotationCandidates(globallyAllocated.tasks, roster),
    report: buildAssignmentReport(globallyAllocated.assignments, roster, {
      previousCooldownCount: previousCooldownKeys.size,
      rotationOffset,
      mainCooldown: runtimeCooldown.mainCooldown,
      backupCooldown: runtimeCooldown.backupCooldown,
      visibleBackupCount: runtimeCooldown.visibleBackupCount
    })
  };
}

export function assignPreciseTuoTargets(tasks = [], roster = [], targetIndexes = [], options = {}) {
  const nextTasks = (Array.isArray(tasks) ? tasks : []).map((task) => ({
    ...task,
    ...(task?.tuoAssignment ? {
      tuoAssignment: {
        ...task.tuoAssignment,
        ...(task.tuoAssignment.primary ? { primary: { ...task.tuoAssignment.primary } } : {}),
        ...(Array.isArray(task.tuoAssignment.candidates)
          ? { candidates: task.tuoAssignment.candidates.map((item) => ({ ...item })) }
          : {}),
        ...(Array.isArray(task.tuoAssignment.rotationCandidates)
          ? { rotationCandidates: task.tuoAssignment.rotationCandidates.map((item) => ({ ...item })) }
          : {})
      }
    } : {})
  }));
  const indexes = [...new Set((Array.isArray(targetIndexes) ? targetIndexes : [])
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value >= 0 && value < nextTasks.length))];
  const targetSet = new Set(indexes);
  const manualLockedSet = new Set((Array.isArray(options.manualLockedIndexes) ? options.manualLockedIndexes : [])
    .map((value) => Number(value))
    .filter((value) => targetSet.has(value)));
  const rosterItems = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!indexes.length) return { tasks: nextTasks, assignedIndexes: [] };
  if (!rosterItems.length) throw targetedAssignmentError("精准托名单为空，不能给新改成托的内容分配托号。");

  const existingByGroup = new Map();
  const occupiedGroupsByAccount = new Map();
  for (const [index, task] of nextTasks.entries()) {
    if (targetSet.has(index) || task?.role !== "tuo" || task?.tuoAssignment?.mode !== "precise_roster") continue;
    const groupKey = targetedPreciseGroupKey(task, index);
    existingByGroup.set(groupKey, task);
    rememberTargetedOccupiedAccount(occupiedGroupsByAccount, task.tuoAssignment.primary, groupKey);
  }

  const pending = [];
  const assignedIndexes = [];
  for (const index of indexes) {
    const task = nextTasks[index];
    if (task?.role !== "tuo") throw targetedAssignmentError(`第 ${index + 1} 条不是托角色，不能执行精准托分配。`);
    if (task?.tuoAssignment?.mode === "precise_roster" && accountKey(task.tuoAssignment.primary)) {
      rememberTargetedOccupiedAccount(occupiedGroupsByAccount, task.tuoAssignment.primary, targetedPreciseGroupKey(task, index));
      continue;
    }
    const groupKey = targetedPreciseGroupKey(task, index);
    const existing = existingByGroup.get(groupKey);
    if (existing?.tuoAssignment?.primary) {
      nextTasks[index] = copyTargetedPreciseAssignment(task, existing);
      assignedIndexes.push(index);
      continue;
    }
    pending.push({ index, groupKey, manualLocked: manualLockedSet.has(index) });
  }

  const pendingByGroup = new Map();
  for (const item of pending) {
    const group = pendingByGroup.get(item.groupKey) || [];
    group.push(item);
    pendingByGroup.set(item.groupKey, group);
  }

  const automaticIndexes = [];
  for (const [groupKey, group] of pendingByGroup) {
    const manualGroup = group.filter((item) => item.manualLocked);
    if (!manualGroup.length) {
      automaticIndexes.push(...group.map((item) => item.index));
      continue;
    }
    const requestedNames = [...new Set(manualGroup.map((item) => normalizeRosterKey(nextTasks[item.index]?.speaker || "")).filter(Boolean))];
    if (requestedNames.length !== 1) {
      throw targetedAssignmentError(`手动补录的同组托号不一致，请为第 ${group.map((item) => item.index + 1).join("、")} 条选择同一个真实托号。`);
    }
    const matches = rosterItems.filter((item) => normalizeRosterKey(item.nickname) === requestedNames[0]);
    if (matches.length !== 1) {
      const reason = matches.length ? "名单中存在同昵称账号，无法确定具体托号" : "填写的昵称不在当前精准托名单中";
      throw targetedAssignmentError(`第 ${manualGroup[0].index + 1} 条${reason}，请从托号名单中重新选择。`);
    }
    const selected = matches[0];
    const foreignGroups = occupiedGroupsByAccount.get(accountKey(selected)) || new Set();
    if ([...foreignGroups].some((key) => key !== groupKey)) {
      throw targetedAssignmentError(`手动选择的托“${selected.nickname}”已被其他说话人占用，请选择其他托号。`);
    }
    const allowedRoster = rosterItems.filter((item) => {
      const groups = occupiedGroupsByAccount.get(accountKey(item));
      return accountKey(item) === accountKey(selected) || !groups?.size || groups.has(groupKey);
    });
    const sampleTask = nextTasks[manualGroup[0].index];
    const intent = candidateIntentForPrimary(inferTuoIntent(sampleTask), selected);
    const candidates = chooseRosterCandidates(allowedRoster, intent, {
      roster: allowedRoster,
      limit: Math.max(1, Number(options.candidateCount || DEFAULT_CANDIDATE_COUNT)),
      visibleBackupCount: Number(options.visibleBackupCount ?? DEFAULT_VISIBLE_BACKUP_COUNT),
      primaryNickname: selected.nickname,
      primaryAccountId: selected.accountId,
      candidateDisplayCounts: new Map(),
      displayedCandidatePairs: new Set()
    });
    const assigned = applyTuoAssignment(sampleTask, selected, candidates, intent, {
      reason: "用户手动补录并锁定托号",
      fallback: false,
      groupKey,
      visibleBackupCount: Number(options.visibleBackupCount ?? DEFAULT_VISIBLE_BACKUP_COUNT)
    });
    assigned.tuoAssignment = { ...assigned.tuoAssignment, manualLocked: true, selectionSource: "manual" };
    for (const item of group) {
      nextTasks[item.index] = copyTargetedPreciseAssignment(nextTasks[item.index], assigned);
      assignedIndexes.push(item.index);
    }
    existingByGroup.set(groupKey, assigned);
    rememberTargetedOccupiedAccount(occupiedGroupsByAccount, selected, groupKey);
  }

  if (automaticIndexes.length) {
    const availableRoster = rosterItems.filter((item) => !(occupiedGroupsByAccount.get(accountKey(item))?.size));
    const automaticTasks = automaticIndexes.map((index) => nextTasks[index]);
    const automatic = assignPreciseTuoSpeakers(automaticTasks, availableRoster, options);
    for (const [position, index] of automaticIndexes.entries()) {
      const assigned = automatic.tasks[position];
      if (assigned?.tuoAssignment?.mode !== "precise_roster" || !accountKey(assigned.tuoAssignment.primary)) {
        throw targetedAssignmentError(`第 ${index + 1} 条没有符合人设且未被占用的托号，请补充托名单或手动选择。`);
      }
      const groupKey = targetedPreciseGroupKey(assigned, index);
      const foreignGroups = occupiedGroupsByAccount.get(accountKey(assigned.tuoAssignment.primary)) || new Set();
      if ([...foreignGroups].some((key) => key !== groupKey)) {
        throw targetedAssignmentError(`第 ${index + 1} 条只能重复使用其他说话人的托“${assigned.speaker}”，本次未保存，请补充托名单或手动选择。`);
      }
      nextTasks[index] = assigned;
      assignedIndexes.push(index);
      rememberTargetedOccupiedAccount(occupiedGroupsByAccount, assigned.tuoAssignment.primary, groupKey);
    }
  }

  return {
    tasks: attachRuntimeRotationCandidates(nextTasks, rosterItems),
    assignedIndexes: [...new Set(assignedIndexes)].sort((a, b) => a - b)
  };
}

function targetedPreciseGroupKey(task = {}, index = 0) {
  const saved = String(task?.tuoAssignment?.groupKey || "").trim();
  return saved || preciseTuoGroupKey(task) || `task:${index + 1}`;
}

function rememberTargetedOccupiedAccount(map, candidate, groupKey) {
  const key = accountKey(candidate);
  if (!key) return;
  const groups = map.get(key) || new Set();
  groups.add(groupKey);
  map.set(key, groups);
}

function copyTargetedPreciseAssignment(task = {}, assigned = {}) {
  const primary = assigned?.tuoAssignment?.primary || {};
  return {
    ...task,
    speaker: primary.nickname || assigned.speaker || task.speaker || "",
    cleanSpeaker: String(primary.nickname || assigned.cleanSpeaker || assigned.speaker || task.cleanSpeaker || task.speaker || "").replace(/\s+/g, ""),
    tuoAssignment: {
      ...assigned.tuoAssignment,
      primary: { ...primary },
      candidates: Array.isArray(assigned?.tuoAssignment?.candidates)
        ? assigned.tuoAssignment.candidates.map((item) => ({ ...item }))
        : [],
      rotationCandidates: Array.isArray(assigned?.tuoAssignment?.rotationCandidates)
        ? assigned.tuoAssignment.rotationCandidates.map((item) => ({ ...item }))
        : []
    }
  };
}

function attachRuntimeRotationCandidates(tasks = [], roster = []) {
  return tasks.map((task) => {
    if (task?.role !== "tuo" || task?.tuoAssignment?.mode !== "precise_roster") return task;
    const intent = {
      tags: [...(task.tuoAssignment.intentTags || [])],
      requiredTags: [...(task.tuoAssignment.requiredIntentTags || [])],
      reasons: [...(task.tuoAssignment.intentReasons || [])]
    };
    const primary = task.tuoAssignment.primary;
    const compatible = runtimeCompatibleRoster(roster, intent);
    const ordered = uniqueRosterCandidates([primary, ...compatible]);
    return {
      ...task,
      tuoAssignment: {
        ...task.tuoAssignment,
        rotationCandidates: ordered.map(serializeCandidate)
      }
    };
  });
}

function runtimeCompatibleRoster(roster = [], intent = {}) {
  const required = new Set(intent.requiredTags || []);
  const inferred = new Set(intent.tags || []);
  const broadMom = required.has("mom") || inferred.has("mom");
  const broadWork = required.has("work") || inferred.has("work");
  const strictPersona = ["student", "young", "mature"].find((tag) => required.has(tag));
  return (Array.isArray(roster) ? roster : [])
    .filter((item) => item?.nickname)
    .filter((item) => {
      const tags = new Set(item.tags || []);
      if (required.has("male") && !tags.has("male")) return false;
      if (required.has("female") && tags.has("male") && !tags.has("female")) return false;
      if (strictPersona) return candidateMatchesIntent(item, { requiredTags: [...required] });
      if (broadMom) return !tags.has("male") && ["mom", "mature", "married"].some((tag) => tags.has(tag));
      if (broadWork) return !tags.has("male") && ["work", "young", "mature", "mom", "married"].some((tag) => tags.has(tag));
      if (required.has("male") || required.has("female")) return candidateMatchesIntent(item, { requiredTags: [...required] });
      return true;
    })
    .sort((left, right) => Number(Boolean(left.backup)) - Number(Boolean(right.backup)) || Number(left.order || 0) - Number(right.order || 0));
}

function uniqueRosterCandidates(candidates = []) {
  const seen = new Set();
  const result = [];
  for (const candidate of candidates) {
    const key = accountKey(candidate);
    if (!candidate?.nickname || !key || seen.has(key)) continue;
    seen.add(key);
    result.push(candidate);
  }
  return result;
}

function targetedAssignmentError(message) {
  const error = new Error(message);
  error.code = "PRECISE_TUO_TARGET_ASSIGNMENT_FAILED";
  error.statusCode = 400;
  return error;
}

function allocatePreciseBackupCandidates(tasks = [], roster = [], assignments = [], options = {}) {
  const groups = [];
  const groupByKey = new Map();
  for (const [taskPosition, task] of tasks.entries()) {
    if (task?.role !== "tuo" || task?.tuoAssignment?.mode !== "precise_roster") continue;
    const key = candidateAllocationGroupKey(task, taskPosition);
    let group = groupByKey.get(key);
    if (!group) {
      group = {
        key,
        position: groups.length,
        taskPositions: [],
        primary: task.tuoAssignment.primary,
        intent: candidateIntentForPrimary({
          tags: [...(task.tuoAssignment.intentTags || [])],
          requiredTags: [...(task.tuoAssignment.requiredIntentTags || [])],
          reasons: [...(task.tuoAssignment.intentReasons || [])]
        }, task.tuoAssignment.primary)
      };
      groups.push(group);
      groupByKey.set(key, group);
    }
    group.taskPositions.push(taskPosition);
  }
  if (!groups.length) return { tasks, assignments };

  const primaryPositions = new Map();
  for (const group of groups) {
    const key = accountKey(group.primary);
    if (!key) continue;
    const positions = primaryPositions.get(key) || [];
    positions.push(group.position);
    primaryPositions.set(key, positions);
  }

  const candidateDisplayCounts = new Map();
  const displayedCandidatePairs = new Set();
  const candidateLastGroup = new Map();
  const candidatesByGroup = new Map();
  const notesByGroup = new Map();
  const shortageByGroup = new Map();
  const visibleBackupCount = Math.max(0, Number(options.visibleBackupCount ?? DEFAULT_VISIBLE_BACKUP_COUNT));
  const limit = Math.max(1 + visibleBackupCount, Number(options.candidateCount || DEFAULT_CANDIDATE_COUNT));

  for (const group of groups) {
    const primaryKey = accountKey(group.primary);
    const foreignPrimaryKeys = new Set(
      [...primaryPositions.entries()]
        .filter(([key, positions]) => key !== primaryKey || positions.some((position) => position !== group.position))
        .map(([key]) => key)
    );
    const candidates = chooseRosterCandidates(roster, group.intent, {
      recentByPersona: new Map(),
      usedCounts: new Map(),
      cooldown: options.cooldown,
      roster,
      rotationOffset: options.rotationOffset,
      previousCooldownKeys: options.previousCooldownKeys,
      runtimeCooldown: null,
      usageHistory: options.usageHistory,
      candidateDisplayCounts,
      displayedCandidatePairs,
      candidateLastGroup,
      primaryPositions,
      foreignPrimaryKeys,
      allocationGroupIndex: group.position,
      limit,
      visibleBackupCount,
      primaryNickname: group.primary?.nickname,
      primaryAccountId: group.primary?.accountId
    });
    const shortageReason = describeCandidateShortage(roster, group.intent, group.primary, candidates, {
      visibleBackupCount
    });
    const visible = visibleBackupCandidates(group.primary, candidates, visibleBackupCount);
    const foreignPrimaryCount = visible.filter((item) => foreignPrimaryKeys.has(accountKey(item))).length;
    const rotationNote = foreignPrimaryCount > 0
      ? `同人设候选不足以完全避开其他组主托，已优先选择距离更远且展示次数更少的 ${foreignPrimaryCount} 个候选`
      : displayedPairReuseNote(group.primary, candidates, {
          displayedCandidatePairs,
          visibleBackupCount
        });
    rememberDisplayedCandidates(group.primary, candidates, {
      candidateDisplayCounts,
      displayedCandidatePairs,
      candidateLastGroup,
      allocationGroupIndex: group.position,
      visibleBackupCount
    });
    candidatesByGroup.set(group.key, candidates.map(serializeCandidate));
    notesByGroup.set(group.key, rotationNote);
    shortageByGroup.set(group.key, shortageReason);
  }

  const nextTasks = tasks.map((task, taskPosition) => {
    if (task?.role !== "tuo" || task?.tuoAssignment?.mode !== "precise_roster") return task;
    const key = candidateAllocationGroupKey(task, taskPosition);
    return {
      ...task,
      tuoAssignment: {
        ...task.tuoAssignment,
        candidates: candidatesByGroup.get(key) || task.tuoAssignment.candidates,
        candidateShortageReason: shortageByGroup.get(key) || "",
        candidateRotationNote: notesByGroup.get(key) || ""
      }
    };
  });
  const nextAssignments = assignments.map((assignment) => {
    const key = candidateAllocationAssignmentKey(assignment);
    const candidates = candidatesByGroup.get(key);
    if (!candidates) return assignment;
    return {
      ...assignment,
      candidateSpeakers: candidates.map((item) => item.nickname),
      candidateShortageReason: shortageByGroup.get(key) || "",
      candidateRotationNote: notesByGroup.get(key) || ""
    };
  });
  return { tasks: nextTasks, assignments: nextAssignments };
}

function candidateAllocationGroupKey(task = {}, taskPosition = 0) {
  const groupKey = String(task?.tuoAssignment?.groupKey || "").trim();
  if (groupKey) return `group:${groupKey}`;
  const taskIndex = Number(task?.index);
  return `task:${Number.isInteger(taskIndex) && taskIndex > 0 ? taskIndex : taskPosition + 1}`;
}

function candidateAllocationAssignmentKey(assignment = {}) {
  const groupKey = String(assignment?.groupKey || "").trim();
  if (groupKey) return `group:${groupKey}`;
  return `task:${Math.max(1, Number(assignment?.index || 1))}`;
}

function applyTuoAssignment(task, item, candidates, intent, options = {}) {
  return {
    ...task,
    speaker: item.nickname,
    cleanSpeaker: item.nickname,
    tuoAssignment: buildTuoAssignment(item, candidates, intent, {
      reason: options.reason,
      fallback: options.fallback,
      cooldown: options.cooldown,
      mainCooldown: options.mainCooldown,
      backupCooldown: options.backupCooldown,
      visibleBackupCount: options.visibleBackupCount,
      cooldownKey: options.cooldownKey,
      groupKey: options.groupKey,
      candidateShortageReason: options.candidateShortageReason,
      candidateRotationNote: options.candidateRotationNote,
      scopeId: options.scopeId || item.scopeId || ""
    })
  };
}

function preciseTuoGroupKey(task = {}) {
  const speaker = originalTuoSpeakerKey(task);
  if (speaker) return `speaker:${speaker}`;
  const interactionGroup = String(task.interactionGroup || "").trim();
  return interactionGroup ? `interaction:${normalizeRosterKey(interactionGroup)}` : "";
}

function originalTuoSpeakerKey(task = {}) {
  const sourceSpeaker = normalizeRosterKey(task.sourceSpeaker || "");
  if (sourceSpeaker && !isGenericTuoSpeakerKey(sourceSpeaker)) return sourceSpeaker;
  const speaker = normalizeRosterKey(task.cleanSpeaker || task.speaker || "");
  if (!speaker || isGenericTuoSpeakerKey(speaker)) return "";
  return speaker;
}

function isGenericTuoSpeakerKey(key) {
  return ["托", "托号", "托儿", "水军", "互动托"].includes(key);
}

function shouldReusePreciseGroup(existing, intent, groupKey) {
  return Boolean(existing?.item && groupKey);
}

function specificIntentTags(intent = {}) {
  return (intent.tags || []).filter((tag) => !GENERIC_PERSONA_TAGS.has(tag));
}

function candidateIntentForPrimary(intent = {}, primary = {}) {
  const required = (intent.requiredTags || []).filter((tag) => STRICT_PERSONA_TAGS.has(tag));
  if (required.length) return intent;
  const preferred = (intent.tags || []).filter((tag) => STRICT_PERSONA_TAGS.has(tag));
  if (preferred.length) return { ...intent, requiredTags: preferred };
  const label = primary.personas?.[0] || "";
  const tags = personaTagsFromLabel(label);
  return tags.length ? { ...intent, tags, requiredTags: tags } : intent;
}

function personaTagsFromLabel(label) {
  const text = String(label || "").trim();
  const tags = [];
  if (/宝妈|妈妈|带娃|母婴/.test(text)) tags.push("mom");
  if (/工作|上班|职场|办公室/.test(text)) tags.push("work");
  if (/学生|大学生/.test(text)) tags.push("student");
  if (/成熟女性|成熟|中年|年纪大|4[0-9]\+|5[0-9]\+/.test(text)) tags.push("mature");
  if (/年轻女性|年轻|少女|2[5-9]\+/.test(text)) tags.push("young");
  if (/女性|女/.test(text)) tags.push("female");
  if (/男性|男/.test(text)) tags.push("male");
  return [...new Set(tags)];
}

export function chooseRosterItem(roster = [], intent = {}, context = {}) {
  const candidates = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!candidates.length) return { item: null, reason: "名单为空", fallback: true };
  const explicitKey = normalizeRosterKey(intent.explicitNickname);
  if (explicitKey) {
    const named = candidates.filter((item) => normalizeRosterKey(item.nickname) === explicitKey);
    if (named.length > 1) {
      const error = new Error(`指定托“${intent.explicitNickname}”存在 ${named.length} 个同昵称账号，缺少稳定账号身份，不能自动选择。`);
      error.code = "TUO_ACCOUNT_IDENTITY_AMBIGUOUS";
      throw error;
    }
    const exact = pickBest(named, intent, context, { allowBackup: true, runtimeKind: "primary" });
    if (exact) return { item: exact.item, reason: "按文案指定托分配", fallback: false };
  }

  const hasSpecificIntent = specificIntentTags(intent).length > 0;
  if (!hasSpecificIntent) {
    const anyAllowed = pickBest(candidates.filter((item) => !item.backup), intent, context, {
      allowBackup: false,
      ignoreTags: true,
      runtimeKind: "primary",
      strictRuntimeCooldown: true
    });
    if (anyAllowed) {
      return { item: anyAllowed.item, reason: "无身份线索，从当前允许使用托中兜底", fallback: true };
    }
    const reused = pickBest(candidates.filter((item) => !item.backup), intent, context, {
      allowBackup: false,
      ignoreTags: true,
      runtimeKind: "primary"
    });
    if (reused) {
      return { item: reused.item, reason: "无身份线索，全部托都在禁用期，兜底复用普通托", fallback: true };
    }
  }

  const requiredIntent = (intent.requiredTags || []).length > 0;
  const primaryPool = candidates.filter((item) => !item.backup && (!requiredIntent || candidateMatchesIntent(item, intent)));
  const primary = pickBest(primaryPool, intent, context, { allowBackup: false, runtimeKind: "primary" });
  if (primary && primary.score > 0) return { item: primary.item, reason: primary.reason, fallback: false };

  const specificFallback = pickBestSpecificCandidate(primaryPool, intent, context);
  if (specificFallback) {
    return {
      item: specificFallback.item,
      reason: `${specificFallback.reason}，同人设候选在冷却池内回退复用`,
      fallback: true
    };
  }

  if ((intent.requiredTags || []).length) {
    const compatibleBackup = pickBackupCandidate(candidates.filter((item) => candidateMatchesIntent(item, intent)), intent, context);
    if (compatibleBackup) return { item: compatibleBackup.item, reason: compatibleBackup.reason, fallback: true };
    return { item: null, reason: "没有符合明确身份条件的可用候选，不会跨人设自动分配", fallback: true };
  }

  const anyPrimary = pickBest(candidates.filter((item) => !item.backup), intent, context, { allowBackup: false, ignoreTags: true, runtimeKind: "primary", strictRuntimeCooldown: true });
  if (anyPrimary) return { item: anyPrimary.item, reason: "没有明显身份命中，按最少使用托兜底", fallback: true };

  const backup = pickBackupCandidate(candidates, intent, context);
  if (backup) return { item: backup.item, reason: backup.reason, fallback: true };
  return { item: null, reason: "没有可用候选", fallback: true };
}

export function chooseRosterCandidates(roster = [], intent = {}, context = {}) {
  const visibleCount = Math.max(0, Number(context.visibleBackupCount ?? DEFAULT_VISIBLE_BACKUP_COUNT));
  const limit = Math.max(1 + visibleCount, Number(context.limit || DEFAULT_CANDIDATE_COUNT));
  const candidates = Array.isArray(roster) ? roster.filter((item) => item?.nickname) : [];
  if (!candidates.length) return [];
  const primaryKey = String(context.primaryAccountId || normalizeRosterKey(context.primaryNickname));
  const exact = primaryKey ? candidates.find((item) => accountKey(item) === primaryKey) : null;
  const compatible = candidates.filter((item) => candidateMatchesIntent(item, intent));
  const ranked = rankRosterCandidates(compatible, intent, context, { allowBackup: true, runtimeKind: "candidate", strictRuntimeCooldown: true })
    .filter((entry) => accountKey(entry.item) !== primaryKey)
    .sort((left, right) => compareDisplayedCandidateEntries(left, right, intent, context));
  const foreignPrimaryKeys = context.foreignPrimaryKeys instanceof Set ? context.foreignPrimaryKeys : null;
  const unreserved = foreignPrimaryKeys
    ? ranked.filter((entry) => !foreignPrimaryKeys.has(accountKey(entry.item)))
    : ranked;
  const reserved = foreignPrimaryKeys
    ? ranked.filter((entry) => foreignPrimaryKeys.has(accountKey(entry.item)))
    : [];
  const candidatePool = unreserved.length >= visibleCount
    ? unreserved
    : [...unreserved, ...reserved];
  const visible = chooseDisplayedCandidatePair(candidatePool, visibleCount, context);
  const visibleKeys = new Set(visible.map((entry) => accountKey(entry.item)));
  const candidatePoolKeys = new Set(candidatePool.map((entry) => accountKey(entry.item)));
  const ordered = [
    ...(exact ? [exact] : []),
    ...visible.map((entry) => entry.item),
    ...candidatePool.filter((entry) => !visibleKeys.has(accountKey(entry.item))).map((entry) => entry.item),
    ...ranked.filter((entry) => !visibleKeys.has(accountKey(entry.item))
      && !candidatePoolKeys.has(accountKey(entry.item))).map((entry) => entry.item)
  ];
  const seen = new Set();
  const result = [];
  for (const item of ordered) {
    const key = accountKey(item);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    result.push(item);
    if (result.length >= limit) break;
  }
  return result;
}

function candidateMatchesIntent(item = {}, intent = {}) {
  const required = [...(intent.requiredTags || intent.tags || [])].filter((tag) => STRICT_PERSONA_TAGS.has(tag));
  if (required.includes("mom")) {
    const femaleIndex = required.indexOf("female");
    if (femaleIndex >= 0) required.splice(femaleIndex, 1);
  }
  if (!required.length) return true;
  const tags = new Set(item.tags || []);
  if (required.some((tag) => !tags.has(tag))) return false;
  if (required.includes("young") && tags.has("mature") && !tags.has("young")) return false;
  if (required.includes("mature") && tags.has("young") && !tags.has("mature")) return false;
  if (required.includes("student") && (tags.has("young") || tags.has("mature")) && !tags.has("student")) return false;
  if (required.includes("female") && tags.has("male") && !tags.has("female")) return false;
  if (required.includes("male") && tags.has("female") && !tags.has("male")) return false;
  return true;
}

function candidateMatchTier(item = {}, intent = {}) {
  const required = new Set((intent.tags || []).filter((tag) => STRICT_PERSONA_TAGS.has(tag)));
  const extras = (item.tags || []).filter((tag) => {
    if (!STRICT_PERSONA_TAGS.has(tag) || required.has(tag)) return false;
    if (GENDER_TAGS.has(tag) && (required.has("mom") || required.has("female"))) return false;
    return AGE_STAGE_TAGS.has(tag) || ["mom", "work", "student", "married"].includes(tag);
  }).length;
  const optional = (item.personas || []).some((label) => /^可/.test(String(label || "").trim()));
  return extras + (optional ? 2 : 0);
}

function compareDisplayedCandidateEntries(left, right, intent, context = {}) {
  const leftPrimaryDistance = distanceFromOtherPrimary(left.item, context);
  const rightPrimaryDistance = distanceFromOtherPrimary(right.item, context);
  if (leftPrimaryDistance !== rightPrimaryDistance) return rightPrimaryDistance - leftPrimaryDistance;
  const leftLastGroup = context.candidateLastGroup?.get(accountKey(left.item));
  const rightLastGroup = context.candidateLastGroup?.get(accountKey(right.item));
  const leftCandidateDistance = Number.isFinite(Number(leftLastGroup))
    ? Number(context.allocationGroupIndex || 0) - Number(leftLastGroup)
    : Number.MAX_SAFE_INTEGER;
  const rightCandidateDistance = Number.isFinite(Number(rightLastGroup))
    ? Number(context.allocationGroupIndex || 0) - Number(rightLastGroup)
    : Number.MAX_SAFE_INTEGER;
  if (leftCandidateDistance !== rightCandidateDistance) return rightCandidateDistance - leftCandidateDistance;
  const leftTier = candidateMatchTier(left.item, intent);
  const rightTier = candidateMatchTier(right.item, intent);
  if (leftTier !== rightTier) return leftTier - rightTier;
  const displayCounts = context.candidateDisplayCounts;
  const leftCount = displayCounts?.get(accountKey(left.item)) || 0;
  const rightCount = displayCounts?.get(accountKey(right.item)) || 0;
  if (leftCount !== rightCount) return leftCount - rightCount;
  if (right.score !== left.score) return right.score - left.score;
  return 0;
}

function distanceFromOtherPrimary(item = {}, context = {}) {
  const positions = context.primaryPositions?.get(accountKey(item)) || [];
  const current = Number(context.allocationGroupIndex || 0);
  const distances = positions
    .map((position) => Math.abs(Number(position) - current))
    .filter((distance) => distance > 0);
  return distances.length ? Math.min(...distances) : Number.MAX_SAFE_INTEGER;
}

function chooseDisplayedCandidatePair(ranked = [], visibleCount = DEFAULT_VISIBLE_BACKUP_COUNT, context = {}) {
  const limit = Math.min(Math.max(0, visibleCount), ranked.length);
  if (limit <= 1) return ranked.slice(0, limit);
  let best = null;
  for (let left = 0; left < ranked.length; left += 1) {
    for (let right = left + 1; right < ranked.length; right += 1) {
      const entries = [ranked[left], ranked[right]];
      const pairKey = candidatePairKey(entries.map((entry) => entry.item));
      const counts = entries.map((entry) => context.candidateDisplayCounts?.get(accountKey(entry.item)) || 0);
      const score = [context.displayedCandidatePairs?.has(pairKey) ? 1 : 0, Math.max(...counts), counts[0] + counts[1], left + right];
      if (!best || compareNumberTuple(score, best.score) < 0) best = { entries, score };
    }
  }
  return best?.entries || ranked.slice(0, limit);
}

function compareNumberTuple(left, right) {
  for (let index = 0; index < Math.max(left.length, right.length); index += 1) {
    const delta = Number(left[index] || 0) - Number(right[index] || 0);
    if (delta) return delta;
  }
  return 0;
}

function candidatePairKey(items = []) {
  return items.map((item) => accountKey(item)).filter(Boolean).sort().join("|");
}

function displayedPairReuseNote(primary, candidates = [], options = {}) {
  const visible = visibleBackupCandidates(primary, candidates, options.visibleBackupCount);
  if (visible.length < Math.max(0, Number(options.visibleBackupCount ?? DEFAULT_VISIBLE_BACKUP_COUNT))) return "";
  const pairKey = candidatePairKey(visible);
  return pairKey && options.displayedCandidatePairs?.has(pairKey)
    ? "同人设备选组合已轮换完，本条复用已有组合"
    : "";
}

function describeCandidateShortage(roster, intent, primary, candidates, options = {}) {
  const target = Math.max(0, Number(options.visibleBackupCount ?? DEFAULT_VISIBLE_BACKUP_COUNT));
  const shown = visibleBackupCandidates(primary, candidates, target).length;
  if (shown >= target) return "";
  const primaryKey = accountKey(primary);
  const compatible = (roster || []).filter((item) => item?.nickname
    && accountKey(item) !== primaryKey
    && candidateMatchesIntent(item, intent));
  const available = compatible.filter((item) => !runtimeCooldownActive(item, options.runtimeCooldown, "candidate"));
  if (!compatible.length) return "名单中没有其他符合当前人设的托，不会跨人设强行补足";
  const cooled = compatible.length - available.length;
  if (cooled > 0) {
    return `本轮仅有 ${shown} 个可用备选；另有 ${cooled} 个符合人设的托处于实际使用冷却`;
  }
  return `名单中仅有 ${shown} 个其他托符合当前人设，不会跨人设强行补足`;
}

function pickBest(candidates, intent, context, options = {}) {
  return rankRosterCandidates(candidates, intent, context, options)[0] || null;
}

function pickBestSpecificCandidate(candidates, intent, context) {
  const wanted = specificIntentTags(intent);
  if (!wanted.length) return null;
  return rankRosterCandidates(
    candidates.filter((item) => wanted.some((tag) => item.tags?.includes(tag))
      && (!(intent.requiredTags || []).length || candidateMatchesIntent(item, intent))),
    intent,
    context,
    { allowBackup: false, runtimeKind: "primary" }
  )[0] || null;
}

function pickBackupCandidate(candidates, intent, context = {}) {
  const backups = candidates.filter((item) => item.backup && item.nickname);
  if (!backups.length) return null;
  const wanted = specificIntentTags(intent);
  const pools = [];
  for (const tag of wanted) {
    pools.push({
      key: `tag:${tag}`,
      label: `备用托人设命中：${tag}`,
      items: backups.filter((item) => item.tags?.includes(tag))
    });
  }
  pools.push({ key: "backup:all", label: "主名单不可用，使用备用托兜底", items: backups });
  for (const pool of pools) {
    const picked = pickUnusedBackupFromPool(pool.items, intent, context, pool.key, { allowReset: false });
    if (picked) return { item: picked, reason: pool.label };
  }
  for (const pool of pools) {
    const picked = pickUnusedBackupFromPool(pool.items, intent, context, pool.key, { allowReset: true });
    if (picked) return { item: picked, reason: `${pool.label}，备用池已用完后进入新一轮` };
  }
  return null;
}

function pickUnusedBackupFromPool(items, intent, context = {}, poolKey, options = {}) {
  const candidates = rankRosterCandidates(items, intent, context, {
    allowBackup: true,
    allowBackupPenalty: false,
    runtimeKind: "primary",
    strictRuntimeCooldown: !options.allowReset
  });
  if (!candidates.length) return null;
  const state = backupPoolState(context.backupRotation, poolKey);
  const globalState = backupPoolState(context.backupRotation, "backup:all");
  const validKeys = new Set(candidates.map((entry) => accountKey(entry.item)).filter(Boolean));
  for (const key of [...state.used]) {
    if (!validKeys.has(key)) state.used.delete(key);
  }
  let fresh = candidates.filter((entry) => {
    const key = accountKey(entry.item);
    return !state.used.has(key) && !globalState.used.has(key);
  });
  if (!fresh.length) {
    if (!options.allowReset) return null;
    state.used.clear();
    if (poolKey === "backup:all") globalState.used.clear();
    fresh = candidates;
  }
  const picked = fresh[0]?.item || null;
  const pickedKey = accountKey(picked);
  if (pickedKey) {
    state.used.add(pickedKey);
    globalState.used.add(pickedKey);
  }
  return picked;
}

function backupPoolState(rotation, key) {
  if (!rotation || typeof rotation.get !== "function") return { used: new Set() };
  const normalized = key || "backup:all";
  if (!rotation.has(normalized)) rotation.set(normalized, { used: new Set() });
  return rotation.get(normalized);
}

function rankRosterCandidates(candidates, intent, context, options = {}) {
  const total = Math.max(1, Number(context.roster?.length || candidates.length || 1));
  const offset = Number(context.rotationOffset || 0);
  const ranked = candidates
    .filter((item) => options.allowBackup || !item.backup)
    .map((item) => scoreCandidate(item, intent, context, options))
    .filter((item) => item.score > -1000)
    .sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      const planned = comparePlannedAndActualUse(left.item, right.item, context);
      if (planned) return planned;
      return rotatedOrder(left.item.order, offset, total) - rotatedOrder(right.item.order, offset, total);
    });
  return ranked;
}

function scoreCandidate(item, intent, context, options = {}) {
  const used = context.usedCounts?.get(accountKey(item)) || 0;
  const previousCooldown = context.previousCooldownKeys?.has(normalizeRosterKey(item.nickname));
  const recent = recentNicknamesForCandidate(item, intent, context).includes(item.nickname);
  const wantedTags = options.ignoreTags ? [] : intent.tags || [];
  let score = options.ignoreTags ? 1 : 0;
  const matched = [];
  for (const tag of wantedTags) {
    if (item.tags?.includes(tag)) {
      score += tag === "female" || tag === "male" ? 1 : 4;
      if (item.compatibleCategories?.includes(tag) && !item.exactCategories?.includes(tag)) score -= 2;
      matched.push(tag);
    }
  }
  if (!options.ignoreTags && wantedTags.includes("young") && item.tags?.includes("mature") && !item.tags?.includes("young")) {
    score -= 6;
  }
  if (!options.ignoreTags && wantedTags.length && !matched.length) score -= 2;
  if (recent) score -= 1;
  if (previousCooldown) score -= 1;
  if (item.backup && options.allowBackupPenalty !== false) score -= 20;
  return {
    item,
    score,
    used,
    reason: matched.length ? `身份命中：${matched.join("/")}` : "按最少使用托兜底"
  };
}

function comparePlannedAndActualUse(left, right, context = {}) {
  const runtime = context.runtimeCooldown;
  const leftKey = accountKey(left);
  const rightKey = accountKey(right);
  const leftPlannedAt = runtime?.mainLast?.get(leftKey);
  const rightPlannedAt = runtime?.mainLast?.get(rightKey);
  const leftPlanned = Number.isFinite(Number(leftPlannedAt));
  const rightPlanned = Number.isFinite(Number(rightPlannedAt));
  if (leftPlanned !== rightPlanned) return leftPlanned ? 1 : -1;
  if (leftPlanned && Number(leftPlannedAt) !== Number(rightPlannedAt)) return Number(leftPlannedAt) - Number(rightPlannedAt);
  const leftHistory = context.usageHistory?.[leftKey] || {};
  const rightHistory = context.usageHistory?.[rightKey] || {};
  const leftLast = Number.isFinite(Number(leftHistory.lastSequence)) ? Number(leftHistory.lastSequence) : -1;
  const rightLast = Number.isFinite(Number(rightHistory.lastSequence)) ? Number(rightHistory.lastSequence) : -1;
  if (leftLast !== rightLast) return leftLast - rightLast;
  const leftPlannedCount = context.usedCounts?.get(leftKey) || 0;
  const rightPlannedCount = context.usedCounts?.get(rightKey) || 0;
  if (leftPlannedCount !== rightPlannedCount) return leftPlannedCount - rightPlannedCount;
  const leftActual = Number(leftHistory.successCount || 0);
  const rightActual = Number(rightHistory.successCount || 0);
  return leftActual - rightActual;
}

function rotatedOrder(order = 0, offset = 0, total = 1) {
  const base = Math.max(0, Number(order || 0));
  const count = Math.max(1, Number(total || 1));
  return (base - Number(offset || 0) + count) % count;
}

function rosterRotationOffset(roster = [], seed = "") {
  const count = Array.isArray(roster) ? roster.filter((item) => item?.nickname).length : 0;
  if (!count) return 0;
  const text = String(seed || "");
  if (!text) return 0;
  let hash = 0;
  for (let index = 0; index < text.length; index += 1) {
    hash = ((hash * 31) + text.charCodeAt(index)) >>> 0;
  }
  return hash % count;
}

function rememberUse(item, intent, context) {
  const nickname = item?.nickname || "";
  if (!nickname) return "";
  const key = cooldownKeyForCandidate(item, intent);
  const identity = accountKey(item);
  context.usedCounts.set(identity, (context.usedCounts.get(identity) || 0) + 1);
  for (const cooldownKey of cooldownKeysForUsedCandidate(item, intent, key)) {
    rememberRecentNickname(cooldownKey, nickname, context);
  }
  return key;
}

function cooldownKeysForUsedCandidate(item = {}, intent = {}, primaryKey = "") {
  const keys = new Set([primaryKey || cooldownKeyForCandidate(item, intent)]);
  for (const tag of item.tags || []) {
    if (!GENERIC_PERSONA_TAGS.has(tag)) keys.add(`tag:${tag}`);
  }
  const personas = Array.isArray(item.personas) ? item.personas : [];
  for (const persona of personas) {
    const key = normalizeRosterKey(persona);
    if (key) keys.add(`persona:${key}`);
  }
  keys.add("all");
  return [...keys].filter(Boolean);
}

function rememberRecentNickname(key, nickname, context = {}) {
  const recentByPersona = context.recentByPersona;
  if (!recentByPersona || !key || !nickname) return;
  const recent = recentByPersona.get(key) || [];
  const existingIndex = recent.indexOf(nickname);
  if (existingIndex >= 0) recent.splice(existingIndex, 1);
  const limit = cooldownLimitForKey(context.roster, key, context.cooldown);
  recent.push(nickname);
  while (recent.length > limit) recent.shift();
  recentByPersona.set(key, recent);
}

function createRuntimeCooldown(options = {}) {
  const mainCooldown = 0;
  const backupCooldown = DEFAULT_BACKUP_COOLDOWN;
  const visibleBackupCount = positiveInteger(options.visibleBackupCount, DEFAULT_VISIBLE_BACKUP_COUNT);
  return {
    sequence: 0,
    mainCooldown,
    backupCooldown,
    visibleBackupCount,
    mainLast: new Map()
  };
}

function positiveInteger(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? Math.floor(number) : fallback;
}

function advanceRuntimeCooldown(runtimeCooldown) {
  if (!runtimeCooldown) return;
  runtimeCooldown.sequence += 1;
}

function rememberRuntimePreciseSelection(primary, candidates = [], options = {}) {
  const runtimeCooldown = options.runtimeCooldown;
  if (!runtimeCooldown) return;
  const primaryKey = accountKey(primary);
  if (primaryKey) {
    runtimeCooldown.mainLast.set(primaryKey, runtimeCooldown.sequence);
  }
}

function rememberDisplayedCandidates(primary, candidates = [], options = {}) {
  const visible = visibleBackupCandidates(primary, candidates, options.visibleBackupCount);
  for (const item of visible) {
    const key = accountKey(item);
    if (!key) continue;
    options.candidateDisplayCounts?.set(key, (options.candidateDisplayCounts.get(key) || 0) + 1);
    if (options.candidateLastGroup && Number.isFinite(Number(options.allocationGroupIndex))) {
      options.candidateLastGroup.set(key, Number(options.allocationGroupIndex));
    }
  }
  const pairKey = candidatePairKey(visible);
  if (pairKey) options.displayedCandidatePairs?.add(pairKey);
}

function visibleBackupCandidates(primary, candidates = [], visibleBackupCount = DEFAULT_VISIBLE_BACKUP_COUNT) {
  const primaryKey = accountKey(primary);
  const limit = Math.max(0, Number(visibleBackupCount || 0));
  const result = [];
  const seen = new Set();
  for (const item of candidates || []) {
    const key = accountKey(item);
    if (!key || key === primaryKey || seen.has(key)) continue;
    seen.add(key);
    result.push(item);
    if (result.length >= limit) break;
  }
  return result;
}

function runtimeCooldownActive(item, runtimeCooldown, kind = "candidate") {
  return false;
}

function recentNicknamesForCandidate(item, intent, context = {}) {
  if (context.recentByPersona) {
    return context.recentByPersona.get(cooldownKeyForCandidate(item, intent)) || [];
  }
  return context.recentNicknames || [];
}

function cooldownLimitForKey(roster = [], key, fallback) {
  const explicit = Number(fallback);
  if (Number.isFinite(explicit) && explicit > 0 && explicit !== DEFAULT_COOLDOWN) return Math.max(1, explicit);
  const count = roster.filter((item) => item?.nickname && candidateMatchesCooldownKey(item, key)).length;
  return Math.max(1, count || DEFAULT_COOLDOWN);
}

function cooldownKeyForCandidate(item = {}, intent = {}) {
  const wanted = specificIntentTags(intent);
  const matchedSpecific = wanted.find((tag) => item.tags?.includes(tag));
  if (matchedSpecific) return `tag:${matchedSpecific}`;
  const matchedAny = (intent.tags || []).find((tag) => item.tags?.includes(tag));
  if (matchedAny) return `tag:${matchedAny}`;
  const firstSpecific = (item.tags || []).find((tag) => !GENERIC_PERSONA_TAGS.has(tag));
  if (firstSpecific) return `tag:${firstSpecific}`;
  const persona = Array.isArray(item.personas) ? item.personas.find(Boolean) : "";
  if (persona) return `persona:${normalizeRosterKey(persona)}`;
  const firstTag = (item.tags || []).find(Boolean);
  return firstTag ? `tag:${firstTag}` : "all";
}

function candidateMatchesCooldownKey(item = {}, key = "") {
  if (key === "all") return true;
  if (key.startsWith("tag:")) return item.tags?.includes(key.slice(4));
  if (key.startsWith("persona:")) {
    const target = key.slice(8);
    return (item.personas || []).some((label) => normalizeRosterKey(label) === target);
  }
  return false;
}

function buildAssignmentReport(assignments, roster, meta = {}) {
  const assigned = assignments.filter((item) => item.assignedSpeaker);
  return {
    ok: true,
    rosterCount: roster.length,
    previousCooldownCount: meta.previousCooldownCount || 0,
    rotationOffset: meta.rotationOffset || 0,
    mainCooldown: Number(meta.mainCooldown ?? DEFAULT_MAIN_COOLDOWN),
    backupCooldown: meta.backupCooldown || DEFAULT_BACKUP_COOLDOWN,
    visibleBackupCount: meta.visibleBackupCount || DEFAULT_VISIBLE_BACKUP_COUNT,
    rosterOptions: serializeRosterOptions(roster),
    tuoTaskCount: assignments.length,
    assignedCount: assigned.length,
    fallbackCount: assignments.filter((item) => item.fallback).length,
    backupCount: assignments.filter((item) => item.backup).length,
    assignments
  };
}

function serializeRosterOptions(roster = []) {
  const seen = new Set();
  const options = [];
  for (const item of roster) {
    const key = accountKey(item);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    options.push(serializeCandidate(item));
  }
  return options;
}

function buildTuoAssignment(primary, candidates, intent, options = {}) {
  return {
    mode: "precise_roster",
    cooldown: options.cooldown || DEFAULT_COOLDOWN,
    mainCooldown: Number(options.mainCooldown ?? DEFAULT_MAIN_COOLDOWN),
    backupCooldown: options.backupCooldown || DEFAULT_BACKUP_COOLDOWN,
    visibleBackupCount: options.visibleBackupCount || DEFAULT_VISIBLE_BACKUP_COUNT,
    cooldownMode: "dynamic_plan_and_actual_history",
    scopeId: options.scopeId || primary.scopeId || "",
    cooldownKey: options.cooldownKey || "",
    groupKey: options.groupKey || "",
    selectedPersona: personaLabelForIntent(intent, primary),
    reason: options.reason || "",
    candidateShortageReason: options.candidateShortageReason || "",
    candidateRotationNote: options.candidateRotationNote || "",
    fallback: Boolean(options.fallback),
    intentTags: intent.tags || [],
    requiredIntentTags: intent.requiredTags || [],
    intentReasons: intent.reasons || [],
    primary: serializeCandidate(primary),
    candidates: candidates.map(serializeCandidate)
  };
}

function personaLabelForIntent(intent = {}, primary = {}) {
  const tags = new Set(intent.tags || []);
  if (tags.has("student")) return "学生";
  if (tags.has("work")) return "工作";
  if (tags.has("mom") && tags.has("mature")) return "成熟女性/宝妈";
  if (tags.has("mom")) return "宝妈";
  if (tags.has("mature") && tags.has("female")) return "成熟女性";
  if (tags.has("mature")) return "成熟";
  if (tags.has("young") && tags.has("female")) return "年轻女性";
  if (tags.has("young")) return "年轻";
  if (tags.has("female")) return "女性";
  if (tags.has("male")) return "男性";
  return primary.personas?.[0] || "all";
}

function serializeCandidate(item = {}) {
  return {
    scopeId: item.scopeId || "",
    accountId: item.accountId || "",
    externalAccountId: item.externalAccountId || "",
    nickname: item.nickname || "",
    remark: item.remark || "",
    tags: item.tags || [],
    exactCategories: item.exactCategories || [],
    compatibleCategories: item.compatibleCategories || [],
    personas: item.personas || [],
    auxTags: item.auxTags || [],
    backup: Boolean(item.backup),
    order: item.order ?? 0
  };
}

function accountKey(item = {}) {
  return String(item.accountId || normalizeRosterKey(item.nickname || ""));
}

const PRIMARY_PERSONA_PRIORITY = ["mom", "student", "work", "mature", "young"];

export function inferTuoIntent(task = {}) {
  const text = [
    task.sourceText || "",
    task.text || "",
    task.speaker || "",
    task.cleanSpeaker || "",
    task.personaHint || ""
  ].join("\n");
  const tags = new Set();
  const requiredTags = new Set();
  const reasons = [];
  const experiencedTrust = /这么多年|这么久|一直跟(?:着)?(?:豆妈|买)|跟(?:着)?豆妈|老粉|老群友|没(?:有)?踩过雷|踩雷|翻车|售后|小助理|处理好|放心跟|放心买/.test(text);
  const youngVoice = /姐妹|爱了|冲|颜值|好看|追剧|减脂|低卡|下午茶|零食|拍照|老妈|我妈|给妈妈|给我妈|看哈|惯不|先买\d*[袋盒瓶包]?|买\d+[袋盒瓶包]/.test(text);

  addIf(tags, reasons, "mom", /宝妈|妈妈|孩子|小孩|娃|宝宝|小朋友|上学|幼儿园|早餐|家里人|老人孩子/.test(text), "母婴/家庭语境");
  addIf(tags, reasons, "work", /上班|工作|办公室|同事|打工|下班|通勤|开会/.test(text), "工作语境");
  addIf(tags, reasons, "mature", /配料|成分|保质期|安全|放心|品质|囤|家用|实惠|性价比|养生|健康/.test(text), "成熟理性语境");
  addIf(tags, reasons, "mature", experiencedTrust, "长期跟买/售后背书语境");
  addIf(tags, reasons, "young", youngVoice && !experiencedTrust, "年轻女性语境");
  addIf(tags, reasons, "female", /姐妹|女性|女生|宝妈|妈妈|女/.test(text), "女性语境");
  addIf(tags, reasons, "male", /男士|男性|爸爸|老公/.test(text), "男性语境");
  addIf(tags, reasons, "student", /学生|大学生|大学里|学校|宿舍|上课/.test(text), "学生身份语境");

  if (/宝妈|我家(?:孩子|小孩|娃|宝宝)|孩子|小孩|娃|宝宝/.test(text)) requiredTags.add("mom");
  if (/上班|办公室|同事|打工|通勤|开会/.test(text)) requiredTags.add("work");
  if (/学生|大学生|大学里|学校|宿舍|上课/.test(text)) requiredTags.add("student");
  if (/成熟女性|中年|退休|我(?:都)?(?:3\d|4\d|5\d)岁/.test(text)) requiredTags.add("mature");
  if (/年轻女性|女生|女孩|小姐姐/.test(text)) requiredTags.add("young");
  if (/女性|女生|女孩|宝妈|妈妈/.test(text)) requiredTags.add("female");
  if (/男士|男性|爸爸|老公/.test(text)) requiredTags.add("male");

  const explicitNickname = extractExplicitNickname(text);
  return resolveSingleTuoPersona({
    tags: [...tags],
    requiredTags: [...requiredTags],
    reasons,
    explicitNickname
  });
}

export function resolveSingleTuoPersona(intent = {}) {
  const tags = [...new Set(intent.tags || [])];
  const requiredTags = [...new Set(intent.requiredTags || [])];
  const requiredPrimary = PRIMARY_PERSONA_PRIORITY.filter((tag) => requiredTags.includes(tag));
  const inferredPrimary = PRIMARY_PERSONA_PRIORITY.filter((tag) => tags.includes(tag));
  const selected = requiredPrimary[0]
    || inferredPrimary.find((tag) => ["mom", "student", "work"].includes(tag))
    || (inferredPrimary.length === 1 ? inferredPrimary[0] : "");
  return {
    ...intent,
    tags: tags.filter((tag) => !PRIMARY_PERSONA_PRIORITY.includes(tag) || tag === selected),
    requiredTags: requiredTags.filter((tag) => !PRIMARY_PERSONA_PRIORITY.includes(tag) || tag === selected),
    reasons: (intent.reasons || []).filter((reason) => {
      const tag = personaTagForReason(reason);
      return !tag || tag === selected;
    })
  };
}

function personaTagForReason(reason) {
  const text = String(reason || "");
  if (/母婴|家庭/.test(text)) return "mom";
  if (/学生/.test(text)) return "student";
  if (/工作/.test(text)) return "work";
  if (/成熟|长期跟买|售后背书/.test(text)) return "mature";
  if (/年轻|表情包/.test(text)) return "young";
  return "";
}

function addIf(tags, reasons, tag, condition, reason) {
  if (!condition) return;
  tags.add(tag);
  reasons.push(reason);
}

function extractExplicitNickname(text) {
  const source = String(text || "");
  const match = source.match(/(?:指定托|固定托|指定说话人|说话人)\s*[：:]\s*([^\n｜|，,。；;]{1,24})/);
  return match ? match[1].trim() : "";
}

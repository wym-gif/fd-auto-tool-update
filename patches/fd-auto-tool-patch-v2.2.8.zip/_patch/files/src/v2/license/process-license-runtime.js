import {
  assertCompanyAccessAllowed,
  getDeviceId,
  getLicenseDiagnostics
} from "./license-manager.js";

const TRANSIENT_STATES = new Set(["unavailable", "timeout", "busy", "refresh_unavailable"]);

export function createProcessLicenseSession(projectRoot, licenseOptions = {}) {
  const authorizedStatuses = new Map();
  const checksInFlight = new Map();

  function current(action = "launch") {
    const status = authorizedStatuses.get(action);
    if (!status?.allowed) return null;
    return {
      ...status,
      state: "session_authorized",
      cached: true,
      session: true,
      message: "本次启动已经确认授权；关闭程序后会重新检查。"
    };
  }

  async function assertAccess(action) {
    const cached = current(action);
    if (cached) return cached;
    if (!checksInFlight.has(action)) {
      const pending = assertCompanyAccessAllowed(projectRoot, action, licenseOptions)
        .then((status) => {
          authorizedStatuses.set(action, status);
          return status;
        })
        .finally(() => {
          checksInFlight.delete(action);
        });
      checksInFlight.set(action, pending);
    }
    return checksInFlight.get(action);
  }

  async function getStatus(action = "launch") {
    try {
      return await assertAccess(action);
    } catch (error) {
      return error?.license || {
        enabled: true,
        allowed: false,
        state: "unavailable",
        company: "",
        expiresAt: "",
        message: error?.message || "无法确认公司授权。"
      };
    }
  }

  async function getDiagnostics(forceRefresh = false) {
    const launchStatus = current("launch");
    if (!forceRefresh && launchStatus) {
      return {
        deviceId: getDeviceId(),
        computerName: "",
        dns: { ok: true, expected: "", addresses: [], message: "本次启动已确认授权，未重复检查 DNS。" },
        service: { checked: false, ok: true, message: "本次启动已确认授权，未重复请求授权服务。" },
        license: launchStatus
      };
    }
    const diagnostics = await getLicenseDiagnostics(projectRoot, {
      ...licenseOptions,
      forceRefresh
    });
    const license = diagnostics?.license || {};
    if (license.allowed === true) {
      authorizedStatuses.set("launch", license);
      return diagnostics;
    }
    const transient = TRANSIENT_STATES.has(String(license.state || ""));
    const cached = current("launch");
    if (transient && cached) {
      return {
        ...diagnostics,
        service: {
          checked: true,
          ok: false,
          message: "授权服务暂不可用；沿用本次启动已确认的授权，不会中断正在创建的任务。"
        },
        license: {
          ...cached,
          state: "session_authorized_offline",
          message: "授权服务暂不可用；本次启动已确认授权，可以继续使用。"
        }
      };
    }
    if (!transient) authorizedStatuses.clear();
    return diagnostics;
  }

  return { assertAccess, getStatus, getDiagnostics };
}



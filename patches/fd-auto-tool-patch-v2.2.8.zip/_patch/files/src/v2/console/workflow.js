import fs from "node:fs/promises";
import path from "node:path";
import { assertCompanyAccessAllowed, submitLicenseOpsEvent, submitLicenseUsageReport } from "../license/license-manager.js";
import { collectRawEventsFromPageWithDiagnostics, materializeRawEventMediaFromPage, summarizeRawEvents, validateCollectedRawEvents } from "../feishu/collector.js";
import { collectError, isFeishuCollectError } from "../feishu/collect-errors.js";
import { closeFeishuCollectPage, normalizeFeishuUrl, openRealFeishuCollectPage } from "../feishu/page-controller.js";
import { normalizeSendDate, todayMonthDay } from "../date/date-rules.js";
import { locateRange } from "../range/locate-range.js";
import { isRangeLocateError } from "../range/range-errors.js";
import {
  buildHeadingStructure,
  collectHeadingStructureFromPage,
  locateHeadingRange,
  resolveHeadingDayRangeSelection,
  resolveHeadingSelection
} from "../range/heading-range.js";
import { parseFixedFormatTasks } from "../parser/parse-fixed-format.js";
import { validatePreviewTaskShape } from "../contracts/preview-task.js";
import { buildPreviewScheduleOptions, preparePreviewTasksForGeneration } from "../time/schedule-preview-tasks.js";
import { clockInputToSeconds } from "../time/clock-input.js";
import { assignPreciseTuoSpeakers } from "../tuo/precise-tuo-assigner.js";
import { loadTuoRoster } from "../tuo/tuo-roster.js";
import { registerTuoRosterIdentity } from "../tuo/tuo-roster-registry.js";
import { loadTuoUsageHistory } from "../tuo/tuo-usage-history.js";
import { importDocumentToRawEvents } from "../document/document-importer.js";
import { createFeishuGatewayConnection } from "../feishu-api/gateway-client.js";
import { prepareFeishuMediaRecovery, createFeishuMediaRecoveryHandler } from "../feishu-api/media-recovery.js";
import { materializeFeishuApiRawEvents } from "../feishu-api/raw-events.js";
import {
  assertFeishuManifestMappedToRawEvents,
  assertFeishuRangeMediaMappedToPreview,
  downloadSelectedFeishuMedia,
  recoverFeishuRangeMediaPreviewTasks
} from "../feishu-api/selective-media.js";
import { localizePreviewTaskMediaWithFetch } from "../media/media-cache.js";
import { createPreviewTestServer } from "../preview/preview-page.js";
import { finalPreviewPath, loadPreviewForOpen, previewTasksPath, readPreviewTasks, saveFinalPreview } from "../preview/preview-store.js";
import {
  loadPreviewRecoveryState,
  recordCreatedPreview,
  recordSavedPreview,
  resolvePreviewHistoryRun
} from "../preview/preview-recovery.js";
import { buildUsageModeSummary } from "../usage/mode-summary.js";
import { buildUsageSendTimeRange } from "../usage/send-time-range.js";
import {
  deletePreviewLibraryItem,
  createCombinedPreviewLibraryWorkingRun,
  createPreviewLibraryWorkingRun,
  listPreviewLibrary,
  movePreviewLibraryItem,
  renamePreviewLibraryItem,
  resolvePreviewLibraryItem,
  resolveRunAsLibraryItem,
  resolveRunLibrarySource,
  savePreviewToLibrary,
  updatePreviewLibraryContent
} from "../preview/preview-library.js";
import {
  deleteSharedPreviewLibraryItem,
  downloadSharedPreviewLibraryItem,
  exportSharedPreviewLibraryItem,
  importSharedPreviewLibraryFile,
  importSharedPreviewLibraryPackage,
  listSharedPreviewLibrary,
  prepareSharedPreviewLibraryItemForUpload,
  syncSharedPreviewLibraryState,
  uploadSharedPreviewLibraryItem
} from "../preview/shared-preview-library.js";
import { openRealCmsCreatePages, repairClosedCmsSessionPages, replaceTrustedCmsSessionRole, validateTrustedCmsPageSession } from "../cms/real-cms-adapter.js";
import { runMediaLocalCheck } from "../cms/media-local-check.js";
import { createCmsSubmitStateStore } from "../cms/submit-state.js";
import { resolveCmsConfigLibraryItem } from "../cms/cms-config-library.js";
import { restoreCmsConfigForRun } from "../cms/cms-config-restore.js";
import { applyCmsConfigFormToPages } from "../cms/cms-config-form-apply.js";
import {
  clearCmsPageBindings,
  createCmsPageBindingsForRun,
  readCmsPageInfos,
  runIdFromRunDir,
  runRealCmsCli
} from "../tools/run-real-cms-cli.js";
import { collectGenerateOptions, cmsRunOptions, normalizeConsoleSettings } from "./settings.js";
import { createWorkflowControl } from "./state.js";
import {
  closeMatchingControlledPages,
  closeV2ControlledBrowser,
  ensureV2ControlledBrowser,
  inspectControlledPages,
  loadV2ControlledBrowserState,
  openOrFocusConsolePage,
  openOrFocusControlledPage,
  openOrReplaceControlledPage
} from "../browser/controlled-browser.js";

const DEFAULT_CMS_URL = "https://cms.iyunzk.com/wx/FenWei_rw";

export function createConsoleWorkflow({ projectRoot, state, licenseFetch, licenseOptions: injectedLicenseOptions, authorizationCheck, instanceConfig = {}, operatorProvider, feishuApiReader, feishuApiMediaDownloader, feishuGateway, previewPageOpener, realCmsRunner, workflowHooks = {}, previewRecoveryOptions = {} }) {
  const licenseOptions = injectedLicenseOptions || (licenseFetch ? { fetch: licenseFetch } : {});
  const assertAuthorization = typeof authorizationCheck === "function"
    ? authorizationCheck
    : (action) => assertCompanyAccessAllowed(projectRoot, action, licenseOptions);
  const gateway = feishuGateway || (!feishuApiReader ? createFeishuGatewayConnection({
    projectRoot,
    instanceId: instanceConfig.id || ""
  }) : null);
  const effectiveFeishuReader = feishuApiReader || ((input, options) => gateway.read(input, options));
  const effectiveFeishuMediaDownloader = feishuApiMediaDownloader || (gateway?.downloadMedia
    ? ((input, options) => gateway.downloadMedia(input, options))
    : null);
  const runsRoot = instanceConfig.runsDir || path.join(projectRoot, "runs");
  const browserInstanceOptions = {
    runsDir: instanceConfig.runsDir,
    port: instanceConfig.cmsDebugPort,
    profileDir: instanceConfig.profileDir,
    instanceId: instanceConfig.id || ""
  };
  let previewServer = null;
  let running = null;
  let consoleUrl = "";
  let currentSettings = {};
  let preparedCmsPages = null;
  let cmsExecutionLease = null;
  let cmsInputMutexTail = Promise.resolve();
  let cmsInputMutationSequence = 0;
  let feishuProgressGeneration = 0;
  let activeOperation = null;
  let pendingCmsAbandon = null;
  const attemptedApiPreviewRuns = new Set();
  const executeRealCms = realCmsRunner || runRealCmsCli;

  function detachPreparedCmsRun() {
    if (!preparedCmsPages) return;
    preparedCmsPages.runId = "";
    preparedCmsPages.bindingState = null;
    preparedCmsPages.previewBindingSignature = "";
  }

  async function acquireCmsInputMutex() {
    let releaseCurrent;
    const current = new Promise((resolve) => { releaseCurrent = resolve; });
    const previous = cmsInputMutexTail;
    cmsInputMutexTail = previous.then(() => current);
    await previous;
    let released = false;
    return () => {
      if (released) return;
      released = true;
      releaseCurrent();
    };
  }

  async function beginCmsInputMutation(action = "修改预览") {
    const release = await acquireCmsInputMutex();
    try {
      assertCmsInputsMutable(action);
      const id = ++cmsInputMutationSequence;
      return { id, release };
    } catch (error) {
      release();
      throw error;
    }
  }

  async function acquireCmsExecutionLease(settings = {}) {
    const release = await acquireCmsInputMutex();
    try {
      return acquireCmsExecutionLeaseInsideMutex(settings);
    } finally {
      release();
    }
  }

  function assertCmsExecutionAvailable(settings = {}) {
    const runDir = settings.runDir || state.snapshot().runDir || "";
    const runId = runIdFromRunDir(runDir) || path.basename(runDir || "");
    if (!runId) throw new Error("没有当前运行记录，不能取得创建运行锁。");
    if (cmsExecutionLease) {
      const decision = settings?.recoveryDecision && typeof settings.recoveryDecision === "object"
        ? settings.recoveryDecision
        : null;
      const canHandoff = decision
        && cmsExecutionLease.runId === runId
        && cmsExecutionLease.status === "held_for_resolution"
        && cmsExecutionLease.runSettled
        && cmsExecutionLease.pendingPageActions.size === 0
        && String(decision.oldRequestId || "")
        && String(decision.oldRequestId || "") === String(cmsExecutionLease.requestId || "");
      if (canHandoff) return;
      const error = new Error(cmsExecutionLease.runId === runId
        ? (cmsExecutionLease.pendingPageActions.size > 0
          ? "上一条页面操作还在结束，暂时不能重试；结束后可再次点击，已成功的记录会保留。"
          : `当前 ${runId} 仍持有创建运行锁，不能重复开始创建。请先处理当前等待结果或异常。`)
        : `当前 ${cmsExecutionLease.runId} 仍持有创建运行锁，不能切换到 ${runId}。`);
      error.code = "CMS_EXECUTION_LOCKED";
      error.statusCode = 409;
      throw error;
    }
  }

  function acquireCmsExecutionLeaseInsideMutex(settings = {}) {
    assertCmsExecutionAvailable(settings);
    if (cmsExecutionLease) {
      cmsExecutionLease.requestId = String(settings.cmsStartRequestId || "");
      cmsExecutionLease.status = "starting";
      cmsExecutionLease.acquiredAt = new Date().toISOString();
      cmsExecutionLease.runSettled = false;
      cmsExecutionLease.terminalResult = null;
      cmsExecutionLease.reason = "";
      cmsExecutionLease.recoveryDecisionId = String(settings.recoveryDecision.decisionId || "");
      return cmsExecutionLease;
    }
    const runDir = settings.runDir || state.snapshot().runDir || "";
    const runId = runIdFromRunDir(runDir) || path.basename(runDir || "");
    cmsExecutionLease = {
      id: `${instanceConfig.id || "default"}:${runId}:${Date.now()}`,
      instanceId: String(instanceConfig.id || "default"),
      runId,
      runDir,
      requestId: String(settings.cmsStartRequestId || ""),
      status: "starting",
      acquiredAt: new Date().toISOString(),
      pageActionsActive: false,
      pageActionRevision: 0,
      pendingPageActions: new Set(),
      runSettled: false,
      terminalResult: null,
      previewSignature: ""
    };
    return cmsExecutionLease;
  }

  function releaseCmsExecutionLease(lease) {
    if (!lease || cmsExecutionLease !== lease) return;
    cmsExecutionLease = null;
  }

  function updateCmsPageActionState(lease, event = {}) {
    if (!lease || cmsExecutionLease !== lease || !event.token) return;
    if (event.active) lease.pendingPageActions.add(event.token);
    else lease.pendingPageActions.delete(event.token);
    lease.pageActionRevision += 1;
    lease.pageActionsActive = lease.pendingPageActions.size > 0;
    if (lease.runSettled) return finalizeCmsExecutionLease(lease);
  }

  async function settleCmsExecutionLease(lease, result) {
    if (!lease || cmsExecutionLease !== lease) return;
    lease.runSettled = true;
    lease.terminalResult = result || { ok: false };
    await finalizeCmsExecutionLease(lease);
  }

  async function finalizeCmsExecutionLease(lease) {
    if (!lease?.runSettled || cmsExecutionLease !== lease) return;
    const result = lease.terminalResult || {};
    if (lease.pendingPageActions.size > 0) {
      lease.status = "held_for_action_drain";
      lease.reason = result.error || result.code || "页面动作尚未结束";
      return;
    }
    // Read after the last page action exits: it may have persisted an unknown
    // submit while draining. An error category alone cannot prove submission.
    const actionRevision = lease.pageActionRevision;
    lease.status = "checking_resolution";
    const safeToRelease = result.code !== "CMS_SUBMIT_UNKNOWN"
      && await hasSettledCmsSubmitState(lease.runDir);
    if (cmsExecutionLease !== lease || !lease.runSettled || lease.terminalResult !== result) return;
    if (lease.pageActionRevision !== actionRevision) return finalizeCmsExecutionLease(lease);
    if (!safeToRelease) {
      lease.status = "held_for_resolution";
      lease.reason = result.error || result.code || "逐条提交结果尚未确认";
      return;
    }
    releaseCmsExecutionLease(lease);
  }

  async function releaseResolvedCmsPageLease(runDir, repairedRole = "") {
    const lease = cmsExecutionLease;
    if (!lease || lease.runId !== runIdFromRunDir(runDir) || !repairedRole) return false;
    if (lease.status !== "held_for_resolution" || lease.pendingPageActions.size > 0) return false;
    const repairableCodes = new Set([
      "CMS_PAGE_SESSION_INVALID",
      "CMS_PAGE_CONFIG_CHANGED",
      "CMS_FINAL_ACCOUNT_MISMATCH",
      "ROBOT_ACCOUNT_IDENTITY_AMBIGUOUS"
    ]);
    if (!repairableCodes.has(lease.terminalResult?.code)) return false;
    if (!await hasSettledCmsSubmitState(runDir)) return false;
    if (cmsExecutionLease !== lease || lease.status !== "held_for_resolution" || lease.pendingPageActions.size > 0) return false;
    releaseCmsExecutionLease(lease);
    state.log(`云中客 ${repairedRole === "douma" ? "豆妈" : "托"} 页面修复并重新核验通过，且没有结果未知的提交记录；创建运行锁已解除。`);
    return true;
  }

  function assertCmsInputsMutable(action = "修改预览") {
    if (!cmsExecutionLease) return true;
    const snapshot = state.snapshot();
    const scheduleContinuationMutation = snapshot.control === "awaiting_expired_schedule_edit"
      && ["重排预览时间", "保存预览修改"].includes(String(action || ""));
    if (scheduleContinuationMutation) return true;
    const error = new Error(`当前 ${cmsExecutionLease.runId} 正在创建或等待结果，本轮预览已锁定，不能${action}。完成或明确停止且页面动作退出后再操作。`);
    error.code = "CMS_EXECUTION_LOCKED";
    throw error;
  }

  async function returnToPreviewAfterTaskError() {
    const before = state.snapshot();
    if (before.control !== "awaiting_error_action" || before.manualAction?.type !== "task_error") {
      const error = new Error("当前不在单条创建失败的等待状态，不能返回预览修改。");
      error.code = "CMS_PREVIEW_EDIT_NOT_AVAILABLE";
      throw error;
    }
    const runDir = before.runDir || cmsExecutionLease?.runDir || "";
    if (!runDir || !previewServer?.url) throw new Error("当前失败轮次没有可打开的预览页。");
    await assertNoUncertainCmsSubmit(runDir);
    const failedIndex = Number(before.manualAction.taskIndex || before.currentIndex || 0);
    const previewTasks = await readJsonIfExists(finalPreviewPath(runDir));
    const failedIdentity = String(before.manualAction.submitIdentity || "");
    const failedSourceOrder = Number(before.manualAction.sourceOrder || 0);
    const previewProblemIndex = Array.isArray(previewTasks)
      ? previewTasks.findIndex((task) => failedIdentity
        ? String(task?.submitIdentity || "") === failedIdentity
        : failedSourceOrder > 0
          ? Number(task?.order || 0) === failedSourceOrder
          : false)
      : -1;
    const stableProblemIndex = previewProblemIndex >= 0 ? previewProblemIndex : Math.max(0, failedIndex - 1);
    const failureReason = String(before.manualAction.reason || before.failureReason || "当前条创建失败");
    state.stop(`正在安全退出创建并返回预览修改第 ${failedIndex || "?"} 条`);

    const deadline = Date.now() + 15000;
    while ((running || cmsExecutionLease) && Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    if (running || cmsExecutionLease) {
      const error = new Error("创建页面动作尚未完全退出，预览仍受保护。请稍后再次点击“返回预览修改”。");
      error.code = "CMS_PREVIEW_EDIT_DRAINING";
      throw error;
    }

    const previewUrl = withPreviewRunParams(previewServer.url, runDir, {
      repairMode: "task-error",
      problemIndex: String(stableProblemIndex),
      problemTaskId: failedIdentity,
      problemReason: failureReason,
      resumeAfterEdit: "1"
    });
    state.update({
      step: "等待预览修改",
      status: "waiting",
      control: "awaiting_preview_confirmation",
      runDir,
      previewPath: finalPreviewPath(runDir),
      previewUrl,
      currentIndex: failedIndex,
      failureStep: "",
      failureReason: "",
      manualAction: null,
      waitingReason: `已安全退出创建，请在预览页修改第 ${failedIndex || "?"} 条并保存；已成功条目不会重复创建。`
    });
    state.log(`已返回预览修改：第 ${failedIndex || "?"} 条；原失败原因=${failureReason}`);
    return { ok: true, runDir, previewUrl, failedIndex };
  }

  async function openExpiredScheduleEditor() {
    const before = state.snapshot();
    if (before.control !== "awaiting_expired_schedule" || before.manualAction?.type !== "expired_schedule") {
      const error = new Error("当前不在连续过期后的排程选择状态，不能打开续排页面。");
      error.code = "CMS_EXPIRED_SCHEDULE_EDIT_NOT_AVAILABLE";
      throw error;
    }
    const runDir = before.runDir || cmsExecutionLease?.runDir || "";
    if (!runDir || !previewServer?.url) throw new Error("当前轮次没有可打开的预览页。");
    await assertNoUncertainCmsSubmit(runDir);
    const nextIndex = Number(before.manualAction.nextIndex || before.currentIndex || 0);
    state.beginExpiredScheduleEdit(`正在修改第 ${nextIndex || "?"} 条起的剩余排程；已成功任务保持锁定。`);
    const previewUrl = withPreviewRunParams(previewServer.url, runDir, {
      scheduleContinuation: "1",
      resumeFromIndex: String(nextIndex),
      resumeAfterEdit: "1"
    });
    state.update({ previewUrl });
    return { ok: true, runDir, previewUrl, nextIndex };
  }

  async function assertNoUncertainCmsSubmit(runDir) {
    const submitPath = path.join(runDir, "cms-submit-state.json");
    let submitState = null;
    try {
      submitState = JSON.parse(await fs.readFile(submitPath, "utf8"));
    } catch (error) {
      if (error?.code === "ENOENT") return true;
      const blocked = new Error("逐条创建记录损坏，不能开放预览修改；请先核对 CMS 是否已经创建。");
      blocked.code = "CMS_SUBMIT_STATE_CORRUPT";
      blocked.cause = error;
      throw blocked;
    }
    const uncertain = new Set(["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown"]);
    const record = Object.values(submitState?.tasks || {}).find((item) => uncertain.has(item?.status));
    if (!record) return true;
    const blocked = new Error(`第 ${record.index || "?"} 条创建结果尚未确认，不能先修改预览。请先使用防重复保护核对结果。`);
    blocked.code = "CMS_SUBMIT_UNKNOWN";
    throw blocked;
  }

  async function hasSettledCmsSubmitState(runDir) {
    let submitState;
    try {
      // Opening the store only reads; its normal schema checks also reject
      // corrupt records instead of treating them as an empty successful run.
      submitState = (await createCmsSubmitStateStore(runDir)).snapshot();
    } catch {
      return false;
    }
    const records = Object.values(submitState?.tasks && typeof submitState.tasks === "object" ? submitState.tasks : {});
    const uncertain = new Set(["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown"]);
    return !records.some((record) => uncertain.has(record?.status));
  }

  function isRecoverableCmsLoginFailure(error) {
    return error?.code === "CMS_PAGE_SESSION_INVALID"
      && /页面已不是登录后的创建任务页/.test(String(error?.message || ""));
  }

  async function generatePreview(settings = {}) {
    await assertAuthorization("generate-preview");
    throw new Error("飞书链接滚动采集入口已停用。请回控制台使用飞书 API 读取或直接粘贴内容。");
  }

  function importDocumentPreview(input = {}, settings = {}) {
    if (running) return Promise.reject(new Error("已有流程正在运行，请等当前流程结束。"));
    const operation = {
      id: `${instanceConfig.id || "default"}:${Date.now()}:${Math.random().toString(16).slice(2)}`,
      kind: input?.mode === "feishu-api" ? "feishu-read" : "document-import",
      controller: new AbortController(), requestId: "", runGeneration: 0,
      cancelRequested: false, cancellationIntent: "",
      backendCancelPromise: null, backendCancelResult: null, backendCancelError: null
    };
    activeOperation = operation;
    // Reserve synchronously, including the asynchronous authorization/check phase.
    running = admitDocumentPreview(input, settings, operation).finally(async () => {
      try {
        if (operation.cancelRequested) await finalizeCancelledOperation(operation);
      } finally {
        if (activeOperation === operation) activeOperation = null;
        running = null;
      }
    });
    return running;
  }

  async function admitDocumentPreview(input, settings, operation) {
    await assertAuthorization("generate-preview");
    if (operation.cancelRequested) return { ok: false, cancelled: true };
    await validatePreviewGenerationSettings(settings);
    if (operation.cancelRequested) return { ok: false, cancelled: true };
    const mode = String(input?.mode || "");
    if (!["feishu-api", "document-paste"].includes(mode)) {
      if (input && typeof input === "object" && "appSecret" in input) input.appSecret = "";
      throw new Error(mode === "feishu-download"
        ? "飞书自动下载 Word 入口已停用。请使用飞书 API 读取或直接粘贴内容。"
        : "这个内容读取入口已停用。请使用飞书 API 读取或直接粘贴内容。");
    }
    const previousPreviewServer = previewServer;
    previousPreviewServer?.beginDrain?.();
    let mutation;
    try {
      mutation = await beginCmsInputMutation("生成新预览");
    } catch (error) {
      previousPreviewServer?.resumeMutations?.();
      throw error;
    }
    try {
      if (operation.cancelRequested) return { ok: false, cancelled: true };
      return await runImportDocumentPreview(input, settings, operation);
    } finally {
      mutation.release();
      if (previewServer === previousPreviewServer) previousPreviewServer?.resumeMutations?.();
    }
  }

  async function startCms(settings = {}) {
    await assertAuthorization("start-cms");
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    const lease = await acquireCmsExecutionLease(settings);
    running = runCms(settings, lease).then(async (result) => {
      await settleCmsExecutionLease(lease, result);
      return result;
    }, async (error) => {
      await settleCmsExecutionLease(lease, { ok: false, code: error?.code || "", error: error?.message || String(error) });
      throw error;
    }).finally(() => {
      running = null;
    });
    return running;
  }

  async function prepareCms(settings = {}) {
    await assertAuthorization("prepare-cms");
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    if (cmsExecutionLease && cmsExecutionLease.runId !== runIdFromRunDir(settings.runDir || state.snapshot().runDir)) {
      throw new Error("当前创建轮次仍持有运行锁，不能为另一轮重新绑定云中客页面。");
    }
    running = runPrepareCms(settings).finally(() => {
      running = null;
    });
    return running;
  }

  async function readFeishuTitle(feishuUrl) {
    if (running) {
      return { ok: false, statusCode: 409, error: "已有流程正在运行，请等当前流程结束后再读取标题。" };
    }
    const url = normalizeFeishuUrl(feishuUrl);
    if (!url) {
      return { ok: false, statusCode: 400, error: "链接格式可能不正确，请检查。" };
    }
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const controlledBrowser = await loadControlledBrowserState(projectRoot, config, browserInstanceOptions);
    if (!controlledBrowser.cdpUrl) {
      return { ok: false, statusCode: 409, error: "当前不是 2.0 专用可控浏览器，请从正式入口启动后再读取标题。" };
    }
    let opened;
    try {
      opened = await openRealFeishuCollectPage({
        url,
        cdpUrl: controlledBrowser.cdpUrl,
        headless: false,
        timeoutMs: 30000
      });
      const title = opened.title || "";
      state.log(`飞书链接标题读取：${url}；标题=${title || "未读取到标题"}`);
      return { ok: true, feishuUrl: url, title };
    } finally {
      await closeOpenedFeishuPage(opened, state);
    }
  }

  async function readHeadingStructure(feishuUrl) {
    if (running) {
      return { ok: false, statusCode: 409, error: "已有流程正在运行，请等当前流程结束后再识别标题结构。" };
    }
    const url = normalizeFeishuUrl(feishuUrl);
    if (!url) {
      return { ok: false, statusCode: 400, error: "链接格式可能不正确，请检查。" };
    }
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const controlledBrowser = await loadControlledBrowserState(projectRoot, config, browserInstanceOptions);
    if (!controlledBrowser.cdpUrl) {
      return { ok: false, statusCode: 409, error: "当前不是 2.0 专用可控浏览器，请从正式入口启动后再识别标题结构。" };
    }
    let opened;
    try {
      opened = await openRealFeishuCollectPage({
        url,
        cdpUrl: controlledBrowser.cdpUrl,
        headless: false,
        focusBody: false,
        timeoutMs: 30000
      });
      const structure = await collectHeadingStructureFromPage(opened.page);
      state.update({ feishuUrl: url, feishuTitle: opened.title || "", feishuTitleUrl: url });
      state.log(`识别标题结构：只读取飞书左侧目录；当前飞书链接=${url}；标题数=${structure.headings.length}`);
      return { ok: true, feishuUrl: url, title: opened.title || "", structure };
    } finally {
      await closeOpenedFeishuPage(opened, state);
    }
  }

  async function readFeishuApiHeadingStructure(input = {}) {
    if (running) {
      return { ok: false, statusCode: 409, error: "已有流程正在运行，请等当前流程结束后再读取标题结构。" };
    }
    const url = normalizeFeishuUrl(input.documentUrl);
    if (!url) {
      return { ok: false, statusCode: 400, error: "链接格式可能不正确，请检查。" };
    }
    try {
      const result = await effectiveFeishuReader({ documentUrl: url }, {
        downloadMedia: false,
        headingOnly: true,
        progress: (message) => state.log(`飞书 API 标题结构：${message}`)
      });
      const headings = (result.report?.rows || [])
        .filter((row) => row.type === "heading")
        .map((row) => ({ text: row.text, level: row.headingLevel, blockId: row.blockId,
          sourceId: `feishu-api-${row.order}`, order: row.order }));
      const structure = buildHeadingStructure(headings);
      if (!structure.headings.length || !structure.days.length) {
        return { ok: false, statusCode: 422, error: "文档中没有识别到可选择的天数标题，请检查标题格式。" };
      }
      const title = result.report?.title || "";
      state.update({ feishuUrl: url, feishuTitle: title, feishuTitleUrl: url });
      state.log(`飞书 API 标题结构读取完成：标题数=${structure.headings.length}；天数=${structure.days.length}`);
      return { ok: true, feishuUrl: url, title, structure };
    } finally {}
  }

  async function getFeishuConnectionStatus() {
    return gateway ? gateway.status() : { ok: true, configured: true, oauthConfigured: true, personalAuthorized: false };
  }

  async function startFeishuOAuth() {
    if (!gateway) throw new Error("测试读取器未配置个人飞书授权入口。");
    return gateway.startOAuth();
  }

  async function readFeishuApiMetadata(input = {}, options = {}) {
    if (!gateway?.metadata) throw new Error("当前读取器未配置轻量文档标题接口。");
    const document = await gateway.metadata(input.documentUrl, options);
    state.log(`飞书 API 自动读取标题：${document.canonicalUrl}；标题=${document.title}`);
    return { ok: true, feishuUrl: document.canonicalUrl, documentId: document.id, title: document.title,
      revision: document.revision, authMode: document.authMode };
  }

  async function previewHasUnsavedChanges() {
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const controlledBrowser = await loadControlledBrowserState(projectRoot, config, browserInstanceOptions);
    if (!controlledBrowser.cdpUrl) return false;
    const pages = await inspectControlledPages(controlledBrowser.cdpUrl, {
      titleIncludes: "妙券自动发单 - 预览确认",
      onlyLocalhost: true,
      includeDirty: true
    }).catch(() => []);
    return pages.some((page) => page.previewDirty);
  }

  async function abandonCurrentRun() {
    assertCmsInputsMutable("放弃当前预览");
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const snapshot = state.snapshot?.() || {};
    const runDir = snapshot.runDir || "";
    const submitSummary = runDir ? await assertCmsRunCanBeAbandoned(runDir) : { succeededCount: 0 };
    const runDirectoryExists = runDir
      ? await fs.stat(runDir).then((stat) => stat.isDirectory()).catch(() => false)
      : false;
    if (runDirectoryExists) {
      await saveJson(path.join(runDir, "flow-abandoned.json"), {
        version: 1,
        abandoned: true,
        abandonedAt: new Date().toISOString(),
        preservedPreview: true,
        preservedSubmitState: true,
        succeededCount: submitSummary.succeededCount
      });
    }
    const closeResult = await closeControlledPreviewPages(projectRoot, config, browserInstanceOptions);
    await previewServer?.close?.().catch(() => {});
    previewServer = null;
    if (runDir) await clearCmsPageBindings(runDir).catch(() => {});
    detachPreparedCmsRun();
    state.log(closeResult.closed
      ? `已关闭当前预览页：${closeResult.closed} 个`
      : "已清理当前预览状态；未检测到需要关闭的预览页");
    return {
      ok: true,
      closedPreviewPages: closeResult.closed || 0,
      archivedRunId: runDir ? path.basename(runDir) : "",
      preservedSucceededCount: submitSummary.succeededCount
    };
  }

  async function assertCmsRunCanBeAbandoned(runDir) {
    let submitState;
    try {
      submitState = JSON.parse(await fs.readFile(path.join(runDir, "cms-submit-state.json"), "utf8"));
    } catch (error) {
      if (error?.code === "ENOENT") return true;
      const blocked = new Error("逐条创建记录损坏，不能直接放弃本轮；请先核对 CMS 任务队列。");
      blocked.code = "CMS_SUBMIT_STATE_CORRUPT";
      throw blocked;
    }
    const records = Object.values(submitState?.tasks && typeof submitState.tasks === "object" ? submitState.tasks : {});
    const uncertainStatuses = new Set(["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown"]);
    const record = records.find((item) => uncertainStatuses.has(item?.status));
    if (!record) {
      return { succeededCount: records.filter((item) => item?.status === "succeeded").length };
    }
    const blocked = new Error(`第 ${record.index || "?"} 条创建结果尚未确认，不能直接放弃本轮。请先核对 CMS 任务队列，避免重复创建。`);
    blocked.code = "CMS_SUBMIT_PROTECTED";
    throw blocked;
  }

  async function cancelCurrentRun(intent = "stop") {
    const requestedIntent = intent === "abandon" ? "abandon" : "stop";
    if (!running && pendingCmsAbandon) {
      return { ok: true, accepted: true, completed: false, state: state.snapshot() };
    }
    if (!running) {
      if (requestedIntent === "abandon") {
        const result = await abandonCurrentRun();
        state.resetForNextRun(
          "结束本轮：已清空当前界面状态，等待重新设置",
          "本轮已结束，请重新设置文档、时间和读取范围，然后点击“保存设置，生成预览”。"
        );
        return { ok: true, accepted: false, completed: true, ...result, state: state.snapshot() };
      }
      state.requestCancellation({ intent: "stop", reason: "正在停止本轮" });
      state.completeCancellation("本轮已停止；设置和诊断记录已保留。");
      return { ok: true, accepted: false, completed: true, state: state.snapshot() };
    }
    if (!activeOperation) {
      if (requestedIntent === "abandon") {
        state.requestCancellation({
          intent: "abandon",
          reason: "正在停止当前创建；安全退出后会归档本轮并回到设置。"
        });
        // CMS runner stops at its next checkpoint. Keep the visible status as
        // cancelling so the page waits for the automatic archive to finish.
        state.update({ control: "stopped" });
        if (!pendingCmsAbandon) {
          const currentRun = running;
          pendingCmsAbandon = finalizeRunningCmsAbandon(currentRun).finally(() => {
            pendingCmsAbandon = null;
          });
        }
      } else {
        state.stop("用户点击停止");
      }
      return { ok: true, accepted: true, completed: false, state: state.snapshot() };
    }
    activeOperation.cancelRequested = true;
    if (requestedIntent === "abandon" || activeOperation.cancellationIntent !== "abandon") {
      activeOperation.cancellationIntent = requestedIntent;
    }
    feishuProgressGeneration += 1;
    const message = activeOperation.cancellationIntent === "abandon"
      ? "正在取消并结束本轮；后台正在结束读取，完成后会自动回到设置。"
      : "正在取消本轮；后台正在结束读取，完成后会显示已停止。";
    state.requestCancellation({
      intent: activeOperation.cancellationIntent,
      reason: message,
      requestId: activeOperation.requestId
    });
    activeOperation.controller.abort();
    startBackendCancellation(activeOperation);
    return { ok: true, accepted: true, completed: false, state: state.snapshot() };
  }

  async function finalizeRunningCmsAbandon(currentRun) {
    try {
      await Promise.resolve(currentRun).catch(() => {});
      const deadline = Date.now() + 30000;
      while (cmsExecutionLease?.status === "held_for_action_drain" && Date.now() < deadline) {
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      const result = await abandonCurrentRun();
      state.resetForNextRun(
        "结束本轮：当前创建已安全退出并归档，已回到设置",
        "本轮已归档，请重新设置文档、时间和读取范围，然后点击“保存设置，生成预览”。"
      );
      return result;
    } catch (error) {
      state.fail("结束本轮", `本轮已停止，但归档清理未完成：${error?.message || String(error)}`);
      return { ok: false, error: error?.message || String(error) };
    }
  }

  function startBackendCancellation(operation) {
    if (!gateway?.cancelRead || !operation?.requestId || operation.backendCancelPromise) return;
    operation.backendCancelPromise = gateway.cancelRead(operation.requestId, {
      progress: (progress) => {
        if (activeOperation !== operation || !operation.cancelRequested) return;
        const stage = String(progress?.stage || "");
        const suffix = stage ? `（后台阶段：${stage}）` : "";
        state.updateCancellation(`正在取消；后台正在结束读取${suffix}。`, {
          cancellationRequestId: operation.requestId
        });
      }
    }).then((result) => {
      operation.backendCancelResult = result || null;
      return result;
    }).catch((error) => {
      operation.backendCancelError = error;
      if (activeOperation === operation && operation.cancelRequested) {
        state.updateCancellation(`客户端读取已停止；仍在等待后台确认结束（${error?.message || "取消状态暂未确认"}）。`, {
          cancellationRequestId: operation.requestId
        });
      }
      throw error;
    });
  }

  async function finalizeCancelledOperation(operation) {
    if (operation.backendCancelPromise) {
      try {
        await operation.backendCancelPromise;
      } catch {
        // The local request has exited. The state already explains that backend completion was not confirmed.
      }
    }
    if (operation.cancellationIntent === "abandon") {
      const result = await abandonCurrentRun();
      state.resetForNextRun(
        "结束本轮：当前读取已退出，已回到设置",
        "本轮已结束，请重新设置文档、时间和读取范围，然后点击“保存设置，生成预览”。"
      );
      return result;
    }
    if (operation.backendCancelError) {
      state.completeCancellation(`本地读取已停止，但后台结果未确认；请用请求编号 ${operation.requestId || "（未取得）"} 核对后台状态后再重试。设置和诊断记录已保留。`);
    } else if (operation.backendCancelResult?.backendOutcome === "not_found") {
      state.completeCancellation(`本地读取已停止；后台在限定时间内未找到请求 ${operation.requestId || "（未取得）"}，无法确认该请求是否曾登记或已因重启过期。请核对后台状态后再重试。`);
    } else if (!operation.requestId) {
      state.completeCancellation("本轮已在请求发送前停止；没有已登记的后台读取需要取消。设置和诊断记录已保留。");
    } else if (!gateway?.cancelRead) {
      state.completeCancellation(`本地读取已停止，但当前读取器无法确认后台请求 ${operation.requestId} 是否结束。请核对后台状态后再重试。设置和诊断记录已保留。`);
    } else {
      state.completeCancellation("本轮已停止，后台已确认终止；设置和诊断记录已保留。再次生成前可先核对读取范围。");
    }
    return { ok: true };
  }

  function isCurrentOperation(operation, progressGeneration, runGeneration) {
    const snapshot = state.snapshot();
    return activeOperation === operation && !operation.cancelRequested && !operation.controller.signal.aborted &&
      progressGeneration === feishuProgressGeneration && snapshot.runGeneration === runGeneration &&
      snapshot.control !== "cancelling";
  }

  async function operationCheckpoint(operation, progressGeneration, runGeneration, checkpoint) {
    await workflowHooks.onImportCheckpoint?.(checkpoint, { operation, state: state.snapshot() });
    await new Promise((resolve) => setImmediate(resolve));
    if (isCurrentOperation(operation, progressGeneration, runGeneration)) return;
    const error = new Error(`本轮已取消，停止于检查点：${checkpoint}`);
    error.name = "AbortError";
    error.code = "WORKFLOW_CANCELLED";
    throw error;
  }

  async function exitProgramSession() {
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const snapshot = state.snapshot?.() || {};
    const runDir = snapshot.runDir || "";
    await previewServer?.close?.().catch(() => {});
    previewServer = null;
    if (runDir) await clearCmsPageBindings(runDir).catch(() => {});
    preparedCmsPages = null;
    const browserResult = await closeV2ControlledBrowser(projectRoot, config, { ...browserInstanceOptions, allowPortFallback: true }).catch(() => ({ closed: false }));
    state.log(browserResult.closed
      ? "退出程序：已关闭 2.0 受控浏览器"
      : "退出程序：未检测到需要关闭的 2.0 受控浏览器");
    return { ok: true, closedBrowser: Boolean(browserResult.closed) };
  }

  async function refreshCurrentCmsPageBindings(options = {}) {
    assertCmsInputsMutable("刷新或覆盖云中客页面绑定");
    const runDir = await resolveRunDirFromRequest(projectRoot, {
      runDir: options.runDir || state.snapshot().runDir,
      runId: options.runId
    }, { runsRoot, previewRecoveryOptions });
    if (!runDir) return { ok: false, error: "没有当前 run 目录，无法刷新云中客配置。" };
    const pages = (preparedCmsPages?.pages || []).filter((page) => !page.isClosed?.());
    if (!pages.length) return { ok: false, error: "当前没有可读取的云中客页面，请先进入云中客设置。" };
    const pageInfos = await readCmsPageInfos(pages, {
      instanceId: instanceConfig.id || "default",
      pageInfoTimeoutMs: 10000,
      onProgress: async (message) => state.log(message)
    });
    const bindingState = await createCmsPageBindingsForRun(runDir, pageInfos, ["tuo", "douma"], {
      instanceId: instanceConfig.id || "default",
      source: "save-cms-config"
    });
    preparedCmsPages.bindingState = bindingState;
    state.log("云中客配置：保存前已刷新当前托/豆妈页面的群、机器人、任务备注和多快捷状态。");
    return { ok: true, runDir, bindingState };
  }

  async function getRestorablePreview() {
    const recovery = await loadPreviewRecoveryState(runsRoot, instanceConfig, previewRecoveryOptions);
    return recovery.candidate
      ? { ...recovery, ...recovery.candidate, runName: recovery.candidate.runId }
      : recovery;
  }

  async function restoreLatestPreview(settings = {}, requestedRunId = "") {
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    const previousPreviewServer = previewServer;
    previousPreviewServer?.beginDrain?.();
    let mutation;
    let replacedPreviewServer = false;
    try {
    mutation = await beginCmsInputMutation("恢复旧预览");
    const recovery = await getRestorablePreview();
    const selectedRunDir = requestedRunId
      ? await resolvePreviewHistoryRun(runsRoot, requestedRunId, previewRecoveryOptions)
      : recovery.candidate?.runDir || "";
    if (!selectedRunDir) return { ok: false, error: requestedRunId
      ? "所选历史预览不存在、已损坏或不属于当前实例。"
      : (recovery.warning || "没有找到可以恢复的上次预览。"), recovery };
    const selected = recovery.history?.find((item) => item.runId === path.basename(selectedRunDir)) || {};
    const candidate = {
      ...selected,
      runDir: selectedRunDir,
      previewPath: finalPreviewPath(selectedRunDir),
      taskCount: Number(selected.taskCount || (await readPreviewTasks(finalPreviewPath(selectedRunDir))).length)
    };
    const normalized = normalizeConsoleSettings(settings);
    currentSettings = normalized;
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const defaultDate = todayMonthDay();
    const libraryItem = await resolveRunLibrarySource(projectRoot, candidate.runDir).catch(() => null);
    const previousPreviewUrl = previousPreviewServer?.url || "";
    await previousPreviewServer?.close?.().catch(() => {});
    const nextPreviewServer = await createPreviewServerForRun(candidate.runDir, {
      config,
      defaultDate,
      restoreDateOnOpen: true,
      reason: "已恢复上次预览，等待确认发单"
    });
    previewServer = nextPreviewServer;
    replacedPreviewServer = true;
    state.update({
      step: "等待预览确认",
      status: "waiting",
      control: "awaiting_preview_confirmation",
      runDir: candidate.runDir,
      previewPath: candidate.previewPath,
      previewUrl: previewServer.url,
      totalCount: candidate.taskCount,
      activeLibraryItemId: libraryItem?.id || "",
      activeLibraryItemName: libraryItem?.name || "",
      waitingReason: `已恢复上次预览；未发送任务日期已默认调整为今天 ${defaultDate}，请检查时间并保存预览内容`
    });
    state.log(`已恢复上次预览：${candidate.previewPath}`);
    state.log(`预览页：${previewServer.url}`);
    await openControlledPreviewPage(projectRoot, config, withPreviewRunParams(previewServer.url, candidate.runDir), browserInstanceOptions, {
      replaceUrl: previousPreviewUrl
    });
    return {
      ok: true,
      runDir: candidate.runDir,
      previewPath: candidate.previewPath,
      previewUrl: previewServer.url,
      taskCount: candidate.taskCount,
      restoredRunId: path.basename(candidate.runDir)
    };
    } finally {
      if (!replacedPreviewServer && previewServer === previousPreviewServer) previousPreviewServer?.resumeMutations?.();
      mutation?.release();
    }
  }

  async function restorePreviewRunState(runId, settings = {}) {
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    const previousPreviewServer = previewServer;
    previousPreviewServer?.beginDrain?.();
    let mutation;
    let replacedPreviewServer = false;
    try {
    mutation = await beginCmsInputMutation("恢复旧预览");
    const runDir = await resolveRunDirFromRequest(projectRoot, { runId }, { runsRoot, previewRecoveryOptions });
    if (!runDir) return { ok: false, error: "没有找到这个记录对应的预览内容。" };
    const previewPath = finalPreviewPath(runDir);
    const tasks = await readJsonIfExists(previewPath);
    const taskCount = Array.isArray(tasks) ? tasks.length : 0;
    const normalized = normalizeConsoleSettings(settings);
    currentSettings = { ...currentSettings, ...normalized };
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const defaultDate = todayMonthDay();
    const libraryItem = await resolveRunLibrarySource(projectRoot, runDir).catch(() => null);
    await previousPreviewServer?.close?.().catch(() => {});
    const nextPreviewServer = await createPreviewServerForRun(runDir, {
      config,
      defaultDate,
      restoreDateOnOpen: true,
      reason: "已从当前控制台页面恢复本轮预览"
    });
    previewServer = nextPreviewServer;
    replacedPreviewServer = true;
    const hasCmsBindings = await exists(path.join(runDir, "cms-page-bindings.json"));
    state.update({
      step: hasCmsBindings ? "CMS 准备" : "等待预览确认",
      status: "waiting",
      control: hasCmsBindings ? "awaiting_cms_setup" : "awaiting_preview_confirmation",
      runDir,
      previewPath,
      previewUrl: previewServer.url,
      totalCount: taskCount,
      activeLibraryItemId: libraryItem?.id || "",
      activeLibraryItemName: libraryItem?.name || "",
      waitingReason: hasCmsBindings
        ? `已恢复本轮 CMS 准备状态；未发送任务日期已默认调整为今天 ${defaultDate}。请检查预览并保存后继续创建。`
        : `已从当前页面恢复本轮预览；未发送任务日期已默认调整为今天 ${defaultDate}，请检查并保存后再进入云中客设置。`
    });
    state.log(`已按 runId 恢复当前预览：${previewPath}`);
    return {
      ok: true,
      runDir,
      previewPath,
      previewUrl: previewServer.url,
      taskCount,
      cmsReady: hasCmsBindings
    };
    } finally {
      if (!replacedPreviewServer && previewServer === previousPreviewServer) previousPreviewServer?.resumeMutations?.();
      mutation?.release();
    }
  }

  async function isAbandonedPreviewRun(runId) {
    const runDir = await resolveRunDirFromRequest(projectRoot, { runId }, { runsRoot, previewRecoveryOptions });
    if (!runDir) return false;
    const marker = await readJsonIfExists(path.join(runDir, "flow-abandoned.json"));
    return marker?.abandoned === true;
  }

  async function getPreviewLibrary() {
    try {
      const synced = await syncSharedPreviewLibraryState(projectRoot, sharedLicenseOptions());
      return synced.items;
    } catch (error) {
      state.log(`同步云端共享状态失败：${error?.message || error}`);
      return listPreviewLibrary(projectRoot);
    }
  }

  async function renameLibraryPreview(id, name) {
    const item = await renamePreviewLibraryItem(projectRoot, id, name);
    state.log(`文案库已改名：${item.name}`);
    return { ok: true, item, items: await listPreviewLibrary(projectRoot) };
  }

  async function moveLibraryPreview(id, move) {
    const result = await movePreviewLibraryItem(projectRoot, id, move);
    state.log(`文案库已调整顺序：${result.item?.name || id}`);
    return { ok: true, ...result };
  }

  async function deleteLibraryPreview(id) {
    const item = await deletePreviewLibraryItem(projectRoot, id);
    state.log(`文案库已删除：${item.name || item.id}`);
    return { ok: true, deleted: item, items: await listPreviewLibrary(projectRoot) };
  }

  async function prepareSharedLibraryUpload(id) {
    try {
      const result = await prepareSharedPreviewLibraryItemForUpload(projectRoot, id);
      if (result.ok === false && Array.isArray(result.problems) && result.problems.length) {
        const repair = await openLibraryPreview(id, {
          libraryConfigMode: "saved",
          repairProblem: result.problems[0]
        }).catch((openError) => ({
          ok: false,
          error: openError?.message || String(openError)
        }));
        return {
          ...result,
          error: result.error || result.problems[0]?.message || "素材无法打包到云端。",
          repairPreviewUrl: repair.previewUrl || "",
          repairOpenError: repair.ok === false ? repair.error || "" : ""
        };
      }
      if (result.repairedCount) {
        state.log(`共享文案上传前已自动整理素材：${result.repairedCount} 个`);
      }
      return result;
    } catch (error) {
      const message = error?.message || String(error);
      state.log(`共享文案上传前检查失败：${message}`);
      const problems = Array.isArray(error?.problems) ? error.problems : [];
      return { ok: false, error: message, code: error?.code || "", problems };
    }
  }

  async function uploadSharedLibraryPreview(id, options = {}) {
    const item = await resolvePreviewLibraryItem(projectRoot, id).catch(() => null);
    const previousWaitingReason = state.snapshot().waitingReason || "";
    let lastProgressMessage = "";
    const sharedUploadProgressPatch = (message = "") => ({
      waitingReason: message,
      sharedUploadItemId: id,
      sharedUploadItemName: item?.name || ""
    });
    const clearUploadProgress = () => {
      const current = state.snapshot();
      if (current.sharedUploadItemId !== id) return;
      state.update({
        sharedUploadItemId: "",
        sharedUploadItemName: "",
        ...(current.waitingReason === lastProgressMessage ? { waitingReason: previousWaitingReason } : {})
      });
    };
    try {
      const result = await uploadSharedPreviewLibraryItem(projectRoot, id, {
        ...sharedLicenseOptions(),
        groupName: options.groupName,
        onProgress: async (message) => {
          lastProgressMessage = String(message || "");
          state.update(sharedUploadProgressPatch(lastProgressMessage));
          state.log(`共享文案上传进度：${message}`);
        }
      });
      clearUploadProgress();
      state.log(`共享文案已上传：${result.item?.name || id}`);
      return result;
    } catch (error) {
      const message = error?.message || String(error);
      // Upload and its bounded reconciliation have finished. An old progress
      // message is not evidence that a background operation is still running.
      const pendingSharedUploadProgress = null;
      clearUploadProgress();
      state.log(`共享文案上传失败：${message}`);
      if (error?.diagnosticPath) {
        state.log(`共享文案上传诊断已保存：${error.diagnosticPath}`);
      }
      const problems = Array.isArray(error?.problems) ? error.problems : [];
      if (error?.code === "SHARED_MEDIA_PACKAGE_INCOMPLETE" && problems.length) {
        const repair = await openLibraryPreview(id, {
          libraryConfigMode: "saved",
          repairProblem: problems[0]
        }).catch((openError) => ({
          ok: false,
          error: openError?.message || String(openError)
        }));
        return {
          ok: false,
          error: message,
          code: error.code,
          problems,
          pendingSharedUploadProgress,
          repairPreviewUrl: repair.previewUrl || "",
          repairOpenError: repair.ok === false ? repair.error || "" : ""
        };
      }
      return { ok: false, error: message, code: error?.code || "", problems, pendingSharedUploadProgress };
    }
  }

  async function getSharedPreviewLibrary() {
    try {
      return await listSharedPreviewLibrary(projectRoot, sharedLicenseOptions());
    } catch (error) {
      const message = error?.message || String(error);
      state.log(`读取云端文案失败：${message}`);
      return { ok: false, error: message, items: [] };
    }
  }

  async function downloadSharedLibraryPreview(cloudId, options = {}) {
    try {
      const result = await downloadSharedPreviewLibraryItem(projectRoot, cloudId, { ...sharedLicenseOptions(), ...options });
      state.log(`云端文案已下载到本机文案库：${result.item?.name || cloudId}`);
      return result;
    } catch (error) {
      const message = error?.message || String(error);
      state.log(`云端文案下载失败：${message}`);
      return { ok: false, error: message };
    }
  }

  async function deleteSharedLibraryPreview(cloudId) {
    try {
      const result = await deleteSharedPreviewLibraryItem(projectRoot, cloudId, sharedLicenseOptions());
      state.log(`云端文案已删除：${result.deleted?.name || cloudId}`);
      return result;
    } catch (error) {
      const message = error?.message || String(error);
      state.log(`云端文案删除失败：${message}`);
      return { ok: false, error: message };
    }
  }

  async function exportSharedLibraryPreview(id) {
    try {
      const result = await exportSharedPreviewLibraryItem(projectRoot, id);
      state.log(`共享包已导出：${result.filePath}`);
      return result;
    } catch (error) {
      const message = error?.message || String(error);
      state.log(`共享包导出失败：${message}`);
      return { ok: false, error: message };
    }
  }

  async function importSharedLibraryPreviewPackage(input) {
    try {
      const result = await importSharedPreviewLibraryPackage(projectRoot, input);
      state.log(`共享包已导入：${result.item?.name || input?.fileName || "未命名文案"}`);
      return result;
    } catch (error) {
      const message = error?.message || String(error);
      state.log(`共享包导入失败：${message}`);
      return { ok: false, error: message };
    }
  }

  async function importSharedLibraryPreviewFile(input, options = {}) {
    try {
      const result = await importSharedPreviewLibraryFile(projectRoot, input, options);
      state.log(`共享包已导入：${result.item?.name || input?.fileName || "未命名文案"}`);
      return result;
    } catch (error) {
      const message = error?.message || String(error);
      state.log(`共享包导入失败：${message}`);
      return { ok: false, error: message };
    }
  }

  function sharedLicenseOptions() {
    return {
      fetch: licenseOptions.fetch || licenseFetch,
      appVersion: licenseOptions.appVersion,
      licenseConfig: licenseOptions.licenseConfig,
      instanceId: instanceConfig.id
    };
  }

  async function openLibraryPreview(id, settings = {}) {
    assertCmsInputsMutable("恢复或打开文案库预览");
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    const currentPageSettings = normalizeConsoleSettings(settings);
    const requestedConfigMode = settings.libraryConfigMode === "current" ? "current" : "saved";
    const libraryItem = await resolvePreviewLibraryItem(projectRoot, id);
    const savedSettings = libraryItem.settingsSnapshot && typeof libraryItem.settingsSnapshot === "object"
      ? normalizeConsoleSettings(libraryItem.settingsSnapshot)
      : null;
    const useSavedSettings = requestedConfigMode === "saved" && savedSettings;
    const normalized = useSavedSettings ? savedSettings : currentPageSettings;
    currentSettings = normalized;
    detachPreparedCmsRun();
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const useCurrentPageConfig = requestedConfigMode === "current";
    const repairProblem = normalizeRepairProblem(settings.repairProblem);
    const defaultDate = useCurrentPageConfig
      ? (normalizeSendDate(normalized.date || "") || todayMonthDay())
      : "";
    const shouldReassignPreciseTuo = useCurrentPageConfig && settings.reassignPreciseTuo === true;
    const preciseTuo = shouldReassignPreciseTuo
      ? await loadRegisteredTuoRoster(normalized, projectRoot)
      : null;
    const item = await createPreviewLibraryWorkingRun(projectRoot, id, {
      runsRoot,
      defaultDate,
      robotStrategy: normalized.robotStrategy,
      configMode: useCurrentPageConfig ? "current" : "saved",
      preciseTuoRoster: preciseTuo?.roster || null,
      preciseTuoOptions: shouldReassignPreciseTuo
        ? {
          rotationSeed: `${id}:${preciseTuo.scopeId}`,
          scopeId: preciseTuo.scopeId,
          usageHistory: preciseTuo.usageHistory
        }
        : {},
      scheduleOptions: useCurrentPageConfig
        ? buildPreviewScheduleOptions(normalized, {
          phase: "regenerate-preview",
          currentDate: defaultDate,
          interactionOrderMode: normalized.robotStrategy === "random" ? "group" : "source"
        })
        : null
    });
    const previousPreviewUrl = previewServer?.url || "";
    await previewServer?.close?.().catch(() => {});
    previewServer = await createPreviewServerForRun(item.workDir, {
      config,
      defaultDate,
      reason: `已从文案库打开预览，可发送条目的日期已默认改为今天 ${defaultDate}`
    });
    state.update({
      step: "等待预览确认",
      status: "waiting",
      control: "awaiting_preview_confirmation",
      runDir: item.workDir,
      previewPath: item.workPreviewPath,
      previewUrl: previewServer.url,
      totalCount: item.taskCount,
      activeLibraryItemId: item.id,
      activeLibraryItemName: item.name || "",
      waitingReason: useCurrentPageConfig
        ? `已按当前页面配置打开文案库预览页，可发送条目的日期已默认改为今天 ${defaultDate}。请检查时间、托和云中客配置后再确认发单。`
        : (useSavedSettings
          ? "已按文案库保存时配置打开预览页。可修改时间/内容，保存后确认发单。"
          : "已按文案库保存的预览内容打开；这份旧文案没有保存原配置，正式发单配置请在控制台确认后再继续。")
    });
    state.log(useCurrentPageConfig
      ? `文案库打开预览：${item.name}；模式=当前页面配置；工作副本=${item.workPreviewPath}；可发送条目日期默认=${defaultDate}`
      : `文案库打开预览：${item.name}；模式=文案库原配置；工作副本=${item.workPreviewPath}；原配置快照=${useSavedSettings ? "有" : "无"}`);
    if (item.preciseTuoReport) {
      state.log(`文案库精准托重分配完成：托词 ${item.preciseTuoReport.assignedCount}/${item.preciseTuoReport.tuoTaskCount} 条；名单=${preciseTuo?.filePath || ""}`);
    }
    state.log(`预览页：${previewServer.url}`);
    const previewUrlForOpen = withPreviewRunParams(previewServer.url, item.workDir, repairProblem ? {
      repairMode: "shared-upload",
      problemIndex: String(repairProblem.index),
      problemReason: repairProblem.message || repairProblem.reason || ""
    } : {});
    await openControlledPreviewPage(projectRoot, config, previewUrlForOpen, browserInstanceOptions, {
      replaceUrl: previousPreviewUrl
    });
    const recoveryWarning = await recordCreatedPreviewSafely(item.workDir, {
      source: "文案库",
      documentName: item.name,
      taskCount: item.taskCount
    });
    return {
      ok: true,
      item,
      runDir: item.workDir,
      previewPath: item.workPreviewPath,
      previewUrl: previewUrlForOpen,
      taskCount: item.taskCount,
      configMode: useCurrentPageConfig ? "current" : "saved",
      hasSavedSettings: Boolean(useSavedSettings),
      recoveryWarning
    };
  }

  async function openCombinedLibraryPreview(ids = [], settings = {}) {
    assertCmsInputsMutable("打开拼接文案库预览");
    if (running) throw new Error("已有流程正在运行，请等当前流程结束。");
    const normalized = normalizeConsoleSettings(settings);
    currentSettings = normalized;
    detachPreparedCmsRun();
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const defaultDate = normalizeSendDate(normalized.date || "") || todayMonthDay();
    const preciseTuo = normalized.robotStrategy === "precise"
      ? await loadRegisteredTuoRoster(normalized, projectRoot)
      : null;
    const combinedScheduleSettings = normalized.scheduleMode === "doc"
      ? { ...normalized, scheduleMode: "realtime", realtimeStartMode: "normal", realtimeStartTime: "" }
      : normalized;
    const item = await createCombinedPreviewLibraryWorkingRun(projectRoot, ids, {
      runsRoot,
      defaultDate,
      robotStrategy: normalized.robotStrategy,
      preciseTuoRoster: preciseTuo?.roster || null,
      preciseTuoOptions: preciseTuo
        ? {
          rotationSeed: `combined:${ids.join(":")}:${preciseTuo.scopeId}`,
          scopeId: preciseTuo.scopeId,
          usageHistory: preciseTuo.usageHistory
        }
        : {},
      scheduleOptions: buildPreviewScheduleOptions(combinedScheduleSettings, {
        phase: "regenerate-preview",
        currentDate: defaultDate,
        interactionOrderMode: normalized.robotStrategy === "random" ? "group" : "source"
      })
    });
    const previousPreviewUrl = previewServer?.url || "";
    await previewServer?.close?.().catch(() => {});
    previewServer = await createPreviewServerForRun(item.workDir, {
      config,
      defaultDate,
      reason: `已按所选顺序拼接 ${item.segments.length} 份文案，并按当前页面配置统一排程`
    });
    state.update({
      step: "等待预览确认",
      status: "waiting",
      control: "awaiting_preview_confirmation",
      runDir: item.workDir,
      previewPath: item.workPreviewPath,
      previewUrl: previewServer.url,
      totalCount: item.taskCount,
      activeLibraryItemId: "",
      activeLibraryItemName: item.name,
      waitingReason: `已拼接 ${item.segments.length} 份文案，共 ${item.taskCount} 条；已统一连续排程${normalized.scheduleMode === "doc" ? "（原文时间模式自动改为当前时间 1 分钟后开始）" : ""}。请按分段标头检查后再确认发单。`
    });
    state.log(`文案库拼接预览：${item.segments.map((segment) => `${segment.index}.${segment.name}`).join("；")}；工作副本=${item.workPreviewPath}`);
    if (item.preciseTuoReport) {
      state.log(`拼接预览精准托统一分配完成：托词 ${item.preciseTuoReport.assignedCount}/${item.preciseTuoReport.tuoTaskCount} 条。`);
    }
    await openControlledPreviewPage(projectRoot, config, withPreviewRunParams(previewServer.url, item.workDir), browserInstanceOptions, {
      replaceUrl: previousPreviewUrl
    });
    const recoveryWarning = await recordCreatedPreviewSafely(item.workDir, {
      source: "文案库拼接",
      documentName: item.name,
      taskCount: item.taskCount
    });
    return {
      ok: true,
      item: {
        combined: true,
        name: item.name,
        segments: item.segments,
        taskCount: item.taskCount
      },
      runDir: item.workDir,
      previewPath: item.workPreviewPath,
      previewUrl: previewServer.url,
      taskCount: item.taskCount,
      recoveryWarning
    };
  }

  async function runGeneratePreview(settings) {
    const normalized = normalizeConsoleSettings(settings);
    const previousFeishuUrl = normalizeFeishuUrl(settings.previousFeishuUrl || "");
    currentSettings = normalized;
    const runName = `v2_real_flow_${timestamp()}`;
    const runDir = path.join(runsRoot, runName);
    let opened;
    detachPreparedCmsRun();
    state.resetForRun("采集飞书");
    state.update({ runDir, previewPath: "", previewUrl: "" });

    try {
      await fs.mkdir(runDir, { recursive: true });
      await clearCmsPageBindings(runDir);
      state.log(`run 目录：${runDir}`);

      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const controlledBrowser = await loadControlledBrowserState(projectRoot, config, browserInstanceOptions);
      if (!controlledBrowser.cdpUrl) {
        throw new Error("当前没有检测到 2.0 专用可控浏览器/CDP。请从“2.0可视化控制台”正式入口重新启动。");
      }
      const options = collectGenerateOptions(normalized);
      const url = normalizeFeishuUrl(options.url || config.feishuUrl);
      if (!url) throw new Error("缺少飞书文档链接。");
      const linkChanged = Boolean(previousFeishuUrl && previousFeishuUrl !== url);
      state.log(`本次使用的飞书链接：${url}`);
      state.log(`飞书链接是否和上次不同：${linkChanged ? "是" : "否"}`);
      if (normalized.rangeMode === "range" && !options.startKeyword) {
        throw new Error("指定范围模式必须填写开始位置。");
      }
      if (normalized.rangeMode === "heading" && normalized.headingSelectionMode === "range" && (!options.headingStartDay || !options.headingEndDay)) {
        throw new Error("按天数范围选择模式必须选择开始第几天和结束第几天。");
      }
      if (normalized.rangeMode === "heading" && normalized.headingSelectionMode !== "range" && !options.headingDay) {
        throw new Error("按节奏/天数选择模式必须先选择第几天。");
      }
      const baseSendDate = resolveBaseSendDate(normalized.date);
      state.log(formatRangeLog(normalized));
      state.log(`本轮基础发单日期：${baseSendDate}${normalized.date ? "" : "（控制台未填写日期，默认今天）"}`);

      state.update({ step: "采集飞书", waitingReason: normalized.rangeMode === "heading" ? "正在打开飞书并按目录标题确定读取范围" : "正在打开飞书文档并滚动采集" });
      opened = await openRealFeishuCollectPage({
        url,
        cdpUrl: controlledBrowser.cdpUrl,
        headless: false,
        timeoutMs: 30000
      });
      await opened.page.waitForTimeout(2500).catch(() => {});
      state.update({ feishuUrl: url, feishuTitle: opened.title || normalized.feishuTitle || "", feishuTitleUrl: url });
      state.log(`读取到的文档标题：${opened.title || normalized.feishuTitle || "未读取到标题"}`);

      const headingRange = normalized.rangeMode === "heading"
        ? await resolveHeadingRangeFromPage(opened.page, normalized, state)
        : null;
      const collectStartKeyword = headingRange ? headingRange.startTitle : options.startKeyword;
      const collectEndKeyword = headingRange ? headingRange.endTitle : options.endKeyword;
      const collectEndAtDocumentEnd = headingRange ? !headingRange.endTitle : options.endAtDocumentEnd;

      const collectOptions = {
        scanFullPage: true,
        startKeyword: normalized.rangeMode === "full" ? "" : collectStartKeyword,
        endKeyword: normalized.rangeMode === "full" || collectEndAtDocumentEnd ? "" : collectEndKeyword,
        requireStartKeywordSearch: normalized.rangeMode === "range",
        requireDocumentEnd: normalized.rangeMode === "full",
        deferMediaMaterialization: true,
        forceFinderCodeBlockCopy: true,
        maxSteps: normalized.rangeMode === "full" ? 240 : undefined,
        mediaCacheDir: path.join(runDir, "media-cache"),
        diagnosticsDir: path.join(runDir, "diagnostics")
      };
      let collected;
      try {
        collected = await collectRawEventsFromPageWithDiagnostics(opened.page, collectOptions);
      } catch (error) {
        if (!isClosedPageError(error)) throw error;
        state.log("飞书页面在采集时已关闭，重新打开当前飞书链接后重试一次；不会改成全文读取，也不会复用旧结果。");
        await closeOpenedFeishuPage(opened, state);
        opened = await openRealFeishuCollectPage({
          url,
          cdpUrl: controlledBrowser.cdpUrl,
          headless: false,
          timeoutMs: 30000
        });
        await opened.page.waitForTimeout(2500).catch(() => {});
        state.update({ feishuUrl: url, feishuTitle: opened.title || normalized.feishuTitle || "", feishuTitleUrl: url });
        state.log(`重新打开飞书文档：${url}；标题=${opened.title || normalized.feishuTitle || "未读取到标题"}`);
        collected = await collectRawEventsFromPageWithDiagnostics(opened.page, collectOptions);
      }
      await saveJson(path.join(runDir, "collect-diagnostics.json"), collected.diagnostics);
      appendSearchTraceLogs(state, collected.diagnostics);
      if (collected.diagnostics?.failure) {
        throw collectError("collect_failed", collected.diagnostics.failure);
      }
      const rawEvents = validateCollectedRawEvents(collected.events, {
        ...buildChecks(normalized),
        allowTemporaryMedia: true
      });
      if (normalized.rangeMode === "full") validateFullReadCompleteness(rawEvents, collected.diagnostics);
      await saveJson(path.join(runDir, "raw-events.json"), rawEvents);
      const rawSummary = summarizeRawEvents(rawEvents);
      state.log(`采集完成：${rawSummary.total} 条 raw-events；首条=${formatEventIdentity(rawSummary.firstEvent)}；末条=${formatEventIdentity(rawSummary.lastEvent)}`);

      state.update({ step: "范围解析", waitingReason: rangeWaitingReason(normalized.rangeMode) });
      state.log("进入范围解析");
      let rangeResult;
      try {
        rangeResult = rangeResultForMode(rawEvents, normalized, options, headingRange, baseSendDate);
      } catch (error) {
        if (normalized.rangeMode === "range" && isRangeLocateError(error)) {
          state.log(formatManualRangeFailureLog(normalized, error));
        }
        throw error;
      }
      if (normalized.rangeMode === "range") {
        state.log(formatManualRangeDiagnosticsLog(normalized, rangeResult.diagnostics));
      }
      state.update({ step: "素材落地", waitingReason: "按当前读取范围统一落地图片、表情包和视频素材" });
      const rangeEvents = validateCollectedRawEvents(await materializeRawEventMediaFromPage(opened.page, rangeResult.events, {
        mediaCacheDir: path.join(runDir, "media-cache"),
        onProgress: (progress) => {
          const message = formatMediaMaterializeProgress(progress);
          if (!message) return;
          state.update({ step: "素材落地", waitingReason: message });
          state.log(message);
        }
      }), {
        requireLocalMedia: true
      });
      await saveJson(path.join(runDir, "range-events.json"), rangeEvents);
      await saveJson(path.join(runDir, "range-diagnostics.json"), rangeResult.diagnostics);
      state.log(`范围解析完成：${rangeEvents.length} 条 events；范围内素材已统一落地到 media-cache`);

      state.update({ step: "生成 preview-tasks.json", waitingReason: "解析角色、互动托、时间模式" });
      const scheduleOptions = buildPreviewScheduleOptions(config, {
        ...options,
        phase: "generate-preview",
        interactionOrderMode: normalized.robotStrategy === "random" ? "group" : "source"
      });
      const parsed = parseFixedFormatTasks(rangeEvents, {
        scheduleMode: scheduleOptions.mode,
        baseSendDate
      });
      let prepared = preparePreviewTasksForGeneration(parsed.tasks, scheduleOptions);
      let previewTasks = applyDefaultDate(prepared.tasks, baseSendDate);
      let preciseTuoReport = null;
      if (normalized.robotStrategy === "precise") {
        const assignment = await applyPreciseTuoAssignment(previewTasks, normalized, projectRoot, {
          rotationSeed: runName,
          previousCooldownNicknames: settings.previousSuccessTuoCooldown === true
            ? settings.previousSuccessTuoNicknames
            : []
        });
        previewTasks = assignment.tasks;
        preciseTuoReport = assignment.report;
        await saveJson(path.join(runDir, "precise-tuo-report.json"), preciseTuoReport);
        state.log(`精准托分配完成：托词 ${preciseTuoReport.assignedCount}/${preciseTuoReport.tuoTaskCount} 条；兜底 ${preciseTuoReport.fallbackCount} 条；备用 ${preciseTuoReport.backupCount} 条`);
      }
      if (scheduleOptions.mode === "realtime" && scheduleOptions.startMode === "reverse") {
        prepared = preparePreviewTasksForGeneration(previewTasks, scheduleOptions);
        previewTasks = applyDefaultDate(prepared.tasks, baseSendDate);
        state.log(formatReverseStartEstimate(prepared.startEstimate));
      }
      for (const task of previewTasks) validatePreviewTaskShape(task);
      if (normalized.rangeMode === "full" && previewTasks.length <= 0) {
        throw new Error("全文读取没有解析出任何 preview-tasks，已停止。");
      }
      await saveJson(previewTasksPath(runDir), previewTasks);
      await saveJson(path.join(runDir, "console-generate-report.json"), {
        ok: true,
        runDir,
        robotStrategy: normalized.robotStrategy,
        documentTitle: opened.title || normalized.feishuTitle || "",
        documentUrl: url,
        previousDocumentUrl: previousFeishuUrl,
        documentUrlChanged: linkChanged,
        readRange: {
          mode: normalized.rangeMode,
          sourceMode: rangeSourceModeLabel(normalized.rangeMode),
          label: rangeReportLabel(normalized, headingRange),
          startKeyword: normalized.rangeMode === "full" ? "" : collectStartKeyword,
          endKeyword: normalized.rangeMode === "full" ? "" : collectEndKeyword,
          headingSelectionMode: normalized.rangeMode === "heading" ? normalized.headingSelectionMode : "",
          headingDay: normalized.rangeMode === "heading" ? normalized.headingDay : "",
          headingRhythm: normalized.rangeMode === "heading" ? normalized.headingRhythm : "",
          headingStartDay: normalized.rangeMode === "heading" ? normalized.headingStartDay : "",
          headingStartRhythm: normalized.rangeMode === "heading" ? normalized.headingStartRhythm : "",
          headingEndDay: normalized.rangeMode === "heading" ? normalized.headingEndDay : "",
          headingEndRhythm: normalized.rangeMode === "heading" ? normalized.headingEndRhythm : "",
          baseSendDate,
          documentEndConfirmed: Boolean(collected.diagnostics?.documentEndConfirmed)
        },
        rawEventCount: rawEvents.length,
        rangeEventCount: rangeEvents.length,
        previewTaskCount: previewTasks.length,
        firstTask: summarizePreviewIdentity(previewTasks[0]),
        lastTask: summarizePreviewIdentity(previewTasks.at(-1)),
        schedule: {
          mode: prepared.mode,
          interactionReordered: prepared.interactionReordered,
          startMode: prepared.startMode || scheduleOptions.startMode || "normal",
          startTime: scheduleOptions.startTime || prepared.startEstimate?.predictedStartTime || "",
          endTime: scheduleOptions.endTime || "",
          intervals: scheduleOptions.intervals || {},
          startEstimate: prepared.startEstimate || null,
          taskTimeSignature: previewTaskTimeSignature(previewTasks),
          diagnostics: [...parsed.diagnostics, ...prepared.diagnostics]
        },
        preciseTuo: preciseTuoReport,
        taskCount: previewTasks.length
      });
      state.update({ totalCount: previewTasks.length });
      state.log(`preview-tasks.json 已生成：${previewTasks.length} 条；首条=${formatTaskIdentity(previewTasks[0])}；末条=${formatTaskIdentity(previewTasks.at(-1))}`);

      state.update({ step: "生成预览内容", waitingReason: "初始化人工确认文件" });
      const previewState = await loadPreviewForOpen(runDir, { regenerate: true, defaultDate: baseSendDate });
      const previewPath = finalPreviewPath(runDir);
      if (!await exists(previewTasksPath(runDir)) || !await exists(previewPath)) {
        throw new Error("新运行目录缺少预览内容，已停止。");
      }
      const mediaRisk = await applyPreviewMediaRiskWarnings(runDir, config);
      const previewReason = mediaRisk.message
        ? "预览已生成；有素材超过云中客上传限制或可能触发压缩提示，请先处理黄色提示后再继续。"
        : "请在预览页检查、修改并保存预览内容";
      const previousPreviewUrl = previewServer?.url || "";
      await previewServer?.close?.().catch(() => {});
      previewServer = await createPreviewServerForRun(runDir, {
        config,
        defaultDate: baseSendDate,
        reason: previewReason
      });
      state.update({
        step: "等待预览确认",
        status: "waiting",
        control: "awaiting_preview_confirmation",
        previewPath,
        previewUrl: previewServer.url,
        waitingReason: previewReason
      });
      state.log(`预览内容已生成：${previewPath}`);
      state.log(`预览内容条目：${previewState.tasks.length} 条`);
      state.log(`预览页：${previewServer.url}`);
      await openControlledPreviewPage(projectRoot, config, withPreviewRunParams(previewServer.url, runDir), browserInstanceOptions, {
        replaceUrl: previousPreviewUrl
      });
      const recoveryWarning = await recordCreatedPreviewSafely(runDir, {
        source: "浏览器采集",
        documentName: opened.title || normalized.feishuTitle || runName,
        taskCount: previewTasks.length
      });
      return {
        ok: true,
        runDir,
        previewPath,
        previewUrl: previewServer.url,
        source: previewState.source,
        taskCount: previewTasks.length,
        recoveryWarning
      };
    } catch (error) {
      await saveFlowError(runDir, state.snapshot().step || "生成预览", error);
      const files = await keyFiles(runDir);
      state.fail(state.snapshot().step || "生成预览", error?.message || String(error), {
        runDir,
        previewPath: "",
        previewUrl: "",
        missingFiles: missingKeyFiles(files)
      });
      return {
        ok: false,
        runDir,
        error: error?.message || String(error),
        files
      };
    } finally {
      await closeOpenedFeishuPage(opened, state);
    }
  }

  async function runImportDocumentPreview(input, settings, operation) {
    const normalized = normalizeConsoleSettings(settings);
    currentSettings = normalized;
    const apiMode = input?.mode === "feishu-api";
    const runName = `${apiMode ? "v2_feishu_api" : "v2_doc_import"}_${timestamp()}`;
    const runDir = path.join(runsRoot, runName);
    detachPreparedCmsRun();
    const progressGeneration = ++feishuProgressGeneration;
    const progressStartedAt = Date.now();
    state.resetForRun(apiMode ? "飞书 API 读取" : "导入文档");
    state.update({ runDir, previewPath: "", previewUrl: "" });
    const runGeneration = state.snapshot().runGeneration;
    operation.runGeneration = runGeneration;

    try {
      await fs.mkdir(runDir, { recursive: true });
      await clearCmsPageBindings(runDir);
      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const baseSendDate = resolveBaseSendDate(normalized.date);
      state.log(`${apiMode ? "飞书 API" : "文档导入"} run 目录：${runDir}`);
      state.log(`本轮基础发单日期：${baseSendDate}${normalized.date ? "" : "（控制台未填写日期，默认今天）"}`);

      let importInput = input;
      let apiResult = null;
      let mediaRecoveryHandler = null;
      if (apiMode) {
        state.update({ step: "飞书 API 读取", waitingReason: "正在固定文档结构；读取期间请勿修改文档，并提醒其他协作者暂时不要编辑" });
        apiResult = await effectiveFeishuReader({ documentUrl: input.documentUrl }, {
          downloadMedia: false,
          signal: operation.controller.signal,
          onRequestStart: ({ requestId }) => {
            operation.requestId = String(requestId || "");
            if (operation.cancelRequested) startBackendCancellation(operation);
          },
          progress: (progress) => {
            if (progress?.requestId && !operation.requestId) {
              operation.requestId = String(progress.requestId);
              if (operation.cancelRequested) startBackendCancellation(operation);
            }
            if (!isCurrentOperation(operation, progressGeneration, runGeneration)) return;
            if (state.snapshot().feishuProgress?.terminal === true) return;
            const formatted = formatFeishuApiProgress(progress, progressStartedAt);
            state.update({ step: formatted.stage, waitingReason: formatted.display, feishuProgress: formatted });
            if (formatted.loggable) state.log(`飞书 API：${formatted.display}`);
          }
        });
        await operationCheckpoint(operation, progressGeneration, runGeneration, "读取飞书响应后");
        await saveJson(path.join(runDir, "feishu-structure-snapshot.json"), {
          schemaVersion: 1,
          title: apiResult.report.title,
          revision: apiResult.report.revision,
          readAttempts: Number(apiResult.report.readAttempts || 1),
          pages: apiResult.report.pages,
          blockCount: apiResult.report.blockCount,
          rows: (apiResult.report.rows || []).map((row) => ({
            blockId: String(row.blockId || ""),
            order: Number(row.order || 0),
            depth: Number(row.depth || 0),
            headingLevel: Number(row.headingLevel || 0) || null,
            type: String(row.type || ""),
            label: String(row.label || ""),
            text: String(row.text || ""),
            segments: Array.isArray(row.segments) ? row.segments : [],
            sourceOccurrenceId: String(row.sourceOccurrenceId || ""),
            sourceSegmentIds: Array.isArray(row.sourceSegmentIds) ? row.sourceSegmentIds : [],
            declaredMediaKind: String(row.mediaKindHint || ""),
            mediaError: String(row.mediaError || "")
          }))
        });
        const apiEvents = await materializeFeishuApiRawEvents(apiResult, {
          mediaCacheDir: path.join(runDir, "media-cache"),
          allowPendingMedia: true
        });
        await operationCheckpoint(operation, progressGeneration, runGeneration, "素材落盘后");
        importInput = {
          mode: "feishu-api-materialized",
          sourceFeishuUrl: input.documentUrl,
          fileName: apiResult.report.title,
          apiEvents
        };
        state.update({ feishuUrl: input.documentUrl, feishuTitle: apiResult.report.title, feishuTitleUrl: input.documentUrl });
      }
      state.update({
        step: apiMode ? "转换飞书 API 内容" : "导入文档",
        waitingReason: apiMode ? "正在按文档块顺序转换为 RawEvent" : "正在解析上传/粘贴/下载的文档内容",
        ...(apiMode ? { feishuProgress: localFeishuProgress("客户端解析", "正在转换 RawEvent", progressStartedAt) } : {})
      });
      let imported = apiMode
        ? {
          events: importInput.apiEvents,
          diagnostics: {
            source: "feishu-api",
            importedAs: "feishu-api",
            title: apiResult.report.title,
            revision: apiResult.report.revision,
            pages: apiResult.report.pages,
            blockCount: apiResult.report.blockCount,
            textCount: apiResult.report.textCount,
            mediaCount: apiResult.report.mediaCount,
            downloadedCount: apiResult.report.downloadedCount,
            warnings: apiResult.report.warnings
          }
        }
        : importDocumentToRawEvents(importInput, { projectRoot, runDir });
      let rawEvents = apiMode ? imported.events : validateCollectedRawEvents(imported.events, { allowTemporaryMedia: true });
      if (apiMode) assertFeishuManifestMappedToRawEvents(apiResult, rawEvents);
      await operationCheckpoint(operation, progressGeneration, runGeneration, "转换 RawEvent 后");
      let rangeResult = fullRangeResult(rawEvents);
      let apiHeadingRange = null;
      if (apiMode) {
        const options = collectGenerateOptions(normalized);
        if (normalized.rangeMode === "range" && !options.startKeyword) throw new Error("指定范围模式必须填写开始位置。");
        if (normalized.rangeMode === "heading") {
          const structure = buildHeadingStructure(rawEvents.filter((event) => event.kind === "title").map((event) => ({
            text: event.text,
            level: event.headingLevel,
            blockId: event.blockId,
            sourceId: event.sourceId,
            order: event.order
          })));
          apiHeadingRange = normalized.headingSelectionMode === "range"
            ? resolveHeadingDayRangeSelection(structure, normalized)
            : resolveHeadingSelection(structure, normalized);
        }
        rangeResult = rangeResultForMode(rawEvents, normalized, options, apiHeadingRange, baseSendDate);
      }
      if (apiMode) {
        const rangeMediaSourceIds = rangeResult.events
          .filter((event) => event.feishuMediaStatus || ["image", "sticker", "video", "unknown-media"].includes(event.kind))
          .map((event) => event.sourceId);
        const pendingMedia = rangeResult.events.some((event) => event.feishuMediaStatus === "pending");
        if (pendingMedia) {
          // A readable preview does not depend on a media quota or an outage ending.
          apiResult = await downloadSelectedFeishuMedia(apiResult, {
            sourceIds: rangeMediaSourceIds,
            mediaSourceIds: rangeMediaSourceIds,
            deferDownloads: true
          });
          await saveJson(path.join(runDir, "feishu-media-manifest.json"), apiResult.selectedMediaManifest);
          mediaRecoveryHandler = await prepareFeishuMediaRecovery(runDir, apiResult, {
            documentUrl: input.documentUrl,
            sourceIds: rangeMediaSourceIds,
            ...mediaRecoveryOptions()
          });
          state.log(`正文与范围已就绪，${rangeMediaSourceIds.length} 项素材将在预览页逐项获取并保存；临时故障会等待恢复。`);
          const materializedEvents = await materializeFeishuApiRawEvents(apiResult, {
            mediaCacheDir: path.join(runDir, "media-cache")
          });
          rawEvents = validateCollectedRawEvents(materializedEvents, { allowTemporaryMedia: true });
          imported = {
            ...imported,
            events: rawEvents,
            diagnostics: {
              ...imported.diagnostics,
              downloadedCount: apiResult.report.downloadedCount,
              selectedMediaCount: apiResult.report.selectedMediaCount,
              downloadedBytes: apiResult.report.downloadedBytes,
              retryRecoveredCount: apiResult.report.retryRecoveredCount,
              manualRequiredCount: apiResult.report.manualRequiredCount,
              mediaCompleteness: apiResult.report.mediaCompleteness
            }
          };
          rangeResult = rangeResultForMode(rawEvents, normalized, collectGenerateOptions(normalized), apiHeadingRange, baseSendDate);
        } else {
          rawEvents = validateCollectedRawEvents(rawEvents, { allowTemporaryMedia: true });
        }
      }
      const rangeEvents = rangeResult.events;
      await operationCheckpoint(operation, progressGeneration, runGeneration, "范围截取后");
      await saveJson(path.join(runDir, "document-import-report.json"), imported.diagnostics);
      await saveJson(path.join(runDir, "raw-events.json"), rawEvents);
      await operationCheckpoint(operation, progressGeneration, runGeneration, "保存 RawEvent 后");
      await saveJson(path.join(runDir, "range-events.json"), rangeEvents);
      await saveJson(path.join(runDir, "range-diagnostics.json"), apiMode ? rangeResult.diagnostics : {
          mode: "document-paste",
        source: imported.diagnostics.source,
        warnings: imported.diagnostics.warnings || []
      });
      state.log(`${apiMode ? "飞书 API 读取" : "文档导入"}完成：${rawEvents.length} 条 raw-events；范围内 ${rangeEvents.length} 条；文本 ${imported.diagnostics.textCount} 条；素材 ${imported.diagnostics.mediaCount} 个`);
      for (const warning of imported.diagnostics.warnings || []) state.log(`导入提示：${warning}`);

      state.update({ step: "生成 preview-tasks.json", waitingReason: "解析角色、视频号、时间模式，并尝试下载导入素材" });
      if (apiMode) {
        state.update({ feishuProgress: localFeishuProgress("生成预览", `正在解析 ${rangeEvents.length} 条 RawEvent`, progressStartedAt, {
          completed: 0, total: rangeEvents.length, unit: "条 RawEvent"
        }) });
      }
      const scheduleOptions = buildPreviewScheduleOptions(config, {
        ...collectGenerateOptions(normalized),
        phase: "generate-preview",
        interactionOrderMode: normalized.robotStrategy === "random" ? "group" : "source"
      });
      const parsed = parseFixedFormatTasks(rangeEvents, {
        scheduleMode: scheduleOptions.mode,
        baseSendDate
      });
      const parsedSourceEvents = Array.isArray(parsed.sourceEvents) ? parsed.sourceEvents : rangeEvents;
      const mediaRecovery = apiMode
        ? recoverFeishuRangeMediaPreviewTasks(parsedSourceEvents, parsed.tasks, {
          diagnostics: parsed.diagnostics,
          baseSendDate
        })
        : { tasks: parsed.tasks, recovered: [], degraded: false };
      if (mediaRecovery.recovered.length) {
        state.log(`系统已把 ${mediaRecovery.recovered.length} 个未能自动归属的原文位置保留为预览标红行，需人工确认后才能创建。`);
      }
      if (apiMode) await saveJson(path.join(runDir, "source-audit.json"), mediaRecovery.audit);
      let prepared = preparePreviewTasksForGeneration(mediaRecovery.tasks, scheduleOptions);
      await operationCheckpoint(operation, progressGeneration, runGeneration, "正文解析后");
      let previewTasks = applyDefaultDate(prepared.tasks, baseSendDate);
      previewTasks = await localizePreviewTaskMediaWithFetch(previewTasks, {
        runDir,
        mediaCacheDir: path.join(runDir, "media-cache")
      });
      await operationCheckpoint(operation, progressGeneration, runGeneration, "预览素材本地化后");
      if (apiMode) assertFeishuRangeMediaMappedToPreview(rangeEvents, previewTasks, { diagnostics: parsed.diagnostics });
      const mediaFailures = previewTasks.filter((task) => task.mediaDownloadError);
      if (mediaFailures.length) {
        state.log(`导入素材下载失败 ${mediaFailures.length} 个，预览页会保留素材地址并在保存/创建前提示更换。`);
      }
      let preciseTuoReport = null;
      if (normalized.robotStrategy === "precise") {
        const assignment = await applyPreciseTuoAssignment(previewTasks, normalized, projectRoot, {
          rotationSeed: runName,
          previousCooldownNicknames: settings.previousSuccessTuoCooldown === true
            ? settings.previousSuccessTuoNicknames
            : []
        });
        previewTasks = assignment.tasks;
        preciseTuoReport = assignment.report;
        await saveJson(path.join(runDir, "precise-tuo-report.json"), preciseTuoReport);
        state.log(`精准托分配完成：托词 ${preciseTuoReport.assignedCount}/${preciseTuoReport.tuoTaskCount} 条；兜底 ${preciseTuoReport.fallbackCount} 条；备用 ${preciseTuoReport.backupCount} 条`);
      }
      if (scheduleOptions.mode === "realtime" && scheduleOptions.startMode === "reverse") {
        prepared = preparePreviewTasksForGeneration(previewTasks, scheduleOptions);
        previewTasks = applyDefaultDate(prepared.tasks, baseSendDate);
        state.log(formatReverseStartEstimate(prepared.startEstimate));
      }
      for (const task of previewTasks) validatePreviewTaskShape(task);
      if (!previewTasks.length) throw new Error("导入文档没有解析出任何 preview-tasks，已停止。请检查是否保留了说话人和时间格式。");
      await operationCheckpoint(operation, progressGeneration, runGeneration, "保存预览任务前");
      await saveJson(previewTasksPath(runDir), previewTasks);
      await saveJson(path.join(runDir, "console-generate-report.json"), {
        ok: true,
        runDir,
        robotStrategy: normalized.robotStrategy,
        documentTitle: importInput.fileName || normalized.feishuTitle || "导入文档",
        documentUrl: importInput.sourceFeishuUrl || "",
        readRange: {
          mode: apiMode ? normalized.rangeMode : "document-paste",
          sourceMode: apiMode ? "飞书 API 读取" : "直接粘贴内容",
          label: apiMode ? rangeReportLabel(normalized, apiHeadingRange) : importInput.fileName || input.fileName || "粘贴内容",
          baseSendDate
        },
        import: imported.diagnostics,
        rawEventCount: rawEvents.length,
        rangeEventCount: rangeEvents.length,
        parsedSourceEventCount: parsedSourceEvents.length,
        previewTaskCount: previewTasks.length,
        firstTask: summarizePreviewIdentity(previewTasks[0]),
        lastTask: summarizePreviewIdentity(previewTasks.at(-1)),
        schedule: {
          mode: prepared.mode,
          interactionReordered: prepared.interactionReordered,
          startMode: prepared.startMode || scheduleOptions.startMode || "normal",
          startTime: scheduleOptions.startTime || prepared.startEstimate?.predictedStartTime || "",
          endTime: scheduleOptions.endTime || "",
          intervals: scheduleOptions.intervals || {},
          startEstimate: prepared.startEstimate || null,
          taskTimeSignature: previewTaskTimeSignature(previewTasks),
          diagnostics: [...parsed.diagnostics, ...prepared.diagnostics]
        },
        preciseTuo: preciseTuoReport,
        mediaFailures: mediaFailures.map((task) => ({
          sourceId: task.sourceId,
          type: task.type,
          mediaPath: task.mediaPath,
          error: task.mediaDownloadError
        })),
        mediaRecovery: {
          degraded: mediaRecovery.degraded,
          recoveredCount: mediaRecovery.recovered.length,
          recovered: mediaRecovery.recovered
        },
        sourceAudit: apiMode ? {
          complete: mediaRecovery.audit.complete,
          sourceOccurrenceCount: mediaRecovery.audit.sourceOccurrenceCount,
          unresolvedCount: mediaRecovery.audit.unresolvedCount,
          recoveredCount: mediaRecovery.recovered.length
        } : null,
        taskCount: previewTasks.length
      });

      state.update({ totalCount: previewTasks.length, step: "生成预览内容", waitingReason: "初始化人工确认文件" });
      const previewState = await loadPreviewForOpen(runDir, { regenerate: true, defaultDate: baseSendDate });
      await operationCheckpoint(operation, progressGeneration, runGeneration, "保存正式预览后");
      const previewPath = finalPreviewPath(runDir);
      if (!await exists(previewTasksPath(runDir)) || !await exists(previewPath)) {
        throw new Error("新运行目录缺少预览内容，已停止。");
      }
      const mediaRisk = await applyPreviewMediaRiskWarnings(runDir, config);
      const previewReason = mediaRecovery.recovered.length
        ? `本轮预览已生成；系统自动保留了 ${mediaRecovery.recovered.length} 条无法完全确认归属的素材，请处理红色提示后再继续。`
        : mediaRisk.message
          ? "已从导入文档生成预览；有素材超过云中客上传限制或可能触发压缩提示，请先处理黄色提示后再继续。"
          : "已从导入文档生成预览；请重点核对素材下载和低置信度提示";
      const previousPreviewUrl = previewServer?.url || "";
      await previewServer?.close?.().catch(() => {});
      previewServer = await createPreviewServerForRun(runDir, {
        config,
        defaultDate: baseSendDate,
        reason: previewReason,
        onRecoverMedia: mediaRecoveryHandler
      });
      await operationCheckpoint(operation, progressGeneration, runGeneration, "打开预览服务前");
      state.update({
        step: "等待预览确认",
        status: "waiting",
        control: "awaiting_preview_confirmation",
        previewPath,
        previewUrl: previewServer.url,
        waitingReason: previewReason
      });
      if (apiMode) {
        const completedProgress = localFeishuProgress("完成", `预览已生成，共 ${previewTasks.length} 条任务`, progressStartedAt, {
          completed: previewTasks.length, total: previewTasks.length, unit: "条任务", status: "complete", terminal: true
        });
        state.update({ feishuProgress: completedProgress });
      }
      state.log(`导入预览已生成：${previewPath}`);
      state.log(`导入预览条目：${previewState.tasks.length} 条`);
      state.log(`预览页：${previewServer.url}`);
      if (!apiMode) {
        await openControlledPreviewPage(projectRoot, config, withPreviewRunParams(previewServer.url, runDir), browserInstanceOptions, {
          replaceUrl: previousPreviewUrl
        });
      } else {
        await operationCheckpoint(operation, progressGeneration, runGeneration, "自动打开预览前");
        const previewUrlForOpen = withPreviewRunParams(previewServer.url, runDir);
        await attemptApiPreviewOpen({
          projectRoot,
          config,
          runDir,
          runGeneration,
          previewUrl: previewUrlForOpen,
          previewReason,
          state,
          browserInstanceOptions,
          attemptedApiPreviewRuns,
          previewPageOpener,
          previousPreviewUrl
        });
      }
      const currentPreviewState = state.snapshot();
      await operationCheckpoint(operation, progressGeneration, runGeneration, "更新最近预览记录前");
      const recoveryWarning = currentPreviewState.runDir === runDir && !["failed", "stopped"].includes(currentPreviewState.status)
        ? await recordCreatedPreviewSafely(runDir, {
          source: apiMode ? "飞书 API" : "粘贴/文件导入",
          documentName: importInput.fileName || normalized.feishuTitle || (apiMode ? "飞书 API 文档" : "导入文档"),
          taskCount: previewTasks.length
        })
        : "";
      return {
        ok: true,
        runDir,
        previewPath,
        previewUrl: previewServer.url,
        source: previewState.source,
        taskCount: previewTasks.length,
        import: imported.diagnostics,
        recoveryWarning
      };
    } catch (error) {
      if (operation.cancelRequested || isCancellationError(error)) {
        if (!operation.backendCancelPromise) startBackendCancellation(operation);
        if (previewServer && state.snapshot().runDir === runDir) {
          await previewServer.close?.().catch(() => {});
          previewServer = null;
        }
        await fs.rm(finalPreviewPath(runDir), { force: true }).catch(() => {});
        await fs.rm(previewTasksPath(runDir), { force: true }).catch(() => {});
        await saveJson(path.join(runDir, "flow-cancelled.json"), {
          cancelled: true,
          intent: operation.cancellationIntent || "stop",
          requestId: operation.requestId || "",
          stage: state.snapshot().step || "导入文档",
          cancelledAt: new Date().toISOString()
        }).catch(() => {});
        state.updateCancellation(operation.cancellationIntent === "abandon"
          ? "当前客户端工作已退出，正在完成本轮清理。"
          : "当前客户端工作已退出，正在确认停止状态。", {
          cancellationRequestId: operation.requestId || ""
        });
        return { ok: false, cancelled: true, runDir, requestId: operation.requestId || "" };
      }
      if (apiMode && progressGeneration === feishuProgressGeneration) {
        const previous = state.snapshot().feishuProgress || {};
        state.update({ feishuProgress: {
          ...previous,
          stage: previous.stage || "飞书读取失败",
          status: "failed",
          terminal: true,
          reason: error?.message || String(error),
          display: `${previous.display || "飞书读取失败"}；失败：${error?.message || String(error)}`
        } });
      }
      await saveFlowError(runDir, state.snapshot().step || "导入文档", error);
      const files = await keyFiles(runDir);
      state.fail(state.snapshot().step || "导入文档", error?.message || String(error), {
        runDir,
        previewPath: "",
        previewUrl: "",
        missingFiles: missingKeyFiles(files)
      });
      return {
        ok: false,
        runDir,
        error: error?.message || String(error),
        files
      };
    } finally {
      if (input && typeof input === "object" && "appSecret" in input) input.appSecret = "";
    }
  }

  async function applyPreviewMediaRiskWarnings(runDir, config = {}) {
    state.update({ step: "生成预览内容", waitingReason: "正在检查预览素材体积和尺寸，提前发现云中客上传风险。" });
    let mediaPrecheck;
    try {
      mediaPrecheck = await runMediaLocalCheck(runDir, {
        timeoutMs: 30000,
        continueOnError: true,
        profileDir: path.resolve(projectRoot, config.profileDir || "./browser-profile")
      });
    } catch (error) {
      state.log(`预览素材风险检查未完成：${error?.message || String(error)}。预览仍会打开，请重点核对素材。`);
      return { warnings: [], message: "" };
    }

    const warnings = mediaPrecheck.riskWarnings || [];
    const errors = mediaPrecheck.mediaErrors || [];
    if (!warnings.length && !errors.length) return { warnings, errors, message: "" };

    const grouped = groupMediaRiskWarningsByPreviewIndex(warnings);
    const errorGrouped = groupMediaRiskWarningsByPreviewIndex(errors);
    const tasks = await readPreviewTasks(finalPreviewPath(runDir));
    const nextTasks = tasks.map((task, index) => {
      const matched = grouped.get(index + 1) || [];
      const errorMatched = errorGrouped.get(index + 1) || [];
      if (!matched.length && !errorMatched.length) return task;
      const nextTask = { ...task };
      if (errorMatched.length) {
        nextTask.previewError = appendPreviewWarning(task.previewError,
          `素材错误：${errorMatched.map((item) => item.message).join("；")} 请先更换或修正素材类型后再创建。`);
      }
      if (matched.length) {
        const warningText = `素材上传风险：${matched.map((item) => item.message).join("；")} 请先压缩或更换素材后再创建。`;
        nextTask.previewWarning = appendPreviewWarning(task.previewWarning, warningText);
      }
      return nextTask;
    });
    await saveFinalPreview(runDir, nextTasks);
    await saveJson(previewTasksPath(runDir), nextTasks);
    const message = [formatMediaErrorSummary(errors), formatMediaRiskWarningSummary(warnings)].filter(Boolean).join("；");
    state.log(`预览素材检查：${message}`);
    return { warnings, errors, message };
  }

  async function runPrepareCms(settings) {
    const normalized = normalizeConsoleSettings(settings);
    currentSettings = normalized;
    const runDir = await resolveRunDirFromRequest(projectRoot, { runDir: settings.runDir || state.snapshot().runDir, runId: settings.runId }, { runsRoot, previewRecoveryOptions });
    state.update({
      step: "CMS 准备",
      status: "running",
      runDir,
      previewPath: runDir ? finalPreviewPath(runDir) : "",
      waitingReason: "正在打开/切换云中客创建任务页面",
      failureStep: "",
      failureReason: ""
    });

    try {
      if (!runDir) throw new Error("没有当前运行记录，请先生成并保存预览内容。");
      await clearCmsPageBindings(runDir);
      const files = await keyFiles(runDir);
      const missing = missingKeyFiles(files);
      if (missing.length) {
        throw new Error(`新 run 目录缺少关键文件：${missing.join("、")}。禁止打开旧 preview 或继续创建。`);
      }
      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      state.update({ waitingReason: "正在提前检查本地素材体积和图片尺寸，避免创建时才弹压缩上传提示。" });
      const mediaPrecheck = await runMediaLocalCheck(runDir, {
        timeoutMs: 30000,
        profileDir: path.resolve(projectRoot, config.profileDir || "./browser-profile")
      });
      const mediaRiskMessage = mediaPrecheck.riskWarnings?.length
        ? formatMediaRiskWarningSummary(mediaPrecheck.riskWarnings)
        : "";
      if (mediaRiskMessage) state.log(`CMS 准备素材预警：${mediaRiskMessage}`);
      const controlledBrowser = await loadControlledBrowserState(projectRoot, config, browserInstanceOptions);
      const cmsUrl = normalized.cmsUrl || config.cmsUrl || DEFAULT_CMS_URL;
      const cdpUrl = resolveCmsCdpUrl(normalized.cdpUrl, controlledBrowser.cdpUrl, instanceConfig);
      const selectedCmsConfig = normalized.cmsConfigId
        ? await resolveCmsConfigLibraryItem(projectRoot, normalized.cmsConfigId)
        : null;
      const selectedCmsRestore = selectedCmsConfig
        ? await restoreCmsConfigForRun({ runDir, item: selectedCmsConfig })
        : null;
      const selectedCmsSignature = selectedCmsRestore?.configForm
        ? JSON.stringify(selectedCmsRestore.configForm)
        : "";
      const preparedMatchesSelectedConfig = !selectedCmsConfig || (
        preparedCmsPages?.cmsConfigId === selectedCmsConfig.id
        && preparedCmsPages?.cmsConfigSignature === selectedCmsSignature
      );
      if (preparedCmsPages?.pageSession && cdpUrl && preparedMatchesSelectedConfig) {
        if (settings.repairCmsRole === "tuo" || settings.repairCmsRole === "douma") {
          await replaceTrustedCmsSessionRole(preparedCmsPages.pageSession, settings.repairCmsRole, {
            cmsUrl,
            timeoutMs: 30000
          });
          preparedCmsPages.pages = [
            preparedCmsPages.pageSession.roles.tuo?.page,
            preparedCmsPages.pageSession.roles.douma?.page
          ].filter(Boolean);
        }
        const repairedRoles = await repairClosedCmsSessionPages(preparedCmsPages.pageSession, {
          instanceId: instanceConfig.id || "default", requiredRoles: ["tuo", "douma"], cmsUrl, timeoutMs: 30000
        });
        preparedCmsPages.pages = [preparedCmsPages.pageSession.roles.tuo?.page, preparedCmsPages.pageSession.roles.douma?.page].filter(Boolean);
        await validateTrustedCmsPageSession(preparedCmsPages.pageSession, {
          instanceId: instanceConfig.id || "default",
          requiredRoles: ["tuo", "douma"],
          requireCreateForm: true
        });
        preparedCmsPages.runId = runIdFromRunDir(runDir);
        preparedCmsPages.previewBindingSignature = await readPreviewCmsReuseSignature(runDir);
        const pageInfos = await readCmsPageInfos(preparedCmsPages.pages || [], {
          instanceId: instanceConfig.id || "default",
          pageInfoTimeoutMs: 10000,
          onProgress: async (message) => state.log(message)
        });
        preparedCmsPages.bindingState = await createCmsPageBindingsForRun(runDir, pageInfos, ["tuo", "douma"], {
          instanceId: instanceConfig.id || "default",
          source: settings.repairCmsRole ? `repair-${settings.repairCmsRole}-page` : "reuse-instance-page-session"
        });
        const releasedResolvedLease = await releaseResolvedCmsPageLease(runDir, settings.repairCmsRole || "");
        state.update({
          step: "CMS 准备",
          status: "waiting",
          control: "awaiting_cms_setup",
          runDir,
          previewPath: finalPreviewPath(runDir),
          waitingReason: mediaRiskMessage || (repairedRoles.length
            ? "已重新打开关闭的云中客页面，请确认新页面的群和机器人后再开始创建。"
            : settings.repairCmsRole
            ? `${settings.repairCmsRole === "douma" ? "豆妈" : "托"}页面已单独重建，请只检查该页面后再开始创建；另一页面设置已保留。`
            : "云中客页面设置仍有效，已绑定到本轮最终预览，无需重新设置。"),
          failureReason: ""
        });
        state.log(settings.repairCmsRole
          ? `云中客页面会话：只修复 ${settings.repairCmsRole} 页面，正常页面保持原绑定。`
          : `云中客页面会话：复用实例级托页/豆妈页；sessionId=${preparedCmsPages.pageSession.sessionId}。`);
        return {
          ok: true,
          reusedCmsPageSession: !settings.repairCmsRole && !repairedRoles.length,
          repairedRoles,
          repairedRole: settings.repairCmsRole || "",
          releasedResolvedLease,
          runDir,
          previewPath: finalPreviewPath(runDir),
          cmsPageCount: preparedCmsPages.pages.length
        };
      }
      if (selectedCmsConfig) {
        const item = selectedCmsConfig;
        const restored = selectedCmsRestore;
        let autoApplyResult = null;
        let autoApplyFailure = "";
        if (restored.configForm && cdpUrl) {
          try {
            state.update({ waitingReason: "正在按云中客配置自动设置页面..." });
            if (preparedCmsPages?.pageSession && cmsPagesAlive(preparedCmsPages)) {
              await validateTrustedCmsPageSession(preparedCmsPages.pageSession, {
                instanceId: instanceConfig.id || "default",
                requiredRoles: ["tuo", "douma"],
                requireCreateForm: true
              });
            } else {
              preparedCmsPages = await openRealCmsCreatePages({
                projectRoot,
                cmsUrl,
                cdpUrl,
                requireExistingCreatePage: false,
                forceFreshCreatePages: true,
                instanceId: instanceConfig.id || "default",
                requiredRoles: ["tuo", "douma"],
                minCreatePages: 2,
                headless: false,
                timeoutMs: 30000
              });
            }
            preparedCmsPages.runId = runIdFromRunDir(runDir);
            preparedCmsPages.previewBindingSignature = await readPreviewCmsReuseSignature(runDir);
            preparedCmsPages.shouldClose = false;
            autoApplyResult = await applyCmsConfigFormToPages({
              pages: preparedCmsPages.pages || [],
              form: restored.configForm,
              onProgress: async (message) => state.update({ waitingReason: message })
            });
            if (autoApplyResult.ok) {
              preparedCmsPages.cmsConfigId = item.id;
              preparedCmsPages.cmsConfigSignature = selectedCmsSignature;
            }
            const pageInfos = await readCmsPageInfos(preparedCmsPages.pages || [], {
              instanceId: instanceConfig.id || "default",
              pageInfoTimeoutMs: 10000,
              onProgress: async (message) => state.log(message)
            });
            preparedCmsPages.bindingState = await createCmsPageBindingsForRun(runDir, pageInfos, ["tuo", "douma"], {
              instanceId: instanceConfig.id || "default",
              source: autoApplyResult.ok ? "cms-config-auto-apply" : "cms-config-auto-apply-manual-fallback"
            });
            if (!autoApplyResult.ok) {
              autoApplyFailure = `云中客配置自动设置失败：${autoApplyResult.errors.join("；")}。请人工设置后点击“我已设置好，开始创建任务”。`;
            }
          } catch (error) {
            autoApplyFailure = `云中客配置自动设置失败：${error?.message || String(error)}。请人工设置后点击“我已设置好，开始创建任务”。`;
            state.log(`CMS 准备：按配置自动设置失败，已保留人工设置流程。原因：${error?.message || String(error)}`);
            if (settings.openBrowserFallback !== false) await openControlledBrowserPage(projectRoot, config, cmsUrl, browserInstanceOptions).catch(() => {});
          }
        } else if (settings.openBrowserFallback !== false) {
          await openControlledBrowserPage(projectRoot, config, cmsUrl, browserInstanceOptions);
        }
        const successMessage = restored.configForm
          ? "已按配置自动设置云中客页面，请检查后点击“我已设置好，开始创建任务”。"
          : "已恢复云中客配置。请检查群、机器人、任务备注和多快捷模式，确认无误后再点击“我已设置好，开始创建”。";
        const autoApplyFailureHint = "自动设置失败，请人工设置后继续。";
        state.update({
          step: "CMS 准备",
          status: "waiting",
          control: "awaiting_cms_setup",
          runDir,
          previewPath: finalPreviewPath(runDir),
          waitingReason: [mediaRiskMessage, autoApplyFailure ? autoApplyFailureHint : `已恢复云中客配置“${item.name || "未命名配置"}”。${successMessage}`].filter(Boolean).join(" "),
          failureReason: autoApplyFailure
        });
        state.log(autoApplyFailure
          ? `CMS 准备：云中客配置 ${item.name || item.id} 自动设置失败，已停在人工确认阶段。${autoApplyFailure}`
          : `CMS 准备：已恢复云中客配置 ${item.name || item.id}，${restored.configForm ? "已尝试按表单自动设置托/豆妈页面" : `恢复页面角色 ${restored.roleCount} 个`}，等待人工检查确认。`);
        return {
          ok: true,
          runDir,
          previewPath: finalPreviewPath(runDir),
          cmsUrl,
          restoredCmsConfig: true,
          cmsConfigId: item.id,
          cmsConfigName: item.name,
          requiresManualConfirm: true,
          cmsPageCount: preparedCmsPages?.pages?.length || restored.roleCount,
          manualSetupRequired: Boolean(autoApplyFailure),
          autoApplyCmsConfig: autoApplyResult ? { ok: autoApplyResult.ok, errors: autoApplyResult.errors } : null
        };
      }
      if (cdpUrl) {
        preparedCmsPages = await openRealCmsCreatePages({
          projectRoot,
          cmsUrl,
          cdpUrl,
          requireExistingCreatePage: false,
          forceFreshCreatePages: true,
          instanceId: instanceConfig.id || "default",
          requiredRoles: ["tuo", "douma"],
          minCreatePages: 2,
          headless: false,
          timeoutMs: 30000
        });
        preparedCmsPages.runId = runIdFromRunDir(runDir);
        preparedCmsPages.bindingState = await createCmsPageBindingsForRun(runDir, pageInfosFromPreparedPages(preparedCmsPages.pages, instanceConfig.id || "default"), ["tuo", "douma"], {
          instanceId: instanceConfig.id || "default",
          source: "prepare-cms"
        });
        preparedCmsPages.previewBindingSignature = await readPreviewCmsReuseSignature(runDir);
        preparedCmsPages.shouldClose = false;
      } else {
        preparedCmsPages = null;
        if (settings.openBrowserFallback !== false) await openControlledBrowserPage(projectRoot, config, cmsUrl, browserInstanceOptions);
        state.update({
          step: "CMS 准备",
          status: "waiting",
          runDir,
          previewPath: finalPreviewPath(runDir),
          waitingReason: mediaRiskMessage || "已在当前浏览器打开/切到云中客页面。请手动确认分组、机器人和发送策略。"
        });
        state.log("CMS 准备：未检测到可控 CDP 浏览器，已禁止启动新的 browser profile。请在当前浏览器云中客标签页手动确认设置。");
        return {
          ok: true,
          runDir,
          previewPath: finalPreviewPath(runDir),
          cmsUrl,
          openInCurrentBrowser: settings.openBrowserFallback === false,
          cmsPageCount: 0,
          needsControlledBrowser: true
        };
      }
      const pages = preparedCmsPages.pages || [];
      for (const page of pages) {
        await page.bringToFront?.().catch(() => {});
        await page.waitForTimeout?.(250).catch(() => {});
      }
      await pages[0]?.bringToFront?.().catch(() => {});
      state.update({
        step: "CMS 准备",
        status: "waiting",
        control: "awaiting_cms_setup",
        runDir,
        previewPath: finalPreviewPath(runDir),
        waitingReason: mediaRiskMessage || "请在云中客页面手动确认分组、机器人和发送策略。确认完成后，回到控制台点击“我已设置好，开始创建”。"
      });
      state.log(`CMS 准备完成：已重建 ${pages.length} 个云中客创建任务页。当前 runId=${runIdFromRunDir(runDir)}；托页面、豆妈页面已固定标记，请手动确认分组、机器人、发送策略和任务备注。`);
      return {
        ok: true,
        runDir,
        previewPath: finalPreviewPath(runDir),
        cmsUrl,
        cmsPageCount: pages.length
      };
    } catch (error) {
      state.fail("CMS 准备", error?.message || String(error), {
        runDir,
        previewPath: runDir ? finalPreviewPath(runDir) : ""
      });
      return { ok: false, error: error?.message || String(error) };
    }
  }

  async function runCms(settings, lease) {
    const normalized = normalizeConsoleSettings(settings);
    const recoveryDecision = settings?.recoveryDecision && typeof settings.recoveryDecision === "object"
      ? { ...settings.recoveryDecision }
      : null;
    currentSettings = normalized;
    const runDir = await resolveRunDirFromRequest(projectRoot, { runDir: settings.runDir || state.snapshot().runDir, runId: settings.runId }, { runsRoot, previewRecoveryOptions });
    const usageStartedAt = new Date();
    let plannedCount = 0;
    state.resetForRun("正式创建 CMS");
    state.update({
      runDir,
      previewPath: runDir ? finalPreviewPath(runDir) : "",
      failureStep: "",
      failureReason: ""
    });

    try {
      if (!runDir) throw new Error("没有当前运行记录，请先生成并保存预览内容。");
      const files = await keyFiles(runDir);
      const missing = missingKeyFiles(files);
      if (missing.length) {
        throw new Error(`新 run 目录缺少关键文件：${missing.join("、")}。禁止打开旧 preview 或继续创建。`);
      }
      const preview = await readJsonIfExists(finalPreviewPath(runDir));
      if (lease) {
        lease.status = "validating";
        lease.previewSignature = previewCmsReuseSignature(preview || []);
      }
      state.update({ waitingReason: "正在校验 CMS 页面配置、本地素材和创建计划，随后开始逐条创建。" });
      state.log("正式创建准备：正在校验 CMS 页面配置、本地素材和创建计划。");
      if (Array.isArray(preview)) {
        plannedCount = estimatedCmsPlanCount(preview, normalized);
        state.update({ totalCount: plannedCount || preview.filter((task) => !task.skip).length });
      }
      const options = cmsRunOptions(normalized);
      const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
      const controlledBrowser = await loadControlledBrowserState(projectRoot, config, browserInstanceOptions);
      const cdpUrl = resolveCmsCdpUrl(options.cdpUrl, controlledBrowser.cdpUrl, instanceConfig);
      if (!cmsPagesAlive(preparedCmsPages) && !cdpUrl) {
        throw new Error("正式创建需要复用可控制的云中客页面，但当前没有检测到 2.0 受控浏览器/CDP 连接。已停止，且不会启动新的浏览器 profile。");
      }
      if (cmsPagesAlive(preparedCmsPages) && preparedCmsPages.runId && preparedCmsPages.runId !== runIdFromRunDir(runDir)) {
        throw new Error(`正式创建已停止：云中客页面绑定属于旧预览 runId=${preparedCmsPages.runId}，当前预览 runId=${runIdFromRunDir(runDir)}。请重新点击“确认无误进入云中客设置”。`);
      }
      if (cmsPagesAlive(preparedCmsPages) && !canReusePreparedCmsForPreview(preparedCmsPages.previewBindingSignature, preview)) {
        await clearCmsPageBindings(runDir).catch(() => {});
        detachPreparedCmsRun();
        throw new Error("正式创建已停止：预览结构已变化（条数、顺序或托/豆妈归属变了）。请重新点击“确认无误，进入云中客设置”。");
      }
      const reusableCmsPages = cmsPagesAlive(preparedCmsPages) ? {
        ...preparedCmsPages,
        pages: preparedCmsPages.pages.filter((page) => !page.isClosed?.()),
        shouldClose: false
      } : null;
      await reportCmsUsage({
        event: "start",
        status: "running",
        runDir,
        startedAt: usageStartedAt,
        plannedCount
      });
      if (lease) lease.status = "running";
      const report = await executeRealCms({
        ...options,
        ...(recoveryDecision ? { recoveryDecision } : {}),
        ...licenseOptions,
        assumeYes: true,
        cdpUrl,
        bringToFront: false,
        focusDuringRun: false,
        followTaskTab: true,
        allowSystemClipboardFallback: false,
        noLaunchBrowser: true,
        runDir,
        projectRoot,
        runsRoot,
        preparedCmsPages: reusableCmsPages,
        instanceId: instanceConfig.id || "default",
        assertAuthorization: () => assertAuthorization("start-cms"),
        onPageActionState: (event) => updateCmsPageActionState(lease, event),
        control: createWorkflowControl(state)
      });
      const successCount = countSubmitted(report);
      await reportCmsUsage({
        event: "finish",
        status: "completed",
        runDir,
        startedAt: usageStartedAt,
        finishedAt: new Date(),
        plannedCount: Math.max(plannedCount, successCount),
        successCount,
        failureCount: 0
      });
      state.update({
        step: "正式创建 CMS",
        status: "completed",
        control: "completed",
        successCount,
        failureCount: 0,
        waitingReason: "正式创建完成"
      });
      state.log("正式创建完成");
      state.log(report);
      return { ok: true, report };
    } catch (error) {
      const stoppedSnapshot = state.snapshot();
      if (stoppedSnapshot.status === "stopped" || stoppedSnapshot.control === "stopped") {
        state.log(`正式创建已停止：${error?.message || String(error)}`);
        await reportCmsUsage({
          event: "finish",
          status: "stopped",
          runDir,
          startedAt: usageStartedAt,
          finishedAt: new Date(),
          plannedCount,
          successCount: state.snapshot().successCount || 0,
          failureCount: 0,
          stopped: true,
          reason: error?.message || String(error)
        });
        return { ok: false, stopped: true, code: error?.code || "", error: error?.message || String(error) };
      }
      const recoverableCmsLogin = isRecoverableCmsLoginFailure(error)
        && await hasSettledCmsSubmitState(runDir);
      await reportCmsUsage({
        event: "finish",
        status: "failed",
        runDir,
        startedAt: usageStartedAt,
        finishedAt: new Date(),
        plannedCount,
        successCount: state.snapshot().successCount || 0,
        failureCount: 1,
        reason: error?.message || String(error)
      });
      if (recoverableCmsLogin) {
        const role = error?.cmsRole === "douma" ? "豆妈" : error?.cmsRole === "tuo" ? "托" : "云中客";
        const reason = `${role}页面当前未登录。请在原云中客页面完成登录，然后回到控制台点击“我已登录，重新检查”；本轮尚未发现结果未知的提交。`;
        state.update({ runDir, previewPath: runDir ? finalPreviewPath(runDir) : "" });
        state.waitForCmsLogin(reason);
        return {
          ok: false,
          code: error?.code || "CMS_PAGE_SESSION_INVALID",
          cmsRole: error?.cmsRole || "",
          error: reason,
          waitingForLogin: true,
          safeToReleaseLease: true
        };
      }
      state.fail("正式创建 CMS", error?.message || String(error), {
        runDir,
        previewPath: runDir ? finalPreviewPath(runDir) : ""
      });
      return { ok: false, code: error?.code || "", cmsRole: error?.cmsRole || "", error: error?.message || String(error) };
    }
  }

  async function reportCmsUsage(details = {}) {
    if (!details.runDir) return;
    const startedAt = details.startedAt instanceof Date ? details.startedAt : new Date(details.startedAt || Date.now());
    const finishedAt = details.finishedAt instanceof Date ? details.finishedAt : details.finishedAt ? new Date(details.finishedAt) : null;
    const scene = details.event === "finish" ? await buildUsageScene(details, state.snapshot()) : {};
    await submitLicenseUsageReport(projectRoot, {
      ...licenseOptions,
      ...(operatorProvider?.() || {}),
      instanceId: instanceConfig.id || "",
      clientEventId: `${runIdFromRunDir(details.runDir)}:${details.event}:${details.status}`,
      usage: {
        event: details.event,
        source: "cms",
        runId: runIdFromRunDir(details.runDir),
        status: details.status,
        startedAt: startedAt.toISOString(),
        finishedAt: finishedAt ? finishedAt.toISOString() : "",
        durationMs: finishedAt ? Math.max(0, finishedAt.getTime() - startedAt.getTime()) : 0,
        plannedCount: details.plannedCount || 0,
        successCount: details.successCount || 0,
        failureCount: details.failureCount || 0,
        stopped: details.stopped === true,
        ...scene
      }
    }).catch(() => {});
  }

  return {
    generatePreview,
    importDocumentPreview,
    validatePreviewGenerationSettings,
    cancelCurrentRun,
    readFeishuTitle,
    readHeadingStructure,
    readFeishuApiHeadingStructure,
    readFeishuApiMetadata,
    getFeishuConnectionStatus,
    startFeishuOAuth,
    prepareCms,
    startCms,
    previewHasUnsavedChanges,
    abandonCurrentRun,
    exitProgramSession,
    refreshCurrentCmsPageBindings,
    getRestorablePreview,
    restoreLatestPreview,
    restorePreviewRunState,
    isAbandonedPreviewRun,
    returnToPreviewAfterTaskError,
    openExpiredScheduleEditor,
    getPreviewLibrary,
    renameLibraryPreview,
    moveLibraryPreview,
    deleteLibraryPreview,
    prepareSharedLibraryUpload,
    uploadSharedLibraryPreview,
    getSharedPreviewLibrary,
    downloadSharedLibraryPreview,
    deleteSharedLibraryPreview,
    exportSharedLibraryPreview,
    importSharedLibraryPreviewPackage,
    importSharedLibraryPreviewFile,
    openLibraryPreview,
    openCombinedLibraryPreview,
    isRunning() {
      return Boolean(running || pendingCmsAbandon);
    },
    isCmsExecutionLocked() {
      return Boolean(cmsExecutionLease);
    },
    assertCmsExecutionAvailable,
    assertCmsInputsMutable,
    setConsoleUrl(url) {
      consoleUrl = String(url || "");
    },
    get previewServer() {
      return previewServer;
    },
    async close() {
      await previewServer?.close?.().catch(() => {});
      previewServer = null;
      await preparedCmsPages?.context?.close?.().catch(() => {});
      preparedCmsPages = null;
    }
  };

  async function validatePreviewGenerationSettings(settings = {}) {
    const normalized = normalizeConsoleSettings(settings);
    if (normalized.scheduleMode === "realtime") {
      if (normalized.realtimeStartMode === "reverse" && clockInputToSeconds(normalized.realtimeEndTime) === null) {
        const error = new Error("反推开始时间需要先填写有效结束时间，例如 10:30。");
        error.code = "REALTIME_END_TIME_REQUIRED";
        error.statusCode = 400;
        throw error;
      }
      if (normalized.realtimeStartMode === "normal" && normalized.realtimeStartTime && clockInputToSeconds(normalized.realtimeStartTime) === null) {
        const error = new Error("开始时间格式不正确；可以留空，或填写例如 09:34:20。");
        error.code = "REALTIME_START_TIME_INVALID";
        error.statusCode = 400;
        throw error;
      }
    }
    if (normalized.robotStrategy !== "precise") return { ok: true, robotStrategy: normalized.robotStrategy };
    if (!normalized.tuoRosterPath) {
      const error = new Error("请先上传或选择托人设名单");
      error.code = "PRECISE_TUO_ROSTER_REQUIRED";
      error.statusCode = 400;
      throw error;
    }
    let loaded;
    try {
      loaded = await loadTuoRoster(normalized.tuoRosterPath, { projectRoot });
    } catch (cause) {
      const error = new Error(`托人设名单无法读取：${cause?.message || String(cause)}`);
      error.code = "PRECISE_TUO_ROSTER_INVALID";
      error.statusCode = 400;
      error.cause = cause;
      throw error;
    }
    if (!Array.isArray(loaded.roster) || loaded.roster.length === 0) {
      const error = new Error("托人设名单没有可用昵称，请重新上传或选择名单");
      error.code = "PRECISE_TUO_ROSTER_INVALID";
      error.statusCode = 400;
      throw error;
    }
    return {
      ok: true,
      robotStrategy: "precise",
      rosterPath: loaded.filePath,
      rosterCount: loaded.roster.length
    };
  }

  function mediaRecoveryOptions() {
    return {
      autoWindowMs: previewRecoveryOptions.mediaAutoWindowMs,
      roundDelayMs: previewRecoveryOptions.mediaRoundDelayMs,
      downloader: effectiveFeishuMediaDownloader
        ? (request) => effectiveFeishuMediaDownloader(request, {
          signal: request.signal, mediaCacheDir: request.mediaCacheDir,
          assetId: request.assetId, onProgress: request.onProgress
        }) : null
    };
  }

  async function createPreviewServerForRun(runDir, options = {}) {
    const onRecoverMedia = options.onRecoverMedia ||
      await createFeishuMediaRecoveryHandler(runDir, mediaRecoveryOptions());
    return createPreviewTestServer(runDir, {
      consoleUrl,
      defaultDate: options.defaultDate || "",
      restoreDateOnOpen: options.restoreDateOnOpen === true,
      onRecoverMedia,
      onBeforeMutation: async ({ action }) => assertCmsInputsMutable(action),
      onBeginMutation: async ({ action }) => beginCmsInputMutation(action),
      onPreviewPersisted: async ({ tasks }) => {
        try {
          await recordSavedPreview(runsRoot, runDir, {
            ...previewRecoveryInstanceDetails(),
            taskCount: Array.isArray(tasks) ? tasks.length : 0
          });
          return { warning: "" };
        } catch (error) {
          const warning = `预览已保存，但最近恢复记录更新失败：${error?.message || String(error)}。历史列表仍会扫描这份预览。`;
          state.log(warning);
          return { warning };
        }
      },
      onPreviewSaved: async ({ path: previewPath, tasks, autoSave, librarySaveMode, libraryName, libraryTargetId, scheduleContinuation }) => {
        const libraryItem = await resolveRunAsLibraryItem(projectRoot, runDir).catch(() => null)
          || await resolveRunLibrarySource(projectRoot, runDir).catch(() => null);
        const totalCount = Array.isArray(tasks) ? tasks.length : state.snapshot().totalCount;
        const preparedRunMatches = preparedCmsPages?.runId && preparedCmsPages.runId === runIdFromRunDir(runDir);
        const preparedStillOpen = cmsPagesAlive(preparedCmsPages);
        let updatedLibraryItem = null;
        let libraryMessagePrefix = "";
        if (scheduleContinuation === true && !autoSave) {
          state.confirmExpiredScheduleEdit("剩余排程已保存，后台将自动从下一条未执行任务继续创建。");
          state.update({
            step: "正式创建 CMS",
            runDir,
            previewPath,
            totalCount,
            previewUrl: previewServer?.url || state.snapshot().previewUrl
          });
          state.log(`连续过期后的剩余排程已保存：${previewPath}；已成功任务保持不变。`);
          return {
            action: "reuse_cms",
            reusable: true,
            focusedConsole: false,
            message: "剩余排程已保存，后台正在自动从下一条未执行任务继续创建。"
          };
        }
        if (libraryItem) {
          if (librarySaveMode === "overwrite") {
            updatedLibraryItem = await updatePreviewLibraryContent(projectRoot, libraryTargetId || libraryItem.id, tasks, {
              name: libraryName || libraryItem.name,
              sourceRunDir: runDir,
              settingsSnapshot: currentSettings
            });
          } else if (librarySaveMode === "copy") {
            updatedLibraryItem = await savePreviewToLibrary(projectRoot, runDir, tasks, {
              name: libraryName || `${libraryItem.name || "未命名文案"} 副本`,
              forceNew: true,
              settingsSnapshot: currentSettings
            });
          }
          libraryMessagePrefix = updatedLibraryItem ? "文案库预览已保存。" : "本次预览已保存，文案库原文案未覆盖。";
          state.log(updatedLibraryItem
            ? `文案库预览已保存：${updatedLibraryItem.name}；${updatedLibraryItem.previewPath}`
            : `文案库预览仅保存本次运行的预览内容，未覆盖原文案库条目：${previewPath}`);
        }
        if (preparedCmsPages && preparedRunMatches && preparedStillOpen && canReusePreparedCmsForPreview(preparedCmsPages.previewBindingSignature, tasks)) {
          preparedCmsPages.previewBindingSignature = previewCmsReuseSignature(tasks);
          state.update({
            step: "CMS 准备",
            status: "waiting",
            runDir,
            previewPath,
            totalCount,
            waitingReason: libraryItem
              ? `${libraryMessagePrefix} 云中客页面仍可复用，确认云中客设置后可直接点击“我已设置好，开始创建任务”。`
              : "预览已更新，云中客页面仍可复用。确认云中客设置后可直接点击“我已设置好，开始创建任务”。"
          });
          state.log(`预览内容已由预览页保存：${previewPath}；任务结构未变，继续复用已打开的云中客页面。`);
          return {
            action: "reuse_cms",
            reusable: true,
            libraryItem: updatedLibraryItem || libraryItem || null,
            focusedConsole: false,
            message: libraryItem
              ? `${libraryMessagePrefix} 可复用已设置好的云中客页面。请回控制台点击开始创建，不需要重新进入云中客设置。`
              : "已修改预览内容，可复用已设置好的云中客页面。请回控制台点击开始创建，不需要重新进入云中客设置。"
          };
        }
        if (preparedCmsPages && preparedRunMatches) {
          const reason = preparedStillOpen
            ? "预览结构已变化（条数、顺序或托/豆妈归属变了），需要重新确认云中客页面。"
            : "已打开的云中客页面已关闭或丢失，需要重新进入云中客设置。";
          await clearCmsPageBindings(runDir).catch(() => {});
          detachPreparedCmsRun();
          state.update({
            step: "等待预览确认",
            status: "waiting",
            runDir,
            previewPath,
            totalCount,
            waitingReason: libraryItem ? `${libraryMessagePrefix} ${reason}` : reason
          });
          state.log(`预览内容已由预览页保存：${previewPath}；${reason}`);
          return {
            action: "prepare_cms",
            reusable: false,
            libraryItem: updatedLibraryItem || libraryItem || null,
            message: libraryItem ? `${libraryMessagePrefix} ${reason}` : reason
          };
        }
        if (libraryItem) {
          state.update({
            step: "等待预览确认",
            status: "waiting",
            runDir,
            previewPath,
            totalCount,
            waitingReason: updatedLibraryItem
              ? "文案库预览已保存。可继续修改，或确认后进入云中客设置。"
              : "本次预览已保存，文案库原文案未覆盖。可继续确认发单。"
          });
          return {
            action: "prepare_cms",
            reusable: false,
            libraryItem: updatedLibraryItem || libraryItem,
            message: updatedLibraryItem
              ? "文案库预览已保存。确认无误后继续进入云中客设置。"
              : "本次预览已保存，但没有覆盖文案库原文案。确认无误后继续进入云中客设置。"
          };
        }
        state.update({
          step: "等待预览确认",
          status: "waiting",
          runDir,
          previewPath,
          totalCount,
          waitingReason: "预览已保存，等待确认发单"
        });
        state.log(`预览内容已由预览页保存：${previewPath}`);
        return {
          action: "prepare_cms",
          reusable: false,
          message: "预览已保存。如果还没有设置云中客，请先使用预览页右侧蓝色按钮进入设置。"
        };
      },
      onSaveToLibrary: async ({ runDir: sourceRunDir, tasks, name, forceNew, targetId }) => {
        const item = targetId
          ? await updatePreviewLibraryContent(projectRoot, targetId, tasks, { name, sourceRunDir, settingsSnapshot: currentSettings })
          : await savePreviewToLibrary(projectRoot, sourceRunDir, tasks, { name, forceNew, settingsSnapshot: currentSettings });
        state.log(`已存入文案库：${item.name}；${item.previewPath}`);
        return item;
      },
      onListLibrary: async () => listPreviewLibrary(projectRoot),
      onRegeneratePreview: async () => {
        const error = "原“文案有变，重新生成预览”会触发已停用的浏览器滚动采集。请回控制台选择飞书 API 读取，或重新粘贴内容。";
        state.log(`预览页请求被拒绝：${error}`);
        return { ok: false, error, consoleUrl, focusedConsole: false };
      },
      onReturnSettings: async () => {
        state.update({
          step: "等待预览确认",
          status: "waiting",
          waitingReason: "用户返回控制台修改设置，本轮配置已保留"
        });
        state.log("预览页请求：返回修改设置");
        return { consoleUrl, focusedConsole: false };
      },
      onAbandon: async ({ runDir: abandonedRunDir }) => {
        state.update({
          step: "等待预览确认",
          status: "stopped",
          runDir: abandonedRunDir,
          waitingReason: "用户选择暂不发，已保存预览草稿，不执行正式发单"
        });
        state.log("预览页请求：暂不发，回到监控/控制台");
        return { consoleUrl, focusedConsole: false };
      },
      onPrepareCms: async ({ runDir: prepareRunDir }) => {
        const prepareConfig = await readJsonIfExists(path.join(projectRoot, "config.json"));
        const cmsUrl = currentSettings.cmsUrl || prepareConfig.cmsUrl || DEFAULT_CMS_URL;
        state.log("预览页请求：确认无误，进入云中客设置");
        setTimeout(() => {
          prepareCms({ ...currentSettings, runDir: prepareRunDir, openBrowserFallback: false }).catch((error) => {
            state.fail("CMS 准备", error?.message || String(error), {
              runDir: prepareRunDir,
              previewPath: finalPreviewPath(prepareRunDir)
            });
          });
        }, 25);
        return { consoleUrl, cmsUrl };
      }
    });
  }

  function previewRecoveryInstanceDetails() {
    return {
      instanceId: instanceConfig.id || "",
      instanceName: instanceConfig.label || (instanceConfig.id ? `实例${instanceConfig.id}` : "默认实例")
    };
  }

  async function recordCreatedPreviewSafely(runDir, details = {}) {
    const runId = path.basename(runDir);
    try {
      await recordCreatedPreview(runsRoot, runDir, { ...previewRecoveryInstanceDetails(), ...details });
      await submitLicenseOpsEvent(projectRoot, {
        ...licenseOptions,
        ...(operatorProvider?.() || {}),
        instanceId: instanceConfig.id || "",
        event: { eventId: `preview:${runId}`, type: "preview_generated", runId, status: "completed",
          source: String(details.source || "preview"), plannedCount: Number(details.taskCount || 0) }
      }).catch(() => {});
      return "";
    } catch (error) {
      const warning = `预览已生成并保存，但最近恢复记录更新失败：${error?.message || String(error)}。历史列表仍会扫描这份预览。`;
      state.log(warning);
      return warning;
    }
  }
}

function isCancellationError(error) {
  return error?.name === "AbortError" || ["WORKFLOW_CANCELLED", "FEISHU_READ_CANCELLED"].includes(error?.code);
}

function formatFeishuApiProgress(progress, startedAt) {
  if (typeof progress === "string") {
    return localFeishuProgress("飞书 API 读取", progress, startedAt);
  }
  const value = progress && typeof progress === "object" ? progress : {};
  const elapsedMs = Number.isFinite(Number(value.elapsedMs))
    ? Math.max(0, Number(value.elapsedMs))
    : Math.max(0, Date.now() - startedAt);
  const elapsed = `已用 ${formatElapsedDuration(elapsedMs)}`;
  const rawStage = String(value.stage || value.phase || "");
  const common = {
    requestId: String(value.requestId || ""),
    phase: String(value.phase || ""),
    status: String(value.status || "running"),
    terminal: value.terminal === true,
    elapsedMs,
    reason: String(value.reason || ""),
    loggable: value.phase !== "response-transfer"
  };

  if (rawStage === "blocks-page") {
    const page = Number(value.page_index || 0);
    const blocks = Number(value.block_count || 0);
    return { ...common, stage: "分页读取正文", completed: page, total: 0, unit: "页",
      display: `已读取第 ${page || "?"} 页，累计 ${blocks || 0} 个文档块；${elapsed}` };
  }
  if (rawStage === "structure-attempt" || rawStage === "structure-retry") {
    const attempt = Number(value.attempt || 1);
    const maxAttempts = Number(value.max_attempts || value.maxAttempts || 3);
    const retrying = rawStage === "structure-retry";
    return { ...common, stage: retrying ? "文档变化，自动重读" : "固定文档结构",
      completed: attempt, total: maxAttempts, unit: "次",
      display: retrying
        ? `检测到文档在读取期间被修改，正在重新完整读取（第 ${attempt}/${maxAttempts} 次）；请暂停修改文档；${elapsed}`
        : `正在固定文档结构（第 ${attempt}/${maxAttempts} 次）；读取期间请勿修改文档；${elapsed}` };
  }
  if (["blocks-ready", "media-start", "media-progress", "media-error", "media-complete"].includes(rawStage)) {
    if (rawStage === "blocks-ready") {
      return { ...common, stage: "正文读取完成", completed: Number(value.block_count || 0), total: Number(value.block_count || 0), unit: "个文档块",
        display: `正文读取完成，共 ${Number(value.block_count || 0)} 个文档块；${elapsed}` };
    }
    const completed = rawStage === "media-complete"
      ? Number(value.media_total || 0)
      : Number(value.media_index || 0);
    const total = Number(value.media_total || 0);
    const imageCompleted = Number(value.image_completed || 0);
    const imageTotal = Number(value.image_total || 0);
    const videoCompleted = Number(value.video_completed || 0);
    const videoTotal = Number(value.video_total || 0);
    const detail = [`素材 ${completed}/${total || "?"}`];
    if (imageTotal) detail.push(`图片 ${imageCompleted}/${imageTotal}`);
    if (videoTotal) detail.push(`视频 ${videoCompleted}/${videoTotal}`);
    return { ...common, stage: rawStage === "media-complete" ? "素材读取完成" : "读取素材",
      completed, total, unit: "个素材", imageCompleted, imageTotal, videoCompleted, videoTotal,
      display: `${detail.join("；")}；${elapsed}` };
  }
  if (["serialize-start", "serialize-text-ready", "serialize-bytes-ready"].includes(rawStage)) {
    const bytes = Number(value.response_bytes || 0);
    return { ...common, stage: "后台组装响应", totalBytes: bytes,
      display: `素材已读取，后台正在组装响应${bytes ? `，大小 ${formatByteCount(bytes)}` : ""}；${elapsed}` };
  }
  if (["response-write-start", "response-write-progress", "response-write-complete"].includes(rawStage)) {
    return { ...common, stage: "响应传输",
      display: `后台正在发送处理结果；${elapsed}` };
  }
  if (value.phase === "response-transfer") {
    const receivedBytes = Number(value.receivedBytes || 0);
    const totalBytes = Number(value.totalBytes || 0);
    return { ...common, stage: "接收后台响应", receivedBytes, totalBytes,
      display: `正在接收：${formatByteCount(receivedBytes)}${totalBytes ? ` / ${formatByteCount(totalBytes)}` : ""}；${elapsed}` };
  }
  if (value.phase === "failed" || value.status === "failed") {
    return { ...common, stage: "飞书读取失败", terminal: true,
      display: `飞书读取失败；${elapsed}${value.reason ? `；${value.reason}` : ""}` };
  }
  const labels = {
    connecting: "校验并连接",
    "request-start": "校验并连接",
    "client-parse": "客户端解析",
    "read-complete": "生成预览"
  };
  const stage = labels[value.phase] || labels[rawStage] || "飞书 API 读取";
  return { ...common, stage, display: `${String(value.stage || stage)}；${elapsed}` };
}

function localFeishuProgress(stage, message, startedAt, details = {}) {
  const elapsedMs = Math.max(0, Date.now() - startedAt);
  return {
    phase: "local",
    stage,
    status: details.status || "running",
    terminal: details.terminal === true,
    elapsedMs,
    completed: Number(details.completed || 0),
    total: Number(details.total || 0),
    unit: String(details.unit || ""),
    display: `${message}；已用 ${formatElapsedDuration(elapsedMs)}`,
    loggable: true
  };
}

function formatElapsedDuration(elapsedMs) {
  const seconds = Math.max(0, Math.floor(Number(elapsedMs || 0) / 1000));
  if (seconds < 60) return `${seconds} 秒`;
  return `${Math.floor(seconds / 60)} 分 ${seconds % 60} 秒`;
}

function formatByteCount(bytes) {
  const value = Math.max(0, Number(bytes || 0));
  if (value < 1024 * 1024) return `${Math.round(value / 1024)} KB`;
  return `${(value / 1024 / 1024).toFixed(1)} MB`;
}


function buildChecks(settings) {
  const checks = {};
  if (settings.rangeMode === "range" && settings.startKeyword) checks.startKeyword = settings.startKeyword;
  if (settings.rangeMode === "range" && settings.endKeyword) checks.endKeyword = settings.endKeyword;
  return checks;
}

function formatRangeLog(settings) {
  if (settings.rangeMode === "full") {
    return "本次读取范围：全文读取。当前 rangeMode=full；不会使用开始位置/结束位置，也不会使用 heading/rhythm/day/phase。";
  }
  if (settings.rangeMode === "heading") {
    if (settings.headingSelectionMode === "range") {
      return `本次读取范围：按节奏/天数选择-范围。当前 rangeMode=heading/node-range；开始=${settings.headingStartDay || "未选择"} / ${settings.headingStartRhythm || "当天开始"}；结束=${settings.headingEndDay || "未选择"} / ${settings.headingEndRhythm || "当天结束"}；不会使用手动 start/end；识别标题结构只读目录，生成预览才读取正文和素材。`;
    }
    return `本次读取范围：按节奏/天数选择-单天。当前 rangeMode=heading/rhythm；选择的第几天=${settings.headingDay || "未选择"}；选择的节奏标题=${settings.headingRhythm || "整天"}；不会使用手动 start/end；识别标题结构只读目录，生成预览才读取正文和素材。`;
  }
  return `本次读取范围：指定开始/结束位置。当前 rangeMode=manual/start-end；start=${settings.startKeyword || "空"}；end=${settings.endKeyword || "空，读到文档末尾"}；本次禁止使用 heading/rhythm/day/phase 作为范围来源。`;
}

function rangeWaitingReason(mode) {
  if (mode === "full") return "全文读取，不截取范围";
  if (mode === "heading") return "按目录标题结构截取范围";
  return "按开始/结束位置截取范围";
}

function rangeResultForMode(rawEvents, normalized, options, headingRange, baseSendDate) {
  if (normalized.rangeMode === "full") return fullRangeResult(rawEvents);
  if (normalized.rangeMode === "heading") return locateHeadingRange(rawEvents, headingRange);
  return locateRange(rawEvents, {
    start: options.startKeyword,
    end: options.endKeyword,
    endAtDocumentEnd: options.endAtDocumentEnd
  }, {
    baseSendDate
  });
}

async function resolveHeadingRangeFromPage(page, settings, state) {
  state.update({ step: "识别标题结构", waitingReason: "只读取飞书左侧目录，不采集正文和素材" });
  const structure = await collectHeadingStructureFromPage(page);
  const fallbackHeadings = settings.headingSelectionMode === "range"
    ? [
        settings.headingStartRhythm ? `${settings.headingStartDay}${settings.headingStartRhythm}` : settings.headingStartDay,
        settings.headingEndRhythm ? `${settings.headingEndDay}${settings.headingEndRhythm}` : settings.headingEndDay
      ].filter(Boolean)
    : [settings.headingRhythm ? `${settings.headingDay}${settings.headingRhythm}` : settings.headingDay];
  const fallbackStructure = structure.headings.length ? structure : buildHeadingStructure(fallbackHeadings);
  const resolved = settings.headingSelectionMode === "range"
    ? resolveHeadingDayRangeSelection(fallbackStructure, settings)
    : resolveHeadingSelection(fallbackStructure, settings);
  state.log(`识别标题结构：只读目录；识别标题数=${fallbackStructure.headings.length}；可选天数=${fallbackStructure.days.map((item) => item.label).join("、") || "无"}`);
  state.log(settings.headingSelectionMode === "range"
    ? `按节奏/天数范围选择：开始=${resolved.startDay} / ${resolved.startRhythm || "当天开始"}；结束=${resolved.endDay} / ${resolved.endRhythm || "当天结束"}；自动识别的开始位置=${resolved.startTitle}；自动识别的结束位置=${resolved.endTitle || "文档末尾"}；跳过朋友圈=${resolved.skippedHeadings.length ? "是" : "否"}`
    : `按节奏/天数选择：第几天=${resolved.day}；节奏标题=${resolved.rhythm || "整天"}；自动识别的开始位置=${resolved.startTitle}；自动识别的结束位置=${resolved.endTitle || "文档末尾"}；跳过朋友圈=${resolved.skippedHeadings.length ? "是" : "否"}`);
  return resolved;
}

function rangeReportLabel(normalized, headingRange) {
  if (normalized.rangeMode === "full") return "全文读取";
  if (normalized.rangeMode === "heading") return `按节奏/天数选择：${headingRange?.label || normalized.headingDay || normalized.headingStartDay || ""}`;
  return "指定开始/结束位置";
}

function rangeSourceModeLabel(mode) {
  if (mode === "full") return "full";
  if (mode === "heading") return "heading/rhythm";
  return "manual/start-end";
}

function pageInfosFromPreparedPages(pages = [], instanceId = "") {
  return pages.map((page, index) => ({
    index: index + 1,
    page,
    url: page?.url?.() || "",
    cmsRole: page?.__v2CmsRole || "",
    trustedRole: page?.__v2CmsTrustedRole || "",
    trustedSessionId: page?.__v2CmsTrustedSessionId || "",
    trustedPageId: page?.__v2CmsTrustedPageId || "",
    trustedTargetId: page?.__v2CmsTrustedTargetId || "",
    trustedInstanceId: String(instanceId || ""),
    selection: {}
  }));
}

function formatMediaErrorSummary(errors = []) {
  const list = Array.isArray(errors) ? errors : [];
  if (!list.length) return "";
  const head = list.slice(0, 3).map((item) => {
    const speaker = item.speaker ? `${item.speaker} ` : "";
    return `预览第 ${item.previewIndex || "?"} 条 ${speaker}${item.message || "素材不能正式创建"}`;
  });
  const more = list.length > head.length ? `；另有 ${list.length - head.length} 条` : "";
  return `发现 ${list.length} 个素材错误：${head.join("；")}${more}。预览页会标红定位，请先更换素材或修正类型。`;
}

function formatMediaRiskWarningSummary(warnings = []) {
  const list = Array.isArray(warnings) ? warnings : [];
  if (!list.length) return "";
  const head = list.slice(0, 3).map((item) => {
    const speaker = item.speaker ? `${item.speaker} ` : "";
    return `预览第 ${item.previewIndex || "?"} 条 ${speaker}${item.message || "素材可能触发上传风险"}`;
  });
  const more = list.length > head.length ? `；另有 ${list.length - head.length} 条` : "";
  return `发现 ${list.length} 个素材可能触发云中客上传失败或“压缩后上传”弹窗：${head.join("；")}${more}。请在预览页先更换或压缩这些素材后再正式创建。`;
}

function groupMediaRiskWarningsByPreviewIndex(warnings = []) {
  const grouped = new Map();
  for (const warning of warnings) {
    const index = Number(warning?.previewIndex || 0);
    if (!index) continue;
    const list = grouped.get(index) || [];
    list.push(warning);
    grouped.set(index, list);
  }
  return grouped;
}

function appendPreviewWarning(current, addition) {
  const base = String(current || "").trim();
  const next = String(addition || "").trim();
  if (!next) return base;
  if (!base) return next;
  if (base.includes(next)) return base;
  return `${base}\n${next}`;
}

function formatMediaMaterializeProgress(progress = {}) {
  const phase = String(progress.phase || "");
  if (!["start", "done", "failed"].includes(phase)) return "";
  const typeLabel = mediaTypeLabel(progress.type);
  const prefix = phase === "failed"
    ? "素材保存失败"
    : phase === "done"
      ? "素材已保存"
      : "正在保存素材";
  const count = `${progress.current || 0}/${progress.total || 0}`;
  const item = progress.item || {};
  const identity = mediaProgressIdentity(item, progress);
  const slowHint = progress.type === "video" && phase === "start" ? "；正在保存视频，可能较慢" : "";
  const localHint = phase === "done" && progress.localPath ? `；本地路径=${progress.localPath}` : "";
  const errorHint = phase === "failed" && progress.error ? `；原因=${progress.error}` : "";
  return `${prefix} ${count}：${typeLabel}${slowHint}；${identity}；原始地址=${progress.source || mediaProgressSource(item)}${localHint}${errorHint}`;
}

function mediaTypeLabel(type) {
  if (type === "video") return "视频";
  if (type === "sticker") return "表情";
  return "图片";
}

function mediaProgressIdentity(item = {}, progress = {}) {
  const speaker = item.collectSpeaker || item.raw?.collectSpeaker || parseEventSpeakerTime(item).speaker || "未识别";
  const time = item.collectTime || item.raw?.collectTime || parseEventSpeakerTime(item).time || "未知时间";
  const order = Number.isFinite(Number(item.order)) ? Number(item.order) + 1 : Number(progress.index) + 1;
  return `第 ${order || "?"} 条；说话人=${speaker}；时间=${time}`;
}

function mediaProgressSource(item = {}) {
  return item.mediaPath || item.assetUrl || item.src || item.sourceUrl || item.raw?.sourceUrl || "";
}

function fullRangeResult(rawEvents) {
  return {
    events: rawEvents,
    diagnostics: {
      mode: "full",
      includedEventCount: rawEvents.length,
      startMatchedEvent: rawEvents[0] || null,
      startExpandedToEvent: rawEvents[0] || null,
      endMatchedEvent: rawEvents.at(-1) || null
    }
  };
}

function formatManualRangeDiagnosticsLog(settings, diagnostics = {}) {
  return [
    "manual/start-end 定位结果：",
    `rangeMode=manual/start-end`,
    `start=${settings.startKeyword || ""}`,
    `end=${settings.endKeyword || "文档末尾"}`,
    `start匹配方式=${manualMatchMethod(diagnostics.startMatchReason)}`,
    `start上下文=${manualCandidateContext(diagnostics.startSelectedCandidate || diagnostics.startMatchedEvent)}`,
    `end匹配方式=${settings.endKeyword ? manualMatchMethod(diagnostics.endMatchReason) : "document_end"}`,
    `end上下文=${settings.endKeyword ? manualCandidateContext(diagnostics.endSelectedCandidate || diagnostics.endMatchedEvent) : "文档末尾"}`,
    `裁剪后events=${diagnostics.includedEventCount ?? 0}`
  ].join("；");
}

function formatManualRangeFailureLog(settings, error) {
  const diagnostics = error?.diagnostics || {};
  return [
    "manual/start-end 定位失败：",
    `rangeMode=manual/start-end`,
    `start=${settings.startKeyword || ""}`,
    `end=${settings.endKeyword || "文档末尾"}`,
    `start匹配方式=${manualMatchMethod(diagnostics.startMatchReason)}`,
    `start候选=${manualCandidateList(diagnostics.startCandidates)}`,
    `end匹配方式=${settings.endKeyword ? manualMatchMethod(diagnostics.endMatchReason) : "document_end"}`,
    `end候选=${settings.endKeyword ? manualCandidateList(diagnostics.endCandidates) : "文档末尾"}`,
    `错误=${error?.message || error}`
  ].join("；");
}

function manualMatchMethod(reason = "") {
  const value = String(reason || "");
  if (value.includes("structured")) return "speaker/date/time";
  if (value.includes("text")) return "text";
  if (value.includes("empty")) return "empty";
  if (value.includes("no_")) return "not_found";
  return value || "unknown";
}

function manualCandidateContext(candidate) {
  if (!candidate) return "无";
  const event = candidate.event || candidate;
  const text = candidate.contextText || event.text || event.sourceText || "";
  const speaker = candidate.speaker || candidate.cleanSpeaker || "";
  const date = candidate.date || "";
  const time = candidate.time || "";
  return [`#${candidate.index ?? event.order ?? ""}`, speaker, date, time, text]
    .filter(Boolean)
    .join(" ")
    .slice(0, 260);
}

function manualCandidateList(candidates = []) {
  if (!Array.isArray(candidates) || !candidates.length) return "无";
  return candidates.slice(0, 5).map(manualCandidateContext).join(" | ");
}

function validateFullReadCompleteness(rawEvents, diagnostics = {}) {
  if (!diagnostics.documentEndConfirmed) {
    throw new Error(`全文读取未确认到达文档末尾，停止原因：${diagnostics.stoppedBecause || "未知"}，滚动次数：${diagnostics.scrollCount ?? 0}`);
  }
  if (!Array.isArray(rawEvents) || rawEvents.length < 3) {
    throw new Error(`全文读取采集结果过少：${rawEvents?.length || 0} 条 raw-events，已停止。`);
  }
}

function isClosedPageError(error) {
  const message = String(error?.message || error || "");
  return /Target page, context or browser has been closed|Target closed|browser has been closed|page has been closed/i.test(message);
}

function summarizePreviewIdentity(task) {
  if (!task) return null;
  return {
    role: task.role || "",
    speaker: task.cleanSpeaker || task.speaker || "",
    date: task.date || "",
    time: task.time || "",
    type: task.type || ""
  };
}

function formatTaskIdentity(task) {
  const item = summarizePreviewIdentity(task);
  if (!item) return "无";
  return `${item.speaker || "未识别"} ${item.date || ""} ${item.time || ""} ${item.type || ""}`.trim();
}

function formatReverseStartEstimate(estimate) {
  if (!estimate) return "反推开始时间失败：没有生成估算结果。";
  return `反推开始时间：共 ${estimate.taskCount || 0} 条；可行范围 ${estimate.earliestStartTime}-${estimate.latestStartTime}；推荐 ${estimate.predictedStartTime}；预计 ${estimate.endTime} 结束。`;
}

function previewTaskTimeSignature(tasks = []) {
  return JSON.stringify((Array.isArray(tasks) ? tasks : [])
    .filter((task) => !task?.skip)
    .map((task) => [
      String(task.sourceId || task.order || ""),
      String(task.order || ""),
      String(task.role || ""),
      String(task.speaker || ""),
      String(task.type || ""),
      String(task.interactionGroup || ""),
      String(task.date || ""),
      String(task.time || "")
    ]));
}

function formatEventIdentity(event) {
  if (!event) return "无";
  const parsed = parseEventSpeakerTime(event);
  return `${parsed.speaker || event.text || event.sourceText || event.type || "未识别"} ${parsed.date || ""} ${parsed.time || ""}`.trim();
}

function parseEventSpeakerTime(event) {
  const text = String(event?.text || event?.sourceText || "").trim();
  const match = text.match(/^(.{1,40}?)\s+(?:(\d{1,2}[\/月]\d{1,2}(?:日)?)\s+)?(\d{1,2}[:：]\d{1,2}(?::\d{1,2})?)/);
  if (!match) return { speaker: "", date: "", time: "" };
  return {
    speaker: match[1].trim(),
    date: match[2] || "",
    time: match[3].replace(/：/g, ":")
  };
}

function applyDefaultDate(tasks, date) {
  const fallback = String(date || "").trim();
  if (!fallback) return tasks;
  return tasks.map((task) => task.date ? task : { ...task, date: fallback });
}

async function applyPreciseTuoAssignment(tasks, settings, projectRoot, options = {}) {
  if (!settings.tuoRosterPath) throw new Error("精准托模式需要填写托名单文件路径。");
  const { roster, filePath, scopeId, usageHistory } = await loadRegisteredTuoRoster(settings, projectRoot);
  const result = assignPreciseTuoSpeakers(tasks, roster, {
    rotationSeed: options.rotationSeed,
    previousCooldownNicknames: options.previousCooldownNicknames,
    scopeId,
    usageHistory
  });
  return {
    tasks: result.tasks,
    report: {
      ...result.report,
      rosterPath: filePath,
      rosterScopeId: scopeId,
      previousCooldownNicknames: Array.isArray(options.previousCooldownNicknames)
        ? options.previousCooldownNicknames
        : []
    }
  };
}

async function loadRegisteredTuoRoster(settings, projectRoot) {
  if (!settings.tuoRosterPath) throw new Error("精准托模式需要填写托名单文件路径。");
  const loaded = await loadTuoRoster(settings.tuoRosterPath, { projectRoot });
  const registered = await registerTuoRosterIdentity({
    projectRoot,
    rosterPath: loaded.filePath,
    roster: loaded.roster,
    scopeId: settings.tuoRosterScopeId || ""
  });
  const usageHistory = await loadTuoUsageHistory({ projectRoot, scopeId: registered.scopeId });
  return { ...loaded, roster: registered.roster, scopeId: registered.scopeId, usageHistory };
}

function resolveBaseSendDate(value) {
  const text = String(value || "").trim();
  return normalizeSendDate(text) || todayMonthDay();
}

function appendSearchTraceLogs(state, diagnostics = {}) {
  const keywordJumps = Array.isArray(diagnostics.keywordJumps) ? diagnostics.keywordJumps : [];
  for (const jump of keywordJumps) {
    const traces = Array.isArray(jump.searchTrace) ? jump.searchTrace : [];
    const label = jump.label === "start" ? "开始" : (jump.label === "end" ? "结束" : "关键词");
    for (const item of traces) {
      const parts = [
        `飞书搜索定位/${label}/${item.index || "-"}：${item.message || item.stage || ""}`,
        item.url ? `url=${item.url}` : "",
        item.title ? `标题=${item.title}` : "",
        item.point ? `点击=(${Math.round(Number(item.point.x) || 0)},${Math.round(Number(item.point.y) || 0)})` : "",
        item.text ? `文字=${String(item.text).slice(0, 80)}` : "",
        item.candidateCount !== undefined ? `候选=${item.candidateCount}` : "",
        item.inputValue !== undefined ? `输入=${String(item.inputValue).slice(0, 80)}` : "",
        item.visibleTextContainsKeyword !== undefined && item.visibleTextContainsKeyword !== null ? `可见包含关键词=${item.visibleTextContainsKeyword ? "是" : "否"}` : ""
      ].filter(Boolean);
      state.log(parts.join("；"));
    }
    if (jump.failureScreenshot) state.log(`飞书搜索定位/${label}：失败截图=${jump.failureScreenshot}`);
  }
}

async function saveFlowError(runDir, step, error) {
  await fs.mkdir(runDir, { recursive: true }).catch(() => {});
  await saveJson(path.join(runDir, "flow-error.json"), {
    ok: false,
    step,
    code: error?.code || error?.name || "error",
    message: error?.message || String(error),
    failedAt: new Date().toISOString()
  }).catch(() => {});
}

async function keyFiles(runDir) {
  return {
    rawEvents: await exists(path.join(runDir, "raw-events.json")),
    previewTasks: await exists(previewTasksPath(runDir)),
    previewJson: await exists(finalPreviewPath(runDir)),
    flowError: await exists(path.join(runDir, "flow-error.json")),
    collectDiagnostics: await exists(path.join(runDir, "collect-diagnostics.json"))
  };
}

async function resolveRunDirFromRequest(projectRoot, { runDir = "", runId = "" } = {}, options = {}) {
  const directRunDir = String(runDir || "").trim();
  if (directRunDir) return directRunDir;
  return await resolvePreviewHistoryRun(
    options.runsRoot || path.join(projectRoot, "runs"),
    runId,
    options.previewRecoveryOptions || {}
  ) || "";
}

function missingKeyFiles(files) {
  const missing = [];
  if (!files.rawEvents) missing.push("raw-events.json");
  if (!files.previewTasks) missing.push("preview-tasks.json");
  if (!files.previewJson) missing.push("预览内容文件");
  return missing;
}

function countSubmitted(report) {
  return (String(report || "").match(/提交成功/g) || []).length;
}

function estimatedCmsPlanCount(preview, settings = {}) {
  const count = (preview || []).filter((task) => !task.skip).length;
  if (!count) return 0;
  const options = cmsRunOptions(settings);
  if (options.useAllPreviewTasks === true || options.fullBatch === true) return count;
  const batchSize = Number(options.batchSize || 1);
  if (Number.isFinite(batchSize) && batchSize > 1) return Math.min(count, Math.floor(batchSize));
  return 1;
}

async function buildUsageScene(details = {}, snapshot = {}) {
  const preview = await readJsonIfExists(finalPreviewPath(details.runDir));
  const report = await readJsonIfExists(path.join(details.runDir, "console-generate-report.json"));
  const librarySource = await readJsonIfExists(path.join(details.runDir, "library-source.json"));
  const libraryMeta = await readJsonIfExists(path.join(details.runDir, "library-meta.json"));
  const submitState = await readJsonIfExists(path.join(details.runDir, "cms-submit-state.json"));
  const sendable = Array.isArray(preview) ? preview.filter((task) => !task.skip) : [];
  const manual = snapshot.manualAction?.type === "task_error" ? snapshot.manualAction : {};
  const taskIndex = Number(
    manual.taskIndex ||
    snapshot.currentIndex ||
    (snapshot.lastCompletedIndex ? snapshot.lastCompletedIndex + 1 : 0)
  ) || 0;
  const task = taskIndex ? sendable[taskIndex - 1] || {} : {};
  const totalCount = Number(manual.totalCount || snapshot.totalCount || details.plannedCount || sendable.length || 0) || 0;
  const reason = details.status === "completed"
    ? ""
    : String(details.reason || manual.reason || snapshot.failureReason || snapshot.waitingReason || "").trim();
  const records = Object.values(submitState?.tasks && typeof submitState.tasks === "object" ? submitState.tasks : {});
  const recordByIndex = new Map(records.map((item) => [Number(item?.index || 0), item]));
  const taskItems = sendable.slice(0, 500).map((item, offset) => {
    const index = Number(item.index || offset + 1);
    const record = recordByIndex.get(index) || {};
    return {
      index,
      role: String(item.role || "").slice(0, 32),
      actualAccount: String(record.actualRobotNickname || item.speaker || "").slice(0, 100),
      plannedAt: [item.date, item.time].filter(Boolean).join(" ").slice(0, 40),
      contentSummary: String(item.type === "text" ? item.text || "" : "").replace(/\s+/g, " ").trim().slice(0, 180),
      materialType: String(item.type || "").slice(0, 32),
      result: String(record.status || "").slice(0, 24),
      attempt: Number(record.attempt || 0),
      reason: String(record.reason || record.action || "").slice(0, 240),
      taskId: String(item.submitIdentity || record.taskKey || "").slice(0, 128)
    };
  });
  const unknownCount = records.filter((item) => ["submit_pending", "submit_confirmation_pending", "intermediate_confirmation_observed", "request_sent", "unknown"].includes(item?.status)).length;
  const skippedCount = records.filter((item) => item?.status === "skipped").length;
  return {
    stage: String(snapshot.failureStep || snapshot.step || "正式创建 CMS").slice(0, 80),
    reason: reason.slice(0, 240),
    action: usageActionLabel(details.status, details.stopped === true, reason),
    sendTimeRange: buildUsageSendTimeRange(sendable),
    modeSummary: buildUsageModeSummary({ report, librarySource, libraryMeta }),
    taskIndex,
    totalCount,
    taskRole: String(manual.role || task.role || "").slice(0, 24),
    taskType: String(manual.taskType || task.type || "").slice(0, 24),
    taskDate: String(manual.date || task.date || "").slice(0, 24),
    taskTime: String(manual.time || task.time || "").slice(0, 24),
    documentName: String(report?.documentTitle || report?.import?.title || libraryMeta?.name || "").slice(0, 160),
    readRange: String(report?.readRange?.label || report?.readRange?.sourceMode || "").slice(0, 160),
    sendDate: String(report?.readRange?.baseSendDate || task.date || "").slice(0, 32),
    timeMode: String(report?.schedule?.mode || "").slice(0, 80),
    tuoStrategy: String(report?.robotStrategy || "").slice(0, 80),
    targetGroup: "",
    snapshotVersion: `confirmed-preview:${runIdFromRunDir(details.runDir)}`.slice(0, 128),
    unknownCount,
    skippedCount,
    taskItems
  };
}

function usageActionLabel(status, stopped, reason) {
  if (status === "completed") return "本轮创建完成";
  if (stopped) return reason ? "本轮中止" : "用户停止本轮";
  if (status === "failed") return "本轮失败";
  return "";
}

function cmsPagesAlive(opened) {
  const pages = opened?.pages || [];
  return pages.filter((page) => !page.isClosed?.()).length >= 2;
}

async function readPreviewCmsReuseSignature(runDir) {
  const preview = await readJsonIfExists(finalPreviewPath(runDir));
  return previewCmsReuseSignature(preview);
}

export function canReusePreparedCmsForPreview(previousSignature, tasks) {
  const nextSignature = previewCmsReuseSignature(tasks);
  if (!Array.isArray(previousSignature) || !Array.isArray(nextSignature)) return false;
  if (previousSignature.length !== nextSignature.length) return false;
  return previousSignature.every((item, index) => {
    const next = nextSignature[index];
    return item.sourceId === next.sourceId && item.order === next.order && item.role === next.role;
  });
}

export function previewCmsReuseSignature(tasks) {
  if (!Array.isArray(tasks)) return null;
  return tasks.map((task, index) => ({
    sourceId: String(task?.sourceId || ""),
    order: Number(task?.order || index + 1),
    role: normalizePreviewRoleForCmsReuse(task?.role)
  }));
}

export function resolveCmsCdpUrl(settingsCdpUrl, controlledBrowserCdpUrl, instanceConfig = {}) {
  if (instanceConfig?.enabled && Number(instanceConfig.cmsDebugPort) > 0) {
    return `http://127.0.0.1:${Number(instanceConfig.cmsDebugPort)}`;
  }
  return String(settingsCdpUrl || controlledBrowserCdpUrl || "").trim();
}

function normalizePreviewRoleForCmsReuse(role) {
  return String(role || "") === "douma" ? "douma" : "tuo";
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function loadControlledBrowserState(projectRoot, config = {}, browserOptions = {}) {
  return loadV2ControlledBrowserState(projectRoot, config, browserOptions);
}

async function saveJson(filePath, value) {
  await fs.writeFile(filePath, JSON.stringify(value, null, 2), "utf8");
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate())
  ].join("") + "_" + [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join("");
}

async function openControlledBrowserPage(projectRoot, config, url, browserOptions = {}) {
  const controlled = await ensureV2ControlledBrowser({
    projectRoot,
    config,
    url,
    openUrl: true,
    port: browserOptions.port,
    profileDir: browserOptions.profileDir,
    runsDir: browserOptions.runsDir,
    instanceId: browserOptions.instanceId || ""
  });
  await openOrFocusControlledPage(controlled.cdpUrl, url).catch(() => {});
}

async function openControlledPreviewPage(projectRoot, config, url, browserOptions = {}, openOptions = {}) {
  const controlled = openOptions.requireExisting
    ? await loadV2ControlledBrowserState(projectRoot, config, browserOptions)
    : await ensureV2ControlledBrowser({
        projectRoot,
        config,
        openUrl: false,
        port: browserOptions.port,
        profileDir: browserOptions.profileDir,
        runsDir: browserOptions.runsDir,
        instanceId: browserOptions.instanceId || ""
      });
  if (!controlled?.cdpUrl) {
    throw new Error("当前实例的受控浏览器未连接");
  }
  const opening = openOrReplaceControlledPage(controlled.cdpUrl, url, {
    titleIncludes: "妙券自动发单 - 预览确认",
    onlyLocalhost: true,
    closeExtra: true,
    replaceUrl: openOptions.replaceUrl || "",
    bringToFront: openOptions.bringToFront !== false
  });
  return openOptions.suppressErrors === false ? opening : opening.catch(() => {});
}

async function attemptApiPreviewOpen(options = {}) {
  const {
    projectRoot,
    config,
    runDir,
    runGeneration,
    previewUrl,
    previewReason,
    state,
    browserInstanceOptions,
    attemptedApiPreviewRuns,
    previewPageOpener,
    previousPreviewUrl
  } = options;
  const attemptKey = `${runGeneration}:${runDir}`;
  if (!isCurrentPreviewRun(state.snapshot(), runDir, runGeneration)) {
    state.log("飞书 API 预览已生成，但本轮已放弃或被替换，不再自动打开预览页。");
    return { ok: false, skipped: true };
  }
  if (attemptedApiPreviewRuns.has(attemptKey)) return { ok: true, skipped: true };
  attemptedApiPreviewRuns.add(attemptKey);
  while (attemptedApiPreviewRuns.size > 50) {
    attemptedApiPreviewRuns.delete(attemptedApiPreviewRuns.values().next().value);
  }
  try {
    const open = previewPageOpener || ((input) => openControlledPreviewPage(
      input.projectRoot,
      input.config,
      input.url,
      input.browserOptions,
      { requireExisting: true, bringToFront: false, suppressErrors: false, replaceUrl: input.previousPreviewUrl }
    ));
    await open({
      projectRoot,
      config,
      url: previewUrl,
      runDir,
      runGeneration,
      browserOptions: browserInstanceOptions,
      requireExisting: true,
      bringToFront: false,
      previousPreviewUrl
    });
    if (isCurrentPreviewRun(state.snapshot(), runDir, runGeneration)) {
      state.log("飞书 API 预览页已在当前实例浏览器中打开；未主动切换到前台。");
    }
    return { ok: true };
  } catch (error) {
    if (!isCurrentPreviewRun(state.snapshot(), runDir, runGeneration)) {
      return { ok: false, skipped: true, error: error?.message || String(error) };
    }
    const openFailure = `预览已生成，但自动打开失败：${error?.message || String(error)}。请点击“打开预览页”手动查看。`;
    state.update({ waitingReason: [previewReason, openFailure].filter(Boolean).join(" ") });
    state.log(openFailure);
    return { ok: false, error: error?.message || String(error) };
  }
}

function isCurrentPreviewRun(snapshot, runDir, runGeneration) {
  return snapshot?.runDir === runDir
    && Number(snapshot?.runGeneration || 0) === Number(runGeneration || 0)
    && snapshot?.control !== "stopped"
    && snapshot?.status !== "stopped";
}

async function closeControlledPreviewPages(projectRoot, config, browserOptions = {}) {
  const controlled = await loadV2ControlledBrowserState(projectRoot, config, browserOptions);
  if (!controlled.cdpUrl) return { closed: 0 };
  return closeMatchingControlledPages(controlled.cdpUrl, {
    titleIncludes: "妙券自动发单 - 预览确认",
    onlyLocalhost: true
  }).catch(() => ({ closed: 0 }));
}

async function focusConsolePage(projectRoot, consoleUrl, browserOptions = {}) {
  if (!consoleUrl) return false;
  try {
    const config = await readJsonIfExists(path.join(projectRoot, "config.json"));
    const controlled = await loadControlledBrowserState(projectRoot, config, browserOptions);
    if (!controlled.cdpUrl) return false;
    await openOrFocusConsolePage(controlled.cdpUrl, withControlledFlag(consoleUrl), { bringToFront: false });
    return false;
  } catch {
    return false;
  }
}

async function closeOpenedFeishuPage(opened, state) {
  const result = await closeFeishuCollectPage(opened);
  if (!result.ok) {
    state?.log?.(`飞书页面关闭失败：${result.error || "未知原因"}，后续流程继续。`);
  } else if (result.closed && !result.closedBrowserContext) {
    state?.log?.("飞书页面已关闭。");
  }
  return result;
}

function withControlledFlag(url) {
  const parsed = new URL(url);
  parsed.searchParams.set("controlled", "1");
  return parsed.toString();
}

function normalizeRepairProblem(problem = null) {
  if (!problem || typeof problem !== "object") return null;
  const index = Number(problem.index);
  if (!Number.isInteger(index) || index < 0) return null;
  return {
    ...problem,
    index,
    taskIndex: Number(problem.taskIndex || index + 1)
  };
}

function withPreviewRunParams(url, runDir, params = {}) {
  const parsed = new URL(withControlledFlag(url));
  parsed.searchParams.set("runId", path.basename(path.resolve(runDir || "")));
  parsed.searchParams.set("ts", String(Date.now()));
  for (const [key, value] of Object.entries(params || {})) {
    if (value === undefined || value === null || value === "") continue;
    parsed.searchParams.set(key, String(value));
  }
  return parsed.toString();
}

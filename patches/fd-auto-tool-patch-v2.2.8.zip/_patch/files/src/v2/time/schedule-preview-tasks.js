import { createPreviewTask, validatePreviewTaskShape } from "../contracts/preview-task.js";
import { parseMonthDay } from "../date/date-rules.js";
import { clockInputToSeconds } from "./clock-input.js";
import { inheritManualDaySegments } from "../contracts/schedule-segments.js";

export function schedulePreviewTasks(tasks, options = {}) {
  assertTimeModuleAllowed(options);
  const mode = options.mode || "doc";
  const input = inheritManualDaySegments(tasks).map((task) => {
    validatePreviewTaskShape(task);
    return createPreviewTask({ ...task });
  });
  if (mode === "doc") return scheduleDoc(input, options);
  if (mode === "realtime") {
    const startMode = options.startMode || options.realtimeStartMode || "normal";
    if (startMode === "reverse") {
      const estimate = estimateRealtimeStartFromEnd(input, options.endTime, options);
      const scheduled = scheduleRealtime(input, { ...options, startTime: estimate.predictedStartTime });
      return { ...scheduled, startMode, startEstimate: estimate };
    }
    return scheduleRealtime(input, options);
  }
  if (mode === "catchup") return scheduleCatchup(input, options);
  throw new Error(`时间模式无效：${mode}`);
}

export function preparePreviewTasksForGeneration(tasks, options = {}) {
  const scheduled = schedulePreviewTasks(tasks, {
    ...options,
    mode: options.mode || "doc",
    phase: options.phase || "generate-preview"
  });
  const ordered = options.interactionOrderMode === "group"
    ? orderInteractionGroups(scheduled.tasks)
    : scheduled.tasks;
  return {
    ...scheduled,
    tasks: ordered.map((task, index) => createPreviewTask({ ...task, order: index + 1 })),
    interactionReordered: !sameTaskOrder(scheduled.tasks, ordered)
  };
}

export function buildPreviewScheduleOptions(settings = {}, options = {}) {
  const mode = options.scheduleMode || options.mode || settings.scheduleMode || "doc";
  const requestedStartMode = options.realtimeStartMode || options.startMode || settings.realtimeStartMode || settings.startMode || "normal";
  const startMode = requestedStartMode === "reverse" ? "reverse" : "normal";
  const configuredStartTime = options.realtimeStartTime || options.startTime || settings.realtimeStartTime || settings.startTime || "";
  const startTime = startMode === "reverse"
    ? ""
    : (configuredStartTime || defaultRealtimeStartTime({ ...settings, now: options.now || settings.now }));
  return {
    mode,
    startMode,
    interactionOrderMode: options.interactionOrderMode === "group" ? "group" : "source",
    phase: options.phase || "generate-preview",
    startTime,
    currentTime: options.currentTime || settings.currentTime || startTime,
    currentDate: options.currentDate || settings.currentDate || "",
    now: options.now || settings.now,
    endTime: options.realtimeEndTime || options.endTime || settings.realtimeEndTime || "",
    intervals: options.intervals || settings.customIntervals || {},
    randomize: options.randomize === true,
    random: options.random
  };
}

export function assertTimeModuleAllowed(options = {}) {
  const phase = options.phase || "generate-preview";
  const allowedPhases = new Set(["generate-preview", "regenerate-preview", "reverse-estimate"]);
  if (!allowedPhases.has(phase)) {
    throw new Error(`时间模块只能在生成/重新生成预览时运行，当前阶段不允许：${phase}`);
  }
  if (options.previewJsonExists && phase !== "regenerate-preview" && phase !== "reverse-estimate") {
    throw new Error("已保存的预览内容已存在，时间模块不能覆盖用户改过的时间。请先点击“重新生成预览”或“按结束时间反推开始时间”。");
  }
}

export function orderInteractionGroups(tasks) {
  const input = tasks.map((task) => createPreviewTask({ ...task }));
  const pulled = new Set();
  const result = [];
  for (let index = 0; index < input.length; index += 1) {
    if (pulled.has(index)) continue;
    const task = input[index];
    result.push(task);
    pulled.add(index);
    if (!task.interactionGroup) continue;
    for (let nextIndex = index + 1; nextIndex < input.length; nextIndex += 1) {
      if (pulled.has(nextIndex)) continue;
      if (input[nextIndex].interactionGroup === task.interactionGroup && sameScheduleSegment(task, input[nextIndex])) {
        result.push(input[nextIndex]);
        pulled.add(nextIndex);
      }
    }
  }
  return result.map((task, index) => createPreviewTask({ ...task, order: index + 1 }));
}

export function estimateRealtimeStartFromEnd(tasks, endTime, options = {}) {
  assertTimeModuleAllowed({ ...options, phase: "reverse-estimate" });
  const endSeconds = timeToSeconds(endTime);
  if (endSeconds === null) throw new Error("结束时间无效，不能反推开始时间。");
  const input = tasks.filter((task) => !task.skip).map((task) => createPreviewTask({ ...task }));
  const ranges = naturalGapRanges(input, options);
  const minimumGap = ranges.reduce((sum, range) => sum + range.min, 0);
  const totalGap = ranges.reduce((sum, range) => sum + range.value, 0);
  const maximumGap = ranges.reduce((sum, range) => sum + range.max, 0);
  return {
    mode: "reverse-estimate",
    endTime: secondsToClock(endSeconds),
    predictedStartTime: secondsToClock(endSeconds - totalGap),
    earliestStartTime: secondsToClock(endSeconds - maximumGap),
    latestStartTime: secondsToClock(endSeconds - minimumGap),
    minimumDurationSeconds: minimumGap,
    recommendedDurationSeconds: totalGap,
    maximumDurationSeconds: maximumGap,
    taskCount: input.length,
    gapCount: Math.max(0, input.length - 1),
    note: "根据最终可发送任务和间隔上下限反推；推荐值使用每组间隔中间值。"
  };
}

function scheduleDoc(tasks, options = {}) {
  const diagnostics = [];
  for (const task of tasks) {
    if (!task.skip && !task.time) {
      diagnostics.push({
        code: "missing_document_time",
        sourceId: task.sourceId,
        message: `文档时间模式下第 ${task.order} 条缺少时间：${task.speaker || ""}`
      });
    }
  }
  applyDocumentModeContinuousTuoGaps(tasks, options);
  return { tasks, diagnostics, mode: "doc" };
}

function scheduleRealtime(tasks, options = {}) {
  const startSeconds = timeToSeconds(options.startTime);
  if (startSeconds === null) throw new Error("实时跟发模式需要有效开始时间。");
  const endSeconds = timeToSeconds(options.endTime);
  const absoluteEndSeconds = endSeconds === null ? null : endSeconds >= startSeconds ? endSeconds : endSeconds + 86400;
  const sendableIndexes = sendableTaskIndexes(tasks);
  const segments = splitSendableIndexesByScheduleSegment(tasks, sendableIndexes);
  const allGaps = [];
  const diagnostics = [];
  segments.forEach((segmentIndexes, segmentIndex) => {
    const segmentTasks = segmentIndexes.map((index) => tasks[index]);
    const segmentStartSeconds = segmentIndex === 0
      ? startSeconds
      : (timeToSeconds(segmentTasks[0]?.time) ?? startSeconds);
    const gaps = naturalGaps(segmentTasks, options);
    const fitted = fitGapsForEndTime(gaps, segmentTasks, {
      ...options,
      startTime: secondsToClock(segmentStartSeconds),
      endTime: segmentIndex === 0 ? options.endTime : ""
    });
    let cursor = segmentStartSeconds;
    segmentIndexes.forEach((taskIndex, sendIndex) => {
      if (sendIndex > 0) cursor += fitted.gaps[sendIndex - 1];
      const baseDate = String(segmentTasks[0]?.date || "").trim();
      tasks[taskIndex] = createPreviewTask({
        ...tasks[taskIndex],
        date: shiftMonthDay(baseDate, Math.floor(cursor / 86400)) || tasks[taskIndex].date,
        time: secondsToClock(cursor),
        ...endTimeWarningFields(tasks[taskIndex], cursor, absoluteEndSeconds)
      });
    });
    if (segmentIndex > 0) allGaps.push(0);
    allGaps.push(...fitted.gaps);
    if (fitted.diagnostic) diagnostics.push(fitted.diagnostic);
  });
  return {
    tasks,
    diagnostics,
    mode: "realtime",
    gaps: allGaps
  };
}

function scheduleCatchup(tasks, options = {}) {
  const now = resolveScheduleNow(options);
  const currentSeconds = epochSeconds(now);
  const sendableIndexes = sendableTaskIndexes(tasks);
  const segments = splitSendableIndexesByScheduleSegment(tasks, sendableIndexes);
  const diagnostics = [];
  segments.forEach((segmentIndexes, segmentIndex) => {
    let cursor = currentSeconds;
    const usedDocumentTime = new Map();
    segmentIndexes.forEach((taskIndex, sendIndex) => {
      const task = tasks[taskIndex];
      const docSeconds = taskDateTimeToEpochSeconds(task, now);
      const prev = sendIndex > 0 ? tasks[segmentIndexes[sendIndex - 1]] : null;
      const prevIndex = sendIndex > 0 ? segmentIndexes[sendIndex - 1] : -1;
      const followsDocumentFlow = prev && usedDocumentTime.get(prevIndex) && isContinuousTuoText(prev, task);
      const nextGap = followsDocumentFlow
        ? textLengthGap(task, options, { allowCustom: false })
        : (prev ? gapBetween(prev, task, options) : 0);
      const nextAvailable = cursor + nextGap;
      if (docSeconds !== null && docSeconds > currentSeconds && docSeconds >= nextAvailable) {
        if (followsDocumentFlow) {
          cursor += nextGap;
        } else {
          cursor = docSeconds;
        }
        usedDocumentTime.set(taskIndex, true);
      } else {
        cursor = nextAvailable;
        usedDocumentTime.set(taskIndex, Boolean(followsDocumentFlow));
        if (docSeconds === null) diagnostics.push(missingCatchupTime(task));
      }
      tasks[taskIndex] = createPreviewTask({ ...task, ...dateTimeFromEpochSeconds(cursor) });
    });
  });
  return { tasks, diagnostics, mode: "catchup" };
}

function applyDocumentModeContinuousTuoGaps(tasks, options = {}) {
  const sendableIndexes = sendableTaskIndexes(tasks);
  const segments = splitSendableIndexesByScheduleSegment(tasks, sendableIndexes);
  for (const segmentIndexes of segments) {
    let cursor = null;
    for (let position = 0; position < segmentIndexes.length; position += 1) {
      const taskIndex = segmentIndexes[position];
      const task = tasks[taskIndex];
      const originalSeconds = timeToSeconds(task.time);
      const prev = position > 0 ? tasks[segmentIndexes[position - 1]] : null;
      if (originalSeconds !== null && prev && cursor !== null && isContinuousTuoText(prev, task)) {
        cursor += textLengthGap(task, options);
        tasks[taskIndex] = createPreviewTask({ ...task, time: secondsToClock(cursor) });
      } else {
        cursor = originalSeconds;
      }
    }
  }
}

function splitSendableIndexesByScheduleSegment(tasks, indexes) {
  const segments = [];
  let previousKey = "";
  for (const index of indexes) {
    const key = scheduleSegmentKey(tasks[index]);
    if (!segments.length || key !== previousKey) {
      segments.push([]);
    }
    segments.at(-1).push(index);
    previousKey = key;
  }
  return segments;
}

function sameScheduleSegment(left, right) {
  return scheduleSegmentKey(left) === scheduleSegmentKey(right);
}

function scheduleSegmentKey(task) {
  const explicit = String(task?.daySegment || "").trim();
  if (explicit) return `segment:${explicit}`;
  return `date:${String(task?.date || "").trim()}`;
}

function missingCatchupTime(task) {
  return {
    code: "missing_document_time",
    sourceId: task.sourceId,
    message: `补发到文档时间模式下第 ${task.order} 条缺少文档时间：${task.speaker || ""}`
  };
}

function naturalGaps(tasks, options = {}) {
  return naturalGapRanges(tasks, options).map((range) => range.value);
}

function naturalGapRanges(tasks, options = {}) {
  const ranges = [];
  for (let index = 1; index < tasks.length; index += 1) {
    ranges.push(gapRangeBetween(tasks[index - 1], tasks[index], options));
  }
  return ranges;
}

function gapBetween(prev, next, options = {}) {
  return gapRangeBetween(prev, next, options).value;
}

export function gapRangeBetween(prev, next, options = {}) {
  if (!prev || !next) return { key: "none", min: 0, max: 0, value: 0 };
  let key;
  let defaults;
  if (sameInteractionGroup(prev, next)) {
    key = "sameTuo";
    defaults = [20, 45];
  } else if (prev.role !== next.role) {
    key = "roleSwitch";
    defaults = [120, 120];
  } else if (isMedia(prev) || isMedia(next)) {
    const media = customInterval("media", options);
    if (media || !hasAnyCustomIntervals(options)) {
      key = "media";
      defaults = [30, 50];
    }
  }
  if (!key) {
    if (next.role === "douma") {
      key = "doumaSame";
      defaults = [45, 45];
    } else if (prev.speaker === next.speaker) {
      key = "sameTuo";
      defaults = [20, 45];
    } else {
      key = "differentTuo";
      defaults = [15, 15];
    }
  }
  const custom = customInterval(key, options);
  let min = Number.isFinite(Number(custom?.min)) ? Number(custom.min) : defaults[0];
  let max = Number.isFinite(Number(custom?.max)) ? Number(custom.max) : defaults[1];
  if (key === "roleSwitch" && !custom) min = max = Math.max(120, min, max);
  if (min > max) [min, max] = [max, min];
  return { key, min, max, value: pickInterval(key, min, max, options) };
}

function isContinuousTuoText(prev, next) {
  return Boolean(prev && next &&
    prev.role === "tuo" &&
    next.role === "tuo" &&
    prev.speaker === next.speaker &&
    prev.type === "text" &&
    next.type === "text");
}

function textLengthGap(task, options = {}, gapOptions = {}) {
  const length = sendableTextLength(task);
  if (length <= 20) return pickTextLengthInterval("tuoTextShort", 20, 30, options, gapOptions);
  if (length <= 50) return pickTextLengthInterval("tuoTextMedium", 30, 60, options, gapOptions);
  return pickTextLengthInterval("tuoTextLong", 60, 150, options, gapOptions);
}

function pickTextLengthInterval(key, min, max, options = {}, gapOptions = {}) {
  if (gapOptions.allowCustom === false) {
    return pickInterval(key, min, max, { ...options, intervals: {} });
  }
  return pickInterval(key, min, max, options);
}

function sendableTextLength(task) {
  return Array.from(String(task?.text || "").replace(/\s+/g, "")).length;
}

export function fitGapsForEndTime(gaps, tasks, options = {}) {
  const endSeconds = timeToSeconds(options.endTime);
  const startSeconds = timeToSeconds(options.startTime);
  if (endSeconds === null || startSeconds === null || gaps.length === 0) return { gaps };
  const ranges = naturalGapRanges(tasks, options);
  const target = endSeconds >= startSeconds ? endSeconds - startSeconds : endSeconds + 86400 - startSeconds;
  const minimum = ranges.reduce((sum, range) => sum + range.min, 0);
  const maximum = ranges.reduce((sum, range) => sum + range.max, 0);
  if (target < minimum || target > maximum) {
    const useMaximum = target > maximum;
    return {
      gaps: ranges.map((range) => useMaximum ? range.max : range.min),
      diagnostic: {
        code: "schedule_window_out_of_range",
        message: `开始和结束时间要求的总间隔为 ${target} 秒，但当前设置只能容纳 ${minimum}-${maximum} 秒；系统已严格使用${useMaximum ? "最长" : "最短"}间隔，没有突破范围。`
      }
    };
  }
  const naturalTotal = gaps.reduce((sum, gap) => sum + gap, 0);
  if (naturalTotal === target) return { gaps };
  const result = ranges.map((range) => range.min);
  let remaining = target - minimum;
  while (remaining > 0) {
    const adjustable = result.map((value, index) => ({ index, capacity: ranges[index].max - value })).filter((item) => item.capacity > 0);
    if (!adjustable.length) break;
    const each = Math.max(1, Math.floor(remaining / adjustable.length));
    for (const item of adjustable) {
      const add = Math.min(item.capacity, each, remaining);
      result[item.index] += add;
      remaining -= add;
      if (remaining <= 0) break;
    }
  }
  return { gaps: result };
}

function endTimeWarningFields(task, absoluteSeconds, absoluteEndSeconds) {
  const next = { timeOverEnd: false, timeWarning: "" };
  if (absoluteEndSeconds === null || absoluteSeconds <= absoluteEndSeconds) return next;
  const order = task?.order || "";
  return {
    timeOverEnd: true,
    timeWarning: `超过结束时间：第 ${order || "?"} 条 ${secondsToClock(absoluteSeconds)} 晚于 ${secondsToClock(absoluteEndSeconds)}，请在预览页调整间隔后点击“按间隔重排”。`
  };
}

function pickInterval(key, min, max, options = {}) {
  const custom = customInterval(key, options);
  const low = Number.isFinite(Number(custom?.min)) ? Number(custom.min) : min;
  const high = Number.isFinite(Number(custom?.max)) ? Number(custom.max) : max;
  if (options.randomize) {
    const rnd = typeof options.random === "function" ? options.random() : Math.random();
    return Math.round(low + Math.max(0, Math.min(1, rnd)) * (high - low));
  }
  return Math.round((low + high) / 2);
}

function customInterval(key, options = {}) {
  return options.intervals?.[key];
}

function hasAnyCustomIntervals(options = {}) {
  return Boolean(options.intervals && Object.keys(options.intervals).length);
}

function sendableTaskIndexes(tasks) {
  return tasks
    .map((task, index) => ({ task, index }))
    .filter(({ task }) => !task.skip)
    .map(({ index }) => index);
}

function isMedia(task) {
  return task.type === "image" || task.type === "sticker" || task.type === "video";
}

function sameInteractionGroup(prev, next) {
  return Boolean(prev?.interactionGroup && next?.interactionGroup && prev.interactionGroup === next.interactionGroup);
}

function timeToSeconds(time) {
  return clockInputToSeconds(time);
}

function resolveScheduleNow(options = {}) {
  const date = options.now ? new Date(typeof options.now === "function" ? options.now() : options.now) : new Date();
  const currentDate = parseMonthDay(options.currentDate);
  if (currentDate) date.setMonth(currentDate.month - 1, currentDate.day);
  const currentTime = timeToSeconds(options.currentTime || options.startTime);
  if (currentTime === null) throw new Error("补发到文档时间模式需要有效当前时间。");
  date.setHours(Math.floor(currentTime / 3600), Math.floor((currentTime % 3600) / 60), currentTime % 60, 0);
  return date;
}

function taskDateTimeToEpochSeconds(task, baseDate) {
  const seconds = timeToSeconds(task?.time);
  if (seconds === null) return null;
  const parsed = parseMonthDay(task?.date);
  if (!parsed) return null;
  const date = new Date(parsed.year || baseDate.getFullYear(), parsed.month - 1, parsed.day);
  if (!parsed.year) {
    const base = new Date(baseDate);
    base.setHours(0, 0, 0, 0);
    const diff = Math.round((date.setHours(0, 0, 0, 0) - base.getTime()) / 86400000);
    if (diff < -180) date.setFullYear(date.getFullYear() + 1);
    if (diff > 180) date.setFullYear(date.getFullYear() - 1);
  }
  date.setHours(Math.floor(seconds / 3600), Math.floor((seconds % 3600) / 60), seconds % 60, 0);
  return epochSeconds(date);
}

function epochSeconds(date) {
  return Math.round(date.getTime() / 1000);
}

function dateTimeFromEpochSeconds(value) {
  const date = new Date(value * 1000);
  return {
    date: `${date.getMonth() + 1}/${date.getDate()}`,
    time: secondsToClock(date.getHours() * 3600 + date.getMinutes() * 60 + date.getSeconds())
  };
}

function secondsToClock(totalSeconds) {
  const seconds = ((Math.round(Number(totalSeconds) || 0) % 86400) + 86400) % 86400;
  const pad = (value) => String(value).padStart(2, "0");
  return `${pad(Math.floor(seconds / 3600))}:${pad(Math.floor((seconds % 3600) / 60))}:${pad(seconds % 60)}`;
}

function shiftMonthDay(value, dayDelta) {
  const text = String(value || "").trim();
  if (!text || !dayDelta) return text;
  const match = text.match(/^(\d{1,2})\s*[\/月-]\s*(\d{1,2})\s*日?$/);
  if (!match) return text;
  const date = new Date(new Date().getFullYear(), Number(match[1]) - 1, Number(match[2]));
  if (Number.isNaN(date.getTime())) return text;
  date.setDate(date.getDate() + Number(dayDelta || 0));
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function sameTaskOrder(left = [], right = []) {
  if (left.length !== right.length) return false;
  return left.every((task, index) => String(task.sourceId || "") === String(right[index]?.sourceId || "")
    && String(task.order || "") === String(right[index]?.order || ""));
}

function defaultRealtimeStartTime(settings = {}) {
  const leadSeconds = Number(settings.realtimeMinLeadSeconds ?? 60);
  const configuredNow = settings.now instanceof Date ? settings.now : new Date(settings.now || Date.now());
  const now = Number.isNaN(configuredNow.getTime()) ? new Date() : configuredNow;
  const nowSeconds = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  return secondsToClock(nowSeconds + (Number.isFinite(leadSeconds) ? leadSeconds : 60));
}

import http from "node:http";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import path from "node:path";
import { Script } from "node:vm";
import {
  applyPreviewDefaultDate,
  applyRestoredPreviewDate,
  finalPreviewCheck,
  finalPreviewPath,
  loadPreviewForOpen,
  previewDraftPath,
  saveFinalPreview,
  savePreviewDraft
} from "./preview-store.js";
import { buildPreviewRetimeResponse } from "./preview-retime-routes.js";
import { PREVIEW_MEDIA_EXPIRED_FILE } from "./preview-recovery.js";
import { inheritManualDaySegments } from "../contracts/schedule-segments.js";
import { clearResolvedFinderError, isCompleteFinderXml } from "./finder-validation.js";

const PREVIEW_RETIME_SETTINGS_FILE = "preview-retime-settings.json";

export async function createPreviewTestServer(runDir, options = {}) {
  const mutationLifecycle = {
    draining: false,
    restoreDateActive: options.restoreDateOnOpen === true,
    mediaRecovery: {
      requestId: 0,
      status: "idle",
      completed: 0,
      total: 0,
      bytes: 0,
      reason: "",
      updates: []
    }
  };
  const server = http.createServer((req, res) => {
    handleRequest(req, res, runDir, { ...options, mutationLifecycle }).catch((error) => sendJson(res, Number(error?.statusCode || (error?.code === "CMS_EXECUTION_LOCKED" ? 409 : 500)), {
      ok: false,
      code: error?.code || "",
      error: error?.message || String(error)
    }));
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port || 0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });
  const address = server.address();
  const url = `http://127.0.0.1:${address.port}/`;
  return {
    server,
    url,
    beginDrain() {
      mutationLifecycle.draining = true;
      mutationLifecycle.mediaRecovery.controller?.abort();
    },
    resumeMutations() {
      mutationLifecycle.draining = false;
    },
    close: () => {
      mutationLifecycle.mediaRecovery.controller?.abort();
      return new Promise((resolve) => server.close(resolve));
    }
  };
}

async function handleRequest(req, res, runDir, options = {}) {
  const url = new URL(req.url || "/", "http://127.0.0.1");
  if (req.method === "GET" && url.pathname === "/") {
    if (await pathExists(path.join(runDir, PREVIEW_MEDIA_EXPIRED_FILE))) {
      sendHtml(res, renderExpiredPreviewPage());
      return;
    }
    const meta = await loadPreviewPageMeta(runDir);
    const defaultDate = options.defaultDate || meta.defaultDate || "";
    const regenerate = url.searchParams.get("regenerate") === "1";
    const opensWithWrite = regenerate || !await pathExists(finalPreviewPath(runDir));
    const load = async () => {
      const loaded = await loadPreviewForOpen(runDir, { regenerate, defaultDate });
      if (!options.mutationLifecycle?.restoreDateActive || !defaultDate) return loaded;
      const succeededTaskKeys = await readSucceededSubmitTaskKeys(runDir);
      if (succeededTaskKeys === null) return loaded;
      return {
        ...loaded,
        tasks: applyRestoredPreviewDate(
          loaded.tasks,
          defaultDate,
          succeededTaskKeys
        )
      };
    };
    const state = opensWithWrite
      ? await withMutationAllowed(options, regenerate ? "通过链接重新生成预览" : "初始化预览", url.pathname, load)
      : await load();
    const succeededTaskKeys = await readSucceededSubmitTaskKeys(runDir);
    const html = renderPreviewPage(state, runDir, {
      ...meta,
      consoleUrl: options.consoleUrl || "",
      defaultDate,
      repairProblem: resolvePreviewRepairProblem(previewRepairProblemFromUrl(url), state.tasks),
      resumeAfterEdit: url.searchParams.get("resumeAfterEdit") === "1",
      scheduleContinuation: url.searchParams.get("scheduleContinuation") === "1",
      resumeFromIndex: Number(url.searchParams.get("resumeFromIndex") || 0),
      succeededTaskKeys: succeededTaskKeys ? Array.from(succeededTaskKeys) : []
    });
    assertPreviewPageScriptsCompile(html);
    sendHtml(res, html);
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/preview") {
    const load = () => loadPreviewForOpen(runDir);
    const state = await pathExists(finalPreviewPath(runDir))
      ? await load()
      : await withMutationAllowed(options, "初始化预览", url.pathname, load);
    sendJson(res, 200, { ok: true, ...state });
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/media-preview") {
    await sendMediaPreview(req, res, url.searchParams.get("path") || "");
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/media-status") {
    sendJson(res, 200, await mediaStatus(url.searchParams.get("path") || ""));
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/media-recovery") {
    sendJson(res, 200, { ok: true, ...mediaRecoveryPublicState(options.mutationLifecycle?.mediaRecovery) });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/media-recovery") {
    const body = await readJsonBody(req);
    const recovery = options.mutationLifecycle?.mediaRecovery;
    if (!recovery || typeof options.onRecoverMedia !== "function") {
      sendJson(res, 200, { ok: false, unavailable: true, error: "当前预览没有可自动恢复的飞书素材。" });
      return;
    }
    if (options.mutationLifecycle.draining) {
      sendJson(res, 409, { ok: false, error: "当前预览正在关闭，已取得素材会保留。" });
      return;
    }
    if (recovery.status !== "running" && (["idle", "failed"].includes(recovery.status) || body.restart === true)) {
      startMediaRecovery(recovery, options.onRecoverMedia, body);
    }
    sendJson(res, 202, { ok: true, ...mediaRecoveryPublicState(recovery) });
    return;
  }
  if (req.method === "GET" && url.pathname === "/api/library/list") {
    const items = typeof options.onListLibrary === "function"
      ? await options.onListLibrary()
      : (Array.isArray(options.libraryItems) ? options.libraryItems : []);
    sendJson(res, 200, { ok: true, items });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/upload-media") {
    const uploaded = await withMutationAllowed(options, "替换或上传素材", url.pathname, () => saveUploadedMedia(req, runDir));
    sendJson(res, 200, { ok: true, ...uploaded });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/preview") {
    const { body, saved, saveAdvice, recoveryWarning } = await withMutationAllowed(options, "保存预览修改", url.pathname, async () => {
      const body = await readJsonBody(req);
      if (body.scheduleContinuation === true) {
        await assertScheduleContinuationChange(runDir, body.tasks || [], Number(body.resumeFromIndex || 0));
      }
      const saved = await saveFinalPreview(runDir, body.tasks, { requireComplete: true });
      const recoveryResult = await options.onPreviewPersisted?.({
        runDir,
        path: saved.path,
        tasks: saved.tasks,
        autoSave: body.autoSave === true
      }).catch((error) => ({ warning: error?.message || String(error) }));
      const saveAdvice = await options.onPreviewSaved?.({
        runDir,
        path: saved.path,
        tasks: saved.tasks,
        autoSave: body.autoSave === true,
        librarySaveMode: body.librarySaveMode,
        libraryName: body.libraryName,
        libraryTargetId: body.libraryTargetId,
        scheduleContinuation: body.scheduleContinuation === true
      });
      return { body, saved, saveAdvice, recoveryWarning: recoveryResult?.warning || "" };
    });
    options.mutationLifecycle.restoreDateActive = false;
    sendJson(res, 200, {
      ok: true,
      source: "preview.json",
      path: saved.path,
      tasks: saved.tasks,
      savedAt: new Date().toISOString(),
      consoleUrl: options.consoleUrl || "",
      saveAdvice: saveAdvice || null,
      recoveryWarning
    });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/preview-draft") {
    const saved = await withMutationAllowed(options, "保存修复中的预览草稿", url.pathname, async () => {
      const body = await readJsonBody(req);
      return savePreviewDraft(runDir, body.tasks || []);
    });
    sendJson(res, 200, {
      ok: true,
      source: "preview-draft.json",
      path: saved.path,
      tasks: saved.tasks,
      savedAt: new Date().toISOString()
    });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/library/save") {
    const result = await withMutationAllowed(options, "保存文案库预览", url.pathname, async () => {
      const body = await readJsonBody(req);
      const saved = await saveFinalPreview(runDir, body.tasks, { requireComplete: true });
      if (!options.onSaveToLibrary) return { unavailable: true };
      const item = await options.onSaveToLibrary({
        runDir,
        path: saved.path,
        tasks: saved.tasks,
        name: body.name,
        forceNew: body.forceNew === true,
        targetId: body.targetId || body.libraryTargetId || ""
      });
      return { saved, item };
    });
    if (result.unavailable) {
      sendJson(res, 400, { ok: false, error: "当前入口没有启用文案库保存。" });
      return;
    }
    sendJson(res, 200, {
      ok: true,
      source: "preview-library",
      item: result.item,
      tasks: result.saved.tasks,
      savedAt: new Date().toISOString()
    });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/regenerate") {
    const result = await withMutationAllowed(options, "重新生成预览", url.pathname, async () => {
      if (options.onRegeneratePreview) return { delegated: true, ...(await options.onRegeneratePreview({ runDir })) };
      const meta = await loadPreviewPageMeta(runDir);
      const state = await loadPreviewForOpen(runDir, {
        regenerate: true,
        defaultDate: options.defaultDate || meta.defaultDate || ""
      });
      return { delegated: false, ...state };
    });
    if (result.delegated) {
      sendJson(res, 202, { ok: true, ...result });
      return;
    }
    sendJson(res, 200, { ok: true, ...result });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/retime-preview") {
    const result = await withMutationAllowed(options, "重排预览时间", url.pathname, async () => {
      const body = await readJsonBody(req);
      const response = buildPreviewRetimeResponse(body);
      if (body.persistSettings === true) {
        await writeJsonAtomic(path.join(runDir, PREVIEW_RETIME_SETTINGS_FILE), {
          version: 1,
          mode: "realtime",
          startMode: body.startMode === "reverse" ? "reverse" : "normal",
          startTime: String(body.startTime || response.startEstimate?.predictedStartTime || ""),
          endTime: String(body.endTime || ""),
          intervals: body.intervals && typeof body.intervals === "object" ? body.intervals : {},
          startEstimate: response.startEstimate || null,
          savedAt: new Date().toISOString()
        });
      }
      return response;
    });
    sendJson(res, 200, result);
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/final-check") {
    const body = await readJsonBody(req);
    sendJson(res, 200, await finalPreviewCheck(runDir, body.tasks));
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/prepare-cms") {
    const body = await readJsonBody(req);
    const check = await finalPreviewCheck(runDir, body.tasks);
    if (!check.ok) {
      sendJson(res, 400, check);
      return;
    }
    if (options.onPrepareCms) {
      const result = await options.onPrepareCms({ runDir, tasks: body.tasks, check });
      sendJson(res, 202, { ok: true, preparedCms: true, ...result });
      return;
    }
    sendJson(res, 200, check);
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/return-settings") {
    const result = await options.onReturnSettings?.({ runDir });
    sendJson(res, 200, { ok: true, consoleUrl: options.consoleUrl || "", ...(result || {}) });
    return;
  }
  if (req.method === "POST" && url.pathname === "/api/abandon") {
    const { body, result } = await withMutationAllowed(options, "放弃或替换当前预览", url.pathname, async () => {
      const body = await readJsonBody(req);
      await savePreviewDraft(runDir, body.tasks || []);
      const result = await options.onAbandon?.({ runDir, tasks: body.tasks || [] });
      return { body, result };
    });
    sendJson(res, 200, { ok: true, consoleUrl: options.consoleUrl || "", draftPath: previewDraftPath(runDir), ...(result || {}) });
    return;
  }
  sendJson(res, 404, { ok: false, error: "Not found" });
}

function renderExpiredPreviewPage() {
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>预览素材已过期</title><style>body{margin:0;background:#f4f7fb;color:#172033;font-family:"Microsoft YaHei",sans-serif}.wrap{max-width:720px;margin:12vh auto;padding:32px}.panel{background:#fff;border:1px solid #d7e0ee;border-radius:8px;padding:28px;box-shadow:0 12px 32px rgba(15,23,42,.08)}h1{margin:0 0 14px;font-size:24px}p{margin:8px 0;line-height:1.7;color:#475569}.warn{color:#b45309;font-weight:700}</style></head><body><main class="wrap"><section class="panel"><h1>这份临时预览的素材已过期</h1><p class="warn">系统已经停止把它作为可恢复预览，因此不会再逐条显示“素材缺失”。</p><p>请从控制台重新读取飞书生成预览；需要长期保留的内容请存入文案库，文案库素材不会按临时预览规则清理。</p></section></main></body></html>`;
}

function startMediaRecovery(state, handler, body = {}) {
  state.controller?.abort();
  const controller = new AbortController();
  const requestId = Number(state.requestId || 0) + 1;
  const sourceIds = [...new Set((Array.isArray(body.sourceIds) ? body.sourceIds : [])
    .map((item) => String(item || "").trim()).filter(Boolean))];
  Object.assign(state, {
    requestId,
    controller,
    status: "running",
    completed: 0,
    total: sourceIds.length,
    bytes: 0,
    reason: "正在自动补齐素材",
    updates: [],
    error: ""
  });
  Promise.resolve().then(() => handler({
    sourceIds,
    signal: controller.signal,
    onProgress(progress = {}) {
      if (state.requestId !== requestId || state.status !== "running") return;
      if (Number.isFinite(Number(progress.completed))) state.completed = Number(progress.completed);
      if (Number.isFinite(Number(progress.total))) state.total = Number(progress.total);
      if (Number.isFinite(Number(progress.bytes))) state.bytes = Number(progress.bytes);
      if (Array.isArray(progress.updates)) {
        const merged = new Map(state.updates.map((item) => [item.sourceId, item]));
        for (const item of progress.updates) merged.set(item.sourceId, item);
        state.updates = [...merged.values()];
      }
      if (String(progress.reason || "").trim()) state.reason = String(progress.reason).trim();
      if (progress.phase === "retry-wait" && Number(progress.retryAfterMs || 0) > 0) {
        state.reason = `素材服务暂时繁忙，约 ${Math.max(1, Math.ceil(Number(progress.retryAfterMs) / 1000))} 秒后继续自动补齐`;
      }
    }
  })).then((result = {}) => {
    if (state.requestId !== requestId) return;
    state.status = Number(result.pendingCount || 0) > 0 ? "waiting" : "complete";
    state.completed = Number(result.completed ?? state.total);
    state.total = Number(result.total ?? state.total);
    state.updates = Array.isArray(result.updates) ? result.updates : [];
    state.reason = String(result.message || "素材自动恢复已完成");
  }).catch((error) => {
    if (state.requestId !== requestId) return;
    state.status = "failed";
    state.error = error?.message || String(error);
    state.reason = "素材自动恢复暂未完成";
  });
}

function mediaRecoveryPublicState(state = {}) {
  return {
    requestId: Number(state.requestId || 0),
    status: String(state.status || "idle"),
    completed: Math.max(0, Number(state.completed || 0)),
    total: Math.max(0, Number(state.total || 0)),
    bytes: Math.max(0, Number(state.bytes || 0)),
    reason: String(state.reason || ""),
    error: String(state.error || ""),
    updates: Array.isArray(state.updates) ? state.updates : []
  };
}

export function assertPreviewPageScriptsCompile(html) {
  const scripts = [...String(html || "").matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
  for (const [index, match] of scripts.entries()) {
    try {
      new Script(match[1], { filename: `preview-page-inline-${index + 1}.js` });
    } catch (error) {
      const wrapped = new Error(`预览页脚本生成失败，已停止打开空白预览：${error?.message || error}`);
      wrapped.code = "PREVIEW_PAGE_SCRIPT_INVALID";
      wrapped.cause = error;
      throw wrapped;
    }
  }
  return { ok: true, count: scripts.length };
}

async function withMutationAllowed(options, action, pathname, callback) {
  if (options.mutationLifecycle?.draining) {
    const error = new Error("这个预览页正在切换或关闭，旧页面的保存请求已停止。请在新恢复的预览页继续操作。");
    error.code = "PREVIEW_SERVER_DRAINING";
    error.statusCode = 409;
    throw error;
  }
  await options.onMutationRequestAccepted?.({ action, pathname });
  let mutation;
  if (typeof options.onBeginMutation === "function") {
    mutation = await options.onBeginMutation({ action, pathname });
  } else if (typeof options.onBeforeMutation === "function") {
    await options.onBeforeMutation({ action, pathname });
  }
  try {
    return await callback();
  } finally {
    mutation?.release?.();
  }
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function previewRepairProblemFromUrl(url) {
  const mode = url.searchParams.get("repairMode");
  if (!new Set(["shared-upload", "task-error"]).has(mode)) return null;
  const index = Number(url.searchParams.get("problemIndex"));
  const taskId = String(url.searchParams.get("problemTaskId") || "");
  if ((!Number.isInteger(index) || index < 0) && !taskId) return null;
  return {
    index: Number.isInteger(index) && index >= 0 ? index : -1,
    taskId,
    mode,
    message: url.searchParams.get("problemReason") || (mode === "task-error"
      ? `第 ${index + 1} 条创建失败，请检查并修改后继续`
      : `第 ${index + 1} 条素材需要重新上传`)
  };
}

function resolvePreviewRepairProblem(problem, tasks = []) {
  if (!problem) return null;
  const matchedIndex = problem.taskId
    ? tasks.findIndex((task) => String(task?.submitIdentity || "") === problem.taskId)
    : -1;
  if (problem.taskId && matchedIndex < 0) return null;
  return {
    ...problem,
    index: matchedIndex >= 0 ? matchedIndex : problem.index
  };
}

async function readSucceededSubmitTaskKeys(runDir) {
  try {
    const state = JSON.parse(await fs.readFile(path.join(runDir, "cms-submit-state.json"), "utf8"));
    if (!state || state.version !== 1 || !state.tasks || typeof state.tasks !== "object" || Array.isArray(state.tasks)) return null;
    if (Object.entries(state.tasks).some(([taskKey, record]) => record?.status === "succeeded" && !/^(?:task:|v2:)/.test(taskKey))) return null;
    return new Set(Object.entries(state?.tasks || {})
      .filter(([, record]) => record?.status === "succeeded")
      .map(([taskKey]) => taskKey));
  } catch (error) {
    if (error?.code !== "ENOENT") return null;
    return new Set();
  }
}

async function assertScheduleContinuationChange(runDir, nextTasks, resumeFromIndex) {
  const current = JSON.parse(await fs.readFile(finalPreviewPath(runDir), "utf8"));
  if (!Array.isArray(current) || !Array.isArray(nextTasks) || current.length !== nextTasks.length) {
    throw new Error("续排只能修改当前预览中的剩余时间，不能增删任务。");
  }
  const succeeded = await readSucceededSubmitTaskKeys(runDir);
  if (succeeded === null) throw new Error("成功记录无法可靠读取，不能开放续排修改。");
  const allowed = new Set(["date", "time", "timeOverEnd", "timeWarning"]);
  const stable = (task) => {
    const normalized = Object.fromEntries(Object.entries(task || {}).filter(([key]) => !allowed.has(key)));
    if (!String(normalized.repairsSourceIds || "").trim()) delete normalized.repairsSourceIds;
    if (normalized.importResolutionConfirmed !== true) delete normalized.importResolutionConfirmed;
    return normalized;
  };
  for (let index = 0; index < current.length; index += 1) {
    const before = current[index] || {};
    const after = nextTasks[index] || {};
    const identity = String(before.submitIdentity || "");
    if (!identity || identity !== String(after.submitIdentity || "")) {
      throw new Error(`续排第 ${index + 1} 行任务身份发生变化，已停止保存。`);
    }
    const locked = succeeded.has(identity) || Number(before.index || before.order || index + 1) < resumeFromIndex;
    if (JSON.stringify(stable(before)) !== JSON.stringify(stable(after))) {
      throw new Error(`续排只能修改日期和时间；第 ${index + 1} 行内容、角色、素材或顺序发生变化。`);
    }
    if (locked && (before.date !== after.date || before.time !== after.time)) {
      throw new Error(`第 ${index + 1} 条已经成功或位于续排起点之前，不能修改时间。`);
    }
  }
}

function renderPreviewPage(state, runDir, meta = {}) {
  const pageTasks = normalizePreviewTasksForRobotStrategy(
    applyPreviewDefaultDate(state.tasks, meta.defaultDate),
    meta.robotStrategy
  );
  const tasksJson = JSON.stringify(pageTasks).replace(/</g, "\\u003c");
  const source = escapeHtml(state.source);
  const previewPathText = escapeHtml(finalPreviewPath(runDir));
  const runDirText = escapeHtml(runDir);
  const runId = path.basename(path.resolve(runDir));
  const rangeLabel = escapeHtml(meta.rangeLabel || "未记录");
  const rawEventCount = escapeHtml(meta.rawEventCount ?? "-");
  const previewTaskCount = escapeHtml(meta.previewTaskCount ?? state.tasks.length);
  const consoleUrl = JSON.stringify(meta.consoleUrl || "").replace(/</g, "\\u003c");
  const defaultDate = JSON.stringify(meta.defaultDate || "").replace(/</g, "\\u003c");
  const runDirJson = JSON.stringify(runDir).replace(/</g, "\\u003c");
  const runIdJson = JSON.stringify(runId).replace(/</g, "\\u003c");
  const libraryItemJson = JSON.stringify(meta.libraryItem || null).replace(/</g, "\\u003c");
  const combinedLibrarySummary = meta.libraryItem?.combined
    ? `<span class="summary-pill recommended-schedule-pill">拼接预览：共 ${escapeHtml(meta.libraryItem.segments?.length || 0)} 段 / ${previewTaskCount} 条</span>`
    : "";
  const robotStrategyJson = JSON.stringify(meta.robotStrategy || "").replace(/</g, "\\u003c");
  const initialScheduleJson = JSON.stringify(meta.schedule || {}).replace(/</g, "\\u003c");
  const modeTitle = escapeHtml(meta.modeSummary?.title || "本轮模式：模式待确认");
  const modeDetails = escapeHtml(meta.modeSummary?.details || "这份旧预览没有保存模式记录，请在创建前人工确认。");
  const preciseTuoRosterJson = JSON.stringify(meta.preciseTuoRosterOptions || []).replace(/</g, "\\u003c");
  const resumeAfterEditJson = JSON.stringify(meta.resumeAfterEdit === true);
  const scheduleContinuationJson = JSON.stringify(meta.scheduleContinuation === true);
  const resumeFromIndexJson = JSON.stringify(Number(meta.resumeFromIndex || 0));
  const succeededTaskKeysJson = JSON.stringify(meta.succeededTaskKeys || []).replace(/</g, "\\u003c");
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>妙券自动发单 - 预览确认</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Arial, "Microsoft YaHei", sans-serif; background: #f3f6fa; color: #111827; }
    header { position: sticky; top: 0; z-index: 5; background: rgba(255,255,255,0.98); border-bottom: 1px solid #d8dde6; box-shadow: 0 1px 4px rgba(15, 23, 42, 0.04); }
    main { padding: 16px 18px 40px; }
    .topbar { min-height: 70px; padding: 14px 18px 12px; display: flex; align-items: flex-start; justify-content: space-between; gap: 18px; flex-wrap: wrap; }
    .title { font-size: 20px; line-height: 1.2; font-weight: 700; }
    .run-mode { margin-top: 8px; max-width: 820px; border-left: 4px solid #2563eb; padding: 8px 10px; background: #eff6ff; }
    .run-mode-title { color: #0f172a; font-size: 18px; line-height: 1.3; font-weight: 800; }
    .run-mode-details { margin-top: 3px; color: #334155; font-size: 13px; line-height: 1.45; }
    .run-mode.pending { border-left-color: #d97706; background: #fffbeb; }
    .library-date-notice { display: none; max-width: 760px; margin-top: 8px; color: #92400e; background: #fffbeb; border: 1px solid #fbbf24; border-radius: 6px; padding: 7px 9px; font-size: 13px; line-height: 1.35; font-weight: 700; box-shadow: 0 1px 0 rgba(146,64,14,0.08); }
    .library-date-notice.show { display: block; }
    .subtitle { margin-top: 4px; color: #475569; font-size: 13px; }
    .debug-paths { margin-top: 6px; color: #64748b; font-size: 12px; max-width: 760px; }
    .debug-paths summary { cursor: pointer; user-select: none; }
    .pathline { margin-top: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .run-summary { margin-top: 8px; display: flex; gap: 10px; flex-wrap: wrap; color: #475569; font-size: 12px; }
    .summary-pill { border: 1px solid #d7e0ee; background: #f8fafc; border-radius: 999px; padding: 3px 9px; }
    .summary-pill.media-recovering { border-color: #93c5fd; background: #eff6ff; color: #1d4ed8; font-weight: 700; }
    .summary-pill.media-recovered { border-color: #86efac; background: #f0fdf4; color: #166534; font-weight: 700; }
    .summary-pill.media-failed { border-color: #fecaca; background: #fef2f2; color: #b91c1c; font-weight: 700; }
    .recommended-schedule-pill { border-color: #86efac; background: #f0fdf4; color: #166534; font-weight: 700; }
    .recommended-schedule-pill[hidden] { display: none; }
    .actions { display: grid; justify-items: end; gap: 8px; min-width: min(100%, 420px); flex: 1 1 420px; }
    .action-buttons { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; max-width: 100%; }
    .cms-advice { max-width: 520px; text-align: right; font-size: 13px; line-height: 1.4; color: #475569; }
    .cms-advice.reusable { color: #c2410c; background: #fff7ed; border: 1px solid #fed7aa; border-radius: 6px; padding: 6px 8px; font-weight: 700; }
    .cms-advice.blocked { color: #b91c1c; font-weight: 600; }
    .cms-advice.library { color: #0f766e; background: #f0fdfa; border: 1px solid #99f6e4; border-radius: 6px; padding: 6px 8px; font-weight: 700; }
    .cms-advice.cancelled { color: #c2410c; background: #fff7ed; border: 1px solid #fed7aa; border-radius: 6px; padding: 6px 8px; font-weight: 700; }
    .library-btn { border-color: #0f766e; color: #0f766e; }
    .batchbar { margin: 0 18px 12px; padding: 12px; border: 1px solid #d7e0ee; border-radius: 8px; background: #fff; display: grid; gap: 10px; }
    .tool-row { min-height: 36px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .status-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .status-actions { min-width: min(100%, 420px); flex: 1 1 420px; display: flex; align-items: center; justify-content: flex-end; gap: 8px; }
    .status-actions .status { min-width: 0; overflow-wrap: anywhere; text-align: right; }
    #locateErrorBtn { flex: 0 0 auto; white-space: nowrap; }
    .view-note { font-size: 12px; color: #64748b; line-height: 1.45; }
    button { height: 36px; border: 1px solid #94a3b8; background: #fff; border-radius: 6px; padding: 0 14px; cursor: pointer; font: inherit; }
    button.primary { background: #2563eb; border-color: #2563eb; color: white; }
    button.danger { border-color: #dc2626; color: #b91c1c; }
    button.ghost { border-color: #2563eb; color: #1d4ed8; }
    button.active { background: #111827; border-color: #111827; color: white; }
    button.small-btn { height: 32px; padding: 0 10px; font-size: 13px; }
    table { width: 100%; border-collapse: collapse; table-layout: fixed; background: #fff; border: 1px solid #d8dde6; }
    th, td { border-bottom: 1px solid #e2e8f0; padding: 10px; vertical-align: top; font-size: 14px; }
    th { background: #eef3f9; text-align: left; font-weight: 700; position: static; box-shadow: 0 1px 0 #d8dde6; }
    .library-segment-row td { padding: 0; border-bottom: 1px solid #86efac; background: #f0fdf4; }
    .library-segment-banner { display: flex; align-items: center; justify-content: space-between; gap: 12px; min-height: 44px; padding: 8px 14px; color: #166534; font-weight: 800; }
    .library-segment-banner span { color: #15803d; font-size: 12px; font-weight: 600; }
    body.row-select-dragging { user-select: none; cursor: crosshair; }
    body.row-select-dragging input[data-select-row] { cursor: crosshair; }
    input, select, textarea { width: 100%; border: 1px solid #cbd5e1; border-radius: 5px; padding: 7px 8px; font: inherit; background: #fff; }
    textarea { min-height: 72px; resize: vertical; line-height: 1.45; }
    .select-col { width: 58px; text-align: center; }
    .exec { width: 76px; }
    .role { width: 92px; }
    .speaker { width: 260px; }
    table.precise-tuo-table .speaker { width: 430px; }
    .date { width: 136px; }
    .time { width: 136px; }
    .type { width: 94px; }
    .skip { width: 72px; text-align: center; }
    .content { width: 360px; min-width: 360px; }
    .muted { color: #64748b; font-size: 12px; }
    .status { min-height: 18px; font-size: 13px; color: #166534; }
    .error { color: #b91c1c; }
    .index-cell strong { display: block; font-size: 16px; margin-bottom: 2px; }
    .subnote { margin-top: 5px; color: #64748b; font-size: 12px; line-height: 1.35; }
    .content-grid { display: grid; grid-template-columns: 1fr; gap: 8px; }
    .media-box { display: grid; grid-template-columns: 96px 1fr; gap: 10px; align-items: start; }
    .media-box.media-drop-zone { border: 1px dashed #cbd5e1; border-radius: 7px; padding: 7px; background: #fff; }
    .media-box.media-drop-zone.drag-over { border-color: #2563eb; background: #eff6ff; }
    .media-tools { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin-top: 7px; }
    .media-hint { color: #64748b; font-size: 12px; line-height: 1.35; margin-top: 5px; }
    .thumb { width: 96px; height: 76px; border: 1px solid #d1d5db; background: #f8fafc; display: flex; align-items: center; justify-content: center; overflow: hidden; color: #64748b; font-size: 12px; }
    .thumb img, .thumb video { max-width: 100%; max-height: 100%; display: block; }
    .media-thumb { cursor: zoom-in; }
    .media-popover { position: fixed; z-index: 30; display: none; width: min(286px, calc(100vw - 24px)); padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; background: #fff; box-shadow: 0 14px 36px rgba(15, 23, 42, 0.22); pointer-events: none; }
    .media-popover.open { display: block; }
    .media-popover img, .media-popover video { display: block; max-width: 268px; max-height: min(360px, calc(100vh - 44px)); margin: 0 auto; object-fit: contain; background: #f8fafc; }
    .hidden-file { display: none; }
    tr.skipped { background: #f3f4f6; color: #6b7280; }
    tr.invalid { outline: 2px solid #fecaca; outline-offset: -2px; }
    tr.time-over-end { background: #fff1f2; outline: 2px solid #fecaca; outline-offset: -2px; }
    tr.time-over-end input[data-field='time'] { border-color: #ef4444; background: #fff7f7; color: #991b1b; font-weight: 700; }
    tr.continuation-locked { background: #f8fafc; color: #64748b; }
    .continuation-lock-badge { display: inline-block; margin-top: 5px; padding: 2px 6px; border: 1px solid #bbf7d0; border-radius: 4px; background: #f0fdf4; color: #166534; font-size: 11px; font-weight: 700; }
    tr.repair-focus { background: #fff1f2; }
    .row-note { margin-top: 4px; color: #b91c1c; font-size: 12px; line-height: 1.35; }
    .row-note.error { color: #b91c1c; background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 6px 8px; font-weight: 700; }
    .row-note.warning { color: #92400e; background: #fffbeb; border: 1px solid #fde68a; border-radius: 6px; padding: 6px 8px; }
    .toolbar-label { color: #374151; font-size: 13px; }
    .toolbar-input { width: 132px; }
    .toolbar-date-custom { width: 132px; }
    .toolbar-number { width: 80px; }
    .retime-panel { border-top: 1px solid #e2e8f0; padding-top: 10px; display: grid; gap: 8px; }
    .retime-panel[hidden] { display: none; }
    .retime-title { color: #0f172a; font-weight: 700; font-size: 13px; }
    .retime-input { width: 116px; }
    .retime-mode { width: 190px; }
    .retime-number { width: 70px; }
    .retime-hint { color: #64748b; font-size: 12px; line-height: 1.45; }
    .cross-day-notice { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 10px; padding: 9px 10px; border: 1px solid #f59e0b; border-radius: 6px; background: #fffbeb; color: #92400e; font-size: 13px; line-height: 1.45; font-weight: 700; }
    .cross-day-notice[hidden] { display: none; }
    .source-day-boundary-row td { padding: 7px 12px; border-top: 2px solid #f59e0b; border-bottom: 1px solid #fde68a; background: #fffbeb; color: #92400e; font-size: 13px; font-weight: 800; }
    .preview-path { margin-top: 5px; color: #64748b; font-size: 12px; overflow-wrap: anywhere; line-height: 1.35; }
    .tag { display: inline-block; border-radius: 999px; background: #dbeafe; color: #1d4ed8; padding: 2px 8px; font-size: 12px; margin-right: 8px; }
    .media-status { margin-top: 5px; color: #64748b; font-size: 12px; }
    .media-status.recovering { color: #1d4ed8; font-weight: 700; }
    .media-status.good { color: #15803d; font-weight: 700; }
    .media-status.bad { color: #b91c1c; font-weight: 600; }
    .manual-badge { display: inline-block; margin-top: 4px; color: #92400e; background: #fef3c7; border: 1px solid #fde68a; border-radius: 999px; padding: 1px 7px; font-size: 12px; }
    .speaker-picker { display: grid; gap: 8px; align-items: start; }
    .speaker-main-row { display: grid; grid-template-columns: 58px 82px minmax(220px, 1fr); gap: 7px; align-items: start; }
    .speaker-picker label { display: grid; gap: 3px; color: #475569; font-size: 12px; font-weight: 700; }
    .speaker-picker select, .speaker-picker input { min-height: 32px; padding: 5px 8px; font-size: 13px; }
    .persona-note { display: grid; gap: 4px; color: #475569; font-size: 12px; line-height: 1.35; }
    .current-candidate { display: flex; align-items: center; justify-content: center; min-height: 32px; padding: 5px 8px; border: 1px solid #fb923c; border-radius: 6px; background: #fff7ed; }
    .current-label { color: #c2410c; font-weight: 800; white-space: nowrap; }
    .candidate-prefix { color: #64748b; font-weight: 700; }
    .candidate-text { font-weight: 700; color: #17345c; }
    .candidate-meta { color: #64748b; font-weight: 600; }
    .backup-tag { display: inline-flex; align-items: center; min-height: 19px; padding: 0 6px; border-radius: 999px; border: 1px solid #fed7aa; background: #fff7ed; color: #c2410c; font-size: 12px; font-weight: 700; white-space: nowrap; }
    .candidate-list { display: grid; grid-template-columns: 58px 82px minmax(220px, 1fr); gap: 6px 7px; padding-top: 6px; border-top: 1px solid #e2e8f0; color: #475569; font-size: 12px; font-weight: 700; }
    .candidate-section-label { display: flex; align-items: center; min-height: 32px; padding-left: 8px; color: #475569; font-weight: 700; }
    .candidate-picks { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px; }
    .candidate-list select { min-height: 32px; padding: 5px 8px; font-size: 13px; }
    .candidate-pick { display: flex; align-items: center; flex-wrap: nowrap; gap: 5px; height: 32px; min-height: 32px; padding: 5px 8px; text-align: left; border-color: #cbd5e1; color: #17345c; background: #f8fafc; font-size: 12px; font-weight: 600; line-height: 1.35; overflow: hidden; }
    .candidate-pick.backup { border-color: #fdba74; background: #fffaf5; }
    .candidate-pick .candidate-text, .candidate-pick .candidate-meta { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .candidate-shortage { min-height: 24px; padding: 5px 8px; border: 1px solid #fde68a; border-radius: 6px; background: #fffbeb; color: #92400e; font-weight: 600; line-height: 1.4; }
    .modal-backdrop { position: fixed; inset: 0; z-index: 20; display: none; align-items: center; justify-content: center; padding: 22px; background: rgba(15, 23, 42, 0.42); }
    .modal-backdrop.open { display: flex; }
    .modal { width: min(720px, 100%); max-height: calc(100vh - 44px); overflow: auto; background: #fff; border-radius: 8px; box-shadow: 0 24px 60px rgba(15, 23, 42, 0.24); border: 1px solid #d8dde6; }
    .modal-header { padding: 16px 18px 12px; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .modal-title { font-size: 18px; font-weight: 700; }
    .modal-close-danger { min-width: 34px; height: 34px; padding: 0; border-color: #fecaca; color: #dc2626; background: #fff1f2; font-size: 20px; line-height: 1; font-weight: 800; }
    .modal-close-danger:hover { border-color: #f87171; background: #fee2e2; color: #b91c1c; }
    .modal-body { padding: 16px 18px; display: grid; gap: 14px; }
    .modal-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
    .modal-field { display: grid; gap: 6px; }
    .modal-field label { font-size: 13px; color: #374151; }
    .modal-field.full { grid-column: 1 / -1; }
    .modal-actions { padding: 12px 18px 16px; display: flex; justify-content: flex-end; gap: 8px; border-top: 1px solid #e2e8f0; }
    .modal-error { color: #b91c1c; font-size: 13px; min-height: 18px; line-height: 1.4; }
    .modal-hint { color: #475569; font-size: 13px; line-height: 1.5; }
    .content-actions { display: flex; justify-content: flex-end; gap: 8px; }
    .detail-textarea { min-height: min(58vh, 520px); font-family: Consolas, "Microsoft YaHei", monospace; white-space: pre-wrap; }
    .manual-media-preview { display: grid; grid-template-columns: 112px 1fr; align-items: start; gap: 10px; }
    .manual-media-preview.media-drop-zone { border: 1px dashed #cbd5e1; border-radius: 7px; padding: 8px; }
    .manual-media-preview.media-drop-zone.drag-over { border-color: #2563eb; background: #eff6ff; }
    .wide-modal { width: min(1120px, 100%); }
    #manualBatchModal .modal-header { cursor: move; user-select: none; }
    #manualBatchModal .modal-header button { cursor: pointer; }
    #manualBatchModal .wide-modal { height: min(760px, calc(100vh - 44px)); display: flex; flex-direction: column; overflow: hidden; }
    #manualBatchModal .wide-modal.is-dragging { transition: none; }
    #manualBatchModal .modal-body { min-height: 0; overflow: hidden; grid-template-rows: auto minmax(0, 1fr) auto; }
    #manualBatchModal .modal-actions { flex-shrink: 0; background: #fff; }
    .manual-batch-tools { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .manual-batch-step { display: grid; grid-template-columns: minmax(90px, 1fr) 92px; gap: 8px; }
    .manual-batch-table-wrap { min-height: 0; overflow: auto; border: 1px solid #d8dde6; border-radius: 8px; }
    .manual-batch-table { width: 100%; border-collapse: collapse; table-layout: fixed; font-size: 13px; }
    .manual-batch-table th, .manual-batch-table td { border-bottom: 1px solid #e5e7eb; padding: 8px; vertical-align: top; }
    .manual-batch-table th { position: sticky; top: 0; z-index: 1; background: #f8fafc; color: #334155; text-align: left; font-weight: 700; }
    .manual-batch-table tbody tr:last-child td { border-bottom: 0; }
    .manual-batch-table select, .manual-batch-table input, .manual-batch-table textarea { width: 100%; min-width: 0; font-size: 13px; }
    .manual-batch-table textarea { min-height: 58px; resize: vertical; }
    .manual-batch-table textarea.drag-over { border-color: #2563eb; background: #eff6ff; }
    .manual-batch-media-box { display: grid; grid-template-columns: 74px minmax(0, 1fr); gap: 8px; align-items: start; margin-top: 7px; padding: 7px; border: 1px dashed #cbd5e1; border-radius: 7px; background: #fff; }
    .manual-batch-media-box.drag-over { border-color: #2563eb; background: #eff6ff; }
    .manual-batch-media-box .thumb { width: 72px; height: 58px; }
    .manual-batch-media-tools { display: grid; gap: 5px; }
    .manual-batch-media-actions { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
    .manual-batch-table .batch-role { width: 82px; }
    .manual-batch-table .batch-speaker { width: 150px; }
    .manual-batch-table .batch-date { width: 96px; }
    .manual-batch-table .batch-time { width: 108px; }
    .manual-batch-table .batch-type { width: 92px; }
    .manual-batch-table .batch-skip { width: 58px; text-align: center; }
    .manual-batch-table .batch-action { width: 70px; text-align: center; }
    .manual-batch-table .batch-content { min-width: 260px; }
    @media (max-width: 720px) {
      .modal-grid, .manual-media-preview { grid-template-columns: 1fr; }
    }
    details.debug { margin-top: 8px; color: #64748b; font-size: 12px; }
    details.debug summary { cursor: pointer; user-select: none; }
    .debug-grid { margin-top: 8px; display: grid; grid-template-columns: repeat(5, minmax(130px, 1fr)); gap: 8px; }
    .debug-grid label { display: block; color: #475569; }
    .debug-grid input, .debug-grid textarea { margin-top: 4px; font-size: 12px; }
  </style>
</head>
<body>
  <header>
    <div class="topbar">
      <div>
        <div class="title">妙券自动发单 - 预览确认</div>
        <div class="run-mode${meta.robotStrategy ? "" : " pending"}">
          <div class="run-mode-title">${modeTitle}</div>
          <div class="run-mode-details">${modeDetails}</div>
        </div>
        <div class="subtitle">本次共 <strong id="totalCount">0</strong> 条，已选中 <strong id="selectedCount">0</strong> 条，已标记不发 <strong id="skipCount">0</strong> 条</div>
        <div class="run-summary">
          <span class="summary-pill">本次读取范围：${rangeLabel}</span>
          <span class="summary-pill">原始采集：${rawEventCount} 条</span>
          <span class="summary-pill">预览条目：${previewTaskCount} 条</span>
          <span id="currentDateSummary" class="summary-pill">当前任务日期：正在读取</span>
          ${combinedLibrarySummary}
          <span id="recommendedScheduleSummary" class="summary-pill recommended-schedule-pill" hidden></span>
          <span id="mediaRecoverySummary" class="summary-pill" hidden></span>
        </div>
        <div id="libraryDateNotice" class="library-date-notice"></div>
        <details class="debug-paths">
          <summary>高级/调试信息</summary>
          <div class="pathline">预览内容文件：${previewPathText}</div>
          <div class="pathline">当前目录：${runDirText}</div>
        </details>
      </div>
      <div class="actions">
        <div class="action-buttons">
          <button class="ghost" id="addRowBtn">手动补录</button>
          <button class="library-btn" id="saveLibraryBtn" title="保存当前改完的预览内容和素材，以后可从控制台文案库直接打开。">存入文案库</button>
          <button class="ghost" id="regenerateBtn" title="飞书文案改过后，沿用控制台当前范围和时间模式重新采集、解析并生成预览。">文案有变，重新生成预览</button>
          <button class="primary" id="confirmBtn">确认无误，进入云中客设置</button>
        </div>
        <div id="cmsAdvice" class="cms-advice">首次确认请进入云中客设置；如果云中客页面已设置且仍可复用，保存后会自动提示返回控制台创建。</div>
      </div>
    </div>
    <div class="batchbar">
      <div id="crossDayNotice" class="cross-day-notice" hidden>
        <span id="crossDayNoticeText"></span>
        <button id="crossDayRetimeBtn" class="small-btn" type="button">打开重排时间</button>
      </div>
      <div class="tool-row">
        <span class="toolbar-label">批量修改：已选 <strong id="batchSelectedCount">0</strong> 条</span>
        <button id="selectAllBtn" class="small-btn">全选</button>
        <button id="selectNoneBtn" class="small-btn">全不选</button>
        <span class="toolbar-label">批量日期：</span>
        <select id="batchDateQuick" class="toolbar-input"></select>
        <input id="batchDateCustom" class="toolbar-date-custom" placeholder="自定义日期" hidden>
        <button id="applyDateBtn" class="small-btn">应用日期</button>
        <span id="batchDateActionSummary" class="toolbar-label">将选中 0 条改为待选日期（尚未应用）</span>
        <span class="toolbar-label">时间：</span>
        <button id="delayBtn" class="small-btn">整体延后</button>
        <button id="advanceBtn" class="small-btn">整体提前</button>
        <input id="batchMinutes" class="toolbar-number" type="number" value="5">
        <select id="batchTimeUnit" class="toolbar-input">
          <option value="second">秒</option>
          <option value="minute" selected>分钟</option>
          <option value="hour">小时</option>
          <option value="day">天</option>
        </select>
        <button id="applyTimeBtn" class="small-btn">应用时间</button>
        <button id="restoreTimeBtn" class="small-btn">恢复选中行时间</button>
        <button id="undoBtn" class="small-btn" disabled>撤回上一步</button>
        <button id="restoreOpenStateBtn" class="small-btn" disabled>恢复打开时状态</button>
      </div>
      <div class="tool-row">
        <span class="toolbar-label">角色：</span>
        <select id="batchRole" class="toolbar-input"><option value="">角色</option><option value="tuo">托</option><option value="douma">豆妈</option></select>
        <button id="applyRoleBtn" class="small-btn">批量改角色</button>
        <button id="skipSelectedBtn" class="small-btn">设为不发</button>
        <button id="unskipSelectedBtn" class="small-btn">取消不发</button>
        <span class="toolbar-label">查看方式：</span>
        <button class="active" id="executionViewBtn">按执行顺序</button>
        <button id="timeViewBtn">按时间顺序</button>
        <button id="toggleSkippedRowsBtn">隐藏不发</button>
        <button id="toggleRetimePanelBtn" class="small-btn" type="button" aria-expanded="false" aria-controls="retimePanel">重排时间</button>
      </div>
      <div class="retime-panel" id="retimePanel" hidden>
        <div class="tool-row">
          <span class="retime-title">重排时间：</span>
          <span class="toolbar-label">开始方式</span>
          <select id="retimeStartMode" class="retime-mode">
            <option value="normal">正常开始</option>
            <option value="reverse">反推开始时间</option>
          </select>
          <span class="toolbar-label">开始（可选）</span>
          <input id="retimeStartTime" class="retime-input" placeholder="留空默认当前时间1分钟后">
          <span class="toolbar-label">结束</span>
          <input id="retimeEndTime" class="retime-input" placeholder="可留空">
          <button id="retimeApplyBtn" class="small-btn primary">按间隔重排</button>
          <span id="retimeSummary" class="retime-hint"></span>
        </div>
        <div class="tool-row">
          <span class="toolbar-label">不同托</span>
          <input id="retimeDifferentTuoMin" class="retime-number" type="number" min="0" value="15">
          <span>-</span>
          <input id="retimeDifferentTuoMax" class="retime-number" type="number" min="0" value="15">
          <span class="toolbar-label">同托连续</span>
          <input id="retimeSameTuoMin" class="retime-number" type="number" min="0" value="20">
          <span>-</span>
          <input id="retimeSameTuoMax" class="retime-number" type="number" min="0" value="45">
          <span class="toolbar-label">图片/表情/视频</span>
          <input id="retimeMediaMin" class="retime-number" type="number" min="0" value="30">
          <span>-</span>
          <input id="retimeMediaMax" class="retime-number" type="number" min="0" value="50">
          <span class="toolbar-label">豆妈连续</span>
          <input id="retimeDoumaSameMin" class="retime-number" type="number" min="0" value="45">
          <span>-</span>
          <input id="retimeDoumaSameMax" class="retime-number" type="number" min="0" value="45">
          <span class="toolbar-label">豆妈/托切换</span>
          <input id="retimeRoleSwitchMin" class="retime-number" type="number" min="0" value="120">
          <span>-</span>
          <input id="retimeRoleSwitchMax" class="retime-number" type="number" min="0" value="120">
        </div>
        <div class="retime-hint">只按当前预览内容重新计算日期和时间；正文、素材、说话人、托分配和不发标记都不变。</div>
      </div>
      <div class="status-row">
        <div id="viewNote" class="view-note">
          <div>按执行顺序：同编号托会放在一起，时间不变。</div>
          <div>按时间顺序：仅用于检查，不改变正式执行顺序。</div>
        </div>
        <div class="status-actions">
          <div id="status" class="status"></div>
          <button id="retryMediaBtn" class="small-btn" type="button" hidden>重新获取缺失素材</button>
          <button id="locateErrorBtn" class="small-btn danger" type="button" hidden>定位到错误处</button>
        </div>
      </div>
    </div>
    <span id="source" hidden>${source}</span>
  </header>
  <main>
    <table id="previewTable">
      <thead>
        <tr>
          <th class="select-col">批量</th>
          <th class="exec">序号</th>
          <th class="role">角色</th>
          <th class="speaker" id="speakerHeader">说话人</th>
          <th class="date">日期</th>
          <th class="time">时间</th>
          <th class="type">类型</th>
          <th class="content">内容/素材</th>
          <th class="skip">不发</th>
        </tr>
      </thead>
      <tbody id="rows"></tbody>
    </table>
  </main>
  <div class="media-popover" id="mediaPopover" aria-hidden="true"></div>
  <div class="modal-backdrop" id="manualModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="manualModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="manualModalTitle">手动补一条</div>
        <button class="small-btn" id="manualCancelTopBtn" type="button">取消</button>
      </div>
      <div class="modal-body">
        <div class="modal-grid">
          <div class="modal-field">
            <label for="manualRole">角色</label>
            <select id="manualRole"><option value="tuo">托</option><option value="douma">豆妈</option></select>
          </div>
          <div class="modal-field">
            <label for="manualSpeaker">说话人</label>
            <input id="manualSpeaker">
          </div>
          <div class="modal-field">
            <label for="manualDate">日期</label>
            <input id="manualDate">
          </div>
          <div class="modal-field">
            <label for="manualTime">时间</label>
            <input id="manualTime" placeholder="例如 19:16:10">
          </div>
          <div class="modal-field">
            <label for="manualType">类型</label>
            <select id="manualType"><option value="text">文字</option><option value="finder">视频号</option><option value="image">图片</option><option value="sticker">表情包</option><option value="video">视频</option></select>
          </div>
          <div class="modal-field">
            <label for="manualInsertPosition">插入位置</label>
            <select id="manualInsertPosition"><option value="after-selection">当前选中行后</option><option value="before-selection">当前选中行前</option><option value="end">末尾</option></select>
          </div>
          <div class="modal-field">
            <label><input id="manualSkip" type="checkbox"> 是否不发</label>
          </div>
          <div class="modal-field full" id="manualTextWrap">
            <label for="manualText">正文</label>
            <textarea id="manualText"></textarea>
          </div>
          <div class="modal-field full" id="manualMediaWrap" hidden>
            <label for="manualMediaPath">素材选择/上传</label>
            <div class="manual-media-preview media-drop-zone" id="manualMediaDropZone">
              <div class="thumb" id="manualMediaThumb">无素材</div>
              <div>
                <input id="manualMediaPath" placeholder="可填写本地素材路径">
                <div class="preview-path" id="manualMediaShortPath">未选择素材</div>
                <div class="media-status" id="manualMediaStatus">未选择素材</div>
                <input class="hidden-file" id="manualMediaFile" type="file">
                <button class="small-btn ghost" id="manualChooseMediaBtn" type="button">选择素材</button>
                <div class="media-hint">也可以拖拽文件到这里，或复制图片后按 Ctrl+V 粘贴。</div>
              </div>
            </div>
          </div>
        </div>
        <div id="manualModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="manualCancelBtn" type="button">取消</button>
        <button class="primary" id="manualAddBtn" type="button">添加</button>
      </div>
    </div>
  </div>
  <div class="modal-backdrop" id="manualBatchModal" aria-hidden="true">
    <div class="modal wide-modal" role="dialog" aria-modal="true" aria-labelledby="manualBatchModalTitle">
      <div class="modal-header" title="按住标题栏可拖动窗口">
        <div class="modal-title" id="manualBatchModalTitle">手动补录</div>
        <button class="small-btn modal-close-danger" id="manualBatchCancelTopBtn" type="button" aria-label="关闭" title="关闭">×</button>
      </div>
      <div class="modal-body">
        <div class="modal-grid">
          <div class="modal-field">
            <label for="manualBatchInsertPosition">插入位置</label>
            <select id="manualBatchInsertPosition"><option value="after-selection">当前选中行后</option><option value="before-selection">当前选中行前</option><option value="end">末尾</option></select>
          </div>
          <div class="modal-field">
            <label for="manualBatchStepMinutes">每行时间递增</label>
            <div class="manual-batch-step">
              <input id="manualBatchStepMinutes" type="number" min="0" value="1">
              <select id="manualBatchStepUnit"><option value="minute">分钟</option><option value="second">秒</option></select>
            </div>
          </div>
          <div class="modal-field full">
            <div class="manual-batch-tools">
              <button class="small-btn ghost" id="manualBatchAddLineBtn" type="button">再加一行</button>
              <span class="modal-hint">只会添加已填写正文/素材的行，空白行自动跳过。图片/视频/表情包可点选择文件，也可拖拽或粘贴图片。</span>
            </div>
            <div class="modal-hint" id="manualBatchStepHint">例：起始 19:34:37，递增 1 分钟，后续行自动变为 19:35:37、19:36:37。</div>
          </div>
        </div>
        <div class="manual-batch-table-wrap">
          <table class="manual-batch-table">
            <thead>
              <tr>
                <th class="batch-role">角色</th>
                <th class="batch-speaker">说话人</th>
                <th class="batch-date">日期</th>
                <th class="batch-time">时间</th>
                <th class="batch-type">类型</th>
                <th class="batch-content">正文/素材</th>
                <th class="batch-skip">不发</th>
                <th class="batch-action">操作</th>
              </tr>
            </thead>
            <tbody id="manualBatchRows"></tbody>
          </table>
        </div>
        <div id="manualBatchModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="manualBatchCancelBtn" type="button">取消</button>
        <button class="primary" id="manualBatchAddBtn" type="button">添加已填写行</button>
      </div>
    </div>
  </div>
  <div class="modal-backdrop" id="librarySaveModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="librarySaveModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="librarySaveModalTitle">存入文案库</div>
        <button class="small-btn" id="librarySaveCancelTopBtn" type="button">取消，不保存</button>
      </div>
      <div class="modal-body">
        <div class="modal-hint" id="librarySaveHint">确认后会保存当前预览页已修改的内容和素材，以后可从控制台文案库直接打开。</div>
        <div class="modal-grid">
          <div class="modal-field full" id="librarySaveModeWrap" hidden>
            <label for="librarySaveMode">保存方式</label>
            <select id="librarySaveMode">
              <option value="overwrite">覆盖原文案</option>
              <option value="copy">另存为新文案</option>
            </select>
          </div>
          <div class="modal-field full" id="librarySaveNameWrap">
            <label for="librarySaveName">文案名称</label>
            <input id="librarySaveName" placeholder="给这份文案起个名字">
          </div>
          <div class="modal-field full" id="librarySaveTargetWrap" hidden>
            <label for="librarySaveTarget">选择要覆盖的文案</label>
            <select id="librarySaveTarget"></select>
          </div>
        </div>
        <div id="librarySaveModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="librarySaveCancelBtn" type="button">取消，不保存</button>
        <button class="primary" id="librarySaveConfirmBtn" type="button">确认存入文案库</button>
      </div>
    </div>
  </div>
  <div class="modal-backdrop" id="contentDetailModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="contentDetailModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="contentDetailModalTitle">内容详情</div>
        <button class="small-btn" id="contentDetailCloseTopBtn" type="button">关闭</button>
      </div>
      <div class="modal-body">
        <div class="modal-hint" id="contentDetailMeta"></div>
        <textarea class="detail-textarea" id="contentDetailText" readonly></textarea>
      </div>
      <div class="modal-actions">
        <button class="primary" id="contentDetailCloseBtn" type="button">关闭</button>
      </div>
    </div>
  </div>
  <div class="modal-backdrop" id="regenerateModal" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="regenerateModalTitle">
      <div class="modal-header">
        <div class="modal-title" id="regenerateModalTitle">重新生成预览</div>
        <button class="small-btn" id="regenerateCancelTopBtn" type="button">取消</button>
      </div>
      <div class="modal-body">
        <div class="modal-hint" id="regenerateModalHint"></div>
        <div id="regenerateModalError" class="modal-error"></div>
      </div>
      <div class="modal-actions">
        <button id="regenerateCancelBtn" type="button">取消</button>
        <button class="primary" id="regenerateConfirmBtn" type="button">确认重新生成</button>
      </div>
    </div>
  </div>
  <script>
    const defaultDate = ${defaultDate};
    const runDirForPage = ${runDirJson};
    const runIdForPage = ${runIdJson};
    const robotStrategy = ${robotStrategyJson};
    const initialSchedule = ${initialScheduleJson};
    const preciseTuoEnabled = robotStrategy === "precise";
    clearLegacyPreviewStorage();
    let tasks = normalizeTasksForCurrentRun(${tasksJson});
    let recommendedScheduleState = initialRecommendedScheduleState();
    let viewMode = "execution";
    let hideSkippedRows = false;
    let pendingTimeDirection = 1;
    let selectedRows = new Set();
    let rowSelectDrag = null;
    let suppressRowSelectClickUntil = 0;
    let dirty = false;
    let autoSaveTimer = null;
    let retimeEstimateTimer = null;
    let saveFailed = false;
    let savedAt = "";
    let lastSaveAdvice = null;
    let libraryUnsavedChanges = false;
    let librarySaveModalResolver = null;
    let previewLibraryItems = [];
    let previewLibraryItemsLoaded = false;
    let mediaPopoverTarget = null;
    const consoleUrl = ${consoleUrl};
    const libraryItem = ${libraryItemJson};
    const libraryDateNotice = ${JSON.stringify(meta.libraryDateNotice || "").replace(/</g, "\\u003c")};
    let previewRepairProblem = ${JSON.stringify(meta.repairProblem || null).replace(/</g, "\\u003c")};
    const resumeAfterEdit = ${resumeAfterEditJson};
    const scheduleContinuation = ${scheduleContinuationJson};
    const resumeFromIndex = ${resumeFromIndexJson};
    const succeededTaskKeys = new Set(${succeededTaskKeysJson});
    let previewRepairFocused = false;
    let previewInitialInvalidFocused = false;
    let mediaRecoveryPollTimer = null;
    let mediaRecoveryApplying = false;
    let mediaRecoveryProgress = null;
    const mediaRecoveryDeferred = new Map();
    let mediaRecoveryDeferredTimer = null;
    const preciseTuoRosterOptions = ${preciseTuoRosterJson};
    window.__v2PreviewPage = true;
    window.__v2PreviewRunDir = runDirForPage;
    window.__v2PreviewRunId = runIdForPage;
    window.__v2PreviewDefaultDate = defaultDate;
    window.__v2PreviewDirty = false;
    const originalTimes = tasks.map((task) => ({ date: task.documentDate || task.date || "", time: task.documentTime || task.time || "" }));
    const initialTasksSnapshot = cloneTasks(tasks);
    const initialOriginalTimesSnapshot = cloneTasks(originalTimes);
    let undoStack = [];
    const fields = ["role", "speaker", "date", "time", "type", "text", "mediaPath", "skip", "order", "interactionGroup", "continueMarker", "cleanSpeaker", "sourceId", "sourceText", "documentDate", "documentTime", "daySegment", "tuoAssignment", "submitIdentity", "repairsSourceIds", "importResolutionConfirmed"];
    initBatchDateControls();
    initRetimeControls();
    initLibraryDateNotice();
    render();
    if (resumeAfterEdit) applySaveAdvice({ action: "reuse_cms" });
    focusInitialRepairProblem();
    focusInitialInvalidProblem();
    startAutomaticMediaRecovery();

    document.getElementById("executionViewBtn").addEventListener("click", () => {
      collect();
      viewMode = "execution";
      render();
      setStatus("当前按执行顺序显示；同编号托会放在一起，时间不变。");
    });
    document.getElementById("timeViewBtn").addEventListener("click", () => {
      collect();
      viewMode = "time";
      render();
      setStatus("当前仅按时间顺序查看，不改变实际执行顺序。");
    });
    document.getElementById("toggleSkippedRowsBtn").addEventListener("click", () => {
      collect();
      hideSkippedRows = !hideSkippedRows;
      if (hideSkippedRows) {
        selectedRows = new Set(Array.from(selectedRows).filter((index) => !tasks[index]?.skip));
      }
      render();
      setStatus(hideSkippedRows ? "已隐藏标记为不发的行；点击“显示全部”可恢复。" : "已显示全部预览内容。");
    });
    document.getElementById("addRowBtn").addEventListener("click", () => {
      collect();
      openManualBatchModal();
    });
    document.getElementById("manualCancelTopBtn").addEventListener("click", () => closeManualModal());
    document.getElementById("manualCancelBtn").addEventListener("click", () => closeManualModal());
    document.getElementById("manualType").addEventListener("change", () => updateManualTypeFields());
    document.getElementById("manualMediaPath").addEventListener("input", () => updateManualMediaPreview());
    document.getElementById("manualMediaFile").addEventListener("change", () => updateManualMediaPreview());
    document.getElementById("manualChooseMediaBtn").addEventListener("click", () => document.getElementById("manualMediaFile").click());
    document.getElementById("manualAddBtn").addEventListener("click", () => addManualTaskFromModal());
    document.getElementById("manualBatchCancelTopBtn").addEventListener("click", () => closeManualBatchModal());
    document.getElementById("manualBatchCancelBtn").addEventListener("click", () => closeManualBatchModal());
    document.getElementById("manualBatchAddLineBtn").addEventListener("click", () => addManualBatchRow());
    document.getElementById("manualBatchAddBtn").addEventListener("click", () => addManualBatchTasksFromModal());
    document.getElementById("manualBatchInsertPosition").addEventListener("change", () => refreshManualBatchTiming());
    document.getElementById("manualBatchStepMinutes").addEventListener("input", () => refreshManualBatchTiming());
    document.getElementById("manualBatchStepUnit").addEventListener("change", () => refreshManualBatchTiming());
    initDraggableModal("manualBatchModal");
    document.getElementById("librarySaveMode").addEventListener("change", () => updateLibrarySaveModeFields());
    document.getElementById("librarySaveTarget").addEventListener("change", () => updateLibrarySaveModeFields());
    document.getElementById("librarySaveCancelTopBtn").addEventListener("click", () => cancelLibrarySaveModal());
    document.getElementById("librarySaveCancelBtn").addEventListener("click", () => cancelLibrarySaveModal());
    document.getElementById("librarySaveConfirmBtn").addEventListener("click", () => confirmLibrarySaveModal());
    document.getElementById("contentDetailCloseTopBtn").addEventListener("click", () => closeContentDetailModal());
    document.getElementById("contentDetailCloseBtn").addEventListener("click", () => closeContentDetailModal());
    document.getElementById("regenerateCancelTopBtn").addEventListener("click", () => closeRegenerateModal());
    document.getElementById("regenerateCancelBtn").addEventListener("click", () => closeRegenerateModal());
    document.getElementById("regenerateConfirmBtn").addEventListener("click", () => confirmRegeneratePreview());
    document.getElementById("selectAllBtn").addEventListener("click", () => {
      collect();
      selectedRows = new Set(sortedRowsForView()
        .filter((row) => !isContinuationLocked(row.task, row.originalIndex))
        .map((row) => row.originalIndex));
      render();
    });
    document.getElementById("selectNoneBtn").addEventListener("click", () => {
      collect();
      selectedRows = new Set();
      render();
    });
    document.getElementById("applyDateBtn").addEventListener("click", () => applyBatchDate());
    document.getElementById("batchDateQuick").addEventListener("change", () => {
      updateBatchDateCustomVisibility();
      updateDateSummaries();
    });
    document.getElementById("batchDateCustom").addEventListener("input", () => updateDateSummaries());
    document.getElementById("delayBtn").addEventListener("click", () => {
      pendingTimeDirection = 1;
      updateTimeDirectionButtons();
      setStatus("已选择整体延后：先勾选要修改的行，填写数值和单位后应用");
    });
    document.getElementById("advanceBtn").addEventListener("click", () => {
      pendingTimeDirection = -1;
      updateTimeDirectionButtons();
      setStatus("已选择整体提前：先勾选要修改的行，填写数值和单位后应用");
    });
    document.getElementById("applyTimeBtn").addEventListener("click", () => shiftSelectedTimes(pendingTimeDirection));
    document.getElementById("toggleRetimePanelBtn").addEventListener("click", () => toggleRetimePanel());
    document.getElementById("retimeApplyBtn").addEventListener("click", () => applyPreviewRetime());
    document.getElementById("crossDayRetimeBtn").addEventListener("click", () => openRetimePanel());
    document.getElementById("retimeStartMode").addEventListener("change", () => {
      updateRetimeStartMode();
      scheduleReverseRetimeEstimate();
    });
    document.getElementById("applyRoleBtn").addEventListener("click", () => applyBatchRole());
    document.getElementById("skipSelectedBtn").addEventListener("click", () => setSelectedSkip(true));
    document.getElementById("unskipSelectedBtn").addEventListener("click", () => setSelectedSkip(false));
    document.getElementById("restoreTimeBtn").addEventListener("click", () => restoreSelectedTimes());
    document.getElementById("undoBtn").addEventListener("click", () => undoLastChange());
    document.getElementById("restoreOpenStateBtn").addEventListener("click", () => restoreOpenState());
    document.getElementById("locateErrorBtn").addEventListener("click", () => locateFirstInvalidProblem());
    document.getElementById("retryMediaBtn").addEventListener("click", () => startAutomaticMediaRecovery({ restart: true }));
    document.getElementById("saveLibraryBtn").addEventListener("click", saveToLibrary);
    document.getElementById("confirmBtn").addEventListener("click", async () => {
      const saved = await savePreview();
      if (!saved.ok) return;
      if (saved.saveAdvice?.action === "reuse_cms") {
        applySaveAdvice(saved.saveAdvice);
        setStatus(saved.saveAdvice.message || "已保存；云中客页面仍可复用。请回控制台直接开始创建。");
        openConsole(saved);
        return;
      }
      const result = await postJson("/api/prepare-cms", { tasks });
      if (result.ok) {
        setStatus(result.preparedCms
          ? "已进入 CMS 准备阶段：请在云中客页面手动确认分组、机器人和发送策略，然后回到控制台继续。"
          : "已保存并核对通过：请准备云中客页面后再开始创建。");
        if (!result.preparedCms && (result.consoleUrl || consoleUrl)) setTimeout(() => openConsole(result), 400);
      } else {
        setStatus(result.error || "进入 CMS 准备阶段失败", true);
      }
    });
    document.getElementById("regenerateBtn").addEventListener("click", async () => {
      if (libraryItem) {
        setStatus("这份预览来自文案库，不能直接重新采集飞书。请回控制台重新选择文档并生成预览。", true);
        return;
      }
      openRegenerateModal();
    });

    function openRegenerateModal() {
      const modal = document.getElementById("regenerateModal");
      const hint = document.getElementById("regenerateModalHint");
      const error = document.getElementById("regenerateModalError");
      hint.textContent = dirty
        ? "当前预览有未保存修改。确认后会沿用控制台当前范围和时间模式重新采集飞书文案，并覆盖当前未保存修改。"
        : "确认后会沿用控制台当前范围和时间模式重新采集飞书文案。";
      error.textContent = "";
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setStatus("请确认是否重新生成预览。");
    }

    function closeRegenerateModal() {
      const modal = document.getElementById("regenerateModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    }

    async function confirmRegeneratePreview() {
      const button = document.getElementById("regenerateBtn");
      button.disabled = true;
      const confirmBtn = document.getElementById("regenerateConfirmBtn");
      const cancelBtn = document.getElementById("regenerateCancelBtn");
      const cancelTopBtn = document.getElementById("regenerateCancelTopBtn");
      const modalError = document.getElementById("regenerateModalError");
      confirmBtn.disabled = true;
      cancelBtn.disabled = true;
      cancelTopBtn.disabled = true;
      modalError.textContent = "";
      closeRegenerateModal();
      setStatus("已收到重新生成请求，正在调出飞书文档并重新读取，请稍等...");
      try {
        const result = await postJson("/api/regenerate", {});
        if (result.ok) {
          if (Array.isArray(result.tasks)) {
            clearLegacyPreviewStorage();
            tasks = normalizeTasksForCurrentRun(result.tasks);
            selectedRows = new Set();
            document.getElementById("source").textContent = result.source || "";
            dirty = false;
            window.__v2PreviewDirty = false;
            viewMode = "execution";
            render();
            setStatus("已重新生成预览内容");
            return;
          }
          clearLegacyPreviewStorage();
          dirty = false;
          window.__v2PreviewDirty = false;
          setStatus(result.refocusFeishu
            ? "已开始调出飞书文档重新读取，完成后会打开新的预览页。"
            : "已提交重新生成预览请求，请到控制台查看进度。");
          if (!result.refocusFeishu) openConsole(result);
          return;
        }
        setStatus(result.error || "重新生成预览失败", true);
      } catch (error) {
        setStatus("重新生成预览失败：" + (error?.message || error), true);
      } finally {
        button.disabled = false;
        confirmBtn.disabled = false;
        cancelBtn.disabled = false;
        cancelTopBtn.disabled = false;
      }
    }

    function render() {
      updateSpeakerLayout();
      const rows = document.getElementById("rows");
      rows.innerHTML = "";
      const displayRows = sortedRowsForView();
      const sourceDayBoundaries = sourceDayBoundaryMap(tasks);
      let previousSegmentId = "";
      for (const { task, originalIndex } of displayRows) {
        const segment = task?.sourceLibrarySegment;
        const segmentId = String(segment?.id || "");
        if (segmentId && segmentId !== previousSegmentId) {
          rows.appendChild(librarySegmentRow(segment));
        }
        previousSegmentId = segmentId;
        if (sourceDayBoundaries.has(originalIndex)) {
          rows.appendChild(sourceDayBoundaryRow(sourceDayBoundaries.get(originalIndex)));
        }
        const continuationLocked = isContinuationLocked(task, originalIndex);
        const tr = document.createElement("tr");
        tr.dataset.index = String(originalIndex);
        tr.className = [task.skip ? "skipped" : "", task.timeOverEnd ? "time-over-end" : "", continuationLocked ? "continuation-locked" : ""].filter(Boolean).join(" ");
        tr.innerHTML = [
          cell(rowCheckbox(originalIndex)),
          execCell(originalIndex, task),
          cell(select("role", task.role, [["tuo", "托"], ["douma", "豆妈"]])),
          speakerCell(task, originalIndex),
          dateCell(originalIndex, task),
          timeCell(originalIndex, task),
          cell(select("type", task.type, [["text", "文字"], ["finder", "视频号"], ["image", "图片"], ["sticker", "表情包"], ["video", "视频"], ["unknown-media", "待确认素材"]])),
          contentCell(task),
          skipCell(task)
        ].join("");
        rows.appendChild(tr);
        if (scheduleContinuation) applyContinuationRowLock(tr, continuationLocked);
      }
      updateViewControls();
      refreshMediaStatuses();
      const errors = validateClient(tasks);
      markInvalidRows(errors);
      updateErrorLocatorButton(errors);
      markRepairProblemRow();
      updateRecommendedScheduleSummary();
      updateMediaRecoverySummary();
      updateCrossDayNotice();
    }

    function sourceDayBoundaryRow(label) {
      const row = document.createElement("tr");
      row.className = "source-day-boundary-row";
      const cell = document.createElement("td");
      cell.colSpan = 9;
      cell.textContent = "原文从这里进入 " + label;
      row.appendChild(cell);
      return row;
    }

    function sourceDayBoundaryMap(items) {
      const boundaries = new Map();
      let previous = null;
      for (let index = 0; index < items.length; index += 1) {
        const info = sourceDayInfo(items[index]);
        if (previous?.scope !== info.scope) previous = null;
        if (previous?.segment !== undefined && info.segment !== undefined && previous.segment !== info.segment) {
          boundaries.set(index, info.label);
        }
        previous = info;
      }
      return boundaries;
    }

    function sourceDayInfo(task) {
      const hasHeadingMarker = Object.prototype.hasOwnProperty.call(task || {}, "sourceDayHeadingSegment");
      const segment = hasHeadingMarker
        ? Number(task?.sourceDayHeadingSegment || 0)
        : String(task?.daySegment || "").trim() || undefined;
      const label = String(task?.sourceDayHeadingLabel || "").trim()
        || (!hasHeadingMarker && segment !== undefined ? "第 " + segment + " 个日期标题段" : "");
      return { segment, label, scope: String(task?.sourceLibrarySegment?.id || "") };
    }

    function updateCrossDayNotice() {
      const notice = document.getElementById("crossDayNotice");
      const text = document.getElementById("crossDayNoticeText");
      const labels = [...new Set(sourceDayBoundaryMap(tasks).values())];
      text.textContent = labels.length
        ? "原文检测到日期标题切换：" + labels.join("、") + "。提醒不改变已保存的发送安排，也不阻止确认创建。"
        : "";
      notice.hidden = labels.length === 0;
    }

    function librarySegmentRow(segment = {}) {
      const row = document.createElement("tr");
      row.className = "library-segment-row";
      row.dataset.librarySegmentId = String(segment.id || "");
      const cell = document.createElement("td");
      cell.colSpan = 9;
      const index = Number(segment.index || 0);
      const total = Number(segment.total || 0);
      const count = Number(segment.taskCount || 0);
      cell.innerHTML = "<div class='library-segment-banner'><strong>文案段 " + escapeHtmlJs(index || "-") + "｜" + escapeHtmlJs(segment.name || "未命名文案") + "</strong><span>第 " + escapeHtmlJs(index || "-") + " / " + escapeHtmlJs(total || "-") + " 段 · " + escapeHtmlJs(count) + " 条</span></div>";
      row.appendChild(cell);
      return row;
    }

    function taskIdentity(task) {
      return String(task?.submitIdentity || "");
    }

    function isContinuationLocked(task, originalIndex) {
      if (!scheduleContinuation) return false;
      const displayIndex = Number(task?.index || task?.order || originalIndex + 1);
      return succeededTaskKeys.has(taskIdentity(task)) || (resumeFromIndex > 0 && displayIndex < resumeFromIndex);
    }

    function applyContinuationRowLock(row, locked) {
      if (locked) {
        row.querySelectorAll("input, select, textarea, button").forEach((node) => { node.disabled = true; });
        const indexCell = row.querySelector(".index-cell");
        if (indexCell && !indexCell.querySelector(".continuation-lock-badge")) {
          indexCell.insertAdjacentHTML("beforeend", "<span class='continuation-lock-badge'>已创建并锁定</span>");
        }
        row.title = "已成功创建，不参与剩余排程修改";
        return;
      }
      row.querySelectorAll("[data-field]").forEach((node) => {
        const field = node.getAttribute("data-field");
        if (field !== "date" && field !== "time") node.disabled = true;
      });
      row.querySelectorAll("button, input[type='file']").forEach((node) => { node.disabled = true; });
      row.title = "续排模式：只允许修改未执行任务的日期和时间";
    }

    function markRepairProblemRow() {
      if (!previewRepairProblem) return;
      const index = Number(previewRepairProblem.index);
      const row = document.querySelector("tr[data-index='" + index + "']");
      if (!row) return;
      row.classList.add("invalid", "repair-focus");
      if (!row.querySelector("[data-repair-note='1']")) {
        const note = document.createElement("div");
        note.className = "row-note error";
        note.dataset.repairNote = "1";
        note.textContent = previewRepairProblem.message || ("第 " + (index + 1) + " 条素材需要重新上传");
        row.querySelector("td:last-child")?.appendChild(note);
      }
    }

    function focusInitialRepairProblem() {
      if (!previewRepairProblem || previewRepairFocused) return;
      previewRepairFocused = true;
      setTimeout(() => {
        const row = document.querySelector("tr[data-index='" + Number(previewRepairProblem.index) + "']");
        if (!row) return;
        row.scrollIntoView({ block: "center", behavior: "smooth" });
        if (previewRepairProblem.mode === "task-error") {
          focusInvalidControl(row, tasks[Number(previewRepairProblem.index)], previewRepairProblem.message);
          setStatus((previewRepairProblem.message || "当前条创建失败") + "。请修改并保存，确认无误后返回控制台继续创建。", true);
          return;
        }
        const button = row.querySelector("button[data-action='choose-media']");
        if (button) button.focus();
        setStatus((previewRepairProblem.message || "素材无法上传共享") + "。请在标红行点击更换素材，或直接拖拽/粘贴素材到这一行。", true);
      }, 250);
    }

    function focusInitialInvalidProblem() {
      if (previewRepairProblem || previewInitialInvalidFocused) return;
      const errors = validateClient(tasks);
      if (!errors.length) return;
      markInvalidRows(errors);
      updateErrorLocatorButton(errors);
      previewInitialInvalidFocused = true;
      setTimeout(() => {
        const first = errors[0];
        const row = document.querySelector("tr[data-index='" + Number(first.index) + "']");
        if (!row) return;
        row.classList.add("repair-focus");
        row.scrollIntoView({ block: "center", behavior: "smooth" });
        focusInvalidControl(row, tasks[first.index], first.message);
        setStatus("当前有 " + errors.length + " 条内容需要处理。" + first.message + "。修改会保存为草稿，全部解决后才能确认并进入创建。", true);
      }, 250);
    }

    function mediaRecoverySourceIds(items = tasks, states = ["recovering"]) {
      const allowed = new Set(states);
      return [...new Set(items.filter((task) => !task.skip && String(task.mediaOrigin || "") !== "manual" && allowed.has(String(task?.mediaRecoveryState || "")))
        .flatMap((task) => String(task?.sourceId || "").split(","))
        .map((item) => item.trim()).filter(Boolean))];
    }

    function isMediaRecoveryPending(task) {
      return !task.skip && ["recovering", "waiting"].includes(String(task?.mediaRecoveryState || "")) && !String(task?.mediaPath || "").trim();
    }

    async function startAutomaticMediaRecovery(options = {}) {
      if (mediaRecoveryApplying) return;
      collect();
      const states = options.restart === true ? ["recovering", "waiting", "failed"] : ["recovering"];
      const sourceIds = mediaRecoverySourceIds(tasks, states);
      if (!sourceIds.length) {
        updateMediaRecoverySummary();
        return;
      }
      if (options.restart === true) {
        for (const task of tasks) {
          if (!["failed", "waiting"].includes(String(task.mediaRecoveryState || "")) || String(task.mediaOrigin || "") === "manual" || task.skip) continue;
          task.mediaRecoveryState = "recovering";
          task.mediaRecoveryMessage = "正在重新获取素材";
          delete task.previewError;
        }
        mediaRecoveryProgress = { status: "running", completed: 0, total: sourceIds.length, reason: "正在重新获取素材" };
        render();
      }
      const started = await postJson("/api/media-recovery", {
        sourceIds,
        restart: options.restart === true
      }).catch((error) => ({ ok: false, error: error?.message || String(error) }));
      if (!started.ok) {
        finalizePendingMediaRecovery(started.error || "当前后台无法继续自动获取素材，请手动补充或重新生成预览。", true);
        return;
      }
      mediaRecoveryProgress = started;
      updateMediaRecoverySummary(started);
      pollMediaRecovery();
    }

    async function pollMediaRecovery() {
      if (mediaRecoveryPollTimer) clearTimeout(mediaRecoveryPollTimer);
      const state = await getJson("/api/media-recovery").catch((error) => ({
        ok: false,
        status: "failed",
        error: error?.message || String(error)
      }));
      mediaRecoveryProgress = state;
      if (state.ok) applyMediaRecoveryUpdates(state.updates || [], state.reason || "", true);
      updateMediaRecoverySummary(state);
      if (state.ok && state.status === "running") {
        mediaRecoveryPollTimer = setTimeout(pollMediaRecovery, 700);
        return;
      }
      mediaRecoveryPollTimer = null;
      if (state.ok && ["complete", "waiting"].includes(state.status)) {
        applyMediaRecoveryUpdates(state.updates || [], state.reason || "素材自动补齐已完成");
        return;
      }
      finalizePendingMediaRecovery(state.error || state.reason || "素材自动恢复暂未完成，请手动补充或稍后重试。", false);
    }

    function applyMediaRecoveryUpdates(updates, message, partial = false) {
      if (mediaRecoveryApplying) return;
      mediaRecoveryApplying = true;
      collect();
      const bySource = new Map((Array.isArray(updates) ? updates : [])
        .map((item) => [String(item?.sourceId || ""), item]).filter(([sourceId]) => sourceId));
      let recovered = 0;
      let failed = 0;
      let waiting = 0;
      let deferred = false;
      const changed = [];
      for (const task of tasks) {
        const update = String(task.sourceId || "").split(",").map((item) => bySource.get(item.trim())).find(Boolean);
        if (!update || String(task.mediaOrigin || "") === "manual" || String(task.mediaRecoveryState || "") === "manual") continue;
        if (String(task.mediaPath || "").trim() && String(task.mediaRecoveryState || "") !== "recovering") continue;
        const row = document.querySelector('tr[data-index="' + tasks.indexOf(task) + '"]');
        if (row?.querySelector(".media-box")?.contains(document.activeElement) || document.activeElement === row?.querySelector('[data-field="type"]')) {
          deferred = true;
          mediaRecoveryDeferred.set(update.sourceId, update);
          continue;
        }
        if (task.mediaRecoveryState === update.status && task.mediaRecoveryMessage === update.message) continue;
        changed.push(task);
        if (update.status === "downloaded" && String(update.mediaPath || "").trim()) {
          task.mediaPath = String(update.mediaPath);
          if (["image", "sticker", "video"].includes(String(update.type || ""))) task.type = String(update.type);
          task.mediaOrigin = "automatic";
          task.mediaRecoveryState = "auto_recovered";
          task.mediaRecoveryMessage = "已自动补齐";
          delete task.mediaRetryAfterMs;
          delete task.previewError;
          recovered += 1;
          continue;
        }
        if (update.status === "waiting" || update.status === "recovering") {
          task.mediaRecoveryState = "waiting";
          task.mediaRecoveryMessage = String(update.message || "已保留进度，可继续获取剩余素材");
          delete task.previewError;
          waiting += 1;
          continue;
        }
        task.mediaRecoveryState = "failed";
        task.mediaRecoveryMessage = String(update.message || "自动恢复后仍未取得素材");
        task.previewError = "飞书素材自动恢复失败：" + task.mediaRecoveryMessage + "。请手动补充素材或设为不发。";
        failed += 1;
      }
      mediaRecoveryApplying = false;
      if (deferred && !mediaRecoveryDeferredTimer) mediaRecoveryDeferredTimer = setTimeout(() => {
        mediaRecoveryDeferredTimer = null;
        const queued = [...mediaRecoveryDeferred.values()];
        mediaRecoveryDeferred.clear();
        applyMediaRecoveryUpdates(queued, "", true);
      }, 700);
      if (!partial) mediaRecoveryProgress = { ...mediaRecoveryProgress, reason: message };
      // Do not rebuild rows while the user edits speaker, text or time fields.
      for (const task of changed) {
        const row = document.querySelector('tr[data-index="' + tasks.indexOf(task) + '"]');
        const box = row?.querySelector(".media-box");
        if (box) box.outerHTML = mediaCell(task);
        const type = row?.querySelector('[data-field="type"]');
        if (type) type.value = task.type;
      }
      updateMediaRecoverySummary();
      if (changed.length) {
        refreshMediaStatuses();
        const errors = validateClient(tasks);
        markInvalidRows(errors);
        updateErrorLocatorButton(errors);
        markDirty(waiting ? "素材进度已保留，可继续获取剩余素材；正在保存草稿" : "素材进度已更新，正在自动保存预览内容");
        if (failed > 0) focusFirstActionableMediaErrorWhenIdle();
      }
    }

    function finalizePendingMediaRecovery(message, unavailable) {
      collect();
      const pending = tasks.filter((task) => isMediaRecoveryPending(task) && String(task.mediaOrigin || "") !== "manual");
      mediaRecoveryProgress = { status: "waiting", completed: 0, total: pending.length, reason: message, unavailable };
      const updates = pending.flatMap((task) => String(task.sourceId || "").split(",")
        .map((sourceId) => ({ sourceId: sourceId.trim(), status: "waiting", message: String(message || "素材自动恢复暂未完成") })));
      applyMediaRecoveryUpdates(updates, message, true);
    }

    function focusFirstActionableMediaErrorWhenIdle() {
      const active = document.activeElement;
      if (active?.closest?.("tr[data-index]")) {
        setStatus("素材自动恢复已结束，仍有需要处理的条目。点击“定位到错误处”逐条处理。", true);
        return;
      }
      previewInitialInvalidFocused = false;
      focusInitialInvalidProblem();
    }

    function updateMediaRecoverySummary(progress = mediaRecoveryProgress) {
      const summary = document.getElementById("mediaRecoverySummary");
      const retry = document.getElementById("retryMediaBtn");
      const confirm = document.getElementById("confirmBtn");
      if (!summary || !retry || !confirm) return;
      const pending = tasks.filter(isMediaRecoveryPending).length;
      const recovered = tasks.filter((task) => String(task?.mediaRecoveryState || "") === "auto_recovered").length;
      const manual = tasks.filter((task) => String(task?.mediaRecoveryState || "") === "manual").length;
      const failed = tasks.filter((task) => !task.skip && String(task?.mediaRecoveryState || "") === "failed").length;
      summary.className = "summary-pill";
      if (pending > 0) {
        const completed = Math.max(0, Number(progress?.completed || 0));
        const total = Math.max(pending, Number(progress?.total || pending));
        summary.hidden = false;
        summary.classList.add("media-recovering");
        summary.textContent = String(progress?.reason || "系统正在自动补齐素材") + "（" + Math.min(completed, total) + "/" + total + "）";
        retry.hidden = progress?.status === "running" || !tasks.some((task) => isMediaRecoveryPending(task) && task.mediaRecoveryState === "waiting");
        retry.textContent = "继续获取剩余素材（" + pending + "）";
        if (!confirm.disabled) {
          confirm.disabled = true;
          confirm.dataset.mediaRecoveryDisabled = "1";
        }
        return;
      }
      if (confirm.dataset.mediaRecoveryDisabled === "1") {
        confirm.disabled = false;
        delete confirm.dataset.mediaRecoveryDisabled;
      }
      if (failed > 0) {
        summary.hidden = false;
        summary.classList.add("media-failed");
        summary.textContent = "仍有 " + failed + " 项素材需要处理";
        retry.hidden = false;
        retry.textContent = "重新获取缺失素材（" + failed + "）";
        return;
      }
      retry.hidden = true;
      if (recovered > 0 || manual > 0) {
        summary.hidden = false;
        summary.classList.add("media-recovered");
        summary.textContent = [recovered ? "自动补齐 " + recovered + " 项" : "", manual ? "手动补充 " + manual + " 项" : ""].filter(Boolean).join("，");
        return;
      }
      summary.hidden = true;
      summary.textContent = "";
    }

    function locateFirstInvalidProblem() {
      collect();
      const errors = validateClient(tasks);
      markInvalidRows(errors);
      updateErrorLocatorButton(errors);
      if (!errors.length) {
        setStatus("当前没有需要定位的错误。");
        return;
      }
      const first = errors[0];
      const row = document.querySelector("tr[data-index='" + Number(first.index) + "']");
      if (!row) {
        setStatus(first.message + "。当前视图中没有找到对应任务。", true);
        return;
      }
      row.classList.add("invalid", "repair-focus");
      row.scrollIntoView({ block: "center", behavior: "smooth" });
      focusInvalidControl(row, tasks[first.index], first.message);
      setStatus(first.message + "。已定位到第 " + (Number(first.index) + 1) + " 条。", true);
    }

    function focusInvalidControl(row, task, message) {
      const text = String(message || "");
      let target = null;
      if (/日期/.test(text)) target = row.querySelector("[data-field='date']");
      else if (/时间/.test(text)) target = row.querySelector("[data-field='time']");
      else if (/角色/.test(text)) target = row.querySelector("[data-field='role']");
      else if (/正文|视频号/.test(text)) target = row.querySelector("[data-field='text']:not([hidden])");
      if (!target && !isTextLikeType(task?.type)) target = row.querySelector("button[data-action='choose-media']");
      if (!target) target = row.querySelector("input:not([type='hidden']), select, textarea:not([hidden]), button");
      target?.focus?.();
    }

    function updateErrorLocatorButton(errors = validateClient(tasks)) {
      const button = document.getElementById("locateErrorBtn");
      if (!button) return;
      button.hidden = !errors.length;
      button.title = errors.length ? errors[0].message : "";
    }

    function updateSpeakerLayout() {
      const precise = tasks.some((task) => isPreciseTuoTask(task));
      document.getElementById("speakerHeader").textContent = precise ? "人设 / 托号昵称 / 备选托" : "说话人";
      document.getElementById("previewTable").classList.toggle("precise-tuo-table", precise);
    }

    function normalizeTasksForCurrentRun(items) {
      const fallback = normalizePreviewDate(defaultDate || "");
      return (Array.isArray(items) ? items : []).map((task) => {
        const next = { ...task };
        next.date = normalizePreviewDate(String(next.date || "").trim() || fallback);
        return normalizeTaskForCurrentRobotStrategy(next);
      });
    }

    function normalizeTasksForCurrentRobotStrategy(items) {
      return (Array.isArray(items) ? items : []).map((task) => normalizeTaskForCurrentRobotStrategy(task));
    }

    function normalizeTaskForCurrentRobotStrategy(task) {
      if (preciseTuoEnabled || !task || typeof task !== "object") return task;
      if (task.role !== "tuo" || !task.tuoAssignment) return task;
      const next = { ...task };
      delete next.tuoAssignment;
      return next;
    }

    function clearLegacyPreviewStorage() {
      try {
        const keys = [];
        for (let index = 0; index < localStorage.length; index += 1) {
          const key = localStorage.key(index) || "";
          if (/^(v2-preview|preview-page|preview-state)/i.test(key)) keys.push(key);
        }
        for (const key of keys) localStorage.removeItem(key);
      } catch {}
    }

    document.addEventListener("input", (event) => {
      const row = event.target.closest && event.target.closest("tr[data-index]");
      if (!row || !event.target.dataset.field) return;
      updateTaskFromRow(row);
      if (event.target.dataset.field === "speaker" && row.querySelector("[data-persona-filter='1']")) {
        refreshPreciseTuoDatalist(row);
      }
      updateTextDetailForRow(row);
      clearRowError(row);
      updateRecommendedScheduleSummary();
      markDirty();
    });
    document.addEventListener("change", async (event) => {
      const row = event.target.closest && event.target.closest("tr[data-index]");
      if (!row) return;
      if (event.target.dataset.selectRow === "1") {
        const index = Number(row.dataset.index);
        if (event.target.checked) selectedRows.add(index);
        else selectedRows.delete(index);
        updateViewControls();
        return;
      }
      if (event.target.dataset.uploadFor === "mediaPath") {
        await uploadReplacement(row, event.target.files && event.target.files[0]);
        return;
      }
      if (event.target.dataset.personaFilter === "1") {
        refreshPreciseTuoDatalist(row);
        updateTaskFromRow(row);
        markDirty("已修改精准托人设筛选，正在自动保存预览内容");
        return;
      }
      if (event.target.dataset.candidateSelect === "1") {
        const value = event.target.value || "";
        if (value) {
          event.target.value = "";
          applyPreciseCandidateChoice(row, value, "已切换备选托");
        }
        return;
      }
      if (event.target.dataset.field) {
        updateTaskFromRow(row);
        markDirty();
        if (event.target.dataset.field === "role" || event.target.dataset.field === "type" || event.target.dataset.field === "skip") render();
      }
    });
    document.addEventListener("pointerdown", (event) => {
      const checkbox = event.target.closest && event.target.closest("input[data-select-row='1']");
      if (!checkbox || event.button !== 0) return;
      const row = checkbox.closest("tr[data-index]");
      if (!row) return;
      event.preventDefault();
      rowSelectDrag = { checked: !checkbox.checked, seen: new Set() };
      document.body.classList.add("row-select-dragging");
      applyRowSelectionDrag(row);
      suppressRowSelectClickUntil = Date.now() + 600;
    }, true);
    document.addEventListener("pointermove", (event) => {
      if (!rowSelectDrag) return;
      const node = document.elementFromPoint(event.clientX, event.clientY);
      const row = node?.closest?.("tr[data-index]");
      if (row) applyRowSelectionDrag(row);
    }, true);
    document.addEventListener("pointerup", () => finishRowSelectionDrag(), true);
    document.addEventListener("pointercancel", () => finishRowSelectionDrag(), true);
    document.addEventListener("click", (event) => {
      const checkbox = event.target.closest && event.target.closest("input[data-select-row='1']");
      if (!checkbox || Date.now() > suppressRowSelectClickUntil) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
    document.addEventListener("click", (event) => {
      const thumb = event.target.closest && event.target.closest("[data-media-popover-src]");
      if (thumb) {
        event.preventDefault();
        toggleMediaPopover(thumb);
        return;
      }
      if (mediaPopoverTarget && !event.target.closest?.("#mediaPopover")) {
        hideMediaPopover();
      }
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        hideMediaPopover();
        closeContentDetailModal();
      }
    });
    window.addEventListener("scroll", () => hideMediaPopover(), true);

    document.addEventListener("click", (event) => {
      const button = event.target.closest && event.target.closest("button[data-action],button[data-candidate-pick]");
      if (!button) return;
      const row = button.closest("tr[data-index]");
      if (!row) return;
      if (button.dataset.candidatePick) {
        applyPreciseCandidateChoice(row, button.dataset.candidatePick, "已切换推荐备选托");
        return;
      }
      if (button.dataset.action === "choose-media") {
        const fileInput = row.querySelector("input[type='file'][data-upload-for='mediaPath']");
        if (fileInput) fileInput.click();
      }
      if (button.dataset.action === "confirm-recovered-media") {
        updateTaskFromRow(row);
        const index = Number(row.dataset.index);
        const task = tasks[index];
        if (!task?.recoveryRequired) return;
        if (task.speakerStatus === "unconfirmed" && (!String(task.speaker || "").trim() || task.speaker === "说话人待确认")) {
          setStatus("请先在本行填写并核对说话人，再确认本行内容及归属。", true);
          return;
        }
        if (!isTextLikeType(task.type) && !String(task.mediaPath || "").trim()) {
          setStatus("请先补充本行素材，再确认本行内容及归属。", true);
          return;
        }
        pushUndoSnapshot("确认系统恢复内容");
        delete task.previewError;
        delete task.invalidReason;
        delete task.recoveryRequired;
        task.speakerStatus = "confirmed";
        task.suggestedSpeaker = "";
        task.importResolutionConfirmed = true;
        task.repairsSourceIds = Array.from(new Set([
          ...String(task.repairsSourceIds || "").split(","),
          ...String(task.sourceId || "").split(",")
        ].map((value) => value.trim()).filter(Boolean))).join(",");
        task.previewWarning = "此条内容及归属已由用户在预览页人工确认。";
        render();
        markDirty("已确认本行内容及归属，正在保存预览草稿");
      }
      if (button.dataset.action === "view-text-detail") {
        updateTaskFromRow(row);
        showContentDetailModal(tasks[Number(row.dataset.index)] || readTaskFromRow(row, {}), row.dataset.index);
      }
      if (button.dataset.action === "mark-skip") {
        updateTaskFromRow(row);
        pushUndoSnapshot("单行设为不发");
        tasks[Number(row.dataset.index)].skip = true;
        render();
        markDirty("已设为不发，正在自动保存预览内容");
      }
    });
    document.addEventListener("dragover", (event) => {
      const target = mediaDropTargetFromEvent(event);
      if (!target) return;
      event.preventDefault();
      target.classList.add("drag-over");
    });
    document.addEventListener("dragleave", (event) => {
      const target = event.target.closest && event.target.closest(".media-drop-zone,.manualBatchContent,[data-manual-batch-drop-zone]");
      if (target) target.classList.remove("drag-over");
    });
    document.addEventListener("drop", async (event) => {
      const target = mediaDropTargetFromEvent(event);
      if (!target) return;
      event.preventDefault();
      target.classList.remove("drag-over");
      const file = firstUsableFile(event.dataTransfer?.files);
      if (!file) return setStatus("没有识别到可上传的素材文件", true);
      await handleDroppedOrPastedMedia(target, file);
    });
    document.addEventListener("paste", async (event) => {
      const file = firstUsableFile(Array.from(event.clipboardData?.files || []));
      if (!file) return;
      const target = mediaPasteTargetFromEvent(event);
      if (!target) return;
      event.preventDefault();
      await handleDroppedOrPastedMedia(target, file);
    });

    function mediaDropTargetFromEvent(event) {
      const target = event.target.closest && event.target.closest("[data-media-drop-zone],#manualMediaDropZone,.manualBatchContent,[data-manual-batch-drop-zone]");
      if (!target) return null;
      if (target.hasAttribute?.("data-manual-batch-drop-zone")) return target;
      if (target.classList?.contains("manualBatchContent")) return target;
      return target.closest?.(".media-drop-zone") || target;
    }

    function mediaPasteTargetFromEvent(event) {
      const row = event.target.closest && event.target.closest("tr[data-index]");
      if (row && !isTextLikeType(tasks[Number(row.dataset.index)]?.type)) return row.querySelector("[data-media-drop-zone]");
      const manualModal = document.getElementById("manualModal");
      if (manualModal?.classList.contains("open") && !document.getElementById("manualMediaWrap")?.hidden) return document.getElementById("manualMediaDropZone");
      const batchRow = event.target.closest && event.target.closest("#manualBatchRows tr");
      if (batchRow && !isTextLikeType(batchRow.querySelector(".manualBatchType")?.value)) {
        return batchRow.querySelector("[data-manual-batch-drop-zone]") || batchRow.querySelector(".manualBatchContent");
      }
      return null;
    }

    function firstUsableFile(files) {
      return Array.from(files || []).find((file) => file && file.size > 0) || null;
    }

    async function handleDroppedOrPastedMedia(target, file) {
      if (target.id === "manualMediaDropZone" || target.closest?.("#manualMediaDropZone")) {
        await setManualModalMediaFile(file);
        return;
      }
      if (target.classList?.contains("manualBatchContent") || target.hasAttribute?.("data-manual-batch-drop-zone")) {
        await setManualBatchMediaFile(target.closest("tr"), file);
        return;
      }
      const row = target.closest?.("tr[data-index]");
      if (row) {
        await uploadReplacement(row, file);
      }
    }

    ${inheritManualDaySegments.toString()}
    ${clearResolvedFinderError.toString()}

    function collect() {
      const nextTasks = tasks.map((task) => ({ ...task }));
      for (const row of Array.from(document.querySelectorAll("tbody tr"))) {
        const originalIndex = Number(row.dataset.index);
        if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= nextTasks.length) continue;
        if (isContinuationLocked(nextTasks[originalIndex], originalIndex)) continue;
        nextTasks[originalIndex] = readTaskFromRow(row, nextTasks[originalIndex]);
      }
      tasks = normalizeTasksForCurrentRobotStrategy(nextTasks);
    }

    function readTaskFromRow(row, baseTask) {
      const task = { ...baseTask };
      const previousType = String(baseTask?.type || "");
      const previousMediaPath = String(baseTask?.mediaPath || "");
      const previousDate = String(baseTask?.date || "");
      const previousTime = String(baseTask?.time || "");
      for (const field of fields) {
        const el = row.querySelector("[data-field='" + field + "']");
        if (!el) continue;
      if (field === "skip") task[field] = el.checked;
      else if (field === "continueMarker" || field === "importResolutionConfirmed") task[field] = el.checked;
      else if (field === "order") task[field] = Number(el.value);
      else task[field] = el.value;
      }
      clearResolvedFinderError(task);
      if (String(task.type || "") !== previousType || String(task.mediaPath || "") !== previousMediaPath || task.skip) {
        delete task.previewError;
      }
      if (String(task.mediaPath || "").trim() && String(task.mediaPath || "") !== previousMediaPath) {
        task.mediaOrigin = "manual";
        task.mediaRecoveryState = "manual";
        task.mediaRecoveryMessage = "已手动补充";
        delete task.mediaRetryAfterMs;
      }
      task.time = normalizeClockInputOrTrim(task.time);
      if (String(task.date || "") !== previousDate || String(task.time || "") !== previousTime || task.skip) {
        delete task.timeOverEnd;
        delete task.timeWarning;
      }
      const persona = row.querySelector("[data-persona-filter='1']");
      if (task.role !== "tuo" && task.tuoAssignment) {
        delete task.tuoAssignment;
      }
      if (persona && task.role === "tuo" && task.tuoAssignment && typeof task.tuoAssignment === "object") {
        task.cleanSpeaker = String(task.speaker || "").replace(/\s+/g, "");
        const speakerChanged = normalizeTuoKey(task.speaker) !== normalizeTuoKey(baseTask?.speaker || "");
        const selected = speakerChanged
          ? allPreciseTuoOptions(baseTask).find((item) => normalizeTuoKey(item?.nickname || "") === normalizeTuoKey(task.speaker))
          : null;
        task.tuoAssignment = {
          ...task.tuoAssignment,
          selectedPersona: persona.value || "all",
          ...(speakerChanged ? {
            manualLocked: true,
            selectionSource: "manual",
            ...(selected ? { primary: selected } : {})
          } : {})
        };
      }
      return task;
    }

    function updateTaskFromRow(row) {
      const originalIndex = Number(row.dataset.index);
      if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= tasks.length) return;
      tasks[originalIndex] = readTaskFromRow(row, tasks[originalIndex]);
    }

    function updateTextDetailForRow(row) {
      const originalIndex = Number(row.dataset.index);
      if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= tasks.length) return;
      const task = tasks[originalIndex];
      const button = row.querySelector("button[data-action='view-text-detail']");
      if (button) button.textContent = textDetailButtonLabel(task);
      const modal = document.getElementById("contentDetailModal");
      if (!modal?.classList.contains("open") || modal.dataset.taskIndex !== String(originalIndex)) return;
      const text = document.getElementById("contentDetailText");
      const meta = document.getElementById("contentDetailMeta");
      if (text) text.value = task.text || "";
      if (meta) meta.textContent = contentDetailLabel(task);
    }

    function applyPreciseCandidateChoice(row, candidateIdentity, message) {
      const originalIndex = Number(row.dataset.index);
      if (!Number.isInteger(originalIndex) || originalIndex < 0 || originalIndex >= tasks.length) return;
      const selectedCandidate = allPreciseTuoOptions(tasks[originalIndex])
        .find((item) => preciseCandidateIdentity(item) === String(candidateIdentity || ""));
      const nickname = String(selectedCandidate?.nickname || candidateIdentity || "").trim();
      const input = row.querySelector("[data-field='speaker']");
      if (input) input.value = nickname;
      updateTaskFromRow(row);
      pushUndoSnapshot("切换推荐备选托");
      const persona = firstPersonaLabel(selectedCandidate)
        || row.querySelector("[data-persona-filter='1']")?.value
        || selectedPersonaForTask(tasks[originalIndex]);
      const groupKey = precisePreviewGroupKey(tasks[originalIndex]);
      let synced = 0;
      tasks[originalIndex] = withPreciseSpeaker(tasks[originalIndex], nickname, persona, selectedCandidate, true);
      if (groupKey) {
        for (let index = 0; index < tasks.length; index += 1) {
          if (index === originalIndex) continue;
          if (!isPreciseTuoTask(tasks[index])) continue;
          if (precisePreviewGroupKey(tasks[index]) !== groupKey) continue;
          tasks[index] = withPreciseSpeaker(tasks[index], nickname, persona, selectedCandidate, true);
          synced += 1;
        }
      }
      render();
      const suffix = synced ? "，并同步 " + (synced + 1) + " 条同组托词" : "";
      markDirty(message + suffix + "，正在自动保存预览内容");
    }

    function withPreciseSpeaker(task, nickname, persona, selectedCandidate = null, manualLocked = false) {
      const next = {
        ...task,
        speaker: nickname,
        cleanSpeaker: String(nickname || "").replace(/\s+/g, "")
      };
      if (next.tuoAssignment && typeof next.tuoAssignment === "object") {
        next.tuoAssignment = {
          ...next.tuoAssignment,
          selectedPersona: persona || next.tuoAssignment.selectedPersona || "all",
          ...(selectedCandidate ? { primary: selectedCandidate } : {}),
          ...(manualLocked ? { manualLocked: true, selectionSource: "manual" } : {})
        };
      }
      return next;
    }

    function precisePreviewGroupKey(task = {}) {
      const saved = String(task?.tuoAssignment?.groupKey || "").trim();
      if (saved) return saved;
      const sourceSpeaker = normalizeTuoKey(task.sourceSpeaker || "");
      if (sourceSpeaker && !isGenericTuoKey(sourceSpeaker)) return "speaker:" + sourceSpeaker;
      const speaker = normalizeTuoKey(task.cleanSpeaker || task.speaker || "");
      if (speaker && !isGenericTuoKey(speaker)) return "speaker:" + speaker;
      const interactionGroup = String(task.interactionGroup || "").trim();
      return interactionGroup ? "interaction:" + normalizeTuoKey(interactionGroup) : "";
    }

    function isGenericTuoKey(value) {
      return ["托", "托号", "托儿", "水军", "互动托"].includes(normalizeTuoKey(value));
    }

    function sortedRowsForView() {
      const rows = tasks.map((task, originalIndex) => ({ task, originalIndex }));
      const sorted = viewMode !== "time" ? rows : [...rows].sort((a, b) => {
        const left = timeSortKey(a.task);
        const right = timeSortKey(b.task);
        if (left !== right) return left - right;
        return a.originalIndex - b.originalIndex;
      });
      return hideSkippedRows ? sorted.filter((row) => !row.task.skip) : sorted;
    }

    function selectedIndexes() {
      return Array.from(selectedRows).filter((index) => index >= 0 && index < tasks.length && !isContinuationLocked(tasks[index], index));
    }

    function cloneTasks(items) {
      return JSON.parse(JSON.stringify(items || []));
    }

    function replaceOriginalTimes(snapshot) {
      originalTimes.splice(0, originalTimes.length, ...cloneTasks(snapshot));
    }

    function pushUndoSnapshot(label) {
      undoStack.push({
        label,
        tasks: cloneTasks(tasks),
        originalTimes: cloneTasks(originalTimes),
        selectedRows: Array.from(selectedRows)
      });
      if (undoStack.length > 20) undoStack.shift();
      updateUndoButtons();
    }

    function undoLastChange() {
      const snapshot = undoStack.pop();
      if (!snapshot) return setStatus("没有可撤回的修改", true);
      tasks = cloneTasks(snapshot.tasks);
      replaceOriginalTimes(snapshot.originalTimes);
      selectedRows = new Set(snapshot.selectedRows || []);
      render();
      markDirty("已撤回上一步：" + snapshot.label + "，正在自动保存预览内容");
      updateUndoButtons();
    }

    function restoreOpenState() {
      collect();
      pushUndoSnapshot("恢复打开时状态前");
      tasks = cloneTasks(initialTasksSnapshot);
      replaceOriginalTimes(initialOriginalTimesSnapshot);
      selectedRows = new Set();
      viewMode = "execution";
      render();
      markDirty("已恢复打开时状态，正在自动保存预览内容");
    }

    function updateUndoButtons() {
      const undo = document.getElementById("undoBtn");
      const restore = document.getElementById("restoreOpenStateBtn");
      if (undo) {
        undo.disabled = !undoStack.length;
        undo.textContent = undoStack.length ? "撤回上一步" : "撤回上一步";
      }
      if (restore) restore.disabled = !initialTasksSnapshot.length;
    }

    function applyBatchDate() {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改日期的行，或点全选", true);
      const value = selectedBatchDate();
      if (!value) return setStatus("请先选择或填写批量日期", true);
      if (!validDate(value)) return setStatus("批量日期格式不合法", true);
      pushUndoSnapshot("批量修改日期");
      for (const index of indexes) tasks[index].date = value;
      render();
      markDirty("已批量修改日期，正在自动保存预览内容");
    }

    function shiftSelectedTimes(direction) {
      collect();
      const amount = Math.abs(Number(document.getElementById("batchMinutes").value || 0));
      if (!amount) return setStatus("请填写时间偏移数值", true);
      const unit = document.getElementById("batchTimeUnit").value || "minute";
      const seconds = amount * batchTimeUnitSeconds(unit);
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改时间的行，或点全选，再应用", true);
      pushUndoSnapshot(direction > 0 ? "批量延后时间" : "批量提前时间");
      for (const index of indexes) {
        const shifted = shiftPreviewDateTime(tasks[index].date, tasks[index].time, direction * seconds);
        tasks[index].date = shifted.date;
        tasks[index].time = shifted.time;
      }
      render();
      markDirty((direction > 0 ? "已批量延后" : "已批量提前") + amount + batchTimeUnitLabel(unit) + "，跨天日期已同步，正在自动保存预览内容");
    }

    async function applyPreviewRetime() {
      collect();
      const startMode = document.getElementById("retimeStartMode").value || "normal";
      let startTime = normalizeClockInputOrTrim(document.getElementById("retimeStartTime").value);
      const endTime = normalizeClockInputOrTrim(document.getElementById("retimeEndTime").value);
      if (startMode === "normal" && !startTime) startTime = shiftClockSeconds(currentClock(), 60);
      document.getElementById("retimeStartTime").value = startTime;
      document.getElementById("retimeEndTime").value = endTime;
      if (startMode === "reverse" && !validTime(endTime)) return setStatus("反推开始时间需要先填写有效结束时间，例如 10:30", true);
      if (startMode !== "reverse" && !validTime(startTime)) return setStatus("开始时间格式不正确；可以留空，或填写例如 19:30:00", true);
      if (endTime && !validTime(endTime)) return setStatus("重排结束时间格式不合法，可以留空", true);
      const button = document.getElementById("retimeApplyBtn");
      button.disabled = true;
      try {
        const before = cloneTasks(tasks);
        const editableIndexes = tasks.map((task, index) => ({ task, index }))
          .filter(({ task, index }) => !isContinuationLocked(task, index))
          .map(({ index }) => index);
        const editableTasks = editableIndexes.map((index) => tasks[index]);
        if (!editableTasks.length) return setStatus("没有未执行任务可以重排", true);
        const result = await postJson("/api/retime-preview", {
          tasks: editableTasks,
          startMode,
          startTime,
          endTime,
          startDate: editableTasks.find((task) => !task.skip)?.date || editableTasks[0]?.date || "",
          intervals: collectRetimeIntervals(),
          persistSettings: true
        });
        if (!result.ok) return setStatus(result.error || "重排时间失败", true);
        if (result.startEstimate?.predictedStartTime) {
          document.getElementById("retimeStartTime").value = result.startEstimate.predictedStartTime;
        }
        pushUndoSnapshot("按间隔重排时间");
        const retimed = result.tasks || editableTasks;
        editableIndexes.forEach((taskIndex, resultIndex) => { tasks[taskIndex] = retimed[resultIndex] || tasks[taskIndex]; });
        tasks = normalizeTasksForCurrentRobotStrategy(tasks);
        recommendedScheduleState = result.startEstimate
          ? recommendedScheduleStateFromEstimate(result.startEstimate)
          : null;
        render();
        const estimateText = result.startEstimate
          ? "；反推范围 " + result.startEstimate.earliestStartTime + "-" + result.startEstimate.latestStartTime + "，采用 " + result.startEstimate.predictedStartTime
          : "";
        markDirty("已按当前间隔重排时间" + estimateText + "，内容和素材未改变，正在自动保存预览内容");
      } catch (error) {
        setStatus("重排时间失败：" + (error?.message || error), true);
      } finally {
        button.disabled = false;
      }
    }

    function applyBatchRole() {
      collect();
      const role = document.getElementById("batchRole").value;
      if (!role) return setStatus("请先选择批量角色", true);
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要修改角色的行，或点全选", true);
      pushUndoSnapshot("批量修改角色");
      for (const index of indexes) {
        tasks[index].role = role;
        if (role !== "tuo") delete tasks[index].tuoAssignment;
      }
      render();
      markDirty("已批量修改角色，正在自动保存预览内容");
    }

    function setSelectedSkip(skip) {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要设为不发的行，或点全选", true);
      pushUndoSnapshot(skip ? "设为不发" : "取消不发");
      for (const index of indexes) tasks[index].skip = skip;
      render();
      markDirty(skip ? "已将选中行设为不发，正在自动保存预览内容" : "已取消选中行不发，正在自动保存预览内容");
    }

    function restoreSelectedTimes() {
      collect();
      const indexes = selectedIndexes();
      if (!indexes.length) return setStatus("请先勾选要恢复时间的行，或点全选", true);
      pushUndoSnapshot("恢复选中行时间");
      for (const index of indexes) {
        if (!originalTimes[index]) continue;
        tasks[index].date = originalTimes[index].date;
        tasks[index].time = originalTimes[index].time;
      }
      render();
      markDirty("已恢复选中行原时间，正在自动保存预览内容");
    }

    async function savePreview(options = {}) {
      if (!options.auto && autoSaveTimer) {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = null;
      }
      setStatus("正在保存...");
      collect();
      const pendingRecoveryCount = tasks.filter(isMediaRecoveryPending).length;
      if (pendingRecoveryCount > 0) {
        try {
          const draft = await postJson("/api/preview-draft", { tasks, autoSave: options.auto === true });
          if (!draft.ok) throw new Error(draft.error || "预览草稿保存失败");
          tasks = draft.tasks || tasks;
          dirty = false;
          window.__v2PreviewDirty = false;
          saveFailed = false;
          savedAt = draft.savedAt || new Date().toISOString();
          setStatus("修改已保存为草稿；系统仍在自动补齐 " + pendingRecoveryCount + " 项素材，完成后才能进入创建。");
          return { ok: false, draftSaved: true, mediaRecoveryPending: true };
        } catch (error) {
          setStatus("系统仍在自动补齐素材，而且草稿保存失败：" + (error?.message || error), true);
          saveFailed = true;
          return { ok: false, draftSaved: false, mediaRecoveryPending: true };
        }
      }
      const errors = validateClient(tasks);
      if (errors.length) {
        if (!options.auto) markInvalidRows(errors);
        updateErrorLocatorButton(errors);
        try {
          const draft = await postJson("/api/preview-draft", { tasks, autoSave: options.auto === true });
          if (!draft.ok) throw new Error(draft.error || "预览草稿保存失败");
          tasks = draft.tasks || tasks;
          dirty = false;
          window.__v2PreviewDirty = false;
          saveFailed = false;
          savedAt = draft.savedAt || new Date().toISOString();
          setStatus("修复草稿已保存；仍有 " + errors.length + " 条问题。可继续修改或稍后重新打开，全部解决后才能确认并进入创建。", true);
          return { ok: false, draftSaved: true };
        } catch (error) {
          setStatus("预览仍有 " + errors.length + " 条问题，而且草稿保存失败：" + (error?.message || error), true);
          saveFailed = true;
          return { ok: false, draftSaved: false };
        }
      }
      if (scheduleContinuation && !options.auto) {
        const overEnd = tasks.filter((task, index) => !isContinuationLocked(task, index) && task.timeOverEnd);
        if (overEnd.length) {
          setStatus("剩余排程超过你设置的结束时间，请先缩短间隔、调整时间或重新设置结束时间后再继续。", true);
          saveFailed = true;
          return { ok: false };
        }
      }
      let result;
      let libraryChoice = {};
      try {
        libraryChoice = await chooseLibrarySaveChoice(options);
        if (libraryChoice?.canceled) return { ok: false, canceled: true };
        result = await postJson("/api/preview", {
          tasks,
          autoSave: options.auto === true,
          scheduleContinuation,
          resumeFromIndex,
          ...libraryChoice
        });
      } catch (error) {
        result = { ok: false, error: error?.message || String(error) };
      }
      if (result.ok) tasks = result.tasks;
      if (result.ok) {
        dirty = false;
        window.__v2PreviewDirty = false;
        saveFailed = false;
        savedAt = result.savedAt || new Date().toISOString();
        lastSaveAdvice = result.saveAdvice || null;
        if (libraryItem && !options.auto) libraryUnsavedChanges = false;
        if (libraryItem && (libraryChoice.librarySaveMode === "overwrite" || libraryChoice.librarySaveMode === "copy")) libraryUnsavedChanges = false;
        applySaveAdvice(lastSaveAdvice);
      }
      setStatus(result.ok
        ? (options.auto ? "已自动保存预览内容：" : "已保存预览内容：") + formatTime(savedAt) + (result.recoveryWarning ? "；" + result.recoveryWarning : "")
        : "保存失败，请重试：" + (result.error || "未知原因"),
        !result.ok || Boolean(result.recoveryWarning));
      if (!result.ok) saveFailed = true;
      if (!options.auto || options.render) render();
      return result;
    }

    async function saveToLibrary() {
      const button = document.getElementById("saveLibraryBtn");
      const oldButtonText = button?.textContent || "存入文案库";
      showTopNotice("准备存入文案库，请按提示确认名称。", "library");
      const choice = await chooseLibrarySaveChoice({ forceAskForLibrary: true });
      if (choice?.canceled) {
        const message = "已取消存入文案库，未保存。";
        setStatus(message);
        showTopNotice(message, "cancelled");
        return;
      }
      const defaultName = choice.libraryName || defaultLibraryName();
      let name = choice.libraryName || "";
      const forceNew = choice.librarySaveMode !== "overwrite";
      const targetId = choice.librarySaveMode === "overwrite" ? choice.libraryTargetId : "";
      name = String(name || defaultName).trim() || defaultName;
      setStatus("正在保存到文案库...");
      showTopNotice("正在存入文案库：" + name + "。", "library");
      if (button) {
        button.disabled = true;
        button.textContent = "存入中...";
      }
      try {
        collect();
        const errors = validateClient(tasks);
        if (errors.length) {
          const message = "不能存入文案库：" + errors.slice(0, 4).map((item) => item.message).join("；");
          markInvalidRows(errors);
          setStatus(message, true);
          showTopNotice(message, "blocked");
          return;
        }
        let result;
        try {
          result = await postJson("/api/library/save", {
            name,
            tasks,
            forceNew,
            targetId,
            librarySaveMode: choice.librarySaveMode
          });
        } catch (error) {
          result = { ok: false, error: error?.message || String(error) };
        }
        if (!result.ok) {
          const message = result.error || "保存到文案库失败";
          setStatus(message, true);
          showTopNotice(message, "blocked");
          return;
        }
        tasks = result.tasks || tasks;
        dirty = false;
        libraryUnsavedChanges = false;
        window.__v2PreviewDirty = false;
        savedAt = result.savedAt || new Date().toISOString();
        render();
        const savedName = result.item?.name || name || defaultName;
        setStatus("已存入文案库：" + savedName);
        showTopNotice("已存入文案库：" + savedName + "。以后可在控制台文案库直接打开。", "library");
      } finally {
        if (button) {
          button.disabled = false;
          button.textContent = oldButtonText;
        }
      }
    }

    async function chooseLibrarySaveChoice(options = {}) {
      if (options.auto) {
        return { librarySaveMode: "none" };
      }
      if (!libraryItem && !options.forceAskForLibrary) return {};
      if (!dirty && !libraryUnsavedChanges && !options.forceAskForLibrary) return { librarySaveMode: "none" };
      return await openLibrarySaveModal(options);
    }

    async function openLibrarySaveModal(options = {}) {
      await loadPreviewLibraryItems();
      return new Promise((resolve) => {
        if (librarySaveModalResolver) {
          librarySaveModalResolver({ canceled: true });
          librarySaveModalResolver = null;
        }
        librarySaveModalResolver = resolve;
        const modal = document.getElementById("librarySaveModal");
        const title = document.getElementById("librarySaveModalTitle");
        const hint = document.getElementById("librarySaveHint");
        const modeWrap = document.getElementById("librarySaveModeWrap");
        const mode = document.getElementById("librarySaveMode");
        const name = document.getElementById("librarySaveName");
        const target = document.getElementById("librarySaveTarget");
        const error = document.getElementById("librarySaveModalError");
        const confirm = document.getElementById("librarySaveConfirmBtn");
        const cancelTop = document.getElementById("librarySaveCancelTopBtn");
        const cancelBottom = document.getElementById("librarySaveCancelBtn");
        error.textContent = "";
        mode.innerHTML = "";
        renderLibrarySaveTargetOptions();
        modal.dataset.cancelMode = options.forceAskForLibrary ? "cancel" : "use-current";
        if (libraryItem) {
          title.textContent = options.forceAskForLibrary ? "保存文案库修改" : "是否保存文案库修改";
          hint.textContent = libraryItem.combined
            ? "这是多份文案拼接后的工作副本。可以另存为一份新文案，但不会覆盖任何来源文案。"
            : (options.forceAskForLibrary
              ? "这份预览来自文案库“" + (libraryItem.name || "未命名文案") + "”。请选择覆盖原文案，或另存为新文案。"
              : "这份预览来自文案库“" + (libraryItem.name || "未命名文案") + "”。不保存到文案库时，本次创建仍会使用当前预览页已修改的内容。");
          modeWrap.hidden = false;
          mode.appendChild(new Option("另存为新文案", "copy"));
          if (!libraryItem.combined && previewLibraryItems.length) mode.appendChild(new Option("覆盖已有文案", "overwrite"));
          if (!options.forceAskForLibrary) mode.appendChild(new Option("本次创建不保存到文案库", "none"));
          mode.value = options.forceAskForLibrary || libraryItem.combined ? "copy" : (previewLibraryItems.length ? "overwrite" : "copy");
          name.value = libraryItem.name || defaultLibraryName();
          if (target && libraryItem?.id) target.value = libraryItem.id;
          confirm.textContent = "确认保存";
          cancelTop.textContent = options.forceAskForLibrary ? "取消，不保存" : "不保存到文案库，继续本次创建";
          cancelBottom.textContent = options.forceAskForLibrary ? "取消，不保存" : "不保存到文案库，继续本次创建";
        } else {
          title.textContent = "存入文案库";
          hint.textContent = previewLibraryItems.length
            ? "请选择另存为新文案，或覆盖已经保存的一份文案。覆盖只有点击确认后才会生效。"
            : "确认后会保存当前预览页已修改的内容和素材，以后可从控制台文案库直接打开。";
          modeWrap.hidden = false;
          mode.appendChild(new Option("另存为新文案", "copy"));
          if (previewLibraryItems.length) mode.appendChild(new Option("覆盖已有文案", "overwrite"));
          mode.value = "copy";
          name.value = options.defaultName || defaultLibraryName();
          confirm.textContent = "确认存入文案库";
          cancelTop.textContent = "取消，不保存";
          cancelBottom.textContent = "取消，不保存";
        }
        updateLibrarySaveModeFields();
        modal.classList.add("open");
        modal.setAttribute("aria-hidden", "false");
        setTimeout(() => {
          const focusTarget = document.getElementById("librarySaveName").disabled ? document.getElementById("librarySaveConfirmBtn") : document.getElementById("librarySaveName");
          focusTarget.focus();
          if (!document.getElementById("librarySaveName").disabled) document.getElementById("librarySaveName").select();
        }, 0);
      });
    }

    function updateLibrarySaveModeFields() {
      const mode = document.getElementById("librarySaveMode").value;
      const name = document.getElementById("librarySaveName");
      const nameWrap = document.getElementById("librarySaveNameWrap");
      const target = document.getElementById("librarySaveTarget");
      const targetWrap = document.getElementById("librarySaveTargetWrap");
      const confirm = document.getElementById("librarySaveConfirmBtn");
      const error = document.getElementById("librarySaveModalError");
      error.textContent = "";
      if (mode === "overwrite") {
        nameWrap.hidden = true;
        name.disabled = true;
        targetWrap.hidden = false;
        target.disabled = false;
        const selected = selectedLibrarySaveTarget();
        name.value = selected?.name || libraryItem?.name || defaultLibraryName();
        confirm.textContent = "确认覆盖已有文案";
        return;
      }
      if (libraryItem && mode === "none") {
        nameWrap.hidden = true;
        name.disabled = true;
        targetWrap.hidden = true;
        target.disabled = true;
        confirm.textContent = "不保存，继续本次创建";
        return;
      }
      targetWrap.hidden = true;
      target.disabled = true;
      nameWrap.hidden = false;
      name.disabled = false;
      if (libraryItem && mode === "copy" && (!String(name.value || "").trim() || name.value === (libraryItem.name || ""))) {
        name.value = (libraryItem.name || defaultLibraryName()) + " 副本";
      }
      confirm.textContent = "确认另存为新文案";
    }

    function confirmLibrarySaveModal() {
      const mode = document.getElementById("librarySaveMode").value || "copy";
      const name = document.getElementById("librarySaveName").value.trim();
      const target = document.getElementById("librarySaveTarget");
      const error = document.getElementById("librarySaveModalError");
      if (mode === "none") {
        closeLibrarySaveModal({ librarySaveMode: "none" });
        return;
      }
      if (mode === "overwrite" && !target.value) {
        error.textContent = "请选择要覆盖的文案。";
        target.focus();
        return;
      }
      if (mode === "copy" && !name) {
        error.textContent = "请填写文案名称。";
        document.getElementById("librarySaveName").focus();
        return;
      }
      const selected = selectedLibrarySaveTarget();
      closeLibrarySaveModal({
        librarySaveMode: mode,
        libraryName: mode === "overwrite" ? (selected?.name || libraryItem?.name || defaultLibraryName()) : name,
        libraryTargetId: mode === "overwrite" ? target.value : ""
      });
    }

    async function loadPreviewLibraryItems() {
      if (previewLibraryItemsLoaded) return previewLibraryItems;
      try {
        const result = await getJson("/api/library/list");
        previewLibraryItems = Array.isArray(result.items) ? result.items : [];
      } catch {
        previewLibraryItems = [];
      }
      previewLibraryItemsLoaded = true;
      return previewLibraryItems;
    }

    function renderLibrarySaveTargetOptions() {
      const target = document.getElementById("librarySaveTarget");
      if (!target) return;
      target.innerHTML = "";
      for (const item of previewLibraryItems) {
        target.appendChild(new Option((item.name || "未命名文案") + "（" + (item.taskCount || 0) + "条）", item.id || ""));
      }
      if (libraryItem?.id && previewLibraryItems.some((item) => item.id === libraryItem.id)) {
        target.value = libraryItem.id;
      }
    }

    function selectedLibrarySaveTarget() {
      const targetId = document.getElementById("librarySaveTarget")?.value || "";
      return previewLibraryItems.find((item) => item.id === targetId) || null;
    }

    function cancelLibrarySaveModal() {
      const modal = document.getElementById("librarySaveModal");
      if (modal.dataset.cancelMode === "use-current") {
        closeLibrarySaveModal({ librarySaveMode: "none" });
        return;
      }
      closeLibrarySaveModal({ canceled: true });
    }

    function closeLibrarySaveModal(result) {
      const modal = document.getElementById("librarySaveModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      if (librarySaveModalResolver) {
        const resolve = librarySaveModalResolver;
        librarySaveModalResolver = null;
        resolve(result || { canceled: true });
      }
    }

    function defaultLibraryName() {
      const first = tasks.find((task) => !task.skip) || tasks[0] || {};
      const parts = [
        first.speaker || "",
        first.date || "",
        first.time || "",
        String(first.text || "").replace(/\\s+/g, " ").trim().slice(0, 18)
      ].filter(Boolean);
      return parts.join(" ") || ("预览文案 " + runIdForPage);
    }

    function applySaveAdvice(advice) {
      const node = document.getElementById("cmsAdvice");
      const button = document.getElementById("confirmBtn");
      if (!node || !button) return;
      node.className = "cms-advice";
      if (advice?.action === "reuse_cms") {
        node.textContent = resumeAfterEdit
          ? "修改可安全保存；已成功条目会保留。确认后返回控制台，从失败位置继续创建。"
          : (advice.message || "云中客页面仍可复用，修改预览后无需重新设置。点击后会保存预览内容并返回控制台。");
        node.classList.add("reusable");
        button.textContent = resumeAfterEdit ? "修改完成，返回控制台继续创建" : "确认无误，回到控制台创建";
        button.title = "结构未变，云中客页面仍可复用；保存后返回控制台直接开始创建。";
        return;
      }
      if (advice?.action === "prepare_cms") {
        node.textContent = advice.message || "预览结构已变化，需要重新进入云中客设置。";
        node.classList.add("blocked");
        button.textContent = "确认无误，进入云中客设置";
        button.title = "";
        return;
      }
      node.textContent = "首次确认请进入云中客设置；如果云中客页面已设置且仍可复用，保存后会自动提示返回控制台创建。";
      button.textContent = "确认无误，进入云中客设置";
      button.title = "";
    }

    function initLibraryDateNotice() {
      if (!libraryItem || !libraryDateNotice) return;
      const node = document.getElementById("libraryDateNotice");
      if (!node) return;
      node.className = "library-date-notice show";
      node.textContent = libraryDateNotice;
    }

    function showTopNotice(message, kind = "") {
      const node = document.getElementById("cmsAdvice");
      if (!node) return;
      node.className = "cms-advice";
      if (kind) node.classList.add(kind);
      node.textContent = message || "";
    }

    function openManualModal() {
      const selected = selectedIndexes();
      const anchorIndex = selected.length ? Math.max(...selected) : tasks.length - 1;
      const anchor = tasks[anchorIndex] || {};
      document.getElementById("manualRole").value = anchor.role || "tuo";
      document.getElementById("manualSpeaker").value = anchor.speaker || "";
      document.getElementById("manualDate").value = defaultDate || todayMonthDay();
      document.getElementById("manualTime").value = validTime(anchor.time) ? shiftClock(anchor.time, 1) : currentClock();
      document.getElementById("manualType").value = "text";
      document.getElementById("manualText").value = "";
      document.getElementById("manualMediaPath").value = "";
      document.getElementById("manualMediaFile").value = "";
      document.getElementById("manualSkip").checked = false;
      document.getElementById("manualInsertPosition").value = selected.length ? "after-selection" : "end";
      document.getElementById("manualModalError").textContent = "";
      updateManualTypeFields();
      updateManualMediaPreview();
      const modal = document.getElementById("manualModal");
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setTimeout(() => document.getElementById("manualSpeaker").focus(), 0);
    }

    function closeManualModal() {
      const modal = document.getElementById("manualModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      const file = document.getElementById("manualMediaFile");
      if (file) file.value = "";
    }

    function manualAnchorTask() {
      const selected = selectedIndexes();
      const anchorIndex = selected.length ? Math.max(...selected) : tasks.length - 1;
      return {
        selected,
        anchor: tasks[anchorIndex] || {}
      };
    }

    function manualBatchAnchorTask() {
      const selected = selectedIndexes();
      const mode = document.getElementById("manualBatchInsertPosition")?.value || (selected.length ? "after-selection" : "end");
      let anchorIndex = tasks.length - 1;
      if (selected.length && mode === "before-selection") anchorIndex = Math.min(...selected);
      else if (selected.length && mode === "after-selection") anchorIndex = Math.max(...selected);
      return {
        selected,
        mode,
        anchor: tasks[anchorIndex] || {}
      };
    }

    function openManualBatchModal() {
      const state = manualAnchorTask();
      document.getElementById("manualBatchInsertPosition").value = state.selected.length ? "after-selection" : "end";
      document.getElementById("manualBatchStepMinutes").value = "1";
      document.getElementById("manualBatchStepUnit").value = "minute";
      updateManualBatchStepHint();
      document.getElementById("manualBatchModalError").textContent = "";
      document.getElementById("manualBatchRows").innerHTML = "";
      addManualBatchRow();
      const modal = document.getElementById("manualBatchModal");
      resetDraggableModal(modal);
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setTimeout(() => document.querySelector("#manualBatchRows textarea")?.focus(), 0);
    }

    function closeManualBatchModal() {
      const modal = document.getElementById("manualBatchModal");
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      document.getElementById("manualBatchModalError").textContent = "";
    }

    function initDraggableModal(modalId) {
      const backdrop = document.getElementById(modalId);
      const dialog = backdrop?.querySelector(".modal");
      const handle = backdrop?.querySelector(".modal-header");
      if (!backdrop || !dialog || !handle) return;
      let drag = null;
      handle.addEventListener("pointerdown", (event) => {
        if (event.button !== 0) return;
        if (event.target.closest("button,input,select,textarea,a")) return;
        const currentX = Number(dialog.dataset.dragX || 0);
        const currentY = Number(dialog.dataset.dragY || 0);
        drag = {
          startX: event.clientX,
          startY: event.clientY,
          currentX,
          currentY
        };
        dialog.classList.add("is-dragging");
        handle.setPointerCapture?.(event.pointerId);
        event.preventDefault();
      });
      handle.addEventListener("pointermove", (event) => {
        if (!drag) return;
        const x = drag.currentX + event.clientX - drag.startX;
        const y = drag.currentY + event.clientY - drag.startY;
        setDraggableModalOffset(dialog, x, y);
      });
      const stop = (event) => {
        if (!drag) return;
        drag = null;
        dialog.classList.remove("is-dragging");
        try {
          handle.releasePointerCapture?.(event.pointerId);
        } catch {}
      };
      handle.addEventListener("pointerup", stop);
      handle.addEventListener("pointercancel", stop);
    }

    function setDraggableModalOffset(dialog, x, y) {
      const bounds = dialog.getBoundingClientRect();
      const maxX = Math.max(0, (window.innerWidth - Math.min(180, bounds.width)) / 2);
      const maxY = Math.max(0, (window.innerHeight - Math.min(120, bounds.height)) / 2);
      const nextX = Math.max(-maxX, Math.min(maxX, x));
      const nextY = Math.max(-maxY, Math.min(maxY, y));
      dialog.dataset.dragX = String(nextX);
      dialog.dataset.dragY = String(nextY);
      dialog.style.transform = "translate(" + nextX + "px, " + nextY + "px)";
    }

    function resetDraggableModal(backdrop) {
      const dialog = backdrop?.querySelector(".modal");
      if (!dialog) return;
      dialog.dataset.dragX = "0";
      dialog.dataset.dragY = "0";
      dialog.style.transform = "";
      dialog.classList.remove("is-dragging");
    }

    function addManualBatchRow() {
      const tbody = document.getElementById("manualBatchRows");
      const state = manualBatchAnchorTask();
      const anchor = state.anchor || {};
      const row = document.createElement("tr");
      const date = normalizePreviewDate(anchor.date || defaultDate || todayMonthDay());
      row.className = "manual-batch-row";
      row.innerHTML =
        "<td><select class='manualBatchRole'><option value='tuo'>托</option><option value='douma'>豆妈</option></select></td>" +
        "<td><input class='manualBatchSpeaker'></td>" +
        "<td><input class='manualBatchDate'></td>" +
        "<td><input class='manualBatchTime'></td>" +
        "<td><select class='manualBatchType'><option value='text'>文字</option><option value='finder'>视频号</option><option value='image'>图片</option><option value='sticker'>表情包</option><option value='video'>视频</option></select></td>" +
        "<td><div class='manual-batch-content-cell'>" +
          "<textarea class='manualBatchContent' placeholder='填写正文；图片/视频/表情包填写本地素材路径'></textarea>" +
          "<div class='manual-batch-media-box' data-manual-batch-drop-zone='1' hidden>" +
            "<div class='thumb manualBatchThumb'>无素材</div>" +
            "<div class='manual-batch-media-tools'>" +
              "<div class='manual-batch-media-actions'>" +
                "<input class='hidden-file manualBatchFile' type='file'>" +
                "<button class='small-btn ghost manualBatchChooseBtn' type='button'>选择文件</button>" +
              "</div>" +
              "<div class='media-status manualBatchMediaStatus'>未选择素材</div>" +
              "<div class='media-hint'>可拖拽素材到这里，或复制图片后在本行 Ctrl+V 粘贴。</div>" +
            "</div>" +
          "</div>" +
        "</div></td>" +
        "<td><input class='manualBatchSkip' type='checkbox'></td>" +
        "<td><button class='small-btn manualBatchRemoveBtn' type='button'>删除</button></td>";
      row.querySelector(".manualBatchRole").value = anchor.role || "tuo";
      row.querySelector(".manualBatchSpeaker").value = anchor.speaker || "";
      row.querySelector(".manualBatchDate").value = date;
      row.querySelector(".manualBatchType").addEventListener("change", (event) => updateManualBatchContentPlaceholder(row, event.target.value));
      row.querySelector(".manualBatchContent").addEventListener("input", () => updateManualBatchMediaPreview(row));
      row.querySelector(".manualBatchFile").addEventListener("change", async (event) => {
        await setManualBatchMediaFile(row, event.target.files && event.target.files[0]);
      });
      row.querySelector(".manualBatchChooseBtn").addEventListener("click", () => row.querySelector(".manualBatchFile")?.click());
      row.querySelector(".manualBatchRemoveBtn").addEventListener("click", () => row.remove());
      tbody.appendChild(row);
      updateManualBatchContentPlaceholder(row, "text");
      refreshManualBatchTiming();
    }

    function manualBatchStepSeconds() {
      const value = Math.max(0, Number(document.getElementById("manualBatchStepMinutes")?.value || 0));
      const unit = document.getElementById("manualBatchStepUnit")?.value || "minute";
      return unit === "second" ? value : value * 60;
    }

    function updateManualBatchStepHint() {
      const input = document.getElementById("manualBatchStepMinutes");
      const unit = document.getElementById("manualBatchStepUnit")?.value || "minute";
      const raw = Math.max(0, Number(input?.value || 0));
      const label = unit === "second" ? "秒" : "分钟";
      const state = manualBatchAnchorTask();
      const base = validTime(state.anchor?.time) ? state.anchor.time : "19:34:37";
      const direction = state.mode === "before-selection" ? -1 : 1;
      const first = shiftClockSeconds(base, direction * raw * (unit === "second" ? 1 : 60));
      const second = shiftClockSeconds(base, direction * raw * (unit === "second" ? 2 : 120));
      const position = state.mode === "before-selection" ? "往前" : "往后";
      const node = document.getElementById("manualBatchStepHint");
      if (node) node.textContent = "例：参考时间 " + base + "，每行" + position + "递增 " + raw + " " + label + "，补录行自动变为 " + first + "、" + second + "。";
    }

    function refreshManualBatchTiming() {
      updateManualBatchStepHint();
      const rows = Array.from(document.querySelectorAll("#manualBatchRows tr"));
      const state = manualBatchAnchorTask();
      const anchor = state.anchor || {};
      const baseTime = validTime(anchor.time) ? anchor.time : currentClock();
      const stepSeconds = manualBatchStepSeconds();
      for (const [index, row] of rows.entries()) {
        const input = row.querySelector(".manualBatchTime");
        if (!input) continue;
        const previousAuto = input.dataset.autoValue || "";
        if (input.value && input.value !== previousAuto) continue;
        const offset = manualBatchTimeOffsetSeconds(index, rows.length, state.mode, stepSeconds);
        const nextValue = validTime(baseTime) ? shiftClockSeconds(baseTime, offset) : currentClock();
        input.value = nextValue;
        input.dataset.autoValue = nextValue;
      }
    }

    function manualBatchTimeOffsetSeconds(index, total, mode, stepSeconds) {
      if (mode === "before-selection") return -1 * Math.max(1, total - index) * stepSeconds;
      return (index + 1) * stepSeconds;
    }

    function updateManualBatchContentPlaceholder(row, type) {
      const input = row.querySelector(".manualBatchContent");
      if (!input) return;
      const mediaBox = row.querySelector("[data-manual-batch-drop-zone='1']");
      const file = row.querySelector(".manualBatchFile");
      const isText = isTextLikeType(type);
      input.placeholder = isText ? "填写正文" : "可填写本地素材路径；也可点选择文件、拖拽文件或粘贴图片";
      if (mediaBox) mediaBox.hidden = isText;
      if (file) {
        file.setAttribute("accept", acceptForType(type));
        file.value = "";
      }
      updateManualBatchMediaPreview(row);
    }

    function updateManualBatchMediaPreview(row) {
      const type = row.querySelector(".manualBatchType")?.value || "";
      const mediaBox = row.querySelector("[data-manual-batch-drop-zone='1']");
      const thumb = row.querySelector(".manualBatchThumb");
      const status = row.querySelector(".manualBatchMediaStatus");
      const pathValue = row.querySelector(".manualBatchContent")?.value.trim() || "";
      if (!mediaBox || !thumb || !status || isTextLikeType(type)) return;
      const preview = mediaPreviewSrc(pathValue);
      if (preview) {
        thumb.innerHTML = type === "video"
          ? "<video src='" + escapeAttr(preview) + "' muted></video>"
          : "<img src='" + escapeAttr(preview) + "' alt='素材预览'>";
        setThumbPopover(thumb, preview, type);
      } else {
        thumb.textContent = "无素材";
        setThumbPopover(thumb, "", type);
      }
      status.textContent = pathValue ? ("已选择：" + (shortPath(pathValue) || pathValue)) : "未选择素材";
      status.className = pathValue ? "media-status manualBatchMediaStatus" : "media-status manualBatchMediaStatus bad";
    }

    async function addManualBatchTasksFromModal() {
      const errorEl = document.getElementById("manualBatchModalError");
      errorEl.textContent = "";
      const rows = Array.from(document.querySelectorAll("#manualBatchRows tr"));
      const nextTasks = [];
      const errors = [];
      const stamp = Date.now();
      for (const [rowIndex, row] of rows.entries()) {
        const role = row.querySelector(".manualBatchRole").value;
        const speaker = row.querySelector(".manualBatchSpeaker").value.trim();
        const date = normalizePreviewDate(row.querySelector(".manualBatchDate").value);
        const time = normalizeClockInputOrTrim(row.querySelector(".manualBatchTime").value);
        const type = row.querySelector(".manualBatchType").value;
        const skip = row.querySelector(".manualBatchSkip").checked;
        const content = row.querySelector(".manualBatchContent").value.trim();
        if (!content) continue;
        const label = "第 " + (rowIndex + 1) + " 行";
        if (!role) errors.push(label + " 请选择角色");
        if (!speaker) errors.push(label + " 请填写说话人");
        if (!date) errors.push(label + " 请填写日期");
        else if (!validDate(date)) errors.push(label + " 日期格式不合法");
        if (!time) errors.push(label + " 请填写时间");
        else if (!validTime(time)) errors.push(label + " 时间格式不合法");
        if (!type) errors.push(label + " 请选择类型");
        if (!isTextLikeType(type) && !mediaPathMatchesType(content, type)) errors.push(label + " 素材类型不匹配");
        nextTasks.push({
          sourceId: "manual-batch-" + stamp + "-" + rowIndex,
          sourceText: "手动批量新增",
          role,
          speaker,
          date,
          time,
          type,
          text: isTextLikeType(type) ? content : "",
          mediaPath: isTextLikeType(type) ? "" : content,
          skip,
          order: 0,
          interactionGroup: "",
          continueMarker: false,
          cleanSpeaker: speaker.replace(/\\s+/g, "")
        });
      }
      if (!nextTasks.length) errors.push("请至少填写一条正文或素材路径");
      if (errors.length) {
        errorEl.textContent = errors.join("；");
        return;
      }
      const sourceText = nextTasks.length === 1 ? "手动新增" : "手动批量新增";
      for (const task of nextTasks) task.sourceText = sourceText;
      for (const task of nextTasks) {
        if (isTextLikeType(task.type)) continue;
        const status = await fetch("/api/media-status?path=" + encodeURIComponent(task.mediaPath)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
        if (!status.ok) {
          errorEl.textContent = "素材不可用：" + (status.message || task.mediaPath);
          return;
        }
      }
      collect();
      const insertAt = manualBatchInsertIndex();
      const insertMode = document.getElementById("manualBatchInsertPosition").value;
      const provenance = manualInsertionProvenance(insertAt, insertMode);
      for (const task of nextTasks) Object.assign(task, cloneTasks(provenance));
      pushUndoSnapshot("手动批量补录");
      tasks.splice(insertAt, 0, ...nextTasks);
      tasks = inheritManualDaySegments(tasks);
      originalTimes.splice(insertAt, 0, ...nextTasks.map(() => ({ date: "", time: "" })));
      reindexTaskOrders();
      selectedRows = new Set(nextTasks.map((_, offset) => insertAt + offset));
      viewMode = "execution";
      closeManualBatchModal();
      render();
      markDirty("已手动补录 " + nextTasks.length + " 条，正在自动保存预览内容");
    }

    function manualBatchInsertIndex() {
      const mode = document.getElementById("manualBatchInsertPosition").value;
      const selected = selectedIndexes();
      if (mode === "before-selection" && selected.length) return Math.min(...selected);
      if (mode === "after-selection" && selected.length) return Math.max(...selected) + 1;
      return tasks.length;
    }

    function updateManualTypeFields() {
      const type = document.getElementById("manualType").value;
      document.getElementById("manualTextWrap").hidden = !isTextLikeType(type);
      document.getElementById("manualMediaWrap").hidden = isTextLikeType(type);
      document.getElementById("manualMediaFile").setAttribute("accept", acceptForType(type));
      document.getElementById("manualModalError").textContent = "";
      updateManualMediaPreview();
    }

    async function updateManualMediaPreview() {
      const type = document.getElementById("manualType").value;
      const thumb = document.getElementById("manualMediaThumb");
      const status = document.getElementById("manualMediaStatus");
      const short = document.getElementById("manualMediaShortPath");
      if (isTextLikeType(type)) return;
      const file = document.getElementById("manualMediaFile").files?.[0];
      const pathValue = document.getElementById("manualMediaPath").value.trim();
      if (file) {
        const objectUrl = URL.createObjectURL(file);
        thumb.innerHTML = type === "video"
          ? "<video src='" + escapeAttr(objectUrl) + "' muted></video>"
          : "<img src='" + escapeAttr(objectUrl) + "' alt='素材预览'>";
        setThumbPopover(thumb, objectUrl, type);
        short.textContent = file.name;
        status.textContent = "已选择本地文件，点击添加后保存到本轮素材缓存";
        status.className = "media-status";
        return;
      }
      short.textContent = shortPath(pathValue) || "未选择素材";
      const preview = mediaPreviewSrc(pathValue);
      if (preview) {
        thumb.innerHTML = type === "video"
          ? "<video src='" + escapeAttr(preview) + "' muted></video>"
          : "<img src='" + escapeAttr(preview) + "' alt='素材预览'>";
        setThumbPopover(thumb, preview, type);
      } else {
        thumb.textContent = "无素材";
        setThumbPopover(thumb, "", type);
      }
      if (!pathValue) {
        status.textContent = "未选择素材";
        status.className = "media-status bad";
        return;
      }
      const result = await fetch("/api/media-status?path=" + encodeURIComponent(pathValue)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
      status.textContent = result.message || (result.ok ? "素材可用" : "素材不可用");
      status.className = result.ok ? "media-status" : "media-status bad";
    }

    async function addManualTaskFromModal() {
      const errorEl = document.getElementById("manualModalError");
      errorEl.textContent = "";
      const role = document.getElementById("manualRole").value;
      const speaker = document.getElementById("manualSpeaker").value.trim();
      const date = normalizePreviewDate(document.getElementById("manualDate").value);
      const time = normalizeClockInputOrTrim(document.getElementById("manualTime").value);
      const type = document.getElementById("manualType").value;
      const skip = document.getElementById("manualSkip").checked;
      const text = document.getElementById("manualText").value;
      let mediaPath = document.getElementById("manualMediaPath").value.trim();
      const file = document.getElementById("manualMediaFile").files?.[0] || null;
      const errors = [];
      if (!role) errors.push("请选择角色");
      if (!speaker) errors.push("请填写说话人");
      if (!date) errors.push("请填写日期");
      else if (!validDate(date)) errors.push("日期格式不合法");
      if (!time) errors.push("请填写时间");
      else if (!validTime(time)) errors.push("时间格式不合法");
      if (!type) errors.push("请选择类型");
      if (isTextLikeType(type)) {
        if (!String(text || "").trim()) errors.push("请填写正文");
      } else if (!file && !mediaPath) {
        errors.push("请选择或填写本地素材路径");
      } else if (mediaPath && !mediaPathMatchesType(mediaPath, type)) {
        errors.push("素材类型不匹配");
      }
      if (errors.length) {
        errorEl.textContent = errors.join("；");
        return;
      }
      if (!isTextLikeType(type) && file) {
        const form = new FormData();
        form.append("file", file);
        form.append("type", type);
        form.append("sourceId", "manual-" + Date.now());
        const uploaded = await postForm("/api/upload-media", form);
        if (!uploaded.ok) {
          errorEl.textContent = uploaded.error || "素材上传失败";
          return;
        }
        mediaPath = uploaded.path;
      }
      if (!isTextLikeType(type) && mediaPath) {
        const status = await fetch("/api/media-status?path=" + encodeURIComponent(mediaPath)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
        if (!status.ok) {
          errorEl.textContent = status.message || "素材不可用";
          return;
        }
      }
      collect();
      const insertAt = manualInsertIndex();
      const insertMode = document.getElementById("manualInsertPosition").value;
      const provenance = manualInsertionProvenance(insertAt, insertMode);
      pushUndoSnapshot("手动新增");
      const task = {
        sourceId: "manual-" + Date.now(),
        sourceText: "手动新增",
        role,
        speaker,
        date,
        time,
        type,
        text: isTextLikeType(type) ? text : "",
        mediaPath: isTextLikeType(type) ? "" : mediaPath,
        skip,
        order: 0,
        interactionGroup: "",
        continueMarker: false,
        cleanSpeaker: speaker.replace(/\\s+/g, ""),
        ...provenance
      };
      tasks.splice(insertAt, 0, task);
      tasks = inheritManualDaySegments(tasks);
      originalTimes.splice(insertAt, 0, { date: "", time: "" });
      reindexTaskOrders();
      selectedRows = new Set([insertAt]);
      viewMode = "execution";
      closeManualModal();
      render();
      markDirty("已手动新增一条，正在自动保存预览内容");
    }

    function manualInsertIndex() {
      const mode = document.getElementById("manualInsertPosition").value;
      const selected = selectedIndexes();
      if (mode === "before-selection" && selected.length) return Math.min(...selected);
      if (mode === "after-selection" && selected.length) return Math.max(...selected) + 1;
      return tasks.length;
    }

    function manualInsertionProvenance(insertAt, mode) {
      const preferredIndex = mode === "before-selection" ? insertAt : insertAt - 1;
      const fallbackIndex = mode === "before-selection" ? insertAt - 1 : insertAt;
      const reference = tasks[preferredIndex] || tasks[fallbackIndex] || null;
      if (!reference) return {};
      const inherited = {};
      if (String(reference.daySegment || "").trim()) inherited.daySegment = reference.daySegment;
      if (Object.prototype.hasOwnProperty.call(reference, "sourceDayHeadingSegment")) {
        inherited.sourceDayHeadingSegment = reference.sourceDayHeadingSegment;
        inherited.sourceDayHeadingLabel = String(reference.sourceDayHeadingLabel || "");
      }
      if (reference.sourceLibrarySegment && typeof reference.sourceLibrarySegment === "object") {
        inherited.sourceLibrarySegment = cloneTasks(reference.sourceLibrarySegment);
      }
      return inherited;
    }

    function reindexTaskOrders() {
      tasks = tasks.map((task, index) => ({ ...task, order: index + 1 }));
    }

    function shiftClock(value, minutes) {
      return shiftClockSeconds(value, Number(minutes || 0) * 60);
    }

    function shiftClockSeconds(value, seconds) {
      const base = parseClockSeconds(value);
      if (!Number.isFinite(base)) return value;
      let total = base + Number(seconds || 0);
      total = ((total % 86400) + 86400) % 86400;
      return formatClockSeconds(total);
    }

    function shiftPreviewDateTime(date, time, seconds) {
      const base = parseClockSeconds(time);
      if (!Number.isFinite(base)) return { date, time };
      const total = base + Number(seconds || 0);
      const dayDelta = Math.floor(total / 86400);
      const secondsOfDay = ((total % 86400) + 86400) % 86400;
      return {
        date: dayDelta ? shiftPreviewDate(date, dayDelta) : date,
        time: formatClockSeconds(secondsOfDay)
      };
    }

    function parseClockSeconds(value) {
      const match = String(value || "").trim().match(/^(\\d{1,2})[:：](\\d{1,2})(?:[:：](\\d{1,2}))?$/);
      if (!match) return NaN;
      return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0);
    }

    function formatClockSeconds(total) {
      const hour = Math.floor(total / 3600);
      const minute = Math.floor((total % 3600) / 60);
      const second = total % 60;
      return pad2(hour) + ":" + pad2(minute) + ":" + pad2(second);
    }

    function shiftPreviewDate(value, dayDelta) {
      const parts = parsePreviewDateParts(value);
      if (!parts) return value;
      const date = new Date(parts.year, parts.month - 1, parts.day);
      if (Number.isNaN(date.getTime())) return value;
      date.setDate(date.getDate() + Number(dayDelta || 0));
      return (date.getMonth() + 1) + "/" + date.getDate();
    }

    function parsePreviewDateParts(value) {
      const text = String(value || "").trim();
      const ymd = text.match(/^(\\d{4})-(\\d{1,2})-(\\d{1,2})$/);
      if (ymd) return { year: Number(ymd[1]), month: Number(ymd[2]), day: Number(ymd[3]) };
      const md = text.match(/^(\\d{1,2})\\s*[\\/月-]\\s*(\\d{1,2})\\s*日?$/);
      if (md) return { year: new Date().getFullYear(), month: Number(md[1]), day: Number(md[2]) };
      return null;
    }

    function batchTimeUnitSeconds(unit) {
      if (unit === "second") return 1;
      if (unit === "hour") return 3600;
      if (unit === "day") return 86400;
      return 60;
    }

    function batchTimeUnitLabel(unit) {
      if (unit === "second") return "秒";
      if (unit === "hour") return "小时";
      if (unit === "day") return "天";
      return "分钟";
    }

    async function uploadReplacement(row, file) {
      if (!file) return;
      updateTaskFromRow(row);
      const index = Number(row.dataset.index);
      const task = tasks[index];
      const result = await uploadMediaFile(file, task.type || "", task.sourceId || "");
      if (!result.ok) {
        setStatus(result.error || "素材上传失败", true);
        return;
      }
      pushUndoSnapshot("更换素材");
      task.mediaPath = result.path;
      task.mediaOrigin = "manual";
      task.mediaRecoveryState = "manual";
      task.mediaRecoveryMessage = "已手动补充";
      delete task.mediaRetryAfterMs;
      delete task.previewError;
      row.querySelector("[data-field='mediaPath']").value = result.path;
      if (previewRepairProblem && Number(previewRepairProblem.index) === index) previewRepairProblem = null;
      render();
      markDirty("素材已替换，正在自动保存预览内容");
    }

    async function setManualModalMediaFile(file) {
      const type = document.getElementById("manualType").value;
      if (isTextLikeType(type)) return setStatus("当前补录类型是文字，不需要上传素材", true);
      const result = await uploadMediaFile(file, type, "manual-" + Date.now());
      const errorEl = document.getElementById("manualModalError");
      if (!result.ok) {
        if (errorEl) errorEl.textContent = result.error || "素材上传失败";
        setStatus(result.error || "素材上传失败", true);
        return;
      }
      document.getElementById("manualMediaPath").value = result.path;
      document.getElementById("manualMediaFile").value = "";
      await updateManualMediaPreview();
      setStatus("素材已上传，可继续补录。");
    }

    async function setManualBatchMediaFile(row, file) {
      if (!row) return;
      const type = row.querySelector(".manualBatchType")?.value || "";
      const errorEl = document.getElementById("manualBatchModalError");
      if (isTextLikeType(type)) {
        if (errorEl) errorEl.textContent = "当前行是文字类型，不需要上传素材。";
        return;
      }
      const result = await uploadMediaFile(file, type, "manual-batch-" + Date.now());
      if (!result.ok) {
        if (errorEl) errorEl.textContent = result.error || "素材上传失败";
        setStatus(result.error || "素材上传失败", true);
        return;
      }
      row.querySelector(".manualBatchContent").value = result.path;
      const fileInput = row.querySelector(".manualBatchFile");
      if (fileInput) fileInput.value = "";
      updateManualBatchMediaPreview(row);
      if (errorEl) errorEl.textContent = "";
      setStatus("批量补录素材已上传。");
    }

    async function uploadMediaFile(file, type, sourceId = "") {
      const form = new FormData();
      form.append("file", file);
      form.append("type", type || "");
      form.append("sourceId", sourceId || "");
      return postForm("/api/upload-media", form);
    }

    function validateClient(items) {
      const errors = [];
      for (const [index, task] of items.entries()) {
        if (task.skip) continue;
        const label = "第 " + (index + 1) + " 条";
        const previewError = String(task.previewError || "").trim();
        if (previewError && !(task.type === "finder" && previewError === "finder_xml_incomplete")) {
          errors.push({ index, message: previewError });
        }
        if (!task.role) errors.push({ index, message: label + " 缺少角色" });
        if (!String(task.date || "").trim()) errors.push({ index, message: label + " 缺少日期" });
        else if (!validDate(task.date)) errors.push({ index, message: label + " 日期格式不合法" });
        if (!String(task.time || "").trim()) errors.push({ index, message: label + " 缺少时间" });
        else if (!validTime(task.time)) errors.push({ index, message: label + " 时间格式不合法" });
        if (isTextLikeType(task.type)) {
          if (!String(task.text || "").trim()) errors.push({ index, message: label + " 正文为空" });
          else if (task.type === "finder" && !isCompleteFinderXml(task.text)) errors.push({ index, message: label + " 视频号代码块未完整采集，请手动补录完整参数" });
        } else if (!String(task.mediaPath || "").trim()) {
          if (!isMediaRecoveryPending(task) && !String(task.previewError || "").trim()) {
            errors.push({ index, message: label + " 素材路径为空" });
          }
        } else if (/^(blob:|image-blob:)/i.test(String(task.mediaPath || "").trim())) {
          errors.push({ index, message: label + " 是临时素材地址，请重新生成预览或点更换素材换成本地文件" });
        } else if (!mediaPathMatchesType(task.mediaPath, task.type)) {
          errors.push({ index, message: label + " 素材类型不匹配" });
        }
      }
      return errors;
    }

    function markInvalidRows(errors) {
      document.querySelectorAll("tbody tr").forEach((row) => clearRowError(row));
      const byIndex = new Map();
      for (const error of errors) {
        if (!byIndex.has(error.index)) byIndex.set(error.index, []);
        byIndex.get(error.index).push(error.message);
      }
      for (const [index, messages] of byIndex.entries()) {
        const row = document.querySelector("tr[data-index='" + index + "']");
        if (!row) continue;
        row.classList.add("invalid");
        const note = document.createElement("div");
        note.className = "row-note error";
        note.dataset.validationNote = "1";
        note.textContent = messages.join("；");
        (row.querySelector(".content-grid") || row.querySelector("td:last-child")).appendChild(note);
      }
    }

    function clearRowError(row) {
      row.classList.remove("invalid");
      row.querySelectorAll("[data-validation-note='1']").forEach((node) => node.remove());
    }

    function timeSortKey(task) {
      return dateSortKey(task.date) * 1000000 + clockSortKey(task.time);
    }

    function dateSortKey(date) {
      const match = String(date || "").match(/(\\d{1,2})\\s*[\\\/月]\\s*(\\d{1,2})/);
      if (!match) return 0;
      return Number(match[1]) * 100 + Number(match[2]);
    }

    function clockSortKey(time) {
      const match = String(time || "").match(/^(\\d{1,2}):(\\d{1,2})(?::(\\d{1,2}))?/);
      if (!match) return 999999;
      return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0);
    }

    function updateViewControls() {
      document.getElementById("executionViewBtn").classList.toggle("active", viewMode === "execution");
      document.getElementById("timeViewBtn").classList.toggle("active", viewMode === "time");
      const toggleSkippedRowsBtn = document.getElementById("toggleSkippedRowsBtn");
      toggleSkippedRowsBtn.classList.toggle("active", hideSkippedRows);
      toggleSkippedRowsBtn.textContent = hideSkippedRows ? "显示全部" : "隐藏不发";
      const selectedCount = selectedIndexes().length;
      const skipCount = tasks.filter((task) => task.skip).length;
      document.getElementById("totalCount").textContent = String(tasks.length);
      document.getElementById("selectedCount").textContent = String(selectedCount);
      document.getElementById("batchSelectedCount").textContent = String(selectedCount);
      document.getElementById("skipCount").textContent = String(skipCount);
      updateDateSummaries();
      updateTimeDirectionButtons();
      updateUndoButtons();
    }

    function updateTimeDirectionButtons() {
      document.getElementById("delayBtn").classList.toggle("active", pendingTimeDirection === 1);
      document.getElementById("advanceBtn").classList.toggle("active", pendingTimeDirection === -1);
    }

    function initBatchDateControls() {
      const select = document.getElementById("batchDateQuick");
      if (!select) return;
      select.innerHTML = batchDateOptions().map((option) =>
        "<option value='" + escapeAttr(option.value) + "'>" + escapeHtmlJs(option.label) + "</option>"
      ).join("");
      select.value = todayMonthDay();
      updateBatchDateCustomVisibility();
      updateDateSummaries();
    }

    function initRetimeControls() {
      const first = firstSendableTask();
      const input = document.getElementById("retimeStartTime");
      const savedSchedule = initialSchedule?.mode === "realtime" ? initialSchedule : {};
      const savedMode = savedSchedule.startMode === "reverse" ? "reverse" : "normal";
      if (input) input.value = savedSchedule.startEstimate?.predictedStartTime || savedSchedule.startTime || first?.time || "";
      document.getElementById("retimeEndTime").value = savedSchedule.endTime || "";
      document.getElementById("retimeStartMode").value = savedMode;
      applySavedRetimeIntervals(savedSchedule.intervals || {});
      updateRetimeStartMode();
      updateRetimeSummary();
      for (const id of ["retimeStartTime", "retimeEndTime", "retimeDifferentTuoMin", "retimeDifferentTuoMax", "retimeSameTuoMin", "retimeSameTuoMax", "retimeMediaMin", "retimeMediaMax", "retimeDoumaSameMin", "retimeDoumaSameMax", "retimeRoleSwitchMin", "retimeRoleSwitchMax"]) {
        document.getElementById(id)?.addEventListener("input", () => {
          updateRetimeSummary();
          scheduleReverseRetimeEstimate();
        });
      }
    }

    function toggleRetimePanel() {
      const panel = document.getElementById("retimePanel");
      const button = document.getElementById("toggleRetimePanelBtn");
      const expanded = panel.hidden;
      panel.hidden = !expanded;
      button.setAttribute("aria-expanded", String(expanded));
      button.classList.toggle("active", expanded);
      button.textContent = expanded ? "收起重排时间" : "重排时间";
      if (expanded) scheduleReverseRetimeEstimate();
    }

    function openRetimePanel() {
      const panel = document.getElementById("retimePanel");
      if (panel.hidden) toggleRetimePanel();
      panel.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }

    function applySavedRetimeIntervals(intervals) {
      const fields = {
        differentTuo: "retimeDifferentTuo",
        sameTuo: "retimeSameTuo",
        media: "retimeMedia",
        doumaSame: "retimeDoumaSame",
        roleSwitch: "retimeRoleSwitch"
      };
      for (const [key, prefix] of Object.entries(fields)) {
        const interval = intervals?.[key];
        if (!interval) continue;
        if (Number.isFinite(Number(interval.min))) document.getElementById(prefix + "Min").value = String(interval.min);
        if (Number.isFinite(Number(interval.max))) document.getElementById(prefix + "Max").value = String(interval.max);
      }
    }

    function updateRetimeStartMode() {
      const mode = document.getElementById("retimeStartMode")?.value || "normal";
      const input = document.getElementById("retimeStartTime");
      if (!input) return;
      input.readOnly = mode === "reverse";
      if (mode === "reverse") input.placeholder = "根据结束时间自动反推";
      else input.placeholder = "留空默认当前时间1分钟后；填写则按填写时间";
      updateRetimeSummary();
    }

    function scheduleReverseRetimeEstimate() {
      clearTimeout(retimeEstimateTimer);
      if (document.getElementById("retimePanel")?.hidden) return;
      if (document.getElementById("retimeStartMode")?.value !== "reverse") return;
      retimeEstimateTimer = setTimeout(() => refreshReverseRetimeEstimate(), 250);
    }

    async function refreshReverseRetimeEstimate() {
      const endTime = normalizeClockInputOrTrim(document.getElementById("retimeEndTime")?.value || "");
      if (!validTime(endTime)) return updateRetimeSummary();
      const editableTasks = tasks.filter((task, index) => !isContinuationLocked(task, index));
      if (!editableTasks.length) return updateRetimeSummary();
      try {
        const result = await postJson("/api/retime-preview", {
          tasks: editableTasks,
          startMode: "reverse",
          endTime,
          startDate: editableTasks.find((task) => !task.skip)?.date || editableTasks[0]?.date || "",
          intervals: collectRetimeIntervals()
        });
        const estimate = result.startEstimate;
        if (!estimate) return;
        document.getElementById("retimeStartTime").value = estimate.predictedStartTime;
        document.getElementById("retimeSummary").textContent = "可行范围 " + estimate.earliestStartTime + "-" + estimate.latestStartTime + "；推荐 " + estimate.predictedStartTime + "；预计 " + estimate.endTime + " 结束";
      } catch (error) {
        document.getElementById("retimeSummary").textContent = error?.message || "暂时无法反推开始时间";
      }
    }

    function firstSendableTask() {
      return tasks.find((task, index) => !task.skip && !isContinuationLocked(task, index))
        || tasks.find((task) => !task.skip)
        || tasks[0]
        || null;
    }

    function updateRetimeSummary() {
      const summary = document.getElementById("retimeSummary");
      if (!summary) return;
      const count = tasks.filter((task, index) => !task.skip && !isContinuationLocked(task, index)).length;
      const start = document.getElementById("retimeStartTime")?.value || "";
      const mode = document.getElementById("retimeStartMode")?.value || "normal";
      summary.textContent = count
        ? (mode === "reverse" ? "填写结束时间后，将为 " + count + " 条内容反推开始时间" : "将从 " + (start || "当前时间1分钟后") + " 起重排 " + count + " 条可发送内容")
        : "没有可发送内容";
    }

    function collectRetimeIntervals() {
      return {
        differentTuo: retimeInterval("retimeDifferentTuo"),
        sameTuo: retimeInterval("retimeSameTuo"),
        media: retimeInterval("retimeMedia"),
        doumaSame: retimeInterval("retimeDoumaSame"),
        roleSwitch: retimeInterval("retimeRoleSwitch")
      };
    }

    function retimeInterval(prefix) {
      return {
        min: document.getElementById(prefix + "Min")?.value || "",
        max: document.getElementById(prefix + "Max")?.value || ""
      };
    }

    function batchDateOptions() {
      return [
        { label: "今天 " + dateOffsetMonthDay(0), value: dateOffsetMonthDay(0) },
        { label: "明天 " + dateOffsetMonthDay(1), value: dateOffsetMonthDay(1) },
        { label: "后天 " + dateOffsetMonthDay(2), value: dateOffsetMonthDay(2) },
        { label: "大后天 " + dateOffsetMonthDay(3), value: dateOffsetMonthDay(3) },
        { label: "自定义日期", value: "custom" }
      ];
    }

    function updateBatchDateCustomVisibility() {
      const custom = document.getElementById("batchDateCustom");
      const select = document.getElementById("batchDateQuick");
      if (!custom || !select) return;
      custom.hidden = select.value !== "custom";
      if (!custom.hidden) custom.focus();
    }

    function selectedBatchDate() {
      const select = document.getElementById("batchDateQuick");
      if (!select) return "";
      if (select.value !== "custom") return normalizePreviewDate(select.value);
      return normalizePreviewDate(document.getElementById("batchDateCustom")?.value || "");
    }

    function updateDateSummaries() {
      const current = document.getElementById("currentDateSummary");
      if (current) current.textContent = "当前任务日期：" + currentTaskDateSummary();
      const action = document.getElementById("batchDateActionSummary");
      if (!action) return;
      const count = selectedIndexes().length;
      const target = selectedBatchDate() || "待选日期";
      action.textContent = count
        ? "将选中 " + count + " 条改为 " + target + "（点击应用后保存）"
        : "将选中 0 条改为 " + target + "（尚未应用）";
    }

    function initialRecommendedScheduleState() {
      if (initialSchedule?.mode !== "realtime" || initialSchedule?.startMode !== "reverse" || !initialSchedule?.startEstimate) return null;
      const estimate = initialSchedule.startEstimate;
      const sendable = tasks.filter((task) => !task.skip);
      if (!sendable.length) return null;
      const startTime = normalizeClockInputOrTrim(estimate.predictedStartTime || initialSchedule.startTime || "");
      const endTime = normalizeClockInputOrTrim(estimate.endTime || initialSchedule.endTime || "");
      if (!startTime || !endTime || normalizeClockInputOrTrim(sendable[0].time) !== startTime || normalizeClockInputOrTrim(sendable.at(-1).time) !== endTime) return null;
      const currentSignature = previewTaskTimeSignature(tasks);
      if (initialSchedule.taskTimeSignature && initialSchedule.taskTimeSignature !== currentSignature) return null;
      return { startTime, endTime, signature: initialSchedule.taskTimeSignature || currentSignature };
    }

    function recommendedScheduleStateFromEstimate(estimate) {
      return {
        startTime: normalizeClockInputOrTrim(estimate?.predictedStartTime || ""),
        endTime: normalizeClockInputOrTrim(estimate?.endTime || ""),
        signature: previewTaskTimeSignature(tasks)
      };
    }

    function updateRecommendedScheduleSummary() {
      const pill = document.getElementById("recommendedScheduleSummary");
      if (!pill) return;
      const matches = Boolean(recommendedScheduleState?.startTime
        && recommendedScheduleState?.endTime
        && recommendedScheduleState.signature === previewTaskTimeSignature(tasks));
      pill.hidden = !matches;
      pill.textContent = matches
        ? "已按推荐时间排序：" + recommendedScheduleState.startTime + " → " + recommendedScheduleState.endTime
        : "";
    }

    function previewTaskTimeSignature(inputTasks) {
      return JSON.stringify((Array.isArray(inputTasks) ? inputTasks : [])
        .filter((task) => !task?.skip)
        .map((task) => [
          String(task.sourceId || task.order || ""),
          String(task.order || ""),
          String(task.role || ""),
          String(task.speaker || ""),
          String(task.type || ""),
          String(task.interactionGroup || ""),
          String(task.date || ""),
          String(task.time || "")
        ]));
    }

    function currentTaskDateSummary() {
      const dates = Array.from(new Set(tasks.map((task) => normalizePreviewDate(task.date)).filter(Boolean)));
      if (!dates.length) return "未填写";
      if (dates.length === 1) return dates[0];
      return "混合日期 " + dates.join("、");
    }

    function input(field, value, type = "text", readonly = false) {
      return "<input data-field='" + field + "' type='" + type + "' value='" + escapeAttr(value ?? "") + "'" + (readonly ? " readonly" : "") + ">";
    }
    function textarea(field, value, readonly = false) {
      return "<textarea data-field='" + field + "'" + (readonly ? " readonly" : "") + ">" + escapeHtmlJs(value ?? "") + "</textarea>";
    }
    function checkbox(field, value) {
      return "<input data-field='" + field + "' type='checkbox'" + (value ? " checked" : "") + ">";
    }
    function select(field, value, options) {
      return "<select data-field='" + field + "'>" + options.map(([key, label]) => "<option value='" + key + "'" + (key === value ? " selected" : "") + ">" + label + "</option>").join("") + "</select>";
    }
    function fileInput(task) {
      return "<input class='hidden-file' data-upload-for='mediaPath' type='file' accept='" + acceptForType(task.type) + "'>";
    }
    function speakerCell(task, originalIndex) {
      if (!isPreciseTuoTask(task)) return cell(input("speaker", task.speaker));
      return cell(preciseTuoSpeakerPicker(task, originalIndex));
    }
    function preciseTuoSpeakerPicker(task, originalIndex) {
      const selectedPersona = selectedPersonaForTask(task);
      const listId = "tuo-speaker-options-" + originalIndex;
      const options = preciseTuoOptionsForTask(task, selectedPersona);
      return "<div class='speaker-picker' data-precise-speaker-row='1'>" +
        "<div class='speaker-main-row'>" +
          "<div class='persona-note' data-persona-note='1'>" + preciseTuoNote(task, selectedPersona) + "</div>" +
          personaSelect(task, selectedPersona) +
          "<input data-field='speaker' list='" + escapeAttr(listId) + "' value='" + escapeAttr(task.speaker || "") + "' placeholder='托号昵称'>" +
        "</div>" +
        preciseTuoDatalist(listId, options) +
        candidateSelect(task, selectedPersona) +
      "</div>";
    }
    function personaSelect(task, selectedPersona) {
      return "<select data-persona-filter='1'>" + precisePersonaOptions(task).map((option) =>
        "<option value='" + escapeAttr(option.value) + "'" + (option.value === selectedPersona ? " selected" : "") + ">" + escapeHtmlJs(option.label) + "</option>"
      ).join("") + "</select>";
    }
    function preciseTuoDatalist(id, options) {
      return "<datalist id='" + escapeAttr(id) + "'>" + options.map((item) =>
        "<option value='" + escapeAttr(item.nickname || "") + "' label='" + escapeAttr(candidateOptionLabel(item)) + "'></option>"
      ).join("") + "</datalist>";
    }
    function refreshPreciseTuoDatalist(row) {
      const index = Number(row.dataset.index);
      const task = tasks[index];
      if (!task) return;
      const persona = row.querySelector("[data-persona-filter='1']")?.value || "all";
      const datalist = row.querySelector("datalist");
      if (datalist) {
        datalist.innerHTML = preciseTuoOptionsForTask(task, persona).map((item) =>
          "<option value='" + escapeAttr(item.nickname || "") + "' label='" + escapeAttr(candidateOptionLabel(item)) + "'></option>"
        ).join("");
      }
      const note = row.querySelector("[data-persona-note='1']");
      if (note) note.innerHTML = preciseTuoNote(task, persona);
      const list = row.querySelector("[data-candidate-list='1']");
      if (list) list.outerHTML = candidateSelect(task, persona);
    }
    function isPreciseTuoTask(task) {
      return preciseTuoEnabled && task?.role === "tuo" && task?.tuoAssignment?.mode === "precise_roster";
    }
    function selectedPersonaForTask(task) {
      const saved = String(task?.tuoAssignment?.selectedPersona || "").trim();
      if (saved) return saved;
      return firstPersonaLabel(currentPreciseCandidate(task) || task?.tuoAssignment?.primary) || "all";
    }
    function precisePersonaOptions(task) {
      const personas = new Set();
      for (const item of allPreciseTuoOptions(task)) {
        for (const label of candidatePersonaLabels(item)) {
          if (label) personas.add(label);
        }
      }
      const ordered = Array.from(personas);
      return [
        { value: "all", label: "全部人设" },
        ...ordered.map((label) => ({ value: label, label }))
      ];
    }
    function preciseTuoOptionsForTask(task, persona) {
      const selected = String(persona || "all");
      const options = allPreciseTuoOptions(task);
      if (selected === "all") return options;
      return options.filter((item) => preciseCandidateMatchesPersona(item, selected));
    }
    function allPreciseTuoOptions(task) {
      const sources = [
        ...(Array.isArray(task?.tuoAssignment?.candidates) ? task.tuoAssignment.candidates : []),
        ...(task?.tuoAssignment?.primary?.nickname ? [task.tuoAssignment.primary] : []),
        ...(Array.isArray(preciseTuoRosterOptions) ? preciseTuoRosterOptions : [])
      ];
      const seen = new Set();
      const result = [];
      for (const item of sources) {
        const nickname = String(item?.nickname || "").trim();
        const key = preciseCandidateIdentity(item);
        if (!key || seen.has(key)) continue;
        seen.add(key);
        result.push(item);
      }
      return result;
    }
    function currentPreciseCandidate(task) {
      const primaryId = preciseCandidateIdentity(task?.tuoAssignment?.primary || {});
      if (primaryId) {
        const primary = allPreciseTuoOptions(task).find((item) => preciseCandidateIdentity(item) === primaryId);
        if (primary) return primary;
      }
      const key = normalizeTuoKey(task?.speaker || "");
      return allPreciseTuoOptions(task).find((item) => normalizeTuoKey(item.nickname) === key) || null;
    }
    function preciseTuoNote(task, persona) {
      return "<div class='current-candidate'>" +
        "<span class='current-label'>在用</span>" +
      "</div>";
    }
    function candidateOptionLabel(item) {
      return candidateSummary(item, item?.nickname || "");
    }
    function candidateSelect(task, persona) {
      const recommended = recommendedPreciseCandidates(task, persona).slice(0, 2);
      const groups = alternatePreciseCandidateGroups(task, persona);
      const options = [
        "<option value=''>选择备选托</option>",
        groups.compatible.length
          ? "<optgroup label='同人设'>" + groups.compatible.map((item) => candidateOption(item, "同人设：")).join("") + "</optgroup>"
          : "",
        groups.crossPersona.length
          ? "<optgroup label='跨人设（手动选择）'>" + groups.crossPersona.map((item) => candidateOption(item, "跨人设：")).join("") + "</optgroup>"
          : ""
      ].join("");
      const shortage = candidateShortageMessage(task, persona, recommended.length)
        || String(task?.tuoAssignment?.candidateRotationNote || "").trim();
      return "<div class='candidate-list' data-candidate-list='1'>" +
        "<div></div><div class='candidate-section-label'>备选</div>" +
        "<div class='candidate-picks'>" +
          recommended.map((item, index) =>
            "<button class='candidate-pick" + (item.backup ? " backup" : "") + "' type='button' data-candidate-pick='" + escapeAttr(preciseCandidateIdentity(item)) + "'>" +
              candidateDisplay(item, index === 0 ? "①" : "②") +
            "</button>"
          ).join("") +
        "</div>" +
        (shortage ? "<div></div><div></div><div class='candidate-shortage' data-candidate-shortage='1'>" + escapeHtmlJs(shortage) + "</div>" : "") +
        "<div></div><div class='candidate-section-label'>更多</div><select data-candidate-select='1'>" + options + "</select>" +
      "</div>";
    }
    function candidateOption(item, prefix) {
      return "<option value='" + escapeAttr(preciseCandidateIdentity(item)) + "'>" + escapeHtmlJs(prefix + candidateSummary(item, item.nickname || "")) + "</option>";
    }
    function candidateShortageMessage(task, persona, count) {
      if (count >= 2) return "";
      const savedPersona = String(task?.tuoAssignment?.selectedPersona || "");
      const savedReason = String(task?.tuoAssignment?.candidateShortageReason || "").trim();
      if (savedReason && String(persona || "all") === String(savedPersona || "all")) return savedReason;
      if (count > 0) return "当前人设仅找到 " + count + " 个备选，不会跨人设强行补足";
      return "当前人设没有其他符合条件的托，不会跨人设强行补足";
    }
    function recommendedPreciseCandidates(task, persona) {
      const selected = String(persona || "all");
      const currentKey = preciseCandidateIdentity(currentPreciseCandidate(task) || {});
      const source = Array.isArray(task?.tuoAssignment?.candidates) ? task.tuoAssignment.candidates : [];
      const seen = new Set();
      const result = [];
      for (const item of source) {
        const key = preciseCandidateIdentity(item);
        if (!key || key === currentKey || seen.has(key)) continue;
        if (selected !== "all" && !preciseCandidateMatchesPersona(item, selected)) continue;
        seen.add(key);
        result.push(item);
      }
      return result;
    }
    function alternatePreciseCandidateGroups(task, persona) {
      const currentKey = preciseCandidateIdentity(currentPreciseCandidate(task) || {});
      const compatible = [];
      const crossPersona = [];
      for (const item of allPreciseTuoOptions(task)) {
        const key = preciseCandidateIdentity(item);
        if (!key || key === currentKey) continue;
        if (String(persona || "all") === "all" || preciseCandidateMatchesPersona(item, persona)) compatible.push(item);
        else crossPersona.push(item);
      }
      return { compatible, crossPersona };
    }
    function preciseCandidateIdentity(item) {
      return String(item?.accountId || item?.externalAccountId || normalizeTuoKey(item?.nickname || ""));
    }
    function preciseCandidateMatchesPersona(item, persona) {
      const required = precisePersonaTags(persona);
      if (!required.length) return true;
      const tags = new Set(Array.isArray(item?.tags) ? item.tags : []);
      return required.every((tag) => tags.has(tag));
    }
    function precisePersonaTags(persona) {
      const text = String(persona || "").trim();
      if (!text || text === "all" || text === "全部人设") return [];
      const tags = [];
      if (/宝妈|妈妈|带娃|母婴/.test(text)) tags.push("mom");
      if (/工作|上班|职场|办公室/.test(text)) tags.push("work");
      if (/学生|大学生/.test(text)) tags.push("student");
      if (/成熟女性|成熟|中年|年纪大|4[0-9]\+|5[0-9]\+/.test(text)) tags.push("mature");
      if (/年轻女性|年轻|少女|2[5-9]\+/.test(text)) tags.push("young");
      if (/女性|女/.test(text)) tags.push("female");
      if (/男性|男/.test(text)) tags.push("male");
      return Array.from(new Set(tags));
    }
    function candidateSummary(item, fallbackName = "") {
      const name = String(item?.nickname || fallbackName || "").trim();
      const personas = candidatePersonaLabels(item);
      const aux = Array.isArray(item?.auxTags) ? item.auxTags : [];
      const parts = [name || "未匹配名单"];
      if (personas.length) parts.push(personas.join("/"));
      if (aux.length) parts.push(aux.join("/"));
      if (item?.backup) parts.push("备用");
      return parts.filter(Boolean).join("｜");
    }
    function candidateDisplay(item, prefix = "") {
      const name = String(item?.nickname || "").trim() || "未匹配名单";
      return (prefix ? "<span class='candidate-prefix'>" + escapeHtmlJs(prefix) + "</span>" : "") +
        "<span class='candidate-text'>" + escapeHtmlJs(name) + "</span>" +
        candidateMetaHtml(item) +
        (item?.backup ? "<span class='backup-tag'>备用</span>" : "");
    }
    function candidateMetaHtml(item = {}) {
      const labels = [
        ...candidatePersonaLabels(item),
        ...(Array.isArray(item?.auxTags) ? item.auxTags : [])
      ].filter(Boolean);
      if (!labels.length) return "";
      return "<span class='candidate-meta'>" + escapeHtmlJs(labels.join(" / ")) + "</span>";
    }
    function candidatePersonaLabels(item = {}) {
      if (Array.isArray(item.personas) && item.personas.length) return item.personas.filter(Boolean);
      return (item.tags || []).map(personaLabel).filter(Boolean);
    }
    function firstPersonaLabel(item = {}) {
      return candidatePersonaLabels(item)[0] || "";
    }
    function personaLabel(tag) {
      if (tag === "mom") return "宝妈";
      if (tag === "work") return "工作";
      if (tag === "young") return "年轻女性";
      if (tag === "mature") return "成熟女性";
      if (tag === "female") return "女性";
      if (tag === "male") return "男性";
      return "";
    }
    function normalizeTuoKey(value) {
      return String(value || "").replace(/\s+/g, "").toLowerCase();
    }
    function dateCell(originalIndex, task) {
      return cell(input("date", task.date) + "<div class='subnote'>原日期：" + escapeHtmlJs(task.documentDate || "未记录") + "</div>");
    }
    function timeCell(originalIndex, task) {
      const warning = String(task?.timeWarning || "").trim();
      return cell(input("time", task.time) +
        "<div class='subnote'>原时间：" + escapeHtmlJs(originalTimes[originalIndex]?.time || "-") + "</div>" +
        (warning ? "<div class='row-note error'>" + escapeHtmlJs(warning) + "</div>" : ""));
    }
    function contentCell(task) {
      const details = debugDetails(task);
      const warning = previewWarningNote(task);
      if (isTextLikeType(task.type)) {
        return cell("<div class='content-grid'>" + warning + textarea("text", task.text) + textDetailButton(task) + recoveryConfirmButton(task) + hiddenMediaField(task) + details + "</div>");
      }
      return cell("<div class='content-grid'>" + warning + hiddenTextField(task) + mediaCell(task) + details + "</div>");
    }
    function previewWarningNote(task) {
      const warnings = [task?.previewWarning, task?.timeWarning].map((item) => String(item || "").trim()).filter(Boolean);
      return warnings.map((warning) => "<div class='row-note warning'>" + escapeHtmlJs(warning) + "</div>").join("");
    }
    function textDetailButton(task) {
      return "<div class='content-actions'><button class='small-btn ghost' type='button' data-action='view-text-detail'>" + escapeHtmlJs(textDetailButtonLabel(task)) + "</button></div>";
    }
    function textDetailButtonLabel(task) {
      const length = String(task?.text || "").length;
      return "查看详情" + (length ? "（" + length + "字）" : "");
    }
    function mediaCell(task) {
      const path = task.mediaPath || "";
      const disabled = isTextLikeType(task.type) ? " disabled" : "";
      const confirmRecovered = task.recoveryRequired && path ? recoveryConfirmButton(task) : "";
      return "<div class='media-box media-drop-zone' data-media-drop-zone='1'>" +
        mediaThumb(task) +
        "<div>" +
          "<span class='tag'>" + typeLabel(task.type) + "</span>" +
          input("mediaPath", path) +
          "<div class='preview-path'>" + escapeHtmlJs(shortPath(path) || (isMediaRecoveryPending(task) ? "系统正在获取素材" : "未选择素材")) + "</div>" +
          "<div class='media-status' data-media-status data-path='" + escapeAttr(path) + "'>正在检查素材状态...</div>" +
          fileInput(task) +
          "<div class='media-tools'><button class='small-btn ghost' data-action='choose-media'" + disabled + ">更换素材</button>" + confirmRecovered + "</div>" +
          "<div class='media-hint'>可拖拽素材到这里，或复制图片后在本行 Ctrl+V 粘贴。</div>" +
        "</div>" +
      "</div>";
    }
    function recoveryConfirmButton(task) {
      if (!task?.recoveryRequired) return "";
      return "<button class='small-btn' type='button' data-action='confirm-recovered-media'>确认本行内容及归属</button>";
    }
    function mediaThumb(task) {
      const src = mediaPreviewSrc(task.mediaPath);
      if (!src || isTextLikeType(task.type)) {
        const label = isMediaRecoveryPending(task) ? "自动获取中" : String(task?.mediaRecoveryState || "") === "failed" ? "素材缺失" : "无素材";
        return "<div class='thumb'>" + label + "</div>";
      }
      const attrs = " class='thumb media-thumb' data-media-popover-src='" + escapeAttr(src) + "' data-media-popover-type='" + escapeAttr(task.type) + "' title='点击放大检查素材'";
      if (task.type === "video") return "<div" + attrs + "><video src='" + escapeAttr(src) + "' muted></video></div>";
      return "<div" + attrs + "><img src='" + escapeAttr(src) + "' alt='素材预览'></div>";
    }
    function mediaPreviewSrc(value) {
      const text = String(value || "").trim();
      if (!text) return "";
      if (/^https?:\\/\\//i.test(text)) return "";
      if (/^data:/i.test(text)) return text;
      return "/api/media-preview?path=" + encodeURIComponent(text);
    }
    function showContentDetailModal(task = {}, taskIndex = "") {
      const modal = document.getElementById("contentDetailModal");
      const text = document.getElementById("contentDetailText");
      const meta = document.getElementById("contentDetailMeta");
      modal.dataset.taskIndex = String(taskIndex ?? "");
      meta.textContent = contentDetailLabel(task);
      text.value = task.text || "";
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      setTimeout(() => text.focus(), 0);
    }
    function contentDetailLabel(task = {}) {
      return [typeLabel(task.type), task.speaker || "", task.date || "", task.time || ""].filter(Boolean).join(" / ") || "当前内容";
    }
    function closeContentDetailModal() {
      const modal = document.getElementById("contentDetailModal");
      if (!modal) return;
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    }
    async function refreshMediaStatuses() {
      const nodes = Array.from(document.querySelectorAll("[data-media-status]"));
      await Promise.all(nodes.map(async (node) => {
        const row = node.closest("tr[data-index]");
        const task = row ? tasks[Number(row.dataset.index)] : null;
        if (isMediaRecoveryPending(task)) {
          node.textContent = String(task.mediaRecoveryMessage || "系统正在自动补齐素材");
          node.className = "media-status recovering";
          return;
        }
        const value = node.dataset.path || "";
        if (!value) {
          node.textContent = String(task?.mediaRecoveryState || "") === "failed"
            ? String(task?.mediaRecoveryMessage || "素材自动恢复后仍缺失")
            : "未选择素材";
          node.className = "media-status bad";
          return;
        }
        const result = await fetch("/api/media-status?path=" + encodeURIComponent(value)).then((res) => res.json()).catch((error) => ({ ok: false, message: error?.message || String(error) }));
        const origin = String(task?.mediaRecoveryState || "");
        const prefix = origin === "auto_recovered" ? "已自动补齐 · " : origin === "manual" ? "已手动补充 · " : "";
        node.textContent = prefix + (result.message || (result.ok ? "素材可用" : "素材不可用"));
        node.className = result.ok ? (prefix ? "media-status good" : "media-status") : "media-status bad";
      }));
    }
    function cell(html) { return "<td>" + html + "</td>"; }
    function execCell(originalIndex, task) {
      const manual = isManualTask(task) ? "<span class='manual-badge'>手动新增</span>" : "";
      return "<td class='index-cell'><strong>" + (originalIndex + 1) + "</strong><div class='subnote'>执行顺序</div>" + manual + hiddenInput("order", task.order, "number") + hiddenInput("submitIdentity", task.submitIdentity || "") + "</td>";
    }
    function rowCheckbox(originalIndex) {
      return "<input type='checkbox' data-select-row='1'" + (selectedRows.has(originalIndex) ? " checked" : "") + ">";
    }
    function applyRowSelectionDrag(row) {
      if (!rowSelectDrag) return;
      const index = Number(row.dataset.index);
      if (!Number.isFinite(index) || rowSelectDrag.seen.has(index)) return;
      rowSelectDrag.seen.add(index);
      if (rowSelectDrag.checked) selectedRows.add(index);
      else selectedRows.delete(index);
      const checkbox = row.querySelector("input[data-select-row='1']");
      if (checkbox) checkbox.checked = rowSelectDrag.checked;
      updateViewControls();
    }
    function finishRowSelectionDrag() {
      if (!rowSelectDrag) return;
      rowSelectDrag = null;
      document.body.classList.remove("row-select-dragging");
      suppressRowSelectClickUntil = Date.now() + 250;
    }
    function skipCell(task) {
      return cell(checkbox("skip", task.skip) + "<div class='subnote'>" + (task.skip ? "不发，创建时跳过" : "要发") + "</div>");
    }
    function debugDetails(task) {
      return "<details class='debug'><summary>高级/调试信息</summary><div class='debug-grid'>" +
        (task.legacySpeakerAudit === "unverified" ? "<div class='legacy-speaker-audit'>历史说话人核对信息未确认：缺少可核实的原始采集依据，未判定当前说话人错误。</div>" : "") +
        debugField("interactionGroup", input("interactionGroup", task.interactionGroup)) +
        debugField("continueMarker", checkbox("continueMarker", task.continueMarker)) +
        debugField("cleanSpeaker", input("cleanSpeaker", task.cleanSpeaker)) +
        debugField("sourceId", input("sourceId", task.sourceId, "text", true)) +
        debugField("原文位置", textarea("sourceOccurrenceIds", (task.sourceOccurrenceIds || []).join("\\n"), true)) +
        debugField("原文说话人", input("sourceSpeaker", task.sourceSpeaker || "", "text", true)) +
        debugField("sourceText", textarea("sourceText", task.sourceText, true)) +
        debugField("修复的缺失 sourceId", input("repairsSourceIds", task.repairsSourceIds || "")) +
        debugField("已人工确认对应关系", checkbox("importResolutionConfirmed", task.importResolutionConfirmed === true)) +
      "</div></details>";
    }
    function debugField(label, control) {
      return "<label>" + label + control + "</label>";
    }
    function hiddenInput(field, value, type = "text") {
      return "<input data-field='" + field + "' type='" + type + "' value='" + escapeAttr(value ?? "") + "' hidden>";
    }
    function hiddenMediaField(task) {
      return "<input data-field='mediaPath' value='" + escapeAttr(task.mediaPath || "") + "' hidden>";
    }
    function hiddenTextField(task) {
      return "<textarea data-field='text' hidden>" + escapeHtmlJs(task.text || "") + "</textarea>";
    }
    function typeLabel(type) {
      if (type === "image") return "图片";
      if (type === "sticker") return "表情包";
      if (type === "video") return "视频";
      if (type === "finder") return "视频号";
      if (type === "unknown-media") return "待确认素材";
      return "文字";
    }
    function isTextLikeType(type) {
      return type === "text" || type === "finder";
    }
    ${isCompleteFinderXml.toString()}
    function isManualTask(task) {
      return /^manual-/i.test(String(task.sourceId || "")) || String(task.sourceText || "") === "手动新增";
    }
    function shortPath(value) {
      const text = String(value || "").trim();
      if (!text) return "";
      if (/^https?:\\/\\//i.test(text) || /^blob:/i.test(text)) return text;
      return text.split(/[\\\\\\/]/).slice(-3).join("\\\\");
    }
    function acceptForType(type) {
      if (type === "video") return ".mp4,.mov,.webm,video/*";
      if (type === "sticker") return ".gif,.webp,.png,.jpg,.jpeg,image/gif,image/webp,image/png,image/jpeg";
      return ".jpg,.jpeg,.png,.webp,.gif,image/*";
    }
    function toggleMediaPopover(target) {
      if (mediaPopoverTarget === target) {
        hideMediaPopover();
        return;
      }
      showMediaPopover(target);
    }
    function showMediaPopover(target) {
      const popover = document.getElementById("mediaPopover");
      const src = target.dataset.mediaPopoverSrc || "";
      const type = target.dataset.mediaPopoverType || "image";
      if (!popover || !src) return;
      popover.innerHTML = type === "video"
        ? "<video src='" + escapeAttr(src) + "' muted autoplay loop playsinline></video>"
        : "<img src='" + escapeAttr(src) + "' alt='素材放大预览'>";
      popover.classList.add("open");
      popover.setAttribute("aria-hidden", "false");
      mediaPopoverTarget = target;
      positionMediaPopover(target, popover);
      const video = popover.querySelector("video");
      if (video) video.play().catch(() => {});
    }
    function hideMediaPopover() {
      const popover = document.getElementById("mediaPopover");
      if (!popover) return;
      popover.classList.remove("open");
      popover.setAttribute("aria-hidden", "true");
      popover.innerHTML = "";
      mediaPopoverTarget = null;
    }
    function positionMediaPopover(target, popover) {
      const rect = target.getBoundingClientRect();
      const gap = 10;
      const margin = 12;
      const width = popover.offsetWidth || 286;
      const height = popover.offsetHeight || 260;
      let left = rect.right + gap;
      let top = rect.top;
      if (left + width > window.innerWidth - margin) left = rect.left - width - gap;
      if (left < margin) left = Math.max(margin, window.innerWidth - width - margin);
      if (top + height > window.innerHeight - margin) top = window.innerHeight - height - margin;
      if (top < margin) top = margin;
      popover.style.left = left + "px";
      popover.style.top = top + "px";
    }
    function setThumbPopover(thumb, src, type) {
      if (!thumb) return;
      if (src && !isTextLikeType(type)) {
        thumb.classList.add("media-thumb");
        thumb.dataset.mediaPopoverSrc = src;
        thumb.dataset.mediaPopoverType = type || "image";
        thumb.title = "点击放大检查素材";
        return;
      }
      thumb.classList.remove("media-thumb");
      delete thumb.dataset.mediaPopoverSrc;
      delete thumb.dataset.mediaPopoverType;
      thumb.removeAttribute("title");
    }
    function validDate(value) {
      const text = String(value || "").trim();
      return /^\\d{1,2}\\s*[\\/月-]\\s*\\d{1,2}\\s*日?$/.test(text) || /^\\d{4}-\\d{1,2}-\\d{1,2}$/.test(text);
    }
    function normalizePreviewDate(value) {
      const text = String(value || "").trim();
      const ymd = text.match(/^\\d{4}-(\\d{1,2})-(\\d{1,2})$/);
      if (ymd) return Number(ymd[1]) + "/" + Number(ymd[2]);
      const md = text.match(/^(\\d{1,2})\\s*[\\/月-]\\s*(\\d{1,2})\\s*日?$/);
      if (md) return Number(md[1]) + "/" + Number(md[2]);
      return text;
    }
    function validTime(value) {
      const match = normalizeClockInput(value).match(/^(\\d{1,2}):(\\d{1,2}):(\\d{1,2})$/);
      if (!match) return false;
      const h = Number(match[1]), m = Number(match[2]), s = Number(match[3] || 0);
      return h >= 0 && h <= 23 && m >= 0 && m <= 59 && s >= 0 && s <= 59;
    }
    function normalizeClockInputOrTrim(value) {
      const normalized = normalizeClockInput(value);
      return normalized || String(value || "").trim();
    }
    function normalizeClockInput(value) {
      const raw = String(value || "").trim();
      if (!raw) return "";
      const text = raw.replace(/[：﹕]/g, ":").replace(/\\s*:\\s*/g, ":").replace(/\\s+/g, " ").trim();
      const separated = text.match(/^(\\d{1,2})(?::|\\s+)(\\d{1,2})(?:(?::|\\s+)(\\d{1,2}))?$/);
      if (separated) return formatClockParts(separated[1], separated[2], separated[3] || 0);
      const compact = text.replace(/\\s+/g, "");
      if (/^\\d{3}$/.test(compact)) return formatClockParts(compact.slice(0, 1), compact.slice(1), 0);
      if (/^\\d{4}$/.test(compact)) return formatClockParts(compact.slice(0, 2), compact.slice(2), 0);
      if (/^\\d{5}$/.test(compact)) return formatClockParts(compact.slice(0, 1), compact.slice(1, 3), compact.slice(3));
      if (/^\\d{6}$/.test(compact)) return formatClockParts(compact.slice(0, 2), compact.slice(2, 4), compact.slice(4));
      return "";
    }
    function formatClockParts(hourValue, minuteValue, secondValue) {
      const h = Number(hourValue), m = Number(minuteValue), s = Number(secondValue);
      if (!Number.isInteger(h) || !Number.isInteger(m) || !Number.isInteger(s)) return "";
      if (h < 0 || h > 23 || m < 0 || m > 59 || s < 0 || s > 59) return "";
      return pad2(h) + ":" + pad2(m) + ":" + pad2(s);
    }
    function mediaPathMatchesType(value, type) {
      const text = String(value || "").toLowerCase();
      if (/^https?:\\/\\//.test(text) || /^sample:\\/\\//.test(text)) return true;
      if (type === "video") return /\\.(mp4|mov|webm)$/.test(text);
      if (type === "sticker") return /\\.(gif|webp|png|jpg|jpeg)$/.test(text);
      if (type === "image") return /\\.(jpg|jpeg|png|webp)$/.test(text);
      return true;
    }
    function pad2(value) {
      return String(value).padStart(2, "0");
    }
    function escapeAttr(value) { return String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;"); }
    function escapeHtmlJs(value) { return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;"); }
    async function postJson(url, data) {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      return response.json();
    }
    async function getJson(url) {
      const response = await fetch(url);
      return response.json();
    }
    async function postForm(url, data) {
      const response = await fetch(url, { method: "POST", body: data });
      return response.json();
    }
    function setStatus(message, error = false) {
      const el = document.getElementById("status");
      el.textContent = message || "";
      el.className = error ? "status error" : "status";
    }
    function markDirty(message = "有修改，正在自动保存预览内容") {
      dirty = true;
      window.__v2PreviewDirty = true;
      saveFailed = false;
      if (libraryItem) {
        libraryUnsavedChanges = true;
        setStatus("文案库预览有修改，正在自动保存本次预览；不会覆盖原文案。确认创建时可选择覆盖、另存或仅本次使用。");
        scheduleAutoSave();
        return;
      }
      setStatus(message);
      scheduleAutoSave();
    }
    function scheduleAutoSave() {
      if (autoSaveTimer) clearTimeout(autoSaveTimer);
      autoSaveTimer = setTimeout(async () => {
        autoSaveTimer = null;
        if (!dirty) return;
        await savePreview({ auto: true });
      }, 900);
    }
    function openConsole(resultOrUrl) {
      const target = typeof resultOrUrl === "string" ? resultOrUrl : (resultOrUrl?.consoleUrl || consoleUrl);
      if (!target) return setStatus("没有控制台地址，无法自动返回。请从 2.0 控制台重新打开预览页。", true);
      if (resumeAfterEdit) {
        location.href = target;
        return;
      }
      if (typeof resultOrUrl === "object" && resultOrUrl?.focusedConsole) {
        setStatus("已切回控制台；当前预览页已保留。");
        return;
      }
      setStatus("当前预览页已保留；请手动切回原控制台标签页。");
    }
    function todayMonthDay() {
      return dateOffsetMonthDay(0);
    }
    function currentClock() {
      const now = new Date();
      return pad2(now.getHours()) + ":" + pad2(now.getMinutes()) + ":" + pad2(now.getSeconds());
    }
    function dateOffsetMonthDay(offsetDays) {
      const now = new Date();
      now.setDate(now.getDate() + Number(offsetDays || 0));
      return (now.getMonth() + 1) + "/" + now.getDate();
    }
    function formatTime(value) {
      if (!value) return "";
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return value;
      return pad2(date.getHours()) + ":" + pad2(date.getMinutes()) + ":" + pad2(date.getSeconds());
    }
  </script>
</body>
</html>`;
}

async function readJsonBody(req) {
  const raw = await readRawBody(req);
  const text = raw.toString("utf8");
  return text ? JSON.parse(text) : {};
}

async function loadPreviewPageMeta(runDir, state) {
  const report = await readJsonIfExists(path.join(runDir, "console-generate-report.json"));
  const preciseTuoReport = await readJsonIfExists(path.join(runDir, "precise-tuo-report.json"));
  const diagnostics = await readJsonIfExists(path.join(runDir, "collect-diagnostics.json"));
  const librarySource = await readJsonIfExists(path.join(runDir, "library-source.json"));
  const libraryMeta = await readJsonIfExists(path.join(runDir, "library-meta.json"));
  const savedRetime = await readJsonIfExists(path.join(runDir, PREVIEW_RETIME_SETTINGS_FILE));
  const robotStrategy = normalizeRobotStrategy(
    librarySource.robotStrategy
    || report.robotStrategy
    || libraryMeta.settingsSnapshot?.robotStrategy
  );
  const previewTasks = await readJsonIfExists(finalPreviewPath(runDir));
  const preciseReport = Object.keys(preciseTuoReport).length ? preciseTuoReport : (report.preciseTuo || {});
  const tuoTaskCount = Number(preciseReport.tuoTaskCount || (Array.isArray(previewTasks) ? previewTasks.filter((task) => task?.role === "tuo" && !task?.skip).length : 0));
  const assignedCount = Number(preciseReport.assignedCount || (Array.isArray(previewTasks) ? previewTasks.filter((task) => task?.role === "tuo" && task?.tuoAssignment?.mode === "precise_roster").length : 0));
  const rosterPath = String(preciseReport.rosterPath || "");
  const rosterName = rosterPath ? path.basename(rosterPath) : (assignedCount ? "本轮保存的人设分配" : "未记录");
  const configSource = librarySource.id || librarySource.combined
    ? (librarySource.configMode === "current" ? "当前页面配置" : librarySource.configMode === "saved" ? "文案库原配置" : "文案库配置")
    : (report.robotStrategy ? "本次生成配置" : "未记录");
  const modeSummary = robotStrategy === "precise"
    ? {
      title: "本轮模式：精细托 · 按人设名单分配",
      details: `名单：${rosterName}；有效分配 ${assignedCount}/${tuoTaskCount} 条托任务；配置来源：${configSource}。`
    }
    : robotStrategy === "random"
      ? { title: "本轮模式：粗略版 · 随机托", details: `配置来源：${configSource}。本页后来打开控制台切换模式，不会改变这份预览。` }
      : { title: "本轮模式：模式待确认", details: `这份旧预览没有可靠的本轮模式记录；配置来源：${configSource}。系统不会根据说话人名称猜测模式。` };
  const libraryRecord = librarySource.id || librarySource.combined ? librarySource : libraryMeta;
  const libraryItem = libraryRecord.id || libraryRecord.combined ? {
    id: libraryRecord.id || "combined",
    name: libraryRecord.name || "",
    taskCount: libraryRecord.taskCount || (Array.isArray(previewTasks) ? previewTasks.length : 0),
    combined: libraryRecord.combined === true,
    segments: Array.isArray(libraryRecord.segments) ? libraryRecord.segments : []
  } : null;
  const libraryDefaultDate = String(librarySource.defaultDate || "").trim();
  return {
    runId: path.basename(path.resolve(runDir)),
    libraryItem,
    libraryDateNotice: libraryItem && libraryDefaultDate
      ? `已按今天 ${libraryDefaultDate} 更新文案库预览日期；原文案库不会被覆盖。请确认日期无误后再创建。`
      : "",
    robotStrategy,
    modeSummary,
    schedule: hasPreviewSchedule(savedRetime)
      ? savedRetime
      : (hasPreviewSchedule(report.schedule) ? report.schedule : (librarySource.schedule || {})),
    defaultDate: report.readRange?.baseSendDate || "",
    rangeLabel: report.readRange?.label || (report.readRange?.mode === "full" ? "全文读取" : ""),
    rawEventCount: report.rawEventCount ?? diagnostics.collectedEventCount,
    previewTaskCount: report.previewTaskCount ?? state?.tasks?.length,
    preciseTuoRosterOptions: Array.isArray(preciseTuoReport.rosterOptions)
      ? preciseTuoReport.rosterOptions
      : (Array.isArray(report.preciseTuo?.rosterOptions) ? report.preciseTuo.rosterOptions : [])
  };
}

function hasPreviewSchedule(value) {
  return Boolean(value && typeof value === "object" && !Array.isArray(value)
    && (value.mode || value.startTime || value.endTime || Object.keys(value.intervals || {}).length));
}

async function writeJsonAtomic(filePath, value) {
  const temporary = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(temporary, JSON.stringify(value, null, 2), "utf8");
  await fs.rename(temporary, filePath);
}

function normalizePreviewTasksForRobotStrategy(tasks, robotStrategy = "") {
  const strategy = normalizeRobotStrategy(robotStrategy);
  if (strategy === "precise") return tasks;
  if (!strategy) return tasks;
  return (Array.isArray(tasks) ? tasks : []).map((task) => {
    if (task?.role !== "tuo" || !task?.tuoAssignment) return task;
    const next = { ...task };
    delete next.tuoAssignment;
    return next;
  });
}

function normalizeRobotStrategy(value) {
  const strategy = String(value || "").trim();
  return ["random", "fixed", "precise"].includes(strategy) ? strategy : "";
}

async function readJsonIfExists(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return {};
  }
}

async function readRawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function saveUploadedMedia(req, runDir) {
  const parsed = parseMultipartFormData(await readRawBody(req), req.headers["content-type"] || "");
  const file = parsed.files[0];
  if (!file?.body?.length) {
    throw new Error("没有收到素材文件。");
  }
  const type = String(parsed.fields.type || "").trim();
  const extension = normalizedMediaExtension(file.filename, type);
  if (!extension) {
    throw new Error(`素材类型不匹配：${type || "未知"} / ${file.filename || ""}`);
  }
  const cacheDir = path.join(runDir, "manual-media-cache");
  await fs.mkdir(cacheDir, { recursive: true });
  const base = sanitizeFilename(path.basename(file.filename || `media${extension}`, path.extname(file.filename || ""))) || "media";
  const hash = crypto.createHash("sha1").update(file.body).digest("hex").slice(0, 10);
  const localPath = path.join(cacheDir, `${Date.now()}-${hash}-${base}${extension}`);
  await fs.writeFile(localPath, file.body);
  return {
    path: localPath,
    previewUrl: `/api/media-preview?path=${encodeURIComponent(localPath)}`,
    size: file.body.length
  };
}

function parseMultipartFormData(buffer, contentType) {
  const boundaryMatch = String(contentType || "").match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!boundaryMatch) throw new Error("上传请求缺少 boundary。");
  const boundary = Buffer.from(`--${boundaryMatch[1] || boundaryMatch[2]}`);
  const fields = {};
  const files = [];
  let offset = buffer.indexOf(boundary);
  while (offset >= 0) {
    const next = buffer.indexOf(boundary, offset + boundary.length);
    if (next < 0) break;
    let part = buffer.subarray(offset + boundary.length, next);
    if (part.subarray(0, 2).toString() === "--") break;
    if (part.subarray(0, 2).toString() === "\r\n") part = part.subarray(2);
    if (part.subarray(-2).toString() === "\r\n") part = part.subarray(0, -2);
    const headerEnd = part.indexOf(Buffer.from("\r\n\r\n"));
    if (headerEnd > 0) {
      const headerText = part.subarray(0, headerEnd).toString("utf8");
      const body = part.subarray(headerEnd + 4);
      const disposition = headerText.match(/content-disposition:[^\n]+/i)?.[0] || "";
      const name = disposition.match(/name="([^"]+)"/i)?.[1] || "";
      const filename = disposition.match(/filename="([^"]*)"/i)?.[1] || "";
      if (filename) files.push({ name, filename, body });
      else if (name) fields[name] = body.toString("utf8");
    }
    offset = next;
  }
  return { fields, files };
}

async function sendMediaPreview(req, res, mediaPath) {
  const filePath = String(mediaPath || "").trim();
  if (!filePath || /^[a-z]+:\/\//i.test(filePath)) {
    sendJson(res, 400, { ok: false, error: "只能预览本地素材路径。" });
    return;
  }
  let stat;
  try {
    stat = await fs.stat(filePath);
  } catch {
    sendJson(res, 404, { ok: false, error: "素材不存在。" });
    return;
  }
  if (!stat.isFile()) {
    sendJson(res, 400, { ok: false, error: "素材路径不是文件。" });
    return;
  }
  res.writeHead(200, {
    "Content-Type": mediaContentType(filePath),
    "Content-Length": stat.size,
    "Cache-Control": "no-store"
  });
  createReadStream(filePath).pipe(res);
}

async function mediaStatus(mediaPath) {
  const filePath = String(mediaPath || "").trim();
  if (!filePath) return { ok: false, message: "未选择素材" };
  if (/^(blob:|image-blob:)/i.test(filePath)) return { ok: false, message: "浏览器临时素材地址，需重新生成预览或更换成本地文件" };
  if (/^data:/i.test(filePath)) return { ok: true, message: "内嵌素材可用" };
  if (/^https?:\/\//i.test(filePath)) {
    return { ok: false, message: "远程地址未落地，保存时会尝试下载到本地 media-cache" };
  }
  if (/^sample:\/\//i.test(filePath)) {
    return { ok: true, message: "测试素材可用" };
  }
  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile() || stat.size <= 0) return { ok: false, message: "素材文件无效" };
    return { ok: true, message: `本地素材可用（${Math.ceil(stat.size / 1024)}KB）` };
  } catch {
    return { ok: false, message: "素材不存在" };
  }
}

function normalizedMediaExtension(filename, type) {
  const ext = path.extname(String(filename || "")).toLowerCase();
  if (type === "video") return [".mp4", ".mov", ".webm"].includes(ext) ? ext : "";
  if (type === "sticker") return [".gif", ".webp", ".png", ".jpg", ".jpeg"].includes(ext) ? ext : "";
  if (type === "image") return [".jpg", ".jpeg", ".png", ".webp", ".gif"].includes(ext) ? ext : "";
  return [".jpg", ".jpeg", ".png", ".webp", ".gif", ".mp4", ".mov", ".webm"].includes(ext) ? ext : "";
}

function mediaContentType(filename) {
  const ext = path.extname(String(filename || "")).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  if (ext === ".gif") return "image/gif";
  if (ext === ".mp4") return "video/mp4";
  if (ext === ".mov") return "video/quicktime";
  if (ext === ".webm") return "video/webm";
  return "application/octet-stream";
}

function sanitizeFilename(value) {
  return String(value || "").replace(/[^\w.-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}

function sendHtml(res, html) {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(html);
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload, null, 2));
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

import { resolveTaskDueAt } from "./creation-timing.js";

const INDICATOR_ID = "__fd_cms_schedule_indicator";

export function createCmsScheduleIndicatorController({ pages = [], control, onWarning } = {}) {
  const targetPages = [...new Set((pages || []).filter(Boolean))];
  let baseState = { status: "waiting", nextAt: "", originalAt: "", successAt: "", taskIndex: null };
  let started = false;
  let stopped = false;
  let controlState = readControlState(control);
  let controlTimer = null;
  let refreshInFlight = false;
  let warned = false;
  const reloadHandlers = new Map();

  const warnOnce = async (error) => {
    if (warned || typeof onWarning !== "function") return;
    warned = true;
    await Promise.resolve(onWarning(error)).catch(() => {});
  };

  const visibleState = () => ({
    ...baseState,
    status: controlState === "paused" ? "paused" : baseState.status
  });

  const renderPage = async (page) => {
    if (!page || page.isClosed?.()) return;
    try {
      await page.evaluate(renderCmsScheduleIndicator, {
        id: INDICATOR_ID,
        state: visibleState()
      });
    } catch (error) {
      await warnOnce(error);
    }
  };

  const renderAll = async () => {
    await Promise.all(targetPages.map((page) => renderPage(page)));
  };

  const refreshClockPage = async (page) => {
    if (!page || page.isClosed?.()) return;
    try {
      const refreshed = await page.evaluate(refreshCmsScheduleIndicatorClock, { id: INDICATOR_ID });
      if (!refreshed) await renderPage(page);
    } catch (error) {
      await warnOnce(error);
    }
  };

  const refreshAllClocks = async () => {
    await Promise.all(targetPages.map((page) => refreshClockPage(page)));
  };

  const update = async (payload = {}) => {
    const status = String(payload.status || baseState.status || "waiting");
    let nextAt = baseState.nextAt;
    let originalAt = baseState.originalAt;
    let successAt = baseState.successAt;
    let taskIndex = baseState.taskIndex;
    if (payload.task) {
      const nextTaskIndex = Number(payload.task.index || 0) || null;
      taskIndex = nextTaskIndex;
      try {
        nextAt = resolveTaskDueAt(payload.task).toISOString();
      } catch {
        nextAt = "";
      }
      try {
        originalAt = resolveTaskDueAt(payload.originalTask || payload.task).toISOString();
      } catch {
        originalAt = nextAt;
      }
      successAt = status === "succeeded"
        ? String(payload.successAt || successAt || "")
        : "";
    } else if (status === "completed") {
      nextAt = "";
      originalAt = "";
      successAt = "";
      taskIndex = null;
    }
    baseState = { status, nextAt, originalAt, successAt, taskIndex };
    if (started && !stopped) await renderAll();
  };

  const start = async (payload = {}) => {
    if (started || stopped) return;
    started = true;
    if (Object.keys(payload).length) await update(payload);
    for (const page of targetPages) {
      if (typeof page.on !== "function") continue;
      const handler = () => {
        if (!stopped) void renderPage(page);
      };
      reloadHandlers.set(page, handler);
      page.on("domcontentloaded", handler);
    }
    await renderAll();
    controlTimer = setInterval(() => {
      if (refreshInFlight) return;
      refreshInFlight = true;
      const nextControlState = readControlState(control);
      let refresh;
      if (nextControlState === controlState) {
        refresh = refreshAllClocks();
      } else {
        controlState = nextControlState;
        refresh = renderAll();
      }
      void refresh.finally(() => { refreshInFlight = false; });
    }, 1000);
    controlTimer.unref?.();
  };

  const stop = () => {
    stopped = true;
    if (controlTimer) clearInterval(controlTimer);
    controlTimer = null;
    for (const [page, handler] of reloadHandlers) page.off?.("domcontentloaded", handler);
    reloadHandlers.clear();
  };

  return {
    start,
    update,
    complete: () => update({ status: "completed" }),
    attention: (task) => update({ status: "attention", task }),
    stop
  };
}

function readControlState(control) {
  try {
    return String(control?.snapshot?.().control || "running");
  } catch {
    return "running";
  }
}

function renderCmsScheduleIndicator({ id, state }) {
  window.__fdCmsScheduleIndicatorState = state;

  const formatClock = (value) => {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "--:--:--";
    return [date.getHours(), date.getMinutes(), date.getSeconds()]
      .map((part) => String(part).padStart(2, "0"))
      .join(":");
  };
  const formatCountdown = (milliseconds) => {
    if (!Number.isFinite(milliseconds)) return "--";
    if (milliseconds <= 0) return "已到时间";
    const seconds = Math.ceil(milliseconds / 1000);
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const rest = seconds % 60;
    return [hours ? `${hours}小时` : "", minutes ? `${minutes}分` : "", `${rest}秒`].filter(Boolean).join("");
  };
  const statusLabel = (status) => ({
    waiting: "等待中",
    creating: "正在创建并发送",
    succeeded: "已确认发送",
    paused: "已暂停",
    attention: "等待人工处理",
    completed: "本轮已完成"
  }[status] || "运行中");

  const findHost = () => {
    const anchor = [...document.querySelectorAll("div,span,h1,h2,h3,h4,label")]
      .find((element) => element.textContent?.trim() === "执行发送设置");
    return anchor?.parentElement || document.body;
  };
  const mount = () => {
    if (!document.body || document.getElementById(id)) return;
    const host = findHost();
    const panel = document.createElement("div");
    panel.id = id;
    panel.setAttribute("aria-live", "polite");
    panel.style.cssText = [
      "pointer-events:none",
      "box-sizing:border-box",
      "min-width:220px",
      "padding:8px 12px",
      "border:1px solid #d7e3f4",
      "border-radius:4px",
      "background:#f7fbff",
      "color:#16324f",
      "font:13px/1.55 -apple-system,BlinkMacSystemFont,Segoe UI,Microsoft YaHei,sans-serif",
      "z-index:2147483646",
      "box-shadow:0 1px 4px rgba(31,78,121,.08)"
    ].join(";");
    if (host === document.body) {
      panel.style.position = "fixed";
      panel.style.top = "12px";
      panel.style.right = "12px";
    } else {
      if (getComputedStyle(host).position === "static") host.style.position = "relative";
      panel.style.position = "absolute";
      panel.style.top = "0";
      panel.style.right = "8px";
    }
    for (const [key, label] of [["status", "状态"], ["now", "现在"], ["next", "下一条"], ["original", "原定发送"], ["realtime", "实时发送"], ["countdown", "倒计时"]]) {
      const row = document.createElement("div");
      row.dataset.fdIndicatorRow = key;
      const name = document.createElement("span");
      const value = document.createElement("strong");
      name.textContent = `${label}：`;
      name.style.color = "#62778d";
      value.dataset.fdIndicatorValue = key;
      row.append(name, value);
      panel.append(row);
    }
    host.append(panel);
  };
  const paint = () => {
    mount();
    const panel = document.getElementById(id);
    if (!panel) return;
    const current = window.__fdCmsScheduleIndicatorState || {};
    const now = new Date();
    const next = current.nextAt ? new Date(current.nextAt) : null;
    const original = current.originalAt ? new Date(current.originalAt) : next;
    const success = current.successAt ? new Date(current.successAt) : null;
    const nextValid = next && !Number.isNaN(next.getTime());
    const originalValid = original && !Number.isNaN(original.getTime());
    const successValid = success && !Number.isNaN(success.getTime());
    const immediate = !successValid
      && !["completed"].includes(current.status)
      && nextValid
      && next.getTime() <= now.getTime();
    const set = (key, value) => {
      const target = panel.querySelector(`[data-fd-indicator-value="${key}"]`);
      if (target) target.textContent = value;
    };
    const show = (key, visible) => {
      const row = panel.querySelector(`[data-fd-indicator-row="${key}"]`);
      if (row) row.hidden = !visible;
    };
    const taskSuffix = current.taskIndex ? `（第 ${current.taskIndex} 条）` : "";
    set("status", statusLabel(current.status));
    const nowText = formatClock(now);
    set("now", nowText);
    set("next", nextValid
      ? `${formatClock(next)}${taskSuffix}`
      : "--");
    set("original", originalValid ? `${formatClock(original)}${taskSuffix}` : "--");
    set("realtime", successValid ? `${formatClock(success)}${taskSuffix}` : `${nowText}${taskSuffix}`);
    show("next", !immediate && !successValid);
    show("original", immediate || successValid);
    show("realtime", immediate || successValid);
    set("countdown", successValid
      ? "--"
      : current.status === "paused"
        ? (immediate ? "恢复后立即发送" : "暂停计时")
      : current.status === "completed"
        ? "--"
        : immediate
          ? "已到点，立即发送"
          : formatCountdown(nextValid ? next.getTime() - now.getTime() : Number.NaN));
  };

  paint();
  if (window.__fdCmsScheduleIndicatorTimer) {
    window.clearInterval(window.__fdCmsScheduleIndicatorTimer);
    window.__fdCmsScheduleIndicatorTimer = null;
  }
  if (!window.__fdCmsScheduleIndicatorObserver) {
    window.__fdCmsScheduleIndicatorObserver = new MutationObserver(() => {
      if (!document.getElementById(id)) paint();
    });
    window.__fdCmsScheduleIndicatorObserver.observe(document.documentElement, { childList: true, subtree: true });
  }
}

function refreshCmsScheduleIndicatorClock({ id }) {
  const panel = document.getElementById(id);
  if (!panel) return false;
  const current = window.__fdCmsScheduleIndicatorState || {};
  const now = new Date();
  const next = current.nextAt ? new Date(current.nextAt) : null;
  const success = current.successAt ? new Date(current.successAt) : null;
  const formatClock = (value) => {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "--:--:--";
    return [date.getHours(), date.getMinutes(), date.getSeconds()]
      .map((part) => String(part).padStart(2, "0"))
      .join(":");
  };
  const formatCountdown = (milliseconds) => {
    if (!Number.isFinite(milliseconds)) return "--";
    if (milliseconds <= 0) return "已到时间";
    const seconds = Math.ceil(milliseconds / 1000);
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const rest = seconds % 60;
    return [hours ? `${hours}小时` : "", minutes ? `${minutes}分` : "", `${rest}秒`].filter(Boolean).join("");
  };
  const writeText = (key, value) => {
    const target = panel.querySelector(`[data-fd-indicator-value="${key}"]`);
    if (target && target.textContent !== value) target.textContent = value;
  };
  const show = (key, visible) => {
    const row = panel.querySelector(`[data-fd-indicator-row="${key}"]`);
    if (row) row.hidden = !visible;
  };
  const nextValid = next && !Number.isNaN(next.getTime());
  const successValid = success && !Number.isNaN(success.getTime());
  const immediate = !successValid
    && !["completed"].includes(current.status)
    && nextValid
    && next.getTime() <= now.getTime();
  const suffix = current.taskIndex ? `（第 ${current.taskIndex} 条）` : "";
  const nowText = formatClock(now);
  writeText("now", nowText);
  if (immediate) writeText("realtime", `${nowText}${suffix}`);
  show("next", !immediate && !successValid);
  show("original", immediate || successValid);
  show("realtime", immediate || successValid);
  writeText("countdown", successValid
    ? "--"
    : current.status === "paused"
      ? (immediate ? "恢复后立即发送" : "暂停计时")
    : current.status === "completed"
      ? "--"
      : immediate
        ? "已到点，立即发送"
        : formatCountdown(nextValid ? next.getTime() - now.getTime() : Number.NaN));
  return true;
}

import { parseMonthDay } from "../date/date-rules.js";
import { normalizeClockInput } from "../time/clock-input.js";

export const CREATION_TIMING_SCHEDULED = "scheduled";
export const CREATION_TIMING_DUE_IMMEDIATE = "due-immediate";

export function normalizeCreationTimingMode(value) {
  return value === CREATION_TIMING_DUE_IMMEDIATE
    ? CREATION_TIMING_DUE_IMMEDIATE
    : CREATION_TIMING_SCHEDULED;
}

export function resolveTaskDueAt(task = {}, options = {}) {
  const now = resolveNow(options.now);
  const date = parseMonthDay(task.date);
  const time = normalizeClockInput(task.time);
  if (!date) throw timingError("CMS_CREATION_DUE_DATE_INVALID", `第 ${task.index || "?"} 条计划日期无效：${task.date || "空"}。`);
  if (!time) throw timingError("CMS_CREATION_DUE_TIME_INVALID", `第 ${task.index || "?"} 条计划时间无效：${task.time || "空"}。`);

  const explicitYear = /^\d{4}-\d{1,2}-\d{1,2}$/.test(String(task.date || "").trim());
  const year = explicitYear ? date.year : closestYearForMonthDay(date, now);
  const [hour, minute, second] = time.split(":").map(Number);
  const dueAt = new Date(year, date.month - 1, date.day, hour, minute, second, 0);
  if (dueAt.getFullYear() !== year || dueAt.getMonth() !== date.month - 1 || dueAt.getDate() !== date.day) {
    throw timingError("CMS_CREATION_DUE_DATE_INVALID", `第 ${task.index || "?"} 条计划日期不存在：${task.date || "空"}。`);
  }
  return dueAt;
}

export async function waitForTaskDue(task = {}, options = {}) {
  if (normalizeCreationTimingMode(options.mode) !== CREATION_TIMING_DUE_IMMEDIATE) {
    return { waited: false, dueAt: null, overdueMs: 0 };
  }
  const now = () => resolveNow(options.now);
  const dueAt = resolveTaskDueAt(task, { now: options.now });
  const sleep = typeof options.sleep === "function" ? options.sleep : defaultSleep;
  const waitingLabel = `第 ${task.index || "?"} 条等待计划时间 ${formatLocalDateTime(dueAt)}，到点后才开始创建并立即发送`;
  let remainingMs = dueAt.getTime() - now().getTime();
  if (remainingMs > 0) {
    await options.control?.checkpoint?.(waitingLabel);
    while ((remainingMs = dueAt.getTime() - now().getTime()) > 0) {
      const controlState = options.control?.snapshot?.().control;
      if (controlState && controlState !== "running") {
        await options.control?.checkpoint?.(waitingLabel);
      }
      await sleep(Math.min(1000, remainingMs));
    }
  }
  const startedAt = now();
  const overdueMs = Math.max(0, startedAt.getTime() - dueAt.getTime());
  await options.control?.checkpoint?.(
    `第 ${task.index || "?"} 条计划时间 ${formatLocalDateTime(dueAt)} 已到${overdueMs >= 1000 ? `（晚 ${Math.floor(overdueMs / 1000)} 秒）` : ""}，开始创建并立即发送`
  );
  return { waited: true, dueAt, startedAt, overdueMs };
}

export function formatLocalDateTime(value) {
  const date = new Date(value);
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())} ${pad2(date.getHours())}:${pad2(date.getMinutes())}:${pad2(date.getSeconds())}`;
}

function closestYearForMonthDay(date, now) {
  const year = now.getFullYear();
  const candidate = new Date(year, date.month - 1, date.day);
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const dayOffset = Math.round((candidate.getTime() - today.getTime()) / 86400000);
  if (dayOffset < -180) return year + 1;
  if (dayOffset > 180) return year - 1;
  return year;
}

function resolveNow(value) {
  if (typeof value === "function") return new Date(value());
  if (value) return new Date(value);
  return new Date();
}

function timingError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

function defaultSleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function pad2(value) {
  return String(value).padStart(2, "0");
}

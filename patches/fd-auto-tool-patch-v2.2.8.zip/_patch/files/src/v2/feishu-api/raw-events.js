import fs from "node:fs/promises";
import path from "node:path";
import { sourceOccurrenceIdsFrom } from "./source-identity.js";

export async function materializeFeishuApiRawEvents(result, options = {}) {
  const mediaCacheDir = options.mediaCacheDir;
  if (!mediaCacheDir) throw new Error("飞书 API 素材缺少 media-cache 目录。");
  await fs.mkdir(mediaCacheDir, { recursive: true });
  const assetPaths = new Map();
  for (const [assetId, asset] of result.assets || []) {
    if (asset.filePath) {
      assetPaths.set(String(assetId), asset.filePath);
      continue;
    }
    const extension = extensionForMime(asset.mime);
    const filePath = path.join(mediaCacheDir, `feishu-api-${String(assetId).padStart(4, "0")}${extension}`);
    await fs.writeFile(filePath, asset.buffer);
    assetPaths.set(String(assetId), filePath);
  }

  const events = [];
  for (const row of result.report?.rows || []) {
    if (row.type === "structure") {
      if (row.label === "分隔线") events.push({ sourceId: `feishu-api-${row.order}`, kind: "divider", text: "", sourceText: "" });
      continue;
    }
    if (row.type === "unsupported") {
      events.push({
        sourceId: `feishu-api-${row.order}`,
        sourceOccurrenceId: String(row.sourceOccurrenceId || ""),
        sourceOccurrenceIds: sourceOccurrenceIdsFrom(row),
        sourceRevision: row.sourceRevision,
        kind: "line",
        type: "line",
        text: "",
        sourceText: row.label || "未识别原文内容",
        blockId: String(row.blockId || ""),
        previewError: String(row.sourceError || "原文内容无法识别，请人工补充或设为不发。")
      });
      continue;
    }
    if (row.type === "title" && row.depth === 0) continue;
    if (["title", "heading", "text"].includes(row.type)) {
      if (!row.text && row.type !== "text") continue;
      events.push({
        sourceId: `feishu-api-${row.order}`,
        sourceOccurrenceId: String(row.sourceOccurrenceId || ""),
        sourceOccurrenceIds: sourceOccurrenceIdsFrom(row),
        sourceSegmentIds: Array.isArray(row.sourceSegmentIds) ? row.sourceSegmentIds : [],
        sourceRevision: row.sourceRevision,
        kind: row.type === "heading" ? "title" : "line",
        type: row.type === "heading" ? "title" : "line",
        text: row.text,
        sourceText: row.text,
        blockId: String(row.blockId || ""),
        headingLevel: row.type === "heading" ? Number(row.headingLevel || 0) || null : null,
        highlighted: row.segments?.some((segment) => segment.highlighted) || false,
        headerHighlighted: firstContentLineHighlighted(row.segments)
        ,...(row.sourceError ? { previewError: String(row.sourceError) } : {})
      });
      continue;
    }
    if (!["image", "file"].includes(row.type)) continue;
    const mediaPath = assetPaths.get(String(row.assetId)) || "";
    const kind = mediaKind(row, mediaPath);
    const recovering = row.mediaRecoveryStatus === "recovering";
    const previewError = row.mediaError
      ? `飞书 API 素材读取失败：${row.mediaError}。请在预览中重新选择素材后再创建。`
      : options.allowPendingMedia === true && !mediaPath
        ? ""
        : unsupportedFileError(row, kind);
    events.push({
      sourceId: `feishu-api-${row.order}`,
      sourceOccurrenceId: String(row.sourceOccurrenceId || ""),
      sourceOccurrenceIds: sourceOccurrenceIdsFrom(row),
      sourceRevision: row.sourceRevision,
      kind,
      type: kind,
      text: "",
      sourceText: row.text || row.label || "飞书素材",
      mediaPath,
      sourceUrl: "",
      assetUrl: "",
      feishuMediaStatus: mediaPath ? "downloaded" : recovering ? "recovering" : row.mediaError ? "failed" : "pending",
      feishuDeclaredKind: declaredKind(row),
      feishuBlockOrder: Number(row.order),
      blockId: String(row.blockId || ""),
      ...(recovering ? {
        mediaRecoveryState: "recovering",
        mediaRecoveryMessage: String(row.mediaRecoveryMessage || "系统正在自动补齐素材"),
        mediaRetryAfterMs: Math.max(0, Number(row.mediaRetryAfterMs || 0))
      } : {}),
      ...(previewError ? { previewError } : {})
    });
  }
  return events.map((event, index) => ({ ...event, order: index + 1, blockIndex: index, y: index }));
}

function firstContentLineHighlighted(segments = []) {
  if (!Array.isArray(segments) || !segments.length) return false;
  let offset = 0;
  const spans = segments.map((segment) => {
    const text = String(segment?.text || "");
    const span = { start: offset, end: offset + text.length, highlighted: Boolean(segment?.highlighted), text };
    offset = span.end;
    return span;
  });
  const text = spans.map((span) => span.text).join("");
  let lineStart = 0;
  while (lineStart <= text.length) {
    const newline = text.indexOf("\n", lineStart);
    const lineEnd = newline < 0 ? text.length : newline;
    if (text.slice(lineStart, lineEnd).replace(/\r/g, "").trim()) {
      return spans.some((span) => span.highlighted && span.start < lineEnd && span.end > lineStart);
    }
    if (newline < 0) break;
    lineStart = newline + 1;
  }
  return false;
}

function mediaKind(row, mediaPath) {
  if (["image", "sticker", "video"].includes(row.mediaKindHint)) return row.mediaKindHint;
  const mime = String(row.detectedMime || row.mime || "").trim().toLowerCase();
  const name = String(row.text || "").trim();
  const localPath = String(mediaPath || "").trim();
  if (mime.startsWith("video/") || hasExtension(name, ["mp4", "mov", "webm"]) || hasExtension(localPath, ["mp4", "mov", "webm"])) return "video";
  if (mime === "image/gif" || /表情|动态表情|sticker/i.test(name) || hasExtension(name, ["gif"]) || hasExtension(localPath, ["gif"])) return "sticker";
  if (mime.startsWith("image/") || hasExtension(name, ["png", "jpg", "jpeg", "webp", "avif"]) || hasExtension(localPath, ["png", "jpg", "jpeg", "webp", "avif"])) return "image";
  if (row.type === "image") return "image";
  return "unknown-media";
}

function unsupportedFileError(row, kind) {
  if (kind === "unknown-media") return `飞书 API 无法确认素材${row.text ? `“${row.text}”` : ""}的实际类型。请重新读取或更换素材后再创建。`;
  if (row.type !== "file" || kind === "video" || /^image\//i.test(row.mime || "")) return "";
  return `飞书 API 读取到暂不支持的附件${row.text ? `“${row.text}”` : ""}。请在预览中更换为图片或视频后再创建。`;
}

function declaredKind(row) {
  return mediaKind({ ...row, mime: "", detectedMime: "" }, "");
}

function hasExtension(value, extensions) {
  const clean = String(value || "").trim().split(/[?#]/, 1)[0];
  return new RegExp(`\\.(?:${extensions.join("|")})$`, "i").test(clean);
}

function extensionForMime(mime) {
  return ({
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif",
    "image/webp": ".webp",
    "image/avif": ".avif",
    "video/mp4": ".mp4",
    "video/quicktime": ".mov",
    "video/webm": ".webm"
  })[String(mime || "").toLowerCase()] || ".bin";
}

# 发单工具版本记录

## 2.1.7

- 恢复云中客确认创建弹窗的原有点击流程：第一次点击“确认创建”后短等 1.8 秒；若未检测到成功/失败且确认弹窗仍在、仍能找到蓝色“确认创建”按钮，则按原逻辑再点一次并等待正式结果，避免第一次点击未触发时卡在确认弹窗。绿色“任务创建成功”提示作为正式成功依据，即使页面暂时没恢复可编辑也不再判失败。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\real-cms-adapter.js`、`node --check tests\v2-real-cms-submit-before.test.js`，以及 `node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js tests\v2-cms-runner.test.js tests\v2-console.test.js`；确认创建原有重试流程、成功判定、运行中页面切换、创建 runner 和控制台相关测试共 115 项通过。
- 调整正式创建运行中的云中客页面切换：每条任务开始前和失败后重试当前条时，默认会用浏览器标签切换接口切到对应托/豆妈云中客页，不再只做后台定位；不使用系统鼠标点标签，仍保留显式 `focusDuringRun: false` 的后台模式给调试使用。控制台正式创建已改为启用可见切换。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\real-cms-adapter.js src\v2\cms\create-runner.js src\v2\console\workflow.js src\v2\tools\run-real-cms-cli.js tests\v2-real-cms-submit-before.test.js`，以及 `node --test --test-concurrency=1 tests\v2-real-cms-submit-before.test.js tests\v2-cms-runner.test.js tests\v2-console.test.js`；运行中页面切换、重试切页、创建 runner 和控制台相关测试共 113 项通过。
- 修复飞书里同一个说话人在同一秒连续发两条文字时，预览页把两条合并到同一条正文里的问题；现在重复出现新的“说话人 + 日期 + 时间”头部会按独立消息拆成多条，只有同一个头部来源被重复采集时才会忽略重复头。
- 验证：2026-09-27 在本机运行 `node --check src\v2\parser\parse-fixed-format.js tests\v2-parser-fixed-format.test.js`，以及 `node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js tests\v2-real-collect-range-parse.test.js tests\v2-feishu-collect.test.js`；同人同秒两条文字拆分、解析、飞书采集和真实范围解析相关测试共 117 项通过。
- 修复实时发创建时，预览日期已经是今天但 CMS 日期下拉只显示 `27号`、`9/27`、`9月27日` 等纯日期文本时，程序找不到“今天(27号)”而误报“CMS 定时日期选项不支持该日期”的问题；现在日期控件定位、选项点击和选中校验都会兼容这些显示方式。若目标日期就是今天且 CMS 当前已是今天，会跳过强制点日期，只填写时间；坐标扫描失败时会再用可见文字定位日期选项。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\schedule-date.js src\v2\cms\real-cms-adapter.js tests\v2-cms-schedule-date.test.js`，以及 `node --test --test-concurrency=1 tests\v2-cms-schedule-date.test.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-runner.test.js`；实时发日期匹配、CMS submit-before 和创建 runner 相关测试通过。
- 修复正式创建某条失败后点击“重试这一条”时，系统没有明确定位到该条对应的托/豆妈云中客页，导致重试流程容易和当前可见页面混淆的问题；现在重试当前失败条时会在后台定位到绑定的对应角色页继续执行，不把云中客窗口强行带到前台，正常连续创建仍保持不频繁抢前台。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\create-runner.js src\v2\cms\real-cms-adapter.js tests\v2-cms-runner.test.js`，以及 `node --test --test-concurrency=1 tests\v2-cms-runner.test.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-schedule-date.test.js`；重试当前条切回角色页、真实 CMS adapter 和日期匹配测试通过。
- 正常连续创建时，每条任务开始前也会在后台定位到该条对应的托/豆妈云中客页执行，不把窗口或标签页强行带到前台；在上传、等待素材极速就绪、等待确认弹窗等长步骤中，控制台选择“从下一条继续/从指定条继续”或“跳过当前条”也会及时生效，不再只能等长步骤超时或结束。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\create-runner.js src\v2\cms\real-cms-adapter.js src\v2\console\state.js tests\v2-cms-runner.test.js`，以及 `node --test --test-concurrency=1 tests\v2-cms-runner.test.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-schedule-date.test.js tests\v2-console.test.js`；连续创建后台定位、长步骤中继续/跳过、控制台状态流和 CMS 相关测试共 116 项通过。
- 发布：2026-09-27 将更新源 `latest.json` 发布为 `2.1.7`，补丁包 `patches/fd-auto-tool-patch-v2.1.7.zip` 可访问；在临时目录模拟从 `2.1.6` 套补丁成功，内置代码检查通过。

## 2.1.6

- 从文案库打开预览时，工作副本里的可发送条目日期会默认改为今天；原文案库保存内容不覆盖，时间、正文、素材和不发条目保持不变。
- 验证：2026-09-27 在本机运行 `node --check src\v2\preview\preview-library.js src\v2\console\workflow.js tests\v2-console.test.js`，以及 `node --test --test-concurrency=1 tests\v2-console.test.js`；文案库工作副本默认今日日期和控制台相关测试通过。
- 授权总控使用报表新增“详情”查看：汇总表保持原样，点击电脑名旁的详情可查看每轮开始/结束时间、状态、任务进度、脱敏场景和失败/中止原因；场景只包含阶段、角色、类型、日期、时间，不上传正文、素材路径或群名。
- 验证：2026-09-27 在本机运行 `node --check src\v2\license\license-manager.js src\v2\console\workflow.js src\v2\console\state.js`、`python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`，以及 `node --test --test-concurrency=1 tests\v2-license-manager.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`、`python -m unittest discover -s tools\server-license -p test_service.py`；使用详情上报、总控明细接口和控制台相关测试通过。
- 预览页说话人列会按托模式切换：粗略托/普通预览显示“说话人”并使用普通列宽，只有精准托名单任务才显示“人设 / 托号昵称 / 备选托”和精准托宽列。
- 验证：2026-09-27 在本机运行 `node --check src\v2\preview\preview-page.js tests\v2-preview-store.test.js`，以及 `node --test --test-concurrency=1 tests\v2-preview-store.test.js`；粗略托和精准托预览页展示测试通过。
- 从文案库打开预览并默认改为今天日期时，预览页顶部摘要区会显示醒目的浅黄色提示，说明已按今天更新日期且原文案库不会被覆盖；本机预览路径和当前目录改为默认收起的“高级/调试信息”。
- 验证：2026-09-27 在本机运行 `node --check src\v2\preview\preview-library.js src\v2\preview\preview-page.js tests\v2-preview-store.test.js`，以及 `node --test --test-concurrency=1 tests\v2-preview-store.test.js`；文案库日期提示、路径默认收起和预览页相关测试通过。
- 发布：2026-09-27 将更新源 `latest.json` 发布为 `2.1.6`，补丁包 `patches/fd-auto-tool-patch-v2.1.6.zip` 可访问；在临时目录模拟从 `2.1.5` 套补丁成功，内置代码检查通过。授权总控服务器 `miaoquan-license.service` 已同步服务脚本并重启，服务状态为 `active`，无 token 访问新报表接口返回 `403 ADMIN_DENIED`，确认新路由已加载且权限生效。

## 2.1.5

- 授权总控新增使用报表：客户端在正式创建开始和结束时上报脱敏使用记录，总控按今日/本周/上周汇总每台电脑的使用次数、总时长、平均时长、计划任务数、成功数、失败数、完成/失败/中止次数和最后使用时间。
- 使用报表只记录设备、版本、时间、任务数量和运行状态，不上传正文、素材、群名或业务内容；统计按北京时间切日和切周。
- 授权总控的“是否最新/更新状态”改为以总控侧最新客户端版本兜底判断，避免客户端未上报 latestVersion 时把旧版误标成“最新”；旧版本会显示“待更新到当前版本”。
- 修复 CMS 日期下拉偶发点错或识别不到“今天(27号)”的问题：日期控件定位会避开右侧时间输入，日期选项匹配优先精确日期，同时兼容 CMS 只显示“今天/明天/后天”的简写。
- 验证：2026-09-26 在本机运行 `node --check src\v2\license\license-manager.js src\v2\console\workflow.js`、`python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`，以及 `node --test --test-concurrency=1 tests\v2-license-manager.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`、`python -m unittest discover -s tools\server-license -p test_service.py`；客户端上报、总控报表汇总和控制台流程测试通过。
- 验证：2026-09-26 在本机运行 `python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`、`python -m unittest discover -s tools\server-license -p test_service.py`；总控旧版设备更新状态兜底显示测试通过。
- 验证：2026-09-27 在本机运行 `node --check src\v2\cms\real-cms-adapter.js tests\v2-cms-schedule-date.test.js`，以及 `node --test --test-concurrency=1 tests\v2-cms-schedule-date.test.js tests\v2-real-cms-submit-before.test.js tests\v2-cms-runner.test.js`；CMS 日期下拉匹配、正式创建前适配和创建执行骨架测试通过。

## 2.1.4

- 预览确认页的图片、表情包和视频缩略图支持点击小窗放大检查；不是大弹窗，点空白处、再点原缩略图或按 Esc 可关闭。
- 正式创建和预览保存后的自动流程不再主动把 2.0 浏览器/控制台切到前台，减少运行时抢光标；需要人工设置云中客时仍会按用户点击打开页面。
- 修复飞书同一条消息的媒体被重复识别成多条预览项的问题；同人同时间的相邻媒体在素材特征相同或画面位置明显相同时只保留一条，避免同一张图/表情包重复发送。
- “机器人不在群”的自动更换机器人默认重试上限从 3 次提高到 5 次，输入框仍可按本轮需要手动修改。
- 授权总控支持准实时设备监控：客户端控制台后台每 60 秒上报心跳、当前版本和更新状态；总控页面每 30 秒自动刷新，显示是否最新、在线状态、更新状态和最后心跳。
- 修复精准托按每条托词重新分配导致同一个原始托被拆成多个托的问题；同一互动托分组或同一明确原始说话人会固定复用同一个名单昵称。
- 精准托自动分配改为按同一人设内的托号数量做轮换冷却；例如宝妈人设有 10 个托时，会尽量等这一人设的其他托轮过后再复用，同一互动组继续说话只占一次使用位。
- 精准托预览页支持按本次托名单备注里的业务人设筛选托昵称；“无头像”“动物头”等头像类信息只作为附加标记显示，不作为人设分类。
- 精准托备选托会在当前行先推荐 2 个备选，并保留“更多备选”下拉显示当前人设下所有可选托；在用托改为浅蓝行内高亮，备选托改为浅灰行内样式，只有备用托额外显示浅橙“备用”标记，选择备选即可切换当前托昵称；同一互动组手动切换备选托时会同步后续同组托词；预览表头随页面滚动冻结显示，精准托列改为“人设 / 托号昵称 / 备选托”三列布局。
- 精准托预览页主行改为“在用 / 人设 / 托号昵称”，整体与日期、时间、类型、正文顶部水平对齐；人设列固定为短宽度，备选托区域下移并用分隔线留出间距，显示为“备选 / ① 托号 / ② 托号”和“更多 / 下拉框”，从人设列缩进对齐且尽量单行展示；“更多”和下拉框固定同一行，备选/更多标签按文字位置对齐。
- 验证：2026-09-24 在本机运行相关 `node --check`，以及 `node --test --test-concurrency=1 tests\v2-controlled-cms-browser.test.js tests\v2-console.test.js tests\v2-real-cms-submit-before.test.js tests\v2-preview-store.test.js`；受控浏览器、控制台、CMS submit-before 和预览页相关测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\parser\parse-fixed-format.js`，以及 `node --test --test-concurrency=1 tests\v2-parser-fixed-format.test.js`、`tests\v2-feishu-collect.test.js`、`tests\v2-real-collect-range-parse.test.js`；解析、采集和真实范围解析链路测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\tuo\precise-tuo-assigner.js tests\v2-precise-tuo.test.js`，以及 `node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`；精准托名单读取、分配和同托复用测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\tuo\tuo-roster.js src\v2\tuo\precise-tuo-assigner.js src\v2\preview\preview-page.js tests\v2-precise-tuo.test.js tests\v2-preview-store.test.js`，以及 `node --test --test-concurrency=1 tests\v2-preview-store.test.js tests\v2-precise-tuo.test.js`；动态人设解析、头像类附加标记、备选托点击保存、表头冻结和精准托预览测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\tuo\precise-tuo-assigner.js src\v2\preview\preview-page.js tests\v2-precise-tuo.test.js tests\v2-preview-store.test.js`，以及 `node --test --test-concurrency=1 tests\v2-precise-tuo.test.js`、`node --test --test-concurrency=1 tests\v2-preview-store.test.js`；同人设轮换冷却、同组备选同步和预览页交互测试通过。
- 验证：2026-09-26 在本机运行 `node --check src\v2\license\license-manager.js src\v2\console\server.js tests\v2-license-manager.test.js`、`python -m py_compile tools\server-license\service.py tools\server-license\test_service.py`，以及 `node --test --test-concurrency=1 tests\v2-license-manager.test.js tests\v2-license-entrypoints.test.js`、`node --test --test-concurrency=1 tests\v2-console.test.js`、`python -m unittest discover -s tools\server-license -p test_service.py`；授权心跳、总控在线/版本状态和控制台入口测试通过。

## 2.1.3

- 修复正式创建中底部“放弃本轮，重新设置”和“退出”被运行状态锁住的问题；这两个中止动作在 2.0 专用可控浏览器里保持可点击。
- “放弃本轮”和“退出”确认改为控制台页面内弹窗，提示内容改成分段分点展示，避免浏览器原生确认框被自动化弹窗状态影响。
- “退出”会优先请求 Chrome 关闭整个 2.0 专用受控浏览器，避免只关控制台而预览页残留。
- 将控制台、预览页、正式创建确认和常见错误提示里的 `preview.json` 改成“已保存的预览内容/预览内容文件”等普通用户能看懂的说法。
- 修复 `10点30催单`、`11点30点催单` 这类独立催单节奏标题被识别成正文发送的问题；正文句子里提到催单时间仍会保留。
- 启动控制台后会后台检查在线更新；发现新版本时先静默下载到待安装目录，不退出、不重启、不影响当前操作，下载好后提示“下次启动会自动更新”。
- 下次双击启动且后台服务未运行时，会先应用已下载好的补丁，再打开控制台；手动“立即更新”仍保留，作为需要马上切换版本时的备用入口。
- 验证：2026-09-24 在本机运行相关 `node --check`，以及 `node --test --test-concurrency=1 tests\v2-controlled-cms-browser.test.js tests\v2-console.test.js tests\v2-preview-store.test.js tests\v2-cms-preflight.test.js tests\v2-cms-dry-run.test.js tests\v2-cms-runner.test.js tests\v2-cms-page-actions.test.js tests\v2-real-cms-submit-before.test.js tests\v2-time.test.js tests\v2-parser-fixed-format.test.js tests\v2-heading-range.test.js tests\v2-collect-range-parse.test.js tests\v2-parser-cli.test.js tests\online-update.test.js tests\v2-version-manager.test.js`，相关测试通过。

## 2.1.2

- 修复文案库管理里“改名”“删除”使用浏览器原生弹窗导致点了没反应的问题，改为控制台页面内确认弹窗。
- 文案库改名或删除后会同步刷新右侧文案库列表和“管理文案库”弹窗列表，删除当前使用文案时会清掉当前使用标记。
- 在读取范围和时间模式处补充提示：直接使用文案库保存的预览时，不需要改读取范围，也不会按时间模式重新排时间；如需改时间请在预览页调整或重新读取飞书生成预览。

## 2.1.1

- 修复从文案库打开的预览只修改时间后，保存时被“未覆盖文案库原文案”提示误导，不能直接复用已设置好的云中客页面创建的问题。

## 2.1.0

- 修复正式创建暂停后，点击“继续”里的“从下一条开始”可能不生效的问题。

## 2.0.9

- 新增文案库选择和管理：可搜索文案名称，选择后在列表中标记为“当前使用”。
- 新增精准托按名单分配：支持上传 XLSX/CSV/JSON 托名单，只读取“昵称”和“备注”，生成预览前自动分配托说话人。
- 新增视频号参数任务：托/豆妈发言下方的 XML 参数整段进入“视频号”预览项，创建时填入云中客视频号入口。
- 调整“文案有变，重新生成预览”和“放弃本轮，重新设置”的行为，避免误复用文案库或旧预览状态。
- 修复改过预览日期后正式创建仍按当天创建的问题。

## 1.0.14

- 创建云中客任务前增加预览内容校验，避免预览有内容但创建时漏填。
- 文字任务填入后会读回核对，不完整会自动重填。
- 普通输入仍不完整时，会使用剪贴板粘贴兜底；兜底失败才停止，避免漏发。
- 图片、表情包、视频创建前会检查本地素材文件是否存在。

## 1.0.13

- 精推/合集读取中，`T1/T3/T10 + 下面有出现/下面还说话/同一个人两句话/有回复` 等互动标注不会再发成正文。
- 第一次识别到某个编号托是互动托后，后面同编号再次出现会继承同一个互动托。
- 预览和实际创建顺序都会把同一个互动托收在一起；原定时间不改。

## 1.0.12

- 修复精推项目里 `T3（下面还说话）` 这类括号标注没有触发互动托归组的问题。
- 精推同一节奏内，同一个编号互动托会先归到一起，再重新计算预览时间。
- 网页控制台同步显示扫描飞书、素材下载进度，不用只看黑色窗口。

## 1.0.11

- 控制台运行状态新增等待进度显示。
- 监控飞书等待下一次检查时，会显示百分比和小进度条。
- 生成预览后，控制台状态会更新为“预览已生成，等待确认”。

## 1.0.10

- 修复控制台“立即更新”点击后看起来没反应的问题。
- 点击“立即更新”后会立刻显示更新状态，不再先弹浏览器确认框。
- 更新失败时页面会显示具体失败原因，方便判断是网络、下载还是安装问题。

## 1.0.9

- 用户操作页面名称改为“妙券自动发单🚀”。
- 预览确认页、黑窗口启动提示和页面确认提示同步使用新名称。

## 1.0.8

- 优化“立即更新”按钮反馈，点击后会显示正在更新。
- 在线更新过程会在黑窗口输出检查、下载、解压、安装和结果提示。
- 已是最新版时会明确提示当前版本，不再像按钮没反应。

## 1.0.7

- 用户操作页面名称改为“妙券自动发单”。
- 预览确认页名称改为“妙券自动发单 - 预览确认”。
- 黑窗口启动和确认提示同步使用“妙券自动发单”名称。

## 1.0.6

- 修正 1.0.5 完整包打包路径问题，确保控制台实际加载的新代码里能看到“检查更新”按钮。
- 保持 GitHub 在线更新地址内置在新包配置中。

## 1.0.5

- 控制台新增在线检查更新和一键更新入口。
- 后续只要配置固定更新地址，用户可以在控制台直接检查并安装补丁。
- 在线补丁仍会走版本检查、更新前备份、补丁校验，不覆盖配置、历史记录、素材缓存和运行记录。

## 1.0.3

- 支持新版完整包的小补丁更新。
- 新增 `一键更新补丁.bat`，自动检查版本、备份旧文件、覆盖补丁文件并做代码检查。
- 新增 `恢复更新前版本.bat`，可恢复最近一次补丁更新前的程序文件。
- 补丁更新不会覆盖 `config.json`、`last-settings.json`、`cms-page-settings.json`、`runs/`、缓存和日志。
- 保留本轮已完成的可视化控制、精推目录读取、精推范围定位等改动。

## 1.0.2

- 当前工作版本。
- 在 `run.bat` 中支持先准备发单页面，再读取 `监控预览` 生成的最新结果执行。
- `监控预览.bat` 会把最新预览同步到 `latest-preview.json`，供 `run.bat` 使用。

## 1.0.1

- 稳定备份版本。
- 备份位置：`C:\Users\Administrator\Documents\ChatGPT\脚本程序\版本备份\fd-auto-tool-v1.0.1-稳定备份`
- 用途：后续如果 1.0.2 改坏了，可以从这里恢复。
